/**
 * \file Pixels/Bayer.h
 * \brief Classes for modeling Bayer CFA pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _BAYER_H
#define _BAYER_H

#include <stdint.h>

#include <Data/gold_data_export.h>

// NOTE: this patch allows compiling both MSVC e gcc-4.7
// MSVC requires templates without export specifiers for exporting symbols
// gcc-4.7 requires templates with export specifiers for exporting symbols
#ifndef GOLD_DATA_TEMPLATE_EXPORT
#if defined (_MSC_VER)
	#define GOLD_DATA_TEMPLATE_EXPORT
#else
	#define GOLD_DATA_TEMPLATE_EXPORT GOLD_DATA_EXPORT
#endif
#endif // GOLD_DATA_TEMPLATE_EXPORT


namespace cimage
{
  // namespace bayerpattern
  // {

	/**
	 * \brief Type modeling a BGGR bayer pattern
	 */
    class GOLD_DATA_TEMPLATE_EXPORT BGGR
    {
        public:

    		/** \brief returns the position of the Red pixel = 3 */
            inline static uint8_t R() { return 3; }

            /** \brief returns the position of the Green1 pixel = 1 */
            inline static uint8_t G1() { return 1; }

            /** \brief returns the position of the Green2  pixel = 2 */
            inline static uint8_t G2() { return 2; }

            /** \brief returns the position of the Blue pixel = 0 */
            inline static uint8_t B() { return 0; }
    };

	/**
	 * \brief Type modeling a GRBG bayer pattern
	 */
    class GOLD_DATA_TEMPLATE_EXPORT GRBG
    {
        public:
		    /** \brief returns the position of the Red pixel = 1 */
            inline static uint8_t R() { return 1; }

            /** \brief returns the position of the Green1 pixel = 0 */
            inline static uint8_t G1() { return 0; }

            /** \brief returns the position of the Green2  pixel = 3 */
            inline static uint8_t G2() { return 3; }

            /** \brief returns the position of the Blue pixel = 2 */
            inline static uint8_t B() { return 2; }
    };

	/**
	 * \brief Type modeling a RGGB bayer pattern
	 */
    class GOLD_DATA_TEMPLATE_EXPORT RGGB
    {
        public:
    	    /** \brief returns the position of the Red pixel = 0 */
            inline static uint8_t R() { return 0; }

            /** \brief returns the position of the Green1 pixel = 1 */
            inline static uint8_t G1() { return 1; }

            /** \brief returns the position of the Green2  pixel = 2 */
            inline static uint8_t G2() { return 2; }

            /** \brief returns the position of the Blue pixel = 3 */
            inline static uint8_t B() { return 3; }
    };

	/**
	 * \brief Type modeling a GBRG bayer pattern
	 */
    class GOLD_DATA_TEMPLATE_EXPORT GBRG
    {
        public:
    		/** \brief returns the position of the Red pixel = 1 */
            inline static uint8_t R() { return 2; }

            /** \brief returns the position of the Green1 pixel = 0 */
            inline static uint8_t G1() { return 0; }

            /** \brief returns the position of the Green2  pixel = 3 */
            inline static uint8_t G2() { return 3; }

            /** \brief returns the position of the Blue pixel = 1 */
            inline static uint8_t B() { return 1; }
    };
    
  //}

    /**
     * \brief Template for modeling a bayer pixel. The pixel is monochome and has one value.
     *
     * \tparam The argument shall belong to BGGR, GRBG, RGGB, GBRG.
     */
    template <class P>
    class GOLD_DATA_TEMPLATE_EXPORT Bayer : 
      public P
    {
      public:
	    /** \brief Default constructor */
        Bayer() {}

        /** \brief Constructor accepting a value for the pixel  */
        template<class T>
        explicit Bayer(T value) : pixel(static_cast<uint8_t>(value)) {}

        /* \brief Return the pixel value */
        operator uint8_t() { return pixel; }

        // TODO: operator ~
        /** \brief Set the current pixel value to the BITWISE AND between the current value and the argument */
        inline Bayer& operator &=(const Bayer& value){ pixel &= value.pixel; return *this; }

        /** \brief Set the current pixel value to the BITWISE OR between the current value and the argument */
        inline Bayer& operator |=(const Bayer& value){ pixel |= value.pixel; return *this; }

        /** \brief Set the current pixel value to the BITWISE XOR between the current value and the argument */
        inline Bayer& operator ^=(const Bayer& value){ pixel ^= value.pixel; return *this; }

        // TODO operator ~ friend inline
        /** \brief Returns a new pixel with value equal to the BITWISE AND between the two arguments */
        friend inline Bayer operator &(const Bayer& value_a, const Bayer& value_b) { return Bayer(value_a)&=value_b; }

        /** \brief Returns a new pixel with value equal to the BITWISE OR between the two arguments */
        friend inline Bayer operator |(const Bayer& value_a, const Bayer& value_b) { return Bayer(value_a)|=value_b; }

        /** \brief Returns a new pixel with value equal to the BITWISE XOR between the two arguments */
        friend inline Bayer operator ^(const Bayer& value_a, const Bayer& value_b) { return Bayer(value_a)^=value_b; }

        /** \brief Set the current pixel value to the SUM between the current value and the argument */
        inline Bayer& operator +=(const Bayer& value) { pixel += value.pixel; return *this; }

        /** \brief Set the current pixel value to the DIFFERENCE between the current value and the argument */
        inline Bayer& operator -=(const Bayer& value) { pixel -= value.pixel; return *this; }

        /** \brief Set the current pixel value to the PRODUCT between the current value and the argument */
        inline Bayer& operator *=(const Bayer& value) { pixel *= value.pixel; return *this; }

        /** \brief Set the current pixel value to the QUOTIENT between the current value and the argument */
        inline Bayer& operator /=(const Bayer& value) { pixel /= value.pixel; return *this; }

        /** \brief Set the current pixel value to the SUM between the current value and the argument */
        template <class T> inline Bayer& operator +=(const T factor) { pixel = static_cast<uint8_t>(factor + pixel); return *this; }

        /** \brief Set the current pixel value to the DIFFERENCE between the current value and the argument */
        template <class T> inline Bayer& operator -=(const T factor) { pixel = static_cast<uint8_t>(pixel - factor); return *this; }

        /** \brief Set the current pixel value to the PRODUCT between the current value and the argument */
        template <class T> inline Bayer& operator *=(const T factor) { pixel = static_cast<uint8_t>(factor * pixel); return *this; }

        /** \brief Set the current pixel value to the QUOTIENT between the current value and the argument */
        template <class T> inline Bayer& operator /=(const T factor) { pixel = static_cast<uint8_t>(pixel / factor); return *this; }

        /** \brief Set the current pixel value to the SUM between the current value and a Pixel obtained passing the argument to the constructor*/
        template <class T> inline Bayer& operator +(const T factor) { pixel += Bayer(factor); return *this; }

        /** \brief Set the current pixel value to the DIFFERENCE between the current value and a Pixel obtained passing the argument to the constructor*/
        template <class T> inline Bayer& operator -(const T factor) { pixel -= Bayer(factor); return *this; }

        /** \brief Set the current pixel value to the PRODUCT between the current value and a Pixel obtained passing the argument to the constructor*/
        template <class T> inline Bayer& operator *(const T factor) { pixel *= Bayer(factor); return *this; }

        /** \brief Set the current pixel value to the QUOTIENT between the current value and a Pixel obtained passing the argument to the constructor*/
        template <class T> inline Bayer& operator /(const T factor) { pixel /= Bayer(factor); return *this; }

        // friend operators
        /** \brief Returns a pixel with value equal to the SUM between between the arguments */
        friend inline Bayer operator +(const Bayer& a, const Bayer& b) { return Bayer(a.pixel+b.pixel); }

        /** \brief Returns a pixel with value equal to the DIFFERENCE  between the arguments */
        friend inline Bayer operator -(const Bayer& a, const Bayer& b) { return Bayer(a.pixel-b.pixel); }

        /** \brief Returns a pixel with value equal to the PRODUCT between the arguments */
        friend inline Bayer operator *(const Bayer& a, const Bayer& b) { return Bayer(a.pixel*b.pixel); }

        /** \brief Returns a pixel with value equal to the QUOTIENT between the arguments */
        friend inline Bayer operator /(const Bayer& a, const Bayer& b) { return Bayer(a.pixel/b.pixel); }

        /** \brief Returns a pixel with value equal to the SUM between between the arguments */
        template <class T> friend inline Bayer operator +(const T a, const Bayer& b) { return Bayer(a+b.pixel); }

        /** \brief Returns a pixel with value equal to the DIFFERENCE  between the arguments */
        template <class T> friend inline Bayer operator -(const T a, const Bayer& b) { return Bayer(a-b.pixel); }

        /** \brief Returns a pixel with value equal to the PRODUCT between the arguments */
        template <class T> friend inline Bayer operator *(const T a, const Bayer& b) { return Bayer(a*b.pixel); }

        /** \brief Returns a pixel with value equal to the QUOTIENT between the arguments */
        template <class T> friend inline Bayer operator /(const T a, const Bayer& b) { return Bayer(a/b.pixel); }

        // comparison operators
        /** \brief Returns true when the value of a is less than the value of b */
        friend inline bool operator < (const Bayer& a, const Bayer& b) { return a.pixel<b.pixel; }

        /** \brief Returns true when the value of a is greater than the value of b */
        friend inline bool operator > (const Bayer& a, const Bayer& b) { return a.pixel>b.pixel; }

        /** \brief Returns true when the value of a is equal or less  than the value of b */
        friend inline bool operator <= (const Bayer& a, const Bayer& b) { return a.pixel<=b.pixel; }

        /** \brief Returns true when the value of a is equal or greater than the value of b */
        friend inline bool operator >= (const Bayer& a, const Bayer& b) { return a.pixel>=b.pixel; }

        /** \brief Returns true when the value of a is strictly equal to the value of b */
        friend inline bool operator == (const Bayer& a, const Bayer& b) { return a.pixel==b.pixel; }

        /** \brief Returns true when the value of a is not equal to the value of b */
        friend inline bool operator != (const Bayer& a, const Bayer& b) { return a.pixel==b.pixel; }

        uint8_t pixel; ///< The bayer pixel value
    };
}


#endif
