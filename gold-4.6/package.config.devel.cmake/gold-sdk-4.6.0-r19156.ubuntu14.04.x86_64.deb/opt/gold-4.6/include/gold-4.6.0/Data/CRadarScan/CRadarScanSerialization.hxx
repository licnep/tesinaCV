#ifndef _CRADARSCAN_SERIALIZATION_HXX
#define _CRADARSCAN_SERIALIZATION_HXX

#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>

#include <boost/archive/text_oarchive.hpp>
#include <boost/archive/text_iarchive.hpp>

#include <boost/serialization/split_free.hpp>

#include <boost/date_time/posix_time/time_formatters.hpp>
#include <boost/date_time/gregorian/greg_serialize.hpp>
#include <boost/date_time/posix_time/time_serialize.hpp>

#include <boost/serialization/array.hpp>
#include <boost/serialization/vector.hpp>

#include <stdint.h>

#include <boost/math/constants/constants.hpp>

namespace data
{
  
class CRadarScanEcho;

// friend class boost::serialization::access;
// When the class Archive corresponds to an output archive, the
// & operator is defined similar to <<.  Likewise, when the class Archive
// is a type of input archive the & operator is defined similar to >>.
template<class Archive>
void serialize( Archive& ar, CRadarScanEcho& sp, unsigned int version )
{
  ar & sp.x;
  ar & sp.y;
  ar & sp.z;

  ar & sp.DeviceID;
  ar & sp.Echo;

  ar & sp.speed_x;
  ar & sp.speed_y;
  ar & sp.radial_speed;
  ar & sp.radial_range;
  ar & sp.angle;
  ar & sp.width;
  ar & sp.height;
  ar & sp.ObjectClassification;
  ar & sp.level_log;
  ar & sp.level_db;
}

class CRadarScan;

// friend class boost::serialization::access;
// When the class Archive corresponds to an output archive, the
// & operator is defined similar to <<.  Likewise, when the class Archive
// is a type of input archive the & operator is defined similar to >>.
template<class Archive>
void serialize( Archive& ar, CRadarScan& scan, unsigned int version )
{
    ar & scan.Cycle_Count;
  
    ar & scan.TimeStamp_Start;
    ar & scan.TimeStamp_End;

    ar & scan.Angle_Start;
    ar & scan.Angle_End;
    ar & scan.Distance_Start;
    ar & scan.Distance_End;
    
    ar & scan.ValidDataCounter;
    ar & scan.Status;
    ar & scan.SystemMode;
    ar & scan.SubSystemMode;

    ar & scan.Data;
}

} // namespace data

#endif // _CRADARSCAN_SERIALIZATION_HXX
