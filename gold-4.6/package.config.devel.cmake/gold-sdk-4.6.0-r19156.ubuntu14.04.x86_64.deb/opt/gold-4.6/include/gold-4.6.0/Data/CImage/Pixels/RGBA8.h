/**
 * \file RGBA8.h
 * \brief Definitions for modeling 4 channels, 8-bit unsigned integer RGBA pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>,
 */

#ifndef _RGBA8_H
#define _RGBA8_H

#include <Data/CImage/Pixels/TRGBA.h>

#include <stdint.h>

namespace cimage
{
/**
 * \brief Definition for RGB8 pixels
 * This pixel support 4 channels, 8-bit unsigned integer depth
 */
typedef TRGBA<uint8_t> RGBA8;

/**
 * \brief Definition for RGBA pixels
 * This pixel support 4 channels, 8-bit unsigned integer depth
 */
typedef RGBA8 RGBA;
}

#endif
