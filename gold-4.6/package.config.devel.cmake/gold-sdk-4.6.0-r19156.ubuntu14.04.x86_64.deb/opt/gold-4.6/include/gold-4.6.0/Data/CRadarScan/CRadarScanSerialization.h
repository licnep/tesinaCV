/**
 * \file CRadarScanSerialization.h
 * \brief Serialization for CRadarScan
 * \author Luca Gatti \<lucag@ce.unipr.it\>, Paolo Grisleri \<grisleri@ce.unipr.it>
 */

#ifndef _CRADARSCANSERIALIZATION_H
#define _CRADARSCANSERIALIZATION_H

#include <boost/filesystem/path.hpp>
#include <boost/property_tree/ptree_fwd.hpp>

#include <Data/CRadarScan/CRadarScan.h>
#include <Data/Base/FormatsEnumerator.h>

#include <Data/gold_data_export.h>

namespace data
{
/** \brief Data and operations related to CRadarScan */
namespace cradar
{

/** \brief Serialization for CRadarScan */
namespace serialization
{
  
/**
 * \brief Read a CRadarScan from a file
 * \param [in] file_name input file containing the CRadarScan to be de-serialized
 * \param [out] data the CRadarScan to be read from the stream
 * \return the number of bytes actually written on disk
 */
GOLD_DATA_EXPORT uint64_t Load(const boost::filesystem::path& url, CRadarScan& scan);

/**
 * \brief Write a CRadarScan on a file
 * \param [in] file_name name of the file were the CRadarScan will be serialized
 * \param [in] data the CRadarScan to be serialized
 * \return the number of bytes actually written on disk
 */
GOLD_DATA_EXPORT uint64_t Save(const boost::filesystem::path& url, const CRadarScan& scan);

/**
 * \brief Enumerator for the formats available
 */
typedef enum
{
	TXT, ///< string format
	BIN  ///< binary format
} FormatType;


/**
 * \brief Load a CRadarScan from a stream using the required format
 * \param [in] is from the CRadarScan has to be loaded
 * \param [in] data CRadarScan to be loaded
 * \param [in] fmt FormatType format type to be used
 * \param [in] options property tree containing the loading options
 *
 */
// GOLD_DATA_EXPORT void Load( std::istream& is,
//                             CRadarScan& data,
//                             FormatType fmt,
//                             boost::property_tree::ptree& options );

/**
 * \brief Save a CRadarScan on a stream using the required format
 * \param [in] data CRadarScan to be saved
 * \param [in] os ostream were to save the CRadarScan
 * \param [in] fmt FormatType format type be used
 * \param [in] options property tree containing the saving options
 */
// GOLD_DATA_EXPORT void Save( const CRadarScan& data,
//                             std::ostream& os,
//                             FormatType fmt,
//                             const boost::property_tree::ptree& options );


/**
 * \brief Load a CRadarScan from a stream using the binary format
 * \param [in] is istream from the CRadarScan has to be loaded
 * \param [in] data CRadarScan to be loaded
 * \param [in] options property_tree containing the options to be used for loading
 */
GOLD_DATA_EXPORT void Load_BIN( std::istream& is, CRadarScan& packet, boost::property_tree::ptree& options );

/**
 * \brief Load a CRadarScan from a stream using the text format
 * \param [in] is istream from the packet has to be loaded
 * \param [in] data packet to be loaded
 * \param [in] options property_tree containing the options to be used for loading
 */
GOLD_DATA_EXPORT void Load_TXT( std::istream& is, CRadarScan& packet, boost::property_tree::ptree& options );

/**
 * \brief Save a CRadarScan on a stream using the binary format
 * \param [in] os ostream were to save the packet
 * \param [in] data packet to be saved
 * \param [in] options property_tree containing the saving options
 */
GOLD_DATA_EXPORT void Save_BIN( const CRadarScan& packet, std::ostream& os, const boost::property_tree::ptree& options );

/**
 * \brief Save a CRadarScan on a stream using the text format
 * \param [in] os ostream were to save the packet
 * \param [in] data packet to be saved
 * \param [in] options property_tree containing the saving options
 */
GOLD_DATA_EXPORT void Save_TXT( const CRadarScan& packet, std::ostream& os, const boost::property_tree::ptree& options );

/**
 * \brief TFormatEnumerator containing the formats supported for serializing CRadarScan
 */
GOLD_DATA_EXPORT data::TFormatEnumerator<CRadarScan>& FormatEnumerator();

} // serialization
} // cradar
} // namespace data

#endif // _CRADARSCANSERIALIZATION_H
