/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/

/**
 * \file CImageRGB8.h
 * \brief Class for modeling a Red, Green, Blue, Alpha, 4-channels, 8-bits unsigned integer per channel image
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Paolo Zani (zani@ce.unipr.it)
 * \date 2006-05-03
 */

#ifndef _CIMAGERGBA_H
#define _CIMAGERGBA_H


#include <Data/CImage/TImage.h>
#include <Data/CImage/Pixels/RGBA8.h>

namespace cimage
{
  /** \brief Type for declaring a Red, Green, Blue, Alpha, 4-channels, 8-bits unsigned integer per channel image */
  typedef TImage<RGBA8> CImageRGBA8;

  /** \brief Type for declaring a Red, Green, Blue, Alpha, 4-channels, 8-bits unsigned integer per channel image */
  typedef CImageRGBA8 CImageRGBA;
}

#endif
