/**
 * @file SerializationUtils.h
 * @brief Common utilities used for writing data serialization modules
 * @author Paolo Grisleri (grisleri@ce.unipr.it)
 */

#ifndef _SERIALIZATION_UTILS_H
#define _SERIALIZATION_UTILS_H

#include <cstring>
#include <iostream>

namespace data
{

/** \brief Serialization functions utilities for data produced from devices and sensors */
namespace serialization
{


/**
 * \brief Skip the boost::serialization::text::iarchive header and return the read version
 * \param ifs input stream open on a boost serialization text iarchive already open
 * \param version return the archive version number
 */
inline void skip_text_iarchive_header(std::istream& ifs, int& version)
{
  char common_header[26]=// "22 serialization::archive "
  {
    0x32, 0x32, 0x20, 0x73, 0x65, 0x72, 0x69, 0x61, 
    0x6c, 0x69, 0x7a, 0x61, 0x74, 0x69, 0x6f, 0x6e, 
    0x3a, 0x3a, 0x61, 0x72, 0x63, 0x68, 0x69, 0x76, 
    0x65, 0x20 
  };
  
  char header[sizeof(common_header)+3];

  version=0;
  
  ifs.get(header, sizeof(header));
  
  // the stream could contain less than sizeof(header)-1 characters
  if( ifs.good() && 
      !strncmp( header, common_header, sizeof(common_header) ) )
  {
    // extract the version number
    version=header[sizeof(common_header)]-'0';
    if(header[sizeof(common_header)+1]!=' ') // isnum
    {
      version*=10;
      version+=header[sizeof(common_header)+1]-'0';
    }
  }
  else
    // stream rewind
    ifs.seekg(std::ios_base::beg);
} 

/**
 * \brief Skip the boost::serialization::bin::iarchive header and return the read version
 * \param ifs input stream pointing to a boost serialization bin iarchive already open
 * \param version return the archive version number
 */
inline void skip_bin_iarchive_header(std::istream& ifs, int& version)
{
  const char header_1_47[30]=
  {
    0x16, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x73, 0x65, 0x72, 0x69, 0x61, 0x6c, 0x69, 0x7a, 
    0x61, 0x74, 0x69, 0x6f, 0x6e, 0x3a, 0x3a, 0x61, 
    0x72, 0x63, 0x68, 0x69, 0x76, 0x65, /*0x09, 0x00, 
    0x04, 0x08, 0x04, 0x08, 0x01, 0x00, 0x00, 0x00, 
    0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1f, 
    0x00, 0x00, 0x00*/
  };

  char header[41/*sizeof(header_1_47)+1*/];
  
  version=9;
  
  ifs.get(header, sizeof(header));
  return;
  
  // the stream could contain less than sizeof(header)-1 characters
  if( ifs.good() && 
      !strncmp(header, header_1_47, sizeof(header_1_47) ) )
  {
    // extract the version number
    version=header[sizeof(header_1_47)]-'0';
    if(header[sizeof(header_1_47)+1]!=0x00) // isnum
    {
      version*=10;
      version+=header[sizeof(header_1_47)+1]-'0';
    }
  }
  else
    // stream rewind
    ifs.seekg(std::ios_base::beg);
}

} // namespace serialization

}// namespace data

#endif // _SERIALIZATION_UTILS_H
