/**
 * \file THSL.h
 * \brief Definitions for modeling Hue, Saturation, Lightness (HSL), 3 channel, generic pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Pietro Versari \<versari@ce.unipr.it\>
 */

#ifndef _THSL_H
#define _THSL_H

#include <boost/operators.hpp>

#include <Data/gold_data_export.h>


// NOTE: this patch is needed for compiling on both MSVC and gcc-4.7
// MSVC requires exported template symbol without specifiers
// gcc-4.7 requires exported template symbol with specifiers
#ifndef GOLD_DATA_TEMPLATE_EXPORT
#if defined (_MSC_VER)
        #define GOLD_DATA_TEMPLATE_EXPORT
#else
        #define GOLD_DATA_TEMPLATE_EXPORT GOLD_DATA_EXPORT
#endif
#endif // GOLD_DATA_TEMPLATE_EXPORT


namespace cimage
{

/**
 * \brief Class for modeling Hue, Saturation, Lightness (HSL), 3 channel, generic pixels
 * \tparam R type to be used as channel type for H, S and L values
 */
  template <class R>
  class GOLD_DATA_TEMPLATE_EXPORT THSL: 
          boost::addable< THSL<R> ,        
          boost::subtractable<THSL<R>,
          boost::multipliable<THSL<R>,
          boost::dividable<THSL<R>,
          boost::orable<THSL<R>,
          boost::andable<THSL<R>,
          boost::xorable<THSL<R>,
          boost::less_than_comparable <THSL<R>,
          boost::equality_comparable<THSL<R>
            > > > > > > > > >
  {
    public:

      /** \brief Enumerator for channel type */
      typedef enum Channels {HUE=0, SATURATION=1, LIGHTNESS=2} Channel;

      /** \brief Default constructor */
      THSL() {}

   	  /** \brief Constructor accepting a generic type that can be converted in R */
      template<class T>
      inline explicit THSL(const T v) :
        H(static_cast<R>(v)),
        S(static_cast<R>(v)),
        L(static_cast<R>(v)){}

      /** \brief Copy constructor from an HSL<T> with T convertible to R */
      template<class T>
      inline explicit THSL(const THSL<T>& v) :
        H(static_cast<R>(v.H)),
        S(static_cast<R>(v.S)),
        L(static_cast<R>(v.L)){}

      /** \brief Constructor accepting 3 separated H,S,L values of a convertible type */
      template<class T>
      inline explicit THSL(const T h, const T s, const T l) :
        H(static_cast<R>(h)),
        S(static_cast<R>(s)),
        L(static_cast<R>(l)){}
      
      /** \brief Returns true when the current pixel has each H, S, and L value less than the corresponding value of the argument */
      bool operator < (const THSL& a) const
      {
        return H<a.H  && S<a.S  && L<a.L;
      }

      /** \brief Returns true when the current pixel has each H, S, and L value strictly equal to the corresponding value of the argument */
      bool operator == (const THSL& a) const
      {
        return H==a.H  && S==a.S  && L==a.L;
      }

      /** \brief Set the current pixel value to the BITWISE AND between the current value and the argument */
      inline THSL& operator &=(const THSL& value)
      {
        H&=value.H, S&=value.S, L&=value.L;
        return *this;
      }
      /** \brief Set the current pixel value to the BITWISE OR between the current value and the argument */
      inline THSL& operator |=(const THSL& value)
      {
        H|=value.H, S|=value.S, L|=value.L;
        return *this;
      }

      /** \brief Set the current pixel value to the BITWISE XOR between the current value and the argument */
      inline THSL& operator ^=(const THSL& value)
      {
        H^=value.H, S^=value.S, L^=value.L;
        return *this;
      }

      /** \brief Set the current pixel value to the SUM between the current value and the argument */
      template<class T>
      inline THSL& operator +=(const THSL<T>& value)
      {
        H+=value.H, S+=value.S, L+=value.L;
        return *this;
      }

      /** \brief Set the current pixel value to the DIFFERENCE between the current value and the argument */
      template<class T>
      inline THSL& operator -=(const THSL<T>& value)
      {
        H-=value.H, S-=value.S, L-=value.L;
        return *this;
      }

      /** \brief Set the current pixel value to the PRODUCT between the current value and the argument */
      template<class T>
      inline THSL& operator *=(const THSL<T>& value)
      {
        H*=value.H, S*=value.S, L*=value.L;
        return *this;
      }

      /** \brief Set the current pixel value to the QUOTIENT between the current value and the argument */
      template<class T>
      inline THSL& operator /=(const THSL<T>& value)
      {
        H/=value.H, S/=value.S, L/=value.L;
        return *this;
      }

      /** \brief Set the current pixel value to the SUM between the current value and the argument */
      template<class T>
      inline THSL& operator +=(const T factor)
      {
        H=static_cast<R>(factor+H),
        S=static_cast<R>(factor+S),
        L=static_cast<R>(factor+L);
        return *this;
      }

      /** \brief Set the current pixel value to the DIFFERENCE between the current value and the argument */
      template<class T>
      inline THSL &operator -= ( const T factor )
      {
        H=static_cast<R> ( H-factor ),
        S=static_cast<R> ( S-factor ),
        L=static_cast<R> ( L-factor );
        return *this;
      }

      /** \brief Set the current pixel value to the PRODUCT between the current value and the argument */
      template<class T>
      inline THSL& operator *=(const T factor)
      {
        H=static_cast<R>(factor*H),
        S=static_cast<R>(factor*S),
        L=static_cast<R>(factor*L);
        return *this;
      }

      /** \brief Set the current pixel value to the QUOTIENT between the current value and the argument */
      template<class T>
      inline THSL &operator /= ( const T factor )
      {
        H=static_cast<R> ( H/factor ),
        S=static_cast<R> ( S/factor ),
        L=static_cast<R> ( L/factor );
        return *this;
      }

      /** \brief Returns a THSL obtained from the SUM between a two THSL arguments */
      template<class T> inline friend THSL operator +(const T factor, const THSL& value) { return THSL(value)+=factor; }

      /** \brief Returns a THSL obtained from the DIFFERENCE between a two THSL arguments */
      template<class T > inline friend THSL operator -(const T factor, const THSL& value) { return THSL(value)-=factor; }

      /** \brief Returns a THSL obtained from the PRODUCT between a two THSL arguments */
      template<class T > inline friend THSL operator *(const T factor, const THSL& value) { return THSL(value)*=factor; }

      /** \brief Returns a THSL obtained from the QUOTIENT between a two THSL arguments */
      template<class T> inline friend THSL operator /(const T factor, const THSL& value) { return THSL(value)/=factor; }

      /**
       * \brief Returns the value of the channel with index selected from the argument
       * \param i channel number
       * \return the value for the i-th channel
       */
      R operator [](unsigned int i) const { return *(&H+i); }
      
      /** \brief Prints the pixel values on a stream */
      friend inline std::ostream& operator << (std::ostream& os, const THSL& value) { /* TODO... */ return os; }
      
      R H;  ///< The Hue channel value
      R S;  ///< The Saturation channel value
      R L;  ///< The Lightness channel value
  };
}

#endif

