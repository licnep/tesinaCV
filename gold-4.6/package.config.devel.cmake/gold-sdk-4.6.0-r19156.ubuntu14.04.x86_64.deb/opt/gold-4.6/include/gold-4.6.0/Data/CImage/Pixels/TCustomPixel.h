/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/

/**
 * \file TCustomPixel.h
 * \brief Definitions for modeling 1 channel, generic pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Paolo Zani (zani@ce.unipr.it)
 * \date 2006-10-23
 */

#ifndef _TCUSTOMPIXEL_H
#define _TCUSTOMPIXEL_H

#include <iostream>

#ifndef TCUSTOMPIXEL_EXPORT
#error "Define TCUSTOMPIXEL_EXPORT to the library export macro before including TCustomPixel.h and undefine it afterwards."
#endif

namespace cimage
{

/**
 * \brief TCustomPixel data type class
 * This class represents a generic image pixel type
 * \note whenever you need low level access to a TCustomPixel buffer raw data, you can safely cast it to a T buffer:
 * \code
 *     typedef TCustomPixel<double, _MyType> MyType;
 *
 *     MyType* p_buffer = new MyType[50];
 *     double* p_raw_byffer = reinterpret_cast<double*>(p_buffer);
 * \endcode
 * \tparam P type to be used as channel type
 * \tparam Q type to be used as pixel name
 */
template<typename P, typename Q>
class TCUSTOMPIXEL_EXPORT TCustomPixel
{
public:
	/** \brief Default constructor */
	TCustomPixel()
	{}

	/** \brief Constructor accepting a generic type that can be converted in P */
	template <typename T>
	explicit TCustomPixel(const T& d) : pixel(static_cast<P>(d))
	{}

	/** \brief Copy constructor */
	TCustomPixel(const TCustomPixel& d)
	{	pixel = d.pixel;}

	/** \brief Automatic conversion operator to type T */
	template <typename T>
	operator T() const
	{	return static_cast<T>(pixel);}

	// inline void operator ~() { /*???*/ pixel=~pixel ; return *this; }

    /** \brief Set the current pixel value to the BITWISE AND between the current value and the argument */
	inline TCustomPixel operator &= (const TCustomPixel& d)
	{	pixel &= d.pixel; return *this;}

    /** \brief Set the current pixel value to the BITWISE OR between the current value and the argument */
	inline TCustomPixel operator |= (const TCustomPixel& d)
	{	pixel |= d.pixel; return *this;}

    /** \brief Set the current pixel value to the BITWISE XOR between the current value and the argument */
	inline TCustomPixel operator ^= (const TCustomPixel& d)
	{	pixel ^= d.pixel; return *this;}

	// TODO operator ~ friend inline
    /** \brief Returns a TCustomPixel obtained from the BITWISE AND between the arguments */
	template <typename T> friend inline TCustomPixel operator &(const TCustomPixel& value_a, const T& value_b)
	{	return TCustomPixel(value_a)&=value_b;}

	/** \brief Returns a TCustomPixel obtained from the BITWISE OR between the arguments */
	template <typename T> friend inline TCustomPixel operator |(const TCustomPixel& value_a, const T& value_b)
	{	return TCustomPixel(value_a)|=value_b;}

	/** \brief Returns a TCustomPixel obtained from the BITWISE XOR between the arguments */
	template <typename T> friend inline TCustomPixel operator ^(const TCustomPixel& value_a, const T& value_b)
	{	return TCustomPixel(value_a)^=value_b;}

	// FIXME ambiguous operators
	// template <typename T> friend inline TCustomPixel &operator &(const T& value_a, const TCustomPixel& value_b) { return TCustomPixel(value_a)&=value_b; }
	// template <typename T> friend inline TCustomPixel &operator |(const T& value_a, const TCustomPixel& value_b) { return TCustomPixel(value_a)|=value_b; }
	// template <typename T> friend inline TCustomPixel &operator ^(const T& value_a, const TCustomPixel& value_b) { return TCustomPixel(value_a)^=value_b; }

	/** \brief Assignment operator: the current pixel gets the same value of the argument */
	inline TCustomPixel operator = (const TCustomPixel& d)
	{	pixel = d.pixel; return *this;}

    /** \brief Set the current pixel value to the SUM between the current value and the argument */
	inline TCustomPixel operator += (const TCustomPixel& d)
	{	pixel += d.pixel; return *this;}

	/** \brief Set the current pixel value to the DIFFERENCE between the current value and the argument */
	inline TCustomPixel operator -= (const TCustomPixel& d)
	{	pixel -= d.pixel; return *this;}

	/** \brief Set the current pixel value to the PRODUCT between the current value and the argument */
	inline TCustomPixel operator *= (const TCustomPixel& d)
	{	pixel *= d.pixel; return *this;}

	/** \brief Set the current pixel value to the QUOTIENT between the current value and the argument */
	inline TCustomPixel operator /= (const TCustomPixel& d)
	{	pixel /= d.pixel; return *this;}

	/** \brief Assignment operator: the current pixel gets the value of the argument*/
	template <typename T> inline TCustomPixel operator = (const T& d)
	{	pixel = d; return *this;}

    /** \brief Set the current pixel value to the SUM between the current value and the argument */
	template <typename T> inline TCustomPixel& operator += (const T& factor)
	{	pixel = pixel + factor; return *this;}

	/** \brief Set the current pixel value to the DIFFERENCE between the current value and the argument */
	template <typename T> inline TCustomPixel& operator -= (const T& factor)
	{	pixel = pixel - factor; return *this;}

	/** \brief Set the current pixel value to the PRODUCT between the current value and the argument */
	template <typename T> inline TCustomPixel& operator *= (const T& factor)
	{	pixel = pixel * factor; return *this;}

	/** \brief Set the current pixel value to the QUOTIENT between the current value and the argument */
	template <typename T> inline TCustomPixel& operator /= (const T& factor)
	{	pixel = pixel / factor; return *this;}

	// friend operators
    /** \brief Returns a TCustomPixel obtained from the SUM between a type convertible to a TCustomPixel value and a TCustomPixel */
	template <typename T> friend inline TCustomPixel operator + (const T& d1, const TCustomPixel& d2)
	{	return TCustomPixel(d1+d2.pixel);}

	/** \brief Returns a TCustomPixel obtained from the SUM between a type convertible to a TCustomPixel value and a TCustomPixel */
	template <typename T> friend inline TCustomPixel operator + (const TCustomPixel& d1, const T& d2)
	{	return TCustomPixel(d2+d1.pixel);}

	/** \brief Returns a TCustomPixel obtained from the DIFFERENCE between a type convertible to a TCustomPixel value and a TCustomPixel */
	template <typename T> friend inline TCustomPixel operator - (const T& d1, const TCustomPixel& d2)
	{	return TCustomPixel(d1-d2.pixel);}

	/** \brief Returns a TCustomPixel obtained from the DIFFERENCE between a TCustomPixel and a type convertible to a TCustomPixel value */
	template <typename T> friend inline TCustomPixel operator - (const TCustomPixel& d1, const T& d2)
	{	return TCustomPixel(d1.pixel-d2);}

	/** \brief Returns a TCustomPixel obtained from the PRODUCT between a type convertible to a TCustomPixel value and a TCustomPixel */
	template <typename T> friend inline TCustomPixel operator * (const T& d1, const TCustomPixel& d2)
	{	return TCustomPixel(d1*d2.pixel);}

	/** \brief Returns a TCustomPixel obtained from the PRODUCT between a type convertible to a TCustomPixel value and a TCustomPixel */
	template <typename T> friend inline TCustomPixel operator * (const TCustomPixel& d1, const T& d2)
	{	return TCustomPixel(d1.pixel*d2);}

	/** \brief Returns a TCustomPixel obtained from the QUOTIENT between a type convertible to a TCustomPixel value and a TCustomPixel */
	template <typename T> friend inline TCustomPixel operator / (const T& d1, const TCustomPixel& d2)
	{	return TCustomPixel(d1/d2.pixel);}

	/** \brief Returns a TCustomPixel obtained from the QUOTIENT between a TCustomPixel and a type convertible to a TCustomPixel value */
	template <typename T> friend inline TCustomPixel operator / (const TCustomPixel& d1, const T& d2)
	{	return TCustomPixel(d1.pixel/d2);}

	/** \brief Returns true if a type convertible to a TCustomPixel value d1 is less than the  TCustomPixel d2; false otherwise*/
	template <typename T> friend inline bool operator < (const T& d1, const TCustomPixel& d2)
	{	return d1 < d2.pixel;}

	/** \brief Returns true if the TCustomPixel d1 is less than a type convertible to a TCustomPixel value d2; false otherwise */
	template <typename T> friend inline bool operator < (const TCustomPixel& d1, const T& d2)
	{	return d1.pixel < d2;}

	/** \brief Returns true if a type convertible to a TCustomPixel value d1 is equal or less than the  TCustomPixel d2; false otherwise*/
	template <typename T> friend inline bool operator <= (const T& d1, const TCustomPixel& d2)
	{	return d1 <= d2.pixel;}

	/** \brief Returns true if the TCustomPixel d1 is equal or less than a type convertible to a TCustomPixel value d2; false otherwise */
	template <typename T> friend inline bool operator <= (const TCustomPixel& d1, const T& d2)
	{	return d1.pixel <= d2;}

	/** \brief Returns true if a type convertible to a TCustomPixel value d1 is greater than the  TCustomPixel d2; false otherwise*/
	template <typename T> friend inline bool operator > (const T& d1, const TCustomPixel& d2)
	{	return d1 > d2.pixel;}

	/** \brief Returns true if the TCustomPixel d1 is greater than a type convertible to a TCustomPixel value d2; false otherwise */
	template <typename T> friend inline bool operator > (const TCustomPixel& d1, const T& d2)
	{	return d1.pixel > d2;}

	/** \brief Returns true if a type convertible to a TCustomPixel value d1 is equal or greater than the  TCustomPixel d2; false otherwise*/
	template <typename T> friend inline bool operator >= (const T& d1, const TCustomPixel& d2)
	{	return d1 >= d2.pixel;}

	/** \brief Returns true if the TCustomPixel d1 is equal or greater than a type convertible to a TCustomPixel value d2; false otherwise */
	template <typename T> friend inline bool operator >= (const TCustomPixel& d1, const T& d2)
	{	return d1.pixel >= d2;}

	/** \brief Returns true if a type convertible to a TCustomPixel value d1 is strictly equal than the  TCustomPixel d2; false otherwise*/
	template <typename T> friend inline bool operator == (const T& d1, const TCustomPixel& d2)
	{	return d1 == d2.pixel;}

	/** \brief Returns true if the TCustomPixel d1 is strictly equal to a type convertible to a TCustomPixel value d2; false otherwise */
	template <typename T> friend inline bool operator == (const TCustomPixel& d1, const T& d2)
	{	return d1.pixel == d2;}

	/** \brief Returns true if a type convertible to a TCustomPixel value d1 is not equal or greater than the  TCustomPixel d2; false otherwise*/
	template <typename T> friend inline bool operator != (const T& d1, const TCustomPixel& d2)
	{	return d1 != d2.pixel;}

	/** \brief Returns true if the TCustomPixel d1 is not equal to a type convertible to a TCustomPixel value d2; false otherwise */
	template <typename T> friend inline bool operator != (const TCustomPixel& d1, const T& d2)
	{	return d1.pixel != d2;}

	// these are needed to avoid ambiguous resolutions for the templates above

    /** \brief Returns a TCustomPixel obtained from the SUM between a two TCustomPixel arguments */
	friend inline TCustomPixel operator + (const TCustomPixel& d1, const TCustomPixel& d2)
	{	return TCustomPixel(d1) += d2;}

	/** \brief Returns a TCustomPixel obtained from the DIFFERENCE between a two TCustomPixel arguments */
	friend inline TCustomPixel operator - (const TCustomPixel& d1, const TCustomPixel& d2)
	{	return TCustomPixel(d1) -= d2;}

	/** \brief Returns a TCustomPixel obtained from the PRODUCT between a two TCustomPixel arguments */
	friend inline TCustomPixel operator * (const TCustomPixel& d1, const TCustomPixel& d2)
	{	return TCustomPixel(d1) *= d2;}

	/** \brief Returns a TCustomPixel obtained from the QUOTIENT between a two TCustomPixel arguments */
	friend inline TCustomPixel operator / (const TCustomPixel& d1, const TCustomPixel& d2)
	{	return TCustomPixel(d1) /= d2;}

	/** \brief Returns true if the TCustomPixel d1 is less than the TCustomPixel d2; false otherwise */
	friend inline bool operator < (const TCustomPixel& d1, const TCustomPixel& d2)
	{	return d1.pixel < d2.pixel;}

	/** \brief Returns true if the TCustomPixel d1 is greater than the TCustomPixel d2; false otherwise */
	friend inline bool operator > (const TCustomPixel& d1, const TCustomPixel& d2)
	{	return d1.pixel > d2.pixel;}

	/** \brief Returns true if the TCustomPixel d1 is strictly equal to the TCustomPixel d2; false otherwise */
	friend inline bool operator == (const TCustomPixel& d1, const TCustomPixel& d2)
	{	return d1.pixel == d2.pixel;}

	/** \brief Returns true if the TCustomPixel d1 is not equal to the TCustomPixel d2; false otherwise */
	friend inline bool operator != (const TCustomPixel& d1, const TCustomPixel& d2)
	{	return d1.pixel != d2.pixel;}

	/** \brief ostream output operator: write the value of TCustomPixel on the output stream */
	friend std::ostream& operator << (std::ostream& os, const TCustomPixel& d)
	{	return os << d.pixel;}

	P pixel; ///< The pixel value
};

} // namespace cimage

/**
 * \brief Macro for declaring a new Custom Pixel
 * \param DATATYPE the internal type used by the pixel
 * \param NAME the name of the new type
 * \param An export macro of the library containing the new type
 */
#define CIMAGE__DECLARE_CUSTOM_PIXEL( DATATYPE, NAME, TCP_EXPORT ) \
    class TCP_EXPORT _##NAME{};\
    typedef  cimage::TCustomPixel<DATATYPE, _##NAME> NAME;

#endif    
