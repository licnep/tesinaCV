/**
 * \file Pixels/HSL8.h
 * \brief Definitions for modeling HSL, 3 channels, 32-bit float pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Pietro Versari \<versari@ce.unipr.it\>
 */

 #ifndef _HSL8_H
 #define _HSL8_H

 #include <Data/CImage/Pixels/THSL.h>
 #include <stdint.h>

 namespace cimage
 {

 /**
 * \brief Definition for HSL8.
 * This pixel support Hue, Saturation and Lightness if three separated 8-bit unsigned integer channels
 * \see THSL
 */
typedef THSL<uint8_t> HSL8;

/**
 * \brief Definition for HSL8u.
 * This pixel support Hue, Saturation and Lightness if three separated 8-bit unsigned integer channels
 * \see THSL
 */
typedef THSL<uint8_t> HSL8u;

}

#endif // _HSL8_H
