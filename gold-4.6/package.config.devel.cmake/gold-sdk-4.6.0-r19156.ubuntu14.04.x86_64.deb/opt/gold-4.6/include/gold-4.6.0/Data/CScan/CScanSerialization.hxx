#ifndef _CSCAN_SERIALIZATION_HXX
#define _CSCAN_SERIALIZATION_HXX

#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/archive/text_oarchive.hpp>
#include <boost/archive/text_iarchive.hpp>

#include <boost/serialization/split_free.hpp>
#include <boost/serialization/array.hpp>
#include <boost/serialization/vector.hpp>

#include <boost/date_time/gregorian/greg_serialize.hpp>
#include <boost/date_time/posix_time/time_serialize.hpp>

#include <stdint.h>

#include <boost/math/constants/constants.hpp>

#include "CScan0_Serialization.hxx"  // compatibility with the the previous version

namespace data{ struct CScanEcho; }
BOOST_CLASS_VERSION(data::CScanEcho, 2);   // class serialization version

namespace data{ class CScan; }
BOOST_CLASS_VERSION(data::CScan, 1);   // class serialization version

namespace data
{

// friend class boost::serialization::access;
// When the class Archive corresponds to an output archive, the
// & operator is defined similar to <<.  Likewise, when the class Archive
// is a type of input archive the & operator is defined similar to >>.
template<class Archive>
void serialize(Archive & ar, CScanEcho& sp, const unsigned int version)
{
  ar & sp.x;
  ar & sp.y;
  ar & sp.z;

  ar & sp.Width;
  ar & sp.Classification;

  ar & sp.DeviceID;
  ar & sp.Layer;
  ar & sp.Echo;
}


void Scan0_to_Scan(const CScan0&Scan0, CScan& Scan);

// friend class boost::serialization::access;
// When the class Archive corresponds to an output archive, the
// & operator is defined similar to <<.  Likewise, when the class Archive
// is a type of input archive the & operator is defined similar to >>.
template<class Archive>
void serialize(Archive& ar, CScan& scan, const unsigned int version)
{
    if(version==1)
    {
      ar & scan.TimeStamp_Start;
      ar & scan.TimeStamp_End;

      ar & scan.Angle_Start;
      ar & scan.Angle_End;

      ar & scan.Data;
//       std::cout << "serializing data " << scan.Data.size() << std::endl;
    }
    // If the version number is 0
    // loads a CScan0 and do the conversion
    else if(version==0)
    {
      CScan0 tmp; // previous format

      // file loading using the previous format
      serialize<Archive>(ar, tmp, version);

      Scan0_to_Scan(tmp, scan);
    }
}

// Conversion from the version 0 to version 1
void Scan0_to_Scan(const CScan0& scan0, CScan& scan)
{
  static CScanEcho::ClassificationID ClassificationLUT[5] = 
  {
    CScanEcho::INVALID,
    CScanEcho::NORMAL,
    CScanEcho::RAIN,
    CScanEcho::GROUND,
    CScanEcho::DIRT
  };

  scan.Angle_Start = scan0.Angle_Start;
  scan.Angle_End   = scan0.Angle_End;

  scan.TimeStamp_Start = scan0.TimeStamp_Start;
  scan.TimeStamp_End = scan0.TimeStamp_End;

  const double rad_2_deg = 180.0/boost::math::constants::pi<double>();
  // const double deg_2_rad = boost::math::constants::pi<double>()/180.0;

  const unsigned int nl=scan0.NumLayers();

  // fills a buffer with the number of echoes for each layer
  boost::array<unsigned int, 4> nel={{0u,0u,0u,0u}};
  std::size_t size = 0u;
  for(unsigned int i=0; i<nl; ++i)
  {
    nel[i]=static_cast<unsigned int>(scan0.Layers[i].NumPulses());
    size+=nel[i];
  }

  // resize the destination vector
  scan.Data.resize(size);

  // copy data en find the scan angular limits
  // Scan.Angle_Start = -boost::math::constants::pi<double>(); 
  // Scan.Angle_End   = +boost::math::constants::pi<double>(); 
  std::vector<double> angles(scan.Data.size());

  unsigned int dst_idx=0u;
  for(unsigned int l=0; l<nl; ++l)
    for(unsigned int i=0; i<nel[l]; ++i,++dst_idx)
    {
      const CScanEcho0& e0( scan0.Layers[l].Pulses[i] );
      CScanEcho& dst = scan.Data[dst_idx];

      // angles[i] = atan2(e0.y,e0.x);
      // Scan.Angle_Start = std::max(Scan.Angle_Start, angles[i]);
      // Scan.Angle_End   = std::min(Scan.Angle_End , angles[i]);

      static_cast<math::Point3d&>(dst) = static_cast<const math::Point3d&>(e0);
      dst.Width = e0.Length;

      dst.Classification=ClassificationLUT[e0.Classification];
      dst.DeviceID=e0.DeviceID;
      dst.Layer=l;
      dst.Echo=e0.ID;
    }

  if(false)
    for(unsigned int i=0; i<scan.Data.size(); ++i)
    {
      CScanEcho& e( scan.Data[i] );
      // PrintStats(Scan);
      std::cout << "index=" << e.Layer << "." << e.Echo
                << std::fixed << std::setprecision(2)
                << " p(" << e.x << ','<< e.y << ") " 
                << "\tang=" /*<< ang <<"="*/  << angles[i]*rad_2_deg
                << "\tstart_ang=" << scan.Angle_Start*rad_2_deg << "("<<scan.Angle_Start*rad_2_deg<<")"
                << "\tend_ang=" << scan.Angle_End*rad_2_deg << "(" << scan.Angle_End*rad_2_deg << ")"
                << "\tnum_points=" << scan.Data.size()
                << std::endl;
    }
}

  
} // namespace data

#endif // _CSCAN_SERIALIZATION_HXX
