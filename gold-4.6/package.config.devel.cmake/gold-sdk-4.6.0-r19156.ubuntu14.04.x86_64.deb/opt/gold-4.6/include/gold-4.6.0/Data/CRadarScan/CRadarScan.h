/**
 * \file CRadarScan.h
 * \brief Classes for modeling high level data produced from a Radar
 * \author Luca Gatti \<lucag@ce.unipr.it\>, Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _CRADARSCAN_H
#define _CRADARSCAN_H

#include <vector>

#include <boost/date_time/posix_time/posix_time_types.hpp>
#include <stdint.h>

#include <Data/gold_data_export.h>

#include <Libs/Time/TimeUtils.h>
#include <Data/Math/Points.h>
#include <Data/Math/TMatrices.h>
#include <Processing/Math/Transformation.h>

namespace data
{
  
/**
 * \brief Class for modeling a single echo
 *
 * An echo is derived from Point3d, and offers additional member variables
 * for modeling other physical quantities estimated from a radar sensor
 */
class GOLD_DATA_EXPORT CRadarScanEcho :
  public math::Point3d
{
public:
  CRadarScanEcho();

  const math::Point3d& operator=(const math::Point3d& point);

  boost::uint8_t  DeviceID;  ///< Identifier of the device that captured this data. Used for array of devices
  boost::uint16_t Echo;      ///< Index of this echo in the overall scan
  double speed_x;            ///< Speed along the X axle [m/s]
  double speed_y;            ///< Speed along the Y axle [m/s]
  double radial_speed;       ///< Speed along the object-sensor direction, positive towards the sensor [m/s]
  double radial_range;       ///< Distance along the object-sensor direction, positive towards the object [m]
  double angle;              ///< Angle between the X axle and the object-sensor segment [rad]
  double width;              ///< Width of the object reflection [m]
  double height;             ///< Height of the object reflection [m]
  boost::uint8_t ObjectClassification;          ///< Object classification provided by the radar sensor
  double level_log; ///< Reflection level [db]
  double level_db;  ///< Reflection level [db]
};


class GOLD_DATA_EXPORT CRadarScan
{
  public:
    CRadarScan(boost::uint16_t pulses=0, boost::uint8_t echoes=0);

    /** \brief Describes the sensor status when the data has been captured */
    // TODO use boost::bimap and move to the radar drivers
    struct SensorStatus
    {
      /** \brief Enumerates the possible sensor status values */
      enum {
        NOT_DEFINED = 0,  ///< The sensor status is undefined
        WORKS_CORRECTLY,  ///< The sensor was working correctly when the data was acquired
        ERRORS            ///< Errors have been detected by the sensor when the data was acquired
      };

      /**
       * \brief Converts a SensorStatus value into the corresponding string
       *
       * Allowed values are: "Not Defined", "Works Correctly", "Errors"
       */
      static void ToString(uint32_t i, std::string& str);

      /** \brief Returns the SensorStatus value corresponding to the string argument */
      static uint32_t FromString(const std::string& s);
    };
    
    /** \brief Describes the sensor mode when the data has been captured */
    struct SensorMode
    {
        /** \brief Enumerates the possible sensor mode values */
        enum {
          CAL_MODE = 0,   ///< Calibration mode
          PULS_MODE = 1,  ///< Pulse mode
          PLL_MODE = 6,   ///< Phase Locked Loop
          PULS_DOPPLER_MODE = 8, ///< Pulse doppler mode
          FSK3FM = 13,           ///< Frequency-Shift Keying mode
          NOT_VALID = 15  ///< Mode not valid
      };

      /**
       * \brief Converts a SensorMode value into the corresponding string
       *
       * Allowed values are: "CAL Mode", "Pulse Mode", "PLL Mode", "Pulse Doppler Mode", "FSK3FM Mode", "Not Valid", "Unknown"
       */
      static void ToString(uint32_t i, std::string& str);

      /** \brief Returns the SensorMode value corresponding to the string argument */
      static uint32_t FromString(const std::string& s);
    };
    
    struct SensorSubMode
    {
        /** \brief Enumerates the possible sensor submode values */
         enum {
           DOWNCHIRP = 0,       ///< down chirp signal
           UPCHIRP = 1,         ///< up chirp signal
           DOPPLER_LOW = 2,     ///< low pulse repetition frequency
           DOPPLER_HIGH = 3,    ///< high pulse repetition frequency
           STATIONARY_MODE = 4, ///< stationary mode
           MAX_RANGE_BIT0 = 5,  ///< 20 m range coverage
           MAX_RANGE_BIT1 = 7,  ///< 8 m range coverage
           NOT_VALID = 15 ///< SubMode not valid
         };

      /**
       * \brief Converts a SensorMode value into the corresponding string
       *
       * Allowed values are:
       *    "DOWNCHIRP", "UPCHIRP",
       *    "DOPPLER_LOW", "DOPPLER_HIGH",
       *    "STATIONARY_MODE", "MAX_RANGE_BIT0",
       *    "MAX_RANGE_BIT1", "NOT_VALID"
       */
      static void ToString(uint32_t i, std::string& str);


      /** \brief Returns the SensorMode value corresponding to the string argument */
      static uint32_t FromString(const std::string& s);
    };
    
    unsigned long Cycle_Count;///< Sequential counter for the scans

    vl::chrono::TimeType TimeStamp_Start; ///< Framework Time of the scan begin
    vl::chrono::TimeType TimeStamp_End;   ///< Framework Time of the scan end

    // Range covered by the sensor
    double Angle_Start; ///< Field of view: angle where the scan starts [rad]. The X axle is 0.0, the Y axle is PI/2
    double Angle_End;   ///< Field of view: angle where the scan ends [rad]. The X axle is 0.0, the Y axle is PI/2
    double Distance_Start; ///< Field of view: minimum distance allowing objects detection [m].
    double Distance_End; ///< Field of view: maximum distance allowing objects detection [m].

    unsigned int ValidDataCounter;  ///< counter for valid data
    boost::uint8_t Status;          ///< Sensor status \see SensorStatus
    boost::uint8_t SystemMode;      ///< Sensor behavior mode 1 \see SensorMode
    boost::uint8_t SubSystemMode;   ///< Sensor behavior mode 2 \see SensorSubMode

    typedef std::vector<CRadarScanEcho> RadarScanType;  ///< Short type of the echoes collection
    RadarScanType Data;  ///< The collection of all the detected echoes
};

  /** \brief Type for rotation and scaling matrix */
  typedef math::TMatrix<double, 3,3> TransformationType;

  /** \brief Affine matrix: for rotation and translations */
  typedef math::TMatrix<double, 3,4> TransformationType4;

  /** \brief Translate all the dst points (echoes) using offset */
  GOLD_DATA_EXPORT void Translate( CRadarScan& dst, const math::Point3d& offsets );

  /**
   * \brief Transform current scan \a scan in \a dst scan data applying @a T transformation
   * \see Transformation.h
   */
  GOLD_DATA_EXPORT void Transform( const CRadarScan& scan, CRadarScan& dst, const TransformationType4& t );

  /**
   * \brief Apply a regular 3x3 transformation to any point of Scan
   */
  GOLD_DATA_EXPORT void Apply( CRadarScan& dst, const math::TMatrix<double, 3,3>& t );

  /**
   * \brief Apply an affine 3x4 transformation to any point of Scan
   */
  GOLD_DATA_EXPORT void Apply( CRadarScan& dst, const math::TMatrix<double, 3,4> & T );
  
  /**
   * \brief Compares two echoes using the distance
   */
  bool Echo_EchoLess(const CRadarScanEcho& e1, const CRadarScanEcho& e2);
  
} // namespace data

#endif // _CRADARSCAN_H
