/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2009                  *
 *                                                                    *
 *       http://www.ARGO.ce.unipr.it    (PGX July 2005)               *
 *                                                                    *
 **********************************************************************/

/**
 * \file CImage.h
 * \brief Definition of the class CImage: base class for modeling images.
 *
 * CImage is a base class for a generic image type. Contains basic methods for:
 * - shared pointers
 * - image inspection
 * - buffer access
 * - new allocations and cloning
 * in a fashion independent from the image type.
 * Locking functions are also provided for managing images in multi-thread environments
 * \see cimage
 */

#ifndef _CIMAGE_H
#define _CIMAGE_H

#include <CImageConfig.h>

#include <Data/gold_data_export.h>

#include <Data/CImage/Definitions.h>
#include <Data/CImage/Geometry.h>
#include <Data/CImage/Buffer.h>

#include <boost/shared_ptr.hpp>
#include <boost/property_tree/ptree.hpp>

/** \brief Contains classes, functions and declarations for managing images */
namespace cimage
{
  
/** 
 * \brief Base class to describe an image.
 *
 * Used for creating structures (such as vectors, list) of etherogeneous images
 * and for interfaces that need to remain independent on the concrete image type
 * This interface describes the image independently on the internal representation
 * The buffer returned is a mere byte array of the right size
 * Simple operations are allowed such as inspecting the geometry, cloning, copying
 * Type information can also be recovered.
 */
  class GOLD_DATA_EXPORT CImage :
        protected Geometry
  {
    public:
      // types

      /** \brief RTTI alternative type referred to the concrete image */
      typedef unsigned int Type;

      /** \brief shared pointer to a CImage */
      typedef boost::shared_ptr<CImage> SharedPtrType;

      /** \brief shared pointer to a const CImage */
      typedef boost::shared_ptr<const CImage> SharedPtrConstType;

      // construction and copy

      /**
       * \brief virtual destructor
       *
       * \note: this is needed by rtti for workinging correctly
       **/
      virtual ~CImage();

      /**
       * \brief Deep copies the argument buffer into the buffer of the current object, properly resized
       * and update the geometry cache consequently
       *
       * Overwrite the current image properties with those of the argument
       * The concrete type of the two images must be the same
       * Otherwise an exception is thrown
       * \param image the image whose buffer will be linked from the current image
       */
      CImage& operator= ( const CImage& image );

      /**
       * \brief Deep copies the argument buffer into the buffer of the current object, properly resized
       *
       * If the two images have different areas, a new buffer for the current image will be
       * allocated. A deep copy of the buffer content will take place calling this method
       * The properties of the current image are preserved.
       * \param [in] image the image containing the buffer that will be copied in those of current image
       * \see operator=
       */
      void CopyBuffer ( const CImage& image );

      /**
       * \brief Swaps the buffer of the argument image with those of the current image
       *
       * The properties of both images are preserved.
       * \param [in] image the image containing the buffer that will swapped with those of current image
       *
       */
      void Swap ( CImage& image );


      // Inspection methods

      /** \brief returns the image width [pixels] */
      SizeType   W()      const { return m_width; }

      /** \brief returns the image height [pixels] */
      SizeType   H()      const { return m_height; }

      /** \brief returns the image Area [pixels] */
      AreaType   Area()   const { return m_area; }

      /** \brief returns the image Volume [pixels] */
      VolumeType Volume() const { return m_volume; }

      /**
       * \brief Returns the number of channels
       *
       * For a Monochrome image the number of channels is 1,
       * for an RGB image the number of channels is 3, and
       * For a Bayer image the number of channels is 3.
       * \return the number of channels
       */
      uint8_t   chs()  const { return m_chs; }
      
      /** 
       * \brief Returns a string array containing the channels names
       **/
      const char** ChNames() const { return m_channel_names; }

      /**
       * \brief Returns the number of bit for each channel
       *
       * Only images with the same number of bits for each channel are supported
       */
      uint8_t   bpc()  const { return m_bpc; }

      /**
       * \brief Returns the number of bytes for each channel
       *
       * Only images with the same number of bytes for each channel are supported
       */
      uint8_t   Bpc()  const { return m_Bpc; }

      /**
       * \brief Returns the number of bytes per pixel
       *
       * Only images with bytes per pixel multiple of one are supported
       */
      uint8_t   Bpp()  const { return m_Bpp; }

      /**
       * \brief Returns the number of bit per pixel
       *
       * Only images with bytes per pixel multiple of 8 are supported
       */
      uint8_t   bpp()  const { return m_bpp; }
      
      /** 
       * \brief Returns the image size in byte
       */
      BufferSizeType  Size() const { return m_pBuffer->Size(); } 

      /** 
       * \returns Returns a global unique identifier of the image
       */
      inline GUIDType GUID() const { return m_guid; }
      
      /**
       * \brief Returns the internal type information. \see Type
       */
      // TODO: move the implementation to CImage.cpp
      virtual const Type& TypeInfo() const = 0;

      /**
       * \brief Returns a clone of the current object,
       * the internal buffer is not cloned
       * \return a pointer to a new allocated image,
       * with the same type and buffer of the current object.
       */
      SharedPtrType Clone() const 
      { 
        return SharedPtrType ( VClone() ); 
      }

      /**
       * \brief Returns a shared pointer to the an empty image
       * of the same type of current image
       * \return a SharedPtrType to an empty image
       */
      SharedPtrType Empty() const { return  SharedPtrType( VEmpty() ); }

      /**
       * \brief Returns a shared pointer to the an image
       * of the same type, same size of current image
       * @return a SharedPtrType to an empty image
       */
      SharedPtrType New() const { return SharedPtrType( VNew(m_width, m_height) ); }

      /**
       * \brief Returns a shared pointer to the an image of the same type,
       * The size of the image is specified by the arguments
       * @return a SharedPtrType to an empty image
       */
      SharedPtrType New ( SizeType w, SizeType h ) const { return  SharedPtrType( VNew( w, h ) ); }

      /**
       * \brief Returns a void pointer to the current writable buffer
       * @return void pointer to the current writable buffer
       */
      void* Buffer() { return m_pBuffer->get(); }

      /**
       * \brief Returns a pointer to the current readable buffer
       * @return void pointer to the current writable buffer
       */
      const void* Buffer() const { return m_pBuffer->get(); }

      /**
       * \brief Update the Image GUID maintaining the current content
       */
      void Refresh() { __update_guid();}


      /** \brief Returns a counter of the number of copies occurred on the current image */
      unsigned long CopyCounter() const;
      // TODO add Allocation/deallocation counter
      
      /**
       * \brief Returns a modifiable reference to the property::tree containing the image metadata
       */
      boost::property_tree::ptree& MetaData() { return m_metadata; }
      
      /**
       * \brief Returns a read-only reference to the property::tree containing the image metadata
       */
      const boost::property_tree::ptree& MetaData() const { return m_metadata; }

    protected:
      
      /**
       * Default ctor: a cimage can only be instantiated from a derived class
       */
      CImage();      
      
      /**
       * \brief Swap the buffer with the argument
       */
      void __swap ( CImage& image );

      /**
       * \brief Deep copies the argument buffer
       */
      void __copy ( const CImage& image );
      
      /**
       * \brief Assigns the initial buffer to the image
       */
      void __set_buffer(impl::BufferType* buffer);

      /**
       * \brief Increments the internal GUID
       */
      void __update_guid();
      
    private:

      virtual CImage* VEmpty() const = 0;
      virtual CImage* VNew ( SizeType w, SizeType h ) const = 0;
      virtual CImage* VClone() const = 0;

      virtual impl::BufferType* VNewBuffer() const = 0;

      impl::BufferType* m_pBuffer; ///< pointer to the buffers
      
      GUIDType m_guid;   ///< image guid
      
      uint64_t     m_copy_counter;  ///< counter for copies
      
      boost::property_tree::ptree m_metadata; ///< ptree for the properties
  };

  /** \brief Type for the allocation function */
  typedef CImage* ( *AllocatorType ) ( SizeType, SizeType );

  /**
   * \brief Type for a self deleting pointer to a CImage (version using only the namespace)
   */
  typedef CImage::SharedPtrType SharedPtrType;

  /**
   * \brief Type for a self deleting pointer to a const CImage (version using only the namespace)
   */
  typedef CImage::SharedPtrConstType SharedPtrConstType;
    
  namespace impl
  {
    GOLD_DATA_EXPORT CImage::Type get_guid();
  }
}

#endif
