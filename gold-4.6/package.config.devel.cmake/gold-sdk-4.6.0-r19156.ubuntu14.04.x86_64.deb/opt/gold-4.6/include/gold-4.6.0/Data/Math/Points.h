/**
 * \file Data/Math/Points.h
 * \brief Data and functions for modeling points and vectors
 * \author Paolo Grisleri\<grisleri@ce.unipr.it\>, Paolo Medici (medici@ce.unipr.it)
 */

#ifndef _POINTS_H
#define _POINTS_H

#include <cmath>
#include <iosfwd> 

/** \brief Mathematical and geometric data and functions */
namespace math
{

/**
 * \brief Class for modeling generic 2-D points or vectors
 * 
 * The main operators, as well as constructors from different types are supported
 * \tparam T type used for representing the coordinates
 * \see Point2f, Point2d, and Point2i for a shorter identifier
 */
template<class T>
struct Point2
{

	/** \brief Local type alias for the template argument: represents the coordinates type */
	typedef T ObjectType;

	/** \brief Class wise constant containing the number of dimensions */
	static const int Dimension = 2;


	T x; ///< Coordinate of the point or vector
	T y; ///< Coordinate of the point or vector

	/** \brief Default constructor: member variables are initialized with T() */
	inline Point2() :
			x(T()), y(T())
	{
	}

	/** \brief Constructor accepting the two coordinates*/
	inline Point2(T _x, T _y) :
			x(_x), y(_y)
	{
	}

	/**
	 * \brief Constructor accepting a struct with the x, y member variables
	 * \tparam P the type of the class to be copied in the current point
	 * \param _p the point to be copied in the current point
	 */
	template<class P>
	explicit Point2(const P&  _p) :
			x(_p.x), y(_p.y)
	{
	}

	/**
	 * \brief Constructor accepting a point of a specified type
	 * \tparam P the type of the point to be copied in the current point
	 * \param _p the point to be copied in the current point
	 */
	template<class P>
	inline Point2(const Point2<P>& _p) :
			x(_p.x), y(_p.y)
	{
	}

	/**
	 * \brief Returns the square of the length of the current vector.
	 *
	 * Or alternatively the square distance of the current point from the origin
	 */
	inline T length2() const
	{
		return x * x + y * y;
	}

	/**
	 * \brief Returns the the length of the current vector.
	 *
	 * Or alternatively the square distance of the current point from the origin
	 */
	inline T length() const
	{
		return std::sqrt(length2());
	}

	/**
	 * \brief Normalize the vector length
	 *
	 * After this call the vector length is unary while direction and verse are maintained.
	 */
	inline void normalize()
	{
		double f = 1.0 / length();
		x *= f;
		y *= f;
	}

	/**
	 * \brief Add the vector passed as argument to the current vector
	 *
	 * \tparam R type of the point passed as parameter
	 * \param p point to be added to the current vector
	 */
	template<class R>
	inline void operator +=(const Point2<R>& p)
	{
		x += p.x;
		y += p.y;
	}

	/**
	 * \brief Subtract the vector passed as argument from current vector
	 *
	 * \tparam R type of the point passed as parameter
	 * \param p point to be subtracted from the current vector
	 */
	template<class R>
	inline void operator -=(const Point2<R>& p)
	{
		x -= p.x;
		y -= p.y;
	}

	/**
	 * \brief Divide the current object by the value passed as argument
	 *
	 * \tparam R type of the value passed as parameter
	 * \param p value to be used as divisor for the current vector
	 */
	template<class R>
	inline void operator /=(const R& p)
	{
		x /= p;
		y /= p;
	}

	/**
	 * \brief Divide the current object by the value passed as argument and return the result
	 *
	 * \tparam R type of the value passed as parameter
	 * \param p value to be used as divisor for the current vector
	 * \return the current object \f$ x = x/ p \f$
	 */
	template<class R>
	inline Point2<T> operator /(const R& p)
	{
		x /= p;
		y /= p;
		return *this;
	}


	/**
	 * \brief Multiply the current object by the value passed as argument
	 *
	 * \tparam R type of the value passed as parameter
	 * \param p value to be used as factor for the current vector
	 */
	template<class R>
	inline void operator *=(const R& p)
	{
		x *= p;
		y *= p;
	}

	/**
	 * \brief Assignment operator: set the current object coordinates to those of the argument
	 *
	 * \tparam X type of the value passed as parameter
	 * \param p value to be assigned to the current vector
	 * \return the object passed as argument
	 */
	template<class X>
	inline const X&  operator =(const X&  p)
	{
		x = T(p.x), y = T(p.y);
		return p;
	}

	/** \brief Unary minus operator: changes the sign of each coordinate */
	Point2<T> operator -() const
	{
		return Point2<T>(-x, -y);
	}

	/** \brief Serialization function used for boost serialization */
	template<typename Archive>
	void serialize(Archive& ar, const unsigned int version)
	{
		ar & x;
		ar & y;
	}
};

/** \brief Alias for declaring a 2-D point or of integers */
typedef Point2<int> Point2i;

/** \brief Alias for declaring a 2-D point or of float */
typedef Point2<float> Point2f;

/** \brief Alias for declaring a 2-D point or of double */
typedef Point2<double> Point2d;

// comparison operators

/** \brief Returns true when the two arguments are equal, false otherwise */
template<class T>
inline bool operator ==(const Point2<T>& a, const Point2<T>& b)
{
	return (a.x == b.x) && (a.y == b.y);
}

/** \brief Returns true when the two arguments are different, false otherwise */
template<class T>
inline bool operator !=(const Point2<T>& a, const Point2<T>& b)
{
	return (a.x != b.x) || (a.y != b.y);
}

/** \brief Returns a Point2<T> containing the sum between the two Point2<T> passed as arguments */
template<class T>
inline Point2<T> operator +(const Point2<T>& a, const Point2<T>& b)
{
	return Point2<T>(a.x + b.x, a.y + b.y);
}

/** \brief Returns a Point2<T> containing the difference between the two Point2<T> passed as arguments */
template<class T>
inline Point2<T> operator -(const Point2<T>& a, const Point2<T>& b)
{
	return Point2<T>(a.x - b.x, a.y - b.y);
}

/** \brief Returns a T containing the scalar product between the two Point2<T> passed as arguments */
template<class T>
inline T operator *(const Point2<T>& a, const Point2<T>& b)
{
	return a.x * b.x + a.y * b.y;
}

/** \brief Returns a Point2<T> containing the product between the Point2<T> and the scalar passed as arguments */
template<class T>
inline Point2<T> operator *(const Point2<T>& a, T b)
{
	return Point2<T>(a.x * b, a.y * b);
}

/** \brief Returns a Point2<T> containing the quotient between the Point2<T> and the scalar passed as arguments */
template<class T>
inline Point2<T> operator /(const Point2<T>& a, T b)
{
	return Point2<T>(a.x / b, a.y / b);
}

/** \brief Returns a Point2<T> containing the vector product the Point2<T> and the scalar passed as arguments */
template<class T>
inline T operator ^(const Point2<T>& a, const Point2<T>&  b)
{
	return a.x * b.y - a.y * b.x;
}

/** \brief Returns the square distance between the two Point2<T> passed as arguments */
template<class T>
T PointDistance2(const Point2<T>& primo, const Point2<T>& secondo)
{
	return ((primo.x - secondo.x) * (primo.x - secondo.x)
			+ (primo.y - secondo.y) * (primo.y - secondo.y));
}

/** \brief Operator for printing the coordinates of the Point2<T> on a stream */
template<class T>
inline std::ostream& operator<<(std::ostream&  o, const Point2<T>&  p)
{
	o << p.x << ',' << p.y;
	return o;
}

/** \brief Operator for reading the coordinates of the Point2<T> from a stream */
template<class T>
inline std::istream& operator>>(std::istream&  i, Point2<T>&  p)
{
	char sep;
	i >> p.x >> sep >> p.y;
	return i;
}


/**
 * \brief Class for modeling generic 3-D points or vectors
 *
 * The main operators, as well as constructors from different types are supported
 * \tparam T type used for representing the coordinates
 * \see Point3f, Point3d, and Point3i for a shorter identifier
 */
template<class T>
struct Point3
{
	/** \brief Local type alias for the template argument: represents the coordinates type */
	typedef T ObjectType;

	/** \brief Class wise constant containing the number of dimensions */
	static const int Dimension = 2;

	T x; ///< Coordinate of the point or vector
	T y; ///< Coordinate of the point or vector
	T z; ///< Coordinate of the point or vector

	/** \brief Default constructor: member variables are initialized with T() */
	inline Point3() :
			x(T()), y(T()), z(T())
	{
	}

	/** \brief Constructor accepting the three coordinates*/
	inline Point3(T _x, T _y, T _z) :
			x(_x), y(_y), z(_z)
	{
	}

	/**
	 * \brief Constructor accepting a struct with the x, y, and z member variables
	 * \tparam P the type of the class to be copied in the current point
	 * \param _p the point to be copied in the current point
	 */
	template<class P>
	explicit Point3(const P&  _p) :
			x(_p.x), y(_p.y), z(_p.z)
	{
	}

	/**
	 * \brief Constructor accepting a point of a specified type
	 * \tparam P the type of the point to be copied in the current point
	 * \param _p the point to be copied in the current point
	 */
	template<class P>
	Point3(const Point3<P>&  _p) :
			x(_p.x), y(_p.y), z(_p.z)
	{
	}

	/**
	 * \brief Returns the square of the length of the current vector.
	 *
	 * Or alternatively the square distance of the current point from the origin
	 */
	inline T length2() const
	{
		return x * x + y * y + z * z;
	}

	/**
	 * \brief Returns the the length of the current vector.
	 *
	 * Or alternatively the square distance of the current point from the origin
	 */
	inline double length() const
	{
		return std::sqrt(x * x + y * y + z * z);
	}

	/**
	 * \brief Normalize the vector length
	 *
	 * After this call the vector length is unary while direction and verse are maintained.
	 */
	inline void normalize()
	{
		double f = 1.0 / length();
		x *= f;
		y *= f;
		z *= f;
	}

	/**
	 * \brief Add the vector passed as argument to the current vector
	 *
	 * \tparam R type of the point passed as parameter
	 * \param p point to be added to the current vector
	 */
	template<class R>
	inline void operator +=(const Point3<R>&  p)
	{
		x += p.x;
		y += p.y;
		z += p.z;
	}

	/**
	 * \brief Subtract the vector passed as argument from the current vector
	 *
	 * \tparam R type of the point passed as parameter
	 * \param p point to be subtracted to the current vector
	 */
	template<class R>
	inline void operator -=(const Point3<R>&  p)
	{
		x -= p.x;
		y -= p.y;
		z -= p.z;
	}


	/**
	 * \brief Divide the current object by the value passed as argument
	 *
	 * \tparam R type of the value passed as parameter
	 * \param p value to be used as divisor for the current vector
	 */
	template<class R>
	inline void operator /=(const R&  p)
	{
		x /= p;
		y /= p;
		z /= p;
	}


	/**
	 * \brief Multiply the current object by the value passed as argument
	 *
	 * \tparam R type of the value passed as parameter
	 * \param p value to be used as factor for the current vector
	 */
	template<class R>
	inline void operator *=(const R&  p)
	{
		x *= p;
		y *= p;
		z *= p;
	}

	/**
	 * \brief Assignment operator: set the current object coordinates to those of the argument
	 *
	 * \tparam X type of the value passed as parameter
	 * \param p value to be assigned to the current vector
	 * \return the object passed as argument
	 */
	template<class X>
	inline const X&  operator =(const X&  p)
	{
		x = T(p.x), y = T(p.y), z = T(p.z);
		return p;
	}

	/** \brief Unary minus operator: changes the sign of each coordinate */
	Point3<T> operator -() const
	{
		return Point3<T>(-x, -y, -z);
	}

	/** \brief Serialization function used for boost serialization */
	template<typename Archive>
	void serialize(Archive& ar, const unsigned int version)
	{
		ar&  x;
		ar&  y;
		ar&  z;
	}
};


/** \brief Alias for declaring a 3-D point or of integers */
typedef Point3<int> Point3i;

/** \brief Alias for declaring a 3-D point or of float */
typedef Point3<float> Point3f;

/** \brief Alias for declaring a 3-D point or of double */
typedef Point3<double> Point3d;


// comparison operators

/** \brief Returns true when the two arguments are equal, false otherwise */
template<class T>
inline bool operator ==(const Point3<T>& a, const Point3<T>& b)
{
	return (a.x == b.x) && (a.y == b.y) && (a.z == b.z);;
}

/** \brief Returns true when the two arguments are different, false otherwise */
template<class T>
inline bool operator !=(const Point3<T>& a, const Point3<T>& b)
{
	return (a.x != b.x) || (a.y != b.y) || (a.z != b.z);
}

/** \brief Returns a Point3<T> containing the sum between the two Point3<T> passed as arguments */
template<class T>
inline Point3<T> operator +(const Point3<T>& a, const Point3<T>& b)
{
	return Point3<T>(a.x + b.x, a.y + b.y, a.z + b.z);
}

/** \brief Returns a Point3<T> containing the difference between the two Point3<T> passed as arguments */
template<class T>
inline Point3<T> operator -(const Point3<T>& a, const Point3<T>& b)
{
	return Point3<T>(a.x - b.x, a.y - b.y, a.z - b.z);
}

/** \brief Returns a T containing the scalar product between the two Point3<T> passed as arguments */
template<class T>
inline T operator *(const Point3<T>& a, const Point3<T>& b)
{
	return a.x * b.x + a.y * b.y + a.z * b.z;
}

/** \brief Returns a Point3<T> containing the product between the Point3<T> and the value passed as arguments */
template<class T>
inline Point3<T> operator *(const Point3<T>& a, T b)
{
	return Point3<T>(a.x * b, a.y * b, a.z * b);
}

/** \brief Returns a Point3<T> containing the scalar product between the Point3<T> and the value passed as arguments */
template<class T>
inline Point3<T> operator /(const Point3<T>& a, T b)
{
	return Point3<T>(a.x / b, a.y / b, a.z / b);
}

/** \brief Returns a Point3<T> containing the vector product between the two Point3<T> passed as arguments */
template<class T>
inline Point3<T> operator ^(const Point3<T>& a, const Point3<T>&  b)
{
	return Point3<T>(a.y * b.z - a.z * b.y, -(a.x * b.z - a.z * b.x),
			a.x * b.y - a.y * b.x);
}

/**
 * \brief Returns square distance between two Point3<T>
 * \note This function is more efficient than PointDistance for comparing an high number of lengths
 *
 */
template<class T>
T PointDistance2(const Point3<T>& first, const Point3<T>& second)
{
	return (first.x - second.x) * (first.x - second.x)
			+ (first.y - second.y) * (first.y - second.y)
			+ (first.z - second.z) * (first.z - second.z);
}

/**
 * \brief Returns square distance between two Point3<T>
 * \note When comparing an high number the lengths it could be more efficient to use PointDistance2 instead
 * \see PointDistance2
 */
template<class T>
typename T::ObjectType PointDistance(const T&  a, const T&  b)
{
	return std::sqrt(PointDistance2(a, b));
}

/** \brief Operator for printing the coordinates of the Point2<T> on a stream */
template<class T>
inline std::ostream& operator<<(std::ostream&  o, const Point3<T>&  p)
{
	o << p.x << ',' << p.y << ',' << p.z;
	return o;
}

} // namespace math

#endif
