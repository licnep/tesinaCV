/**
 * \file CImageRGB8.h
 * \brief Class for modeling a Red, Green, Blue, 3-channels, 8-bits unsigned integer per channel image
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 * \date 2012-04-06
 */

#ifndef _CIMAGE_RGB8_H
#define _CIMAGE_RGB8_H

#include <Data/CImage/Pixels/RGB8.h>
#include <Data/CImage/TImage.h>

namespace cimage
{
  /** \brief Type for declaring Red, Green, Blue, 3-channels, 16-bits unsigned integer per channel image */
  typedef TImage<RGB8> CImageRGB8;

  /** \brief Alias type for declaring Red, Green, Blue, 3-channels, 16-bits unsigned integer per channel image */
  typedef CImageRGB8  CImageRGB;
}

#endif

