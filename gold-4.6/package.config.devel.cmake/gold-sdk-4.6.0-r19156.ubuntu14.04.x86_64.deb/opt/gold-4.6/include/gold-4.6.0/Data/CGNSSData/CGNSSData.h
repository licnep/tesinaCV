/**
 * \file CGNSSData.h
 * \brief Classes for modeling GNSS waypoints and GNSS related information
 * \author Paolo Medici \<medici@ce.unipr.it\>, Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _CGNSSDATA_H
#define _CGNSSDATA_H

#include <bitset>
#include <vector>

#include <stdint.h>

#include <Libs/Time/TimeUtils.h>

#include <Data/gold_data_export.h>

#pragma pack(push)
#pragma pack(1)

namespace data
{

/**
 * \brief A GNSS waypoint containing Latitude, Longitude and Altitude (LLA)
 * \note operator == and iostream << >> are implemented
 **/
struct GOLD_DATA_EXPORT WayPoint
{

	double latitude;  ///< latitude [degrees]
	double longitude; ///< longitude [degrees]
	double altitude;  ///< height [m]

	/**
	 * \brief Constructor taking latitude, longitude and altitude
	 */
	WayPoint(double lat = 0.0, double lon = 0.0, double alt = 0.0);

	/**
	 * \brief Checks equality between two waypoints (including altitude)
	 * \param [in] wp waypoint to be compared to the current one
	 * \return true when wp has the same latitude, longitude and altitude
	 */
	bool operator ==(const WayPoint& wp) const;

	/**
	 * \brief Checks for the same position between two waypoints:
	 * this does NOT include altitude
	 * \param wp Waypoint to be compared to the current one
	 */
	bool HasTheSamePositionOf(const WayPoint& wp) const;
};

/**
 * \brief Data supplied from a generic GNSS device
 * Three kind of information are supplied:
 *  - a waypoint
 *  - the sensor status when the data has been captured
 *  - a bitset containing which data are valid
 *  - data captured from the gps sensor
 */
struct GOLD_DATA_EXPORT GNSS: public WayPoint
{
public:
	/** \brief Default constructor */
	GNSS();

	/**
	 * \brief Constructor taking the time origin and a time_stamp
	 *
	 * \param time_origin GOLD Time origin for the current session
	 * \param timestamp timestamp of the captured data
	 */
	GNSS(const boost::posix_time::ptime& time_origin,
		 const boost::posix_time::time_duration& timestamp);

	/**
	 * \brief Build the data from an NMEA string
	 *
	 * The fields specified by the NMEA string are substituted in the object
	 * \param nmea_str the nmea string
	 * \return true if the decoding succeeded
	 */
	bool FromNMEA(const std::string& nmea_str);

public:
	/** \brief Hardware status */
	typedef enum
	{
		STATUS_OFF = 0,        ///< The hardware is off
		STATUS_ERROR = -1,     ///< An error occurred
		STATUS_COLD_START = 1, ///< A cold start is being performed
		STATUS_WARM_START = 2, ///< A warm start is being performed
		STATUS_ONLINE = 3,     ///< The GNSS is online and working
		STATUS_OUTAGE = 4      ///< The sensor is online but no satellite is currently visible
	} StatusID;

	/** \brief Fix Quality */
	typedef enum
	{
		Invalid=0,   ///< Current fix is invalid
		GNSSFix=1,   ///< Using GNSS fix
		DGNSSFix=2,  ///< using Differential GNSS fix (e.g. base station or WAAS/EGNOS)
		DGNSSFix2=3, ///< unimplemented
		RTKFixed=4,  ///< RTK Fixed correction
		RTKFloat=5,  ///< RTK Floating correction
		DeadReckoning=6,      ///< Dead Recking mode
		Manual=7,             ///< manual correction
		Simulation=8          ///< simulation mode
	} FixQuality;

	/** \brief Capabilities supported by the GNSS sensor */
	typedef enum Capabilities
	{
		CAP_TIME,      ///< GNSS clock (time part)
		CAP_DATE,      ///< GNSS clock (date part)
		
		CAP_LATITUDE,  ///< Latitude
		CAP_LONGITUDE, ///< Longitude
		CAP_ALTITUDE,  ///< Altitude

		CAP_HEIGHT_ON_GEOID, ///< Height on geoid
		CAP_HEADING, ///< Hardware heading measurement
		CAP_SPEED,   ///< Hardware speed measurement

		CAP_FIX_QUALITY, ///< Support for reading the fix quality
		CAP_SAT_NUM,     ///< Can read the number of satellites currently visible
		CAP_SAT_INFO,    ///< Can get information on the currently visible satellites
		CAP_HDOP, ///< Can return information on the horizontal dilution of position
		CAP_VDOP, ///< Can return information on the vertical dilution of position
		CAP_PDOP,  /// Can return information on the Positional Dilution of Precision
		CAP_TIME_TO_LAST_FIX ///< Delta time from last differential correction
	} CapabilitiesID;

	/// constellation classes
	typedef enum {
	GPS,	///< Global Positioning System
	GLONASS,	///< GLObal NAvigation Satellite System
	GALILEO	///< Galileo Positioning System
	} ConstellationType;

	/**
	 * \brief Information returned by GNSS sensors on one of the visible satellites
	 */
	struct SatInfo
	{
		uint8_t prn;      ///< Satellite ID
		float elevation;  ///< Satellite elevation, from the ground plane [rad]
		float azimuth;    ///< Satellite azimuth, from the ground plane [rad]
		float SNR;        ///< Signal to noise ratio, signal strength
		bool used_in_fix; ///< true when the satellite is used for current fixing of position
		ConstellationType type; ///< satellite class 
	};	
public:
	
	StatusID status;   ///< GNSS status
	
	std::bitset<32> capabilities;  ///< list of the supported capabilities
         
         std::bitset<32> updated;		///< updated bitfield for last processed packet
	
         vl::chrono::AbsoluteTimeType time;  ///< Absolute GNSS Time (UTC), day, month, year
	
	FixQuality fix_quality; ///< Class of GNSS fix
	
	/** angle between the current motion direction and the direction towards the True north (geodetic north) [rad].
	    NORTH = 0 and positive in EAST direction.*/
	double heading;    
	
	double speed;      ///< GNSS measured speed [m/s]

	/**
	 * \brief Height of geoid above WGS84 ellipsoid
	 *  Geoidal separation (Diff. between WGS-84 earth ellipsoid and mean sea level.  -=geoid is below WGS-84 ellipsoid)
	 */
	double geoid_height;

	/// Number of Satellites in view (total, from all constallation)
	uint8_t num_sats;

	/// Time since last DGPS update
	double time_to_last_fix;

	std::vector<SatInfo> sat_info;    ///< information on the visible satellites

	float pdop; ///< Positional Dilution of Position
	float hdop; ///< Horizontal Dilution of Position
	float vdop; ///< Vertical Dilution of Position
};


/**
 * \brief This is the deprecated class name, use data::WayPoint instead
 */
GOLD_DATA_DEPRECATED typedef WayPoint CWayPoint;

/**
 * \brief This is the deprecated class name, use data::GNSS instead
 */
GOLD_DATA_DEPRECATED typedef GNSS CGNSSData;

} // namespace data

#pragma pack(pop)

#endif //_CGNSSDATA_H
