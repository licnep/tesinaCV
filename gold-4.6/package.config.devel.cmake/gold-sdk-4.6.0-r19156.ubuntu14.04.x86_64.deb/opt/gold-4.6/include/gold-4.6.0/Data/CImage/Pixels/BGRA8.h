/**
 * \file Pixels/BGRA8.h
 * \brief Definitions for modeling BGRA8 pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _BGRA8_H
#define _BGRA8_H

#include <stdint.h>
#include <Data/CImage/Pixels/TBGRA.h>
#include <Data/gold_data_export.h>

namespace cimage
{
  /** \brief Definition for BGRA8. \see TBGRA */
  typedef TBGRA<uint8_t> BGRA8;

  /** \deprecated This definition is deprecated, use BGRA8 instead*/
  GOLD_DATA_DEPRECATED typedef BGRA8 BGRA32;

  /** \deprecated This definition is deprecated, use BGRA8 instead*/
  GOLD_DATA_DEPRECATED typedef BGRA8 BGRA;
}

#endif
