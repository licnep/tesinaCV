/**
 * \file Data/Math/Circles.h
 * \brief Data and functions for modeling circles
 */
#ifndef _CIRCLES_H
#define _CIRCLES_H

namespace math
{
/**
 * \brief Generic structure for modeling a 2-D circle described by center and radius
 * \tparam T type used for center and radius variables
 */
// FIXME: the name is circle 3 even if is a 2D
template<class T>
struct Circle3
{
	T x0;  ///< x coordinates of the center
    T y0;  ///< y coordinates of the center
	T r;   ///< circle radius

	// TODO: add some methods
};

/** \brief short type for a circle of float */
typedef Circle3<float> Circle3f;

/** \brief short type for a circle of double */
typedef Circle3<double> Circle3d;

}

#endif
