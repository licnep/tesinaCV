/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/

/**
 * \file Mono8s.h
 * \brief Definitions for modeling 1 channel, 8-bit signed integer pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Paolo Zani (zani@ce.unipr.it)
 * \date 2006-10-08
 */

#ifndef _SIGNEDMONO8_H
#define _SIGNEDMONO8_H

#include <stdint.h>

namespace cimage
{
/**
 * \brief Definition for Mono8s pixels
 * This pixel support one luminance channel with a depth of 8-bit signed depth
 */
typedef int8_t Mono8s;
}

#endif
