/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2009                  *
 *                                                                    *
 *       http://www.ARGO.ce.unipr.it    (PGX July 2005)               *
 *                                                                    *
 **********************************************************************/

#ifndef _BUFFER_H
#define _BUFFER_H

#include <Data/CImage/Geometry.h>
#include <boost/pool/poolfwd.hpp>
#include <map>

namespace cimage
{

namespace impl
{

class MemoryPools
{
public:
  
    struct Descriptor
    {
      boost::pool<> *p;
      unsigned int alloc_counter;
      unsigned int free_counter;
    };
  
    Descriptor& operator[](BufferSizeType size);
    ~MemoryPools();
    
private:
    typedef std::map<unsigned int, MemoryPools::Descriptor> MapType;
    MapType m_descriptors;
};


class GOLD_DATA_EXPORT BufferType
{
public:
  
    BufferType ( BufferSizeType size );
    ~BufferType();
    uint8_t* get();
    
    operator uint8_t*() const;
    operator void*() const;
    
    BufferSizeType Size() const;

private:
 
    void* m_aligned_ptr;
    uint8_t* m_ptr;
    BufferSizeType m_size;
    BufferSizeType m_aligned_size;
    MemoryPools::Descriptor* m_descr; 
};
} // namespace impl
} // namespace cimage

#endif
