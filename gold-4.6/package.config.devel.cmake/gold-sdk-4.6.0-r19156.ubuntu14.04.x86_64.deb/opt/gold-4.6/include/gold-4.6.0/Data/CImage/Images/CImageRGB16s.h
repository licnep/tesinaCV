/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file CImageRGB16s.h
 * \brief Class for modeling a Red, Green, Blue, 3-channels, 16-bits signed integer per channel image
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Paolo Zani (zani@ce.unipr.it)
 * \date 2012-04-06
 */

#ifndef _CIMAGESIGNEDRGB48_H
#define _CIMAGESIGNEDRGB48_H

#include <Data/CImage/TImage.h>
#include <Data/CImage/Pixels/RGB16s.h>

namespace cimage
{
  /** \brief Type for declaring a Red, Green, Blue, 3-channels, 16-bits signed integer per channel image */
  typedef TImage<RGB16s> CImageRGB16s;
}

#endif

