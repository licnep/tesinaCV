/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2009                  *
 *                                                                    *
 *       http://www.ARGO.ce.unipr.it    (PGX July 2005)               *
 *                                                                    *
 **********************************************************************/

/**
 * \file Geometry.h
 * \brief Class modeling the geometry attributes of an image
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */


#ifndef _GEOMETRY_H
#define _GEOMETRY_H

#include <Data/gold_data_export.h>
#include <Data/CImage/Definitions.h>

namespace cimage
{
  /**
   * \brief Base class for CImage modeling the geometry attributes of an image
   *
   * This class models the image geometry, including dimensions such as width, height, and depth
   * and channels attributes such as number of channels, bit per pixel, byte per pixel and so on.
   * Parsing the geometry attributes is the better way for understanding the image type.
   */
  class GOLD_DATA_EXPORT Geometry
  {
    public:
	  /**
	   * \brief Default constructor. Set all values to 0
	   */
      Geometry() :
          m_width ( 0 ), m_height ( 0 ), m_depth ( 0 ),
          m_area ( 0 ), m_volume ( 0 ),
          m_chs(0), m_bpc(0), m_Bpc(0), m_bpp(0), m_Bpp(0),
          m_channel_names(0)
      {}

      /**
       * \brief Constructor accepting width and height
       *
       * Depth is set to 1, Area and Volume are set consequently.
       * \param [in] width the new image width
       * \param [in] height the new image height
       */
      Geometry ( cimage::SizeType width, cimage::SizeType height ) :
          m_width ( width ), m_height ( height ), m_depth ( 1 ),
          m_area ( m_width*m_height ), m_volume ( m_width*m_height*m_depth ),
          m_chs(0), m_bpc(0), m_Bpc(0), m_bpp(0), m_Bpp(0),
          m_channel_names(0)
      {}

      /** \brief Recalculate the area value */
      void UpdateArea() { m_area=m_width*m_height; }

      cimage::SizeType   m_width; ///< image width [pixels]
      cimage::SizeType   m_height;///< image height [pixels]
      cimage::SizeType   m_depth; ///< image depth [pixels]. Default=1
      cimage::AreaType   m_area;  ///< image area [pixels] (=m_width*m_height)
      cimage::VolumeType m_volume; ///< image volume [pixels] (=m_width*m_height*m_depth)
      
      uint8_t m_chs;   ///< number of channels
      uint8_t m_bpc;   ///< bit per channel
      uint8_t m_Bpc;   ///< byte per channel
      uint8_t m_bpp;   ///< bit per pixel
      uint8_t m_Bpp;   ///< byte per pixel

      /**
       * \brief pointer to an array of string containing the channel names
       */
      const char** m_channel_names;
  };
}
#endif
