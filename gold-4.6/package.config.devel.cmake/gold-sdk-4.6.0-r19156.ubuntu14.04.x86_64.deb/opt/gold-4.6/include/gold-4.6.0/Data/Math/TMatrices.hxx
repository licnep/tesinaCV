#include <Data/Math/TMatrices.h>

namespace math {

template<>
bool TMatrix<double,2,2>::invert(TMatrix<double,2,2> & d) const
{
double determinant = 1.0/(M[0]*M[3] - M[1]*M[2]);
double invdet = 1/determinant;
d[0] =  M[3] * invdet;
d[1] = -M[1] * invdet;
d[2] = -M[2] * invdet;
d[3] =  M[0] * invdet;
return true;
}


template<>
bool TMatrix<double,3,3>::invert(TMatrix<double,3,3> & result) const
{
const TMatrix<double,3,3> &A = *this;

//  std::cout << "A:\n" << A << std::endl;

double determinant =   A(0,0)*(A(1,1)*A(2,2)-A(2,1)*A(1,2))
                     - A(0,1)*(A(1,0)*A(2,2)-A(1,2)*A(2,0))
                     + A(0,2)*(A(1,0)*A(2,1)-A(1,1)*A(2,0));
double invdet = 1.0/determinant;

// the inverse of a matrix is the transposed cofactors matrix,
// divided by the matrix determinant
result[0] =  (A(1,1)*A(2,2)-A(2,1)*A(1,2))*invdet; // ok
result[1] = -(A(0,1)*A(2,2)-A(0,2)*A(2,1))*invdet;
result[2] =  (A(0,1)*A(1,2)-A(0,2)*A(1,1))*invdet;
result[3] = -(A(1,0)*A(2,2)-A(1,2)*A(2,0))*invdet; // ok
result[4] =  (A(0,0)*A(2,2)-A(0,2)*A(2,0))*invdet;
result[5] = -(A(0,0)*A(1,2)-A(1,0)*A(0,2))*invdet;
result[6] =  (A(1,0)*A(2,1)-A(2,0)*A(1,1))*invdet; // ok
result[7] = -(A(0,0)*A(2,1)-A(2,0)*A(0,1))*invdet;
result[8] =  (A(0,0)*A(1,1)-A(1,0)*A(0,1))*invdet;

return true;
}

} // namespace math
