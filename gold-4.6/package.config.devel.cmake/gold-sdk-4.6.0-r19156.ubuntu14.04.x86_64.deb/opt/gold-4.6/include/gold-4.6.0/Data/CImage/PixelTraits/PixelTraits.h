/**
 * \file PixelTraits.h
 * \brief Generic class for defining the pixel traits
 * \author Paolo Grisleri
 * \date 8/02/2007
 */
// TODO: change name to ImageTraits

#ifndef _PIXEL_TRAITS_H
#define _PIXEL_TRAITS_H

#include <limits>
#include <typeinfo>

#include <stdint.h>

#include <Data/CImage/Geometry.h>

namespace cimage
{
/*
 * \brief Generic class for defining the pixel traits
 *
 * \tparam T type of the pixel whose traits are represented from the class
 * \tparam dummy type for enabling the template if T is of a specified type
 *
 * \note:
 * Architecture Dependent (AD). On some architecture it might be more efficient use different types for
 * doing calculations. For example using int instead of unsigned char can be faster
 * on some x86 processors.
 * The size of a Fast* data may be higher than the original data
 * The size of the Least* data may be lower than the original data
 */
template<class T, class Enable = void>
struct PixelTraits
{

	typedef T PixelType;       ///< Type of the pixel
	typedef T ChannelType;     ///< Type of the channel data

	// typedef T exact;
	typedef PixelType FastType; ///< Fastest type that can be used instead of PixelType (AD)
	typedef PixelType LeastType; ///< Smallest type capable of representing PixelType (AD)
	typedef PixelType SignedType; ///< Signed type capable of representing PixelType
	// typedef T exactSigned;
	typedef PixelType FastSignedType; ///< Fastest Signed type for PixelType (AD)
	typedef PixelType LeastSignedType; ///< Smallest Signed type for PixelType (AD)

	typedef PixelType DifferenceType; ///< Type capable of representing the difference between two PixelType
	typedef PixelType CumulativeType; ///< Type capable of representing a sum of PixelType

	typedef ChannelType ChannelCumulativeType; ///< Type capable of representing a sum of ChannelType
	// TODO: add here other channel-related types

	typedef PixelType FloatingType; ///< Floating point type for representing PixelType

	// methods for inspecting the image format
	inline static bool IsPacked()
	{
		return true;
	}  ///< true when the format is packet (Es RGBRGBRGB)
	inline static bool IsPlanar()
	{
		return true;
	}  ///< true when the format is planar (Es RRR... GGG... BBB...)

	// methods for inspecting the image geometry
	// independents
	inline static uint8_t Channels()
	{
		return 1;
	} ///< Returns the number of channels

	/**
	 * \brief Returns the number of bits per channel
	 * \note: for some format this value is different for each channel.
	 * This cannot be modeled with this function. The function should accept a channel number instead.
	 */
	inline static uint8_t BitPerChannel()
	{
		return static_cast<uint8_t>(sizeof(ChannelType) * 8);
	}

	// dependents
	/**
	 * \brief  Returns the number of Bytes per channel
	 * \note: here an approximation to the ceil is needed
	 * BitPerChannel = 4 Byte Per Channel = 1;
	 */
	inline static uint8_t BytePerChannel()
	{
		return BitPerChannel() >> 3;
	}

	/**
	 * \brief Returns the number of bit per pixel
	 */
	inline static uint8_t BitPerPixel()
	{
		return Channels() * BitPerChannel();
	}

	/**
	 * \brief Returns the number of Bytes per pixel
	 */
	inline static uint8_t BytePerPixel()
	{
		return Channels() * BytePerChannel();
	}

	/**
	 * \brief Returns the size stored for each pixel. Used in some IO operations
	 */
	inline static uint8_t StoredSize()
	{
		return sizeof(PixelType);
	}

	// elements for computations

	// TODO: see stl char_traits for understanding what kind of operations are needed here

	/**
	 * \brief Returns a default value for PixelType. Usually zero filled.
	 *
	 * In general it is the default constructor but for some
	 * types a different value may be needed.
	 */
	inline static PixelType Zero()
	{
		return PixelType();
	}

	/**
	 * \brief Returns the maximum value for PixelType
	 */
	inline static PixelType Min()
	{
		return std::numeric_limits < PixelType > ::min();
	}

	/**
	 * \brief Returns the minimum value for PixelType
	 */
	inline static PixelType Max()
	{
		return std::numeric_limits < PixelType > ::max();
	}

	/**
	 * \brief Returns the default value for ChannelType
	 */
	inline static ChannelType Channel_Zero()
	{
		return ChannelType();
	}

	/**
	 * \brief Returns the minimum value for ChannelType
	 */
	inline static ChannelType Channel_Min()
	{
		return std::numeric_limits < ChannelType > ::min();
	}

	/**
	 * \brief Returns the maximum value for ChannelType
	 */
	inline static ChannelType Channel_Max()
	{
		return std::numeric_limits < ChannelType > ::max();
	}

	/**
	 * \brief Returns a pointer to the requested channel element of a pixel using a pointer to the pixel
	 *
	 * Returns the value for the R channel of a RGB pixel
	 * \note Experimental. DO NOT USE
	 * \param ppixel pointer to the pixel in the image buffer
	 * \param channel channel number
	 * \return pointer to the requested ChannelType of the pixel pointed by ppixel
	 */
	inline static ChannelType* GetChannel(PixelType *ppixel,
			unsigned int channel)
	{
		return reinterpret_cast<ChannelType*>(ppixel) + channel;
	}

	/**
	 * \brief Returns a pointer to the requested channel element of a pixel using a pointer to the pixel
	 *
	 * Returns the value for the R channel of a RGB pixel
	 * \note: Experimental. DO NOT USE
	 * \param ppixel pointer to the pixel in the image buffer
	 * \param w size of the pixel row [pixel]
	 * \param channel channel number
	 * \return pointer to the requested ChannelType of the pixel pointed by ppixel
	 */
	inline static const ChannelType* GetChannel(const PixelType *ppixel,
			SizeType w, unsigned int channel)
	{
		return reinterpret_cast<const ChannelType*>(ppixel) + channel;
	}

	/**
	 * \brief Move a pointer to a ChannelType to the channel element of the next pixel of the same row
	 * \note Experimental. DO NOT USE
	 * \param value pointer to the current ChannelType
	 * \return pointer to a ChannelType to the channel element of the next pixel of the same row
	 */
	inline static const ChannelType* Next(const ChannelType* value)
	{
		return value += sizeof(PixelType);
	}

	/**
	 * \brief Return a PixelType containing the bilinear interpolation between the pixel pointed by ppixel and its neighbors
	 * \param ppixel pointer to the pixel to be interpolated with its neighbors
	 * \param w row size
	 * \param dx horizontal size of the neighborhood
	 * \param dy row vertical size of the neighborhood
	 * \return PixelType containing the bilinear interpolation between the pixel pointed by ppixel and its neighbors
	 */
	template<class R>
	inline static PixelType BilinearInterpolate(const PixelType* ppixel,
			SizeType w, R dx, R dy)
	{
		return static_cast<PixelType>((ppixel[w] * (R(1) - dx)
				+ ppixel[w + 1] * dx) * dy
				+ (ppixel[0] * (R(1) - dx) + ppixel[1] * dx) * (R(1) - dy));
	}

	/**
	 * \brief Channel names for Monochrome images
	 */
	inline static const char** ChNames()
	{
		static const char*names[] =
		{ "Luminance" };
		return names;
	}

};
} // namespace cimage

#include <boost/integer.hpp>
#include <stdint.h>
#include <boost/utility/enable_if.hpp> 
#include <boost/type_traits/is_integral.hpp>
#include <boost/type_traits/is_unsigned.hpp>
#include <boost/mpl/if.hpp>

namespace cimage
{

/*
 * \brief Pixel traits specialization for monochrome images
 */
template<class T>
struct PixelTraits<T, typename boost::enable_if<boost::is_integral<T> >::type>
{
	typedef T PixelType;
	typedef PixelType ChannelType;
	typedef PixelType FastType;
	typedef PixelType LeastType;

	// for PixelType, LeastType and ChannelType the following typedef can be used as well
	// typedef boost::mpl::if_<boost::is_unsigned<PixelType> ,
	//                           typename boost::uint_t< sizeof(PixelType)<<3 >::fast,
	//                           typename boost::int_t< sizeof(PixelType)<<3 >::fast
	//                        >::type FastType

	typedef typename boost::mpl::if_<boost::is_unsigned<PixelType>,
			typename boost::int_t<2 * (sizeof(PixelType) << 3)>::fast, PixelType>::type SignedType;

	typedef SignedType FastSignedType;
	typedef SignedType LeastSignedType;

	typedef typename boost::int_t<2 * (sizeof(PixelType) << 3)>::fast DifferenceType;
	typedef typename boost::mpl::if_<boost::is_unsigned<PixelType>, uint32_t, // typename boost::uint_t< 2* (sizeof(PixelType)<<3) >::fast,
			int32_t  // typename boost::int_t< 2* (sizeof(PixelType)<<3) >::fast
	>::type CumulativeType;

	typedef CumulativeType ChannelCumulativeType;

	typedef float FloatingType;

	inline static uint8_t Channels()
	{
		return 1;
	}

	inline static uint8_t BitPerChannel()
	{
		return BytePerChannel() << 3;
	}
	inline static bool IsPacked()
	{
		return true;
	}
	inline static bool IsPlanar()
	{
		return true;
	}
	inline static uint8_t BytePerChannel()
	{
		return sizeof(PixelType);
	}
	inline static uint8_t BitPerPixel()
	{
		return BitPerChannel();
	}
	inline static uint8_t BytePerPixel()
	{
		return BytePerChannel();
	}
	;
	inline static uint8_t StoredSize()
	{
		return sizeof(PixelType);
	}

	inline static PixelType Zero()
	{
		return PixelType();
	}
	inline static PixelType Min()
	{
		return std::numeric_limits < PixelType > ::min();
	}
	inline static PixelType Max()
	{
		return std::numeric_limits < PixelType > ::max();
	}

	inline static ChannelType Channel_Zero()
	{
		return ChannelType();
	}
	inline static ChannelType Channel_Min()
	{
		return std::numeric_limits < ChannelType > ::min();
	}
	inline static ChannelType Channel_Max()
	{
		return std::numeric_limits < ChannelType > ::max();
	}

	inline static ChannelType* GetChannel(PixelType *pPixel, uint32_t Channel)
	{
		return reinterpret_cast<ChannelType*>(pPixel) + Channel;
	}

	inline static const ChannelType* GetChannel(const PixelType *pPixel,
			SizeType W, unsigned int Channel)
	{
		return reinterpret_cast<const ChannelType*>(pPixel) + Channel;
	}

	inline static const ChannelType* Next(const ChannelType* value)
	{
		return const_cast<ChannelType*>(value + sizeof(PixelType));
	}

	template<class R>
	inline static PixelType BilinearInterpolate(const PixelType *pPixel,
			SizeType W, R Dx, R Dy)
	{
		return static_cast<PixelType>((pPixel[W] * (R(1) - Dx)
				+ pPixel[W + 1] * Dx) * Dy
				+ (pPixel[0] * (R(1) - Dx) + pPixel[1] * Dx) * (R(1) - Dy));
	}
	inline static const char** ChNames()
	{
		static const char*names[] =
		{ "Luminance" };
		return names;
	}
};
}

#include <Data/CImage/Pixels/Mono8o127.h>

namespace cimage
{
/*
 * \brief Type traits specialization for 8 bit monochrome images, with offset 127
 */
template<>
struct PixelTraits<Mono8o127>
{
	typedef Mono8o127 PixelType;
	typedef PixelType ChannelType;

	typedef PixelType FastType;
	typedef PixelType LeastType;

	typedef int16_t SignedType;

	typedef SignedType FastSignedType;
	typedef SignedType LeastSignedType;

	typedef int16_t DifferenceType;
	typedef uint32_t ChannelCumulativeType;
	typedef uint32_t CumulativeType;

	typedef float FloatingType;

	inline static uint8_t Channels()
	{
		return 1;
	}
	inline static uint8_t BitPerChannel()
	{
		return BytePerChannel() << 3;
	}
	inline static bool IsPacked()
	{
		return true;
	}
	inline static bool IsPlanar()
	{
		return true;
	}
	inline static uint8_t BytePerChannel()
	{
		return sizeof(PixelType);
	}
	inline static uint8_t BitPerPixel()
	{
		return BitPerChannel();
	}
	inline static uint8_t BytePerPixel()
	{
		return BytePerChannel();
	}
	;
	inline static uint8_t StoredSize()
	{
		return sizeof(PixelType);
	}

	inline static Mono8o127 Zero()
	{
		return (Mono8o127) 127;
	}
	inline static Mono8o127 Min()
	{
		return (Mono8o127) std::numeric_limits < uint8_t > ::min();
	}
	inline static Mono8o127 Max()
	{
		return (Mono8o127) std::numeric_limits < uint8_t > ::max();
	}

	inline static ChannelType* GetChannel(PixelType *pPixel, uint32_t Channel)
	{
		return reinterpret_cast<ChannelType*>(pPixel) + Channel;
	}

	inline static const ChannelType* GetChannel(const PixelType *pPixel,
			SizeType W, unsigned int Channel)
	{
		return reinterpret_cast<const ChannelType*>(pPixel) + Channel;
	}

	inline static const ChannelType* Next(const ChannelType* value)
	{
		return const_cast<ChannelType*>(value + sizeof(PixelType));
	}

	template<class R>
	inline static PixelType BilinearInterpolate(const PixelType *pPixel,
			SizeType W, R Dx, R Dy)
	{
		return static_cast<PixelType>((pPixel[W] * (R(1) - Dx)
				+ pPixel[W + 1] * Dx) * Dy
				+ (pPixel[0] * (R(1) - Dx) + pPixel[1] * Dx) * (R(1) - Dy));
	}
	inline static const char** ChNames()
	{
		static const char*names[] =
		{ "Luminance" };
		return names;
	}
};
}

#include <Data/CImage/Pixels/TRGB.h>
#include <Data/CImage/Pixels/TRGBA.h>
#include <Data/CImage/Pixels/TBGRA.h>

#include <Data/CImage/Pixels/THSV.h>
#include <Data/CImage/Pixels/THSL.h>

#include <boost/type_traits/is_floating_point.hpp>

namespace cimage
{
template<typename S> struct Ch;

/*
 * \brief Channel names for RGB
 */
template<typename T> struct Ch<TRGB<T> >
{
	static inline const char** Names()
	{
		static const char*names[] =
		{ "R", "G", "B" };
		return names;
	}
};

/*
 * \brief Channel names for RGBA
 */
template<typename T> struct Ch<TRGBA<T> >
{
	static inline const char** Names()
	{
		static const char*names[] =
		{ "R", "G", "B", "A" };
		return names;
	}
};

/*
 * \brief Channel names for BGRA
 */
template<typename T> struct Ch<TBGRA<T> >
{
	static inline const char** Names()
	{
		static const char*names[] =
		{ "B", "G", "R", "A" };
		return names;
	}
};
template<typename T> struct Ch<THSV<T> >
{
	static inline const char** Names()
	{
		static const char*names[] =
		{ "H", "S", "V" };
		return names;
	}
};

/*
 * \brief Channel names for HSL
 */
template<typename T> struct Ch<THSL<T> >
{
	static inline const char** Names()
	{
		static const char*names[] =
		{ "H", "S", "L" };
		return names;
	}
};

/*
 * \brief Pixel traits specialization for integer RGB, RGBA, BGRA, HSV HSL
 */
template<template<typename > class S, typename T>
struct PixelTraits<S<T>, typename boost::enable_if<boost::is_integral<T> >::type>
{
	typedef S<T> PixelType;
	typedef T ChannelType;

	typedef PixelType FastType;
	typedef PixelType LeastType;

	typedef typename boost::mpl::if_<boost::is_unsigned<T>,
			S<typename boost::int_t<2 * (sizeof(T) << 3)>::fast>, PixelType>::type SignedType;

	typedef SignedType FastSignedType;
	typedef SignedType LeastSignedType;

	typedef S<typename boost::int_t<2 * (sizeof(T) << 3)>::fast> DifferenceType;

	typedef typename boost::mpl::if_<boost::is_unsigned<T>, uint32_t, // typename boost::uint_t< 4* (sizeof(T)<<3) >::fast ,
			int32_t   // typename boost::int_t< 4* (sizeof(T)<<3) >::fast
	>::type ChannelCumulativeType;

	typedef S<ChannelCumulativeType> CumulativeType;
	typedef S<float> FloatingType;

	inline static uint8_t Channels()
	{
		return sizeof(PixelType) / sizeof(ChannelType);
	}
	inline static uint8_t BitPerChannel()
	{
		return sizeof(ChannelType) << 3;
	}
	inline static bool IsPacked()
	{
		return true;
	}
	inline static bool IsPlanar()
	{
		return !IsPacked();
	}
	inline static uint8_t BytePerChannel()
	{
		return BitPerChannel() >> 3;
	}
	inline static uint8_t BitPerPixel()
	{
		return Channels() * BitPerChannel();
	}
	inline static uint8_t BytePerPixel()
	{
		return Channels() * BytePerChannel();
	}
	inline static uint8_t StoredSize()
	{
		return sizeof(PixelType);
	}

	inline static PixelType Zero()
	{
		return PixelType();
	}
	inline static PixelType Min()
	{
		return PixelType(std::numeric_limits < ChannelType > ::min());
	}
	inline static PixelType Max()
	{
		return PixelType(std::numeric_limits < ChannelType > ::max());
	}

	inline static ChannelType Channel_Zero()
	{
		return ChannelType();
	}
	inline static ChannelType Channel_Min()
	{
		return std::numeric_limits < ChannelType > ::min();
	}
	inline static ChannelType Channel_Max()
	{
		return std::numeric_limits < ChannelType > ::max();
	}

	inline static ChannelType* GetChannel(PixelType *pPixel, uint32_t Channel)
	{
		return reinterpret_cast<ChannelType*>(pPixel) + Channel;
	}
	inline static const ChannelType* GetChannel(const PixelType *pPixel,
			SizeType W, unsigned int Channel)
	{
		return reinterpret_cast<const ChannelType*>(pPixel) + Channel;
	}

	inline static const ChannelType* Next(const ChannelType* value)
	{
		return const_cast<ChannelType*>(value + sizeof(PixelType));
	}

	template<typename R> inline static PixelType BilinearInterpolate(
			const PixelType* pPixel, SizeType W, R Dx, R Dy)
	{
		return PixelType(
				((GetChannel(pPixel + W, 0) * (R(1) - Dx)
						+ GetChannel(pPixel + W + 1, 0) * Dx) * Dy
						+ (GetChannel(pPixel, 0) * (R(1) - Dx)
								+ GetChannel(pPixel + 1, 0) * Dx) * (R(1) - Dy)),
				((GetChannel(pPixel + W, 1) * (R(1) - Dx)
						+ GetChannel(pPixel + W + 1, 1) * Dx) * Dy
						+ (GetChannel(pPixel, 1) * (R(1) - Dx)
								+ GetChannel(pPixel + 1, 1) * Dx) * (R(1) - Dy))(
						(GetChannel(pPixel + W, 2) * (R(1) - Dx)
								+ GetChannel(pPixel + W + 1, 2) * Dx) * Dy
								+ (GetChannel(pPixel, 2) * (R(1) - Dx)
										+ GetChannel(pPixel + 1, 2) * Dx)
										* (R(1) - Dy)));
	}

	inline static const char** ChNames()
	{
		return Ch<PixelType>::Names();
	}
};

/*
 * \brief Pixel traits specialization for floating RGB, RGBA, BGRA, HSV HSL
 */
template<template<typename > class S, typename T>
struct PixelTraits<S<T>,
		typename boost::enable_if<boost::is_floating_point<T> >::type>
{
	typedef S<T> PixelType;
	typedef T ChannelType;

	typedef PixelType FastType;
	typedef PixelType LeastType;

	typedef PixelType SignedType;

	typedef SignedType FastSignedType;
	typedef SignedType LeastSignedType;

	typedef SignedType DifferenceType;

	typedef ChannelType ChannelCumulativeType;

	typedef S<ChannelCumulativeType> CumulativeType;
	typedef PixelType FloatingType;

	inline static uint8_t Channels()
	{
		return sizeof(PixelType) / sizeof(ChannelType);
	}
	inline static uint8_t BitPerChannel()
	{
		return sizeof(ChannelType) << 3;
	}
	inline static bool IsPacked()
	{
		return true;
	}
	inline static bool IsPlanar()
	{
		return !IsPacked();
	}
	inline static uint8_t BytePerChannel()
	{
		return BitPerChannel() >> 3;
	}
	inline static uint8_t BitPerPixel()
	{
		return Channels() * BitPerChannel();
	}
	inline static uint8_t BytePerPixel()
	{
		return Channels() * BytePerChannel();
	}
	inline static uint8_t StoredSize()
	{
		return sizeof(PixelType);
	}

	inline static PixelType Zero()
	{
		return PixelType();
	}
	inline static PixelType Min()
	{
		return PixelType(std::numeric_limits < ChannelType > ::min());
	}
	inline static PixelType Max()
	{
		return PixelType(std::numeric_limits < ChannelType > ::max());
	}

	inline static ChannelType Channel_Zero()
	{
		return ChannelType();
	}
	inline static ChannelType Channel_Min()
	{
		return std::numeric_limits < ChannelType > ::min();
	}
	inline static ChannelType Channel_Max()
	{
		return std::numeric_limits < ChannelType > ::max();
	}

	inline static ChannelType* GetChannel(PixelType *pPixel, uint32_t Channel)
	{
		return reinterpret_cast<ChannelType*>(pPixel) + Channel;
	}
	inline static const ChannelType* GetChannel(const PixelType *pPixel,
			SizeType W, unsigned int Channel)
	{
		return reinterpret_cast<const ChannelType*>(pPixel) + Channel;
	}

	inline static const ChannelType* Next(const ChannelType* value)
	{
		return const_cast<ChannelType*>(value + sizeof(PixelType));
	}

	template<typename R> inline static PixelType BilinearInterpolate(
			const PixelType* pPixel, SizeType W, R Dx, R Dy)
	{
		return PixelType(
				((GetChannel(pPixel + W, 0) * (R(1) - Dx)
						+ GetChannel(pPixel + W + 1, 0) * Dx) * Dy
						+ (GetChannel(pPixel, 0) * (R(1) - Dx)
								+ GetChannel(pPixel + 1, 0) * Dx) * (R(1) - Dy)),
				((GetChannel(pPixel + W, 1) * (R(1) - Dx)
						+ GetChannel(pPixel + W + 1, 1) * Dx) * Dy
						+ (GetChannel(pPixel, 1) * (R(1) - Dx)
								+ GetChannel(pPixel + 1, 1) * Dx) * (R(1) - Dy))(
						(GetChannel(pPixel + W, 2) * (R(1) - Dx)
								+ GetChannel(pPixel + W + 1, 2) * Dx) * Dy
								+ (GetChannel(pPixel, 2) * (R(1) - Dx)
										+ GetChannel(pPixel + 1, 2) * Dx)
										* (R(1) - Dy)));
	}

	inline static const char** ChNames()
	{
		return Ch<PixelType>::Names();
	}
};

}

#include <Data/CImage/Pixels/Bayer.h>

namespace cimage
{

/*
 * \brief Pixel traits specialization for Bayer images
 */
template<typename T>
struct PixelTraits<Bayer<T> >
{

	typedef Bayer<T> PixelType;
	typedef PixelType FastType;
	typedef PixelType LeastType;

	typedef PixelType SignedType;
	typedef PixelType FastSignedType;
	typedef PixelType LeastSignedType;

	typedef PixelType DifferenceType;
	typedef PixelType CumulativeType;
	typedef PixelType SignedCumulativeType;

	typedef uint8_t ChannelType;
	typedef uint16_t ChannelCumulativeType;

	typedef float FloatingType;

	inline static uint8_t Channels()
	{
		return 4;
	}
	inline static uint8_t BitPerChannel()
	{
		return 8;
	}
	inline static bool IsPacked()
	{
		return true;
	}
	inline static bool IsPlanar()
	{
		return !IsPacked();
	}
	inline static uint8_t BytePerChannel()
	{
		return BitPerChannel() >> 3;
	}
	inline static uint8_t BitPerPixel()
	{
		return Channels() * BitPerChannel();
	}
	inline static uint8_t BytePerPixel()
	{
		return Channels() * BytePerChannel();
	}
	;
	inline static uint8_t StoredSize()
	{
		return 1;
	}

	inline static PixelType Zero()
	{
		return PixelType();
	}
	inline static PixelType Min()
	{
		return PixelType(std::numeric_limits < PixelType > ::min());
	}
	inline static PixelType Max()
	{
		return PixelType(std::numeric_limits < PixelType > ::max());
	}

	inline static ChannelType Channel_Zero()
	{
		return ChannelType();
	}
	inline static ChannelType Channel_Min()
	{
		return std::numeric_limits < ChannelType > ::min();
	}
	inline static ChannelType Channel_Max()
	{
		return std::numeric_limits < ChannelType > ::max();
	}

	inline static ChannelType* GetChannel(PixelType *pPixel,
			unsigned int Channel)
	{
		return reinterpret_cast<ChannelType*>(pPixel) + Channel;
	}
	inline static const ChannelType* GetChannel(const PixelType *pPixel,
			SizeType W, unsigned int Channel)
	{
		return reinterpret_cast<const ChannelType*>(pPixel)
				+ (Channel / 2) * (W - 2) + Channel;
	}
	inline static const ChannelType* Next(const ChannelType* value)
	{
		return value += sizeof(PixelType);
	}
	template<class R>
	inline static PixelType BilinearInterpolate(const PixelType *pPixel,
			SizeType W, R Dx, R Dy);
	inline static const char** ChNames();
};

/**
 * \brief Channel names for BGGR bayer images
 */
template<> inline const char** PixelTraits<Bayer<BGGR> >::ChNames()
{
	static const char*names[] =
	{ "B", "G1", "G2", "R" };
	return names;
}

/**
 * \brief Channel names for GRBG bayer images
 */
template<> inline const char** PixelTraits<Bayer<GRBG> >::ChNames()
{
	static const char*names[] =
	{ "G1", "R", "B", "G2" };
	return names;
}

/**
 * \brief Channel names for RGGB bayer images
 */
template<> inline const char** PixelTraits<Bayer<RGGB> >::ChNames()
{
	static const char*names[] =
	{ "R", "G1", "G2", "B" };
	return names;
}

/**
 * \brief Channel names for GBRG bayer images
 */
template<> inline const char** PixelTraits<Bayer<GBRG> >::ChNames()
{
	static const char*names[] =
	{ "G1", "B", "R", "G2" };
	return names;
}
}
#endif

