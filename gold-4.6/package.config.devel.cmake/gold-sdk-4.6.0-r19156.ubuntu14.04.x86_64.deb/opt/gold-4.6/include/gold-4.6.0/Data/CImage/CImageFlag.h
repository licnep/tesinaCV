/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file CImage/CImageFlag.h
 * \brief Generic flags and flag sets for storing image properties
 * \author Paolo Grisleri\<grisleri@ce.unipr.it\>, Paolo Zani (zani@ce.unipr.it)
 * \date 2006-05-24
 */

#ifndef _CIMAGEFLAG_H
#define _CIMAGEFLAG_H

#include <iomanip>
#include <map>
#include <iosfwd>
#include <set>
#include <stdint.h>

#include <Data/gold_data_export.h>

namespace cimage
{

/**
 * \class CImageFlag
 * \brief CImage flag class
 * This class represents a flag suitable for defining optional behaviors in CImage operations
 */
class GOLD_DATA_EXPORT CImageFlag
{
public:

	/** \brief Default constructor */
    CImageFlag();

    /** \brief Copy constructor */
    CImageFlag(const CImageFlag& flag);
    
    /** \brief Constructor accepting a string */
    CImageFlag(const std::string& str);

    /** \brief Assignment operator */
    const CImageFlag& operator = (const CImageFlag& flag);

    /** \brief Returns true when the argument is identical to the current object, false otherwise */
    bool operator == (const CImageFlag& flag) const;

    /** \brief Returns true when the argument less than the current object */
    bool operator < (const CImageFlag& flag) const;

    /** \brief return the internal value of the current flag */
    uint64_t value() const;

    /** \brief operator for writing the content of the argument on a stream */
    friend std::ostream& operator << (std::ostream& os, const CImageFlag& flag);

private:

    static  uint64_t  m_max_value;
    uint64_t m_value;
};

/**
 * \class CImageFlagSet
 * \brief CImage flag set class
 * This class represents a set of CImageFlag
 * \see CImageFlag
 */
class GOLD_DATA_EXPORT CImageFlagSet
{

public:

	/** \brief Default constructor */
	CImageFlagSet();

	/** \brief Constructor accepting a string */
    CImageFlagSet(const std::string& str);

    /** \brief Constructor accepting a cimage flag */
    CImageFlagSet(const CImageFlag& flag);
    
    /** \brief Add the flag passed as argument to the current set */
    CImageFlagSet& set (const CImageFlag& flag);

    /** \brief Remove the flag passed as argument from the current set */
    CImageFlagSet& reset (const CImageFlag& flag);
    
    /** \brief Check if the set passed as argument belong to the curren set */
    bool test(const CImageFlag& flag) const;

    /** \brief operator for writing the content of the argument on a stream */
    friend GOLD_DATA_EXPORT std::ostream& operator << (std::ostream& os, const CImageFlagSet& cfs);
    
private:

    std::set<CImageFlag> m_flags;
};

} // namespace cimage


// #ifdef CIMAGE_FLAG_LOCAL
// # define CIMAGE__DECLARE_FLAG(F)  namespace cimage { extern GOLD_DATA_EXPORT const CImageFlag F ; }
// #else
// # define CIMAGE__DECLARE_FLAG(F)  namespace cimage { extern DECLSPEC_IMPORT const CImageFlag F ; }
// #endif

/**
 * \brief Macro for declaring a new CImageFlag. To be used in the header files
 */
#define CIMAGE__DECLARE_FLAG(F)  extern const cimage::CImageFlag F;

/**
 * \brief Macro for registering a declared CImageFlag. To be used in implementation files
 */
#define CIMAGE__REGISTER_FLAG(F) const CImageFlag F;

#endif
