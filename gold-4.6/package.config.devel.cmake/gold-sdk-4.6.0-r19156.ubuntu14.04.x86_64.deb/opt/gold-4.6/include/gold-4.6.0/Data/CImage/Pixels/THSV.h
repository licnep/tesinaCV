/**
 * \file THSV.h
 * \brief Definitions for modeling Hue, Saturation, Value (HSV), 3 channel, generic pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Pietro Versari \<versari@ce.unipr.it\>
 */

#ifndef _THSV_H
#define _THSV_H

#include <boost/operators.hpp>

#include <Data/gold_data_export.h>

// NOTE: this patch is needed for compiling on both MSVC and gcc-4.7
// MSVC requires exported template symbol without specifiers
// gcc-4.7 requires exported template symbol with specifiers
#ifndef GOLD_DATA_TEMPLATE_EXPORT
#if defined (_MSC_VER)
        #define GOLD_DATA_TEMPLATE_EXPORT
#else
        #define GOLD_DATA_TEMPLATE_EXPORT GOLD_DATA_EXPORT
#endif
#endif // GOLD_DATA_TEMPLATE_EXPORT


namespace cimage
{

  /**
   * \brief Class for modeling Hue, Saturation, Value (HSV), 3 channel, generic pixels
   * \tparam R type to be used as channel type for H, S and V values
   */
  template <class R>
  class GOLD_DATA_TEMPLATE_EXPORT THSV:
          boost::addable< THSV<R> ,
          boost::subtractable<THSV<R>,
          boost::multipliable<THSV<R>,
          boost::dividable<THSV<R>,
          boost::orable<THSV<R>,
          boost::andable<THSV<R>,
          boost::xorable<THSV<R>,
          boost::less_than_comparable <THSV<R>,
          boost::equality_comparable<THSV<R>
            > > > > > > > > >
  {
    public:

	  /** \brief Enumerator for channel type */
      typedef enum Channels {HUE=0, SATURATION=1, value=2} Channel;

      /** \brief Default constructor */
      THSV() {}

   	  /** \brief Constructor accepting a generic type that can be converted in R */
      template<class T>
      inline explicit THSV(const T v) :
        H(static_cast<R>(v)),
        S(static_cast<R>(v)),
        V(static_cast<R>(v)){}

      /** \brief Copy constructor from an HSV<T> with T convertible to R */
      template<class T>
      inline explicit THSV(const THSV<T>& v) :
        H(static_cast<R>(v.H)),
        S(static_cast<R>(v.S)),
        V(static_cast<R>(v.V)){}

      /** \brief Constructor accepting 3 separated H,S,V values of a convertible type */
      template<class T>
      inline explicit  THSV(const T h, const T s, const T v) :
        H(static_cast<R>(h)),
        S(static_cast<R>(s)),
        V(static_cast<R>(v)){}

      /** \brief Returns true when the current pixel has each H, S, and V value less than the corresponding value of the argument */
      bool operator < (const THSV& a) const
      {
        return H<a.H  && S<a.S  && V<a.V;
      }

      /** \brief Returns true when the current pixel has each H, S, and V value strictly equal to the corresponding value of the argument */
       bool operator == (const THSV& a) const
      {
        return H==a.H  && S==a.S  && V==a.V;
      }

       /** \brief Set the current pixel value to the BITWISE AND between the current value and the argument */
      inline THSV& operator &=(const THSV& value)
      {
        H&=value.H, S&=value.S, V&=value.V;
        return *this;
      }

      /** \brief Set the current pixel value to the BITWISE OR between the current value and the argument */
      inline THSV& operator |=(const THSV& value)
      {
        H|=value.H, S|=value.S, V|=value.V;
        return *this;
      }

      /** \brief Set the current pixel value to the BITWISE XOR between the current value and the argument */
      inline THSV& operator ^=(const THSV& value)
      {
        H^=value.H, S^=value.S, V^=value.V;
        return *this;
      }

      /** \brief Set the current pixel value to the SUM between the current value and the argument */
      template<class T>
      inline THSV& operator +=(const THSV<T>& value)
      {
        H+=value.H, S+=value.S, V+=value.V;
        return *this;
      }

      /** \brief Set the current pixel value to the DIFFERENCE between the current value and the argument */
      template<class T>
      inline THSV& operator -=(const THSV<T>& value)
      {
        H-=value.H, S-=value.S, V-=value.V;
        return *this;
      }

      /** \brief Set the current pixel value to the PRODUCT between the current value and the argument */
      template<class T>
      inline THSV& operator *=(const THSV<T>& value)
      {
        H*=value.H, S*=value.S, V*=value.V;
        return *this;
      }

      /** \brief Set the current pixel value to the QUOTIENT between the current value and the argument */
      template<class T>
      inline THSV& operator /=(const THSV<T>& value)
      {
        H/=value.H, S/=value.S, V/=value.V;
        return *this;
      }

      /** \brief Set the current pixel value to the SUM between the current value and the argument */
      template<class T>
            inline THSV& operator +=(const T factor)
            {
              H=static_cast<R>(factor+H),
              S=static_cast<R>(factor+S),
              V=static_cast<R>(factor+V);
              return *this;
            }

      /** \brief Set the current pixel value to the DIFFERENCE between the current value and the argument */

      template<class T>
      inline THSV &operator -= ( const T factor )
      {
        H=static_cast<R> ( H-factor ),
        S=static_cast<R> ( S-factor ),
        V=static_cast<R> ( V-factor );
        return *this;
      }

      /** \brief Set the current pixel value to the PRODUCT between the current value and the argument */
      template<class T>
      inline THSV& operator *=(const T factor)
      {
        H=static_cast<R>(factor*H),
        S=static_cast<R>(factor*S),
        V=static_cast<R>(factor*V);
        return *this;
      }

      /** \brief Set the current pixel value to the QUOTIENT between the current value and the argument */
      template<class T>
      inline THSV &operator /= ( const T factor )
      {
        H=static_cast<R> ( H/factor ),
        S=static_cast<R> ( S/factor ),
        V=static_cast<R> ( V/factor );
        return *this;
      }

      /** \brief Returns a THSV obtained from the SUM between a two THSV arguments */
      template<class T> inline friend THSV operator +(const T factor, const THSV& value) { return THSV(value)+=factor; }

      /** \brief Returns a THSV obtained from the DIFFERENCE between a two THSV arguments */
      template<class T > inline friend THSV operator -(const T factor, const THSV& value) { return THSV(value)-=factor; }

      /** \brief Returns a THSV obtained from the PRODUCT between a two THSV arguments */
      template<class T > inline friend THSV operator *(const T factor, const THSV& value) { return THSV(value)*=factor; }

      /** \brief Returns a THSV obtained from the QUOTIENT between a two THSV arguments */
      template<class T> inline friend THSV operator /(const T factor, const THSV& value) { return THSV(value)/=factor; }

      /**
       * \brief Returns the value of the channel with index selected from the argument
       * \param i channel number
       * \return the value for the i-th channel
       */
      R operator [](unsigned int i) const { return *(&H+i); }

      /** \brief Prints the pixel values on a stream */
      friend inline std::ostream& operator << (std::ostream& os, const THSV& value) { /*TODO...*/ return os; }

      R H;  ///< The Hue channel
      R S;  ///< The Saturation channel
      R V;  ///< The Value channel
  };

}

#endif

