/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * \file Data/Math/Planes.h
 * \brief Data and functions for modeling planes
 * \author Paolo Grisleri\<grisleri@ce.unipr.it\>, Paolo Zani (zani@vislab.it)
 * \date 2012-04-05
 */

#ifndef _PLANE_H
#define _PLANE_H

#include <Data/Math/Points.h>

#include <limits>
#include <iosfwd>
#include <stdexcept>




namespace math
{
  
    template<typename T>
    class Plane3;
    
    template<class T>
    inline std::ostream& operator<<(std::ostream& o, const math::Plane3<T>& p);
  
    /**
    * \brief 3-D plane expressed by the equation: \f$ ax + by + cz + d = 0 \f$
    *
    * \tparam T type used for the internal representation of the coefficients
    */
    template<typename T>
    class Plane3
    {
        public:

    	    /** \brief Default constructor: initialize all the coefficients with the default constructor of T */
            Plane3() :
            	m_a(T()), m_b(T()), m_c(T()), m_d(T()),
            	m_1_a(T()), m_1_b(T()), m_1_c(T())
            {}

    	    /**
    	     * \brief Constructor accepting 3 points
    	     *
    	     * Calculate the proper coefficients for a plane passing for the 3 points passed as argument
    	     * \tparam U internal type for the 3-D points used as parameter
    	     * \param [in] p0 1st point to be used as constraint for the current plane
    	     * \param [in] p1 2nd point to be used as constraint for the current plane
    	     * \param [in] p2 3rd point to be used as constraint for the current plane
    	     *
    	     * This constructor throws a std::runtime error when a plane passing for the 3 points cannot be found
    	     */
            template<typename U>
            Plane3(const Point3<U>& p0, const Point3<U>& p1, const Point3<U>& p2)
            {
                if(!Create(p0, p1, p2))
                    throw std::runtime_error("Plane3<T>::Plane3<T>(): Trying to create a plane from invalid points!");
            }

    	    /**
    	     * \brief Constructor accepting 3 points (non-throwing version)
    	     *
    	     * Calculate the proper coefficients for a plane passing for the 3 points passed as argument
    	     * \tparam U internal type for the 3-D points used as parameter
    	     * \param [in] p0 1st point to be used as constraint for the current plane
    	     * \param [in] p1 2nd point to be used as constraint for the current plane
    	     * \param [in] p2 3rd point to be used as constraint for the current plane
 	 	 	 * \param [out] valid contains true if the plane has been created correctly, false otherwise
    	     */
            template<typename U>
            Plane3(const Point3<U>& p0, const Point3<U>& p1, const Point3<U>& p2, bool& valid)
            {
                valid = Create(p0, p1, p2);
            }

    	    /**
    	     * \brief Constructor accepting the 3 coefficients a, b, and c
    	     *
    	     * Calculate the proper coefficients for a plane passing for the 3 points passed as argument
    	     * \tparam U internal type for the 3-D points used as parameter
    	     * \param [in] a a coefficient used as for the current plane
    	     * \param [in] b b coefficient used as for the current plane
    	     * \param [in] c c coefficient used as for the current plane
    	     *
    	     * This constructor throws a std::runtime error when a plane passing for the 3 points cannot be found
    	     */
            template<typename U>
            Plane3(U a, U b, U c, U d)
            {
                T norm = sqrt(a * a + b * b + c * c);

                if(norm < std::numeric_limits<T>::epsilon())
                    throw std::runtime_error("Plane3<T>::Plane3<T>(): Trying to create a plane from invalid params!");

                m_a = a / norm;
                m_b = b / norm;
                m_c = c / norm;
                m_d = d / norm;

                if(m_a)
                    m_1_a = 1.0 / m_a;

                if(m_b)
                    m_1_b = 1.0 / m_b;

                if(m_c)
                    m_1_c = 1.0 / m_c;
            }

    	    /**
    	     * \brief Returns the y coordinate of the plane corresponding to the y and z passed as argument
    	     *
    	     * std::numeric_limits<T>::quiet_NaN() is returned when the a coefficient is 0
    	     */
            template<typename U>
            inline T X(U y, U z) const
            {
                if(m_a)
                    return -(m_b * y + m_c * z + m_d) * m_1_a;
                else
                    return std::numeric_limits<T>::quiet_NaN();
            }

    	    /**
    	     * \brief Returns the y coordinate of the plane corresponding to the x and z passed as argument
    	     *
    	     * std::numeric_limits<T>::quiet_NaN() is returned when the b coefficient is 0
    	     */
            template<typename U>
            inline T Y(U x, U z) const
            {
                if(m_b)
                    return -(m_a * x + m_c * z + m_d) * m_1_b;
                else
                    return std::numeric_limits<T>::quiet_NaN();
            }

    	    /**
    	     * \brief Returns the z coordinate of the plane corresponding to the x and y passed as argument
    	     *
    	     * std::numeric_limits<T>::quiet_NaN() is returned when the c coefficient is 0
    	     */
            template<typename U>
            inline T Z(U x, U y) const
            {
                if(m_c)
                    return -(m_a * x + m_b * y + m_d) * m_1_c;
                else
                    return std::numeric_limits<T>::quiet_NaN();
            }

    	    /** \brief Returns the corresponding z coordinate on the current plane of a 2-D point passed as argument */
            template<typename U>
            inline T operator()(const Point2<U>& p) const { return Z(p.x, p.y); }

            /** \brief Returns the distance between the point p passed as argument and the current plane */
            template<typename U>
            inline T Distance(const Point3<U>& p) const { return m_a * p.x + m_b * p.y + m_c * p.z + m_d; }

            /** \brief Returns the normal vector to the current plane */
            inline Point3<T> Normal() const { return Point3<T>(m_a, m_b, m_c); }

        private:

            template<typename U>
            bool Create(const Point3<U>& p0, const Point3<U>& p1, const Point3<U>& p2)
            {
                Point3<T> p1p0 = p1-p0;
                Point3<T> p2p0 = p2-p0;

                // normal = p1p0 x p2p0 (cross product)
                Point3<T> n(p1p0.y * p2p0.z - p1p0.z * p2p0.y, p1p0.z * p2p0.x - p1p0.x * p2p0.z, p1p0.x * p2p0.y - p1p0.y * p2p0.x);

                // normalization
                const T length = sqrt(n.x * n.x + n.y * n.y + n.z * n.z);

                // check for collinearity: p0, p1 and p2 are not aligned iif |(p1-p0) x (p2-p0)| != 0
                if(length < std::numeric_limits<T>::epsilon())
                    return false;

                n /= length;

                m_a = n.x;
                m_b = n.y;
                m_c = n.z;
                m_d = -(n*p0);

                if(m_a)
                    m_1_a = 1.0 / m_a;

                if(m_b)
                    m_1_b = 1.0 / m_b;

                if(m_c)
                    m_1_c = 1.0 / m_c;

                return true;
            }

            
            friend std::ostream& operator<< <>(std::ostream& o, const math::Plane3<T>& p);

            T m_a, m_b, m_c, m_d;
            T m_1_a, m_1_b, m_1_c;
    };

    typedef Plane3<int> Plane3i; ///< Short type for a 3-D plane of int
    typedef Plane3<float> Plane3f; ///< Short type for a 3-D plane of float
    typedef Plane3<double> Plane3d; ///< Short type for a 3-D plane of double
    
    
    /** \brief operator for printing the plane coefficients on a stream */
    template<class T>
    inline  std::ostream& operator<<(std::ostream& o, const math::Plane3<T>& p)
    {
        return o << p.m_a << ", " << p.m_b << ", " << p.m_c << ", " << p.m_d;
    }
    
    
} // namespace math



#endif
