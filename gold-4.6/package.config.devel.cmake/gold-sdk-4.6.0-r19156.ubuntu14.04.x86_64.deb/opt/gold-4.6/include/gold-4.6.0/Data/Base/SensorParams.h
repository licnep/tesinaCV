/**
 * @file SensorParams.h
 * @brief Common parameters for sensors, such as position and orientation
 * @author Paolo Grisleri (grisleri@ce.unipr.it)
 */

#ifndef _CSENSOR_PARAMS_H
#define _CSENSOR_PARAMS_H

#include <string>
#include <stdexcept>
#include <boost/tokenizer.hpp>
#include <boost/lexical_cast.hpp>

namespace dev
{

/**
 * \brief Template for modeling the position parameters of a sensor
 * \tparam L the type used for representing the x,y,z variables
 */
template <class L> struct TPosition
{
  L x, y, z;  ///< coordinates of the sensor position

  /** Default constructor */
  TPosition() {}

  /**
   * \brief Constructor from coordinates of different type
   * \tparam T type different from L of the coordinate set
   * \param x X coordinate [m]
   * \param y Y coordinate [m]
   * \param z Z coordinate [m]
   */
  template <class T>
  TPosition(T x_, T y_, T z_) :
    x(static_cast<L>(x_)),
    y(static_cast<L>(y_)),
    z(static_cast<L>(z_)) {}

  /**
   * \brief Constructor from a string with syntax "x, y, z".
   * Builds the internal coordinate from a string with syntax "x, y, z"
   * where x, y, and z are stream convertible to L type
   * @param str the string to be used for construction. Es: "1.2, 1.0, 0.0"
   */
  TPosition(const std::string& str)
  {
    try
    {
    typedef boost::tokenizer<boost::char_separator<char> > Tokenizer;
    boost::char_separator<char> sep(" \t,");
    Tokenizer tok(str, sep);
    Tokenizer::iterator itr = tok.begin();

    x = boost::lexical_cast<L>(*itr);
    y = boost::lexical_cast<L>(*++itr);
    z = boost::lexical_cast<L>(*++itr);
    }
    catch( const boost::bad_lexical_cast& )
    {
      throw std::runtime_error("[EE] TOrientation - Bad orientation: " + str );
    }
  }

  /**
   * \brief Return the string version of the data with syntax "x, y, z"
   * @return the string version of the data with syntax "x, y, z"
   */
  std::string string() const
  {
      std::ostringstream oss;
      oss << x << ", "  << y << ", " << z;
      return oss.str();
  }
};



/**
 * \brief Template for modeling the orientation parameters of a sensor
 * \tparam L the type used for representing the yaw,pitch,roll variables
 */
template <class A> struct TOrientation
{
  A yaw, pitch, roll;  ///< sensor orientation

  /** Default constructor */
  TOrientation() {}

  /**
   * \brief Constructor from values of different type
   * \tparam T type different from L of the orientation set
   * \param yaw Yaw value [rad]
   * \param pitch Pitch value [rad]
   * \param roll Roll value [rad]
   */
  template <class T>
  TOrientation(T yaw_, T pitch_, T roll_) :
    yaw(static_cast<A>(yaw_)),
    pitch(static_cast<A>(pitch_)),
    roll(static_cast<A>(roll_)) {}

  /**
   * \brief Constructor from a string with syntax "yaw, pitch, roll".
   * Builds the internal coordinate from a string with syntax "yaw, pitch, roll"
   * where yaw, pitch and roll are stream convertible to L type
   * @param str the string to be used for construction. Es: "0.0, 0.3, 0.0"
   */
  TOrientation(const std::string &str)
  {
    try
    {
      // decodifica la stringa
      typedef boost::tokenizer<boost::char_separator<char> > Tokenizer;
      boost::char_separator<char> sep(" \t,");
      Tokenizer tok(str, sep);
      Tokenizer::iterator itr = tok.begin();

      yaw   = boost::lexical_cast<A>(*itr);
      pitch = boost::lexical_cast<A>(*++itr);
      roll  = boost::lexical_cast<A>(*++itr);
    }
    catch( const boost::bad_lexical_cast& )
    {
      throw std::runtime_error("[EE] TOrientation - Bad orientation: " + str );
    }
  }

  /**
   * \brief Return the string version of the data with syntax "yaw, pitch, roll".
   * @return the string version of the data with syntax "yaw, pitch, roll".
   */
  std::string string() const
  {
      std::ostringstream oss;
      oss << yaw << ", "  << pitch << ", " << roll;
      return oss.str();
  }
};

/**
 * \brief Template for modeling angular field of view
 * \deprecated This class is now deprecated. \see PixelFocalLenght (ku,kv) in TCameraParams
 */
template <class A> struct TAngularFOV
{
  A H, V; ///< Horizontal and vertical angular field of view [rad]

  /** \brief Default constructor */
  TAngularFOV() {}

  /**
   * \brief Cast constructor: construct the object from 2 values of different type
   */
  template <class T>
  TAngularFOV(T HFOV_, T VFOV_) :
    H(static_cast<A>(HFOV_)),
    V(static_cast<A>(VFOV_))
    {}
};

} // namespace dev

#endif
