/**
 * @file FormatsEnumerator.h
 * @brief Classes for registering data serialization formats
 * @author Paolo Grisleri (grisleri@ce.unipr.it)
 */

#ifndef _FORMAT_ENUMERATOR_H
#define _FORMAT_ENUMERATOR_H

#include <map>
#include <iosfwd>
#include <vector>

#include <boost/property_tree/ptree.hpp>

#include <Data/gold_data_export.h>


// NOTE: this patch is needed for compiling on both MSVC e gcc-4.7
// MSVC exports template symbols when they are declared without visibility specifiers
// gcc-4.7 exports template symbols when they are declared with visibility specifiers


#ifndef GOLD_DATA_TEMPLATE_EXPORT
#if defined (_MSC_VER)
	#define GOLD_DATA_TEMPLATE_EXPORT
#else
	#define GOLD_DATA_TEMPLATE_EXPORT GOLD_DATA_EXPORT
#endif
#endif // GOLD_DATA_TEMPLATE_EXPORT

/** \brief Classes modeling data produced from devices and sensors, such as: images, scans, and can messages */
namespace data
{


/**
 * \brief struct for describing a data serialization format
 */
struct GOLD_DATA_TEMPLATE_EXPORT FormatDescriptor
{
  /**
   * \brief string identifier for the data serialization format
   */
  std::string id;

  /**
   * \brief string version of the data serialization format
   */
  std::string version;

  /**
   * \brief string version of the data serialization format
   */
  std::string description;

  /**
   * \brief vector of string containing the supported file extensions
   */
  std::vector<std::string> extensions;

  /**
   * \brief property tree containing the options associated to each extension
   */
  boost::property_tree::ptree options;
};
  

/**
 * \brief Data serialization format enumerator for a generic BaseType.
 * \tparam BaseType Type of the parent class specific for a FormatEnumerator
 *
 * A separate TFormatEnumerator shall be instantiated for every BaseType
 * The format enumerator collects the informations of formats, expressed as
 * types or as extensions, and associated to the corresponding load/save pair for
 * every concrete type derived from BaseType.
 *
 */
template <class BaseType>
class GOLD_DATA_TEMPLATE_EXPORT TFormatEnumerator
{
	/** \brief Type for the key used for format lookup */
    typedef std::type_info KeyType;

    /** \brief Type of the map for converting string into keytype */
    typedef std::map< std::string, const KeyType* > StringToFormatType;

    /** \brief Map for converting string to format */
    StringToFormatType StringToFormat;
    
  public:
    
  /** \brief Type for the options */
  typedef boost::property_tree::ptree OptionsType;

  /** \brief Type for the load function */
  typedef void ( *LoadType ) ( std::istream& in, BaseType& data, const OptionsType& options );

  /** \brief Type for the save function */
  typedef void ( *SaveType ) ( const BaseType& data, std::ostream& out, const OptionsType& options );
    
  /** \brief Internal descriptor */
  struct Descriptor
  {
	  /** \brief Pointer to a FormatDescriptor containing the format metadata */
    FormatDescriptor* metadata;

    /** \brief The load function */
    LoadType load;

    /** \brief The save function */
    SaveType save;
  };    

  private:

    /**
     * \brief hash merging format and type
     */
    struct CFormatKey
    {
    	/**
    	 * \brief Constructor accepting object and format as KeyType
    	 */
      CFormatKey ( const KeyType* _object, const KeyType* _format  );

      const KeyType* object;
      const KeyType* format;

      bool operator< ( const CFormatKey& format_key ) const;

      template <typename T>
      friend std::ostream& operator <<(std::ostream& os, const typename data::TFormatEnumerator<T>::CFormatKey& fk);
    };

    // format map: association between the format key and the IO functions
    typedef std::map<CFormatKey, Descriptor > FormatsType;
    FormatsType m_formats;

    typedef typename FormatsType::iterator IteratorType;
    typedef typename FormatsType::const_iterator ConstIteratorType;


  public:

    /** \brief This is the static method for accessing the singleton instance */
    static TFormatEnumerator& Instance();
    
    /**
     * \brief Register a new format descriptor
     * \tparam Concrete type associated to the format
     * \tparam Dummy type for representing the format
     *
     * \param load_funct  The load function
     * \param save_funct  The save function
     * \param desc  Format descriptor
     */
    template <class ConcreteType, class FormatType>
    void Register ( LoadType load_funct, SaveType save_funct, const FormatType& desc );
    
    /** \brief Returns an array with the format descriptors*/
    const std::vector< FormatDescriptor >& MetaData() const;

    /** \brief Prints the registred format registered in the current instance on a string */
    void PrintFormats(std::string& str) const;
    
    /** \brief Prints the file extensions registered in the current instance on a string */
    void PrintExtensions(std::string& err) const;    

    /**
     * \brief Calls the corresponding load function for BaseType selecting the format from a string
     * \param in the input stream where object will be loaded
     * \param object the object that will be loaded from the istream
     * \param format a string representing the format to be used for the load function
     * \param option Options for the required format
     */
    void Load ( std::istream& in,
    		    BaseType& object,
    		    const std::string& format,
    		    const OptionsType& options=OptionsType() );

    /**
     * \brief Calls the corresponding save function for BaseType selecting the format from a string
     * \param out the output stream where object will be saved
     * \param object the object that will be saved from the ostream
     * \param format a string representing the format to be used for the save function
     * \param option Options for the required format
     */
    void Save ( std::ostream& out,
    		    const BaseType& object,
    		    const std::string& format,
    		    const OptionsType& options=OptionsType() ) const;


    /**
     * \brief Calls the corresponding load function for object
     * \tparam ObjectType type of the object used for retrieve the load function
     * \tparam FormatType type of the format to be used for loading the object
     * \param in the input stream where object will be loaded
     * \param object the object that will be loaded from the istream
     * \param option Options for the required format
     */
    template <class ObjectType,
    		  class FormatType>
    void Load ( std::istream& in,
    			ObjectType& object,
    			const OptionsType& options=OptionsType() );

    /**
     * \brief Calls the corresponding save function for object
     * \tparam ObjectType type of the object used for retrieve the save function
     * \tparam FormatType type of the format to be used for saving the object
     * \param in the input stream where object will be saved
     * \param object the object that will be saved from the istream
     * \param option Options for the required format
     */
    template <class ObjectType,
    		  class FormatType>
    void Save ( std::ostream& out,
    			const ObjectType& object,
    			const OptionsType& options=OptionsType() ) const;
    
    /**
     * \brief Returns the internal descriptor for DerivedType using the file extension lookup
     * \tparam DerivedType A type derived from BaseType
     * \param t reference to an instance of an object of type DerivedType
     * \param extension file extension to be searched
     */
    template <typename DerivedType>
    const typename data::TFormatEnumerator<BaseType>::Descriptor& Find ( DerivedType& t, const std::string& extension ) const;    
    
    /**
     * \brief Returns the internal descriptor for BaseType using the file extension lookup
     * \param extension file extension to be searched
     */
    const typename data::TFormatEnumerator<BaseType>::Descriptor& Find ( const std::string& extension ) const;        

  private:
    
    std::vector< FormatDescriptor > m_metadata;
    
    const typename data::TFormatEnumerator<BaseType>::Descriptor& _Find ( const CFormatKey& key ) const;
    const KeyType* _Find ( const std::string& extension ) const;     

    
    void Load ( std::istream& in, BaseType& object, const CFormatKey& key, const OptionsType& options );
    void Save ( const BaseType& object, std::ostream& out, const CFormatKey& key, const OptionsType& options ) const;
};




// functions to be implemented for each data,format pair

///////////////////////////////////////////////////////////////////////////////

/**
 * \brief Load function to be implemented for each {data, format} pair.
 * \tparam O concrete data type
 * \tparam F format data
 * \param object object to be loaded
 * \param options load options, format specific
 */
template <class O, class F>
void Load ( O& object,
			std::istream& in,
			const std::string& options="" );

/**
 * \brief Save function to be implemented for each {data, format} pair.
 * \tparam O concrete data type
 * \tparam F format data
 * \param object object to be saved
 * \param options save options, format specific
 */
template <class O, class F>
void Save ( std::ostream& out, const O& object, const std::string& options="" );

///////////////////////////////////////////////////////////////////////////////


} // namespace data

#endif
