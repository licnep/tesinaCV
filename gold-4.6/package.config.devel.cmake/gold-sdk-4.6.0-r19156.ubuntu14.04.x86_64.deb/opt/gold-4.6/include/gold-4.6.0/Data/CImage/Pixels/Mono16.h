/**
 * \file Pixels/Mono16.h
 * \brief Definitions for modeling 1 channel, 16-bit unsigned integer pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _MONO16_H
#define _MONO16_H

#include <stdint.h>

namespace cimage
{
/**
 * \brief Definition for Mono16 pixels
 * This pixel support one unsigned luminance channel with a depth of 16 bit
 */
typedef uint16_t Mono16;
}

#endif
