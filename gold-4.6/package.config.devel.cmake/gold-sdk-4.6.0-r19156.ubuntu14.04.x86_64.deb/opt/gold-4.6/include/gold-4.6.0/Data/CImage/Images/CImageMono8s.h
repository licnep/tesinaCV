/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file CImageMono8s.h
 * \brief Class for modeling an 8-bit signed monochrome image
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Paolo Zani (zani@ce.unipr.it)
 * \date 2006-10-08
 */

#ifndef _CIMAGESIGNEDMONO8_H
#define _CIMAGESIGNEDMONO8_H

#include <Data/CImage/Pixels/Mono8s.h>
#include <Data/CImage/TImage.h>

namespace cimage
{
  /** \brief Type for declaring an 8-bit signed monochrome image */
  typedef TImage<cimage::Mono8s> CImageMono8s;
}

#endif

