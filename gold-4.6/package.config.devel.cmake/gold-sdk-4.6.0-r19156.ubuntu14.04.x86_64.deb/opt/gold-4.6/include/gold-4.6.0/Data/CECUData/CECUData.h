/**
 * \file CECUData.h
 * \brief Class modeling a data produced from an ECU
 * \author Luca Gatti \<lucag@ce.unipr.it\>
 */

#ifndef _CECUDATA_H
#define _CECUDATA_H

#include <Data/gold_data_export.h>

#include <Data/Math/Points.h>
#include <Data/Math/TMatrices.h>
#include <Processing/Math/Transformation.h>

#include <boost/date_time/posix_time/posix_time_types.hpp>

#include <stdint.h>

#include <vector>
#include <cstring>

namespace data
{
/**
 * \brief Class modeling one of the objects detected from an ECU
 */
class GOLD_DATA_EXPORT CObjectDetected  :
  public math::Point3d
{
public:
  /** \brief Default constructor */
  CObjectDetected();

  /** \brief classification for the motion type */
  struct GOLD_DATA_EXPORT MotionStatus
  {
    enum {
      NOT_DEFINED = 0, ///< Motion status cannot be determined
      STATIONARY,      ///< Fixed object, such as a tree, a pole
      MOVING           ///< Moving object, such as a pedestrian, or a moving vehicle
    };
    
    // TODO IDEA a boost::bimap can be used here, move in the corresponding driver

    /**
     * \brief Method for converting the motion status value to the corresponding string
     * \param [in] motion_status the motion status value to be converted
     * \param [out] str the string converted that will be valid values are "Not Defined", "Stationary", "Moving".
     */
    static void ToString(uint32_t motion_status, std::string& str);

    /**
     * \brief Method for converting a string in the corresponding MotionStatus value
     * \param [in] s the string containing the motion status value to be converted.
     * valid values are "Not Defined", "Stationary", "Moving".
     * \return the value converted
     */
    static uint32_t FromString(const std::string& s);
  };
  
  /**
   * \brief Defines whether the obstacle is in front of the sensor or not
   */
  struct GOLD_DATA_EXPORT LeadingStatus
  {
    enum {
      NOT_DEFINED = 0,  ///< Not defined
      NO_LEADING,       ///< The obstacle is not front of the sensor
      LEADING           ///< The obstacle is in front of the sensor
    };
    
    /**
     * \brief Conversion from LeadingStatus value to string
     */
    static void ToString(uint32_t i, std::string& str);

    /**
     * \brief Conversion from string to LeadingStatus value
     */
    static uint32_t FromString(const std::string& s);
  };
  

  /**
   * \brief Classification for the type of object represented
   */
  struct GOLD_DATA_EXPORT ObjectType
  {
    enum {
      NOT_DEFINED = 0,  ///< not defined
      PEDESTRIAN,       ///< A pedestrian
      CAR,              ///< A car
      TRUCK,            ///< A truck or a bus
      BIKE,             ///< A bicycle
      MOTORCYCLE,       ///< A motorcycle
      GUARD_RAIL,       ///< A guard rail
      GENERIC_PAINTED_MARKINGS,  ///< Painted markings such as lane markings
      ROAD_SIGN,        ///< A road sign
      WALL,             ///< A wall
      HILL,             ///< A hill or a slope change
      OTHER_TYPE        ///< A different type of object
    };

   /**
    * \brief convert an object type value in the corresponding string a string
    * \param [in] i the  ObjectType to be converted
    * \param [out] str the string converted
    */
    static void ToString(uint32_t i, std::string& str);

    /**
     * \brief a string in the corresponding object type
     * \param [in] s the string to be converted. Allowed values are:
     * "Not Defined", "Pedestrian", "Car", "Truck", "Bike", "Motorcycle",
     * "Guard Rail", "Generic Painted Markings", "Road Sign", "Wall",
     * "Hill", "Other Type"
     * \return [out] the corresponding ObjectType value
     */
    static uint32_t FromString(const std::string& s);

  };

  /**
   * \brief Classification for the painted markings types
   */
  struct GOLD_DATA_EXPORT PaintedMarkingType
  {
    enum {
      NOT_DEFINED = 0, ///< Not defined
      SINGLE_LINE,     ///< Single line
      DOUBLE_LINE,     ///< Double line
      ROAD_CROSSING,   ///< Road crossing
      STOP_LINE,       ///< Stop line
      OTHER_TYPE       ///< Other type
    };
    //TODO string
  };
  
  /**
   * \brief Classification for lane position
   */
  struct GOLD_DATA_EXPORT LanePositionType
  {
    enum {
      NOT_DEFINED = -4,      ///< Not defined
      RIGHTRIGHTRIGHT = -3,  ///< ???
      RIGHTRIGHT = -2,       ///< ???
      RIGHT = -1,            ///< ???
      EGOLANE = 0,           ///< ???
      LEFT = 1,              ///< ???
      LEFTLEFT = 2,          ///< ???
      LEFTLEFTLEFT = 3,      ///< ???
    };
    // TODO string
  };

  /**
   * \brief Copy operator from a Point3d
   * \param point Point3d to be copied in the internal data
   */
  const math::Point3d& operator=(const math::Point3d& point);

  boost::uint8_t ECUID;                         ///< Identifier of the ECU that detected the object
  boost::uint64_t ObstacleID;                   ///< Obstacle tracking identifier
  boost::uint8_t MotionClassification;          ///< Motion classification. \see MotionStatus
  boost::uint8_t LeadingClassification;         ///< ??? PRINCIPALE/NON PRINCIPALE
  boost::uint8_t ObjectClassification;          ///< Object classification. \see ObjectType
  boost::uint8_t MarkingClassification;         ///< Classification for the detected marking
  boost::uint8_t LanePos;                       ///< Position inside the lane

  bool singlePoint;                             ///< true when a single points represent the object center. Can be true even when vectorOfPoint is true
  bool vectorOfPoint;                           ///< true when a point cloud represent the object. Can be true even when singlePoint is true
  std::vector<math::Point3d> points;                  ///< Other points identifying the object (???)
  std::vector<float> angles;                    ///< vector of angles (???)[rad]
  std::vector<float> other_values;              ///< Vector with other data ???
  float width;                                  ///< Object width [m]
  float height;                                 ///< Object height [m]
  float length;                                 ///< Object length [m]
  double speed;                                 ///< Speed module [m/s]
  double speed_x;                               ///< Velocity along the X axel [m/s]
  double speed_y;                               ///< Velocity along the Y axel [m/s]
  double acceleration;                          ///< Acceleration module [m/s^2]
  double acceleration_x;                        ///< Acceleration value along the X axel [m/s^2]
  double acceleration_y;                        ///< Acceleration value along the Y axel [m/s^2]
};


/**
* \brief Class modeling a data produced from an ECU
*
* ECU Data is a list of objects, each related to a tracking id and classifications
* Some sensors such as radars produces high level data organized in this way
*/
class GOLD_DATA_EXPORT CECUData
{
  public:
	/** \brief Constructor taking the number of obstacle*/
    CECUData(boost::uint8_t obstacle_amount);
    
    /** \brief Default constructor obstacle*/
    CECUData(){}

    /**
	 * \brief Struct for enumerating the sensor status
	 *
	 */
    struct GOLD_DATA_EXPORT SensorStatus
    {
      enum {
        NOT_DEFINED = 0,  ///< Sensor status not defined
        WORKS_CORRECTLY,  ///< Sensor is working correclty
        ERRORS            ///< An error status has been signaled
      };

      /**
       * \brief Convert SensorStatus to the corresponding string
       */
      static void ToString(uint32_t i, std::string& str);

      /**
       * \brief Convert a string in the corresponding SensorStatus
       */
      static uint32_t FromString(const std::string& s);
    };
    
    /**
	 * \brief Struct for modeling the current system mode
	 *
	 * This is strictly related to radars from SMS
	 */
    struct GOLD_DATA_EXPORT SystemMode
    {
      enum {
        NOT_DEFINED = 0,  ///< system mode not defined
        FMSK,             ///< frequency-modulated shift keying
        PDHS,             ///< phase doppler ???
        PDHM,             ///< pure doppler ???
        OTHER_MODE        ///< ???
      };

      /**
       * \brief Convert SystemMode to the corresponding string
       */
      static void ToString(uint32_t i, std::string& str);

      /**
       * \brief Convert a string in the corresponding SystemMode
       */
      static uint32_t FromString(const std::string& s);
    };
    
    boost::posix_time::time_duration TimeStamp_Start; ///< Computation begin timestamp
    boost::posix_time::time_duration TimeStamp_End;   ///< Computation end timestamp

    double Angle_Start, Angle_End, Distance_Start, Distance_End; ///< Range
    
    unsigned long  Cycle_Count;

    boost::uint8_t ECUID;                         ///< ECU identifier
    boost::uint8_t Status;                        ///< SensorStatus: defines whether the sensor is working correctly or not
    boost::uint8_t SystemMode;                    ///< System Mode:
    
    typedef std::vector<CObjectDetected> ObjectDetectedType;

    boost::uint64_t ValidObjectCounter;
    ObjectDetectedType ObjectData;
};


  /**
   * \brief Matrix for rotations and scale changes
   */
  typedef math::TMatrix<double, 3,3> TransformationType;

  /**
   * \brief Affine Matrix, rotations and translations
   */
  typedef math::TMatrix<double, 3,4> TransformationType4;

  /**
   * \brief Translate all of the dst points using offset
   */
  GOLD_DATA_EXPORT void Translate( CECUData& dst, const math::Point3d& offset );

  /**
   * \brief Transform each object in scan in a corresponding object in dst applying T transformation
   * \see Transformation.h
   */
  GOLD_DATA_EXPORT void Transform( const CECUData& scan, CECUData& dst,  const TransformationType4& T );

  /**
   * \brief Apply a regular 3x3 transformation to each object
   */
  GOLD_DATA_EXPORT void Apply( CECUData& dst, const math::TMatrix<double, 3,3> & T );

  /**
   * \brief Apply an affine 3x4 transformation to each object
   */
  GOLD_DATA_EXPORT void Apply( CECUData& dst, const math::TMatrix<double, 3,4> & T );
  
} // namespace data  

#endif //_CSCAN_H
