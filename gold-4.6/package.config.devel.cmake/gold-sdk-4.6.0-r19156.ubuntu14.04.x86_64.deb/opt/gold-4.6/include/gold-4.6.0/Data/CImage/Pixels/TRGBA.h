/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/

/**
 * \file TRGB.h
 * \brief Definitions for modeling Red, Green, Blue, Alpha (RGBA), 3 channel, generic pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 * \date 2006-10-23
 */

#ifndef _TRGBA_H
#define _TRGBA_H

#include <boost/operators.hpp>

#include <Data/gold_data_export.h>


// NOTE: this patch is needed for compiling on both MSVC and gcc-4.7
// MSVC requires exported template symbol without specifiers
// gcc-4.7 requires exported template symbol with specifiers
#if defined (_MSC_VER)
	#define GOLD_DATA_TEMPLATE_EXPORT
#else
	#define GOLD_DATA_TEMPLATE_EXPORT GOLD_DATA_EXPORT
#endif

namespace cimage
{

  /**
   * \brief Class for modeling Red, Green, Blue, alpha (RGBA), 4 channel, generic pixels
   * \tparam S type to be used as channel type for R, G, and B values
   */
  template <class S>
  class GOLD_DATA_TEMPLATE_EXPORT TRGBA : 
          boost::addable< TRGBA<S> ,        
          boost::subtractable<TRGBA<S>,
          boost::multipliable<TRGBA<S>,
          boost::dividable<TRGBA<S>,
          boost::orable<TRGBA<S>,
          boost::andable<TRGBA<S>,
          boost::xorable<TRGBA<S>,
          boost::less_than_comparable <TRGBA<S>,
          boost::equality_comparable<TRGBA<S>
            > > > > > > > > >
  {
    public:

      /** \brief Enumerator for channel type */
      typedef enum Channels {RED=0, GREEN=1, BLUE=2, alpha=3} Channel;

      /** \brief Default constructor */
      TRGBA()
      {}

      /** \brief Constructor taking a value. R, G, and B values are set to the argument value */
      explicit TRGBA ( const S val ) :
    		  R ( val ),
    		  G ( val ),
    		  B ( val ),
    		  A ( val )
      {}

      /** \brief Constructor accepting 3 separated R, G, B, and A values of a convertible type */
      template<class T>
      inline explicit TRGBA ( T r, T g, T b, T a ) :
          R ( static_cast<S> ( r ) ),
          G ( static_cast<S> ( g ) ),
          B ( static_cast<S> ( b ) ),
          A ( static_cast<S> ( a ) )
      {}

      /** \brief Constructor accepting 3 separated R, G, B, and A values of a type S */
      inline explicit TRGBA ( S r, S g, S b, S a=255 ) :
          R ( static_cast<S> ( r ) ),
          G ( static_cast<S> ( g ) ),
          B ( static_cast<S> ( b ) ),
          A ( a )
      {}

       /** \brief Constructor accepting a luminance value */
 	   template<class T>
	   inline explicit TRGBA ( const T luminance ) :
	     R ( static_cast<S> ( luminance ) ),
	     G ( static_cast<S> ( luminance ) ),
	     B ( static_cast<S> ( luminance ) ),
	     A ( 255 )
	   {}

      /** \brief Constructor accepting a luminance and an alpha value */
      template<class T>
      inline explicit TRGBA ( const T luminance, const T alpha ) :
          R ( static_cast<S> ( luminance ) ),
          G ( static_cast<S> ( luminance ) ),
          B ( static_cast<S> ( luminance ) ),
          A ( alpha )
      {}


      /** \brief Returns true when the current pixel has each R, G, B, and A value less than the corresponding value of the argument */
      bool operator < (const TRGBA& a) const
      {
        return R<a.R  && G<a.G  && B<a.B && A<a.A;
      }

      /** \brief Returns true when the current pixel has each R, G, B, and A value strictly equal to the corresponding value of the argument */
      bool operator == (const TRGBA& a) const
      {
        return R==a.R  && G==a.G  && B==a.B && A==a.A;
      }

      // TODO: operator ~

      /** \brief Set the current pixel value to the BITWISE AND between the current value and the argument */
      inline TRGBA& operator &= ( const TRGBA& value )
      {
        R&=value.R, G&=value.G, B&=value.B, A&=value.A;
        return *this;
      }

      /** \brief Set the current pixel value to the BITWISE OR between the current value and the argument */
      inline TRGBA& operator |= ( const TRGBA& value )
      {
        R|=value.R, G|=value.G, B|=value.B, A|=value.A;
        return *this;
      }

      /** \brief Set the current pixel value to the BITWISE XOR between the current value and the argument */
      inline TRGBA& operator ^= ( const TRGBA& value )
      {
        R^=value.R, G^=value.G, B^=value.B, A^=value.A;
        return *this;
      }



      /** \brief Set the current pixel value to the SUM between the current value and the argument */
      inline TRGBA& operator += ( const TRGBA& value )
      {
        R+=value.R, G+=value.G, B+=value.B, A+=value.A;
        return *this;
      }

      /** \brief Set the current pixel value to the DIFFERENCE between the current value and the argument */
      inline TRGBA& operator -= ( const TRGBA& value )
      {
        R-=value.R, G-=value.G, B-=value.B, A-=value.A;
        return *this;
      }

      /** \brief Set the current pixel value to the PRODUCT between the current value and the argument */
      inline TRGBA& operator *= ( const TRGBA& value )
      {
        R*=value.R, G*=value.G, B*=value.B, A*=value.A;
        return *this;
      }

      /** \brief Set the current pixel value to the QUOTIENT between the current value and the argument */
      inline TRGBA& operator /= ( const TRGBA& value )
      {
        R/=value.R, G/=value.G, B/=value.B, A/=value.A;
        return *this;
      }


      /** \brief Set the current pixel value to the SUM between the current value and the argument */
      template<class T>
      inline TRGBA& operator += ( const T factor )
      {
        R=static_cast<S> ( factor+R ),
        G=static_cast<S> ( factor+G ),
        B=static_cast<S> ( factor+B );
        A=static_cast<S> ( factor+A );
        return *this;
      }

      /** \brief Set the current pixel value to the DIFFERENCE between the current value and the argument */
      template<class T>
      inline TRGBA& operator -= ( const T factor )
      {
        R=static_cast<S> ( R-factor ),
        G=static_cast<S> ( G-factor ),
        B=static_cast<S> ( B-factor );
        A=static_cast<S> ( A-factor );
        return *this;
      }

      /** \brief Set the current pixel value to the PRODUCT between the current value and the argument */
      template<class T>
      inline TRGBA& operator *= ( const T factor )
      {
        R=static_cast<S> ( factor*R ),
        G=static_cast<S> ( factor*G ),
        B=static_cast<S> ( factor*B );
        A=static_cast<S> ( factor*A );
        return *this;
      }

      /** \brief Set the current pixel value to the QUOTIENT between the current value and the argument */
      template<class T>
      inline TRGBA& operator /= ( const T factor )
      {
        R=static_cast<S> ( R/factor ),
        G=static_cast<S> ( G/factor ),
        B=static_cast<S> ( B/factor );
        A=static_cast<S> ( A/factor );
        return *this;
      }


      /** \brief Returns a TRGBA obtained from the SUM between a two TRGBA arguments */
      template<class T>
      friend inline TRGBA operator + ( const T factor, const TRGBA& value )
      {
        return TRGBA ( value ) +=factor;
      }

      /** \brief Returns a TRGBA obtained from the DIFFERENCE between a two TRGBA arguments */
      template<class T>
      friend inline TRGBA operator - ( const T factor, const TRGBA& value )
      {
        return TRGBA ( value )-=factor;
      }

      /** \brief Returns a TRGBA obtained from the PRODUCT between a two TRGBA arguments */
      template<class T>
      friend inline TRGBA operator * ( const T factor, const TRGBA& value )
      {
        return TRGBA ( value ) *=factor;
      }

      /** \brief Returns a TRGBA obtained from the QUOTIENT between a two TRGBA arguments */
      template<class T>
      friend inline TRGBA operator / ( const T factor, const TRGBA& value )
      {
        return TRGBA ( value ) /=factor;
      }

      /**
       * \brief Returns the value of the channel with index selected from the argument
       * \param i channel number
       * \return the value for the i-th channel
       */
      S operator [](unsigned int i) const { return *(&R+i); }


      S R;  ///< The Red channel value
      S G;  ///< The Green channel value
      S B;  ///< The Blue channel value
      S A;  ///< The Alpha (transparency) channel value

  };

}


#endif
