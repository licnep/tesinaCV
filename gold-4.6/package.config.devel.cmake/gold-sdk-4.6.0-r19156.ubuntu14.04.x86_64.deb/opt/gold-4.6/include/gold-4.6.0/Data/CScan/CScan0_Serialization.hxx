#ifndef _CSCAN0_SERIALIZATION_HXX
#define _CSCAN0_SERIALIZATION_HXX

/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8
// Old CScan Serialization support
#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>

#include <boost/archive/text_oarchive.hpp>
#include <boost/archive/text_iarchive.hpp>

#include <boost/serialization/split_free.hpp>

#include <Data/Math/Points.h>

  
///////////////////////////////////////////////////////////////////////////////
///////////////////////////// DEPRECATED VERSION //////////////////////////////
///////////////////////////////////////////////////////////////////////////////

namespace data
{

/// Impulso di una scansione in un piano (ha una eco principale ed altre secondarie)
struct CScanEcho0 :
  public math::Point3d
{
  typedef enum 
  {
    // NOTE These Flags are based on the IBEO Alasca XT
    INVALID,
    NORMAL,
    RAIN,
    GROUND,
    DIRT
  } ClassificationID;

  int ID;           ///< Echo identifier

  /// NOTE: Leght==Duration if unit is arbitrary
  double Length;    ///< Echo Length [m] (0.0 = INVALID)
  double Duration;  ///< Echo Duration [s] (0.0 = INVALID)

  ClassificationID Classification;   ///< Pulse classification
  uint8_t  DeviceID;          ///< Device Identifier

  CScanEcho0() :
    math::Point3d(),
    ID(-1),
    Length(0.0),
    Duration(0.0),
    Classification(INVALID),
    DeviceID(0)
  {}

  CScanEcho0(const math::Point3d& Point, int echo=0, double length=0.0, double duration=0.0,
    ClassificationID classification=NORMAL, uint8_t device_id=0u) :
    math::Point3d(Point),
    ID(echo),  // FIXME? ok? serve per il drawer, ma dovrebbe contenere anche NumPulse e NumLayer
    Length(length),
    Duration(duration),
    Classification(classification),
    DeviceID(device_id)
  {}
};


/// scansioni su un piano
struct CScanLayer0
{
  typedef std::vector<CScanEcho0> ScanPulsesType;
  typedef ScanPulsesType::iterator ScanPulsesItrType;

  ScanPulsesType Pulses;

  CScanLayer0() {}
  CScanLayer0(unsigned int NumPulses) : Pulses(NumPulses) {}

  std::size_t NumPulses() const { return Pulses.size(); }
};



/// Scansione: vettore di Layer
/// TODO renderla invisibile all'esterno
struct GOLD_DATA_EXPORT CScan0
{
  CScan0(uint8_t Layers=0, uint16_t Pulses=0):
  TimeStamp_Start(),
  TimeStamp_End(),
  TimeStamp_UTC_Start(),
  TimeStamp_UTC_End ()
{
//   std::cout << "CScan::Layers size:" << CScan::Layers.size() << std::endl;
  CScan0::Layers.reserve(Layers);
//   std::cout << "CScan::Layers capacity:" << CScan::Layers.capacity() << std::endl;
  for(ScanLayersItrType itr=CScan0::Layers.begin(); itr!=CScan0::Layers.end(); ++itr)
  {
    itr->Pulses.reserve(Pulses);
    // std::cout << "CScan::Layers capacity:" << itr->Pulses.capacity() << std::endl;
  }
}



  typedef std::vector<CScanLayer0> ScanLayersType;
  typedef ScanLayersType::iterator ScanLayersItrType;

  ScanLayersType Layers;

  void Clear();

  unsigned int NumLayers() const { return static_cast<unsigned int>(Layers.size()); }

  // NOTE: questi tempi li dovrebbe dare il device
  // ciò che caratterizza questo dato è invece la durata della scansione
  // che qui è ripetuta due volte
  boost::posix_time::time_duration TimeStamp_Start;
  boost::posix_time::time_duration TimeStamp_End;      ///< Framework timestamp

  boost::posix_time::ptime TimeStamp_UTC_Start;
  boost::posix_time::ptime TimeStamp_UTC_End;          ///< UTC Timestamp

  double Angle_Start, Angle_End;

  // operatori di streaming
  friend std::ostream &operator << (std::ostream &os, const CScan0& Scan);
  friend std::ostream &operator >> (std::ostream &os, CScan0& Scan);
};

inline std::ostream &operator << (std::ostream &os, const CScan0& Scan)
{
  os << "TSS="<< std::endl;
  os << "this is the place where to put the CScan_deprecated save code" << std::endl;
  return os;
}

inline std::ostream &operator >> (std::ostream &os, CScan0& Scan)
{
  os << "this is the place where to put the CScan_deprecated load code" << std::endl;
  return os;
}

/////////////////////////////////////////////////////////////////////////////////////////

}

BOOST_CLASS_VERSION(data::CScanEcho0, 1);   // class serialization version
  
namespace data
{
  #if defined(__GNUC__) 
    #warning Invalid classifications for CScan0 mapped to CScan::NORMAL
  #elif defined(_MSC_VER)
    #pragma message("Invalid classifications for CScan0 mapped to CScan::NORMAL")
  #endif


  // friend class boost::serialization::access;
  // When the class Archive corresponds to an output archive, the
  // & operator is defined similar to <<.  Likewise, when the class Archive
  // is a type of input archive the & operator is defined similar to >>.
  template<class Archive>
  void serialize(Archive & ar, CScanEcho0& sp, const unsigned int version)
  {
    //std::cout << "Serializing CPulse" << std::endl;

    ar & sp.x;
    ar & sp.y;
    ar & sp.z;
    ar & sp.ID;

    if(version > 0)
    {
      ar & sp.Length;
      ar & sp.Duration;
      ar & sp.Classification;
      ar & sp.DeviceID;

      
      if(sp.Classification>CScanEcho0::DIRT)
      {
        // std::cout << "!!!!"<< sp.Classification<<std::endl;
        sp.Classification=CScanEcho0::NORMAL;
      }
    }
  }

  // friend class boost::serialization::access;
  // When the class Archive corresponds to an output archive, the
  // & operator is defined similar to <<.  Likewise, when the class Archive
  // is a type of input archive the & operator is defined similar to >>.
  template<class Archive>
  void serialize(Archive & ar, CScanLayer0& sl, const unsigned int version)
  {
    //std::cout << "Serializing CLayer" << std::endl;
    ar & sl.Pulses;
  }

  // friend class boost::serialization::access;
  // When the class Archive corresponds to an output archive, the
  // & operator is defined similar to <<.  Likewise, when the class Archive
  // is a type of input archive the & operator is defined similar to >>.
  template<class Archive>
  void serialize(Archive& ar, CScan0& Scan, const unsigned int version)
  {
      //std::cout << "Serializing CScan" << std::endl;
      ar & Scan.TimeStamp_Start;
      ar & Scan.TimeStamp_End;

      ar & Scan.TimeStamp_UTC_Start;
      ar & Scan.TimeStamp_UTC_End;

      ar & Scan.Angle_Start;
      ar & Scan.Angle_End;

      ar & Scan.Layers;
  }
} // namespace data

///////////////////////////////////////////////////////////////////////////////
///////////////////////////// DEPRECATED VERSION //////////////////////////////
///////////////////////////////////////////////////////////////////////////////

// Serialization support
/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8

#endif // _CSCAN0_SERIALIZATION_HXX
