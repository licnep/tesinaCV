/**
 * \file Mono8.h
 * \brief Definitions for modeling 1 channel, 8-bit unsigned integer pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _MONO8_H
#define _MONO8_H

#include <stdint.h>

namespace cimage
{
/**
 * \brief Definition for Mono8 pixels
 * This pixel support one luminance channel with a depth of 8-bit unsigned
 */
typedef uint8_t Mono8;
}

#endif
