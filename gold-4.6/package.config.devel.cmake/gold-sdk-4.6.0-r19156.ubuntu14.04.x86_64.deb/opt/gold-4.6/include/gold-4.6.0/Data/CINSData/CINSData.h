/**
 * \file CINSData.h
 * \brief Classes for modeling data produced from and Inertial Navigation System (INS)
 * \author Paolo Medici \<medici@ce.unipr.it\>, Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _CINSDATA_H
#define _CINSDATA_H

#include <Data/gold_data_export.h>

#include <bitset>
#include <string>


#pragma pack(push)
#pragma pack(1)

namespace data
{

/**
 * \brief Data provided from a generic INS
 *
 * The following types of information are provided
 * - sensor status when the data has been captured
 * - a bitset containing the valid data provided by the sensor
 * - the read data
 *     + velocity, acceleration
 *     + orientation, angular velocity
 */
struct GOLD_DATA_EXPORT CINSData
{
public:

  /** Enumerator for sensor status */
  typedef enum 
  {
    STATUS_OFF=0,  ///< The sensor is off
    STATUS_ERROR=-1, ///< the sensor reported an error
    STATUS_BOOT=1,  ///< The sensor is booting
    STATUS_ONLINE=2, ///< The sensor is online and running correctly
  } StatusID;
  
  
  StatusID status; ///< Field for reading the sensor status when the data has been captured

  /** Enumerator for sensor capabilities */
  typedef enum Capabilities
  {
    CAP_ODOMETER, ///< absolute space
        
    CAP_VX,    ///< X velocity
    CAP_VY,    ///< Y velocity
    CAP_VZ,    ///< Z velocity
    CAP_V,     ///< velocity


    CAP_ACC_X, ///< X acceleration
    CAP_ACC_Y, ///< Y acceleration
    CAP_ACC_Z, ///< Z acceleration
    CAP_ACC,   ///< Acceleration
    
    CAP_ROLL,  ///< Absolute roll
    CAP_PITCH, ///< Absolute pitch
    CAP_YAW,   ///< Absolute yaw

    CAP_ROLL_RATE,   ///< Roll rate
    CAP_PITCH_RATE,  ///< Pitch rate
    CAP_YAW_RATE,    ///< Yaw rate

    CAP_TEMPERATURE,  ///< Sensor temperature

    CAP_MAG        ///< Magnetic components
  } CapabilitiesID;
  
  std::bitset<32> capabilities; ///< Field for reading the sensor capabilities
  
  CINSData();
  ~CINSData();
  
  double odometer;     ///< Absolute positioning movement [m]
  
  double vx;           ///< Velocity towards the X axle in the selected reference system [m/s]
  double vy;           ///< Velocity along the Y axle in the selected reference system [m/s]
  double vz;           ///< Velocity along the Z axle in the selected reference system [m/s]
  double velocity;     ///< Velocity in the movement direction [m/s]

  double ax;           ///< Acceleration along the axle in the selected reference system [m/s^2]
  double ay;           ///< Acceleration along the axle in the selected reference system [m/s^2]
  double az;           ///< Acceleration along the axle in the selected reference system [m/s^2]
  double acceleration; ///< Acceleration in the movement direction [m/s^2]
    
  double roll;         ///< Tilt around the X axle [rad]
  double pitch;        ///< Tilt around the Y axle [rad]
  double yaw;          ///< Tilt around the Z axle [rad]

  double roll_rate;    ///< Angular velocity around the X axle [rad/s]
  double pitch_rate;   ///< Angular velocity around the Y axle [rad/s]
  double yaw_rate;     ///< Angular velocity around the > axle [rad/s]

  double mag_x;        ///< Magnetic component along the X axle [???]
  double mag_y;        ///< Magnetic component along the Y axle [???]

  float  temperature;  ///< Sensor temperature [deg C]

};

#pragma pack(pop)

/**
 * \brief Converts a CINSData to a formatted string
 * \param [in] ins_data The CINSData to be converted into string
 * \param [out] os A reference to the output string
 */
GOLD_DATA_EXPORT void ToString ( const CINSData& ins_data, std::string& os);

/**
 * \brief Converts string properly formatted into a CINSData
 * \param [in] os A const reference to the input string
 * \param [out] ins_data The CINSData to be converted from the string
 */
GOLD_DATA_EXPORT void FromString (const std::string& is, CINSData& ins_data);

} // namespace data

#endif //_INSDATA_H
