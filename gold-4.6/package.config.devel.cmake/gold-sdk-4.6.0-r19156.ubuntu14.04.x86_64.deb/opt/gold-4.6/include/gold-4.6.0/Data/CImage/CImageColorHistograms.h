#ifndef _CIMAGE_COLOR_HISTOGRAMS_H
#define _CIMAGE_COLOR_HISTOGRAMS_H

namespace cimage
{

// ////////////////////////////////////////////////////////////////////////////
// virtual CColorHistogram ColorHistogram(unsigned int Channel=0) const __attribute__((deprecated)) = 0;

// template <class S> void ColorHistogram(S* DstArray, unsigned long NumElements, unsigned int Channel=0, unsigned int Step=1) const {}

// color histogram for one channel
// CColorHistogram ColorHistogram(unsigned int Channel=0) const;

// c-style array: bring to CImage
// template <class S> void ColorHistogram(S* DstArray, unsigned long NumElements, unsigned int Channel=0, unsigned int Step=1) const;

// vertical and horizontal histogram
// template <class S> std::vector<S> VerticalHistogram() const;
// template <class S> std::vector<S> HorizontalHistogram() const;

// c-style array
// template <class S>
// void VerticalHistogram ( S* DstArray, unsigned long NumElements ) const;

// template <class S>
// void HorizontalHistogram ( S* DstArray, unsigned long NumElements ) const;
// ////////////////////////////////////////////////////////////////////////////

//// NOTE: check if using valarray bring performance improvements
//class CColorHistogram:
//	public std::vector<unsigned int>
//{
//public:
//	/** Default constructor: creates an empty histogram */
//	CColorHistogram() :
//			std::vector<unsigned int>()
//	{
//	}
//
//	/** Constructor accepting the initial histogram size */
//	CColorHistogram(unsigned int size) :
//			std::vector<unsigned int>(size)
//	{
//	}
//
//	/**
//	 * \brief Converts the current object into an array of numbers
//	 * \tparam S Type for the destination array
//	 * \param dst_vector Destination array;
//	 * \param num_elements size of the destination array
//	 */
//	template<class S>
//	void Convert(S* dst_vector, uint64_t& num_elements)
//	{
//		// std::map<unsigned char, unsigned int>::iterator ii
//		// TODO: check if numelements is correct!!
//		num_elements = 0uL;
//		for (typename std::vector<unsigned int>::iterator ii = (*this).begin();
//				ii != (*this).end(); ++ii, ++num_elements)
//			dst_vector[num_elements] = static_cast<S>(*ii);
//		num_elements = (*this).size();
//	}
//};

// // map
// template <class T, class Traits>
// CColorHistogram TImage<T, Traits>::ColorHistogram(unsigned int Channel) const
// {
//   CColorHistogram ColorHistogram(1<<PixelTraits::BitPerChannel());
// 
//   // compute the new one
//   const T *color =RLock();
//   for(unsigned int i=0; i<W()*H(); ++i, ++color)
//     ++ColorHistogram[*PixelTraits::GetChannel(color,  W(), Channel)];
//   UnLock();
// 
//   return ColorHistogram;
// }
// 
// // // vettore c-style
// // template <class T> template <class S>
// // void TImage<T, Traits>::ColorHistogram(S* DstArray, unsigned long NumElements, unsigned int Channel, unsigned int Step) const
// // {
// //   throw std::runtime_error("void TImage<T, Traits>::ColorHistogram(S* DstArray, unsigned long NumElements, unsigned int Channel, unsigned int Step) const is not implemented");
// // }
// 
// 
// /// TEMPLATE METHODS
// 
// template <> template <class S>
// void CImageMono::ColorHistogram(S* DstArray, unsigned long NumElements, unsigned int Channel, unsigned int Step) const
// {
//   if(NumElements<(chs()*1<<bpp()))
//     throw std::runtime_error("TImage::Histogram(double* DstArray, unsigned long NumElements) Array too small");
// 
//   // clean the destination
//   std::fill(DstArray, DstArray+NumElements, S());
// 
//   // compute the new one
//   const unsigned char *color = RLock();
//   for(unsigned int i=0; i<Area(); i+=Step, color+=Step)
//     ++DstArray[*color];
//   UnLock();
// }
// 
// 
// // template code
// template<> template <class S>
// void CImageRGB8::ColorHistogram(S* DstArray, unsigned long NumElements, unsigned int PixelChannel, unsigned int Step) const
// {
//   // TODO: 3 is the number of channel per pixel (cpp)
//   if(NumElements<(1u<<(bpp()/(3*chs()))))
//     throw std::runtime_error("TImage<RGB8>::Histogram(double* DstArray, unsigned long NumElements) Array too small");
// 
//   // clean the destination
//   std::fill(DstArray, DstArray+NumElements, S());
// 
//   const unsigned char *p=reinterpret_cast<const unsigned char *>(RLock())+PixelChannel;
// 
//   // compute the new one
//   for(unsigned int i=0; i<Area(); i+=Step, p+=Step*sizeof(cimage::RGB8))
//     ++DstArray[*p];
//   UnLock();
// 
// }
// 
// 
// template <> template <class S>
// void CImageBayerBGGR::ColorHistogram(S* DstArray, unsigned long NumElements, unsigned int Channel, unsigned int Step) const
// {
//   if(NumElements<(chs()*1<<bpp()))
//     throw std::runtime_error("TImage::Histogram(double* DstArray, unsigned long NumElements) Array too small");
// 
//   // clean the destination
//   // NOTE: questo non e' rigoroso, ma per ora facciamo cosi'
//   memset(DstArray, 0, NumElements*sizeof(S));
//   std::cout << "CImageBayerBGGR::ColorHistogram - fake algorithm" << std::endl;
// 
//   // compute the new one
//   const unsigned char *color = reinterpret_cast<const unsigned char *>(RLock());
//   for(unsigned int i=0; i<Area(); i+=Step, color+=Step)
//     ++DstArray[*color];
//   UnLock();
// }
// 
// 
// template <> template <class S>
// void CImageBayerGRBG::ColorHistogram(S* DstArray, unsigned long NumElements, unsigned int Channel, unsigned int Step) const
// {
//   if(NumElements<(chs()*1<<bpp()))
//     throw std::runtime_error("TImage::Histogram(double* DstArray, unsigned long NumElements) Array too small");
// 
//   // clean the destination
//   // NOTE: questo non e' rigoroso, ma per ora facciamo cosi'
//   memset(DstArray, 0, NumElements*sizeof(S));
//   std::cout << "CImageBayerGRBG::ColorHistogram - fake algorithm" << std::endl;
// 
//   // compute the new one
//   const unsigned char *color = reinterpret_cast<const unsigned char *>(RLock());
//   for(unsigned int i=0; i<Area(); i+=Step, color+=Step)
//     ++DstArray[*color];
//   UnLock();
// }
// 
// template <> template <class S>
// void CImageBayerRGGB::ColorHistogram(S* DstArray, unsigned long NumElements, unsigned int Channel, unsigned int Step) const
// {
//   if(NumElements<(chs()*1<<bpp()))
//     throw std::runtime_error("TImage::Histogram(double* DstArray, unsigned long NumElements) Array too small");
// 
//   // clean the destination
//   // NOTE: temporary solution
//   memset(DstArray, 0, NumElements*sizeof(S));
//   std::cout << "CImageBayerRGGB::ColorHistogram - fake algorithm" << std::endl;
//   // compute the new one
//   const unsigned char *color = reinterpret_cast<const unsigned char *>(RLock());
//   for(unsigned int i=0; i<Area(); i+=Step, color+=Step)
//     ++DstArray[*color];
// 
//   UnLock();
// 
// }
// 
// 
// template <> template <class S>
// void CImageBayerGBRG::ColorHistogram(S* DstArray, unsigned long NumElements, unsigned int Channel, unsigned int Step) const
// {
//   if(NumElements<(chs()*1<<bpp()))
//     throw std::runtime_error("TImage::Histogram(double* DstArray, unsigned long NumElements) Array too small");
// 
//   // clean the destination
//   // NOTE: temporary solution
//   memset(DstArray, 0, NumElements*sizeof(S));
//   std::cout << "CImageBayerGBRG::ColorHistogram - fake algorithm" << std::endl;
//   // compute the new one
//   const unsigned char *color = reinterpret_cast<const unsigned char *>(RLock());
//   for(unsigned int i=0; i<Area(); i+=Step, color+=Step)
//     ++DstArray[*color];
//   UnLock();
// }
// 

}

# endif // _CIMAGE_COLOR_HISTOGRAMS_H
