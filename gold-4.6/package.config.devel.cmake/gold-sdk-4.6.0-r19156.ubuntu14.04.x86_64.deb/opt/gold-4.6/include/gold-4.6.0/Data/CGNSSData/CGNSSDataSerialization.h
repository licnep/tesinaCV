/** \file CGNSSDataSerialization.h
 *  \brief Serialization for GNSSData
 *  \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _CGNSSDATA_SERIALIZATION_H
#define _CGNSSDATA_SERIALIZATION_H

#include <Data/Base/FormatsEnumerator.h>
#include <Data/CGNSSData/CGNSSData.h>

#include <boost/property_tree/ptree_fwd.hpp>
#include <boost/filesystem/path.hpp>

#include <iosfwd>
#include <string>

#include <Data/gold_data_export.h>


namespace data
{
  
/**
 * \brief Write a waypoint on a stream
 * \param [in] os destination output stream
 * \param [in] wp GNSS waypoint to be written on the stream
 * \return the ostream passed as argument for further writings
 */

GOLD_DATA_EXPORT std::ostream& operator << (std::ostream& os, const data::WayPoint& wp);

/**
 * \brief Read a waypoint from a stream
 * \param [in] is istream to be used to load the waypoint
 * \param [in] wp waypoint to be loaded
 * \return the istream passed as input for further readings
 */
GOLD_DATA_EXPORT std::istream& operator >> (std::istream& is, data::WayPoint& wp);  
  
/**
 * \brief namespace for classes, functions, and types for managing  CGNSSData
 */
namespace cgnss
{

/**
 * \brief namespace enclosing the CGNSSData serialization interface
 */
namespace serialization
{

/**
 * \brief Read a CGNSSData from a file
 * \param [in] file_name input file containing the CGNSSData to be de-serialized
 * \param [out] data the CGNSSData to be read from the stream
 * \return the number of bytes actually written on disk
 */GOLD_DATA_EXPORT uint64_t Load(const boost::filesystem::path& file_name, data::GNSS& data);

/**
 * \brief Write a CGNSSData on a file
 * \param [in] file_name name of the file were the CGNSSData will be serialized
 * \param [in] data the CGNSSData to be serialized
 * \return the number of bytes actually written on disk
 */GOLD_DATA_EXPORT uint64_t Save(const boost::filesystem::path& file_name, const data::GNSS& data);

/**
 * \brief Enumerator for the formats available
 */
typedef enum
{
	TXT, ///< string format
	BIN  ///< binary format
} FormatType;


/* * \brief Load a CGNSSData from a stream using the required format
 *
 * \param [in] is from the CGNSSData has to be loaded
 * \param [in] data CGNSSData to be loaded
 * \param [in] fmt FormatType format type to be used
 * \param [in] options property tree containing the loading options
 *
 */
// GOLD_DATA_EXPORT void Load( std::istream& is,
//                             CGNSSData& data,
//                             FormatType fmt,
//                             boost::property_tree::ptree& options );
/* * \brief Save a CGNSSData on a stream using the required format
 *
 * \param [in] os ostream were to save the CGNSSData
 * \param [in] data CGNSSData to be saved
 * \param [in] fmt FormatType format type be used
 * \param [in] options property tree containing the saving options
 *
 */
// GOLD_DATA_EXPORT void Save( const CGNSSData& data,
//                             std::ostream& os,
//                             FormatType fmt,
//                             const boost::property_tree::ptree& options );

/**
 * \brief Load a CGNSSData from a stream using the binary format
 * \param [in] is istream from the CGNSSData has to be loaded
 * \param [in] data CGNSSData to be loaded
 * \param [in] options property_tree containing the options to be used for loading
 */
GOLD_DATA_EXPORT void Load_BIN( std::istream& is, data::GNSS& data, boost::property_tree::ptree& options );

/**
 * \brief Load a CGNSSData from a stream using the text format
 * \param [in] is istream from the packet has to be loaded
 * \param [in] data packet to be loaded
 * \param [in] options property_tree containing the options to be used for loading
 */
GOLD_DATA_EXPORT void Load_TXT( std::istream& is, data::GNSS& data, boost::property_tree::ptree& options );

/**
 * \brief Save a CGNSSData on a stream using the binary format
 * \param [in] os ostream were to save the packet
 * \param [in] data packet to be saved
 * \param [in] options property_tree containing the saving options
 */
GOLD_DATA_EXPORT void Save_BIN( const data::GNSS& data, std::ostream& os, const boost::property_tree::ptree& options );

/**
 * \brief Save a CGNSSData on a stream using the text format
 * \param [in] os ostream were to save the packet
 * \param [in] data packet to be saved
 * \param [in] options property_tree containing the saving options
 */
GOLD_DATA_EXPORT void Save_TXT( const data::GNSS& data, std::ostream& os, const boost::property_tree::ptree& options );

/**
 * \brief TFormatEnumerator containing the formats supported for serializing CGNSSData
 */
GOLD_DATA_EXPORT data::TFormatEnumerator<data::GNSS>& FormatEnumerator();

} // serialization
} // cgnss
} // namespace data


#endif // _CGNSSDATA_SERIALIZATION_H

