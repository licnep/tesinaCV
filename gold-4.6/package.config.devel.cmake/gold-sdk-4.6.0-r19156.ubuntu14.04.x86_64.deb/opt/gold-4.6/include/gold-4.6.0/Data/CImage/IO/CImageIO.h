/**
 * \file CImageIO.h
 * \brief Non intrusive interface for CImage serialization in still images format
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

// TODO: rename as CImageSerialization

#ifndef _IMAGE_IO_H
#define _IMAGE_IO_H

#include <fstream>
#include <boost/filesystem/path.hpp>
#include <boost/property_tree/ptree_fwd.hpp>

#include "CImageConfig.h"
#include <Data/CImage/CImage.h>
#include <Data/Base/FormatsEnumerator.h>
#include <Data/gold_data_export.h>



namespace cimage
{
  /** \brief Short definition for the type used for containing options. \see boost::property_tre::ptree */
  typedef boost::property_tree::ptree OptionsType;

/**
 * \brief Creates a new CImage from an existing file saved in one of the supported format
 * \param file_name full path of the file to be loaded
 * \return a shared pointer to a new CImage filled with the content stored in the file
   \code
   CImage::SharedPtrType p_image=CreateFromFile("/my/image/path/myImage.pgm");
   \endcode
 */
GOLD_DATA_EXPORT SharedPtrType CreateFromFile(const std::string& file_name);

// TODO: add a template version for typed images


/**
 * \brief Loads the content of a CImage, allocated by the user, from a file
 * \param url full path of the file to be loaded. The file must be recorded in one of the supported formats
 * \param image modifiable reference user allocated image
 * \param options OptionsType with the format-specific options to be used for loading the file
 */
GOLD_DATA_EXPORT void Load ( boost::filesystem::path url, CImage& image, const OptionsType& options = OptionsType() );

/**
 * \brief Save the content of a CImage in a file using the format specified by the extension and the specified options
 * \param url full path of the file to be saved
 * \param image const reference to the image to be saved
 * \param options OptionsType with the format-specific options to be used for saving
 */
GOLD_DATA_EXPORT void Save( boost::filesystem::path url, const CImage& image, const OptionsType& options = OptionsType());

/**
 * \brief Loads the content of a CImage, allocated by the user, from an open stream using the requested format and options
 * \param in The input stream where the image has to be loaded
 * \param image The image to be filled with the content read from the stream
 * \param format A string identifier of the format to be used to load the image
 * \param options OptionsType filled with the options to be used to load the image
 */
GOLD_DATA_EXPORT void Load(std::istream& in, CImage& image, const std::string& format, const OptionsType& options = OptionsType());

/**
 * \brief Save the content of a CImage, allocated by the user, to an open stream using the requested format and options
 * \param out The output stream where the image has to be saved
 * \param image const reference to the image to be saved
 * \param format A string identifier of the format to be used to save the image
 * \param options OptionsType filled with the options to be used to save the image
 */
GOLD_DATA_EXPORT void Save(std::ostream& out, const CImage& image, const std::string& format, const OptionsType& options = OptionsType());

/**
 * \brief Returns a reference to the one and only instance (Singleton) of the CImage TFormatEnumerator
 *
 * The TFormatEnumerator provides all the information concerning the supported formats
 * Available formats are dynamics since their availability depends on the platform and on the compiling options.
 * The only way of knowing what format can be used and what options they support is query the TFormatEnumerator
 * TFormatEnumerator also allow to add user defined formats to those supported by the system.
 */
GOLD_DATA_EXPORT data::TFormatEnumerator<CImage>& FormatEnumerator();

} // namespace cimage

#endif

