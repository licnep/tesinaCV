/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2009                  *
 *                                                                    *
 *       http://www.ARGO.ce.unipr.it    (PGX July 2005)               *
 *                                                                    *
 **********************************************************************/

/**
 * \file CImage/Definitions.h
 * \brief Definitions used by the CImage library
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 *
 */

#ifndef _DEFINITIONS_H
#define _DEFINITIONS_H

#include <Data/gold_data_export.h>
#include <stdint.h>

namespace cimage
{
typedef int32_t PosType; ///< Type for the position of a pixel inside an image (integer)
typedef double SubPixelPosType; ///< Type for the position of a pixel inside an image (with subpixel accuracy)
typedef uint32_t SizeType;           ///< Type for the size of an image
typedef uint64_t AreaType; ///< Type for pixel counters (variables for iterating over the area)
typedef uint64_t VolumeType; ///< Type for pixel counters (variables for iterating over the volume)
typedef uint32_t BufferSizeType; ///< Type for byte counters (variables for iterating at byte level over a image buffer)
typedef uint64_t GUIDType; ///< Type for the unique identifier of an image

/** \brief structure for describing the pixel coordinates */
template<class T>
struct TPixelCoordType
{
	T u, v, h;  ///< Pixel position
	uint8_t ch; ///< Channel
};

typedef TPixelCoordType<PosType> PixelCoordType; ///< Short type for pixel coordinates (integer)
typedef TPixelCoordType<SubPixelPosType> SubPixelCoordType; ///< Short type for pixel coordinates (subpixel precision)

/**
 * \brief structure for describing the coverage type of an operation
 */
typedef enum COVERAGES
{
	PARTIAL_COVERAGE, ///< The operation requires full coverage: all the pixel in the image are written
	FULL_COVERAGE ///< The operation requires a partial coverage: only a subset of the image will be written
} COVERAGE;

/**
 * \brief Angular units
 */
typedef enum ANGLE_UNITS
{
	DEGREES, ///< Degrees. One loop belongs to 0-360 [deg]
	RADIANTS ///< Radiants. Belongs to 0, 2*PI
} ANGLE_UNIT;

} // namespace cimage

#endif

