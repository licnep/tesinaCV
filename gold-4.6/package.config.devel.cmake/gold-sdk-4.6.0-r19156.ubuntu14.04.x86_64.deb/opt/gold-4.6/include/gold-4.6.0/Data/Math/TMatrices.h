/**
 * \file Data/Math/TMatrices.h
 * \brief Declarations and functions for matrix management
 * \author Paolo Grisleri <grisleri@ce.unipr.it>, Paolo Medici <medici@ce.unipr.it>
 **/
#ifndef _T_MATRIX_H
#define _T_MATRIX_H

#include <iostream>
#include <iomanip>
#include <Data/Math/Points.h>

#include <Libs/Compatibility/DeclSpecs.h>
// #include <Data/gold_data_export.h> // GOLD_DATA_EXPORT

namespace math
{

/**
 * \brief Generic template for modeling a matrix.
 * 
 * \code
 * // The following code declares a 3x4 matrix of integers
 * TMatrix<int, 3, 4> int_matrix;
 *
 * // The following code declares a 3x3 matrix of floats
 * TMatrix<float, 3> float_matrix;
 * \endcode
 *
 * The advantages of this class are the following:
 * - light footprint: a TMatrix<double,3,3> stores exactly 9 doubles and has the same features and performance of a C style array.
 * - compile time type-checking
 *
 * \tparam T type of the matrix elements
 * \tparam R number of rows
 * \tparam C number of columns. Default=R
 **/
template<typename T, unsigned int R, unsigned int C = R>
class DECLSPEC_EXPORT TMatrix
{
protected:
	T M[C * R];  ///< buffer storing the matrix elements
public:
	/** \brief Alias for the element type */
	typedef T Type;

	/** \brief Alias for the complementary minor matrix*/
	typedef TMatrix<T, C - 1, R - 1> MinorType;

	/** \brief true if the the class represents a square matrix */
	static const bool is_square = (C == R);

	// some simple traits
	static const unsigned int columns = C; //< Number of columns
	static const unsigned int rows = R; //< Number of rows

public:
	/** \brief Default constructor */
	TMatrix()
	{
	}

	/**
	 * \brief Constructor from a C-style array
	 * \param src C-style array containing the matrix to use to initialize this class
	 * \see Import
	 */
	template<class X>
	explicit TMatrix(const X* src)
	{
		Import(src);
	}

	/**
	 * \brief Returns the i-th element of the array
	 */
	inline T& operator[](unsigned int i)
	{
		return M[i];
	}

	/**
	 * \brief Returns the i-th element of the array (const version)
	 */
	inline const T& operator[](unsigned int i) const
	{
		return M[i];
	}

	/**
	 * \brief Returns the element stored in a specific row and column
	 * \param r row of the element to be returned. Belongs to [0, R-1]
	 * \param c column of the element to be returned. Belongs to [0, C-1]
	 *
	 * \code
	 * TMatrix<int, 3, 4> M;
	 * int value = M(1,2); // value is set to the value of the element at the second row, third column
	 * \endcode
	 */
	inline T& operator()(unsigned int r, unsigned int c)
	{
		return M[c + r * C];
	}

	/**
	 * \brief Returns the element stored in a specific row and column (const version)
	 * \param r row of the element to be returned. Belongs to [0, R-1]
	 * \param c column of the element to be returned. Belongs to [0, C-1]
	 *
	 * \code
	 * TMatrix<int, 3, 4> M;
	 * int value = M(1,2); // value is set to the value of the element at the second row, third column
	 * \endcode
	 */
	inline const T& operator()(unsigned int r, unsigned int c) const
	{
		return M[c + r * C];
	}


	/**
	 * \brief Assigns the internal elements from a C-style array
	 *
	 * For a 3x3 Matrix, the array is supposed to be organized as follows:
	 * {a11, a12, a13, a21, a22, a23, a31, a32, a33}
	 */
	template<class X>
	inline void Import(const X* src)
	{
		for (unsigned int i = 0; i < C * R; i++)
			M[i] = src[i];
	}

	/**
	 * \brief Fills an external C-style array with the values of the internal elements
	 *
	 * For a 3x3 Matrix, the array will be written as follows:
	 * {a11, a12, a13, a21, a22, a23, a31, a32, a33}
	 */
	template<class X>
	inline void Export(X* dst) const
	{
		for (unsigned int i = 0; i < C * R; i++)
			dst[i] = M[i];
	}

	/**
	 * \brief Returns a pointer to the first element of the internal array
	 */
	inline T* get()
	{
		return M;
	}

	/**
	 * \brief Returns a pointer to the first element of the internal array (const version)
	 */
	inline const T* get() const
	{
		return M;
	}

	/**
	 * \brief Fills the internal elements as an identity matrix
	 *
	 * Also working for rectangular matrix such as affine transformations
	 * \returns the current matrix.
	 */
	TMatrix<T, R, C>& SetIdentity()
	{
		for (unsigned int j = 0; j < R; j++)
			for (unsigned int i = 0; i < C; i++)
				M[i + j * C] = (i == j) ? T(1) : T(0);
		return *this;
	}

	/**
	 *   \brief Returns the complementary minor of the current matrix.
	 *
	 *   It is used to compute the determinant.
	 *   \return Returns the matrix without the row J and the column I passed as argument
	 *
	 */
	MinorType Minor(unsigned int J, unsigned int I) const
	{
		MinorType out;
		T *ptr =& out[0];
		for (unsigned int j = 0; j < R; j++)
			for (unsigned int i = 0; i < C; i++)
			{
				if ((i != I) && (j != J))
					*ptr++ = M[i + j * C];
			}
		return out;
	}

	/**
	 * \brief compute the determinant of the current matrix
	 * \code
	 * M.det();
	 * \endcode
	 *
	 **/
	T det() const;

	/**
	 * \brief Fills @a d with the inverse of the current matrix
	 * \param d a square matrix filled in output with the inverse matrix of current one
	 *
	 * \code
	 * A.invert(A_inv);
	 * \endcode
	 *
	 * \note Number of rows must be equal to the number of columns.
	 * \note Only 1x1 2x2 3x3 inverse calculation is currently implemented
	 * \return true when the matrix is invertible false otherwise (BEWARE that false actually is never returned!)
	 */
	bool invert(TMatrix<T, C, C>& d) const;

	/**
	 * \brief Unary minus: changes the sign of every element in the current matrix
	 */
	TMatrix<T, R, C> operator -() const
	{
		TMatrix<T, R, C> O;
		for (unsigned int i = 0; i < R * C; i++)
			O[i] = -M[i];
		return O;
	}
};

/**
 * \brief Compute the inverse of a 1x1 matrix
 * \note The other specializations are in TMatrices.hxx
 */
template<>
inline bool TMatrix<double, 1, 1>::invert(TMatrix<double, 1, 1>& d) const
{
	d[0] = 1.0 / M[0];
	return true;
}

/**
 * \brief Returns the determinant of a 1x1 matrix
 */
template<>
inline double TMatrix<double, 1u, 1u>::det() const
{
	return M[0];
}

/**
 * \brief Returns the determinant of a 2x2 matrix
 */
template<>
inline double TMatrix<double, 2u, 2u>::det() const
{
	return M[0] * M[3] - M[1] * M[2];
}

/**
 * \brief Returns the determinant of a 3x3 matrix
 */
template<>
inline double TMatrix<double, 3, 3>::det() const
{
	return M[0] * (M[4] * M[8] - M[5] * M[7])
			+ M[1] * (M[6] * M[5] - M[3] * M[8])
			+ M[2] * (M[3] * M[7] - M[4] * M[6]);
}

/**
 * \brief  Returns the determinant of an RxC matrix (using the Laplace development)
 */
template<typename T, unsigned int R, unsigned int C>
T TMatrix<T, R, C>::det() const
{
	T acc = 0;
	for (unsigned int j = 0; j < R; j++)
		acc += ((j&  1) ? T(-1) : T(1)) * M[j * C] * Minor(j, 0).det();
	return acc;
}

/**
 * \brief Returns the identity matrix (do not modify the content of the current matrix)
 * \code
 *  Matrix<double,3,3> I = Identity<double,3>();
 * \endcode
 */
template<typename T, unsigned int R>
TMatrix<T, R, R> Identity(void)
{
	TMatrix<T, R, R> out;
	return out.Identity();
}

/**
 * \brief Returns the transposed of the current matrix (do not modify the content of the current matrix)
 * \code
 * TMatrix<double,4,3> R;
 * TMatrix<double,3,4> = Traspose( R );
 * \endcode
 */
template<typename T, unsigned int R, unsigned int C>
TMatrix<T, C, R> Traspose(const TMatrix<T, R, C>&  in)
{
	TMatrix<T, C, R> out;
	for (unsigned int j = 0; j < R; j++)
		for (unsigned int i = 0; i < C; i++)
			out(i, j) = in(j, i);    // i:colonna, j:riga
	return out;
}

/**
 * \brief Write the content of the current matrix on a std::ostream
 */
template<typename T, unsigned int R, unsigned int C>
inline std::ostream& operator<<(std::ostream& o, const TMatrix<T, R, C>&  in)
{
	for (unsigned int j = 0; j < R; j++)
	{
		o << "| ";
		for (unsigned int i = 0; i < C; i++)
			o << std::setw(11) << in(j, i) << ' ';
		o << "|\n";
	}
	return o;
}

/**
 * \brief Compute the matrix multiplication and store the result in a user allocated matrix $out=a*b$
 * The resulting matrix has size: AR x AC x BR x BC = AR x BC
 */
template<typename T, unsigned int N, unsigned int AR, unsigned int BC>
void mul(TMatrix<T, AR, BC>& out,
		const TMatrix<T, AR, N>& a,
		const TMatrix<T, N, BC>& b)
{
	for (unsigned int i = 0; i < AR; i++)
		for (unsigned int j = 0; j < BC; j++)
		{
			T sum = T(0);
			for (unsigned int k = 0; k < N; k++)
				sum += a(i, k) * b(k, j);
			out(i, j) = sum;
		}
}

/**
 * \brief Returns the result of the matrix multiplication
 * \code
 * M = A * B;
 * \endcode
 **/
template<typename T, unsigned int N, unsigned int AR, unsigned int BC>
TMatrix<T, AR, BC> operator *(
		const TMatrix<T, AR, N>& a,
		const TMatrix<T, N, BC>& b)
{
	TMatrix<T, AR, BC> out;
	for (unsigned int i = 0; i < AR; i++)
		for (unsigned int j = 0; j < BC; j++)
		{
			T sum = T(0);
			for (unsigned int k = 0; k < N; k++)
				sum += a(i, k) * b(k, j);
			out(i, j) = sum;
		}
	return out;
}

/**
 * \brief Returns the result of the multiplication between a 3x3 matrix and a Point3
 */
template<typename T>
Point3<T> operator *(const TMatrix<T, 3, 3>&  a, const Point3<T>&  b)
{
	return Point3<T>(a[0] * b.x + a[1] * b.y + a[2] * b.z,
			a[3] * b.x + a[4] * b.y + a[5] * b.z,
			a[6] * b.x + a[7] * b.y + a[8] * b.z);
}


/**
 * \brief Returns the result of the multiplication between a 3x3 matrix and a Point3, transposed
 */
template<typename T>
Point3<T> TransposeMul(const TMatrix<T, 3, 3>&  a, const Point3<T>&  b)
{
	return Point3<T>(a[0] * b.x + a[3] * b.y + a[6] * b.z,
			a[1] * b.x + a[4] * b.y + a[7] * b.z,
			a[2] * b.x + a[5] * b.y + a[8] * b.z);
}

/**
 * \brief Returns the Cross Product Matrix associated to cross product of v x
 */
template<typename T>
TMatrix<T, 3, 3> CrossProductMatrix(const Point3<T>&  v)
{
	TMatrix<T, 3, 3> m;
	m[0] = 0.0;
	m[1] = -v.z;
	m[2] = v.y;
	m[3] = v.z;
	m[4] = 0.0;
	m[5] = -v.x;
	m[6] = -v.y;
	m[7] = v.x;
	m[8] = 0.0;
	return m;
}

/**
 * \brief Extract a Point3d from a 3x3 matrix
 */
template<int col>
inline Point3d Column(const TMatrix<double, 3, 3>&  M)
{
	return Point3d(M(0, col), M(1, col), M(2, col));
}

/**
 * \brief Set a 3x3 matrix column using a Point3d
 */
template<int col>
inline void Column(TMatrix<double, 3, 3>&  M, const Point3d& v)
{
	M(0, col) = v.x;
	M(1, col) = v.y;
	M(2, col) = v.z;
}

/**
 * \brief Returns the sum of two matrices: $S=A+B$
 */
template<typename T, unsigned int R, unsigned int C>
TMatrix<T, R, C> operator +(
		const TMatrix<T, R, C>&  a,
		const TMatrix<T, R, C>&  b)
{
	TMatrix<T, R, C> out;
	for (unsigned int i = 0; i < R; i++)
		for (unsigned int j = 0; j < C; j++)
		{
			out(i, j) = a(i, j) + b(i, j);
		}
	return out;
}

/**
 * \brief Returns the difference of two matrices: $S=A-B$
 */
template<typename T, unsigned int R, unsigned int C>
TMatrix<T, R, C> operator -(
		const TMatrix<T, R, C>&  a,
		const TMatrix<T, R, C>&  b)
{
	TMatrix<T, R, C> out;
	for (unsigned int i = 0; i < R; i++)
		for (unsigned int j = 0; j < C; j++)
		{
			out(i, j) = a(i, j) - b(i, j);
		}
	return out;
}

/**
 * \brief Returns the result of the multiplication between a matrix and a scalar (modifies the argument)
 */
template<typename T, unsigned int R, unsigned int C>
TMatrix<T, R, C>& operator *=(TMatrix<T, R, C>& M, T f)
{
	for (unsigned int i = 0; i < R * C; i++)
		M[i] *= f;
	return M;
}

/**
 * \brief Returns the result of the multiplication between a matrix and a scalar (do not modify the argument)
 */
template<typename T, unsigned int R, unsigned int C>
TMatrix<T, R, C> operator *(const TMatrix<T, R, C>&  a, T b)
{
	TMatrix<T, R, C> out;
	for (unsigned int i = 0; i < R; i++)
		for (unsigned int j = 0; j < C; j++)
		{
			out(i, j) = a(i, j) * b;
		}
	return out;
}

} // namespace math

#endif
