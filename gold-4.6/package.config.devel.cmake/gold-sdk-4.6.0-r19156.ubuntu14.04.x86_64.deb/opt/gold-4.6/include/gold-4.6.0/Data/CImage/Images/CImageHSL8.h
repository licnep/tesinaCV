/**
 * \file CImageHSL8.h
 * \brief Class for modeling a Hue, Saturation, Lightness (HSL) 3-channels, 8-bits unsigned integer image
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Pietro Versari \<versari@ce.unipr.it\>
 */

#ifndef _CIMAGE_HSL8_H
#define _CIMAGE_HSL8_H

#include <Data/CImage/Pixels/HSL8.h>
#include <Data/CImage/TImage.h>

namespace cimage
{
  /** \brief Type for declaring a Hue, Saturation, Lightness (HSL) 3-channels, 8-bits unsigned integer image */
  typedef TImage<HSL8> CImageHSL8;
  
  /** \brief Alias type for declaring a Hue, Saturation, Lightness (HSL) 3-channels, 8-bits unsigned integer image */
  typedef CImageHSL8 CImageHSL8u;
}

#endif

