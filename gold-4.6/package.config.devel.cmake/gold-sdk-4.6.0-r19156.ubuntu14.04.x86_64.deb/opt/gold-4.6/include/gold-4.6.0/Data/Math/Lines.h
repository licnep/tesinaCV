/**
 * \file Data/Math/Lines.h
 * \brief Data and functions for modeling lines
 * \author Paolo Grisleri \grisleri@ce.unipr.it\>, Paolo Medici (medici@ce.unipr.it)
 */

#ifndef _LINES_H
#define _LINES_H

#include <iostream>
#include <cmath>
#include <Data/Math/Points.h>

namespace math
{

/**
 * \brief Generic class modeling a 2-D line with equation: \f$ y = mx + q \f$
 * \note Line2 has singularities for vertical lines. Use Line3 where possible
 */
template<class T>
struct Line2
{
	T q; ///< Angular factor
	T m; ///< Offset

	/** \brief Default constructor. Initialize the coefficients with the default constructor of T() */
	Line2() : q(T()), m(T())
	{
	}

	/** \brief constructor taking m and q separately 
    * \param [in] _m slope coefficient of the line 
    * \param [in] _q the Y intercept of the line 
    */
	Line2(T _m, T _q) :
			m(_m), q(_q)
	{
	}

	/** \brief Constructor accepting two points. The constructed line will pass in these two points 
    * \param [in] z first point
    * \param [in] w second point
    */
	Line2(const Point2<T>& z, const Point2<T>& w)
	{
		T b = z.x - w.x;
		if (b == 0)
		{
			// not valid: vertical line
			m = 0;
			q = 0;
			return;
		}

		m = (z.y - w.y) / b;         // -a/b
		q = (z.x * w.y - z.y * w.x) / b; // -c/b
	}

	/** \brief Returns the y coordinate associated to the corresponding  to x coordinate
    * \param [in]  x  x coordinate of the points
    * \return the y coordinate associated to the x coordinate
    */
	inline T operator()(T x) const
	{
		return m * x + q;
	}

	/** \brief Translate the line moving the point (0,0) in (dx,dy)    
    * \param [in]  dx  x coordinate displacement
    * \param [in]  dy  y coordinate displacement
    */
	void traslate(T dx, T dy)
	{
		q += dy - m * dx;
	}

};

/** \brief Short type for a line of float */
typedef Line2<float> Line2f;

/** \brief Short type for a line of double */
typedef Line2<double> Line2d;

/** \brief operator for writing the coefficients of a Line2 on a stream */
template<class T>
inline std::ostream& operator<<(std::ostream & out, const Line2<T> & l)
{
	out << "m:" << l.m << ", q:" << l.q;
	return out;
}

/**
 * \brief Generic class modeling a 2-D line with equation: \f$ ax + by + c = 0 \f$ without vertical singularities as Line2
 * \tparam T type used for the coefficients
 *
 * \note Line3 could be ambiguous: this is still a 2-D line. A 3-D vector should use Point3
 * \note This object can also be used as equation for a 3-D plane
 *  \f$ aX + bY + cZ = 0 \f$ is the plane intersecting the plane Z = 1 in the lane defined by the equation.
 * \note An object Line3 cannot be drawn directly on the display. Use the function line3d_to_screen or clip_line3
 * to transform this object in a segment that can be drawn using functions such as CWindow::DrawLine.
 */
template<class T>
struct Line3
{
	/** \brief parameters of equation \f$ ax + by + c = 0 \f$ */
	T a, b, c;

	/** \brief Default constructor. Initialize the coefficients with the default constructor of T() */
	Line3() : a(T()), b(T()), c(T())
	{
	}

	/** \brief Constructor accepting the coefficients a, b, and c */
	Line3(T _a, T _b, T _c) :
			a(_a), b(_b), c(_c)
	{
	}

	/** \brief Constructor accepting 2 Points2: the constructed line will pass in these two points */
	Line3(const Point2<T> & z, const Point2<T>& w) :
			a(w.y - z.y), b(z.x - w.x), c(z.y * w.x - z.x * w.y)
	{
	}

	/** \brief Returns \f$ x \f$ from given \f$ y \f$ (\f$ x = X(y) \f$) */
	T X(T y) const
	{
		return -(b * y + c) / a;
	}

	/** \brief Returns \f$ y \f$ from given \f$ x \f$ (\f$ y = Y(x) \f$) */
	T Y(T x) const
	{
		return -(a * x + c) / b;
	}

	/** \brief Returns the projection of the Point2 passed as argument on the line */
	Point2<T> project(const Point2<T>& p) const
	{
		T a2 = a * a, b2 = b * b, ab = a * b;
		double d = 1.0 / (a2 + b2);
		return Point2<T>((-a * c + b2 * p.x - ab * p.y) * d,
				(-b * c + a2 * p.y - ab * p.x) * d);
	}

	/**
	 * \brief When \f$ a^2 + b^2>0 \f$: normalize the coefficients
	 * \f$ (a^2 + b^2 = 1) \f$ and returns true; otherwise return false
	 */
	bool normalize()
	{
		T m = a * a + b * b;
		if (m > 0.0)
		{
			T d = T(1.0) / sqrt(m);
			a *= d;
			b *= d;
			c *= d;
			return true;
		}
		return false;
	}

	/**
	 * \brief Returns the distance between the line and a point passed as argument.
	 * The distance is oriented thus can be negative
	 */
	inline T distance(const Point2<T> & pt) const
	{
		return (pt.x * a + pt.y * b + c) / sqrt(a * a + b * b);
	}

	/** \brief Returns the square distance between point and the line */
	inline T distance2(const Point2<T> & pt) const
	{
		T f = (pt.x * a + pt.y * b + c);
		return f * f / (a * a + b * b);
	}

	/** \brief Translate the line moving the point (0,0) to (dx,dy) */
	void traslate(T dx, T dy)
	{
		c -= dx * a + dy * b;
	}
};

/** \brief Short type for a Line3 of float. Note that is a 2-D line even if the name contains an ambiguous '3' */
typedef Line3<float> Line3f;

/** \brief Short type for a Line3 of double. Note that is a 2-D line even if the name contains an ambiguous '3' */
typedef Line3<double> Line3d;

/** \brief operator for writing the coefficients of a Line3 on a stream */
template<class T>
inline std::ostream& operator<<(std::ostream & o, const Line3<T> & l)
{
	o << "a:" << l.a << ", b:" << l.b << ", c:" << l.c;
	return o;
}

/**
 * \brief 2-D line expressed in polar coordinates
 *
 * \f$ \rho = x \cos \theta + y \sin \theta \f$
 * \note angles are expressed in [rad]
 *
 * \code
 * const Line3d Line = PolarLine<double>(rho, theta)
 * \endcode
 *
 * \note This class can be used for converting \f$ \rho \f$ e \f$ \theta \f$
 *       in a Line3 and compute the line-to-point distance.
 * \tparam T type used for the internal representation of the angles
 */
template<typename T = double>
struct PolarLine
{
	T rho;    ///< Module of the segment perpendicular to the line
	T theta;  ///< Angle of the line [rad]

	// some typedef as local aliases that could be turned into possible traits
	typedef Point2<T> point_t;  ///< Alias for Point2<T>
	typedef Line2<T> line2_t;   ///< Alias for Line2<T>
	typedef Line3<T> line3_t;   ///< Alias for Line3<T>

	/** \brief Default constructor. Initialize the coefficients with the default constructor of T() */
	PolarLine() : rho(T()),theta(T())
	{
	}

	/**
	 * \brief Constructor accepting
	 * \param _rho Distance of the line from the origin (module of the segment perpendicular to the line)
	 * \param _theta Angle of the line [rad]
	 */
	PolarLine(T _rho, T _theta) :
			rho(_rho), theta(_theta)
	{
	}

	// TODO constructor from Line2 and Line3

	/**
	 * \brief Returns the X coordinate corresponding to a certain Y coordinate passed as argument
	 * \note This function is pretty slow due to the fairly high amount of computation need
	 * A good work around is to cast this line to a Line3 or a Line2
	 */
	inline T X(T y) const
	{
		return (rho - y * sin(theta)) / cos(theta);
	}

	/**
	 * \brief Returns the Y coordinate corresponding to a certain X coordinate passed as argument
	 * \note This function is pretty slow due to the fairly high amount of computation need
	 * A good work around is to cast this line to a Line3 or a Line2
	 */
	inline T Y(T x) const
	{
		return (rho - x * cos(theta)) / sin(theta);
	}

	/**
	 * \brief Returns the distance between the line and a point passed as argument.
	 * The distance is oriented thus can be negative
	 */
	inline T distance(const point_t & pt) const
	{
		return pt.x * cos(theta) + pt.y * sin(theta) - rho;
	}

	/** \brief Convert the current object in a Line3 */
	inline operator line3_t() const
	{
		return line3_t(cos(theta), sin(theta), -rho);
	}

	/**
	 * \brief Convert the current object in a Line3
	 * \note Line2 has singularities for vertical lines. Use Line3 instead
	 */
	inline operator line2_t() const
	{
		return line2_t(-T(1) / tan(theta), rho / sin(theta));
	}

};

/** \brief operator for writing the coefficients of a Line2 on a stream */
template<class T>
inline std::ostream& operator<<(std::ostream & o, const PolarLine<T> & l)
{
	o << "rho:" << l.rho << ", theta:" << l.theta << "rad";
	return o;
}

}

#endif

