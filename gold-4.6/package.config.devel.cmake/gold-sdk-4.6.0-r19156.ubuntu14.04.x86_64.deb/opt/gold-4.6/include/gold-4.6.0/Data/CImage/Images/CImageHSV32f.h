/**
 * \file CImageHSL32f.h
 * \brief Class for modeling a Hue, Saturation, Value (HSL) 3-channels, 32-bits float image
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Pietro Versari \<versari@ce.unipr.it\>
 */

#ifndef _CIMAGE_HSV32F_H
#define _CIMAGE_HSV32F_H

#include <Data/CImage/Pixels/HSV32f.h>
#include <Data/CImage/TImage.h>

namespace cimage
{
  /** \brief Type for declaring a Hue, Saturation, Value (HSV) 3-channels, 32-bits float image */
  typedef TImage<HSV32f> CImageHSV32f;
  
  /** \brief Alias type for declaring a Hue, Saturation, Value (HSV) 3-channels, 32-bits float image */
  typedef CImageHSV32f CImageHSVf;
}

#endif
