/**
 * \file CImageHSV8.h
 * \brief Class for modeling a Hue, Saturation, Value (HSV) 3-channels, 8-bits unsigned integer image
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Pietro Versari \<versari@ce.unipr.it\>
 */

#ifndef _CIMAGE_HSV8_H
#define _CIMAGE_HSV8_H

#include <Data/CImage/Pixels/HSV8.h>
#include <Data/CImage/TImage.h>

namespace cimage
{
  /** \brief Type for declaring a Hue, Saturation, Value (HSV) 3-channels, 8-bits unsigned integer image */
  typedef TImage<HSV8> CImageHSV8;
  
  /** \brief Alias type for declaring a Hue, Saturation, Value (HSV) 3-channels, 8-bits unsigned integer image */
  typedef CImageHSV8 CImageHSV8u;
}

#endif

