/**
 * \file CScan.h
 * \brief Classes for modeling high level data produced from a LaserScanner
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _CSCAN_H
#define _CSCAN_H

#include <vector>

#include <stdint.h>

#include <Libs/Time/TimeUtils.h>

#include <Data/Math/TMatrices.h>
#include <Data/Math/Points.h>
#include <Processing/Math/Transformation.h>

#include <Data/gold_data_export.h>

namespace data
{

/**
 * \brief Class for modeling a single echo
 *
 * An echo is derived from Point3d, and offers additional member variables
 * for modeling other physical quantities estimated from a radar sensor
 *
 * sizeof(CScanEcho) = 48 bytes (on a 64 bit machine)
 */
struct GOLD_DATA_EXPORT CScanEcho :
  public math::Point3d
{
  CScanEcho();

  // NOTE: Leght==Duration if unit is arbitrary
  double Width;    ///< Echo Length [m] (0.0 = INVALID)

  /** \brief Enumerator for the Echo classification */
  typedef enum
  {
    INFINITE_=-2,  ///< The echo comes from an infinite distance
    INVALID=-1,    ///< The echo is invalid
    NORMAL,        ///< The echo is normal
    RAIN,          ///< The echo has been reflected by a rain drop
    GROUND,        ///< The echo has been reflected from the ground
    DIRT,          ///< The echo comes from some dirt on the scanner glass
    TRANSPARENT_   ///< The echo comes from a transparent object
  } ClassificationID;

  ClassificationID Classification;   ///< Pulse classification

  /** \brief operator = for copying CScanEcho */
  const math::Point3d& operator=(const math::Point3d& point);

  uint8_t  DeviceID;  ///< Device Identifier of the sensor that captured this echo
  uint16_t Layer;     ///< Number of the layer the echo belong to
  uint16_t Echo;      ///< number of the echo in a pulse. A pulse may have more than one echo, such as for rain drops.
};

/**
 * \brief Class for modeling a scan captured from a laserscanner
 *
 * Data from laserscanners are usually organized as follows:
 * - a scan has a fixed number of layers
 * - a layer may contains a variable number of pulses: depending on the framed scene the number of pulses may vary
 * - a pulse may contains several echoes
 *
 * Some laserscanner do not have a constant horizontal angular separation
 * some others also do not have a constant vertical angular separation
 * This means that the angular resolution is variable with the angle, this is
 * the reason why it is not stored here and point position is stored instead.
 *
 * Following these rules, the fastest way for representing CScan is an unordered collection of CScanEcho
 * A CScan is basically a class containing a point cloud std::vector<CScanEcho>
 * not necessarily sorted in some way, with some additional feature such as the
 * timestamp of the scan, captured with the data.
 */
// TODO: find a set of functions for operating on this structure
// Ideas:
// * operations on filtered vectors
//   + faster
//   - requires conversion operations
//   ? is it more convenient copy the data or work on array of pointers


class GOLD_DATA_EXPORT CScan
{
  public:
    CScan(uint8_t layers=0, uint16_t pulses=0, uint8_t echoes=0);

    vl::chrono::TimeType TimeStamp_Start; ///< Timestamp of the beginning of the scan
    vl::chrono::TimeType TimeStamp_End;   ///< Timestamp of the beginning of the scan

    // Range covered by the sensor
    double Angle_Start; ///< Field of view: angle where the scan starts [rad]. The X axle is 0.0, the Y axle is PI/2
    double Angle_End;   ///< Field of view: angle where the scan ends [rad]. The X axle is 0.0, the Y axle is PI/2

    /** \brief Type for the scan:  contains plan CScanEcho */
    typedef std::vector<CScanEcho>  ScanType;

    /** \brief Type for a modifiable view of the scan: contains pointers to CScanEcho */
    typedef std::vector<CScanEcho*> ViewType;


    /** \brief Type for a read-only view of the scan: contains pointers to CScanEcho */
    typedef std::vector<const CScanEcho*> ConstViewType;

    /** \brief Local alias for CScanEcho */
    typedef CScanEcho EchoType;

    ScanType Data;
};

/** \brief Type for rotation and scaling matrix */
typedef math::TMatrix<double, 3,3> TransformationType;

/** \brief Affine matrix: for rotation and translations */
typedef math::TMatrix<double, 3,4> TransformationType4;

/** \brief Translate all the dst points (echoes) using offset */
  GOLD_DATA_EXPORT void Translate( CScan& dst, const math::Point3d& offsets );

  /**
   * \brief Transform current scan \a scan in \a dst scan data applying @a T transformation
   * \see Transformation.h
   */
  GOLD_DATA_EXPORT void Transform( const CScan& scan, CScan&dst,  const TransformationType4 & T );

  /** \brief Returns the 3x3 rotation matrix using a Point3d of angles */
  GOLD_DATA_EXPORT TransformationType Rotation( const math::Point3d& angles );

  /** \brief Apply a regular 3x3 transformation to any point of Scan */
  GOLD_DATA_EXPORT void Apply( CScan& dst, const math::TMatrix<double, 3,3> & t );

  /** \brief Apply an affine 3x4 transformation to any point of Scan */
  GOLD_DATA_EXPORT void Apply( CScan& dst, const math::TMatrix<double, 3,4> & t );

  /**
   * \brief Returns the number of layers in the CScan::ScanType
   * Complexity: O(N)
   */
  GOLD_DATA_EXPORT uint16_t Max_Layer(const CScan::ScanType& scan);

  /**
   * \brief Returns the maximum number of echoes (maximum echo depth) in the CScan::ScanType
   * Complexity: O(N)
   */
  GOLD_DATA_EXPORT uint16_t Max_Echo(const CScan::ScanType& scan);


  /**
   * \brief Returns number of echoes for a specified layer in a CScan::ScanType
   * Complexity: O(N)
   */
  GOLD_DATA_EXPORT uint32_t Count_EchoesPerLayer(CScan::ScanType& scan, uint16_t layer);

  /**
   * \brief Converts the content of a CScan::ScanType into a CScan::ViewType
   *
   * Filters can be applied to a CScan::ViewType
   */
  GOLD_DATA_EXPORT void GenerateView( CScan::ScanType& data, CScan::ViewType& scan );


  /** \brief Filter for extracting a view containing the required layer */
  GOLD_DATA_EXPORT void Layer(CScan::ViewType& scan, unsigned int layer_num, CScan::ViewType& layer);

  // functors

  /** \brief return true when the argument is not classified as CScanEcho::INVALID */
  inline bool IsValid(const CScanEcho& echo) { return echo.Classification!=CScanEcho::INVALID; }

  /** \brief return true when the argument is classified as CScanEcho::INVALID */
  inline bool IsInvalid(const CScanEcho& echo) { return echo.Classification==CScanEcho::INVALID; }

  /** \brief compares two echoes and returns true when the layer of the first is less than the layer of the second argument */
  inline bool Echo_LayerLess(const CScanEcho& e1, const CScanEcho& e2) { return e1.Layer<e2.Layer; }

  /** \brief compares two echoes and returns true when the Echo number of the first is less than the Echo number of the second argument */
  inline bool Echo_EchoLess(const CScanEcho& e1, const CScanEcho& e2) { return e1.Echo<e2.Echo; }

  /**
   * \brief Functor for filtering a certain layer
   */
  class GOLD_DATA_EXPORT LayerFilter
  {
      unsigned int m_Layer;
    public:
      LayerFilter(unsigned int Layer) : m_Layer(Layer){}
      bool operator()(const CScanEcho* e) {return e->Layer==m_Layer; }
      bool operator()(const CScanEcho& e) {return e.Layer==m_Layer; }
  };

  /**
   * \brief Functor for filtering out a certain layer
   */
  class GOLD_DATA_EXPORT NotLayerFilter
  {
      unsigned int m_Layer;
    public:
      NotLayerFilter(unsigned int Layer) : m_Layer(Layer){}
      bool operator()(const CScanEcho* e) { return e->Layer!=m_Layer; }
      bool operator()(const CScanEcho& e) { return e.Layer!=m_Layer; }
  };

  /**
   * \brief Functor for filtering a certain Echo number
   */
  class GOLD_DATA_EXPORT  EchoFilter
  {
      unsigned int m_Echo;
    public:
      EchoFilter(unsigned int Echo) : m_Echo(Echo){}
      bool operator()(const CScanEcho* e) {return e->Echo==m_Echo; }
      bool operator()(const CScanEcho& e) {return e.Echo==m_Echo; }
  };


  /**
   * \brief Functor for filtering out a certain Echo number
   */
  class GOLD_DATA_EXPORT NotEchoFilter
  {
      unsigned int m_Echo;
    public:
      NotEchoFilter(unsigned int Echo) : m_Echo(Echo){}
      bool operator()(const CScanEcho* e) {return e->Echo!=m_Echo; }
      bool operator()(const CScanEcho& e) {return e.Echo!=m_Echo; }
  };

} // namespace data

/**
  * \brief STL extension/specialization for std::swap
  */
namespace std
{
  template <>
  inline void swap<data::CScan>(data::CScan& a, data::CScan& b)
  {
    std::swap(a.TimeStamp_Start, b.TimeStamp_Start);
    std::swap(a.TimeStamp_End, b.TimeStamp_End);
    std::swap(a.Angle_Start, b.Angle_Start);
    std::swap(a.Angle_End, b.Angle_End);
    std::swap(a.Data, b.Data);
  }
}


// TODO functions for computing HAngle,VAngle, Distance from the CScanEcho
#endif //_CSCAN_H
