/**
 * \file CImageBGRA8.h
 * \brief Class for modeling a Blue, Green, Red, Alpha (BGRA) 4-channels, 8-bits image
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Paolo Zani (zani@ce.unipr.it)
 * \date 2007-04-17
 */

#ifndef _CIMAGEBGRA8_H
#define _CIMAGEBGRA8_H

#include <Data/CImage/TImage.h>
#include <Data/CImage/Pixels/BGRA8.h>

namespace cimage
{
  /** \brief Type for declaring a Blue, Greem Red, Alpha (BGRA) 4-channels, 8-bits image */
  typedef TImage<BGRA8> CImageBGRA8;

  /** \brief Alias type for declaring a Blue, Greem Red, Alpha (BGRA) 4-channels, 8-bits image */
  typedef CImageBGRA8 CImageBGRA;
}

#endif //_CIMAGEBGRA8_H
