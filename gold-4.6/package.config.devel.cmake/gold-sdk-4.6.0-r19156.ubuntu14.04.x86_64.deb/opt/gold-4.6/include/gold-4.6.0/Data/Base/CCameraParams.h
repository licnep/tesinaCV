/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2007                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file CCameraParams.h
 * @brief Template classes for modeling camera parameters
 * @author Paolo Grisleri (grisleri@ce.unipr.it), Paolo Medici (medici@ce.unipr.it), Paolo Zani (zani@ce.unipr.it)
 */
#ifndef _CCAMERA_PARAMS_H
#define _CCAMERA_PARAMS_H

#include <cmath>

#include <Data/Base/SensorParams.h>
#include <Data/gold_data_export.h>

/** \brief Classes and function for modeling devices and sensors */
namespace dev
{


/**
 * \brief Template for collecting extrinsic parameters: position and orientation
 * \tparam L type for the position parameters. Default: double
 * \tparam L type for the orientation parameters. Default: double
 */
template<class L = double, class A = double> struct TExtrinsicParams: public TPosition<L>,
		public TOrientation<A>
{
	typedef TPosition<L> P;    ///< position type
	typedef TOrientation<A> O; ///< orientation type
};

/**
 * \brief Structure for modeling camera parameters
 *
 * \tparam FloatType type for extrinsic parameters
 * \tparam UIntType type to be used ad unsigned integer
 */
template<typename FloatType = double, typename UIntType = unsigned int>
struct TCameraParams: public TExtrinsicParams<FloatType, FloatType>
{
	/** \brief Local type for representing floating point numbers */
	typedef FloatType floating_type;

	/** \brief Local type for representing unsigned integer numbers */
	typedef UIntType uinteger_type;

	/** \brief Local type for extrinsic parameter */
	typedef TExtrinsicParams<FloatType, FloatType> P;

	// intrinsic parameters

	/** \brief Sensor size [pixels] */
	UIntType width, height;

	/**
	 * \brief Optical center
	 *
	 * These values represents the coordinates of the optical center.
	 * Please consider that these might not correspond to the geometric center.
	 */
	FloatType u0, v0;

	/**
	 * \brief Focal length [pixel units]
	 *
	 */
	FloatType ku, kv;

	/**
	 * \brief Set ku and ku values
	 */
	void Set_FocalLengthInPixel(FloatType _ku, FloatType _kv)
	{
		ku = _ku;
		kv = _kv;

		// TODO: compute alpha and beta from these
	}

	/**
	 * \brief operator for printing the content on a std::ostream
	 */
	friend std::ostream& operator <<(std::ostream& os, const TCameraParams& a)
	{
		os << "K: (" << a.ku << ',' << a.kv << "), O: (" << a.u0 << ',' << a.v0
				<< "), S: (" << a.width << ',' << a.height << "), T: (" << a.x
				<< ',' << a.y << ',' << a.z << "), Y: " << a.yaw << ", P: "
				<< a.pitch << ", R: " << a.roll;
		return os;
	}

	/**
	 * \brief Checks the identity between two TCameraParams
	 */
	friend
	bool operator ==(const TCameraParams& a, const TCameraParams& b)
	{
		return (a.width == b.width) && (a.height == b.height)
				&&
				//  (a.alpha == b.alpha) && (a.beta == b.beta) &&
				(a.ku == b.ku) && (a.kv == b.kv) && (a.x == b.x) && (a.y == b.y)
				&& (a.z == b.z) && (a.yaw == b.yaw) && (a.pitch == b.pitch)
				&& (a.roll == b.roll) && (a.u0 == b.u0) && (a.v0 == b.v0);
	}

	/**
	 * \brief Returns true when two TCameraParams are different
	 */
	friend
	bool operator !=(const TCameraParams& a, const TCameraParams& b)
	{
		return !(a == b);
	}

	/**
	 * \brief Recalculate parameters after a resampling
	 */
	void SetGeometry(UIntType w, UIntType h)
	{
		// center is scaled proportionally
		if (u0 != 0.0)
			u0 *= (double) w / (double) width;
		else
			u0 = w / FloatType(2.0);

		if (v0 != 0.0)
			v0 *= (double) h / (double) height;
		else
			v0 = h / FloatType(2.0);

		// Ku and Kv are adjusted as well
		ku *= (double) w / (double) width;
		kv *= (double) h / (double) height;

		width = w;
		height = h;
	}

    /**
     * \brief Recalculate parameters after a cropping
     * @param x0,y0 top left corner (included)
     * @param x1,y1 bottom right corner (included)
     */
    void SetROI(int x0, int y0, int x1, int y1)
    {
      // ku and kv do not change
      u0 -= x0;
      v0 -= y0;
      width = x1 - x0 + 1;
      height = y1 - y0 + 1;
    }
    
	/**
	 * \brief Returns the vanishing point Y coordinate (x -> inf)
	 * @note a PerspectiveMapping / InversePerspectiveMapping can return the same information
	 */
	inline FloatType getHorizonY(void) const
	{
		// kv = v0 / tan(beta); tan(beta) = v0 / kv;
		return v0 - tan(P::O::pitch) * kv;
	}

	/**
	 * \brief Returns the vanishing point X coordinate (x -> inf)
	 * @note a PerspectiveMapping / InversePerspectiveMapping can return the same information
	 */
	inline FloatType getHorizonX(void) const
	{
		// ku = u0 / tan(alpha); tan(alpha) = u0 / ku;
		return u0 - ku * tan(P::O::yaw) / cos(P::O::pitch);
	}

	/**
	 * \brief Extract pitch using @a y coordinate of vanishing point and beta and v0
	 */
	inline FloatType ExtractPitch(FloatType y) const
	{
		return atan((v0 - y) / kv);
	}

	/**
	 * \brief Extract pitch using @a x coordinate of vanishing point and alpha and u0 and pitch
	 */
	inline FloatType ExtractYaw(FloatType x) const
	{
		return atan(cos(P::O::pitch) * (u0 - x) / ku);
	}

	/**
	 * Compute the pitch angle using @a y coordinate of vanishing point
	 */
	inline void UpdatePitch(FloatType y)
	{
		P::O::pitch = ExtractPitch(y);
	}
};

/** Typedef for simplifying the writing of user code */
typedef TCameraParams<double, unsigned int> CameraParams;

/** Typedef for simplifying the writing of user code */
typedef TCameraParams<double, unsigned int> CameraParams_t;

} // namespace dev




#endif
