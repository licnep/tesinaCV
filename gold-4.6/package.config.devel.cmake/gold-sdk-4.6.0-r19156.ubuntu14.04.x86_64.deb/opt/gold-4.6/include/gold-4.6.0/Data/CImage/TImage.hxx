// This is the TImage Implementation file
#ifndef _TIMAGE_HXX
#define _TIMAGE_HXX

#undef VERBOSITY_DEBUG
#define VERBOSITY_DEBUG 0
// #include <Libs/Logger/Log.h>

#include <Data/CImage/TImage.h>

namespace cimage
{
// template <typename T> GOLD_DATA_EXPORT Loki::TypeInfo  TImage<T>::m_type_info = typeid(TImage<T>);

// ()
template <typename T>
TImage<T>::TImage()
{
    __ctor();
}

template <typename T>
TImage<T>::~TImage() {}

// (Size)
template <typename T>
TImage<T>::TImage ( SizeType width, SizeType height)
{
    static_cast<Geometry&> ( *this ) = Geometry ( width, height );
    __ctor();
}


// Copy constructor
template <typename T>
TImage<T>::TImage ( const TImage& image )
{
    static_cast<Geometry&> ( *this ) = static_cast<const Geometry&> ( image );
    __ctor();
    static_cast<CImage&>(*this)=static_cast<const CImage&>(image);
}

// Assignment operator
// Example: TImage = TImage
template <typename T>
TImage<T>& TImage<T>::operator= ( const TImage& image )
{
    static_cast<CImage&> ( *this ) = static_cast<const CImage&> ( image );
    return *this;
}

// Assignment operator
// Example: TImage = CImage
template <typename T>
TImage<T>& TImage<T>::operator= ( const CImage& image )
{
    // images must be of the same type
    assert(TypeInfo()==image.TypeInfo());

    static_cast<CImage&> ( *this ) = image;
    return *this;
}

template <typename T>
const CImage::Type& TImage<T>::TypeInfo() const
{
    return type_info();
}

template <typename T>
const CImage::Type& TImage<T>::type_info()
{
  // static CImage::Type ti(typeid(TImage<T>));
  static CImage::Type ti=impl::get_guid();
  return ti;
}

// delegated ctor
template <typename T>
void TImage<T>::__ctor()
{
    using impl::BufferType;

    // assigns the image buffer and update the cache
    __set_buffer ( __ctor_buffer() );

    // fills the geometry fields using PixelTraits
    m_chs=PixelTraits::Channels();
    m_channel_names= PixelTraits::ChNames();
    m_bpc=PixelTraits::BitPerChannel();
    m_Bpc=PixelTraits::BytePerChannel();
    m_bpp=PixelTraits::BitPerPixel();
    m_Bpp=PixelTraits::BytePerPixel();
}

template <typename T>
impl::BufferType* TImage<T>::__ctor_buffer() const
{
    return new impl::BufferType ( PixelTraits::StoredSize()*Area() );
}

} // namespace cimage


#endif // _TIMAGE_HXX
