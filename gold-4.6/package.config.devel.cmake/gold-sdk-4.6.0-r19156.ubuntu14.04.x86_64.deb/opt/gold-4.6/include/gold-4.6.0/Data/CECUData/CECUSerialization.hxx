#ifndef _CECU_SERIALIZATION_HXX
#define _CECU_SERIALIZATION_HXX

/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8
// Serialization support
#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>

#include <boost/archive/text_oarchive.hpp>
#include <boost/archive/text_iarchive.hpp>

#include <boost/serialization/split_free.hpp>
#include <boost/serialization/array.hpp>
#include <boost/serialization/vector.hpp>

#include <boost/date_time/gregorian/greg_serialize.hpp>
#include <boost/date_time/posix_time/time_serialize.hpp>

#include <boost/serialization/array.hpp>
#include <stdint.h>

#include <boost/math/constants/constants.hpp>

// #include <Compatibility/vector_serialization.hxx>

namespace data  
{

class CObjectDetected;

/**
 * \brief Function requested by boost serialization for serializing a CObjectDetected
 * friend class boost::serialization::access;
 * When the class Archive corresponds to an output archive, the
 * & operator is defined similar to <<.  Likewise, when the class Archive
 * is a type of input archive the & operator is defined similar to >>.
 */
template<class Archive>
void serialize(Archive & ar, CObjectDetected& od, unsigned int version)
{
  ar & od.x;
  ar & od.y;
  ar & od.z;
  
  ar & od.ECUID;
  ar & od.ObstacleID;
  
  ar & od.MotionClassification;
  ar & od.LeadingClassification;
  ar & od.ObjectClassification;
  ar & od.MarkingClassification;;
  ar & od.LanePos;
  
  ar & od.singlePoint;
  ar & od.vectorOfPoint;

  ar & od.points;
  ar & od.angles;
  ar & od.other_values;
  
  ar & od.width;
  ar & od.height;
  ar & od.length;
  
  ar & od.speed;
  ar & od.speed_x;
  ar & od.speed_y;
  ar & od.acceleration;
  ar & od.acceleration_x;
  ar & od.acceleration_y;
}

class CECUData;

/**
 * \brief Function requested by boost serialization for serializing a CObjectDetected
 * friend class boost::serialization::access;
 * When the class Archive corresponds to an output archive, the
 * & operator is defined similar to <<.  Likewise, when the class Archive
 * is a type of input archive the & operator is defined similar to >>.
 */
template<class Archive>
void serialize(Archive& ar, CECUData& Computation, unsigned int version)
{
    ar & Computation.TimeStamp_Start;
    ar & Computation.TimeStamp_End;

    ar & Computation.Angle_Start;
    ar & Computation.Angle_End;
    ar & Computation.Distance_Start;
    ar & Computation.Distance_End;

    ar & Computation.Cycle_Count;
    
    ar & Computation.ECUID;
    ar & Computation.Status;
    ar & Computation.SystemMode;

    ar & Computation.ValidObjectCounter;
    ar & Computation.ObjectData;
}

} // namespace data  

#endif // _CSCAN_SERIALIZATION_HXX
