/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file CImageRGB16.h
 * \brief Class for modeling a Red, Green, Blue, 3-channels, 16-bits unsigned per channel image
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Gabriele Camellini (cgabri@ce.unipr.it)
 * \date 2012-04-06
 */

#ifndef _CIMAGE_RGB16_H
#define _CIMAGE_RGB16_H

#include <Data/CImage/TImage.h>
#include <Data/CImage/Pixels/RGB16.h>

namespace cimage
{
/** \brief Type for declaring an a Red, Green, Blue, 3-channels, 16-bits unsigned per channel image */
typedef TImage<RGB16> CImageRGB16;
}

#endif // _CIMAGE_RGB16_H
