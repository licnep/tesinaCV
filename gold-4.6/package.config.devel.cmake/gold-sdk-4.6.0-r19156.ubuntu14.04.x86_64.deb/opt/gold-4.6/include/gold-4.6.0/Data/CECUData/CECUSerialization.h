/** \file CECUSerialization.h
 *  \brief Serialization for CECUData
 *  \author Luca Gatti \<lucag@ce.unipr.it\>
 */

#ifndef _CECUDATA_SERIALIZATION_H
#define _CECUDATA_SERIALIZATION_H

/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8

#include <boost/filesystem/path.hpp>
#include <boost/property_tree/ptree_fwd.hpp>

#include <Data/Base/FormatsEnumerator.h>

#include <Data/gold_data_export.h>

namespace data  
{
  
/**
 * \brief namespace for classes, functions, and types for managing  CECUData
 */
namespace cecu
{

/**
 * \brief namespace enclosing the CECUData serialization interface
 */
namespace serialization
{
/**
 * \brief Read a CECUData from a file
 * \param [in] file_name input file containing the CECUData to be de-serialized
 * \param [out] data the CECUData to be read from the stream
 * \return the number of bytes actually written on disk
 */GOLD_DATA_EXPORT uint64_t Load(const boost::filesystem::path& file_name, CECUData& data);

/**
 * \brief Write a CECUData on a file
 * \param [in] file_name name of the file were the CECUData will be serialized
 * \param [in] data the CECUData to be serialized
 * \return the number of bytes actually written on disk
 */GOLD_DATA_EXPORT uint64_t Save(const boost::filesystem::path& file_name, const CECUData& data);

/**
 * \brief Enumerator for the formats available
 */
typedef enum
{
	TXT, ///< string format
	BIN  ///< binary format
} FormatType;


/* * \brief Load a CECUData from a stream using the required format
 *
 * @param [in] is from the CECUData has to be loaded
 * @param [in] data CECUData to be loaded
 * @param [in] fmt FormatType format type to be used
 * @param [in] options property tree containing the loading options
 *
 */
// GOLD_DATA_EXPORT void Load( std::istream& is,
//                             CECUData& data,
//                             FormatType fmt,
//                             boost::property_tree::ptree& options );
/* * \brief Save a CECUData on a stream using the required format
 *
 * @param [in] os ostream were to save the CECUData
 * @param [in] data CECUData to be saved
 * @param [in] fmt FormatType format type be used
 * @param [in] options property tree containing the saving options
 *
 */
// GOLD_DATA_EXPORT void Save( const CECUData& data,
//                             std::ostream& os,
//                             FormatType fmt,
//                             const boost::property_tree::ptree& options );

/**
 * \brief Load a CECUData from a stream using the binary format
 * @param [in] is istream from the CECUData has to be loaded
 * @param [in] data CECUData to be loaded
 * @param [in] options property_tree containing the options to be used for loading
 */
GOLD_DATA_EXPORT void Load_BIN( std::istream& is, CECUData& data, boost::property_tree::ptree& options );

/**
 * \brief Load a CECUData from a stream using the text format
 * @param [in] is istream from the packet has to be loaded
 * @param [in] data packet to be loaded
 * @param [in] options property_tree containing the options to be used for loading
 */
GOLD_DATA_EXPORT void Load_TXT( std::istream& is, CECUData& data, boost::property_tree::ptree& options );

/**
 * \brief Save a CECUData on a stream using the binary format
 * @param [in] os ostream were to save the packet
 * @param [in] data packet to be saved
 * @param [in] options property_tree containing the saving options
 */
GOLD_DATA_EXPORT void Save_BIN( const CECUData& data, std::ostream& os, const boost::property_tree::ptree& options );

/**
 * \brief Save a CECUData on a stream using the text format
 * @param [in] os ostream were to save the packet
 * @param [in] data packet to be saved
 * @param [in] options property_tree containing the saving options
 */
GOLD_DATA_EXPORT void Save_TXT( const CECUData& data, std::ostream& os, const boost::property_tree::ptree& options );

/**
 * \brief TFormatEnumerator containing the formats supported for serializing CECUData
 */
GOLD_DATA_EXPORT data::TFormatEnumerator<CECUData>& FormatEnumerator();

} // serialization
} // cecu
} // namespace data  



// Serialization support
/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8

#endif
