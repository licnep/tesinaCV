/**
 * \file Pixels/HSL32f.h
 * \brief Definitions for modeling HSL, 3 channels, 32-bit float pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Pietro Versari \<versari@ce.unipr.it\>
 */

#ifndef _HSL32F_H
#define _HSL32F_H

#include <Data/CImage/Pixels/THSL.h>

namespace cimage
{
/**
 * \brief Definition for HSL32f.
 * This pixel support Hue, Saturation and Lightness if three separated 32-bit float channels
 * \see THSL
 */
typedef THSL<float> HSL32f;

/**
 * \brief Definition for HSLf.
 * This pixel support Hue, Saturation and Lightness if three separated 32-bit float channels
 * \see TBGRA
 */
typedef THSL<float> HSLf;

}

#endif // _HSL32F_H
