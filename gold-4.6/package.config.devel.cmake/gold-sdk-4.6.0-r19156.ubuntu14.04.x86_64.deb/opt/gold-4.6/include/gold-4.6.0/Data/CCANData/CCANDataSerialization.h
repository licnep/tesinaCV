/**
 * @file CCANDataSerialization.h
 * @brief Serialization for CAN packets
 * @authors Paolo Grisleri (grisleri@ce.unipr.it)
 */
#ifndef _CCANDATA_SERIALIZATION_H
#define _CCANDATA_SERIALIZATION_H


#include <Data/Base/FormatsEnumerator.h>
#include <Data/CCANData/CANData.h>

#include <boost/property_tree/ptree_fwd.hpp>
#include <iosfwd>

#include <Data/gold_data_export.h>


namespace data
{
  
// TODO: stream functions are slow, add string io functions

/**
 * \brief Write a can packet on a stream
 * \param [out] ostr output stream were the packet will be serialized
 * \param [in] can_data the packet to be serialized
 */
GOLD_DATA_EXPORT std::ostream& operator << (std::ostream& ostr, const data::CCANData& packet);

/**
 * \brief Read a can packet from a stream
 * \param [in] istr input stream from were the packet will be de-serialized
 * \param [in] can_data the packet to be read from the stream
 */
GOLD_DATA_EXPORT std::istream& operator >> (std::istream& istr, data::CCANData& packet);

/**
 * \brief namespace for classes, functions, and types for managing can packets serialization
 */
namespace ccan
{

/**
 * \brief namespace enclosing the can packets serialization interface
 */
namespace serialization
{

/**
 * \brief Enumerator for the formats available
 */
typedef enum
{
	TXT, ///< string format
	BIN  ///< binary format
} FormatType;


/**
 * \brief Load a CAN packet from a stream using the required format
 * @param [in] is from the packet has to be loaded
 * @param [in] packet packet to be loaded
 * @param [in] fmt FormatType format type to be used
 * @param [in] options property tree containing the loading options
 */
// GOLD_DATA_EXPORT void Load( std::istream& is,
//                             data::CCANData& packet,
//                             FormatType fmt,
//                             boost::property_tree::ptree& options );

/**
 * \brief Save a CAN packet on a stream using the required format
 * @param [in] os ostream were to save the packet
 * @param [in] packet packet to be saved
 * @param [in] fmt FormatType format type be used
 * @param [in] options property tree containing the saving options
 */
// GOLD_DATA_EXPORT void Save( const CCANData& packet,
//                             std::ostream& os,
//                             FormatType fmt,
//                             const boost::property_tree::ptree& options );

/**
 * \brief Load a CAN packet from a stream using the binary format
 * @param [in] is istream from the packet has to be loaded
 * @param [in] packet packet to be loaded
 * @param [in] options property_tree containing the options to be used for loading
 */
GOLD_DATA_EXPORT void Load_BIN( std::istream& is, data::CCANData& packet, boost::property_tree::ptree& options );

/**
 * \brief Load a CAN packet from a stream using the text format
 * @param [in] is istream from the packet has to be loaded
 * @param [in] packet packet to be loaded
 * @param [in] options property_tree containing the options to be used for loading
 */
GOLD_DATA_EXPORT void Load_TXT( std::istream& is, data::CCANData& packet, boost::property_tree::ptree& options );

/**
 * \brief Save a CAN packet on a stream using the binary format
 * @param [in] os ostream were to save the packet
 * @param [in] packet packet to be saved
 * @param [in] options property_tree containing the saving options
 */
GOLD_DATA_EXPORT void Save_BIN( const data::CCANData& packet, std::ostream& os, const boost::property_tree::ptree& options );

/**
 * \brief Save a CAN packet on a stream using the text format
 * @param [in] os ostream were to save the packet
 * @param [in] packet packet to be saved
 * @param [in] options property_tree containing the saving options
 */
GOLD_DATA_EXPORT void Save_TXT( const data::CCANData& packet, std::ostream& os, const boost::property_tree::ptree& options );

/**
 * \brief TFormatEnumerator containing the formats supported for serializing CAN packets
 */
GOLD_DATA_EXPORT data::TFormatEnumerator<CCANData>& FormatEnumerator();

} // namespace serialization
} // namespace ccan
} // namespace data


#endif // _CCANDATA_SERIALIZATION_H

