/**
 * \file Data/Math/Quadratics.h
 * \brief Data and functions for modeling quadratics curves
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Paolo Medici (medici@ce.unipr.it)
 */
#ifndef _QUADRATIC_H
#define _QUADRATIC_H

#include <Data/Math/Points.h>
#include <utility>

namespace math
{

/**
 * \brief Generic class modeling a quadratic curve equation: \f$ y = a x ^2 + b x + c \f$
 */
template<class T>
struct Quadratic
{

	T a; ///< Parameter
	T b; ///< Parameter
	T c; ///< Parameter

	/** \brief Reset the curve  to a flat line (degenerate case) of equation: \f$ y = t \f$ */
	void reset(T t = T(0))
	{
		a = b = (0);
		c = t;
	}

	/**
	 * \brief Set to a line passing for 2 points (degenerate case)
	 * \params [in] x1 x coordinate of the point 1
	 * \params [in] y1 x coordinate of the point 1
	 * \params [in] x2 x coordinate of the point 2
	 * \params [in] y2 x coordinate of the point 2
	 */
	void set_line(T x1, T y1, T x2, T y2)
	{
		T den = x1 - x2;
		a = T(0);
		b = (y1 - y2) / den;
		c = (x1 * y2 - y1 * x2) / den;
	}

	/**
	 * \brief Set to a quadratic curve passing for 3 points
	 * \params [in] x1 x coordinate of the point 1
	 * \params [in] y1 x coordinate of the point 1
	 * \params [in] x2 x coordinate of the point 2
	 * \params [in] y2 x coordinate of the point 2
	 * \params [in] x3 x coordinate of the point 3
	 * \params [in] y3 x coordinate of the point 3
	 */
	bool set_quadratic(T x1, T y1, T x2, T y2, T x3, T y3)
	{
		/*
		 double det = (x1 - x2)*(x1 - x3)*(x3 - x2);
		 a = (x1*(y2 - y3) + x2*(y3 - y1) + x3*(y1 - y2)) / det ;
		 b = ((y2 - y3)*x1*x1 + (y3 - y1)*x2*x2 + (y1 - y2)*x3*x3) / det;
		 c = ((x2*y3 - x3*y2)*x1*x1 + x1*(y2*x3*x3 - y3*x2*x2) + x2*x3*y1*(x2 - x3)) / det;
		 */
		/*
		 a =  ((y2-y1)*(x1-x3) + (y3-y1)*(x2-x1))/((x1-x3)*(x2*x2-x1*x1) + (x2-x1)*(x3*x3-x1*x1));
		 b =  ((y2 - y1) - a *(x2*x2 - x1*x1)) / (x2-x1);
		 c = y1 - a * x1 * x1 - b * x1;
		 */

		a = (x1 * (y2 - y3) + y1 * (x3 - x2) + x2 * y3 - x3 * y2)
				/ ((x2 - x1) * (x3 - x1) * (x3 - x2));
		b = ((y3 - y1) / (x3 - x1)) - a * (x3 + x1);
		c = y1 - a * x1 * x1 - b * x1;
		return true;
	}

	/**
	 * \brief Set the quadratic using point at specific X:
	 * \param y1 value associated to X = -1
	 * \param y2 value associated to X = 0
	 * \param y3 value associated to X = +1
	 * \note this is effective and the fastest implementation
	 */
	void set_quadratic(T y1, T y2, T y3)
	{
		a = ((y3 + y1) / T(2)) - y2;
		b = ((y3 - y1) / T(2));
		c = y2;
	}

	/**
	 * \brief Returns the result of equation: \f$ y = a x^2 + b x + c \f$
	 */
	double operator()(T x) const
	{
		// 2 multiplications a and 2 sums (0 powers)
		return (a * x + b) * x + c;
	}

	////////////////// PROPOSAL ////////////////////////
	// A method returning a std::pair<T, T> with the solutions.
	// That are the x corresponding to the intersections with y=0
	// the 2 real solutions of quadratic equation
	// std::pair<T,T> solution() const
	// {
	// T d = sqrt(b*b - T(4) * a * c);
	// T ib = 1.0 / (T(2) * b);
	// return std::pair<T,T>( (-b - d) * ib, (-b + d) * ib);
	//  }
	////////////////////////////////////////////////////

	/**
	 * \brief Returns the X corresponding to the max/min of quadratic equation
	 */
	T vertex() const
	{
		return -b / (T(2) * a);
	}

};

/**
 * \brief Generic 2-D quadratic curve
 * TODO: find another name
 */
typedef Quadratic<double> Quadratic1d;

/**
 * \brief Class modeling a generic quadratic curve in 2 variables of equation: \f$ x = x(t), y = y(t) \f$
 * \tparam T type for the internal quadratic representation
 */
template<class T>
struct Quadratic2
{
	/** \brief local type for the point used */
	typedef Point2<T> point_t;

	Quadratic<T> x, y;

	/** \brief Set the curve to a flat plane (degenerate case) */
	void set_const(const point_t &p)
	{
		x.set_const(p.x);
		y.set_const(p.y);
	}

	/** \brief cast operator for getting the two values \f$ [x(t), y(t)] \f$ */
	inline point_t operator ()(T t)
	{
		return point_t(x(t), y(t));
	}
};

/**
 * \brief A function \f$ R^2 -> R^2 \f$ of equation: \f$ x = x(t), y = y(t) \f$
 * TODO change name
 */
typedef Quadratic2<double> Quadratic2d;

} // namespace math

#endif

