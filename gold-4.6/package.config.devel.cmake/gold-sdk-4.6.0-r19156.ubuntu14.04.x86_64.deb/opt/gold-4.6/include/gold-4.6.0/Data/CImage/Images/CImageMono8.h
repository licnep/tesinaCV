/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.ARGO.ce.unipr.it    (PGX July 2005)               *
 *                                                                    *
 **********************************************************************/

/**
 * \file CImageMono8.h
 * \brief Class for modeling an 8-bit monochrome image
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 * \date 2006-05-27
 */

#ifndef _CIMAGE_MONO8_H
#define _CIMAGE_MONO8_H

#include <Data/CImage/TImage.h>
#include <Data/CImage/Pixels/Mono8.h>

namespace cimage
{
  /** \brief Type for declaring an 8-bit monochrome image */
  typedef TImage<cimage::Mono8> CImageMono;

  /** \brief Alias type for declaring an 8-bit monochrome image */
  typedef CImageMono CImageGray;

  /** \brief Alias type for declaring an 8-bit monochrome image */
  typedef CImageMono CImageGrey;

  /** \brief Alias type for declaring an 8-bit monochrome image */
  typedef CImageMono CImageMono8;
}

#endif

