/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/

/**
 * \file CImageMono8o127.h
 * \brief Class for modeling an 8-bit monochrome image with an offset value of 127
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Mirko Felisa (felisa@ce.unipr.it),
 * \date 2009-10-08
 */

#ifndef _CIMAGEMONO8O127_H
#define _CIMAGEMONO8O127_H

#include <Data/CImage/Pixels/Mono8o127.h>
#include <Data/CImage/TImage.h>

namespace cimage
{
  /** \brief Type for declaring an 8-bit monochrome image with an offset value of 127 */
  typedef TImage<cimage::Mono8o127> CImageMono8o127;
}


#endif

