/**
 * \file CImageMono16.h
 * \brief Class for modeling a 16-bit monochrome image
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _CIMAGE_MONO16_H
#define _CIMAGE_MONO16_H

#include <Data/CImage/Pixels/Mono16.h>
#include <Data/CImage/TImage.h>
namespace cimage
{
  /** \brief Type for declaring a a 16-bit monochrome image */
  typedef TImage<cimage::Mono16> CImageMono16;
}

#endif
