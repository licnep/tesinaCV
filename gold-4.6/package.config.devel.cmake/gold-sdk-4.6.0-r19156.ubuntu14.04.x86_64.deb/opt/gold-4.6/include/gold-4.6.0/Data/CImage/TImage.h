/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2009                  *
 *                                                                    *
 *       http://www.ARGO.ce.unipr.it    (PGX July 2005)               *
 *                                                                    *
 **********************************************************************/

/**
 * \file TImage.h
 * \brief Class modeling a typed image
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _TIMAGE_H
#define _TIMAGE_H

#include <Data/CImage/CImage.h>
#include <Data/CImage/Buffer.h>
#include <Data/CImage/PixelTraits/PixelTraits.h>
#include <Data/CImage/Exceptions.h>

#include <Data/gold_data_export.h>

namespace cimage
{

/**
 * \brief Class modeling a typed image
 *
 * This template, derived from CImage, is parameterized on the internal type of the image
 * In this way a TImage<uint8_t> has an internal buffer of uint8_t and a TImage<float> has
 * an internal buffer of float.
 *
 * The internal representation, such as packet, plane, yuv422 uses buffers of different types
 * Every representation has different implementation for the same operation.
 *
 * \tparam the internal type of a pixel of the image buffer
 */
template<typename T = unsigned char>
class GOLD_DATA_EXPORT TImage: public CImage
{
public:

	/** \brief Type for a pixel of the internal buffer */
	typedef T PixelType;

	/** \brief Type for the traits of the PixelType. See cimage::PixelTraits */
	typedef cimage::PixelTraits<T> PixelTraits;

	/** \brief Type capable of containing the differeces between pixels */
	typedef typename PixelTraits::DifferenceType DifferenceType;

	/** \brief Type capable of containing an accumulation of pixels */
	typedef typename PixelTraits::CumulativeType CumulativeType;

	/** \brief Typed shared pointer to a TImage<T> */
	typedef boost::shared_ptr<TImage<T> > SharedPtrType;

	/** \brief Typed shared pointer to a const TImage<T> */
	typedef boost::shared_ptr<const TImage<T> > SharedPtrConstType;

	/** \brief Default constructor */
	TImage();

	/** \brief Constructor accepting width and heigth
	 * \param [in] width the width of the new image [pixels]
	 * \param [in] the height of the new image [pixels]
	 */
	TImage(SizeType width, SizeType height);

	/** \brief Copy constructor: create another image with a copy of the same buffer */
	TImage(const TImage& image);

	/** \brief Destructor */
	virtual ~TImage();

	/**
	 * \brief Assignment operator taking a TImage<T>. Create a copy of the current object
	 * \code
	 * TImage<uint8_t> a(10, 10), b(20, 20);
	 * a=b;
	 * //here a is 20x20
	 * \endcode
	 */
	TImage& operator=(const TImage& image);

	/**
	 * \brief Assignment operator taking a CImage. Create a copy of the current object
	 * \code
	 * TImage<uint8_t> a(10, 10), b(20, 20);
	 * CImage& ref=b;
	 * a=b;
	 * //here a is 20x20
	 * \endcode
	 */
	TImage& operator=(const CImage& image);

	/**
	 * \brief Returns the internal Type of the current image
	 *
	 * \returns the image Type of the curren image: an integer identifying the image type.
	 */
	virtual const Type& TypeInfo() const;

	/**
	 * \brief Returns the internal Type of the current image
	 *
	 * \returns the image Type of the curren image: an integer identifying the image type.
	 */
	static const Type& type_info();

	/**
	 * \brief Returns a const pointer to the internal buffer
	 * \return Returns a const pointer to the internal buffer
	 * The pointer has the same type of the pixel
	 * The buffer is read-only
	 * The user is responsible for preventing concurrent access to the buffer
	 * Multiple reader can work concurrently on the same buffer, only one writer is allowed.
	 */
	const T* Buffer() const
	{
		return reinterpret_cast<const T*>(CImage::Buffer());
	}

	/**
	 * \brief Returns a pointer to the internal buffer
	 * \return Returns a pointer to the internal buffer
	 * The pointer has the same type of the pixel
	 * The buffer can be written.
	 * The user is responsible for preventing concurrent access to the buffer
	 * Multiple reader can work concurrently on the same buffer, only one writer is allowed.
	 */
	T* Buffer()
	{
		return reinterpret_cast<T*>(CImage::Buffer());
	}

	// unsigned long Copy_Counter() const { return *m_pcopy_counter; }
	// unsigned long AllocCounter() const { return *m_pcopy_counter; }

	// Allocation functions

	/**
	 * \brief Allocates an empty image of the same type of the current image
	 *
	 * The buffer of the new image is left empty
	 */
	static TImage* TAllocator_Empty()
	{
		return new TImage();
	}

	/**
	 * \brief Allocates an w x h sized image of the same type of the current image
	 *
	 * the buffer of the new image is left empty
	 */
	static TImage* TAllocator_Size(SizeType w, SizeType h)
	{
		return new TImage(w, h);
	}

	/**
	 * \brief Allocates a copy of the image passed as argument
	 *
	 * \param image the image to be copyed.
	 *
	 * Must be of the same type of the current image
	 * Otherwise an exception is thrown
	 */

	static TImage* TAllocator_Copy(const CImage& image)
	{
		TImage* img = new TImage(static_cast<const TImage&>(image));
		return img;
	}

private:

	void __ctor();
	impl::BufferType* __ctor_buffer() const;

	virtual CImage* VEmpty() const
	{
		return TAllocator_Empty();
	}

	virtual CImage* VNew(SizeType W, SizeType H) const
	{
		return TAllocator_Size(W, H);
	}

	virtual CImage* VClone() const
	{
		return TAllocator_Copy(*this);
	}

	virtual impl::BufferType* VNewBuffer() const
	{
		return __ctor_buffer();
	}
};
} // namespace cimage

#endif
