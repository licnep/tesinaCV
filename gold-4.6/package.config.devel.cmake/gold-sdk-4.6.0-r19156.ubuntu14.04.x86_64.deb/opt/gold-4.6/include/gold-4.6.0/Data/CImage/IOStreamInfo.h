/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2009                  *
 *                                                                    *
 *       http://www.ARGO.ce.unipr.it    (PGX July 2005)               *
 *                                                                    *
 **********************************************************************/

/**
 * \file IOStreamInfo.h
 * \brief This file handle the Regions classes.
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _IOSTREAMINFO_H
#define _IOSTREAMINFO_H

#include <ostream>
#include <string>

#include <Data/CImage/TImage.h>

namespace cimage
{

/**
 * \brief Operator for writing the main parameters of the image on a ostream
 * \param stream the ostream to be used as output
 * \param image the image to be written
 * Parameters written are:
 * Width Height Channels bit_per_channel byte_per_pixel bit_per_pixel size_in_bytes
 *
 */
  inline std::ostream & operator << ( std::ostream& stream, const CImage& image ) const
  {
    return stream << image.W() << " " << image.H() << " " <<
    		image.chs() << " " << image.bpc() << " " << image.Bpp() << " " << image.bpp() << " " <<
    		image.Size();

  }

  /**
   * \brief Operator for writing the main parameters of the image on a string
   * \param str the string to be filled with the image parameters
   * \param image the image to be written
   * Parameters written are:
   * Width Height Channels bit_per_channel byte_per_pixel bit_per_pixel size_in_bytes
   */
  inline void StrInfo(std::string& str, const CImage& image)
  {
    std::ostringstream ostr;
    ostr << image;
    str = ostr.str();
  }
} // namespace cimage

#endif // _IOSTREAMINFO_H
