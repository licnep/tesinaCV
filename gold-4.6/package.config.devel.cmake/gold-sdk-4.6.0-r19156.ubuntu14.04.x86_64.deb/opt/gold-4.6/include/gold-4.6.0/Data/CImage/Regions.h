/**
 * \file Regions.h
 * \brief This file handle the Regions classes.
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _CIMAGE_REGIONS_H
#define _CIMAGE_REGIONS_H

#include <Data/CImage/CImage.h>
#include <Data/CImage/Definitions.h>


namespace cimage
{
// NOTE: the possible type of regions should be:
// - regular regions
// - mask
// - list of points

/**
 * \brief Contains the description of a regular region
 *
 * A regular region is defined as a region starting from a pixel
 * made of size pixels, each separated by step pixels from the previous
 *
 */
// TODO: which is the minimum number of parameters?
// for writing a regular subset of a 3D matrix
// start, stride e size are good for a 2D array
// NOTE: use a slice instead, for identifying regular regions
struct RegularRegion
{
	/** \brief Default constructor */
	RegularRegion() :
			Start(), Stride(1), Size(0)
	{
	}

	/** \brief Constructor taking the stride only. Start=0, Size=0. */
	RegularRegion(SizeType stride) :
			Start(), Stride(stride), Size(0)
	{
	}

	/** \brief Constructor taking the start and stride. Size=0. */
	RegularRegion(PixelCoordType start, SizeType stride) :
			Start(start), Stride(stride), Size(0)
	{
	}

	/** \brief Constructor taking the start and stride. Size=0. */
	RegularRegion(PixelCoordType start, SizeType stride,
			SizeType size) :
			Start(start), Stride(stride), Size(size)
	{
	}

	PixelCoordType Start;  ///< Starting point
	SizeType Stride; ///< Step: separation between two points
	SizeType Size;   ///< Number of points
};
}

#endif // _CIMAGE_REGIONS_H
