/**
 * \file CImageRegistration.h
 * \brief Utilities for registering new image types
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _CIMAGE_REGISTRATION_H
#define _CIMAGE_REGISTRATION_H

#include <Data/CImage/TImage.hxx> // TODO: distribute in the images implementation files

#include <boost/bimap.hpp>
#include <boost/tokenizer.hpp>

#include <map>

namespace cimage
{
  namespace impl
  {
    /** \brief Returns a map containing the registered allocators */
    GOLD_DATA_EXPORT std::map< std::string, cimage::AllocatorType >& StringAllocators();

    /** \brief Returns a boost::bimap associating the CImage::Type with the corresponding string representation */
    GOLD_DATA_EXPORT boost::bimap< CImage::Type, std::string >& TypeInfo2String();
    
    /**
     * \brief Template for registering an allocator for a specific image type
     *
     * \tparam T the image type for the allocator registrar
     */
    template<class T>
    class GOLD_DATA_EXPORT Allocator_Registrar
    {
      public:
    	/**
    	 * \brief Constructor accepting a string used for generating an allocator
    	 *
    	 * The following code register a new allocator for MY_IMAGE_TYPE
    	 * \code
    	 * Allocator_Registrar<MyImageType> x( "MY_IMAGE_TYPE" );
    	 * \endcode
    	 *
    	 * After the registration it will be possible to call:
    	 * \code
    	 * cimage::SharedPtrType shptr = cimage::Build("MY_IMAGE_TYPE, 10, 10");
    	 * \endcode
    	 */
        Allocator_Registrar ( const std::string& str )
        {
          using namespace boost;
          typedef tokenizer<char_separator<char> > Tokenizer;
          char_separator<char> sep ( " \t," );
          Tokenizer tok ( str, sep );

          for ( Tokenizer::iterator itr_tk=tok.begin(); itr_tk!=tok.end(); ++itr_tk )
          {
            StringAllocators().insert ( std::make_pair ( *itr_tk, ( cimage::AllocatorType ) cimage::TImage<typename T::PixelType>::TAllocator_Size ) );
            TypeInfo2String().insert ( boost::bimap< CImage::Type, std::string >::value_type ( T::type_info(), *tok.begin()) ); 
          }
        }
    };
  } // namespace impl
} // namespace cimage


/**
 * \brief Macro for registering a new allocator
 *
 *	Place the following code in the image implementation file
 * \code
 *   CIMAGE__REGISTER_ALLOCATOR(CImageMono8, "MONO8");
 * \endcode
 */
#define CIMAGE__REGISTER_ALLOCATOR( I, S ) \
        static cimage::impl::Allocator_Registrar<I> _Allocator_Registrar##I(S)


#endif // _CIMAGE_REGISTRATION_H

