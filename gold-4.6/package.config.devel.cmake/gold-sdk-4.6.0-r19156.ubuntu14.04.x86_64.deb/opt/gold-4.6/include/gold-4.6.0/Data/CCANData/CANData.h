/**
 * @file CANData.h
 * @brief Class modeling a CAN packet
 * @authors Paolo Grisleri (grisleri@ce.unipr.it)
 */

#ifndef _CCANDATA_H
#define _CCANDATA_H

#include <string>
#include <stdint.h>

#include <Data/gold_data_export.h>

#pragma pack(push)
#pragma pack(1)

namespace data
{ 

/**
 * \brief Class modeling a CAN packet
 *
 * This class is used for modeling a CAN packet
 * that is an 8 byte array containing values
 * read or to be written on a CAN bus as a message
 */
class GOLD_DATA_EXPORT CCANData
{
public:

	/** \brief type for the message identifier */
    typedef uint32_t IDType;

    IDType    ID;         ///< Message identifier
    uint8_t   MsgType;    ///< Message type
    uint8_t   Length;     ///< Message lenght [# byte]
    uint8_t   Payload[8]; ///< Message data

    /** \brief Default constructor */
    CCANData();

    /**
     * \brief Constructor accepting id, message type and a pointer to external data
     * \param id Message identifier
     * \param msg_type Message type
     * \param data 8 bytes long data array allocated externally
     */
    CCANData(IDType id, uint8_t msg_type, const uint8_t* data);

    /**
     * \brief Constructor from string
     *
     * \param string containing a can message with the format:
     * \code
     * 		ID   Type Length Payload-byte0 ... Payload-byte7
     * 		"0430 0 8 04 a4 00 13 04 04 00 00"
     * \endcode
     *
     */
    CCANData(const std::string& str);


    /**
     * \brief Produces a string containg the meassage and compatible with the string constructor
     *
     * \param string containing a can message with the format:
     * \code
     * 		ID   Type Length Payload-byte0 ... Payload-byte7
     * 		"0430 0 8 04 a4 00 13 04 04 00 00"
     * \endcode
     *
     */
    void FromString(const std::string& str);

    /** \brief Cleanup the message content */
    void Clear();

    /** \brief Returns the message size */
    unsigned long Size() const {
        return Length;
    }

    /** \brief Returns the size of a standard CAN message */
    static unsigned int SizeStd() {
        return 8;
    }
};

} // namespace data

#pragma pack(pop)


#endif //#ifndef _CCANDATA_H
