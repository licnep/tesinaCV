/**
 * \file RGB8.h
 * \brief Definitions for modeling 3 channels, 8-bit unsigned integer RGB pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>,
 */

#ifndef _RGB8_H
#define _RGB8_H

#include <Data/CImage/Pixels/TRGB.h>

#include <stdint.h>

namespace cimage
{
/**
 * \brief Definition for RGB8 pixels
 * This pixel support 3 channels, 16-bit unsigned integer depth
 */
typedef TRGB<uint8_t> RGB8;

/**
 * \brief Definition for RGB8 pixels
 * This pixel support 3 channels, 16-bit unsigned integer depth
 */
typedef TRGB<uint8_t> RGB888;

/** \brief Deprecated version, use RGB8 instead */
GOLD_DATA_DEPRECATED typedef TRGB<uint8_t> RGB24;

/** \brief Deprecated version, use RGB8 instead */
GOLD_DATA_DEPRECATED typedef TRGB<uint8_t> RGB;
}

#endif // _RGB8_H
