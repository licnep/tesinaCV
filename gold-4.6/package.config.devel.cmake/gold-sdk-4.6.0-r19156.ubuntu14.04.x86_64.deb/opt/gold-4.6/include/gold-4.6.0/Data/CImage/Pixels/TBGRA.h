/**
 * \file TBGRA.h
 * \brief Definitions for modeling 4 channels, generic BGRA pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>,
 */

#ifndef _TBGRA_H
#define _TBGRA_H

#include <boost/operators.hpp>

#include <Data/gold_data_export.h>

namespace cimage
{
/**
 * \brief Template class for modeling generic Blue, Green, Red, Alpha (BGRA), 4 channels pixels
 * \tparam S type to be used for the channel
 */
  template <class S>
  class GOLD_DATA_EXPORT TBGRA :
          boost::addable< TBGRA<S> ,        
          boost::subtractable<TBGRA<S>,
          boost::multipliable<TBGRA<S>,
          boost::dividable<TBGRA<S>,
          boost::orable<TBGRA<S>,
          boost::andable<TBGRA<S>,
          boost::xorable<TBGRA<S>,
          boost::less_than_comparable <TBGRA<S>,
          boost::equality_comparable<TBGRA<S>
            > > > > > > > > >
  {
    public:

	  /** \brief Enumerator for channel identifier */
      typedef enum Channels {BLUE=0, GREEN=1, RED=2, ALPHA=3} Channel;

      /** \brief Default constructor */
      TBGRA()
      {}

      /**
       * \brief Constructor accepting a value of the same type of the channel
       *
       * All the channel values are set to val
       */
      inline explicit TBGRA ( const S val ) : B ( val ), G ( val ), R ( val ), A ( val )
      {}

      /**
       * \brief Constructor accepting 4 values B, G, R and A, of a different type, convertible to S
       */
      template<class T>
      inline explicit TBGRA ( T b, T g, T r, T a ) :
          B ( static_cast<S> ( b ) ),
          G ( static_cast<S> ( g ) ),
          R ( static_cast<S> ( r ) ),
          A ( static_cast<S> ( a ) )
      {}

      /**
       * \brief Constructor accepting 4 values B, G, R and A
       */
      inline explicit TBGRA ( S b, S g, S r, S a=255 ) :
          B ( static_cast<S> ( b ) ),
          G ( static_cast<S> ( g ) ),
          R ( static_cast<S> ( r ) ),
          A ( a )
      {}


	// template<class T>
	// inline explicit TBGRA ( const T luminance ) :
	//   B ( static_cast<S> ( luminance ) ),
	//   G ( static_cast<S> ( luminance ) ),
	//   R ( static_cast<S> ( luminance ) ),
	//   A ( 255 )
	// {}

      /**
       * \brief Constructor accepting a luminance of different type
       * Alpha is set by default to 255
       */
      template<class T>
      inline explicit TBGRA ( const T luminance, const T alpha=255 ) :
          B ( static_cast<S> ( luminance ) ),
          G ( static_cast<S> ( luminance ) ),
          R ( static_cast<S> ( luminance ) ),
          A ( alpha )
      {}

      /**
       * \brief Returns true if the current pixel has each of the 4 values less than the correspondent value of the argument
       */
      bool operator < (const TBGRA& a) const
      {
        return R<a.R  && G<a.G  && B<a.B && A<a.A;
      }

      /**
       * \brief Returns true if the current pixel has each of the 4 values equal to the correspondent value of the argument
       */
       bool operator == (const TBGRA& a) const
      {
        return R==a.R  && G==a.G  && B==a.B && A==a.A;
      }


       /** \brief Set the current pixel value to the BITWISE AND between the current value and the argument */
      inline TBGRA& operator &= ( const TBGRA& value )
      {
        R&=value.R, G&=value.G, B&=value.B, A&=value.A;
        return *this;
      }

      /** \brief Set the current pixel value to the BITWISE OR between the current value and the argument */
      inline TBGRA& operator |= ( const TBGRA& value )
      {
        R|=value.R, G|=value.G, B|=value.B, A|=value.A;
        return *this;
      }

      /** \brief Set the current pixel value to the BITWISE XOR between the current value and the argument */
      inline TBGRA& operator ^= ( const TBGRA& value )
      {
        R^=value.R, G^=value.G, B^=value.B, A^=value.A;
        return *this;
      }


      /** \brief Set the current pixel value to the SUM between the current value and the argument */
      inline TBGRA& operator += ( const TBGRA& value )
      {
        R+=value.R, G+=value.G, B+=value.B;
        return *this;
      }

      /** \brief Set the current pixel value to the DIFFERENCE between the current value and the argument */
      inline TBGRA& operator -= ( const TBGRA& value )
      {
        R-=value.R, G-=value.G, B-=value.B;
        return *this;
      }

      /** \brief Set the current pixel value to the PRODUCT between the current value and the argument */
      inline TBGRA& operator *= ( const TBGRA& value )
      {
        R*=value.R, G*=value.G, B*=value.B;
        return *this;
      }

      /** \brief Set the current pixel value to the QUOTIENT between the current value and the argument */
      inline TBGRA& operator /= ( const TBGRA& value )
      {
        R/=value.R, G/=value.G, B/=value.B;
        return *this;
      }

      /** \brief Set the current pixel value to the SUM between the current value and the argument */
      template<class T>
      inline TBGRA& operator += ( const T factor )
      {
        R=static_cast<S> ( factor+R ),
        G=static_cast<S> ( factor+G ),
        B=static_cast<S> ( factor+B );
        A=static_cast<S> ( factor+A );
        return *this;
      }

      /** \brief Set the current pixel value to the DIFFERENCE between the current value and the argument */
      template<class T>
      inline TBGRA& operator -= ( const T factor )
      {
        R=static_cast<S> ( R-factor ),
        G=static_cast<S> ( G-factor ),
        B=static_cast<S> ( B-factor );
        A=static_cast<S> ( A-factor );
        return *this;
      }

      /** \brief Set the current pixel value to the PRODUCT between the current value and the argument */
      template<class T>
      inline TBGRA& operator *= ( const T factor )
      {
        R=static_cast<S> ( factor*R ),
        G=static_cast<S> ( factor*G ),
        B=static_cast<S> ( factor*B );
        A=static_cast<S> ( factor*A );
        return *this;
      }

      /** \brief Set the current pixel value to the QUOTIENT between the current value and the argument */
      template<class T>
      inline TBGRA& operator /= ( const T factor )
      {
        R=static_cast<S> ( R/factor ),
        G=static_cast<S> ( G/factor ),
        B=static_cast<S> ( B/factor );
        A=static_cast<S> ( A/factor );
        return *this;
      }


      /** \brief Returns a TBGRA obtained from the SUM between the TRGBA constructed with value and factor */
      template<class T>
      friend inline TBGRA operator + ( const T factor, const TBGRA& value )
      {
        return TBGRA ( value ) +=factor;
      }

      /** \brief Returns a TBGRA obtained from the DIFFERENCE between the TRGBA constructed with value and factor */
      template<class T>
      friend inline TBGRA operator - ( const T factor, const TBGRA& value )
      {
        return TBGRA ( value )-=factor;
      }

      /** \brief Returns a TBGRA obtained from the PRODUCT between the TRGBA constructed with value and factor */
      template<class T>
      friend inline TBGRA operator * ( const T factor, const TBGRA& value )
      {
        return TBGRA ( value ) *=factor;
      }

      /** \brief Returns a TBGRA obtained from the QUOTIENT between the TRGBA constructed with value and factor */
      template<class T>
      friend inline TBGRA operator / ( const T factor, const TBGRA& value )
      {
        return TBGRA ( value ) /=factor;
      }

       /**
       * \brief Index operator: returns the value of the channel requested as argument
       * \param i channel number
       * \return the value for the i-th channel
       */
      S operator [](unsigned int i) const { return *(&R+i); }

      S B; ///< Value of the Blue channel
      S G; ///< Value of the Green channel
      S R; ///< Value of the Red channel
      S A; ///< Value of the Alpha channel (transparency: 0 means fully transparent)
  };


}

#endif
