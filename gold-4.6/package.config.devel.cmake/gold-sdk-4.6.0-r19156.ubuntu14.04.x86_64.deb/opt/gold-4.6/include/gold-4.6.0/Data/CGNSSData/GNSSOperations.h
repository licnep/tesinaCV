/**
 * \file GNSSOperations.h
 * \brief Functions and classes for operating on CGNSSData
 * \author Paolo Medici \<medici@ce.unipr.it\>, Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _GNSS_OPERATIONS_H
#define _GNSS_OPERATIONS_H

#include "CGNSSData.h"

#include <Data/Math/TMatrices.h>
#include <Data/Math/Points.h>

namespace data
{
/** \brief Data and operations related to CGNSSData */
namespace cgnss
{

/** \brief Constants for operating on CGNSSData */
namespace constant
{
	/** \brief Earth Radius [km] */
	static const double EarthRadius_KM = 6378.0;

	/** \brief Earth Radius in [m] */
	static const double EarthRadius_M = EarthRadius_KM * 1000.0;

	/** \brief SemiMinor Earth Axis [m] */
	static const double EarthSemiMinorAxis_M = 6356752.0;

	/** \brief SemiMajor Axis of Earth [m] */
	static const double EarthSemiMajorAxis_M = 6378137.0;

	/** \brief NMEA Flattening factor (WGS84) (f) */
	static const double EarthFlattening = (1.0 / 298.257223563);

	/** \brief NMEA Eccentricy^2 (Derived WGS84) (2-f)f */
	//	static const double SquaredEccentricy = 2.0 * EarthFlattening - EarthFlattening*EarthFlattening;
	static const double SquaredEccentricy = 6.69437999013 * 0.001;
}


/**
 * \brief Convert Longitude,Latitude,Altitude (LLA ) to ECEF XYZ
 * \param lat latitude in [degrees]
 * \param lon longitude in [degrees]
 * \param alt altitude in [m]
 * \return a XYZ ECEF point
 **/
math::Point3d GOLD_DATA_EXPORT GNSSToECEF(const data::WayPoint& point);

/** \brief Distance algorithms */
enum DistanceAlgorithm
{
	GreatCircleDistance,     ///<  Great Circle Distance algorithm
	OblateSpheroidEarthModel ///<  Oblate Spheroid Earth Model algorithm
};

/** \brief Compute the distance between two data::WayPoint using the specified algorithm */
double GOLD_DATA_EXPORT Distance(const data::WayPoint& a, const data::WayPoint& b,
		DistanceAlgorithm algo = GreatCircleDistance);

/**
 * \brief Returns the Radius in Prime Vertical
 * \param latitude latitude in degree
 * \return Prime Vertical N
 **/
double GOLD_DATA_EXPORT PrimeVertical(double latitude);

/**
 * \brief Reference Frame centrated on SetOrigin and allows conversions from ECEF to ENU, or from LLA to ENU
 *
 * This class permits also to convert from ENU to Vehicle Reference Frame
 **/
class GOLD_DATA_EXPORT CENUReference
{

	math::TMatrix<double, 3, 3> m_rotation;  ///< Rotation matrix
	math::Point3d m_origin;                  ///< Origin

public:

	/** \brief Default constructor */
	CENUReference();

	/**
	 * \brief Sets the ENU origin point
	 * \param point a LLA point
	 * \code
	 * m_cur = boost::any_cast<CGNSSData>(data);
	 * // ....
	 * m_ref.SetOrigin(m_cur);
	 * \endcode
	 **/
	void SetOrigin(const data::WayPoint & point);

	/**
	 * \brief Multiply Rotation matrix with an additional rotation angle in order to create a Local Reference Frame
	 *
	 * The reference used is X: Front of Vehicle, Y: Left, Z: Up
	 * @param heading eventually a GNSS heading to use LocalCoordiante instead of ENU. [rad] from North.
	 **/
	void SetLocalReference(double heading);

	/**
	 * \brief Multiply Rotation matrix with an additional matrix
	 **/
	void MulMatrix(const math::TMatrix<double, 3, 3>& L);

	/**
	 * \brief Converts a point from XYZ ECEF to ENU (X:EAST, Y:NORTH, Z:UP)
	 * \param ecef a ECEF point
	 * \return a ENU point
	 **/
	math::Point3d ECEFtoENU(const math::Point3d & ecef) const;


	/** converts a point from ENU (X:EAST, Y:NORTH, Z:UP) to ECEF
	 * @param ecef a ECEF point
	 * @return a ENU point
	 **/
	math::Point3d ENUtoECEF(const math::Point3d & enu) const;

	/** Converts a LLA coordiante in ENU (X:EAST, Y:NORTH, Z:UP)
	 * @param in a data::WayPoint
	 * @return a Point3d in ENU Reference Frame
	 * \code
	 * Point3d p = m_refV.LLAtoENU(*i);
	 * \endcode
	 **/
	math::Point3d LLAtoENU(const data::WayPoint & in) const;
};

/** \brief A filter for simplifying use of std::transform with containers of data::WayPoint
 *
 * \code
 *	std::vector<Point2d> local;
 *	std::transform(m_lastPoints.begin(), m_lastPoints.end(), local.begin(), static_cast<LLAtoENFilter&>(m_refV) );
 * \endcode
 * \see CENUReference::LLAtoENU
 **/
class LLAtoENFilter: public CENUReference
{
public:
	math::Point2d operator()(const data::WayPoint& in) const;
};

} // namespace cgnss
} // namespace data

#endif
