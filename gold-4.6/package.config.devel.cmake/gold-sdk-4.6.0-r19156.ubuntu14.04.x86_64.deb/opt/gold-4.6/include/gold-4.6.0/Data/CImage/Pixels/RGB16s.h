/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/

/**
 * \file RGB16s.h
 * \brief Definitions for modeling 3 channels, 16-bit signed integer RGB pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 * \date 2006-08-03
 */

#ifndef _RGB16S_H
#define _RGB16S_H

#include <Data/CImage/Pixels/TRGB.h>

#include <stdint.h>

namespace cimage
{
/**
 * \brief Definition for RGB16s pixels
 * This pixel support 3 channels, 16-bit signed integer depth
 */
typedef TRGB<int16_t> RGB16s;
}

#endif // _RGB16S_H
