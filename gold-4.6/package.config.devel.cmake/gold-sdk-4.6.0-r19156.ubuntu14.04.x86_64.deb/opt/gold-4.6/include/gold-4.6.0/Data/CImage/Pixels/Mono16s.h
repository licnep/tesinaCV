/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/

/**
 * \file Mono16s.h
 * \brief Definitions for modeling 1 channel, 16-bit signed integer pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Paolo Zani (zani@ce.unipr.it)
 * \date 2006-05-27
 */

#ifndef _SIGNEDMONO16_H
#define _SIGNEDMONO16_H

#include <stdint.h>

namespace cimage
{
/**
 * \brief Definition for Mono16s pixels
 * This pixel support one luminance channel with a depth of 16-bit signed depth
 */
typedef int16_t Mono16s;
}

#endif
