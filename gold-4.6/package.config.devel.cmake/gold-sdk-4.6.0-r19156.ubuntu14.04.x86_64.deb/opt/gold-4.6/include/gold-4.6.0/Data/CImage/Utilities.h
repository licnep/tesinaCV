/**
 * \file CImage/Utilities.h
 * \brief Functions for creating images from string, and existing buffers
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _CIMAGE_UTILITIES_H
#define _CIMAGE_UTILITIES_H

#include <Data/CImage/CImage.h>

#include <vector>
#include <string>

namespace cimage
{
  /**
   * \brief Returns a vector filled with all the allocators names available
   * \return a vector filled with all the allocators available
   * \see Build
   */
  GOLD_DATA_EXPORT std::vector<std::string> Allocators();
  
  /**
   * \brief Build a new CImage of requested type and size from a string specifying the format
   *
   * The following code allocates a new 10x10 CImageMono8.
   * MONO8 is the allocator identifier corresponding to CImageMono8
   * \code
   * std::string str="MONO8, 10, 10";
   * CImageSharedPtrType sp_img = cimage::Build(str);
   * \endcode
   * \param str format string. "ALLOCATOR, WIDTH, HEIGHT"
   * \return shared pointer to the newly allocated image
   */
  GOLD_DATA_EXPORT SharedPtrType Build ( const std::string& str );

  /**
   * \brief Build a new CImage from an existing C-array of bytes
   * \param buffer the existing C-array of bytes containing an image of type Gray,RGB,RGBA, etc etc
   * \param width,height logical dimensions of the image
   * \param stride image pitch. 0 if the image is contiguous
   * \param type image type. \see CImage::Type
   * \return  shared pointer to the newly allocated image
   */
  GOLD_DATA_EXPORT SharedPtrType Build( const void* buffer, SizeType width, SizeType height, long stride, CImage::Type type);
  
  /**
   * \brief Returns the allocation string corresponding to an image
   * @param [in] img image for which the allocation string is wanted
   * @param [out] str allocation string to be filled
   * @return the allocation string passed as parameter
   */  
  GOLD_DATA_EXPORT std::string& Allocation_String ( const cimage::CImage& image, std::string& str );

  
  /**
   * \brief Builds an empty CImage from a destination type
   *
   * \tparam The type of the image to be created
   * \return shared pointer to the newly allocated image
   * Example:
   * \code
   * // builds a CImageMono8
   * CImage::SharedPtrType pImg = cimage::Build<CImageMono8>();
   * \endcode
   */
  template<typename T> typename T::SharedPtrType Build(SizeType w=0, SizeType h=0)
  {
    return typename T::SharedPtrType(new T(w, h));
  }
}

#endif // _CIMAGE_UTILITIES_H
