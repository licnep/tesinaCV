/**
 * \file CImage/CImageHistograms.h
 * \brief Functions for computing vertical and horizontal histograms
 * \author Paolo Grisleri\<grisleri@ce.unipr.it\>
 */

#ifndef _CIMAGE_HISTOGRAMS_H
#define _CIMAGE_HISTOGRAMS_H

#include <vector>
#include <Data/CImage/TImage.h>

/**
 * \brief Compute the vertical histogram of an image
 *
 * The vertical histogram is a vector with the same size of the image width
 * where each element contains the sum of the pixel values of the corresponding
 * column of the image
 * \tparam T The PixelType of the input image
 * \tparam S The type for the elements of the histogram. Shall be wide enough to host a sum of pixel values.
 * \param [in] image A constant reference to the input image used for computing the histogram
 * \param [out] histogram A reference to the user allocated histogram
 */
template <class T, class S>
void VerticalHistogram(const cimage::TImage<T>& image, std::vector<S>& histogram) const
{
  // resize the histogram and fill it with spaces
  histogram.resize(image.W());
  std::fill(histogram.begin(), histogram.end(), S());

  const cimage::SizeType w=image.W();
  const cimage::SizeType h=image.H();

  // fill the histogram with the values
  for(unsigned int i=0; i<image.W(); ++i)
    for(unsigned int j=0; j<image.H(); ++j)
      histogram[i]+=image.Buffer()[i*image.W()+j];
}

/**
 * \brief Compute the horizontal histogram of an image
 *
 * The horizontal histogram is a vector with the same size of the image height
 * where each element contains the sum of the pixel values of the corresponding
 * row of the image
 * \tparam T The PixelType of the input image
 * \tparam S The type for the elements of the histogram. Shall be wide enough to host a sum of pixel values.
 * \param [in] image A constant reference to the input image used for computing the histogram
 * \param [out] histogram A reference to the user allocated histogram
 */
template <class T, class S>
void HorizontalHistogram(const cimage::TImage<T>& image, std::vector<S>& histogram) const
{
	  // resize the histogram and fill it with spaces
	  histogram.resize(image.W());
	  std::fill(histogram.begin(), histogram.end(), S());

	  const cimage::SizeType w=image.W();
	  const cimage::SizeType h=image.H();

	  for(unsigned int j=0; j<h; ++j)
		for(unsigned int i=0; i<w; ++i)
			histogram[j]+=image.Buffer[i*image.W()+j];
}

#endif // _CIMAGE_HISTOGRAMS_H
