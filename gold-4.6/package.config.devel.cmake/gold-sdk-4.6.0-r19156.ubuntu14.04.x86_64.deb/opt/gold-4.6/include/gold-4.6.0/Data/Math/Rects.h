/**
 * \file Data/Math/Rects.h
 * \brief Data and functions for modeling rectangles
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Paolo Medici (medici@ce.unipr.it)
 */
#ifndef  _RECTS_H
#define  _RECTS_H

#include <cmath>
#include <iosfwd> 
#include <Data/Math/Points.h>

namespace math
{

/**
 * \brief Generic model for a 2-D rectangle defined by two coordinates: (x0,y0) and (x1,y1)
 *
 * (x0,y0) is the upper left corner, (x1,y1) is the bottom right corner
 * \tparam T type for the coordinates
 * \see Rect2_t: an alias for  Rect2<T>
 *
 */
template<class T>
struct Rect2
{

	T x0; ///< x coordinate of the upper left corner
	T y0; ///< y coordinate of the upper left corner
	T x1; ///< x coordinate of the bottom right corner
	T y1; ///< y coordinate of the bottom right corner

	/** \brief Default constructor: initialize all the members with the T() */
	inline Rect2():  x0(T()), y0(T()), x1(T()), y1(T())
	{}

	/**
	 * \brief Constructor accepting the two points as separate coordinates
	 *
	 * \param x0 x coordinate of the upper left corner
	 * \param y0 y coordinate of the upper left corner
	 * \param x1 x coordinate of the bottom right corner
	 * \param y1 y coordinate of the bottom right corner
	 */
	inline Rect2(T _x0, T _y0, T _x1, T _y1) :
			x0(_x0), y0(_y0), x1(_x1), y1(_y1)
	{
	}

	/**
	 * \brief Copy constructor accepting another struct with public members x0, y0, y1, and y1
	 *
	 * \tparam R type of the struct with public members x0, y0, y1, and y1 to be copied
	 * \param s struct of type R with public members x0, y0, y1, and y1 to be copied
	 */
	template<class R>
	Rect2(const R& s) :
			x0(s.x0), y0(s.y0), x1(s.x1), y1(s.y1)
	{
	}

	/**
	 * \brief Returns true when the 2-D point of coordinates (x, y) is contained (<= ) in the current rectangle
	 * \param x coordinate of the 2-D point to be checked for inclusion in the current rectangle
	 * \param y coordinate of the 2-D point to be checked for inclusion in the current rectangle
	 * \return true when true when the 2-D point of coordinate (x, y) is contained (<= ) in the current rectangle
	 */
	inline bool is_inside(T x, T y) const
	{
		return (x0 <= x) && (y0 <= y) && (x <= x1) && (y <= y1);
	}

	/**
	 * \brief Returns true when the the 2-D point of coordinates (x, y),
	 * offered by the structure R is contained in the current rectangle
	 * \tparam R type of the structure exposing the 2-D point coordinates (x, y)
	 * \return true when true the the 2-D point of coordinates (x, y),
	 * offered by the structure R is contained (<=) in the current rectangle
	 */
	template<class R>
	inline bool is_inside(const R& p) const
	{
		return (x0 <= p.x) && (y0 <= p.y) && (p.x <= x1) && (p.y <= y1);
	}

	/**
	 * \brief Returns true when the 2-D point of coordinates (x, y) is strictly contained (<) in the current rectangle
	 * \param x coordinate of the 2-D point to be checked for strict inclusion in the current rectangle
	 * \param y coordinate of the 2-D point to be checked for strict inclusion in the current rectangle
	 * \return true when true when the 2-D point of coordinate (x, y) is strictly contained (<) in the current rectangle
	 */
	inline bool is_stricly_inside(T x, T y) const
	{
		return (x0 < x) && (y0 < y) && (x < x1) && (y < y1);
	}

	/**
	 * \brief Modify the rectangle coordinates so that the 2-D point passed as argument will result included in the rectangle
	 * \param x coordinate of the 2-D point to be included in the current rectangle
	 * \param y coordinate of the 2-D point to be included in the current rectangle
	 */
	inline void include(T x, T y)
	{
		if (x > x1)
			x1 = x;
		if (x < x0)
			x0 = x;
		if (y > y1)
			y1 = y;
		if (y < y0)
			y0 = y;
	}

	/**
	 * \brief Modify the rectangle coordinates so that the 2-D point compatible type \a p
	 * passed as argument will result included in the rectangle
	 * \tparam type of the 2-D point compatible type to be included in the rectangle. The type shall have x and y public members.
	 * \param p 2-D point compatible type to be included in the rectangle
	 * \see clamp
	 */
	template<class R>
	inline void include(const R& p)
	{
		if (p.x > x1)
			x1 = p.x;
		if (p.x < x0)
			x0 = p.x;
		if (p.y > y1)
			y1 = p.y;
		if (p.y < y0)
			y0 = p.y;
	}

	/**
	 * \brief Forces  \a pt to be included in the rectangle
	 * Modifies x,y of @a pt so that it is included by the rectangle limits
	 * If \a pt is already included in the rectangle, than its coordinate are not modified
	 * If \a pt is not included in the current rectangle, than its coordinate are changed
	 * \tparam type of the 2-D point compatible type to be included in the rectangle. The type shall have x and y public members.
	 * \param p 2-D point compatible type to be included in the rectangle
	 * \see include
	 */
	template<class R>
	void clamp(R& pt) const
	{
		if (pt.x < x0)
			pt.x = x0;
		if (pt.y < y0)
			pt.y = y0;
		if (pt.x > x1)
			pt.x = x1;
		if (pt.y > y1)
			pt.y = y1;
	}

	/**
	 * \brief Clip current rectangle inside @a bounds
	 * \tparam type of the Rect2 to be used for clipping the current rectangle
	 * \param bounds the rectangle to be used for clipping the current rectangle
	 * \return A reference to the current rectangle
	 */
	template<class R>
	Rect2<T>& clip(const Rect2<R>& bounds)
	{
		if (x0 < bounds.x0)
			x0 = bounds.x0;
		if (x1 > bounds.x1)
			x1 = bounds.x1;
		if (y0 < bounds.y0)
			y0 = bounds.y0;
		if (y1 > bounds.y1)
			y1 = bounds.y1;
		return *this;
	}

	/** \brief Returns the left-most coordinate of the rectangle*/
	inline T& left()
	{
		return x0;
	}

	/** \brief Returns the right-most coordinate of the rectangle*/
	inline T & right()
	{
		return x1;
	}

	/** \brief Returns the top-most coordinate of the rectangle*/
	inline T & top()
	{
		return y0;
	}

	/** \brief Returns the bottom-most coordinate of the rectangle*/
	inline T & bottom()
	{
		return y1;
	}

	/** \brief Returns the left-most coordinate of the rectangle (const version)*/
	inline const T & left() const
	{
		return x0;
	}

	/** \brief Returns the right-most coordinate of the rectangle (const version)*/
	inline const T & right() const
	{
		return x1;
	}

	/** \brief Returns the top-most coordinate of the rectangle (const version)*/
	inline const T & top() const
	{
		return y0;
	}

	/** \brief Returns the bottom-most coordinate of the rectangle (const version)*/
	inline const T & bottom() const
	{
		return y1;
	}

	/** \brief Returns the top-left point of the rectangle */
	inline Point2<T> topleft() const
	{
		return Point2<T>(x0, y0);
	}

	/** \brief Returns the bottom right point of the rectangle */
	inline Point2<T> bottomright() const
	{
		return Point2<T>(x1, y1);
	}

	/** \brief Returns the width of the rectangle */
	inline T width() const
	{
		return x1 - x0;
	}

	/** \brief Returns the height of the rectangle */
	inline T height() const
	{
		return y1 - y0;
	}
};

/**
 * \brief Compute the rectangle including all the points between [ \a __first and \a __last [
 * \tparam T type of the output rectangle
 * \tparam InputIterator type of the iterator
 * \param [out] rect output rectangle containing all the points between [ \a __first and \a __last [
 * \param [in] input iterator to the first point to be included by the output rectangle
 * \param [in] input iterator to the last point to be included by the output rectangle
 * \note __first will be included, while __last will NOT be included
 **/
template<class T, class InputIterator>
void bounding_rect(Rect2<T>& rect, InputIterator __first, InputIterator __last)
{
	if (__first != __last)
	{
		rect.x0 = rect.x1 = __first->x;
		rect.y0 = rect.y1 = __first->y;
		++__first;
		for (; __first != __last; ++__first)
		{
			rect.include(__first->x, __first->y);
		}
	}
}

/**
 * \brief Operator for writing the content of the Rect2<T> passed as argument on a stream
 *
 * The output will be formatted as the following example. No CR/LF is appended.
 * \code
 * 0.0,0.0,10.0,10.0
 * \endcode
 *
 * \tparam T type of the input rectangle
 * \param [in] o std::ostream where the Rect2<T> content will be printed
 * \param [in] l Rect2<T> to be printed on the stream
 **/
template<class T>
inline std::ostream& operator<<(std::ostream& o, const Rect2<T>& l)
{
	o << l.x0 << ',' << l.y0 << ',' << l.x1 << ',' << l.y1;
	return o;
}

/**
 * \brief Operator for reading the content of the Rect2<T> passed as argument from a stream
 *
 * The input shall be formatted as the following example. No CR/LF is read. No additional separators are allowed
 * \code
 * 0.0,0.0,10.0,10.0
 * \endcode
 *
 * \tparam T type of the input rectangle
 * \param [in] o std::ostream where the Rect2<T> content will be printed
 * \param [in] l Rect2<T> to be printed on the stream
 **/
template<class T>
inline std::istream& operator>>(std::istream & i, Rect2<T> & l)
{
	char sep;
	i >> l.x0 >> sep >> l.y0 >> sep >> l.x1 >> sep >> l.y1;
	return i;
}

// common typedefs

/** \brief Alias for Rect2<int>  */
typedef Rect2<int> Rect2i;

/** \brief Alias for Rect2<unsigned int>  */
typedef Rect2<unsigned int> Rect2ui;

/** \brief Alias for Rect2<float>  */
typedef Rect2<float> Rect2f;

/** \brief Alias for Rect2<double>  */
typedef Rect2<double> Rect2d;


}// namespace math

#endif
