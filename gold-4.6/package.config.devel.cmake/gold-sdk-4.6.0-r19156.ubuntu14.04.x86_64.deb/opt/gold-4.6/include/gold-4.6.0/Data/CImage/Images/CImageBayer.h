/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/

/**
 * \file CImageBayer.h
 * \brief Class for modeling a generic Bayer image
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Paolo Zani (zani@ce.unipr.it)
 * \date 2006-03-25
 */

#ifndef _CIMAGEBAYER_H
#define _CIMAGEBAYER_H

#include <Data/CImage/TImage.h>
#include <Data/CImage/Pixels/Bayer.h>

namespace cimage
{

  /**
   * \brief Class for modeling a generic Bayer image
   *
   * Bayer images are raw images produced as output of commercial sensors
   * Every pixel on a bayer image has a color filter on it and contains the value level for
   * specific color, usually a combination of Red, 2 Green pixel, and a Blue pixel
   */
  template<typename U>
  class GOLD_DATA_TEMPLATE_EXPORT CImageBayer
  {
    public:
	  /**
	   * \brief Type for accessing a TImageBayer<U>. This work like a typedef template
	   * \see Robert Schmidt, "Typedef Templates", Microsoft Corp, August 3, 2000
	   */
      typedef TImage< Bayer<U> > Type;
  };

  /** \brief Short type for declaring a CImageBayerBGGR */
  typedef CImageBayer<BGGR>::Type CImageBayerBGGR;

  /** \brief Short type for declaring a CImageBayerGRBG */
  typedef CImageBayer<GRBG>::Type CImageBayerGRBG;

  /** \brief Short type for declaring a CImageBayerRGGB */
  typedef CImageBayer<RGGB>::Type CImageBayerRGGB;

  /** \brief Short type for declaring a CImageBayerGBRG */
  typedef CImageBayer<GBRG>::Type CImageBayerGBRG;

  /** \brief Short type for declaring a CImageBayerRGGB */
  typedef CImageBayer<RGGB>::Type CImageBayerRGGB;
}

#endif
