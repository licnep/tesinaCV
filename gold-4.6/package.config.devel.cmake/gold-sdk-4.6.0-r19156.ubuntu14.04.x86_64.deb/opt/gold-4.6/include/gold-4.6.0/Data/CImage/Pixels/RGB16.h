/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/

/**
 * \file RGB16.h
 * \brief Definitions for modeling 3 channels, 16-bit unsigned integer RGB pixels
 * \author Gabriele Camellini (cgabri@ce.unipr.it), Paolo Grisleri \<grisleri@ce.unipr.it\>,
 * \date 2012-04-06
 */

#ifndef _RGB16_H
#define _RGB16_H

#include <Data/CImage/Pixels/TRGB.h>

#include <stdint.h>

namespace cimage
{
/**
 * \brief Definition for RGB16 pixels
 * This pixel support 3 channels, 16-bit unsigned integer depth
 */
typedef TRGB<uint16_t> RGB16;
}

#endif // _RGB16_H
