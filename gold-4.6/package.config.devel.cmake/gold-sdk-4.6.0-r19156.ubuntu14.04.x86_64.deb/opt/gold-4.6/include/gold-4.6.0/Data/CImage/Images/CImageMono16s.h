/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file CImageMono16s.h
 * \brief Class for modeling a 16-bit signed monochrome image
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Paolo Zani (zani@ce.unipr.it)
 * \date 2006-05-27
 */

#ifndef _CIMAGESIGNEDMONO16_H
#define _CIMAGESIGNEDMONO16_H

#include <Data/CImage/Pixels/Mono16s.h>
#include <Data/CImage/TImage.h>


namespace cimage
{
  /** \brief Type for declaring a a 16-bit signed monochrome image (15 bit depth for both positive and negative values) */
  typedef TImage<Mono16s> CImageMono16s;
}

#endif

