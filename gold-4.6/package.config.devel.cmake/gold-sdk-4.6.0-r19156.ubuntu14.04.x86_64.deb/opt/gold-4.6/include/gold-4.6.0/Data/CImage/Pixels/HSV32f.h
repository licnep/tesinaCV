/**
 * \file Pixels/HSV32f.h
 * \brief Definitions for modeling HSL, 3 channels, 32-bit float pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Pietro Versari \<versari@ce.unipr.it\>
 */

#ifndef _HSV32F_H
#define _HSV32F_H

#include <Data/CImage/Pixels/THSV.h>

namespace cimage
{

/**
 * \brief Definition for HSV32f.
 * This pixel support Hue, Saturation and Value if three separated 32-bit float channels
 * \see THSV
 */
typedef THSV<float> HSV32f;

/**
 * \brief Definition for HSVf.
 * This pixel support Hue, Saturation and Value if three separated 32-bit float channels
 * \see THSV
 */
typedef THSV<float> HSVf;

}

#endif // _HSV32F_H
