/**
 * \file CImage/Exceptions.h
 * \brief This file contains the exceptions thrown by the cimage library
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 *
 *  Exception are thrown by the cimage library whenever a certain condition cannot be managed
 *  \ref cimage_except
 */

#ifndef _CIMAGE_EXCEPTIONS_H
#define _CIMAGE_EXCEPTIONS_H

#include <string>
#include <boost/current_function.hpp>

#include <stdexcept>

namespace cimage
{
/**
 * \brief Exception thrown for signaling that the called method is not implemented
 *
 * Methods or functions that do not have a general implementation and a specialized implementation.
 * may throw this exception.
 */
class not_implemented: public std::runtime_error
{
public:
	/** \brief Constructor accepting a string */
	not_implemented(const std::string& what) :
			std::runtime_error("Not Implemented: " + what)
	{
	}
};

/**
 * \brief macro for throwing a not_implemented exception with BOOST_CURRENT_FUNCTION as argument
 */
#define NOT_IMPLEMENTED throw cimage::not_implemented(BOOST_CURRENT_FUNCTION)

/**
 * \brief Exception thrown when a certain function is not found for a certain argument
 *
 * Some processing functions operating on typed images are registered inside single dispatcher
 * so they can be called using generic CImage and be resolved using rtti
 * This exception is thrown when the corresponding function is not found from the single dispatcher lookup procedure

 */
class unregistered_call: public std::runtime_error
{
public:
	/** \brief Constructor accepting function name and an image type */
	template<typename T>
	unregistered_call(const std::string& name, const T& img) :
			runtime_error(name + " not registered for " + typeid(img).name())
	{
	}
};

}

#endif

