/**
 * \file CScanSerialization.h
 * \brief Serialization for CScan
 * \author Paolo Grisleri \<grisleri@ce.unipr.it>
 */

#ifndef _CSCAN_SERIALIZATION_H
#define _CSCAN_SERIALIZATION_H


#include <boost/filesystem/path.hpp>
#include <boost/property_tree/ptree.hpp>
#include <Data/gold_data_export.h>

#include <Data/Base/FormatsEnumerator.h>

namespace data
{
  
class CScan;

/** \brief Data and operations related to CScan */
namespace cscan
{
  /** \brief Serialization for CScan */
  namespace serialization
  {
    /**
     * \brief Read a CScan from a file
     * \param [in] file_name input file containing the CScan to be de-serialized
     * \param [out] data the CScan to be read from the stream
     * \param [in] check_version false if the load function should skip the version check
     * \return the number of bytes actually written on disk
     */
    GOLD_DATA_EXPORT uint64_t Load(const boost::filesystem::path& filename, 
                                   CScan& scan, bool check_version=true);

    /**
     * \brief Read a CScan from a file
     * \param [in] file_name input file containing the CScan to be de-serialized
     * \param [out] data the CScan to be read from the stream
     * \return the number of bytes actually written on disk
     */
    GOLD_DATA_EXPORT uint64_t Save(const CScan& scan, 
                                   const boost::filesystem::path& filename);

    /**
     * \brief Enumerator for the formats available
     */
    typedef enum
    {
    	TXT, ///< string format
    	BIN  ///< binary format
    } FormatType;

    /**
     * \brief Load a CScan from a stream using the required format
     * \param [in] is from the CScan has to be loaded
     * \param [in] data CScan to be loaded
     * \param [in] fmt FormatType format type to be used
     * \param [in] options property tree containing the loading options
     * \param [in] check_version false if the load function should skip the version check
     */
    // TODO embed checkversion inside options
    GOLD_DATA_EXPORT void Load( std::istream& is,
    							CScan& data,
                                FormatType fmt, 
                                boost::property_tree::ptree options=boost::property_tree::ptree(), 
                                bool check_version=true);

    /**
     * \brief Save a CScan on a stream using the required format
     * \param [in] data CScan to be saved
     * \param [in] out ostream were to save the CScan
     * \param [in] fmt FormatType format type be used
     * \param [in] options property tree containing the saving options
     */
    GOLD_DATA_EXPORT void Save(const CScan& data,
                               std::ostream& out, 
                               FormatType fmt, 
                               const boost::property_tree::ptree& options);    
    
    /**
     * \brief TFormatEnumerator containing the formats supported for serializing CScan
     */
    GOLD_DATA_EXPORT data::TFormatEnumerator<CScan>& FormatEnumerator();
  }    
  
} // namespace cscan
} // namespace data

#endif
