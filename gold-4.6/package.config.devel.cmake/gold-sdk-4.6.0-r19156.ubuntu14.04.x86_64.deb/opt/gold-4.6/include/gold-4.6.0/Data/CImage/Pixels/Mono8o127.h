/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/

/**
 * \file Mono8o127.h
 * \brief Declaration for modeling 1 channel, 8-bit unsigned integer, with an offset of 127 pixels
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _MONO8O127_H
#define _MONO8O127_H

#include <Data/gold_data_export.h>

#define TCUSTOMPIXEL_EXPORT GOLD_DATA_EXPORT 
#include <Data/CImage/Pixels/TCustomPixel.h>
#undef TCUSTOMPIXEL_EXPORT

#include <stdint.h>


namespace cimage
{

/**
 * \brief Declares a custom pixel with type uint8_t
 * This pixel support one luminance channel with a depth of 8-bit unsigned and an offset of 127
 */
CIMAGE__DECLARE_CUSTOM_PIXEL ( uint8_t, Mono8o127, GOLD_DATA_EXPORT  );
 
}

#endif
 
