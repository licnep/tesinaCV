/**
 * \file CImageHSL32f.h
 * \brief Class for modeling a Hue, Saturation, Lightness (HSL) 3-channels, 32-bits float image
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Pietro Versari \<versari@ce.unipr.it\>
 */

#ifndef _CIMAGE_HSL32F_H
#define _CIMAGE_HSL32F_H

#include <Data/CImage/Pixels/HSL32f.h>
#include <Data/CImage/TImage.h>

namespace cimage
{
  /** \brief Type for declaring a Hue, Saturation, Lightness (HSL) 3-channels, 32-bits float image */
  typedef TImage<HSL32f> CImageHSL32f;
  
  /** \brief Alias type for declaring a Hue, Saturation, Lightness (HSL) 3-channels, 32-bits float image */
  typedef CImageHSL32f CImageHSLf;
}

#endif
