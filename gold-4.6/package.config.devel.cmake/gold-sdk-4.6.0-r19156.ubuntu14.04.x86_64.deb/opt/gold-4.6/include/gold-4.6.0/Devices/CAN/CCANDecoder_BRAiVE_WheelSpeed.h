/**
 * \file CCANDecoder_BRAiVE_WheelSpeed.h
 * \brief CAN Decoder for BRAiVE wheel speed messages
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Manuel Gargioni
 */
#ifndef CCANDECODER_SPEED_H_
#define CCANDECODER_SPEED_H_

#include "CCANDecoder.h"
#include "CCANDecoderRegistration.h"

namespace dev
{
namespace can
{
namespace decoder
{

/** \brief  CAN Decoder for BRAiVE wheel speed messages */
class BRAiVE_WheelSpeed :
public dev::can::CDecoder
{
public:
  BRAiVE_WheelSpeed();
  virtual ~BRAiVE_WheelSpeed();
  virtual void Initialize(const boost::property_tree::ptree& ptree , std::vector<data::CCANData::IDType>& ids);
  virtual StatusID Decode(const CCAN::FrameType& frame);
private:             
  std::vector<double> m_wheel_speeds; // FL, FR, RL, RR
  std::vector<data::CCANData::IDType> m_ids;
};

} // namespace decoders
} // namespace can
} // namespace dev

#endif /* CCANDECODER_SPEED_H_ */
