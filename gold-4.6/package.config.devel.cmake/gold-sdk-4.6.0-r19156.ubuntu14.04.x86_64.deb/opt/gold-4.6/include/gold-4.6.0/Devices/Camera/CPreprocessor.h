/**
 * \file Camera/CPreprocessor.h
 * \brief Class modeling a camera preprocessor node
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _PREPROCESSOR_H
#define _PREPROCESSOR_H

#include <map>

#include <boost/shared_ptr.hpp>

#include <Devices/Camera/CCameraPlugin.h>
#include <Data/CImage/CImage.h>
#include <UI/Panel/Widget.h>

namespace dev
{
class CCamera;
class CCameraMap;

namespace camera
{

/**
 * \brief Class representing a generic node of the camera preprocessor
 */
class GOLD_DEV_EXPORT CPreprocessorNode
{
public:


  /** \brief Alias for subnodes collection */
  // TODO: trasformare in vector
  typedef std::list<CPreprocessorNode> SubNodesType;

  CPreprocessorNode();  
  ~CPreprocessorNode();

  /** \brief Exception thrown when a node name is not found during a lookup */
  class name_not_found{};

  /** \brief Exception thrown when a node name is found during during a new insertion */
  class duplicated_name_found{};

  /** \brief Lazy initialization of the node */
  void Initialize();
  
  /** \brief Returns the node name */
  const std::string& Name() const;

  /**
   * \brief Changes the size of the current node source
   * \param source_image the new image to be used as source
   */
 void SetSource(const cimage::CImage::SharedPtrConstType source_image);

  /**
   * \brief Set a new value of the pixel aspect ratio
   * \param par the pixel aspect ratio (W/H)
   */
  void SetPAR(double par);  

  /**
   * \brief Set the node operation and instantiate the appropriate plugin
   * \param op Operation identifier
   * \param name name of the current node
   * \param params operation parameters
   */
  void SetOperation(const std::string& op, const std::string& name, const std::string& params="");


  /**
   * \brief Assign the camera to be controlled by the node
   * \param camera Camera to be controlled by the node
   */
  void Control(CCamera& camera);

  /**
   * \brief Connects the map of all the available cameras to the current node
   *
   * In this way the node can control other cameras
   * \param cameras CCameraMap containing all the camera instantiated
   */
  void  Connect(CCameraMap& cameras);

  /**
   * \brief Execute the plugin code using the argument image and
   * execute all the subnodes using the result of this node as input
   * \param image input image for the current node
   */
  void Execute(const cimage::CImage::SharedPtrConstType image);

  /**
   * \brief Adds a preprocessing subnode to the current node.
   * The node and the associated plugin are automatically deallocated.
   * \param preprocess subnode configuration string
   * \return pointer to the newly allocated node if instantiation succeeded,
   * otherwise an exception is thrown
   */
  CPreprocessorNode* Add(const std::string& preprocess);

  /**
   * \brief Remove a preprocessing subnode with specified name from the current node
   * If the node is not found in the current node, the look up continue recursively in every children
   * \param node_name name of the subnode to be removed
   */
  void Remove(const std::string& node_name);


  /**
   * \brief Returns a pointer to the node with the requested name
   * \param node_name Name of the node to be returned
   * \return pointer to the node if the name is found, 0 otherwise
   */
  CPreprocessorNode* find(const std::string& node_name);

  /**
   * \brief Return true if the node with specified name is found in the subnodes
   * \param node_name name of the node to be found
   * \return true if the node with specified name is present, false otherwise
   */
  bool HasNode(const std::string& node_name);

  /**
   * \brief Returns a const reference to the subnodes list of the current node
   * \return riferimento costante alla lista dei sottonodi
   */
  const SubNodesType& SubNodes() const;

  /**
   * \brief Returns the configuration string used to create the node
   * \return The configuration string
   */
  const std::string& ConfigString() const;

  /**
   * \brief Returns a shared const pointer to the image stored in the plugin map with identifier name
   * \param name Identifier associated to the image in the plugin map
   * \return The shared const pointer to the image
   */
  cimage::CImage::SharedPtrConstType Image(const std::string& name="") const;
  

  /**
   * \brief Returns the map of images produced by the internal plugin
   * \return the map of images produced by the internal plugin
   */
  const std::map<std::string, cimage::CImage::SharedPtrConstType >& Images() const;

  /**
   * \brief Returns a boost optional reference to the image stored in the plugin map with identifier name
   * \param name Identifier associated to the image in the plugin map
   * \return Reference to the image
   */
  boost::optional<ui::win::CWindowVisibilityProxy&> Window(const std::string& name="");
  
  /**
   * \brief Returns a reference to the CWindow of the plugin with the specified name
   * \param name Identifier associated to the CWindow in the plugin map
   * \return Reference to the CWindow
   */
  ui::win::CWindow& Wnd(const std::string& name="");

  static const std::string Root;  ///< Name of the root node, one for all the instances

  /** \brief Return true if the curren node is the root node of the preprocessing tree */
  bool IsRoot();
  
  /** \brief Returns a pointer to the parent node */
  CPreprocessorNode* Parent();
  
  /** \brief Panel of the current node, contains the plugin GUI */
  ui::wgt::Widget panel; // TODO: private
  
protected:
  
  /** \brief rename the current node using the argument string */
  void Rename(const std::string& name);

private:
  
  /** \brief Children can only be instantiated by the father */
  CPreprocessorNode(CPreprocessorNode* parent);

  /**
   * \brief Returns a pair containg: a pointer to the father and an iterator to the required subnode
   * \param node_name Name of the subnode to be found
   * \return pair containg: a pointer to the father and an iterator to the required subnode
   */
  std::pair<CPreprocessorNode*, SubNodesType::iterator>
    _find(const std::string& node_name);

  /** \brief Typedef for the tokenizer used for parameter parsing */
  typedef boost::tokenizer<boost::char_separator<char> > TokenizerType;

  /** \brief Instance of the char separator used for parameter parsing */
  static boost::char_separator<char> sep;
  
  std::string m_name; ///< Name of the current node

  double m_par;  ///< Pixel Aspect Ratio relative to the output of the current node
  float m_fps_factor; ///< Factor for throttling the input frame rate; es: 0.5 means that if the input goes at 10Hz, the output will be produced at 5Hz.
  float m_fps_counter; ///< Used internally for implementing the fps trotthling
  
  CCameraMap* m_pcameras; ///< List of the available cameras
  CCamera* m_pcamera;  ///< Camera owning the current node
  SubNodesType m_nodes;   ///< List of subnodes of the current node
  boost::shared_ptr<camera::Plugin> m_pplugin; ///< Shared pointer to the internal instance of the plugin
  std::string m_config_string;                ///< Configuration string
  
  CPreprocessorNode* m_parent; ///< Pointer to the parent node
};

} // namespace camera
  
} // namespace dev

#endif
