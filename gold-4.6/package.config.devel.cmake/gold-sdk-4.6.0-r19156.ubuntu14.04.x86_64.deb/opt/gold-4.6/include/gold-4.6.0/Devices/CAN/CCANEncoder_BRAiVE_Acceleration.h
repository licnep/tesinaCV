/**
 * \file CCANEncoder_BRAiVE_Acceleration.h
 * \brief CAN Encoder for sending Acceleration messages on BRAiVE
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Manuel Gargioni
 */

#ifndef CCANENCODER_ACCELERATION_H
#define CCANENCODER_ACCELERATION_H

#include "CCANEncoder.h"
#include "CCANEncoderRegistration.h"

namespace dev
{
namespace can
{
namespace encoder
{

/** \brief CAN Encoder for sending Acceleration messages on BRAiVE */
class BRAiVE_Acceleration :
  public dev::can::CEncoder
{
  public :
	  BRAiVE_Acceleration();
    virtual ~BRAiVE_Acceleration();
    virtual void Initialize(const boost::property_tree::ptree& ptree , std::vector<data::CCANData::IDType>& ids);
    virtual data::CCANData Encode(const boost::any& Dato);
    
  private :
    std::vector<data::CCANData::IDType> m_ids;
    data::CCANData m_can_data;

    struct Acceleration
    {
      bool auto_accel;
      float accel;
    };

    Acceleration m_new_data;
};

} // namespace encoder
} // namespace can
} // namespace dev

#endif // CCANENCODER_ACCELERATION_H
