/**
 * \file CCANDecoderRegistration.h
 * \brief Objects and macros for registering dev::can::CDecoder implementations
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Manuel Gargioni
 */

#ifndef CCANDECODERSREGISTRATION_H_
#define CCANDECODERSREGISTRATION_H_

#include <Libs/Patterns/Singleton.h>
#include <Libs/Patterns/Factory.h>
#include <Libs/Patterns/RegisterObject.h>

#include "CCANDecoder.h"

namespace dev
{
namespace can
{

/** \brief Factory for collecting decoders*/
typedef vl::Factory<std::string, dev::can::CDecoder> CDecodersFactoryType;

/** \brief Macro for registering decoders implementation */
#define REGISTER_CCANDECODER(DECODER, NAME) \
  GOLD_DEV_EXPORT vl::ObjectRegistrar< dev::can::CDecodersFactoryType, DECODER > drf_##DECODER(NAME);

} // namespace can
} // namespace dev

#endif /* CCANDECODERSREGISTRATION_H_ */
