/**
 * \file CROI.h
 * \brief Class for modeling a camera Region of Interest
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _CROI_H
#define _CROI_H

#include <string>

#include <Devices/gold_dev_export.h>

namespace dev
{
namespace camera
{
/**
 * \brief Class for modeling a camera Region of Interest
 */
class GOLD_DEV_EXPORT CRoI
{
  public:

    /** \brief Empty constructor to avoid pointers */
    CRoI();

    /** \brief Constructor to set the sensor Width/Height */
    CRoI(unsigned int W, unsigned int H);

    /** \brief Function to set the Rect boundaries */
    void SetRect(unsigned int left, unsigned int top, unsigned int right, unsigned int bottom) 
    {
      // TODO: preconditions
      m_left=left, m_top=top;
      m_left=right, m_top=bottom;
    }

    /** \brief Function to set the increments allowed for position and size */
    void SetIncrements(unsigned int dx, unsigned int dy, unsigned int dw, unsigned int dh);
  
    /** \brief Resize the RoI using a string */
    void Resize(const std::string& str);

    /** \brief Checks the equality of two RoIs */
    bool operator ==(const CRoI& roi);
  
    // print
    /** \brief Returns a string describing the sensor geometry in the format "WxH" in pixels */
    std::string StrSensor() const;

    /** \brief Returns the string describing the RoI rect in the format "Left,Top,Right,Bottom" in sensor coordinates */
    std::string StrRect() const;

    /** \brief Returns the string describing the RoI rect size in the format "WxH" in pixels*/
    std::string StrSize() const;
  
    /** \brief Operator for printing the content of a CRoI on a stream */
    GOLD_DEV_EXPORT friend  std::ostream & operator << (std::ostream& os, const CRoI& roi);
  
    // Accessors
    /** \brief Returns the RoI width in pixels */
    unsigned int Width()  const { return m_right-m_left+1; }

    /** \brief Returns the RoI height in pixels */
    unsigned int Height() const { return m_bottom-m_top+1; }

    /** \brief Returns the RoI left coordinate in pixels */
    unsigned int Left() const { return m_left; }

    /** \brief Returns the RoI top coordinate in pixels */
    unsigned int Top() const { return m_top; }

    /** \brief Returns the RoI right coordinate in pixels */
    unsigned int Right() const { return m_right; }

    /** \brief Returns the RoI bottom coordinate in pixels */
    unsigned int Bottom() const { return m_bottom; }

    /** \brief Returns the RoI Area in pixels */
    unsigned long Area() const { return Width()*Height(); }
  
    /** \brief Returns the sensor width in pixels */
    unsigned int SensorWidth() const { return m_w; }

    /** \brief Returns the sensor height in pixels */
    unsigned int SensorHeight() const { return m_h; }

  private:
    /** \brief Performs the RoI consistency check and throws an exception if something gores wrong */
    // TODO: return a value
    void ConsistencyCheck();    

    unsigned int m_w, m_h;          ///< Full sensor size
    unsigned int m_left, m_top;     ///< NO point (included)
    unsigned int m_right, m_bottom; ///< SE point (included)

    unsigned int m_hus,m_vus;       ///< Horizontal, vertical unit for RoI size 
    unsigned int m_hup,m_vup;       ///< Horizontal, vertical unit for RoI position
};

} // namespace camera
} // namespace dev

#endif
