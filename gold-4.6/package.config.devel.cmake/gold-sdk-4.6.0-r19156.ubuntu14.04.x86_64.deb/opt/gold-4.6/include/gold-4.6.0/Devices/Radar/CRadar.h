/**
 * \file CRadar.h
 * \brief Device modeling a profiler for the applications.
 *
 * The driver which provides this device device is instantiated by the engine.
 * There is no need to set up a dedicated section in the HWS
 * This device is always present with one and only one instance.
 *
 * \author Luca Gatti \<lucag@ce.unipr.it\>, Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _CRADAR_H
#define _CRADAR_H

#include <stdint.h>

#include <Data/CRadarScan/CRadarScan.h>
#include <Devices/Base/CSensor.h>
#include <Devices/Base/TFrame.h>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <Devices/gold_dev_export.h>

namespace dev
{

/**
 * \brief Device modeling a generic Radar
 */
class GOLD_DEV_EXPORT CRadar : 
  public dev::CSensor
{
  public:

    /** \brief Alias for the frame type; required by the infrastructure */
    typedef TFrame<data::CRadarScan> FrameType;

	/** \brief Alias for the signal type used to notify a new frame to the user */
#ifdef USE_BOOST_SIGNAL2
    typedef boost::signals2::signal< void ( const FrameType& Frame ) > SignalType;
#else
    typedef boost::signal< void ( const FrameType& Frame ) > SignalType;
#endif



	/** \brief Default constructor */
    CRadar();

	/** \brief Virtual destructor */
    virtual ~CRadar();

	/**
	 * \brief Register a callback that will be called every time a new data is captured.
	 *
	 * If the driver receive the data in a separate thread, the user function will be
	 * invoked from that thread.
	 */
    void Do_On_Frame_AsyncReceived ( boost::function<void ( const FrameType& )> slot );

  protected:
	/** \brief Returns the maximum number of points managed by the device */
    static const boost::uint32_t MaxNumPulses() { return boost::uint32_t ( 5000 ); }

	/** \brief Initialization code. \see CModule */
    void On_Initialization();

	/** \brief Shutdown code. \see CModule */
    void On_ShutDown();

	/** \brief Code called when device-specific parameters are saved. \see CModule */
    void On_SaveParams ( INIFile& ini );

	/** \brief Notify the user functions with the new captured data */
    void Notify_Frame_Received_Async ( const FrameType& frame );

	/** \brief Function performing the preprocessing */
    void Preprocessing(FrameType& frame);
    
    ui::wgt::Widget  panel;

  private:
    SignalType m_signal_async;    ///< Signal for synchronous notification of frames to the users

    data::TransformationType R;
};

} // namespace dev


#endif // _CRADAR_H
