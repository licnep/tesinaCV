/**
 * \file LUTSet.h
 * \brief Defines a structure for managing a set of Look-Up-Tables
 * \author Paolo Grisleri <grisleri@vislab.it>
 */


#ifndef LUTSET_H
#define LUTSET_H

#include <boost/filesystem/path.hpp>

#include <string>
#include <map>

#include <Devices/gold_dev_export.h>

namespace vl{ class CVarReplacer; }
namespace vl{ namespace ini {class INIFile;} } using vl::ini::INIFile;


namespace dev
{

/**
 * \brief Class describing a LUT.
 */
struct GOLD_DEV_EXPORT LUTEntry
{
    std::string native; ///< The native string indicatyng the path (this may contains unexpanded variables)
    boost::filesystem::path expanded; ///< The path (variables are expanded here) of the LUT
};
typedef std::map<std::string, LUTEntry> LUTMap;


namespace impl
{

/** \brief Class for managing a set of LUT */
class GOLD_DEV_EXPORT LUTSet
{
public:
	/** \brief Default constructor */
    LUTSet();

    /**
     * \brief Loads a LUT set from file
     * \param [in] ini the configuration file were load the LUTs
     * \param [in] vrep the CVarReplacer containing the variable to be expanded
     */
    void Load(const INIFile& ini,const vl::CVarReplacer& vrep);


    /**
     * \brief Save a LUT set to a configuration file and save the LUTs in the specified path
     * \param [in] ini the configuration file were to save the LUTs
     * \param [in] path path where the LUTs will be saved
     */
    void Save(INIFile& ini, const boost::filesystem::path& path);

    /** \brief Returns the internal map containing the LUTEntry */
    LUTMap   LUTs() const;

    /** \brief Returns a specific LUTEntry with name specified by the argument */
    LUTEntry LUT(const std::string& name) const;
private:
    LUTMap m_lut_map; ///< Internal LUT map
};

} // namespace impl

} // namespace dev

#endif // LUTSET_H
