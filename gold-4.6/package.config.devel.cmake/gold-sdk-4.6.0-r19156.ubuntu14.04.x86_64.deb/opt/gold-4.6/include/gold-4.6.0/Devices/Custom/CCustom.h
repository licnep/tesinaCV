/**
 * \file CCustom.h
 * \brief Device with a custom implementation.
 *
 * In some cases it may be necessary to implement a device with custom code
 * placed in an application or in an external driver. This can be usesful when
 * the device needed is someting not general, such as a rare bus, for which
 * building a dedicated data-device-driver set would be a not efficient effort.
 *
 * This kind of device works on strings, so there is no correspondent CCustomData.
 *
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _DEV_CUSTOM_H
#define _DEV_CUSTOM_H

#include <string>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <Devices/Base/CSensor.h>
#include <Devices/Base/TFrame.h>
#include <UI/Panel/Widget.h>

#include <Devices/gold_dev_export.h>

namespace dev
{

/** \brief Class modeling a device where the implementation is in user space.
 *
 * Some special applications require to interact with external devices for which it does'n worth
 * to write a dedicated driver. Examples of these devices are:
 * - dedicated bus
 * - network connections transferring custom protocols
 * - serial connections with custom protocols
 * In all these cases it might be more convenient to write a custom driver.
 * The driver code can be included in an external driver (the DDK package is required) or
 * in an external application.
 * 
 * All the recording functionalities of a real driver are supported.
 * There is a special driver for playing back the data recorded with this kind of driver.
 *
 * The driver needs to be instantiated in the HWS file exactly as any other.
 *
 * Example of code showing how to register the custom callback set from user code
 * \code
 * // in the user space (eg application or external driver)
 * dev::CCustom::Callbacks cb;
 *
 * cb.on_initialization = boost::bind(my_on_initialization);
 * cb.on_shutdown = boost::bind(my_on_shutdown);
 * cb.on_wake_up = boost::bind(my_on_wakeup);
 * cb.on_suspend = boost::bind(my_on_suspend);
 *
 * dev::CCustom& customdev = Dev()["Custom_device"];
 * customdev.RegisterCallBacks(cb);
 * // from here, the device will start to react to the events
 * // for example when the play button is pressed, the
 * // my_on_wakeup function is called
 *
 * \endcode
 *
 *
 * To interact with external hardware, usually an external set of functions, such as a thread
 * which waits for reading and writing to the physical devices, need to be set up.
 *
 * The thread can be started and destroyed every time the dev::CCustom::Callbacks::on_wake_up and
 * dev::CCustom::Callbacks::on_suspend are executed, or when the On_Initialization of the application
 * is triggered.
 *
 * The thread needs to notify the device when a data is ready using the Notify method
 * Example:
 * \code
 *
 * class ApplicationDefinedDevice
 * {
 * public:
 *     void load_params(const IniFile& ini, hws::Version version) {}
 *     void save_params(IniFile& ini, hws::Version version){}
 *     void recording_save_params(IniFile& ini){}
 *     void initialization() { std::cout << "This is initialization" << std::endl; }
 *     void shutdown() { std::cout << "this is shutdown " << std::endl; }
 *     void suspend() { m_loop = false; }
 *     void wakeup()
 *     {
 *        // in playback mode the thread is not created
 *        m_loop=true;
 *        if(m_mode == HARDWARE)
 *            boost::thread(boost::bind( &ApplicationDefinedDevice::thread, this, pctm, pclk ));
 *    }
 *
 *   void Register(ModeID mode, dev::CDeviceManager& dev)
 *   {
 *   	  // get an handler to the device using the device manager
 *        dev::CCustom& ctm = dev["XX/C1"];
 *        dev::CClock& clk = dev["Clock"];
 *
 *        pctm = &ctm;
 *        pclk = &clk;
 *
 *        m_mode = mode;
 *
 *        dev::CCustom::Callbacks cbs;
 *
 *        cbs.on_load_params = boost::bind (&ApplicationDefinedDevice::load_params, this, _1, _2);
 *        cbs.on_save_params = boost::bind (&ApplicationDefinedDevice::save_params, this, _1, _2);
 *        cbs.on_recording_save_params = boost::bind (&ApplicationDefinedDevice::recording_save_params, this, _1);
 *        cbs.on_initialization = boost::bind (&ApplicationDefinedDevice::initialization, this);
 *        cbs.on_shutdown = boost::bind (&ApplicationDefinedDevice::shutdown, this);
 *        cbs.on_wakeup = boost::bind (&ApplicationDefinedDevice::wakeup, this);
 *        cbs.on_suspend = boost::bind (&ApplicationDefinedDevice::suspend, this);
 *        ctm.RegisterCallBacks(cbs);
 *    }
 *
 *    dev::CCustom& Dev() {return *pctm; };
 *    private:
 *
 *    // this is the thread method interacting with the custom hardware
 *    void thread(dev::CCustom* ctm, dev::CClock* clk)
 *    {
 *        dev::CCustom::FrameType frame;
 *        while(m_loop)
 *        {
 *            // in this example no interaction is actually done
 *            // we just fill a string with an increasing counter and time
 *            frame.Data.clear();
 *            frame.Data += "counter=" + boost::lexical_cast<std::string>(++counter);
 *            frame.Data += " time=" + boost::lexical_cast<std::string>(clk->SumActive());
 *            frame.TimeStamp = clk->SumActive();
 *
 *			  // an optional log for showing the content of the captured frame
 *            // log_info << "zzz \"" << frame.Data << "\"" << std::endl;
 *
 *			  // notifies the device of the frame captured
 *            pctm->Notify(frame);
 *
 *            // works at 10Hz in order to avoid flooding the CPU
 *            boost::this_thread::sleep(boost::posix_time::milliseconds(100));
 *        }
 *    }
 *
 *    boost::thread m_thread;
 *    ModeID m_mode;
 *    bool m_loop;
 *    dev::CCustom* pctm;
 *    dev::CClock* pclk;
 *    uint64_t counter;
 * };
 *
 * ApplicationDefinedDevice app_dev;
 *
 * // this is the callback registered by the application to receive the captured data
 * // the synchronizer can be used as well
 * void DataCallBack(const dev::CCustom::FrameType& frame)
 * {
 *     std::cout << "data received: " << frame.Data << std::endl;
 * }
 *
 *
 *
 * void CDummy::On_Initialization()
 * {
 *    ////////////////////////////////////////////////////////////////////////////
 *    // Application side custom device example
 *    ////////////////////////////////////////////////////////////////////////////
 *    try
 *    {
 *        app_dev.Register( HARDWARE, Dev());
 *        app_dev.Dev().Do_On_Frame_AsyncReceived ( boost::bind(DataCallBack, _1) );
 *    }
 *    catch(...)
 *    {
 *        std::cout << "custom device not found" << std::endl;
 *    }
 *    ////////////////////////////////////////////////////////////////////////////
 *    // ... here continue the rest of the CApplication code
 * \endcode
 */
class GOLD_DEV_EXPORT CCustom: public CSensor
{
public:

	/** \brief structure containing a callback set that can be registered in this device */
	struct Callbacks
	{
		/** \brief Callback called when the device specific parameter set needs to be loaded */
		boost::function<void(const INIFile&, hws::Version)> on_load_params;

		/** \brief Callback called when the device specific parameter set needs to be saved */
		boost::function<void(INIFile& ini, hws::Version)> on_save_params;

		/** \brief Callback called when, after a recording, the device specific parameter set needs to be saved in the recording*/
		boost::function<void(INIFile& ini)> on_recording_save_params;

		/** \brief Callback called when, the initialization code needs to be executed */
		boost::function<void()> on_initialization;

		/** \brief Callback called when, the shutdown code needs to be executed */
		boost::function<void()> on_shutdown;

		boost::function<void()> on_wakeup;
		boost::function<void()> on_suspend;
	};

	/** \brief Virtual destructor */
	virtual ~CCustom();

	/** \brief Alias FrameType, required by the device infrastructure */
	typedef TFrame<std::string> FrameType;

	/**
	 * \brief Method for registering the user callbacks in the device
	 * \param cbs Callback to be used by the current device
	 * */
	void RegisterCallBacks( Callbacks cbs );

	/** \brief type of the signal used for notifying the frame capture */
#ifdef USE_BOOST_SIGNAL2
	typedef boost::signals2::signal<void(const FrameType& Frame)> SignalType;
#else
	typedef boost::signal<void(const FrameType& Frame)> SignalType;
#endif

	/**
	 * \brief Register a callback which is called every time the device receive a frame.
	 *
	 * The callback is invoked in the same thread where the Notify function is called.
	 * For example, if the data capture and the Notify are placed in a separate thread
	 * the callback will be invoked from that thread
	 */
	void Do_On_Frame_AsyncReceived(
			boost::function<void(const FrameType& Frame)> cb);

	/**
	 * \brief Method to be called by the capture function to notify the device and the
	 * user callbacks that a new data has been captured.
	 * \brief frame captured frame: a buffer needs to be allocated in user space.
	 */
	virtual void Notify(const FrameType& frame)=0;

protected:

	/** \brief Loads the generic parameters associated to the current device */
	void LoadParams(const INIFile& ini, hws::Version version);

	/** \brief Saves the generic parameters associated to the current device */
	void SaveParams(INIFile& ini, hws::Version version = hws::V_1_1);

	/** \brief Saves the generic parameters associated to the current device, in a recording */
	void Recording_SaveParams(INIFile& ini);

	/** \brief Initialization code \see CModule */
	void On_Initialization();

	/** \brief Shutdown code \see CModule */
	void On_ShutDown();

	/** \brief WakeUp code \see CModule */
	void On_WakeUp();

	/** \brief Shutdown code \see CModule */
	void On_Suspend();

	/** \brief Notify the reception of a frame to the user data received callbacks */
	void Notify_Frame_Received_Async(const FrameType& frame);

private:

	SignalType m_signal_async; ///< Signal to notify the data received callbacks
	Callbacks m_callbacks;     ///< Set of boost functions containing the
};

} // namespace dev

#endif // _DEV_CUSTOM_H
