/**
 * \file TAR_Archive.h
 * \brief Classes for reading and writing files encoded with the TAR format
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

/*
 * Copyright (c) Ian F. Darwin 1986-1995.
 * Software written by Ian F. Darwin and others;
 * maintained 1995-present by Christos Zoulas and others.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice immediately at the beginning of the file, without modification,
 *    this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/*
 * Header file for public domain tar (tape archive) program.
 *
 * @(#)tar.h 1.20 86/10/29      Public Domain.
 *
 * Created 25 August 1985 by John Gilmore, ihnp4!hoptoad!gnu.
 *
 * $File: tar.h,v 1.11 2007/01/16 14:56:45 ljt Exp $ # checkin only
 */
  

#ifndef _T_ARCHIVE
#define _T_ARCHIVE

#include <fstream>
#include <stdint.h>
#include <cstring>
#include <map>

#include <boost/filesystem/path.hpp>
#include <boost/function.hpp>

#include <Devices/gold_dev_export.h>


/** \brief Classes for managing TAR files */
namespace tar
{

#pragma pack(push)
#pragma pack(1)

/**
 * \brief Header of an entry in a tar file
 */
struct GOLD_DEV_EXPORT FileHeader
{
	/** \brief Default constructor clean up all the fields */
    FileHeader();

    uint64_t evt_key;   ///< Event key
    char     evt_id[32];///< Event identifier
    uint64_t frame_num; ///< Frame number
    char     name[100]; ///< File name
    std::streamoff offset; ///< Offset
    std::streamoff size; ///< Size
};
#pragma pack(pop)

/**
 * \brief Class for reading a TAR file
 */
class GOLD_DEV_EXPORT Reader
{
public:
	/** \brief Typedef for the decoded Index */
    typedef std::map<std::string,  FileHeader> IndexType;  

    /**
     * \brief Open a TAR file.
     * \param path the pathname of the file to be open
     * \param id NOT USED
     * \return boost::system::error_code boost::system::errc::success if success,
     * otherwise: boost::system::errc::no_such_file_or_directory if the file cannot be open
     */
    boost::system::error_code Open(const boost::filesystem::path& path, const std::string& id);

    /**
     * \brief Seeks a specific filename in the tar file.
     * \param file_name file to search inside the TAR.
     * \return if the requested filename is found boost::system::errc::success is returned,
     * otherwise:
     * boost::system::errc::not_connected if the file is not open,
     * boost::system::errc::invalid_seek if the filename is not found
     */
    boost::system::error_code Seek(const std::string& file_name);
    
    /** \brief Returns and handle to the internal stream to read the seeked file */
    std::istream& ISTR();
    
private:
    IndexType      m_index;  /// Index. TODO: remove
    std::ifstream  m_ifs;    ///< internal stream
    uint64_t       m_curr_frame_number; ///< current frame number
};


/**
 * \brief Class for writing a TAR file
 */
class GOLD_DEV_EXPORT Writer
{
public:
	/** \brief Typedef for the Index */
    typedef std::map<std::string,  FileHeader> IndexType;  

    /**
     * \brief Open a TAR file.
     * \param path the pathname of the file to be open
     */
    void Open(const boost::filesystem::path& path);

    /** \brief Return true if the file is open, false otherwise */
    bool IsOpen() const;

    /**
     * \brief Write a file in the currently open TAR
     * \param file_name name of the file to be written in the index
     * \param save_func user side function for writing the file
     */
    void Write(const std::string& file_name, boost::function<void (std::ofstream&)> save_func);

private:
    std::ofstream  m_ofs;   ///< internal stream
    static boost::shared_ptr<char> padding; ///< padding structure
    static std::string uname; ///< username to be used in the tar file
    static std::string gname; ///< groupname to be used in the tar file
};

} // namespace tar

#endif //  _T_ARCHIVE
