#ifndef _CSAMPLER_H
#define _CSAMPLER_H

/**
 * \file Devices/Base/CSampler.h
 * \brief  Abstract class device that can sample data like sensors and buses
 * \author Paolo Grisleri (grisleri\vislab.it)
 * \date 2010-06-20
 * Every CSensor contains a sampler and provides a method for accessing it.
 */

#include <string>

#include <Libs/Time/TimeUtils.h>
#include <Libs/Time/CChronometer.h>

#include <Devices/gold_dev_export.h>


namespace dev
{

/**
 * \addtogroup Devices
 * \{
 **/

/**
 * \brief Interface providing sampling information related to a certain sensor.
 * This class is responsible of providing user accessible sampling information related to a certain sensor.
 * Each sensor contains a Sampler ad update it every time a new data is collected
 * When the user need to access the information stored in the sensor sampler this class is the appropriate interface
 */
class GOLD_DEV_EXPORT CSampler
{
  public:

	/**
	 * \brief Type for counters
	 */
    typedef uint64_t CounterType;
    
    /**
     * \brief Type for the internal accumulator
     */
    typedef vl::chrono::Accumulator AccumulatorType;    

    /**
     * \brief returns the frame number.
     * The frame number is a unique identifier for each frame in a track
     * This data is valid only in PlayBack mode.
     * Different tracks may have the same frame number. The same frame always has the same framenumber.
     * \return [out] CounterType containing the framenumber of the last acquired data for the current track
     */
    virtual CounterType FrameNumber() const = 0;

    /**
     * \briefs returns the number of captured samples
     * This is an always increasing number.
     * \return CounterType containing the number of captured samples
     */
    virtual CounterType FrameCounter() const = 0;


    /**
     * \briefs returns the number of captured samples
     * This is an always increasing number.
     * This is just a different name for the FrameCounter method-
     * \return CounterType containing the number of captured samples
     */
    virtual CounterType NumSamples() const = 0;

    /**
     * \briefs returns the virtual origin of the current track
     * Virtual origin is the absolute time when the track has been
     * recorded (PlayBack Mode) or the acquisition has been started (Hardware Mode)
     * \return AbsoluteTimeType containing the Virtual Origin Time
     */
    virtual const vl::chrono::AbsoluteTimeType& VirtualOrigin() const = 0;

    /**
     * \briefs returns the TimeStamp of the last data captured
     * TimeStamp is referred to the virtual Origin
     * \return TimeType timestamp of the last captured data
     */
    virtual const vl::chrono::TimeType& TimeStamp() const = 0;

    /**
     * \briefs returns the Duration of the last data captured (NOT SUPPORTED)
     * This method is here for future implementations
     * \return TimeType duration of the last captured data
     */
    virtual const vl::chrono::TimeType& Duration() const = 0;
    
    /**
     * \brief returns the time difference between the last two captured data
     * This value can be used to calculate frequency or to see if
     * a data is too far in time for being processed
     * \return TimeType: the time difference between the last two captured data
     */
    virtual const vl::chrono::TimeType& LastDelta() const = 0;    
    
    /**
     * \brief returns true if the last delta is valid, false otherwise
     * Last Delta can be invalid for example if play has just been has been pressed
     * \return bool: true if LastDelta is valid
     */
    virtual bool IsLastDeltaValid() const = 0;
    
    /**
     * \brief user read-only access to the internal accumulator
     * The accumulator contains time statistics on the user sample
     * These statistics include counting, mean, min, max and variance.
     * \return AccumulatorType, see boost::accumulators library doc
     */    
    virtual const AccumulatorType& Accumulator() const = 0;
    
    /**
     * \brief returns the average framerate of the captured samples
     * \return TimeType: frame rate of the captured samples
     */    
    virtual double Avg_FrameRate() const = 0;
    
    /**
     * \brief Prints the statistics of the accumulator with a specified indentation
     */
    virtual void Print(const AccumulatorType& acc, unsigned int indent=2) const = 0;
};

/**\}**/

} // namespace dev

#endif // _CSAMPLER_H
