/**
 * \file CCamera.h
 * \brief Device modeling a generic camera
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _CCAMERA_H
#define _CCAMERA_H

#include <string>
#include <map>
#include <list>

#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string/classification.hpp>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif


#include <Data/Base/CCameraParams.h>
#include <Data/CImage/CImage.h>
#include <Devices/Base/CSensor.h>
#include <Devices/Base/LUTSet.h>
#include <Devices/Base/TFrame.h>
#include <Devices/Camera/CROI.h>

#include <UI/Panel/Widget.h>

#include "CCameraProperty.h"



namespace vl{ namespace ini {class INIFile;} } using vl::ini::INIFile;
class CFrameCounter;
namespace vl { class CVarReplacer; }

namespace dev
{

namespace camera {class CPreprocessorNode;}

/**
 * \brief Device modeling a generic camera
 *
 * This class models a physical camera device that can be used inside 
 * applications. A method to get camera parameters is available as well as 
 * another for registering a callback to get the frames. The camera has a 
 * preprocessor that can be set at configuration time or using an API
 * The output of the camera can be set to be one of the preprocessor nodes.
 * The camera is configured in the HWS file.
 */
class GOLD_DEV_EXPORT CCamera: public CSensor
{
public:
	/**
	 * \brief The frame type provided by this device is a shared pointer to a CImage
	 */
	typedef TFrame<cimage::CImage::SharedPtrConstType> FrameType;


	/** \brief Default constructor */
	CCamera();

	/** \brief Virtual destructor */
	virtual ~CCamera();

	/**
	 * \brief Returns camera parameters
	 * \tparam T the floating type specified by the template argument
	 * \see TCameraParams
	 */
	template<typename T>
	TCameraParams<T> Params() const
	{
		TCameraParams<T> dst;

		// short names for camera parameters  types
		typedef typename TCameraParams<T>::uinteger_type cp_uint_type;
		typedef typename TCameraParams<T>::floating_type cp_float_type;

		dst.width = m_src_frame.Data->W();
		dst.height = m_src_frame.Data->H();

		dst.u0 = m_opt_cx;
		dst.v0 = m_opt_cy;

		dst.ku = m_ku;
		dst.kv = m_kv;

		dst.x = X();
		dst.y = Y();
		dst.z = Z();

		dst.yaw = Yaw();
		dst.pitch = Pitch();
		dst.roll = Roll();

		return dst;
	}

	/**
	 * \brief Returns camera parameters using the default floating type
	 */
	CameraParams Params() const;

	/**
	 * \brief Set the optical center of the camera to specified values
	 * \param [in] cx X coordinate of the optical center: belongs to [0, SrcFrame->W()]
	 * \param [in] cy Y coordinate of the optical center: belongs to [0, SrcFrame->W()]
	 */
	void SetOpticalCenter(double cx, double cy);

	/**
	 * \brief Set the pixel focal length to specified values
	 */
	void SetFocalLength(double ku, double kv);

	/**
	 * \brief Returns the current Region of Interest
	 * \see CRoI
	 */
	const dev::camera::CRoI& RoI() const;

	/**
	 * \brief Add a preprocessing node to the preprocessing tree
	 * \param preproc_str the preprocessing configuration string
	 * \code
	 * // adds a debayer filter node named X to the preprocessing tree
	 * m_camera->Preprocess_Add("DeBayer X Source Simple");
	 * \endcode
	 */
	void Preprocess_Add(const std::string& preproc_str);

	/**
	 * \brief Delete a preprocessing node to the preprocessing tree
	 * \param name the preprocessing node name
	 * \code
	 * // remove the node X from the preprocessing tree
	 * m_camera->Preprocess_Del("X");
	 * \endcode
	 */
	void Preprocess_Del(const std::string& name);

	/**
	 * \brief Returns a specified preprocessor node
	 * \param name name of the note to find
	 * \return The Node found. If the requested node is not found the returned value is 0
	 */
	camera::CPreprocessorNode* Preprocess_Find(const std::string& name);

	/**
	 * \brief Returns the preprocessor output node
	 * \return The Node current output node
	 */
	camera::CPreprocessorNode* Preprocess_OutNode();

	/**
	 * \brief Return the available preprocessing node list
	 * \return the list of all available nodes
	 */
	const std::list<std::string>& Sources() const;

	/**
	 * \brief Returns a list filled with the available preprocessor plugins
	 * Returns a list filled with the names of the plugins that can be instantiated
	 * \returna list filled with the available preprocessor plugins
	 */
	const std::list<std::string>& Plugins() const;

	/**
	 * \brief Set one of the existing preprocessor nodes as default output for the camera
	 * \param name Node to be used as output
	 */
	void SetAsOut(const std::string& name);

	/**
	 * \brief Set one of the existing preprocessor nodes as default recording output
	 * \param name Name of the node to be used as output for recording
	 */
	void SetAsRecOut(const std::string& name);

	/**
	 * \brief Returns the list of the currently available video properties
	 * \see camera::VideoProperty
	 */
	const camera::VideoPropertiesList& VideoProperties() const;

	/**
	 * \brief Typedef for an optional property.
	 *
	 * This type can be evaluated as bool. \see boost::optional
	 */
	typedef boost::optional<camera::VideoProperty&> OptPropertyType;

	/**
	 * \brief Returns boost::optional to a requested video property
	 * \param name The property name
	 * \return boost::optional for a reference to the property
	 */
	OptPropertyType VideoProperty(const std::string& name);

	/**
	 * \brief Set a video property attribute to the specified value
	 * \param path std::string containing the path of the requested property
	 * \param value value to be assigned to the property
	 */
	template<typename T>
	void SetVideoPropAttribute(const std::string& path, const T& value);

	/**
	 * \brief Get the value of a specified video property attribute
	 * \param path std::string containing the path of the requested property
	 * \param ret_val value read from the property
	 */
	template<typename T>
	void GetVideoPropAttribute(const std::string& path, T& ret_val);

	/**
	 * \brief Callback type for a frame received from a camera
	 */

#ifdef USE_BOOST_SIGNAL2
	typedef boost::signals2::signal<void(const FrameType& frame)> SignalType;
#else
	typedef boost::signal<void(const FrameType& frame)> SignalType;
#endif


	/**
	 * \brief Register a callback called each time the camera receive a frame
	 * If the acquisition happens in a separated thread, the callback is called
	 * in that thread each time an image is captured.
	 * NOTE: this call is not necessarily executed in the same thread of the application
	 * \param cb the callback to be called each time a frame is captured
	 */
	void Do_On_Frame_AsyncReceived( boost::function<void(const FrameType& frame)> cb );

	/**
	 * \brief Returns the pixel aspect ratio of the source image
	 */
	double PixelAspectRatio() const;

	/**
	 * \brief Returns the map of the lookup tables specified in the configuration file
	 * This method returns a map where the key is the part of the LUT key specified in the HWS file
	 * and the value is the filename specified for the corresponding key.
	 * Example of HWS file:
	 * \code
	 * [SECTION CAMERAS]
	 * 	[SECTION A]
	 * 		# ...
	 * 		LUT A = /path/to/my/LUT.blt
	 * 	[END]
	 * [END]
	 * \endcode
	 * 
	 * In this case the map will contain one element with first="A" and second="/path/to/my/LUT.blt"
	 */
	LUTMap LUTs() const;

	/**
	 * Returns one of the look up tables tables specified in the configuration file
	 * If the specified LUT does not exists an emtpy string is returned
	 */
	LUTEntry LUT(const std::string& name) const;

	/**
	 * DEPRECATED: this method is deprecated since the meaning of the operator << is ambiguous
	 */
	GOLD_DEV_DEPRECATED friend void operator <<(CameraParams& dst,
			const CCamera& camera);

	/**
	 * DEPRECATED: this method is deprecated since the meaning of the operator << is ambiguous
	 */
	GOLD_DEV_DEPRECATED friend void operator <<(CameraParams& dst,
			const CCamera* camera);

protected:

	/**
	 * \brief Add a video property to the camera
	 * \param PropertyName Reference to the Video property Name
	 * \param VideoProperty Reference to the camera video property
	 * \return the reference to the added video property
	 */
	void AddVideoProperty(camera::VideoProperty::ShPtrType sp_vp);

	/**
	 * \brief Destroy all video properties.
	 *
	 * To be executed in during the shutdown
	 * before resource deallocation
	 */
	void ClearVideoProperties();

	/**
	 * \brief Returns a shared pointer to the source frame
	 * \return A reference to the source frame
	 */
	cimage::CImage::SharedPtrConstType SrcFrame() const
	{
		return m_src_frame.Data;
	}

	/**
	 * \brief Returns a shared pointer to the frame used for recording
	 * \return A shared pointer to the recording frame
	 */
	cimage::CImage::SharedPtrConstType RecOutFrame() const;

	/**
	 * \brief Notifies a frame received to the registered callbacks
	 * \return A reference to the source frame
	 */
	void Notify_Frame_Received_Async(const FrameType& frame);

	/**
	 * \brief Collects the names of the preprocessing nodes that can be used as source
	 */
	void CollectSources();

	/**
	 * \brief Collects the names of the preprocessing nodes that can be used as source
	 */
	void CollectSources(const camera::CPreprocessorNode& node,
			            std::list<std::string>& sources);

	void On_Initialization();
	void On_ShutDown();

	void LoadParams(const INIFile& ini, hws::Version version);
	void SaveParams(INIFile& ini, hws::Version version = hws::V_1_1);

	void LoadLUTs(const INIFile& ini, const vl::CVarReplacer& vrep);
	void SaveLUTs(INIFile& ini, const boost::filesystem::path& path);

	/**
	 * \brief Set the current Region of Interest
	 * TODO public?
	 */
	void SetRoI(const dev::camera::CRoI& roi);

	// TODO: callback for notifying to the user a ROI change

	/**
	 * \brief Virtual function called whenever the Region of interest changes
	 * TODO: boost::signals, remove virtual
	 */
	virtual void On_RoIChanged(dev::camera::CRoI& roi);

	/**
	 * \brief Preprocess the frame argument
	 * \params frame Frame to be preprocessed
	 */
	void Preprocess(const FrameType& frame);

	// FIXME private
	camera::CPreprocessorNode* m_preprocessor; ///< Pointer to the preprocessor tree

	FrameType m_src_frame; ///< The source frame, captured by the driver
	FrameType m_out_frame; ///< The output frame, passed to the applications
	FrameType m_rec_frame; ///< The recording frame, saved when recording is active

	ui::wgt::Widget panel; ///< Camera panel containing the run-time modifiable options

	camera::CPreprocessorNode* m_out_node;     ///< Output preprocessor node
	camera::CPreprocessorNode* m_rec_out_node; ///< Output for recording

private:
	double m_ku, m_kv;           ///< Focal length in pixel units
	double m_opt_cx, m_opt_cy;   ///< Optical Center

	std::string m_poly_dist, m_inv_poly_dist; ///< lens distortion coefficient

	camera::VideoPropertiesList m_video_props; /// Video Properties

	std::list<std::string> m_sources; ///< Names of the available preprocessing nodes

	SignalType m_signal_async; ///< Signal for notifying frames to the registered callbacks

	dev::camera::CRoI m_roi; ///< The region of interest

	/**
	 * \brief List of the currently available plugins
	 */
	// TODO: convert to a pluginenumerator capable of registering and give the services list
	mutable std::list<std::string> m_plugin_list;

	dev::impl::LUTSet m_luts; ///< Collection of the look up tables loaded for this camera

	std::string m_str_fb; ///< String version of the frame buffer

	double m_pixel_aspect_ratio; ///< Pixel Aspect Ratio of the output image
};

 // TODO: integrate in a single component capable of iterating fast as a list
 // with the insertion efficiency of a map, such as boost::multi_index
class CCameraMap;



/**
 * \brief Class for modeling a map of cameras
 * This is needed from the preprocessor of one camera 
 * to access and control the others
 */
class GOLD_DEV_EXPORT CCameraMap: public std::map<std::string, CCamera *>
{
public:
	CCameraMap();
	// CCameraMap(const dev::CCameraList& cameras);
	CCamera* operator[](const std::string& camera_name);
	bool Has(const std::string& CameraName) const;
	friend std::ostream& operator <<(std::ostream& os,
			const CCameraMap& camera_map);
};

/**
 * \brief Class to describe a video stream
 *
 * This class is now DEPRECATED. 
 */
struct GOLD_DEV_DEPRECATED CVideoStreamDescriptor
{
	std::string url;

	// mplayer&  co. do not need these info
	unsigned int w, h;
	double frame_rate;
};

/**
 * \brief Method to set the value of a specified video property attribute
 * \param path the path of the video property attribute
 * \param ret_val the value to be set
 */
template<typename T>
void CCamera::SetVideoPropAttribute(const std::string& path, const T& value)
{
	// path tokenization
	std::vector<std::string> split_path;
	boost::split(split_path, path, boost::is_any_of("./|"));

	try
	{
		const dev::CCamera::OptPropertyType& vp = VideoProperty(split_path[0]);
		if (vp)
		{
			dev::camera::VideoProperty::OptAttribType oa = vp->Attribute(
					split_path[1]);

			if (oa)
			{
				switch (oa->TypeID())
				{
				case dev::camera::videoprop::Attribute::at_uint32:
					*(oa) = (uint32_t) value;
					break;
				case dev::camera::videoprop::Attribute::at_float:
					*(oa) = (float) value;
					break;

				default:
					std::cout << "Gain type not handled" << std::endl;
					break;
				}
			}
			else
			{
				std::cout << "Attribute " << path << " not found "
						<< " from camera " << Name() << std::endl;
			}
		}
		else
		{
			std::cout << "Property " << split_path[0] << " missing from camera "
					<< Name() << std::endl;
		}
	} catch (const std::runtime_error& err)
	{
		std::cout << " Exception: " << err.what() << std::endl;
	} catch (...)
	{
		std::cout << "Unknown exception: " << std::endl;
	}
}

/**
 * \brief Method to get the value of a specified video property attribute
 * \param path the path of the video property attribute
 * \param ret_val the returned value
 */
template<typename T>
void CCamera::GetVideoPropAttribute(const std::string& path, T& ret_val)
{
	// path tokenization
	std::vector<std::string> split_path;
	boost::split(split_path, path, boost::is_any_of("./|"));

	try
	{
		const dev::CCamera::OptPropertyType& vp = VideoProperty(split_path[0]);
		if (vp)
		{
			dev::camera::VideoProperty::OptAttribType oa = vp->Attribute(
					split_path[1]);

			if (oa)
			{
				switch (oa->TypeID())
				{
				case dev::camera::videoprop::Attribute::at_uint32:
					ret_val = (uint32_t) *(oa);
					break;
				case dev::camera::videoprop::Attribute::at_float:
					ret_val = (float) *(oa);
					break;

				default:
					std::cout << "Gain type not handled" << std::endl;
					break;
				}
			}
			else
			{
				std::cout << "Attribute " << path << " not found "
						<< " from camera " << Name() << std::endl;
			}
		}
		else
		{
			std::cout << "Property " << split_path[0] << " missing from camera "
					<< Name() << std::endl;
		}
	} catch (const std::runtime_error& err)
	{
		std::cout << "  std::runtime_error catched: " << err.what()
				<< std::endl;
	} catch (...)
	{
		std::cout << " other stuff " << std::endl;
	}
}

/** \brief Namespace containing classes and functions for managing camera devices */
namespace camera
{
} // namespace camera

} // namespace dev

#endif

