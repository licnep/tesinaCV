/**
 * \file CGNSS.h
 * \brief Device modeling a generic Global Navigation Satellite System (GNSS)
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Paolo Medici\<grisleri@ce.unipr.it\>
 */

#ifndef __CGNSS_H
#define __CGNSS_H

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <Data/CGNSSData/CGNSSData.h>
#include <Devices/Base/CSensor.h>
#include <Devices/Base/TFrame.h>

namespace dev
{

/**
 * \brief Device modeling a generic Global Navigation Satellite System (GNSS)
 *
 * The device can be used registering a callback function which is called
 * every time the physical device receive a new CGNSSData.
 *
 * Otherwise, the GetCGNSSData() method called directly on the device returns
 * the last captured CGNSSData.
 * Using this second method, it may happens that the application runs faster than
 * the update rate of the GNSS unit. In this case it is possible to check if the
 * data has not been updated by checking if the the values of the m_TimeStampUTC
 * time stamps are equal.
 *
 * When the status field of the returned CGNSSData is false then one of the following conditions is true:
 * - no data has been read, maybe because the unit is off or no satellites have been found
 * - the connection with the GNSS unit has been closed; in this case all the fields have 0 value.
 *
 * This device deals with CGNSSData.
 *
 *	Code example for the application header file
 *  \code
 *  #include <Devices/CGNSS/CGNSS.h>
 *
 *	class MyApplication:public CApplication
 *	{
 *  	// the application may have a member variable CWPS
 *  	CGNSS* m_gnss;
 *	};
 *  \endcode
 *
 *  Code example to retrieve an handle to a device of type dev::CGNSS
 *
 *  \code
 *   dev::CGNSS& gnss=Dev()["GNSS"];
 *  \endcode
 *
 *	Code example to get data from a dev::CGNSS
 *	\code
 *  // nella Execute
 *  bool MyApp::Execute()
 *  {
 *
 *  // retreive teh GNSS position using the UTM (north/east/down) format
 *  CGNSSData data;
 *
 *  gnss->GetCGNSSData(data);
 *  std::cout<<"Position in UTM format " << data.x << " " << data.y << std::endl;
 *
 *  }
 *
 *  \endcode
 */
class GOLD_DEV_EXPORT CGNSS: public CSensor
{
public:

	/** \brief Alias for the frame type; required by the infrastructure */
	typedef TFrame<data::GNSS> FrameType;

	/** \brief Alias for the device type; required by the infrastructure */
	typedef CGNSS DeviceType;

	/** \brief Alias for the signal type used to notify a new frame to the user */
#ifdef USE_BOOST_SIGNAL2
	typedef boost::signals2::signal<void(const FrameType& frame)> SignalType;
#else
	typedef boost::signal<void(const FrameType& frame)> SignalType;
#endif


	/** \brief Default  constructor */
	CGNSS();

	/** \brief Virtual destructor */
	virtual ~CGNSS();

	/** \brief Returns the last CGNSSData received
	 *
	 * \param data user space CGNSSData structure be filled with the last CGNSSData received.
	 * When the status field is false, there are no data available or the communication has been interrupted
	 */
	virtual void GetGNSSData(data::GNSS& data)=0;

	/**
	 * \brief Register a callback that will be called every time a new data is captured.
	 *
	 * If the driver receive the data in a separate thread, the user function will be
	 * invoked from that thread.
	 */
	void Do_On_Frame_AsyncReceived(
			boost::function<void(const FrameType& Frame)> slot);

protected:

	/** \brief Initialization code. \see CModule */
	void On_Initialization();

	/** \brief Initialization code. \see CModule */
	void On_ShutDown();

	/** \brief Call the user callbacks with new data. \*/
	void Notify_Frame_Received_Async(const FrameType& frame);

private:

	SignalType m_signal_async; ///< Signal for synchronous notification of frames to the users

};

}

#endif //__CGNSS_H
