/**
 * \file CCameraPlugin_Registration.h
 * \brief Declarations and macros for registering camera preprocessing plugins
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _CCAMERA_PLUGIN_REGISTRATION
#define _CCAMERA_PLUGIN_REGISTRATION

#include <Libs/Patterns/Factory.h>
#include <Libs/Patterns/RegisterObject.h>

#include "CCameraPlugin.h"

namespace dev
{
  
/**
 * \brief Factory type for registering and instantiating the plugins
 * \see vl::Factory
 */
typedef vl::Factory<std::string, dev::camera::Plugin>  CCameraPluginFactoryType;

/**
 * \brief Object for registering automatically a plugin name, its description, and its syntax
 */
class CCameraPluginDescription_Registrar
{
  public:
  CCameraPluginDescription_Registrar(const std::string& name, const std::string& descr, const std::string& syntax)
  {
    // std::cout << "Registering object" << Name << std::endl;
    dev::camera::Plugin_Descriptions::Add(name, descr, syntax);
  }
};

/**
 * \brief Macro to be placed at the end of a plugin declaration for registering the plugin
 * Example:
 * \code
 * // to be placed after declaration and definition of the CCameraPlugin_PGRAutoExposure class
 * REGISTER_CAMERA_PLUGIN(CCameraPlugin_PGRAutoExposure, "PGRAutoExposure",
 *   	"Syncronize gain and shutter betweean cameras\n",
 *		"{Ctrl=CameraMaster,CameraSlave1,..,CameraSlaveN}");
 * \endcode
 */
#define REGISTER_CAMERA_PLUGIN(CLASS, NAME, DESCR, SYNTAX) \
  vl::ObjectRegistrar< dev::CCameraPluginFactoryType, CLASS > drf_##CLASS(NAME); \
  CCameraPluginDescription_Registrar reg_desc##CLASS(NAME, DESCR, SYNTAX);

}

#endif // _CCAMERA_PLUGIN_REGISTRATION
