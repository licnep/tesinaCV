/**
 * \file CCANDecoder_BRAiVE_SteeringWheelAngle.h
 * \brief CAN Decoder for BRAiVE steering wheel angle messages
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Manuel Gargioni
 */
#ifndef CCANDECODER_BRAIVE_STEERINGWHEELANGLE_H_
#define CCANDECODER_BRAIVE_STEERINGWHEELANGLE_H_

#include "CCANDecoder.h"
#include "CCANDecoderRegistration.h"

namespace dev
{
namespace can
{
namespace decoder
{
/** \brief CAN Decoder for BRAiVE steering wheel angle messages */
class BRAiVE_SteeringWheelAngle: public dev::can::CDecoder
{
public:
	BRAiVE_SteeringWheelAngle();
	virtual ~BRAiVE_SteeringWheelAngle();
	virtual void Initialize(
			const boost::property_tree::ptree& ptree,
			std::vector<data::CCANData::IDType>& ids);
	virtual StatusID Decode(const CCAN::FrameType& frame);
private:
	double m_data;
	std::vector<data::CCANData::IDType> m_ids;
};

} // namespace decoders
} // namespace can
} // namespace dev

#endif /* CCANDECODER_BRAIVE_STEERINGWHEELANGLE_H_ */
