/**
 * \file CCameraPlugin.h
 * \brief Base class for a camera plugin
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _CCAMERA_PLUGIN_H
#define _CCAMERA_PLUGIN_H

#include <boost/tokenizer.hpp>

#include <Devices/gold_dev_export.h>
#include <Data/CImage/CImage.h>
#include <UI/Panel/Widgets.h>
#include <UI/CWindows/CWindowFwd.h>
#include <UI/CWindows/WindowsMap.h>

namespace dev
{

class CCamera;
class CCameraMap;

namespace camera
{

/**
 * \brief Base class for a camera plugin
 *
 * This class supplies the common interface and basic methods for developing a camera plugins
 * The public interface is used by the GOLD.
 *
 * The user implementing a plugin shall look at the protected section and reimplement the required methods
 * in the derived class.
 *
 * \code
 * #include <CCameraPlugin.h>
 * #include <CCameraPlugin_Registration.h>
 *
 * 	// An example of empty plugin replicating the source image
 *	class Root :
 *   public camera::Plugin
 *	{
 *	  public:
 *	  	// this is necessary
 *		virtual ~Root(){}
 *
 *	  protected:
 *
 *       // When the input size changes we need
 *       // to reallocate our only buffer
 *		virtual void On_Output_Change()
 *		{
 *		  // std::cout << "Root::On_Output_Change"<<std::endl;
 *		  m_images.clear(); // TODO: questa va unificata
 *		  m_images.insert ( std::make_pair ( "", m_source->New()) );
 *		}
 *
 *       // The processing function is actually empty
 *       // We just paint the input image on the defautl window
 *		virtual void On_Execute( const CImage::SharedPtrConstType image )
 *		{
 *		  m_images[""] = image;
 *		  DrawImageOnDefaultWindow();
 *		}
 *	};
 *
 * REGISTER_CAMERA_PLUGIN(Root, "My_Camera_Plugin",
 *   	"Put here a shor plugin description",
 *		"Put here an example of the plugin syntax");
 * \endcode
 *
 * A camera plugin has a default image, which is the first image of the internal a map of images,
 * and a default window, which is the first window in a map of windows.
 * All the object in the image map and in the windows map are available through appropriate methods
 * for more complex implementations.
 */
class GOLD_DEV_EXPORT Plugin
{
public:

	/** \brief Constructor */
	Plugin();

	/** \brief Virtual destructor */
	virtual ~Plugin();

	/**
	 * \brief Assign to the plugin the camera to control.
	 * Called from the camera, do not use in plugin implementation.
	 *
	 * This method shall not be called by user implementing a plugin
	 * \param camera The camera to be controlled by this plugin
	 */
	void Control(CCamera& camera);

	/**
	 * \brief Set the source node of the plugin.
	 * Called from the camera, do not use in plugin implementation.
	 * \param source The new source node of the plugin
	 */
	void SetSource(const cimage::CImage::SharedPtrConstType source);

	/**
	 * \brief Connects a map containing the other available cameras to the current plugin.
	 * Called from the camera, do not use in plugin implementation.
	 * \param cameras CCameraMap containing the other available cameras
	 */
	void Connect(CCameraMap& cameras);

	/**
	 * \brief Set the plugin operation and parameters.
	 * Called from the camera, do not use in plugin implementation.
	 * \param operation Identifier of the operation to be executed by the node
	 * \param params String containing the parameters of the operation in the format:
	 * "key1=value1 space key2=value2 space" where space is space, tab, or ";"
	 * Up to 10 positional parameters are also supported, their key will automatically
	 * be set to "$0..$9"
	 */
	void SetOperation(const std::string& operation, const std::string& params);

	/**
	 * \brief Initialize or re-initialized the plugin
	 * Called from the camera, do not use in plugin implementation.
	 */
	void Initialize();

	/**
	 * \brief Update the result.
	 * Called from the camera, do not use in plugin implementation.
	 * \param image Source image from the parent plugin
	 */
	void Execute(const cimage::CImage::SharedPtrConstType image);

	/**
	 * \brief Returns a shared pointer to the requested image
	 * \param name Identifier of the requested image in the map
	 * \see m_images
	 */
	const cimage::CImage::SharedPtrConstType Image(
			const std::string& name = "") const;

	/**
	 * \brief Returns the read-only version of the internal images map
	 */
	const std::map<std::string, cimage::CImage::SharedPtrConstType>& Images() const;

	/**
	 * \brief Returns a boost::optional containing the CWindowVisibilityProxy of the requested window
	 * An empty string means the default window.
	 * If the identifier is not found the boost optional is false
	 */
	boost::optional<ui::win::CWindowVisibilityProxy&> Window(
			const std::string& name = "");

	/**
	 * \brief Returns the internal windows visibility proxy map
	 */
	ui::win::WindowsMap::CWindowsProxiesMap& Windows();

	/**
	 * \brief Returns the modifiable CWindow associated to an identifier
	 * An empty string means the default window.
	 */
	ui::win::CWindow& Wnd(const std::string& name = "");

	/** \brief Returns the current operation identifier */
	const std::string& Operation() const;

	/** \brief Returns the name of the current plugin */
	const std::string& Name() const;

	/** \brief Returns a map containing the parsed options */
	typedef std::map<std::string, std::string> OptionMapType;
	const OptionMapType& Options() const;

	// FIXME: bring to the private section
	ui::wgt::NoteBook panel;

	/**
	 * \brief Performs the necessaries operations when the output frame size is changed.
	 *
	 * Implementations shall call this function when a parameter change cause the output frame resize.
	 */
	void ChangeOutput();

protected:

	/** \brief Implementations shall override this function with their own initialization code */
	virtual void On_Initialization();

	/** \brief Implementations shall override this function with their own processing code */
	virtual void On_Execute(const cimage::CImage::SharedPtrConstType image);

	/**
	 * \brief Implementations may override function when they need to execute code when the source size is changed
	 *
	 * Usually nothing needs to be done.
	 */
	virtual void On_Source_Changed();

	/**
	 * \brief Implementations may override function when they need to rebuild one or more buffers consequently to an output change
	 *
	 * Usually nothing needs to be done.
	 */
	virtual void On_Output_Change();

	/**
	 * \brief Change the size of the default window to the current default buffer
	 */
	void ResizeDefaultWnd();

	/**
	 * \brief Draws the default image on the default window
	 */
	void DrawImageOnDefaultWindow();

	CCameraMap* m_p_cameras; ///< Map of the available target cameras that may be used by the plugin
	CCamera* m_p_camera;  ///< Camera containing the current plugin

	cimage::CImage::SharedPtrType m_source; ///< Shared Pointer to the source image used for initialization

	/** \brief typedef for the Tokenizer used to parse the options */
	typedef boost::tokenizer<boost::char_separator<char> > TokenizerType;

	/** \brief char separator */
	static boost::char_separator<char> sep;

	/** \brief maps containing the parsed options */
	OptionMapType m_options;

	/** \brief Fills the m_options map using the string passed as argument */
	void ParseOptions(const std::string& options);

	/** \brief map of the images/buffer used by the plugin implementation */
	std::map<std::string, cimage::CImage::SharedPtrConstType> m_images;

	/** \brief map of the CWindows used by the plugin implementation */
	ui::win::WindowsMap m_windows;

	std::string m_operation;  ///< identifier of the current operation
	std::string m_name;       ///< name of the current plugin
	bool m_initialized;   ///< true when the current plugin has been initialized

	static boost::mutex m_mtx; ///< mutex for exclusive access to the plugin map
};

/**
 * \brief Class for accessing the plugin descriptions. Used by the camera, not by the implementations
 */
class GOLD_DEV_EXPORT Plugin_Descriptions
{
	/** \brief Typedef for the internal data: \<plugin-name \<syntax, description\> \>*/
	typedef std::map<std::string, std::pair<std::string, std::string> > MapType;

	/** \brief instance of the internal data: one map for all plugins of all cameras */
	static MapType desc;

public:
	/** \brief Add an entry */
	static void Add(const std::string& name, const std::string& descr,
			const std::string& syntax);
	/** \brief Get the description using the plugin name as key */
	static const std::string& Description(const std::string& plugin_name);

	/** \brief Get the syntax using the plugin name as key */
	static const std::string& Syntax(const std::string& plugin_name);
};

/** \brief Namespace containing instantiable camera plugins */
namespace plugin
{
} // namespace plugin

} // namespace camera

} // namespace dev

#endif

