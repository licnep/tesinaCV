/**
 * \file CINS.h
 * \brief Device modeling a generic Inertial Navigation System (INS)
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Paolo Medici\<grisleri@ce.unipr.it\>
 */

#ifndef __CINS_H
#define __CINS_H

#include <Data/CINSData/CINSData.h>
#include <Devices/Base/CSensor.h>
#include <Devices/Base/TFrame.h>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

namespace dev
{
/**
 * \brief Device modeling a generic Inertial Navigation System (INS)
 *
 * The device can be used registering a callback function which is called
 * every time the physical device receive a new CINSData.
 *
 * Otherwise, the GetINSData() and GetINSDataUnbiased() methods called directly
 * on the device return the last captured CINSData.
 * Using this second method, it may happens that the application runs faster than
 * the update rate of the GNSS unit. In this case it is possible to check if the
 * data has not been updated by checking if the the values of the m_TimeStampUTC
 * time stamps are equal.
 *
 * When the status field of the returned CGNSSData is false then one of the following conditions is true:
 * - no data has been read, maybe because the unit is off or no satellites have been found
 * - the connection with the GNSS unit has been closed; in this case all the fields have 0 value.
 *
 */

class GOLD_DEV_EXPORT CINS: public CSensor
{
public:
	/** \brief Alias for the frame type; required by the infrastructure */
	typedef TFrame<data::CINSData> FrameType;

	/** \brief Alias for the device type; required by the infrastructure */
	// typedef CINS DeviceType;

	/** \brief Alias for the signal type used to notify a new frame to the user */
#ifdef USE_BOOST_SIGNAL2
	typedef boost::signals2::signal<void(const FrameType& frame)> SignalType;
#else
	typedef boost::signal<void(const FrameType& frame)> SignalType;
#endif

	/** \brief Default constructor */
	CINS();

	/** \brief Virtual destructor */
	virtual ~CINS();

	/**
	 * \brief Returns the last CINSData captured from the INS unit.
	 * \param data user space CINSData to be filled with the content of the last captured data.
	 */
	virtual void GetINSData(data::CINSData& data) = 0;

	/**
	 * \brief Returns the last CINSData captured from the INS unit (unbiased version)
	 *
	 * Data coming from INS sensors are affected by a bias value depending on the temperature
	 * This method returns the value unaffected from this bias.
	 * Note that the unbiased value is obtained subtracting from the  read value,
	 * a value computed from a bias function; it is not a physical read.
	 * \param data user space CINSData to be filled with the content of the last captured data.
	 */
	virtual void GetUnBiasedINSData(data::CINSData& data) = 0;

	/**
	 * \brief Register a callback that will be called every time a new data is captured.
	 *
	 * If the driver receive the data in a separate thread, the user function will be
	 * invoked from that thread.
	 */
	void Do_On_Frame_AsyncReceived(
			boost::function<void(const FrameType& frame)> slot);

	/**
	 * \brief Register a callback that will be called every time a new data is captured.
	 *
	 * If the driver receive the data in a separate thread, the user function will be
	 * invoked from that thread.
	 */
	void Do_On_Frame_AsyncReceived_Biased(
			boost::function<void(const FrameType& frame)> slot);

protected:
	/** \brief Initialization code. \see CModule */
	void On_Initialization();

	/** \brief Shutdown code. \see CModule */
	void On_ShutDown();

	/** \brief Call the user callbacks with new data. \*/
	void Notify_Biased_Frame_Received_Async(const FrameType& frame);

	/** \brief Call the user callbacks with new unbiased data. \*/
	void Notify_Frame_Received_Async(const FrameType& frame);

	/** \brief Returns true when the device is waiting for an unbiased data. \*/
	bool IsWaitingForUnBiasedData() const;
private:

	SignalType m_signal_async; ///< Signal for synchronous notification of frames to the users
	SignalType m_signal_async_biased; ///< Signal for synchronous notification of frames to the users (unbiased version)
};

}

#endif //__CINS_H
