/**
 * \file Profiler.h
 * \brief Device modeling a profiler for the applications.
 *
 * The driver which provides this device device is instantiated by the engine.
 * There is no need to set up a dedicated section in the HWS
 * This device is always present with one and only one instance.
 *
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef PROFILER_H
#define PROFILER_H

#include <string>
#include <vector>

#include <Libs/Time/CChronometer.h>

#include <Devices/gold_dev_export.h>

namespace dev
{
/**
 * \brief Device modeling a profiler for the applications.
 *
 * The profiler is a device where an application can connect one or more
 * vl::chrono::CChronometer or vl::chrono::Accumulator in order to see the statistics
 * visualized in the profiler panel.
 *
 */
class GOLD_DEV_EXPORT CProfiler
{
public:

	// typedef CProfiler DeviceType;

	/** \brief Default constructor */
	CProfiler();

	/** brief Virtual destructor */
	virtual ~CProfiler();

	/**
	 * \brief Connect a vl::chrono::CChronometer to the profiler.
	 *
	 * After this call every update to the vl::chrono::CChronometer updates the profiler.
	 * The profiler is also updated periodically.
	 */
	void Connect(const vl::chrono::CChronometer& chrono);

	/**
	 * \brief Connect a vl::chrono::Accumulator to the profiler.
	 *
	 * After this call every update to the vl::chrono::Accumulator updates the profiler.
	 * The profiler is also updated periodically.
	 */
	void Connect(const std::string& name, const vl::chrono::Accumulator& t_acc);

	/**
	 * \brief Removes a vl::chrono::CChronometer previously attached from the profiler
	 */
	void Remove(const vl::chrono::CChronometer& chrono);

	/**
	 * \brief Removes a vl::chrono::Accumulator previously attached from the profiler
	 */
	void Remove(const vl::chrono::Accumulator& accum);

	/**
	 * \brief Resets the profiler statistics by resetting the statistics of each chronometer
	 */
	void Reset(void);

	/** \brief Prints a report on the console. */
	void PrintReport(void);

protected:

	/**
	 * \brief Prints on the console the statistics of a specified chronometer
	 * \param pchronometer Pointer to a valid chronometer whose status will be printed
	 */
	void PrintEntry(const vl::chrono::CChronometer* pchronometer);

	/**
	 * \brief Add an entry to the current profiler with the specified name
	 */
	virtual unsigned int Add_Entry(const std::string& name) = 0;

	/**
	 * \brief Update the requested entry of the current profiler
	 *
	 */
	virtual void Update_Entry(unsigned int id, const vl::chrono::Accumulator&) = 0;

private:

	std::vector<vl::chrono::CChronometer*> m_chronos; ///< List of the connected vl::chrono::CChronometer
	std::vector<vl::chrono::Accumulator*> m_accums; ///<  List of the connected vl::chrono::Accumulator
};

}
#endif

