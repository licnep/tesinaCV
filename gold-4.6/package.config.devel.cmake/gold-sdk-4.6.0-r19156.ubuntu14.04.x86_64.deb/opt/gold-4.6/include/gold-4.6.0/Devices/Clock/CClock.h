/** \file CClock.h
 *  \brief Clock device for profiling and time measurments
 *  \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 **/

#ifndef _CCLOCK_H
#define _CCLOCK_H

#include <Libs/Time/CChronometer.h>

#include <Devices/gold_dev_export.h>

namespace dev
{

/**
 * \brief Device modeling a clock.
 *
 * It is a device wrapper for the CTSChronometer class.
 * \see vl::chrono::CTSChronometer
 */
class GOLD_DEV_EXPORT CClock :
      public vl::chrono::CTSChronometer
{
protected:
  CClock(CChronometer::ClockType ClockID);
};
}
#endif // _CCLOCK_H
