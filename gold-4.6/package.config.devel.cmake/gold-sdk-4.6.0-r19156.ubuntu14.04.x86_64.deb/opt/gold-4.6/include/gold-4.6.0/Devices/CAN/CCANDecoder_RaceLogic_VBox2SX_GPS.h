/**
 * \file CCANDecoder_RaceLogic_VBox2SX_GPS.h
 * \brief CAN Decoder for GPS data produced by a RaceLogic VBox2SX unit
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Manuel Gargioni
 */

#ifndef CCANDECODER_GPS_H
#define CCANDECODER_GPS_H

#include <Data/CGNSSData/CGNSSData.h>
#include <Libs/Time/CChronometer.h>

#include "CCANDecoder.h"
#include "CCANDecoderRegistration.h"

namespace dev
{
namespace can
{
namespace decoder
{
/** \brief CAN Decoder for GPS data produced by a RaceLogic VBox2SX unit */
class RaceLogic_VBox2SX_GPS:
public dev::can::CDecoder
{
public:
	RaceLogic_VBox2SX_GPS();
	virtual ~RaceLogic_VBox2SX_GPS();
	virtual void Initialize(const boost::property_tree::ptree& ptree,
			std::vector<data::CCANData::IDType>& ids);
	virtual StatusID Decode(const CCAN::FrameType& Frame);
private:

	uint8_t m_receive; ///< BitMask
	data::GNSS m_data;  ///< Last DATA
	std::vector<data::CCANData::IDType> m_ids;     ///< Reserved
};

} // namespace decoder
} // namespace can
} // namespace dev
#endif // CCANDECODER_GPS_H
