/**
 * \file CCANDecoderRegistration.h
 * \brief Objects and macros for registering dev::can::CEncoder implementations
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Manuel Gargioni
 */

#ifndef CCANENCODERSREGISTRATION_H
#define CCANENCODERSREGISTRATION_H

#include <Libs/Patterns/Singleton.h>
#include <Libs/Patterns/Factory.h>
#include <Libs/Patterns/RegisterObject.h>

#include "CCANEncoder.h"

namespace dev
{
namespace can
{

/** \brief Factory for collecting the encoders*/
typedef vl::Factory<std::string, dev::can::CEncoder> CEncodersFactoryType;

/** \brief Macro for registering encoders implementation */
#define REGISTER_CCANENCODER(CLASS, NAME) \
  GOLD_DEV_EXPORT vl::ObjectRegistrar< dev::can::CEncodersFactoryType, CLASS > drf_##CLASS(NAME)

} // namespace can

} // namespace dev

#endif // CCANENCODERSREGISTRATION_H

