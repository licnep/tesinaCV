/**
 * \file CCANEncoder.h
 * \brief Interface for a generic encoder for translating an high level data into a series of CAN messages
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Manuel Gargioni
 */

#ifndef CCANENCODER_H
#define CCANENCODER_H

#include <boost/property_tree/ptree_fwd.hpp>
#include <Devices/CAN/CCAN.h>
#include <Devices/gold_dev_export.h>

namespace dev
{
namespace can
{

/** \brief Interface for a generic encoder for translating an high level data into a series of CAN messages */
class CEncoder
{
  public:
	CEncoder();
    virtual ~CEncoder();
    virtual void Initialize(const boost::property_tree::ptree& tree , std::vector<data::CCANData::IDType>& ids) = 0;
    virtual data::CCANData Encode(const boost::any& data) = 0;
};

/** \brief CAN preprocessor available encoders */
namespace encoder{}

} // namespace can
} // namespace dev


#endif // CCANENCODERS_H
