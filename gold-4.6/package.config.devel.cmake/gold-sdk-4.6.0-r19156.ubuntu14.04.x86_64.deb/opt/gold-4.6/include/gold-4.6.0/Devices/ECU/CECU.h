/**
 * \file CECU.h
 * \brief Device modeling a generic Electronic Control Unit (ECU)
 * \author Luca Gatti \<lucag@ce.unipr.it\>, Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef CECU_H
#define CECU_H

#include <Data/CECUData/CECUData.h>
#include <Devices/Base/CSensor.h>
#include <Devices/Base/TFrame.h>

#include <stdint.h>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <Devices/gold_dev_export.h>

namespace dev
{

/**
 * \brief Device modeling a generic Electronic Control Unit (ECU)
 *
 * An ECU is a sensor producing a list of objects as data.
 * Examples of these sensors are High level processing of radars and laserscanners.
 */
class GOLD_DEV_EXPORT CECU: public CSensor
{
public:

	/** \brief Alias for the frame type required by the infrastructure */
	typedef TFrame<data::CECUData> FrameType;

	/** \brief Default constructor */
	CECU();

	/** \brief Destructor */
	~CECU();

	/** \brief Type of the signal used to notify the user callbacks */
#ifdef USE_BOOST_SIGNAL2
	typedef boost::signals2::signal<void(const FrameType& frame)> SignalType;
#else
	typedef boost::signal<void(const FrameType& frame)> SignalType;
#endif

	/**
	 * \brief Register a callback that will be called every time the ECU
	 * receive a list of objects.
	 *
	 * If the driver receive the data in a separate thread, the user function will be
	 * invoked from that thread.
	 */
	void Do_On_Frame_AsyncReceived(
			boost::function<void(const FrameType& frame)> slot);

protected:

	/** \brief Initialization code. \see CModule */
	void On_Initialization();

	/** \brief ShutDown code. \see CModule */
	void On_ShutDown();

	/** \brief Code invoked when the parameters specific of this device are saved. \see CModule */
	void On_SaveParams(INIFile &ini);

	/** \brief Code invoked when the parameters specific of this device are saved. \see CModule */
	void Notify_Frame_Received_Async(const FrameType& frame);

	/** \brief Function performing the preprocessing */
	void Preprocessing(FrameType& frame);

	ui::wgt::Widget panel; ///< User interface panel for the device

private:
	SignalType m_signal_async; ///< Signal for asynchronous notification of frames to the users

	data::TransformationType R;
};

} // namespace dev

#endif // CECU_H
