/**
 * \file CDiskWriter.h
 * \brief Device for writing objects on disk
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _DISKWRITER_H
#define _DISKWRITER_H

#include <string>
#include <vector>

#include <Devices/CDiskWriter/CWritable.h>
#include <Devices/CDiskWriter/VLA_Archive.h>

#include <Devices/gold_dev_export.h>

namespace dev
{

/**
 * \brief Device for writing objects on disk.
 *
 * TODO: This device is now used on system side only.
 * The exposure of this interface to the user can also be avoided
 * This class shall be integrated in CSystemDiskWriter.
 */
class GOLD_DEV_EXPORT CDiskWriter
{
public:
	/** \brief Constructor */
	CDiskWriter();

	/** \brief Virtual destructor */
	virtual ~CDiskWriter(void);

	/**
	 * \brief Enumerator for the supported container types
	 */
	typedef enum
	{
		NONE, ///< separate files, where applicable
		TAR, ///< all the files, excluding streams (such as videos), will be encapsulated in a tar file
		VLA ///< all the files, excluding streams (such as videos), will be encapsulated in a vla file
	} ContainerType;

	/**
	 * \brief Register a new track
	 *
	 * This method inform the writer that a new track will be part of the current recording.
	 * New tracks can only be added before the actual begin of the recording.
	 * \param container path of the container for the track. For VLA and TAR a file is required, for NONE a directory is required.
	 * \param ct ContainerType specifying the container type
	 * \param track a descriptor for the new track. \see vla::Track
	 * \return the track id assigned by the DiskWriter to the requested track. This id must be used during the recording; \see Write
	 */
	virtual uint8_t RegisterTrack(const boost::filesystem::path& container,
			ContainerType ct, const vla::Track& track) = 0;

	/**
	 * \brief Write an object on a specified track
	 *
	 * This function is reentrant. The object is added to a queue and written later from a separate thread.
	 * The object must not be canceled; canceling the object will likely result in a memory corruption.
	 * \param writable spCWritableType is a shared pointer to a type implementing the CWritable interface
	 * \param track_id the track identifier returned by the RegisterTrack method
	 */
	void Write(spCWritableType writable, uint8_t track_id = 0xff);

	/**
	 * \brief Returns the number of elements still in queue waiting for being written
	 *
	 * Note that this number can change after the call return.
	 */
	virtual uint64_t Queues_Size() const = 0;

	/**
	 * \brief Returns the vector containing the active track descriptors
	 */
	const std::vector<vla::Track>& Tracks() const
	{
		return m_tracks;
	}

	/**
	 * \brief vector containing the active track descriptors
	 *
	 * This is currently just a copy of those stored in the writing queues,
	 * it must be transformed in a collection of the per-writing-queue vectors
	 */
	std::vector<vla::Track> m_tracks;

private:

	/**
	 * \brief Internal writing function: reservations are taken into account
	 * \param writable shared pointer to the CWritable to be written
	 * \param track_id track identifier released by the register track function
	 */
	virtual void Internal_Write(spCWritableType writable, uint8_t track_id)=0;

public:
	// exceptions thrown by the Write method

	/**
	 * \brief exception thrown by the Write method when there is no more space in the memory queue
	 */
	class frame_dropped: public std::runtime_error
	{
	public:
		frame_dropped() :
				runtime_error("Reservation failed")
		{
		}
	};

	/**
	 * \brief exception thrown by the Write method when a reservation fails
	 */
	class bad_reservation: public std::runtime_error
	{
	public:
		bad_reservation() :
				runtime_error("Bad reservation")
		{
		}
	};

	/**
	 * \brief exception thrown by the Write method when a reservation fails
	 */
	class reservation_failed: public std::runtime_error
	{
	public:
		reservation_failed() :
				runtime_error("Reservation failed")
		{
		}
	};

	/**
	 * \brief exception thrown by the Write method when the engine is shutting down and the write request is ignored
	 */
	class ignoring_write: public std::runtime_error
	{
	public:
		ignoring_write() :
				runtime_error("Ignoring write: DiskWriter is closing")
		{
		}
	};
};
} // namespace dev
#endif
