
#ifndef GOLD_DEV_EXPORT_H
#define GOLD_DEV_EXPORT_H

#ifdef GOLD_DEV_STATIC_DEFINE
#  define GOLD_DEV_EXPORT
#  define GOLD_DEV_NO_EXPORT
#else
#  ifndef GOLD_DEV_EXPORT
#    ifdef gold_dev_EXPORTS
        /* We are building this library */
#      define GOLD_DEV_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define GOLD_DEV_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef GOLD_DEV_NO_EXPORT
#    define GOLD_DEV_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef GOLD_DEV_DEPRECATED
#  define GOLD_DEV_DEPRECATED __attribute__ ((__deprecated__))
#  define GOLD_DEV_DEPRECATED_EXPORT GOLD_DEV_EXPORT __attribute__ ((__deprecated__))
#  define GOLD_DEV_DEPRECATED_NO_EXPORT GOLD_DEV_NO_EXPORT __attribute__ ((__deprecated__))
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define GOLD_DEV_NO_DEPRECATED
#endif

#endif
