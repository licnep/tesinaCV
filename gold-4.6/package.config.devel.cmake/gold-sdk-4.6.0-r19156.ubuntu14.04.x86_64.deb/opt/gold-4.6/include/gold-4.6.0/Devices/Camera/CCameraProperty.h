/**
 * \file CCameraProperty.h
 * \brief Classes and functions for building the camera properties set
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _CCAMERA_PROPERTY_H
#define _CCAMERA_PROPERTY_H

#include <Devices/gold_dev_export.h>

#include <UI/Panel/Widget.h>
#include <UI/Panel/Vars.h>

#include <boost/optional.hpp>

#include <Libs/INIFiles/strcast.h> // TODO vl::cast/conversion

#include <string>
#include <map>
#include <vector>
namespace dev
{

namespace camera
{

/** \brief Classes and functions for building a camera properties set */
namespace videoprop
{

/**
 * \brief Base class for modeling one single attribute of a camera property
 *
 * An attribute is a sub-element of a property. A property may have one or more attributes.
 * An attribute cannot be instantiated directly, can only be constructed as base of a derived class.
 *
 */
class GOLD_DEV_EXPORT Attribute
{
public:

	/** \brief Enumeration of the attribute types supported */
	typedef enum
	{
		at_unknown,
		at_group,
		at_bool,
		at_enum,
		at_text,
		at_label,
		at_uint8,
		at_uint16,
		at_uint32,
		at_uint64,
		at_int8,
		at_int16,
		at_int32,
		at_int64,
		at_float,
		at_double
	} Type;

	/** \brief Method for translating a type in an Attribute::Type */
	template<typename T>
	Type type_to_attr();

private:
	ui::var::Base m_base_value;

	Attribute::Type m_type;

protected:

	/**
	 * \brief Constructor taking name, the variabile and the attribute type
	 * \param _name Name of the attribute
	 * \param base ui::var::Base representing the variable
	 * \param type enumeration value representing the attribute type
	 */
	Attribute(const std::string& _name, ui::var::Base base,
			Attribute::Type type = at_unknown);
public:

	std::string name;       ///< Attribute identifier
	ui::wgt::Widget widget; ///< Widget associated to the attribute

	/** \brief Returns an enumerative representing the attribute type */
	Attribute::Type TypeID() const
	{
		return m_type;
	}

	// TODO per il parsing occorrono anche questi
	// std::string path;

	/** \brief Update the base value */
	void Update();

	/** \brief Enable or disable the attribute */
	void Enabled(bool value);

	/**
	 * \brief Read the variable value as a specified type
	 */
	template<typename T>
	operator T() const
	{
		return m_base_value.GetValue<T>();
	}

	/**
	 * \brief Write the variable value as a specified type
	 */
	template<typename T>
	const T& operator=(const T& value)
	{
		m_base_value.SetValue(value);
		return value;
	}

	/**
	 * \brief Returns true when the argument is strictly equal to the value of the internal variable
	 */
	template<typename T>
	bool operator==(const T& value)
	{
		return value == m_base_value.GetValue<T>();
	}

	/**
	 * \brief Returns true when the argument is not equal to the value of the internal variable
	 */
	template<typename T>
	bool operator!=(const T& value)
	{
		return value != m_base_value.GetValue<T>();
	}

	/**
	 * \brief Returns true when the argument is less than the value of the internal variable
	 */
	template<typename T>
	bool operator<(const T& value)
	{
		return value < m_base_value.GetValue<T>();
	}

	/**
	 * \brief Returns true when the argument is greater than the value of the internal variable
	 */
	template<typename T>
	bool operator>(const T& value)
	{
		return value > m_base_value.GetValue<T>();
	}
};

/** \brief Contains a set of ready to use attributes */
namespace attribute
{

/** \brief Contains internal stuff for attributes construction */
namespace impl
{

/** \brief Needed to instantiate the first creation of the attribute value
 *  and then the base class, which contains the ui::var::Base
 */
template<class T>
class base_var
{
protected:

	T m_value;
	base_var()
	{
		// std::cout << "base_var::base_var=" <<m_value.m_guid <<std::endl;
	}
};
} // namespace impl

/**
 * \brief Attribute representing a group of attributes.
 *
 * No callbacks/actions are associated to this kind of attributes.
 */
class GOLD_DEV_EXPORT Group: public impl::base_var<ui::var::Value<std::string> >,
		public Attribute
{
public:
	typedef boost::function<void(std::string)> SetType;
	typedef boost::function<std::string(void)> GetType;

	/**
	 * \brief Constructor accepting the name, set and get function.
	 * \param name The attribute name
	 */
	Group(const std::string& name/*, SetType set, GetType get*/);
};

/**
 * \brief Attribute representing a label (not modifiable from the GUI)
 */
class GOLD_DEV_EXPORT Label: public impl::base_var<ui::var::Value<std::string> >,
		public Attribute
{
public:

	/**
	 * \brief Constructor accepting the name, set and get function.
	 * \param name The attribute name
	 * \param set The set function is called when the label value is written.
	 * \param get The get function is called when the label value is read.
	 */
	Label(const std::string& name,
			boost::function<void(std::string)> set,
			boost::function<std::string(void)> get);
};

/**
 * \brief Attribute representing a text (modifiable from the GUI)
 */
class GOLD_DEV_EXPORT Text: public impl::base_var<ui::var::Value<std::string> >,
		public Attribute
{
public:
	typedef boost::function<void(std::string)> SetType;
	typedef boost::function<std::string(void)> GetType;

	/**
	 * \brief Constructor accepting the name, set and get function.
	 * \param name The attribute name
	 * \param set The set function is called when the label value is written.
	 * \param get The get function is called when the label value is read.
	 */
	Text(const std::string& name, SetType set, GetType get);
};

/**
 * \brief Attribute representing an on/off value
 */
class GOLD_DEV_EXPORT Switch: public impl::base_var<ui::var::Value<bool> >,
		public Attribute
{
public:

	/**
	 * \brief Constructor accepting the name, set and get function.
	 * \param name The attribute name
	 * \param set The set function is called when the label value is written.
	 * \param get The get function is called when the label value is read.
	 */
	Switch(const std::string& name,
			boost::function<void(bool)> set,
			boost::function<bool(void)> get);
};

/**
 * \brief Attribute representing a range of values
 * \tparam T type of the internal variable
 */
template<typename T>
class GOLD_DEV_EXPORT Range: public impl::base_var<ui::var::Range<T> >,
		public Attribute
{
public:

	/**
	 * \brief Constructor accepting the name, set and get function.
	 * \param name The attribute name
	 * \param set The set function is called when the label value is written.
	 * \param get The get function is called when the label value is read.
	 * \param min minimum value of the range
	 * \param max maximum value of the range
	 * \param step step of the range
	 * \param unit optional the measurment unit of the value
	 */
	Range(const std::string& name, boost::function<void(T)> set,
			boost::function<T(void)> get, T min, T max, T step,
			// TODO: default
			const std::string& unit = "#");
};

/**
 * \brief Attribute representing a value selected in a limited choice
 * \tparam T type of the internal variable
 */
class GOLD_DEV_EXPORT Choice: public impl::base_var<ui::var::Choice<std::string> >,
		public Attribute
{

public:

	Choice(const std::string& name, boost::function<void(std::string)> set,
			boost::function<std::string(void)> get,
			const std::vector<std::string>& data);
};

/** \brief Contains the modes supported by attribute::Mode */
namespace mode
{
typedef enum
{
	MANUAL, AUTO, ONE_PUSH
} Type;
} // namespace mode

/**
 * \brief Attribute representing the available modes of a property
 */
class GOLD_DEV_EXPORT Mode: public impl::base_var<ui::var::Map<mode::Type> >,
		public Attribute
{
	std::vector<std::pair<std::string, mode::Type> > m_checked_modes;

public:
	// deve consentire di specificare i modi disponibili
	Mode(const std::vector<mode::Type>& modes,
			boost::function<void(mode::Type)> set,
			boost::function<mode::Type(void)> get);

	std::string Values() const;
};
} // namespace attribute
} // namespace videoprop

// TODO: copyable

/**
 * \brief Base class for representing a video property.
 * It is a collections of attributes.
 */
class GOLD_DEV_EXPORT VideoProperty
{
public:
	typedef boost::shared_ptr<VideoProperty> ShPtrType;
	typedef std::vector<camera::VideoProperty::ShPtrType> ListType;
	typedef std::map<std::string, videoprop::Attribute> AttributesMap;
	// FIXME mmm, si riesce a fare con una mappa sola?
	typedef std::map<std::string, videoprop::attribute::Group> GroupsMap;
	typedef boost::optional<videoprop::Attribute&> OptAttribType;

	/** \brief Constructor accepting the property name and the initialization file */
	VideoProperty(const std::string& name, INIFile* pini = 0);

	/** \brief Destructor */
	~VideoProperty();

	// TODO: implement this using the attributes; shall be a non visible one
	const std::string& Name() const;

	/** \brief Adds an attribute to the property */
	void AddAttribute(const videoprop::Attribute& attribute);

	/**
	 * \brief Returns a boost::options containing the requested attribute, if found
	 * \param name the name of the requested attribute to be returned
	 * \return  boost::options true and containing the requested attribute if the attribute name has been found, false otherwhise
	 */
	OptAttribType Attribute(const std::string& name);

	/**
	 * \brief Returns the full AttributesMap, that can be browsed by the user in a custom way
	 */
	const AttributesMap& Attributes() const;

	/** \brief Returns the list of the children VideoProperty */
	const ListType& GetChildren();

	/** \brief Returns the list of the parent VideoProperty */
	VideoProperty* GetParent();

	/** \brief handler to the panel */
	ui::wgt::Widget panel;

protected:

	INIFile* m_pini; ///< Initialization file

private:
	std::string m_name;  ///< Property name
	AttributesMap m_attributes; ///< Map of the attributes
	GroupsMap m_groups; ///< Map of the groups
	ListType m_children; ///< Children VideoProperties
};

/** \brief Alias for a list of videoproperties external to the class*/
typedef VideoProperty::ListType VideoPropertiesList;

/** \brief functions and declarations related to videoproperties */
namespace videoprop
{
/** \brief functor for comparing the name of an attribute using the STL algorithms */
class HasName
{
	const std::string m_name;
public:
	HasName(const std::string& name);
	bool operator()(VideoProperty::ShPtrType prop);
};
} // namespace videoprop

} // namespace camera

} // namespace dev

#endif
