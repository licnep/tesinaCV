/**
 * \file CCANDecoder_LinTrans.h
 * \brief CAN Decoder for messages requiring a simple linear transformation
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Manuel Gargioni
 */
#ifndef CCANDECODER_LINTRANS_H_
#define CCANDECODER_LINTRANS_H_

#include "CCANDecoder.h"
#include "CCANDecoderRegistration.h"

namespace dev
{
namespace can
{
namespace decoder
{
/** \brief CAN Decoder for messages requiring a simple linear transformation \f$ Value=K*CAN_v+Offset \f$ */
class LinTrans : public dev::can::CDecoder
{
public:
	LinTrans();
	virtual ~LinTrans();
	virtual void Initialize(const boost::property_tree::ptree& ptree,
			std::vector<data::CCANData::IDType>& ids);
	virtual can::CDecoder::StatusID Decode(const dev::CCAN::FrameType& frame);
private:
	uint16_t m_start_bit;
	uint16_t m_bit_length;
	double m_offset;
	double m_multiplier;
	uint64_t m_data;
	std::vector<data::CCANData::IDType> m_ids;
};
} // namespace decoder
} // namespace can
} // namespace dev

#endif /* CCANDECODER_LINTRANS_H_ */
