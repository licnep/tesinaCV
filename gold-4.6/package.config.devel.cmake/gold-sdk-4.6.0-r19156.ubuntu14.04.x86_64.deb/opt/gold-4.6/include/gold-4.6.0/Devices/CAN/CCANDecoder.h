/**
 * \file CCANDecoder.h
 * \brief Interface for a generic decoder for translating a series of CAN messages in high level data
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Manuel Gargioni
 */

#ifndef CCANDECODER_H_
#define CCANDECODER_H_

#include <boost/property_tree/ptree_fwd.hpp>
#include <boost/tuple/tuple.hpp>
#include <Devices/CAN/CCAN.h>
#include <Devices/gold_dev_export.h>

namespace dev
{
namespace can
{

/**
 * \brief Interface for a generic decoder for translating a series of CAN messages in high level data
 */
class GOLD_DEV_EXPORT CDecoder
{
  public:
	/** \brief Default constructor */
	CDecoder();
    /** \brief Virtual destructor */
    virtual ~CDecoder();

    /** \brief Typedef for the global unique identifier */
    typedef unsigned long GUIDType;

    /** \brief Lazy initialization function; not intended to be called by users in applications */
    virtual void Initialize(const boost::property_tree::ptree& tree , std::vector<data::CCANData::IDType>& ids) = 0;

    /** \brief Enumerator for the possible status of the decoding */
    typedef enum{
    	IN_PROGRESS, ///< The decoding is in progress, but some messages necessary to complete the data still need to be received
    	COMPLETED ///< All the messages necessary to complete the decoding has been received
    } StatusID;

    /** \brief System side interface: called when a new message arrives and needs to be processed */
    virtual StatusID Decode(const CCAN::FrameType& frame) = 0;
    
    /**
     * \brief this method must be called by implementation for signalling the end of the decoding and
     * dispatch the data to the subscribers
     */
    void Decode_TM(const CCAN::FrameType& frame);

    /**
     * \brief user side interface: applications can subscribe to be notified when a decoding is completed
     * \param slot user side callback function to be invoked when a decoding is complete
     */
    void Subscribe_Decoding(const CCAN::SignalDecodeType::slot_type& slot);

    /**
     * \brief Returns a pair containing a boost::any containing the high level value and a GUIDType unique for each value
     */
    boost::tuple<boost::any, GUIDType> Value () const;

  protected:

    /**
     * \brief called by implementation for setting the internal high level value
     */
    void Set_Value (boost::any val);

    /** \brief Dispatch the high level data to all the subscribers */
    void Dispatch( const boost::any data );

  private:
    CCAN::SignalDecodeType m_signal;
    mutable boost::mutex m_mtx;
    boost::any   m_value;
    GUIDType     m_guid;
    data::CCANData     m_can_data;
};

/** \brief CAN preprocessor available decoders */
namespace decoder{}

} // namespace can

} // namespace dev



#endif /* CCANDECODERS_H_ */
