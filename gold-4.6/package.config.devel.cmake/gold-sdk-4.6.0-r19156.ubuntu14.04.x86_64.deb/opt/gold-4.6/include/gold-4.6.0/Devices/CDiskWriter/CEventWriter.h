/**
 * \file CEventWriter.h
 * \brief Class for writing Event Files \see GRP_MEF_FILE_FORMAT
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */
#ifndef _CEVENT_WRITER_H
#define _CEVENT_WRITER_H

#include <vector>
#include <fstream>

#include <boost/thread/mutex.hpp>
#include <boost/filesystem/path.hpp>
#include <boost/function.hpp>

#include <Framework/CEvent.h>

#include <Devices/gold_dev_export.h>

namespace data
{
//   namespace serialization
//  {
    

/**
 * \brief Class for writing the Event Files
 *
 * \see MEF_File_Format
 */
class GOLD_DEV_EXPORT CEventWriter
{
  public: 
	/** brief typedef for the event */
    typedef data::CEvent EventType;
    
    /**
     * \brief Constructor accepting the path of the file to be written and an optional path for the cache
     *
     * In some cases it can be efficient to write a temporary file in a RAM disk,
     * instead of writing the real file in the same path of the other data
     * \param url path of the destination file where the events will be stored
     * \param cache path of the optional cache file where the events will be stored temporarily
     */
    CEventWriter ( const std::string& url, const std::string& cache="" );
    ~CEventWriter();

    // Event File I/O functions

    /** \name Write Event on file */
    
    /**
     * \brief Append an event to the file
     * \param in EventType to be appended to the file
     */
    void Dump ( const EventType& in );
    
    /**
     * \brief Append an event to the file
     * \param in EventType to be appended to the file
     * \see Dump
     */
    void operator << (const EventType& in);
    
    /**
     * \brief Removes from the cache all the events with key less than the specified
     * \param key all the events in the cache with key less than key will be removed
     */
    void Remove_from_cache ( const EventType::KeyType& key ); 
    
    /**
     * \brief Returns the number of written events
     */
    uint64_t Written_Number() const { return m_written_number; }

    /**
     * \brief Returns the number of bytes written in the file
     */
    uint64_t Written_Size() const { return m_written_size; }      


    /**
     * \brief Caching policy allowed
     */
    typedef enum {
    	Cache,   // Write the events in the cache
    	Disk     // Write the events on disk
    	/*,	Discard*/} CachingPolicy;

    /**
     * \brief Set the cache policy to the required value
     *
     * When changing from Cache to Disk policy, the events still presents
     * in the cache are flushed on disk.
     */
    template<CachingPolicy Policy>
    void WriteOn();
    
    /** \brief Return the current position of the writing pointer on the disk */
    uint64_t tellp() { return m_o_events_file.tellp(); }

private:
    void write_on_cache( const EventType& in );
    void write_on_disk( const EventType& in );
    // uint64_t write_on_null( const EventType& in );    
    
    void Cache_Flush();
    void Cache_Discard();    
    
  
    boost::function<void (const EventType& )> write_on; ///< pointer to teh current writing function
    
    std::ofstream   m_o_events_file;     ///< handler to the output event file
    boost::mutex    m_mutex;             ///< mutex for thread safe access
    std::string     m_event_string;      ///< buffer for the event to be written

    // boost::iostreams::stream<boost::iostreams::mapped_file_sink> m_o_events_file;
    // boost::iostreams::mapped_file_params p;
   
    boost::filesystem::path m_url;
    boost::filesystem::path m_cache_file;
    
    bool m_is_caching;
    
    std::vector<EventType> m_cache_ram;
    
    boost::posix_time::ptime start, stop;  // profiling variables

    std::map<std::string, unsigned long>   m_written; ///< number of events written, grouped by id
    uint64_t m_written_number;  ///< total number of the written events
    uint64_t m_written_size;    ///< total size of the written events in byte
};

// } // namespace serialization
} // namespace data

#endif

