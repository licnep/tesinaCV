/**
 * \file CLaserScanner.h
 * \brief Device modeling a generic LaserScanner (LIDAR) system
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _CLASERSCANNER_H
#define _CLASERSCANNER_H

#include <vector>
#include <stdint.h>
#include <boost/multi_array.hpp>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <Data/CScan/CScan.h>
#include <Devices/Base/CSensor.h>
#include <Devices/Base/TFrame.h>

#include <Data/CImage/Pixels/RGBA8.h> // necessary for the echo colors
#include <Devices/gold_dev_export.h>

namespace dev
{
/**
 * \brief Device modeling a generic LaserScanner (LIDAR) system
 */
class GOLD_DEV_EXPORT CLaserScanner: public CSensor
{
public:

	/** \brief Alias for the frame type; required by the infrastructure */
	typedef TFrame<data::CScan> FrameType;

	/** \brief Alias for the signal type used to notify a new frame to the user */
#ifdef USE_BOOST_SIGNAL2
	typedef boost::signals2::signal<void(const FrameType& frame)> SignalType;
#else
	typedef boost::signal<void(const FrameType& frame)> SignalType;
#endif
	/** \brief Default constructor */
	CLaserScanner();

	/** brief Virtual destructor */
	virtual ~CLaserScanner();

	/**
	 * \brief Register a callback that will be called every time a new data is captured.
	 *
	 * If the driver receive the data in a separate thread, the user function will be
	 * invoked from that thread.
	 */
	void Do_On_Frame_AsyncReceived(
			boost::function<void(const FrameType& frame)> slot);

	/** \brief Colors for drawing layers */
	typedef boost::multi_array<cimage::RGBA8, 2> PulsesColorType;

	/** \brief Returns Colors for drawing layers */
	virtual const PulsesColorType& PulsesColor() = 0;

protected:
	/** \brief Returns the maximum number of points managed by the device */
	static const uint32_t MaxNumPulses()
	{
		return 5000;
	}

	/** \brief Returns the maximum number of layers managed by the device */
	static unsigned int Default_NumLayers()
	{
		return 4;
	}

	/** \brief Returns the maximum number of pulses per layer managed by the device */
	static unsigned int Default_NumPulsesPerLayer()
	{
		return 2000;
	}

	/** \brief Initialization code. \see CModule */
	void On_Initialization();

	/** \brief Shutdown code. \see CModule */
	void On_ShutDown();

	/** \brief Code called when device-specific parameters are saved. \see CModule */
	void On_SaveParams(INIFile& ini);

	/** \brief Notify the user functions with the new captured data */
	void Notify_Frame_Received_Async(const FrameType& frame);

	ui::wgt::Widget panel; ///< The user interface panel for the current device

private:
	SignalType m_signal_async; ///< Signal for synchronous notification of frames to the users
};

}

#endif
