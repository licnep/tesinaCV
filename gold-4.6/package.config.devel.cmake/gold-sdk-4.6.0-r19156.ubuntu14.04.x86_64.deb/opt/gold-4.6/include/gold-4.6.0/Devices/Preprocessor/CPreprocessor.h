/**
 * \file CPreprocessor.h
 * \brief Interface class for a device independent preprocessor
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef PREPROCESSOR_H
#define PREPROCESSOR_H

#include <string>

namespace dev
{


class Preprocessor
{
public:
	/**
	 * \brief Insert a new node in the preprocessing tree
	 * \param preproc_string The preprocessing configuration string
	 */
	void Insert(const std::string& preproc_string)=0;

	/**
	 * \brief Erase a preprocessing node from the preprocessing tree
	 * \param name Name of the preprocessing node to be erased
	 */
	void Erase(const std::string& name)=0;

	/**
	 * \brief Find a preprocessor node the preprocessor
	 * \param Name name of the note to find
	 * \return The Node found
	 */
	CPreprocessorNode& Find(const std::string& name)=0;

	/**
	 * Return the available preprocessing node list
	 * \return the list of all available nodes
	 */
	const std::list<std::string>& Sources() const = 0;

	/**
	 * \brief Returns the list of the available plugins that can be used as preprocessing nodes
	 * \return the list of the available plugins that can be used as preprocessing nodes
	 */
	const std::list<std::string>& Plugins() const = 0;
};

} // namespace dev

#endif
