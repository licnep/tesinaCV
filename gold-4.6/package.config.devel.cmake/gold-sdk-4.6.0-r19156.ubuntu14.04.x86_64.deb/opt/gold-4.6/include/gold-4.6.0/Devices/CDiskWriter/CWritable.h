/**
 * \file CWritable.h
 * \brief Allow the user to specify, to the disk writer, how to save a data
 *
 * CWritable is an interface that the user can inherit and specialize
 * to specify how a particular kind of data should be saved
 * It is made of a class, whose pointer is stored in the CDiskWriter queues
 * during the recording, and from a template, derived, class that the user
 * (who has some kind of data to record) may specialize.
 * This class allows to break the dependency of the CDiskWriter from the data definition
 * leaving the knowledge of the serialization details on the data definiiton side.
 *
 * This class is similar to a package that the DiskWriter may handle and where the user inserts
 * the object to be recorded and the information on how to record.
 *
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _CWRITABLE_H
#define _CWRITABLE_H

#include <string>

#include <boost/shared_ptr.hpp>
#include <boost/function.hpp>

#include <Libs/Time/TimeUtils.h>
#include <Devices/gold_dev_export.h>

namespace data { class CEvent; }

namespace dev
{

/**
 * \brief Interface class for serializing an object through the CDiskWriter
 *
 */
class GOLD_DEV_EXPORT CWritable
{
	boost::shared_ptr<data::CEvent> m_event;    ///< index data
	std::string m_location; ///< name of the file to be written
	uint8_t m_track_id; ///< identifier of the track to be used for the recording

public:

	/**
	 * \brief Constructor accepting an event and a track identifier
	 * \param event shared pointer to a CEvent describing the data
	 * \param track_id identifier of the track released by CDiskWriter::RegisterTrack
	 */
	CWritable(boost::shared_ptr<data::CEvent> event, uint8_t track_id);

	/**
	 * \brief Constructor accepting an event and a file location
	 * \deprecated use the other constructor
	 */
	CWritable(boost::shared_ptr<data::CEvent> event, const std::string& location);

	/**
	 * \brief Virtual destructor
	 */
	virtual ~CWritable();

	/** \brief Set the track number that will be used for recording the current object */
	void SetTrackID(uint8_t track_id);

	/** \brief Returns the event passed as argument to the constructor */
	const data::CEvent& Event() const;

	/** \brief Returns the Location passed as argument to the constructor */
	const std::string& Location() const;

	/**
	 * \brief Expands a variable in Location using Value
	 * \param var_name The name of the variable to be expanded
	 * \param value The value of the variable
	 */
	void Expand(const std::string& var_name, const std::string& value);

	/** \brief Called when the associated resource/file has to be removed. Default is doing nothing. */
	virtual void Remove_Resource();

	/** \brief Called when the payload in RAM has to be deleted. Default is doing nothing. */
	virtual void Destroy_Payload();

	/** \brief Returns the number of samples included in this CWritable. Default is 1 */
	virtual uint64_t NumSamples() const;

	/** \brief Returns the size of the data in memory */
	virtual uint64_t Size() const = 0;

	/** \brief Save the data and returns the data actually written */
	virtual uint64_t Save() const = 0;

	/** \brief Save the data on the stream passed as argument */
	virtual void Save(std::ostream& ostr) const = 0;

	/** \brief Save metadata on a stream */
	virtual void Save_Metadata(std::ostream& ostr) const = 0;

	/** DEBUG purposes ony. Returns the number of reference to the internal data. Default is 0 */
	virtual uint64_t use_count() const;

	/** \brief Returns the track id passed as argument to the constructor */
	uint8_t TrackID() const;

	/** \brief function to be called when a resource needs to be removed */
	boost::function<void()> on_remove_resurce;
};

/** \brief Alias for a shared pointer to a CWritable */
typedef boost::shared_ptr<CWritable> spCWritableType;

/**
 * \brief Generic class for implementing a TWritable for a certain type.
 * A TWritable is the concrete object instantiated by the writer, used
 * to pass the data to be written to the disk writer.
 * A TWritable need to be specialized for every different object type that
 * need to be written by the DiskWriter.
 * Each method needs to be redefined in order to get the correct behavior.
 * \code
 * template<>
 * class TWritable<cimage::CImage::SharedPtrConstType> :
 *       public CWritable
 *       {
 *       // redefine here the methods
 *       };
 * \endcode
 * \tparam T Object Type. This shall be replaced with the object which is managed
 * from a certain specialization.
 * \tparam W Dummy type. This dummy type is necessary do make differences among
 * different specialization for the same object. This might be used for managing
 * different classes of formats, such as still images and movies for the images.
 */
template<class T, class W = void>
class TWritable: public CWritable
{
public:
	/** \brief Alias for the object type */
	typedef T ObjType;

	/**
	 * \brief Constructor for a writable object
	 * \param event shared pointer to the CEvent ot be serialized
	 * \param location location where to write the data
	 * \param object object to be serialized. ATTENTION: in the default implementation the object is copied.
	 * Specializations may use smart pointers or other fancy stuff, with care.
	 */
	TWritable(boost::shared_ptr<data::CEvent> event, const std::string& location,
			const T& object) :
			CWritable(event, location), m_object(object)
	{
	}

	/**
	 * \brief Virtual destructor. This is necessary, since the DiskWriter
	 * stores long queues of CWritables and calls these functions through the
	 * virtual interface of CWritable.
	 */
	virtual ~TWritable()
	{
	}

	/** \brief Returns the number of samples included in the object. Default is 1 */
	virtual uint64_t NumSamples()
	{
		return 1uL;
	}

	/** \brief Returns the size of the object in memory. Default is sizeof(m_object) */
	virtual uint64_t Size() const
	{
		return sizeof(m_object);
	}

    /**
     * \brief Method that serialize the object on the requested location.
     * This function is called asynchronously by the DiskWriter
     * Therefore all the object shall be allocated and in a consistent status
     * \return the number of bytes actually written on disk
     */
	virtual uint64_t Save() const;

    /**
     * \brief Method that serialize the object on a stream.
     * This function is called asynchronously by the DiskWriter
     * Therefore all the object shall be allocated and in a consistent status
     * \param ostr the open stream where the object must be serialized
     */
	virtual void Save(std::ostream& ostr) const
	{
	}

    /**
     * \brief Method that serialize the object metadata on a stream.
     * This function is called asynchronously by the DiskWriter
     * Therefore all the object shall be allocated and in a consistent status
     * \param ostr the open stream where the metadata must be serialized
     */
	virtual void Save_Metadata(std::ostream& ostr) const
	{
	}

	/** \brief Returns a const reference to the internal object */
	const ObjType& operator()() const
	{
		return m_object;
	}

private:
	T m_object; ///< Instance of the internal object
};

} // namespace dev

#endif
