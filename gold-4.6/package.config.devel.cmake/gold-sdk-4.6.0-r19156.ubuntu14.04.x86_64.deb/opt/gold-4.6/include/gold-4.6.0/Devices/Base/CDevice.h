/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * \file CDevice.h
 * \brief Base class modeling a device for user applications.
 * \author Paolo Grisleri (grisleri@vislab.it)
 * \date 2010-06-20
 */

#ifndef _CDEVICE_H
#define _CDEVICE_H

#include <UI/Panel/Widget.h>
#include <UI/CWindows/WindowsMap.h>
#include <Framework/HWS_Version.h>

#include <Devices/gold_dev_export.h>

#include <boost/property_tree/ptree.hpp>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <boost/system/error_code.hpp>

#include <string>
#include <cmath>

namespace vl{ namespace ini {class INIFile;} } using vl::ini::INIFile;


/**
 * \brief Provides types, classes, and functions for managing abstract devices in user code, such as applications or processing libraries.
 */
namespace dev
{
/**
 * \defgroup Devices Devices
 * \brief 2 Provides types, classes, and functions for managing abstract devices in user code, such as applications or processing libraries.
 * \{
 * \}
 **/


/**
 * \addtogroup Devices
 * \{
 **/

  /**
   * \brief Base class for modeling devices.
   * Contains the basic properties and methods for implementing concrete devices.
   **/
  class GOLD_DEV_EXPORT CDevice
  {
    public:
      CDevice();

      /**
       * \brief Returns the device name
       * \return const reference to a string containing the device name
       */
      const std::string& Name() const;

      /**
       * \brief Returns the device vendor
       * \return const reference to a string containing the device vendor
       */
      const std::string& Vendor()const;

      /**
       * \brief Returns the device model
       * \return const reference to a string containing the device model
       */
      const std::string& Model() const;

      /**
       * \brief Returns the device name
       * \return const reference to a string containing the device serial number
       */
      const std::string& Serial()const;

      /**
       * \brief Returns the device interface
       * \return const reference to a string containing the device interface name
       */
      const std::string& Interface()const;

      /**
       * \brief Returns the device description
       * \return const reference to a string containing the device description
       */
      const std::string& Description()const;
      
      /**
       * \brief Returns a string containing the requested property value
       * \param [in] key identifier of the property
       * \return const reference to a string containing the property value
       */
      const std::string& GetPropertyValue(const std::string& key) const;
      
      /**
       * \brief Returns map of CWindowsProxy, containing the views supplied from the device
       * Applications may call this methods for obtaining or changing the visibility status of a view.
       * \return map of CWindowsProxy to the available views
       */
      ui::win::WindowsMap::CWindowsProxiesMap& Views();

      /**
       * Typedef for the user callbacks to be notified whenever an error occurs in the device
       */
#ifdef USE_BOOST_SIGNAL2
      typedef boost::signals2::signal<void(boost::system::error_code)> SignalNotificationType;
#else
      typedef boost::signal<void(boost::system::error_code)> SignalNotificationType;
#endif


      /**
       * \brief Allow users to subscribe the notifications of errors.
       * Depending on the error type, the device may disappear from the DeviceManager
       * \param [in] cb User callback invoked from the device when an error condition occurs
       */
      void Subscribe_Notification(boost::function<void(boost::system::error_code)> cb);
            
    protected:

      /**
       * This method shall be called explicitly from derived classes
       * for executing initialization code
       */
      void On_Initialization();

      /**
       * This method shall be called explicitly from derived classes
       * for executing destruction code
       */
      void On_ShutDown();

      /**
       * This method shall be called explicitly from derived classes
       * for loading parameters from initialization file
       */
      void LoadParams(const INIFile& ini, hws::Version version);

      /**
       * This method shall be called explicitly from derived classes
       * for saving parameters from initialization file
       */
      void SaveParams(INIFile& ini, hws::Version=hws::V_1_1);
      
       /**
       * This method shall be called explicitly from derived classes
       * for saving parameters to a newly recorded initialization file
       */
      void Recording_SaveParams(INIFile& ini, hws::Version version=hws::V_1_1);  
      
      /**
       * Changes the "Name" property
       * \param [in] name string containing the new value for the property
       */
      void Rename ( const std::string& name );

      /**
       * Changes the "Vendor" property
       * \param [in] vendor string containing the new value for the property
       */
      void SetVendor(const std::string& vendor);

      /**
       * Changes the "Vendor" property
       * \param [in] model string containing the new value for the property
       */
      void SetModel(const std::string& model);

      /**
       * Changes the "Vendor" property
       * \param [in] serial string containing the new value for the property
       */
      void SetSerial(const std::string& serial);

      /**
       * Changes the "Interface" property
       * \param [in] iface string containing the new value for the property
       */
      void SetInterface(const std::string& iface);

      /**
       * Changes the "Description" property
       * \param [in] description string containing the new value for the property
       */
      void SetDescription(const std::string& description);
      
      /**
       * Notify an error condition to the subscribers
       * \param [in] ec error condition to be notified
       */
      void Notify(boost::system::error_code ec);
      
      ui::wgt::Widget panel; ///< device panel
      ui::win::WindowsMap views; ///< views map
      
    private:
      
      boost::property_tree::ptree m_properties; ///< storage for the properties
      SignalNotificationType m_signal;          ///< signal for errors notification
  };

  /**@}*/

}

#endif
