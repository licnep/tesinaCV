/**
 * \file CCAN.h
 * \brief Device modeling a generic CAN interface
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>,  Pietro Cerri (cerri@ce.unipr.it), Stefano Ghidoni (ghidoni@ce.unipr.it)
 */

#ifndef _CCAN_H
#define _CCAN_H

#include <string>
#include <map>

#include <boost/date_time/posix_time/posix_time_types.hpp>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <boost/ptr_container/ptr_map.hpp>
#include <boost/thread/thread.hpp>
#include <boost/any.hpp>

#include <stdint.h>

#include <Libs/Threads/CTSQueue.hxx>
#include <Libs/INIFiles/INIFile.h>

#include <Data/CCANData/CANData.h>
#include <Devices/Base/CSampler.h>
#include <Devices/Base/TFrame.h>
#include<Devices/Base/CDevice.h>

#include <Devices/gold_dev_export.h>

namespace dev
{
  
/**
 * \brief Device modeling a generic CAN interface
 *
 * This class models a physical can interface that can be used inside
 * applications. A method for registering a callback invoked when a packet is received
 * is available as well as another for registering a callback related to periodic send.
 * There are also method for subscribing high level decoded data.
 * The interface is configured in the HWS file.
 * TODO add a list of the ids for the received messages
 */
class  GOLD_DEV_EXPORT CCAN :
  public CDevice 
{
  public:

	/** \brief Default constructor */
	CCAN();

	/** \brief Virtual destructor */
	virtual ~CCAN();

	/**
	 * \brief The frame type provided by this device is a CCANData
	 */
    typedef TFrame<data::CCANData> FrameType;

    /** \brief Type for the callback ivoked when a frame is received */
#ifdef USE_BOOST_SIGNAL2
    typedef boost::signals2::signal< void (const FrameType&) > SignalRecvType;
#else
    typedef boost::signal< void (const FrameType&) > SignalRecvType;
#endif


    /** \brief Type for the callback invoked when a packet must be sent */
#ifdef USE_BOOST_SIGNAL2
    typedef boost::signals2::signal< void (uint8_t *data, unsigned int length) > SignalSendType;
#else
    typedef boost::signal< void (uint8_t *data, unsigned int length) > SignalSendType;
#endif

    /** \brief alias for shorter declarations */
    typedef boost::ptr_map<unsigned int, SignalRecvType> SignalMap;

    /**
     * \brief Method for registering a new callback invokend when a frame is received by the interface
     * \param id identifier of the CAN message associated to the callback.
     * The callback will be invoked when a message with identifier id is received.
     * \param slot the callback to be invoked.
     * \code
     * m_pcan->Do_On_Frame_AsyncReceived(0x1f1, boost::bind(&CWPF::On_GPSData_Received, this, _1));
     * \endcode
     */
    void Do_On_Frame_AsyncReceived(unsigned int id, boost::function<void ( const FrameType& frame )> slot);

    /**
     * \brief Register a callback to be invoked every period, for sending a message with identifier id
     * \param id identifier of the CAN message associated to the callback.
     * \param period interval between two successive invocation of the callback
     * \param slot callback to be invoked.
     * \code
     * m_pcan->Do_On_PeriodicSend(0x1f1,
     * 							  boost::posix_time::milliseconds(100),
     * 							  boost::bind(&CWPF::On_GPSData_Send, this, _1));
     * \endcode
     */
    void Do_On_PeriodicSend(unsigned int id, vl::chrono::TimeType period, const SignalSendType::slot_type& slot);

    /**
     * \brief Writes directly a CCANData on the current interface. Blocking, not reentrant.
     * \param can_data CCANData to be writted on the interface
     * \return true when the operation succeeded
     */
    bool Send(const data::CCANData& can_data);

    /**
     * \brief return a const reference to the last package read from the interface
     * \return a const reference reference to the last package read from the interface
     */
    const data::CCANData& CANData() const { return m_pCANData->Data; };

    // preprocessor related section

    /** \brief Callback Type for receiving a data decoded from the CAN Preprocessor */
#ifdef USE_BOOST_SIGNAL2
    typedef boost::signals2::signal< void ( const boost::any& ) > SignalDecodeType;
#else
    typedef boost::signal< void ( const boost::any& ) > SignalDecodeType;
#endif

    /** \brief Callback Type for sending a data encoded with the CAN Preprocessor */
#ifdef USE_BOOST_SIGNAL2
    typedef boost::signals2::signal< void ( const boost::any& ) > SignalEncodeType;
#else
    typedef boost::signal< void ( const boost::any& ) > SignalEncodeType;
#endif

    /** \brief Direct send type */
#ifdef USE_BOOST_SIGNAL2
    typedef boost::signals2::signal< void ( const data::CCANData& ) > SignalDirectSendType;
#else
    typedef boost::signal< void ( const data::CCANData& ) > SignalDirectSendType;
#endif

    /**
     * \brief Register a user callback for receiving an high level data decoded from the CAN Preprocessor
     * \param name string containing the name of the decoding node
     * \param slot boost::function containing the callback to be invoked when the preprocessor has completed the decoding
     * \code
     * m_pCAN->Subscribe_Decoding("GPS", boost::bind(&CWPF::On_GPSData_Received, this, _1));
     * \endcode
     **/
    virtual void Subscribe_Decoding(const std::string& name, const SignalDecodeType::slot_type& slot) = 0;

    /**
     * \brief Read directly a data decoded by the preprocessor
     * \param name string containing the name of the decoding node
     */
    virtual boost::any Get_Value(const std::string& name) = 0;

    /**
     * \brief Write directly a data encoded by the preprocessor
     * \param info boost::any containing a copy of the high level data to be encoded
     * \param name string containing the name of the encoding node
     */
    virtual void Send_Value(const boost::any& info , const std::string& name) = 0;
    
    /**
     * \brief Old interface for subscribing the receive of messages with a certain id
     * \deprecated Use Subscribe_Recv instead
     */
    GOLD_DEV_DEPRECATED void Subscribe_ID(unsigned int ID,  boost::function<void ( const FrameType& Frame )> slot) { Do_On_Frame_AsyncReceived(ID, slot); }
    void Subscribe_Recv(unsigned int ID,  boost::function<void ( const FrameType& Frame )> slot) { Do_On_Frame_AsyncReceived(ID, slot); }

  protected:
    /** \brief Width of the user interface panel */
    static unsigned int DisplayW() { return 500; }

    /** \brief Height of the user interface panel */
    static unsigned int DisplayH() { return 500; }

    /** \brief Used by implementations for dispatching a new frame */
    void Dispatch( const FrameType& frame );

    vl::thread::CTSQueue<data::CCANData> CANWriteQueue; ///< Queue of the messages to be written

    /** \brief Suspend the current interface */
    void CAN_Suspend();

    /** \brief Resume the current interface */
    void CAN_Resume();

    /** \brief Implementation reserved: destroys all the structures dedicated to the sending of messages */
    void DestroySendingStructures();

    /**
     * \brief Driver-specific code for sending a message.
     *
     * Default implementation is throwing an std::runtime_error
     */
    virtual void On_Send(const data::CCANData& message);

  private:
    /** \brief Pointer to the last received FrameType */
    const FrameType* m_pCANData;

    /**
     * \brief Map associating each id to the signal containing all the user-registered callbacks related to that id
     */
    SignalMap SignalTable;

    /**
     * \brief Class for collecting all the necessaries information for sending messages
     */
    struct CyclicSendThreadData
    {
      data::CCANData  Packet;   ///< can packet to be send
      vl::chrono::TimeType  Period;   ///< period between two sends
      SignalSendType Signal;  ///< signal to be signalled
      boost::thread Thread; ///< thread
      CCAN*     This; ///< pointer to the interface owning the descriptor
    };

    /** \brief Method containing the loop for sending a periodic message */
    void CyclicSend_Thread(CyclicSendThreadData* cstd);

    /** \brief vector collecting all the CyclicSendThreadData descriptor related to this interface */
    std::vector<CyclicSendThreadData*> m_send_data;

    bool m_exit_requested;  ///< true when the termination of the writing threads has been requested
    bool m_can_enabled;  ///< share the enable state with the derived classes

    /** \brief thread object for writing directly on the interface */
    boost::thread m_can_write_queue_thread;

    /** \brief thread for writing directly on the interface */
    void CANWriteQueue_Thread();
};

/** \brief Definitions and classes related to the CAN interface */
namespace can{}

}// namespace dev
#endif
