/**
 * \file VLA_Archive.h
 * \brief Classes for reading and writing files encoded with the VisLab Archive format
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */
#ifndef _VL_ARCHIVE
#define _VL_ARCHIVE

#include <fstream>
#include <vector>
#include <map>

#include <stdint.h>

#include <boost/filesystem/path.hpp>

#include <Devices/gold_dev_export.h>

/** \brief Classes for managing VLA (VisLab Archives) files */
namespace vla
{

/**
 * @addtogroup GRP_VLA_FILE_FORMAT VLA File Format
 * \brief Description of the VLA file format
 *
 * @{
 * \page VLA_File_Format
 * \section VLA_File_Format_Description Description
 * VLA, acronym for VisLab Archive, is a file format for recording and playing back efficiently
 * multitrack set of data produced from a fixed setup.
 *
 * \subsection Features
 *
 * Support for up to 256 different tracks.
 *
 * Support for arbitrary data format.
 *
 * Support for metadata.
 *
 * Support for signature.
 *
 * \section VLA_File_Format_Format Format
 * The format is made of two files, one file containing the data, and one containing the index.
 *
 * \subsection VLA_File_Format_Index Index file
 * The index file starts with an header IndexHeader with the following structure
 *
 * \code
 * uint8_t  magic[4];  // Magic sequence for format identification: "VLA\0"
 * uint16_t version;   // Version number. Currently 1
 * uint8_t  num_tracks;// Number of tracks
 * \endcode
 *
 * The index is followed by num_tracks Track structures, each of which describes one of the track
 * included in the index/data pair.
 *
 * Then a great number of BlockHeader structures follows until the end of the file.
 *
 * \code
 * IndexHeader
 * Track 1
 * Track 2
 * Track 3
 * ...
 * Track n
 * BlockHeader 1
 * BlockHeader 2
 * BlockHeader 3
 * ...
 * BlockHeader m
 * \endcode
 *
 * \subsection VLA_File_Format_Data VLA (aka data) file
 * The data file is a sequence of files, and metadata freely managed by the user.
 * The writing operations are the following:
 *
 * \code
 * update the BlockHeader data.offset field using the current data stream position
 * data serialization using the requested format
 * update the BlockHeader data.size using the difference between the current data stream position and the data.offset field
 * update again the BlockHeader metadata.offset field using the current data stream position
 * serialize the metadata
 * update the BlockHeader metadata.size using the difference between the current data stream position and the data.offset field
 * \endcode
 *
 * metadata may include signature, additional data such as exif, encoded in a proper format and similar.
 * @}
 */
  
#pragma pack(push)
#pragma pack(1)

/** \brief class for mapping the index header */
class IndexHeader
{
public:
  
  /** \brief fills the magic field with the VLA-specific byte sequence */
  void fill()
  {
    magic[0]='V';
    magic[1]='L';
    magic[2]='A';
    magic[3]=0x00;
    version = 1;
  }
  
  uint8_t  magic[4];  ///< Magic sequence for format identification
  uint16_t version;   ///< Version number
  uint8_t  num_tracks;///< Number of tracks
};

/** \brief Class representing one track */
struct Track
{
	/** \brief Available signature types */
  typedef enum {
	  NO_SIGNATURE, ///< Do not compute signature
	  MD5,          ///< Compute an MD5 signature
	  PGP_ENCRYPTED_MD5 ///< compute an MD5 signature encrypted with PGP
  } SignatureType;

  /** \brief Default constructor: clean up all the fields */
  Track() 
  {

    std::fill(name, name+sizeof(name), 0);
    std::fill(filename, filename+sizeof(filename), 0);
    std::fill(ser_format, ser_format+sizeof(ser_format), 0);    
    std::fill(ser_params, ser_params+sizeof(ser_params), 0);    
    std::fill(md_format, md_format+sizeof(md_format), 0);
    std::fill(reserved, reserved+sizeof(reserved), 0);
  }
  
  /**
   * \brief Constructor. Clean up all the buffers.
   * \param _id track identifier
   * \param _filename template name of the file names associated to the track
   * this include unexpanded variables
   * \param _ser_format string representing the requested serialization format (this must be expanded)
   * \param _ser_params parameters used for the serialization,
   * \param _md_format string representing the metadata format (this must be expanded)
   */
  Track(const std::string& _id, 
        const std::string& _filename, 
        const std::string& _ser_format, 
        const std::string& _ser_params,
        const std::string& _md_format
       )
  {
    // buffers cleanup
    std::fill(name, name+sizeof(name), 0);
    std::fill(filename, filename+sizeof(filename), 0);
    std::fill(ser_format, ser_format+sizeof(ser_format), 0);    
    std::fill(ser_params, ser_params+sizeof(ser_params), 0);    
    std::fill(md_format, md_format+sizeof(md_format), 0);
    std::fill(reserved, reserved+sizeof(reserved), 0);

    // arguments copy
    std::copy(_id.begin(), _id.end(), name);
    std::copy(_filename.begin(), _filename.end(), filename);
    std::copy(_ser_format.begin(), _ser_format.end(), ser_format);
    std::copy(_ser_params.begin(), _ser_params.end(), ser_params);
    std::copy(_md_format.begin(), _md_format.end(), md_format);
    
    // fills the remaining fields
    frame_num_w=6;
    frame_num_offset=0uL;
    signature_type=NO_SIGNATURE; 
    data_signature_size=0; 
  }
  
  /** \brief Returns the file extension */
  std::string extension() const
  {
    return boost::filesystem::path(filename).extension().string();
  }
  
  char name[1024];       ///< track name zero-terminated
  char filename[1024];   ///< filename format zero terminated
  char ser_format[1024]; ///< serialization format zero terminated
  char ser_params[1024]; ///< serialization params zero terminated
  char frame_num_w;      ///< number of digits for the framenumber
  uint64_t frame_num_offset; ///< offset for the framenumber (for future use)
  char     md_format[1024]; ///< serialization format zero terminated
  SignatureType signature_type; ///< signature type at the end of each data 0 means no signature
  uint32_t data_signature_size; ///< there is a signature at the end of each data 0 means no signature
  uint8_t  reserved[1024];  ///< reserved for future uses
};


// #define TRACK_ID_SIZE 32

/** \brief Class representing the header of a block */
struct GOLD_DEV_EXPORT BlockHeader
{
	/** \brief Cleanup all the files */
    BlockHeader();

    uint64_t time_code;    ///< object timecode [us]
    uint8_t  track_id;     ///< track identifier
    std::streamoff data_offset; ///< offset in the data file 
    std::streamoff data_size;   ///< object size
    uint64_t       num_objects; ///< number of objects (usually 1)
    std::streamoff mtd_offset;  ///< metadata offset in the data file 
    std::streamoff mtd_size;    ///< metadata size
    uint8_t  reserved[64]; ///< reserved for future uses
};

#pragma pack(pop)

// m_ofs_idx << td::setw(32) << std::setfill(' ') << Object->Event().Key()
//           << std::setw(16) << Object->Event().ID()
//           << std::setw(16) << std::setfill(' ') << Object->Event().FrameNumber() 
//           << std::setw(32) << std::setfill(' ') << p_offset 
//           << std::setw(32) << std::setfill(' ') << p_size                     
//           << std::setw(32) << m_ObjectName
//           << std::endl;

/** \brief Writes a BlockHeader on a stream */
GOLD_DEV_EXPORT void write(const BlockHeader& fh, std::ofstream& ofs);

/** \brief Reads a BlockHeader from a stream */
GOLD_DEV_EXPORT void read(std::ifstream& ifs, BlockHeader& fh);

/** \brief  Structure collecting data and index streams */
template<typename StreamType>
struct tfs
{
    StreamType data; ///< stream containing data
    StreamType index;///< stream containing the index
};

/** \brief Alias for input ... */
typedef tfs<std::ifstream> IFSType;

/** \brief Alias for output ... */
typedef tfs<std::ofstream> OFSType;

/**
 * \brief Class for reading a file encoded using the VisLab Archive format.
 * To use the reader it is necessary to open a valid file and subscribe a track
 * One reader can follow one track at time. The seek function moves the pointer across
 * the different blocks (contained files) of the same track.
 */
class GOLD_DEV_EXPORT Reader
{
public:
	/** \brief Alias for the index type: a vector of blocks */
    typedef std::vector<BlockHeader> IndexType;

    /** \brief Alias for a slice of the index: a vector of const pointers to blocks */
    typedef std::vector<const BlockHeader*> PIndexType;

    /** \brief Defautl constructor: clean up everithing */
	Reader();

	/** \brief Destructor */
    ~Reader();

    /**
     * \brief Open a file encoded using the VisLab Archive format.
     * \param path path of the file to be open
     * \return a boost::system::error_code containing the error code of the operation
     * boost::system::errc::success when the file has been open successfully
     * boost::system::errc::bad_file_descriptor when the open function fails
     */
    boost::system::error_code Open(const boost::filesystem::path& path);

    /**
     * \brief Set the track to be used by the current reader.
     * \param id Track ID to be used by the current reader.
     * \return a boost::system::error_code containing the error code of the operation
     * boost::system::errc::success when the subscription succeded
     */
    boost::system::error_code Subscribe(const std::string& id);

    /**
     * \brief Moves the pointer to the requested frame.
     *
     * The number of frames can be retrived using Index().size()
     * \param frame_num
     */
    boost::system::error_code Seek(uint64_t frame_num);

    /**
     * \brief Returns an handler to the data stream, to phisically read the block.
     */
    std::ifstream& ifs_data();    

    /** \brief Returns a reference to the IndexHeader of the file */
    const IndexHeader& Header() const;

    /** \brief Returns a reference to the Table of the tracks */
    const std::vector<vla::Track>& Tracks() const;

    /** \brief Returns a reference to the subscribed track */
    const vla::Track& Track() const;

    /** \brief Returns a reference to the index of the blocks of the subscribed track */
    const std::vector<BlockHeader>& Index() const;

    /** \brief Returns a map with all the track indexes */
    const std::map<uint8_t, Reader::PIndexType>& TrackIDX() const;

private:
    boost::filesystem::path m_path;  ///< path of the current file
    IFSType*     m_ifs;              ///< input index and data streams
    PIndexType*  m_index;            ///< pointer to the track index
    uint64_t     m_curr_frame_number; ///< current frame number
    uint8_t      m_track_id;         ///< subscribed track
};



/**
 * \brief Class for writing a file encoded using the VisLab Archive format.
 * To use the writer it is necessary to open a valid file. Then the files can be
 * written using the Write method for submitting the BlockHeader to the index
 * and the ofs_data for writing the data directly on the stream.
 */
class GOLD_DEV_EXPORT Writer
{
    OFSType m_ofs;

public:
    /**
     * \brief Opens the requested file.
     * Two files are created: one data file with the requested extension
     * and one index with the same name but extension replaced with ".idx"
     */
    void Open(const boost::filesystem::path& path, const std::vector<Track>& tracks);

    /**
     * \brief Returns true if the Writer has open a file correctly
     */
    bool IsOpen() const { return m_ofs.data.is_open(); }

    /**
     * \brief Closes the requested file.
     */
    void Close(const boost::filesystem::path& path);

    /** \brief Writes a new block header in the index */
    void Write(const BlockHeader& fh);

    /** \brief Returns a reference to the ostream opened on the data file */
    std::ofstream& ofs_data();  
    
private:    
    void WriteHeader(std::ofstream& ofs, const std::vector<Track>& tracks);
};

/**
 * \brief Function for signing the data
 * The sing is written on the stream starting from the current position
 * The sing is computed using one of the supported algorithms specified by signature_type
 * The sign is computed on the bytes already written on the stream
 * starting from offset, included, to offset+size, excluded.
 * \param ofs output stream where the signature will be stored
 * \param offset first byte of the stream used to compute the signature
 * \param size of the block of byte to be used to compute the signature
 * \param signature_type algorithm to be used to compute the signature
 */
GOLD_DEV_EXPORT 
void Write_Signature(std::ofstream& ofs, 
                     std::streamoff offset,
                     std::streamoff size, 
                     vla::Track::SignatureType signature_type);  
  
} // namespace vla



#endif // _VL_ARCHIVE
