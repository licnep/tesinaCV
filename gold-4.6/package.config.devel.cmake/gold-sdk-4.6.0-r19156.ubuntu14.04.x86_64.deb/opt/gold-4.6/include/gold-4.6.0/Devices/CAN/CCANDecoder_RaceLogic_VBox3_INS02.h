/**
 * \file CCANDecoder_RaceLogic_VBox3_INS02.h
 * \brief CAN Decoder for INS data produced by a RaceLogic VBox3 unit
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Manuel Gargioni
 */

#ifndef CCANDECODER_RACELOGICIMU_H_
#define CCANDECODER_RACELOGICIMU_H_

#include "CCANDecoder.h"
#include "CCANDecoderRegistration.h"

#include <Data/CINSData/CINSData.h>

namespace dev
{
namespace can
{
namespace decoder
{

/** \brief CAN Decoder for INS data produced by a RaceLogic VBox3 unit */
class RaceLogic_VBox3_IMU02 :
	public dev::can::CDecoder
{
public:
	RaceLogic_VBox3_IMU02();
	virtual ~RaceLogic_VBox3_IMU02();
	virtual void Initialize(const boost::property_tree::ptree& ptree,
			std::vector<data::CCANData::IDType>& ids);
	virtual StatusID Decode(const CCAN::FrameType& frame);
private:

	data::CINSData m_data; ///< current data
	uint8_t m_receive; ///< message counter
	std::vector<data::CCANData::IDType> m_ids; // parameters (unused now)
};
} // namespace decoder
} // namespace can
} // namespace dev

#endif /* CCANDECODER_RACELOGICIMU_H_ */
