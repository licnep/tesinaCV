/**
 * \file TFrame.h
 * \brief Template for modeling a generic FrameType with metadata
 * \author Paolo Grisleri <grisleri@vislab.it>
 */


#ifndef _TFRAME_H
#define _TFRAME_H

#include <Libs/Time/TimeUtils.h>
#include <string>

namespace dev
{
  
/**
 * \brief Template for modeling a generic FrameType with metadata
 * \tparam T Type of the data to be used internally
 */
template <typename T> 
struct TFrame
{
  typedef T DataType;

  std::string Name;  ///< Name of the sensor which captured the sample

  DataType  Data;    ///< Typed data representing the sample

  /**
   * \brief Absolute timestamp of the sample.
   * In playback mode is the absolute time at which the data has been captured in the past
   */
  vl::chrono::AbsoluteTimeType AbsTimeStamp;

  /**
   * \brief Timestamp of the sample, relative to the session origin
   */
  vl::chrono::TimeType TimeStamp;

  /**
   * \brief Sample duration.
   */
  vl::chrono::TimeType Duration;

  /**
   * \brief Sample number. In playback can be repeated.
   */
  uint64_t Number;

  /**
   * \brief Sample counter. Always increasing
   */
  uint64_t Counter;

  /**
   * \brief Operator used by STL
   */
  const DataType& operator()() const { return Data; }

  /**
   * \brief Operator used by STL (const version)
   */
  operator const DataType&()   const { return Data; }
};

} // namespace dev

#endif
