/**
 * \file Trigger.h
 * \brief Device modeling a generic trigger.
 *
 * The trigger device can be set up from the HWS file to produce
 * hardware or software trigger used to control other devices.
 *
 * TODO: API to control the timings from software
 *
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 *
 */
#ifndef TRIGGER_H
#define TRIGGER_H

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <Libs/Time/CChronometer.h>
#include <Devices/gold_dev_export.h>
#include <Devices/Base/TFrame.h>
#include <Devices/Base/CDevice.h>

namespace dev
{


/**
 * \brief Device modeling a generic trigger.
 *
 * The TimeTable is a sequence of status belongin to {0,1} each maintained for a fixed amount of time.
 * A TimeTable is a sequence of of Fase. A Fase is a status, belonging to {0,1} associated to a time duration.
 * The trigger device executes periodically a timetable.
 *
 * Every concrete trigger load a timetable of type
 * Here is an example of TIMETABLE loaded from the HWS file
 * TIMETABLE = "0:0:0.050,on","0:0:0.050,off", "0:0:0.050,on","0:0:0.050,off","0:0:1.000,off"
 *
 * Users can register callbacks in their applications to execute stuff whenever the trigger changes status.
 *
 */
class GOLD_DEV_EXPORT CTrigger: public dev::CDevice
{
public:
	/** \brief Dummy class working as placeholder for the frame type required by the infrastructure */
	class TriggerData
	{
	};

    /** \brief Alias for the frame type; required by the infrastructure */
	typedef TFrame<TriggerData> FrameType;

	/** \brief Alias for the signal type used to notify a new frame to the user */
#ifdef USE_BOOST_SIGNAL2
    typedef boost::signals2::signal< void ( const FrameType& Frame ) > SignalType;
#else
    typedef boost::signal< void ( const FrameType& Frame ) > SignalType;
#endif

	/** \brief Default constructor */
	CTrigger();

	/** \brief Virtual destructor */
	virtual ~CTrigger();

	/**
	 * \brief Structure containing the basic information of one trigger phase
	 */
	struct Fase
	{
		/** \brief Defautl constructor. Creates an empty Fase */
		Fase();

        /**
         * \brief Constructor from string.
         * \param s string to be decoded in a Fase
         * The argument shall be in the format: "0:0:0.050,on","0:0:0.050,off", "0:0:0.050,on","0:0:0.050,off","0:0:1.000,off"
         */
		Fase(const std::string& s);

		/**
		 * \brief Constructor accepting a duration and a state
		 */
		Fase(const boost::posix_time::time_duration& d, bool v);

		vl::chrono::TimeType duration; ///< Duration of the trigger phase
		bool value; ///< value of the trigger phase
	};

	/** \brief Alias for the timetable which describe the status and the durations executed by the trigger */
	typedef std::vector<Fase> TimeTableType;

	/**
	 * \brief Register a callback that will be called every time a new data is captured.
	 *
	 * If the driver receive the data in a separate thread, the user function will be
	 * invoked from that thread.
	 */
	void Do_On_Frame_AsyncReceived(
			boost::function<void(const FrameType& frame)> cb);

protected:
	/** \brief Initialization code. \see CModule */
	virtual void On_Initialization();

	/** \brief Shutdown code. \see CModule */
	virtual void On_ShutDown();

	/** \brief Notify the user functions with the new captured data */
	void Notify(const FrameType& frame);

private:
	SignalType m_signal; ///< Signal for synchronous notification of frames to the users
};

} // namespace dev

#endif

