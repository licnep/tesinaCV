/**
 * \file CCANDecoder_RaceLogic_VBox2_GPSINS.h
 * \brief CAN Decoder for GPS and INS data produced by a RaceLogic VBox2SX unit
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Manuel Gargioni
 */

#ifndef CCANDECODER_GPSIMU_H
#define CCANDECODER_GPSIMU_H

#include "CCANDecoder.h"
#include "CCANDecoderRegistration.h"

#include <Data/CGNSSData/CGNSSData.h>
#include <Data/CINSData/CINSData.h>

namespace dev
{
namespace can
{
namespace decoder
{

/** \brief CAN Decoder for GPS and INS data produced by a RaceLogic VBox2SX unit */
class RaceLogic_VBox2_GPSIMU :
public dev::can::CDecoder
{
public:
    RaceLogic_VBox2_GPSIMU();
    virtual ~RaceLogic_VBox2_GPSIMU();
    virtual void Initialize(const boost::property_tree::ptree& ptree , std::vector<data::CCANData::IDType>& ids);
    virtual StatusID Decode(const CCAN::FrameType& frame);
private:    
    uint8_t m_receive;
    data::GNSS m_gps_data;
    data::CINSData m_ins_data;
    std::vector<data::CCANData::IDType> m_ids;
    uint8_t m_invert_2[2];
    uint8_t m_invert_3[3];
    uint8_t m_invert_4[4];
};
} // namespace decoder
} // namespace can
} // namespace dev
#endif // CCANDECODER_GPSIMU_H
