/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * \file CSensor.h
 * \brief Base class modeling a sensor for user applications.
 * \author Paolo Grisleri (grisleri@vislab.it)
 * \date 2010-06-20
 */

#ifndef _CSENSOR_H
#define _CSENSOR_H

#include <UI/Panel/Widget.h>
#include <Data/Base/SensorParams.h>
#include <Devices/Base/CDevice.h>
#include <Devices/Base/CSampler.h>
#include <Devices/gold_dev_export.h>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <boost/filesystem/path.hpp>

#include <string>

namespace dev
{

/**
 * \addtogroup Devices
 * \{
 **/

/**
 * \brief Base class modeling a sensor for  user applications.
 * A sensor is defined as a device having a sampler, a position and an orientation.
 **/
class  GOLD_DEV_EXPORT  CSensor :
    public CDevice
{
public:

    /** Typedef for the floating type used for position and orientation **/
    typedef double FloatingType;

    /** Typedef for shorting the position type **/
    typedef TPosition<double> PositionType;

    /** Typedef for the position user callback **/
#ifdef USE_BOOST_SIGNAL2
    typedef boost::signals2::signal<void (const PositionType& ) >  PositionSignalType;
#else
    typedef boost::signal<void (const PositionType& ) >  PositionSignalType;
#endif



    /** Typedef for shorting the orientation type **/
    typedef TOrientation<double> OrientationType;

    /** Typedef for the orientation user callback **/


#ifdef USE_BOOST_SIGNAL2
    typedef boost::signals2::signal<void (const OrientationType& )> OrientationSignalType;
#else
    typedef boost::signal<void (const OrientationType& )> OrientationSignalType;
#endif

#ifdef USE_BOOST_SIGNAL2
    typedef boost::signals2::connection ConnectionType;
#else
    typedef boost::signals::connection ConnectionType;
#endif


    CSensor();
    virtual ~CSensor();

    /**
     * Returns a const reference to the internal Sampler instance
     * The Sampler contains information about time distribution of data,
     * counters and latest timestamps.
     * \return reference to the internal CSampler instance
     */
    const dev::CSampler& Sampler() const;

    /**
     * Returns a PositionType containing the current sensor position
     * \return PositionType containing the current sensor position
     */
    PositionType& Position() {
        return m_position;
    }

    /**
     * Returns the current X sensor position
     * \return FloatingType containing the current X sensor position
     */
    FloatingType X() const {
        return m_position.x;
    }

    /**
     * Returns the current Y sensor position
     * \return FloatingType containing the current Y sensor position
     */
    FloatingType Y() const {
        return m_position.y;
    }

    /**
     * Returns the current Z sensor position
     * \return FloatingType containing the current Z sensor position
     */
    FloatingType Z() const {
        return m_position.z;
    }

    /**
     * Sets a new sensor position and signals the change to all the subscribers
     * \param [in] new_position PositionType containing the new sensor position
     */
    void SetPosition(const PositionType& new_position)
    {
        m_position=new_position;
        m_position_signal(m_position);
    }

    /**
     * Sets a new sensor position and signals the change to all the subscribers
     * \param [in] X X coordinate of the new sensor position
     * \param [in] Y Y coordinate of the new sensor position
     * \param [in] Z Z coordinate of the new sensor position
     */
    template <class T>
    void SetPosition(T X, T Y, T Z)
    {
        m_position=PositionType(static_cast<FloatingType>(X),
        		static_cast<FloatingType>(Y),
        		static_cast<FloatingType>(Z));
        m_position_signal(m_position);
    }

    /**
     * Sets a new sensor position and signals the change to all the subscribers
     * \param [in] str string containing the new sensor position in the format "X, Y, Z"
     */
    void SetPosition(const std::string& str)
    {
        m_position=PositionType(str);
        m_position_signal(m_position);
    }

    /**
    * Register a callback for receiving a notification whenever the sensor position changes
    * The callback are removed when a new session is opened
    * \param slot pointing to the callback
    * \return boost::signals::connection for enabling, disabling the signalling
    *
    * Example:
    * \code
    * // for free functions
    * m_sensor.Do_On_Position_Change( myfunct );
    *
    * // for methods
    * m_sensor.Do_On_Position_Change( boost::bind(&MyObjectType::On_Change_Position, *this, _1));
    *
    * \endcode
    * \return the connection to the slot. Can be used to temporarily disable the slot
    */

    ConnectionType Do_On_Position_Change(const PositionSignalType::slot_type& slot)
    {
        return m_position_signal.connect(slot);
    }


    /**
     * Returns a OrientationType containing the current sensor position
     * \return OrientationType containing the current sensor position
     */
    OrientationType& Orientation() {
        return m_orientation;
    }

    /**
     * Returns the yaw component of the current sensor orientation
     * \return FloatingType containing the yaw component of the current sensor orientation
     */
    FloatingType Yaw()   const {
        return m_orientation.yaw;
    }

    /**
     * Returns the pitch component of the current sensor orientation
     * \return FloatingType containing the pitch component of the current sensor orientation
     */
    FloatingType Pitch() const {
        return m_orientation.pitch;
    }

    /**
     * Returns the roll component of the current sensor orientation
     * \return FloatingType containing the roll component of the current sensor orientation
     */
    FloatingType Roll()  const {
        return m_orientation.roll;
    }

    /**
     * Sets a new sensor orientation and signals the change to all the subscribers
     * \param [in] new_orientation OrientationType containing the new sensor orientation
     */
    void SetOrientation(const OrientationType& new_orientation)
    {
        m_orientation=new_orientation;
        m_orientation_signal(m_orientation);
    }

    /**
     * Sets a new sensor orientation and signals the change to all the subscribers
     * \param [in] Yaw Yaw component of the new sensor orientation
     * \param [in] Pitch Pitch component of the new sensor orientation
     * \param [in] Roll Roll component of the new sensor orientation
     */
    template <class T>
    void SetOrientation(T Yaw, T Pitch, T Roll)
    {
        m_orientation=OrientationType(static_cast<FloatingType>(Yaw),
        		static_cast<FloatingType>(Pitch),
        		static_cast<FloatingType>(Roll));
        m_orientation_signal(m_orientation);
    }


    /**
     * Sets a new sensor orientation and signals the change to all the subscribers
     * \param [in] str string containing the new sensor orientation in the format "yaw, pitch, roll"
     */
    void SetOrientation(const std::string& str)
    {
        m_orientation=OrientationType(str);
        m_orientation_signal(m_orientation);
    }


    /**
    * Register a callback for receiving a notification whenever the sensor position changes
    * The callback are removed when a new session is opened
    * \param slot pointing to the callback
    * \return boost::signals::connection for enabling and disabling the signalling
    *
    * Example:
    * \code
    * // for free functions
    * m_sensor.Do_On_Orientation_Change( myfunct );
    *
    * // for methods
    * m_sensor.Do_On_Orientation_Change( boost::bind(&MyObjectType::On_Change_Orientation, *this, _1));
    *
    * \endcode
    * \return the connection to the slot. Can be used to temporarily disable the slot
    */
    ConnectionType Do_On_Orientation_Change(const OrientationSignalType::slot_type& slot)
    {
        return m_orientation_signal.connect(slot);
    }


protected:

    /**
     * This method provides the initialization code
     * Derived classes shall call it in order to maintain the object integrity
     */
    void On_Initialization();

    /**
     * This method provides the destruction code
     * Derived classes shall call it in order to maintain the object integrity
     */
    void On_ShutDown();

    /**
     * This method provides the code for loading sensor parameters
     * Derived classes shall call when necessary
     */
    void LoadParams(const INIFile& ini, hws::Version version);

    /**
     * This method provides the code for saving sensor parameters
     * Derived classes shall call when necessary
     */
    void SaveParams(INIFile& ini);


    /**
     * Method for connecting to the sensor and external Sampler
     * The sampler will be made available to the users for getting statistics
     * on the captured data, accessing timestamps and counters
     */
    void ConnectSampler(dev::CSampler& sampler);

    /**
     * This is the sensor panel
     * Derived classes are free to use it for embedding the sensor controls
     * in their own panels or for pushing implementation-specific controls.
     */
    ui::wgt::Widget panel;

private:
    PositionType m_position;     ///< The current sensor position
    PositionSignalType m_position_signal;   ///< Signal for the sensor position

    OrientationType m_orientation; ///< The current sensor orientation
    OrientationSignalType m_orientation_signal;  ///< Signal for the sensor orientation

    hws::Version m_hws_version;  ///< version of the sensor parameters
    dev::CSampler* m_psampler;   ///< pimpl for the sampler instance
};

/**\}*/

} // namespace dev

#endif
