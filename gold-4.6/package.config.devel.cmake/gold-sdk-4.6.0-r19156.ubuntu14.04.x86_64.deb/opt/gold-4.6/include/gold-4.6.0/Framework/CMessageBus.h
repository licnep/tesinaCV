/**
 * @file Framework/CMessageBus.h
 * \brief Bus for exchanging messages between different modules (deprecated)
 * \author Paolo Grisleri (grisleri@vislab.it)
 */
#ifndef _CMESSAGEBUS_H
#define _CMESSAGEBUS_H

#include <string>
#include <vector>
#include <map>

#include <Framework/CMessageQueue.h>

#include <Framework/gold_msg_bus_export.h>

/**
 * \brief Message bus (deprecated)
 * \deprecated All the functions and objects inside this namespace are now deprecated in favor of the new VLBus
 */
namespace msgbus
{

/** Goals:
  * Communication:
  * - Point-to-point communication
  * - Broadcast communication
  * - Actions on communication between two nodes
  *
  * Communication betweem classes:
  * - in the same process (same and different threads)
  * - in different processes on the same machine
  * - in different processes on diferent machines
  *
  * Data independency
  * Efficiency
  * NOTE: dynamic registration of supported messages
  */

  /*
  * registrare i messaggi dinamicamente, in modo da poter fare il lookup in un dizionario.
  * permette di non avere un dizionario centralizzato e maggiore scalabilità: API diverse
  * possono definire il proprio set di messaggi indipendenti dagli altri e comunicare solo
  * tramite quelli
  * \code
  *  //
  *  struct CMsgDescriptor
  *  {
  *    std::string name;
  *    std::string description;
  *    unsigned int id;
  *    // serializer
  *  };
  *
  *  void RegisterMessage();  // nel CMessageBus
  *
  *  C'è modo di farla staticamente senza usare rtti?
  *  La dimensione dei messaggi è nota a tempo di compilazione
  *  Tuttavia più processi sulla stessa macchina o su macchine diverse possono essere aggiunti
  *  solo a tempo di esecuzione
  *
  * \endcode
  *
  * TODO: registrazione dinamica dei messaggi
  */


/**
 * \brief Class representing an endpoint
 * An endpoint is a structure modeling an access point to one of the messagebus lines
 * Multiple endpoints can be connected to the same lane for sending or receiving messages
 */
struct CEndPoint
{
    typedef uint32_t  IDType;
    typedef uint64_t KeyType;

    IDType  id;
    KeyType key;
};




/**
 * \brief Singleton class for modeling a bus of messages
 * This class is intended to be used by the engine and by users
 * A message bus contains multiple endpoints
 */
class GOLD_MSG_BUS_EXPORT CMessageBus
{
public:

	/**
	 * \brief Returns the one and only instance of the class
	 * \see Sigleton
	 */
    static CMessageBus& Instance();

    /** Destructor */
    ~CMessageBus();

    /**
     * \brief Creates new EndPoint associated with a path
     * \param path string for identifying the endpoint
     * \return the created endpoint
     */
    CEndPoint CreateEndPoint(const std::string& path);

    /**
     * \brief Destroys an existing endpoint
     * \param key the endpoint to be destroyed
     */
    void DestroyEndPoint(CEndPoint::KeyType key);

    /**
     * \brief Returns the node identifier of the endpoint associated to a path
     */
    CEndPoint::IDType GetNodeID(const std::string& path);

    /**
     * \brief Starts the message dispatching for a requested endpoint
     */
    void Dispatch_Start(CEndPoint::KeyType key);

    /**
     * \brief Stop the message dispatching for a requested endpoint
     */
    void Dispatch_Stop(CEndPoint::KeyType key);

    /**
     * \brief Send a message to a specific endpoint
     * \param id identifier for the destination endpoint
     * \param msg Message to be sent
     */
    void Send(CEndPoint::IDType id, const module::CMessage& msg);

    /**
     * \brief Receive a message from a specific endpoint
     * \param id identifier for the source endpoint
     * \param msg Message to be received
     */
    void Recv(CEndPoint::IDType id, module::CMessage& msg);

    // TODO: broadcast send, to all endpoint
    // void Send(const module::CMessage& msg);

    // TODO: Synchronous version for Receive
    // void Recv(const module::CMessage& msg, CEndPoint::IDType& id);

    /**
     * \brief Subscribe the reception notification for a message sent from a specific endpoint
     */
    void Subscribe_Message(CEndPoint::IDType id, module::MessageID msg_id, const CMessageQueue::SignalType::slot_type& slot);

    /**
     * \brief Subscribe the reception notification for all the messages messages sent from a specific endpoint
     */
    void Subscribe_Messages(CEndPoint::IDType id, const CMessageQueue::SignalType::slot_type& slot);

private:
    const std::string& lookup_path(CEndPoint::IDType id) const;

    // TODO: bimap|multi-index

    typedef std::map<CEndPoint::KeyType, CEndPoint::IDType> KeysMap;
    KeysMap m_keys;

    typedef std::map<std::string, CEndPoint::IDType> PathIDType;
    PathIDType m_paths_id_table;

    std::vector<CMessageQueue*> m_local_nodes;
};

}

#endif // _CMESSAGEBUS_H
