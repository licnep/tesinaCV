
#ifndef GOLD_FRAMEWORK_EXPORT_H
#define GOLD_FRAMEWORK_EXPORT_H

#ifdef GOLD_FRAMEWORK_STATIC_DEFINE
#  define GOLD_FRAMEWORK_EXPORT
#  define GOLD_FRAMEWORK_NO_EXPORT
#else
#  ifndef GOLD_FRAMEWORK_EXPORT
#    ifdef gold_framework_EXPORTS
        /* We are building this library */
#      define GOLD_FRAMEWORK_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define GOLD_FRAMEWORK_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef GOLD_FRAMEWORK_NO_EXPORT
#    define GOLD_FRAMEWORK_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef GOLD_FRAMEWORK_DEPRECATED
#  define GOLD_FRAMEWORK_DEPRECATED __attribute__ ((__deprecated__))
#  define GOLD_FRAMEWORK_DEPRECATED_EXPORT GOLD_FRAMEWORK_EXPORT __attribute__ ((__deprecated__))
#  define GOLD_FRAMEWORK_DEPRECATED_NO_EXPORT GOLD_FRAMEWORK_NO_EXPORT __attribute__ ((__deprecated__))
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define GOLD_FRAMEWORK_NO_DEPRECATED
#endif

#endif
