/**
 * @file DataRateGuard.h
 * @author Paolo Grisleri
 * @brief Timing Checker for Sensors Data Rate
 */

 #ifndef DATARATE_GUARD_H
 #define DATARATE_GUARD_H

 #include <Devices/Base/CSensor.h>

 #include <boost/thread/pthread/mutex.hpp>
 #include <boost/thread/condition.hpp>
 #include <boost/function.hpp>
 #include <boost/thread/detail/thread.hpp>
 #include <Framework/gold_framework_export.h>

namespace dev
{


 /**
  * \class DataRateGuard
  * \brief Timing Checker for Sensors Data Rate
  *
  * This class is used to control if the period of a sensor is included between
  * the requested limit or not. User shall register the requested parameters with the
  * Connect method and the class will invoke a callback when the data arrives from the sensor
  * too early or too late.
  *
  * \code
  * void test_cb(TimeType t) { std::cout << "synchronization failed " << t << std::endl; }
  *
  *  // In an initialization function, m_drg and m_camera are two member variables
  *  m_drg.Connect(m_camera,
  *  			   boost::posix_time::milliseconds(10),
  *  			   boost::posix_time::milliseconds(1),
  *  			   test_cb);
  *
  * \endcode
  *
  */
 class GOLD_FRAMEWORK_EXPORT DataRateGuard
 {
 public:
	 /** \brief Constructor */
     DataRateGuard():
    	 	 m_sensor(0),
             m_period_guard(0L),
             m_period_guard_th(0L),
    	 	 m_timestamp(0L),
    	 	m_delta_timestamp(0L),
             m_is_delta_valid(false)
     {
     }

     /** \brief Destructor */
     ~DataRateGuard()
     {
         if (m_watch_dog.joinable())
         {
             m_watch_dog.interrupt();
             m_watch_dog.join();
         }
     }

     /** Type for the user callback */
     typedef boost::function<void (TimeType)> CallBackType;

     /**
      * \brief Connects a sensor, whenever the data arrives outside the selected threshold
      * the callback is invoked.
      *
      * \tparams T  type of the sensor
      * \params  sensor reference to the sensor to be monitored
      * \params  period expected period of the sensor
      * \params  th treshold accepted for the data arrival
      * \params  cb callback to be invoked if the data arrives too early or too late
      *
      */
     template<typename T>
     void Connect(T& sensor, const TimeType& period, const TimeType& th_us, CallBackType cb)
     {
         m_sensor = &sensor;

         m_period_guard = period.total_microseconds();
         m_period_guard_th = th_us.total_microseconds();
         m_period_guard_cb = cb;
         m_watch_dog = boost::thread(boost::bind(&DataRateGuard::thread, this));
         sensor.Do_On_Frame_AsyncReceived(boost::bind(&DataRateGuard::NotifyFrame<T>, this, _1));
     }

 private:

     template <typename T>
     void NotifyFrame(const typename T::FrameType& frame)
     {
         {
             boost::mutex::scoped_lock lock(m_mtx);
             // TODO: reset oppure start/stop per azzerare i delta
             m_delta_timestamp = m_sensor->Sampler().LastDelta().total_microseconds();
             m_timestamp = m_sensor->Sampler().TimeStamp().total_microseconds();
             m_is_delta_valid = m_sensor->Sampler().IsLastDeltaValid();
         }
         m_cnd.notify_all();
     }

     void thread()
     {
         try
         {
             while (1)
             {
                 boost::mutex::scoped_lock lock(m_mtx);

                 bool ret_val = m_cnd.timed_wait(lock, boost::posix_time::microseconds(m_period_guard+m_period_guard_th));
                 if (m_is_delta_valid)
                     if (!(std::abs(m_delta_timestamp-m_period_guard)<m_period_guard_th))
                         m_period_guard_cb(boost::posix_time::microseconds(m_delta_timestamp));

                 // std::cout << "received "  << ret_val << " " << m_delta_timestamp << " " <<  m_period_guard << " " << m_period_guard_th << std::endl;
             }
         }
         catch (...)
         {
         }
     }

     const dev::CSensor* m_sensor;
     bool m_is_delta_valid;
     long              m_period_guard;
     long              m_period_guard_th;
     long              m_timestamp;
     long              m_delta_timestamp;
     boost::function<void(TimeType )> m_period_guard_cb;
     boost::thread     m_watch_dog;
     boost::mutex      m_mtx;
     boost::condition  m_cnd;


 };

}// namespace dev

 #endif
