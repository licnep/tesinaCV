/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2011                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * \file Synchronizers.h
 * \brief Classes for presenting synchronized data to the applications
 * \author Paolo Grisleri (grisleri@vislab.it), Paolo Zani (zani@vislab.it)
 * \date 2011-04-01
 */

#ifndef SYNCHRONIZERS_H
#define SYNCHRONIZERS_H

#include <Libs/Threads/CSuspendable.hxx> // semaphore
#include <Libs/Time/TimeUtils.h>
#include <boost/any.hpp>
#include <boost/bind.hpp>
#include <boost/function.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/thread/condition.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/algorithm/minmax_element.hpp>

#include <Framework/gold_framework_export.h>
#include <Libs/Compatibility/DeclSpecs.h>
#include <Libs/Debug/Demangling.h>

#include <map>
#include <utility>
#include <vector>

namespace dev 
{
class CDevice;
}
// namespace dev


namespace usr
{
  class Transport;
  class CApplication;


/**
 * \class Synchronizer_Basic
 * \brief Basic class for presenting synchronized data to the applications
 *
 * Applications that needs to work on synchronized data shall encapsulate
 * an instance of this class and connect it to the devices.
 * Whenever a data arrives to the synchronizer it is collected and stored until the frame
 * is complete. A frame is the set of data connected through the ConnectSync method.
 *
 * Other methods are available for connecting data needed with different policies such as
 * Last o Buffer.
 *
 * The mutex shall be locked during the capture part of the processing
 * When the method WaitData is called in a thread, the thread is suspended until
 * all the data connected through the ConnectSync have been refreshed once by the device.
 * At the same time the mutex is opened.
 *
 * A threshold can be defined by users for determining when two data are out of sync.
 *
 * When the frame is completed the WaitData exits and the processing can continue.
 * A typical usage is like this
 * \code
 *
 * void On_Initialization()
 * {
 *    m_pCam_l = (Dev()["CAMERAS/A"]);
 *    m_pCam_r = (Dev()["CAMERAS/B"]);
 *    m_synchro.ConnectLast(*m_pCam_l);
 *    m_synchro.ConnectLast(*m_pCam_r);
 * }
 * \endcode
 *
 * \code
 *
 * void On_Execute()
 * {
 *     const dev::CCamera::FrameType& frame_l = m_synchro.LastFrameFrom<dev::CCamera>(*m_pCam_l);
 *     const dev::CCamera::FrameType& frame_r = m_synchro.LastFrameFrom<dev::CCamera>(*m_pCam_r);
 *
 *     // data processing
 *     // ...
 * }
 *
 * \endcode
 *
 */
class GOLD_FRAMEWORK_EXPORT Synchronizer_Basic
{
public:

    /**
     * \brief Constructor.
     */
    Synchronizer_Basic();

    /**
     * \brief Destructor.
     */
    ~Synchronizer_Basic();
    
    /**
     * \brief Connects a device to the synchronized set. Custom function
     *
     * The Wait method, called by the system is released when all devices connected
     * to the syncronized set have provided one frame within SyncThreshold from the first.
     * @param device a device to be connected to the synchronized set
     * @param connect_func the function to call to subscribe to the device
     * @see Synchronizer_Basic::SyncFrameFrom for accessing the frame content.
     */
    template <typename T, typename R, typename F, typename L>
    void ConnectSync(T& device, boost::_bi::bind_t<R, F, L> connect_func)
    {
        _ConnectSync<T>(device, connect_func);
    }

    /**
     * \brief Connects a device to the synchronized set. Pointer to member function
     *
     * The Wait method, called by the system is released when all devices connected
     * to the syncronized set have provided one frame within SyncThreshold from the first.
     * @param device a device to be connected to the synchronized set
     * @param connect_func the function to call to subscribe to the device
     * @see Synchronizer_Basic::SyncFrameFrom for accessing the frame content.
     */
    template <typename T>
    void ConnectSync(T& device,
                     void (T::*connect_func)(boost::function<void(const typename T::FrameType&)>) = &T::Do_On_Frame_AsyncReceived)
    {
        _ConnectSync<T>(device, connect_func);
    }

    /**
     * \brief Connects a device to the synchronized set. Pointer to member function with argument
     *
     * The Wait method, called by the system is released when all devices connected
     * to the syncronized set have provided one frame within SyncThreshold from the first.
     * @param device a device to be connected to the synchronized set
     * @param connect_func the function to call to subscribe to the device
     * @see Synchronizer_Basic::SyncFrameFrom for accessing the frame content.
     */
    template <typename T, typename R>
    void ConnectSync(T& device, const R& arg,
                     void (T::*connect_func)(R, boost::function<void(const typename T::FrameType&)>) = &T::Do_On_Frame_AsyncReceived)
    {
        _ConnectSync<T>(device, bind(connect_func, _1, arg, _2 ));
    }

    /**
     * \brief Connects to a device, keeping the last frame.
     *
     * This is typically used for lasers, radar and other devices not synchronized with cameras.
     * The application is notified each time a frame is received, but only if
     * Synchronizer_Basic::ConnectSync is not used in conjunction with
     * Synchronizer_Basic::ConnectLast, in which case the application is
     * notified only when the synchronization condition is satisfied.
     * @note The frame can be retrieved via a call to Synchronizer_Basic::LastFrameFrom.
     * @param device a device to connect to
     * @param connect_func the function to call to subscribe to the device
     */
    template <typename T, typename R, typename F, typename L>
    void ConnectLast(T& device, boost::_bi::bind_t<R, F, L> connect_func)
    {
        _ConnectLast<T>(device, connect_func);
    }

    /**
     * \brief Connects to a device, keeping the last frame.
     *
     * This is typically used for lasers, radar and other devices not synchronized with cameras.
     * The application is notified each time a frame is received, but only if
     * Synchronizer_Basic::ConnectSync is not used in conjunction with
     * Synchronizer_Basic::ConnectLast, in which case the application is
     * notified only when the synchronization condition is satisfied.
     * @note The frame can be retrieved via a call to Synchronizer_Basic::LastFrameFrom.
     * @param device a device to connect to
     * @param connect_func the function to call to subscribe to the device
     */
    template <typename T>
    void ConnectLast(T& device,
                     void (T::*connect_func)(boost::function<void(const typename T::FrameType&)>) = &T::Do_On_Frame_AsyncReceived)
    {
        _ConnectLast<T>(device, connect_func);
    }

    /**
     * \brief Connects to a device, keeping the last frame.
     *
     * This is typically used for lasers, radar and other devices not synchronized with cameras.
     * The application is notified each time a frame is received, but only if
     * Synchronizer_Basic::ConnectSync is not used in conjunction with
     * Synchronizer_Basic::ConnectLast, in which case the application is
     * notified only when the synchronization condition is satisfied.
     * @note The frame can be retrieved via a call to Synchronizer_Basic::LastFrameFrom.
     * @param device a device to connect to
     * @param connect_func the function to call to subscribe to the device
     */
    template <typename T, typename R>
    void ConnectLast(T& device, const R& arg,
                     void (T::*connect_func)(R, boost::function<void(const typename T::FrameType&)>) = &T::Do_On_Frame_AsyncReceived)
    {
        _ConnectLast<T>(device, bind(connect_func, _1, arg, _2 ));
    }

    /**
     * \brief Connects to a device, buffering the frames.
     *
     * This is typically used for can bus
     * The application appends each frame to a container of the specified type.
     * @note When the application is notified, the container can be retrieved
     * via a call to Synchronizer_Basic::BufferedFrameFrom.
     * @param device a device to connect to
     * @param connect_func the function to call to subscribe to the device
     * @param arg argument of the connect_func function
     */
    template <template<typename, typename> class C, typename R, typename F, typename L, typename D>
    void ConnectBuffered(D& device, boost::_bi::bind_t<R, F, L> connect_func)
    {
        _ConnectBuffered<D, C>(device, connect_func);
    }

    /**
     * \brief Connects to a device, buffering the frames.
     *
     * This is typically used for can bus
     * The application appends each frame to a container of the specified type.
     * @note When the application is notified, the container can be retrieved
     * via a call to Synchronizer_Basic::BufferedFrameFrom.
     * @param device a device to connect to
     * @param connect_func the function to call to subscribe to the device
     * @param arg argument of the connect_func function
     */
    template < template<typename, typename> class C, typename R, typename D>
    void ConnectBuffered(D& device, const R& arg,
                         void (D::*connect_func)(R, boost::function<void(const typename D::FrameType&)>) = &D::Do_On_Frame_AsyncReceived)
    {
        _ConnectBuffered<D, C>(device, bind(connect_func, _1, arg, _2 ));
    }

    /**
     * \brief Connects to a device, buffering the frames.
     *
     * This is typically used for can bus
     * The application appends each frame to a container of the specified type.
     * @note When the application is notified, the container can be retrieved
     * via a call to Synchronizer_Basic::BufferedFrameFrom.
     * @param device a device to connect to
     * @param connect_func the function to call to subscribe to the device
     * @param arg argument of the connect_func function
     */
    template < template <typename, typename> class C, typename D>
    void ConnectBuffered(D& device,
                         void (D::*connect_func)(boost::function<void(const typename D::FrameType&)>) = &D::Do_On_Frame_AsyncReceived)
    {
        _ConnectBuffered<D, C>(device, connect_func);
    }
    

    /**
     * \brief Returns the mutex used by the application when waiting for new frames.
     * @return boost::mutex& the mutex to lock on
     */
    boost::mutex& Mutex() {
        return m_mutex;
    }

    /**
     * \brief Sets the maximum tolerance between two frames timestamps to consider them synchronized.
     * @param threshold the synchronization tolerance
     */
    void SetSyncThreshold(vl::chrono::TimeType threshold) {
        m_threshold = threshold.total_microseconds();
    }

    /**
     * \brief Returns the maximum tolerance between two synchronized frames timestamps.
     * @return long the synchronization tolerance
     */
    vl::chrono::TimeType GetSyncThreshold() const {
        return boost::posix_time::microseconds(m_threshold);
    }

    /**
     * \brief Returns a frame from the synchronization group
     * @param device the device to get the frame from
     * @return the frame
     */
    template<typename T>
    const typename T::FrameType& SyncFrameFrom(const T& device) const
    {
        std::map<const dev::CDevice*, unsigned int>::const_iterator dd = m_devices.find(static_cast<const dev::CDevice*>(&device));
#ifndef NDEBUG
        if(dd == m_devices.end())
            throw(std::runtime_error("Device " + device.Name() + " not connected to Synchronizer_Basic"));

        if(m_sync_frames.empty())
            throw(std::runtime_error("Synchronous frame requested to " + device.Name() +
                                     "\nbut no frames are currently available.\nCheck the existance of the corresponding ConnectSync."));
#endif // NDEBUG

        // return frame.empty() ? typename T::FrameType() : boost::any_cast<const typename T::FrameType&>(frame);
            
        /**
         * NOTE if you are looking for a bug and you get here with a debugger
         * check if m_usr_sync_frames contains null values
         * you should probably change schedule.ini and use COMPAT_4_5=false
         */
        const boost::any& frame = m_usr_sync_frames[dd->second];
        return boost::any_cast<const typename T::FrameType&>(frame);  
    }

    /**
     * \brief Returns a frame from the last frames group
     * @param device the device to get the frame from
     * @return the frame
     */
    template<typename T>
    const typename T::FrameType& LastFrameFrom(const T& device) const
    {
        std::map<const dev::CDevice*, unsigned int>::const_iterator dd = m_devices.find(static_cast<const dev::CDevice*>(&device));

#ifndef NDEBUG
        if(dd == m_devices.end())
            throw(std::runtime_error("Device " + device.Name() + " not connected to Synchronizer_Basic"));

        if(m_last_frames.empty())
            throw(std::runtime_error("Synchronous frame requested to " + device.Name() +
                                     "\nbut no frames are currently available.\nCheck the existance of the corresponding ConnectSync."));
#endif // NDEBUG

        // return frame.empty() ? typename T::FrameType() : boost::any_cast<const typename T::FrameType&>(frame);
        const boost::any& frame = m_usr_last_frames[dd->second];
        return boost::any_cast<const typename T::FrameType&>(frame);
    }

    /**
     * \brief Returns a container from the buffered frames group
     * @param device the device to get the frame from
     * @return the container holding the buffered frames
     */
    template< template<typename, typename> class C, typename T>
    C<typename T::FrameType, typename std::allocator<typename T::FrameType> >& BufferedFrameFrom(const T& device)
    {
        std::map<const dev::CDevice*, unsigned int>::const_iterator dd = m_devices.find(static_cast<const dev::CDevice*>(&device));
	
#ifndef NDEBUG
        if (dd == m_devices.end())
            throw(std::runtime_error("Device " + device.Name() + " not connected to Synchronizer_Basic"));
	
        if(m_buff_frames.empty())
            throw(std::runtime_error("Synchronous frame requested to " + device.Name() +
                                     "\nbut no frames are currently available.\nCheck the existance of the corresponding ConnectSync."));
#endif // NDEBUG

        typedef C<typename T::FrameType, typename std::allocator<typename T::FrameType> > ContainerType;
        return *boost::any_cast<boost::shared_ptr<ContainerType> >(m_usr_buff_frames[dd->second]);
    }

    /**
     * \brief Waits for one complete frame of the Sync set
     * NOTE: Do not call this method from the application. Is used by the scheduler
     */
    void WaitData();
    
    /**
     * \brief Notifies the framework that the application On_Execute method is over
     * NOTE: Do not call this method from the application. Is used by the scheduler
     */
    void EndOfProcessing_();

    /**
     * \brief To be called with the mutex locked
     * \return true when the frame is completed
     * NOTE: Do not call this method from the application. Is used by the scheduler
     */
    bool FrameCompleted_();

    /**
     * \brief To be called when looping on frame
     * NOTE: Do not call this method from the application. Is used by the scheduler
     */
    void LoopOnFrame_();   
    
    
    ///////////////////////////////////////////////////////////////////////////
    // DEPRECATED METHODS
    ///////////////////////////////////////////////////////////////////////////
    /**
     * \brief Returns a frame from the synchronization group
     * @param n the position in the synchronization group
     */
    template<typename T>
    DECLSPEC_DEPRECATED const typename T::FrameType SyncFrameFrom(unsigned int n) {
        return boost::any_cast<typename T::FrameType&>(m_sync_frames[n]);
    }

    /**
     * \brief Returns a frame from the last frames group
     * @param n the position in the last frames group
     */
    template<typename T>
    DECLSPEC_DEPRECATED const typename T::FrameType LastFrameFrom(unsigned int n) {
        return boost::any_cast<typename T::FrameType&>(m_last_frames[n]);
    }

    /**
     * \brief Returns a container from the buffered frames group
     * @param n the position in the buffered frames group
     * @return the container holding the buffered frames
     */
    template<typename C>
    DECLSPEC_DEPRECATED C& BufferedFrameFrom(unsigned int n) {
        return *boost::any_cast<boost::shared_ptr<C> >(m_buff_frames[n]);
    }
    
    /**
     * \brief Suspends the calling thread until the synchronization condition is satisfied.
     * @return boost::mutex::scoped_lock& the lock to suspend the thread on
     */
    DECLSPEC_DEPRECATED void Wait(boost::mutex::scoped_lock& lock);
    
    /**
     * \brief Sets the CApplication used by the Synchronizer_Basic.
     * @param application the CApplication to connect to
     */
    DECLSPEC_DEPRECATED void SetApplication(const CApplication& _app);

    /**
     * \brief Sets the Transport used by Synchronizer_Basic.
     * @param transport the Transport to connect to
     */
    DECLSPEC_DEPRECATED void SetTransport(usr::Transport& _tr);
    
    /**
     * \brief Notifies the framework that the application On_Execute method is over
     */
    DECLSPEC_DEPRECATED void EndOfProcessing();

    /**
     * \brief To be called with the mutex locked
     * \return true when the frame is completed
     */
    DECLSPEC_DEPRECATED bool FrameCompleted();

    /**
     * \brief To be called when looping on frame
     */
    DECLSPEC_DEPRECATED void LoopOnFrame();   
    ///////////////////////////////////////////////////////////////////////////
    // DEPRECATED METHODS
    ///////////////////////////////////////////////////////////////////////////    

private:

    const usr::CApplication* m_app;  // DEPRECATED TO BE REMOVED
    usr::Transport*          m_tr;   // DEPRECATED TO BE REMOVED
    long                m_threshold;
    
    boost::function<bool()> is_app_enabled;

    boost::mutex m_mutex;      // mutex for data notification to the App
    boost::condition m_cond;   // condition variable for data notification to the App
    vl::thread::Semaphore m_eop_sem;       // semaphore for end of processing notificatio to the Transport
    bool m_execute;            // local variable to check the if current frame is completed
    bool m_is_frame_completed; // true when the current frame is completed

    std::map<const dev::CDevice*, unsigned int> m_devices;
    std::vector<long>                     m_timestamps;
    std::vector<boost::any>               m_sync_frames;
    std::vector<boost::any>               m_last_frames;
    std::vector<boost::any>               m_buff_frames;
    
    std::vector<boost::any>               m_usr_sync_frames;
    std::vector<boost::any>               m_usr_last_frames;
    std::vector<boost::any>               m_usr_buff_frames;
    
    unsigned int m_check;
    
    void PublishData();

    template<typename T>
    unsigned int _ConnectSync(T& device, boost::function<void(T*,  boost::function<void(const typename T::FrameType&)>)>  connect_func = &T::Do_On_Frame_AsyncReceived)
    {
#ifndef NDEBUG            
        if(m_devices.find(static_cast<const dev::CDevice*>(&device)) != m_devices.end())
            throw(std::runtime_error("Device " + device.Name() + " already connected to Synchronizer_Basic"));
 # endif 
        
        m_sync_frames.push_back(boost::any());
        m_timestamps.push_back(0uL);
        m_devices[static_cast<const dev::CDevice*>(&device)] = m_sync_frames.size() - 1;
        connect_func(&device, boost::bind(&Synchronizer_Basic::NotifySync<T>, this, m_sync_frames.size() - 1, _1));
        return m_sync_frames.size() - 1;
    }


    template<typename T>
    unsigned int _ConnectLast(T& device, boost::function<void(T*,  boost::function<void(const typename T::FrameType&)>)> connect_func = &T::Do_On_Frame_AsyncReceived)
    {
#ifndef NDEBUG            
        if(m_devices.find(static_cast<const dev::CDevice*>(&device)) != m_devices.end())
          throw(std::runtime_error("Device " + device.Name() + " already connected to Synchronizer_Basic"));
 # endif 
            
        m_last_frames.push_back(boost::any());
        m_devices[static_cast<const dev::CDevice*>(&device)] = m_last_frames.size() - 1;
        connect_func(&device, boost::bind(&Synchronizer_Basic::NotifyLast<T>, this, m_last_frames.size() - 1, _1));
        return m_last_frames.size() - 1;
    }

    template<typename D, template<typename, typename> class C>
    unsigned int _ConnectBuffered(D& device,  boost::function<void(D*,  boost::function<void(const typename D::FrameType&)>)> connect_func = &D::Do_On_Frame_AsyncReceived)
    {
#ifndef NDEBUG            
        if(m_devices.find(static_cast<const dev::CDevice*>(&device)) != m_devices.end())
          throw(std::runtime_error("Device " + device.Name() + " already connected to Synchronizer_Basic"));
 # endif 

        typedef C<typename D::FrameType, typename std::allocator<typename D::FrameType> > ContainerType;

        m_buff_frames.push_back(boost::shared_ptr<ContainerType>(new ContainerType()));
        m_devices[static_cast<const dev::CDevice*>(&device)] = m_buff_frames.size() - 1;
        connect_func(&device, boost::bind(&Synchronizer_Basic::NotifyBuffered<D, ContainerType>, this, m_buff_frames.size() - 1, _1));
        return m_buff_frames.size() - 1;
    }
    
    template <typename T>
    void NotifySync(unsigned int n, const typename T::FrameType& frame)
    {
        if (is_app_enabled && !is_app_enabled())
            return;

        boost::mutex::scoped_lock lock(m_mutex);

        // std::cout << "[II] " << " NotifySync()  device = " << n << "  timestamp = "<< frame.TimeStamp.total_microseconds()<<std::endl;

        if (m_sync_frames[n].empty())
            ++m_check;

        m_sync_frames[n] = frame;
        m_timestamps[n] = frame.TimeStamp.total_microseconds();

        if (m_check==m_sync_frames.size())
        {
            typedef std::pair<std::vector<long>::iterator, std::vector<long>::iterator> retval_type;
            retval_type retval = boost::minmax_element(m_timestamps.begin(), m_timestamps.end());

            m_execute = ((*(retval.second) - *(retval.first)) <  m_threshold );

            // std::cout << "[II] " <<"NotifySync() TimeStamp difference = " <<  *(retval.second) - *(retval.first) << ", Threshold = "<< m_threshold << std::endl;

            if (m_execute)
            {
                m_is_frame_completed = true;
                
                // std::cout << "[II] " <<"NotifySync() Notify application"<<std::endl;
                m_cond.notify_all();
            }
        }
    }

    template<typename T>
    void NotifyLast(unsigned int n, const typename T::FrameType& frame)
    {
        if (is_app_enabled && !is_app_enabled())
          return;

        boost::mutex::scoped_lock lock(m_mutex);

        // std::cout << "[II] " <<"NotifyLast()  device = " << n << "  timestamp = "<< frame.TimeStamp.total_microseconds()<<std::endl;

        m_last_frames[n] = frame;
        
        m_execute = m_sync_frames.empty();

        if (m_execute)
        {
            m_is_frame_completed = true;
            
            // std::cout << "[II] " <<"NotifySync() Notify application"<<std::endl;
            m_cond.notify_all();
        }        
    }

    template<typename T, typename C>
    void NotifyBuffered(unsigned int n, const typename T::FrameType& frame)
    {
        if (is_app_enabled && !is_app_enabled())            
          return;

        // std::cout << "[II] " <<"NotifyBuffered()  device = " << n << "  timestamp = "<< frame.TimeStamp.total_microseconds()<<std::endl;

        boost::mutex::scoped_lock lock(m_mutex);
        boost::shared_ptr<C> buffer = boost::any_cast<boost::shared_ptr<C> >(m_buff_frames[n]);
        buffer->insert(buffer->end(), frame);
    }
};

} // namespace usr

#endif
