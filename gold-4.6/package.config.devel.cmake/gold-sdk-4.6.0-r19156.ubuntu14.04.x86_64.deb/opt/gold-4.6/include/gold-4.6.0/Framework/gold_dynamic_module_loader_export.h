
#ifndef GOLD_DYNAMIC_MODULE_LOADER_EXPORT_H
#define GOLD_DYNAMIC_MODULE_LOADER_EXPORT_H

#ifdef GOLD_DYNAMIC_MODULE_LOADER_STATIC_DEFINE
#  define GOLD_DYNAMIC_MODULE_LOADER_EXPORT
#  define GOLD_DYNAMIC_MODULE_LOADER_NO_EXPORT
#else
#  ifndef GOLD_DYNAMIC_MODULE_LOADER_EXPORT
#    ifdef gold_dynamic_module_loader_EXPORTS
        /* We are building this library */
#      define GOLD_DYNAMIC_MODULE_LOADER_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define GOLD_DYNAMIC_MODULE_LOADER_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef GOLD_DYNAMIC_MODULE_LOADER_NO_EXPORT
#    define GOLD_DYNAMIC_MODULE_LOADER_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef GOLD_DYNAMIC_MODULE_LOADER_DEPRECATED
#  define GOLD_DYNAMIC_MODULE_LOADER_DEPRECATED __attribute__ ((__deprecated__))
#  define GOLD_DYNAMIC_MODULE_LOADER_DEPRECATED_EXPORT GOLD_DYNAMIC_MODULE_LOADER_EXPORT __attribute__ ((__deprecated__))
#  define GOLD_DYNAMIC_MODULE_LOADER_DEPRECATED_NO_EXPORT GOLD_DYNAMIC_MODULE_LOADER_NO_EXPORT __attribute__ ((__deprecated__))
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define GOLD_DYNAMIC_MODULE_LOADER_NO_DEPRECATED
#endif

#endif
