/**
 * \file CDynamicModulesLoader.h
 * \brief Class for managing the dynamic loading and unloading of libraries
 * \author Paolo Grisleri (grisleri@ce.unipr.it)
 */

#ifndef _DYNAMIC_MODULE_LOADER_H
#define _DYNAMIC_MODULE_LOADER_H

#include <map>
#include <vector>
#include <string>
#include <boost/filesystem/path.hpp>

#include <Framework/gold_dynamic_module_loader_export.h>

namespace vl
{


/**
 * \brief Class for managing the dynamic loading and unloading of libraries
 *
 * Platform independent class for managing dynamic libraries.
 * On the platforms where dynamic libraries are supported this class
 * allows to abstract from the specific technology and
 *
 */
class GOLD_DYNAMIC_MODULE_LOADER_EXPORT CDynamicModulesLoader
{
public:

	/** Local type for the path */
    typedef boost::filesystem::path PathType;
    
    /** \brief Destructor */
    ~CDynamicModulesLoader();

    /** \brief Clear all the stored paths  */
    void ClearPaths();

    /** \brief Clear the stored regular expression  */
    void ClearRegExp();

    /**
     * \brief Add a search path
     * \param path new path to be added to the internal set of search paths scanned when looking for a new plugin
     */
    void AddPath(const PathType& path);

    /**
     * \brief Add a set of paths
     * \param path vector of paths to be added to the internal set of search paths scanned when looking for a new plugin
     */
    void AddPaths(const std::vector<PathType>& paths);

    /**
     * \brief Add a regular expression to be checked when scanning a directory
     * \param the regular expression to be added to the internal set
     */
    void AddRegEx(const std::string& regex);

    /**
     * \brief Load all the required dynamic libraries
     *
     * Load all the dynamic libraries with filename verifying one of the regular expressions
     * added by the user using AddRegEx, and contained in one of the directories added by the user
     * using AddPath or AddPaths
     */
    void Load ();

    /**
     * \brief Unload all the previously loaded dynamic libraries
     *
     * Note that all the memory associated with the libraries is released
     * this may cause memory issues to all the structures pointing to that memory
     * and not properly deallocated before unloading
     */
    void UnLoad (bool verbose = false);

    /**
     * \brief Load the required dynamic libraries
     * @param path_name path were look for the libraries
     * @param sregex regular expressio for matching the libraries to be loaded
     * @param recurse_subdirs true if the search shell be performed recursively in the subdirectories
     */
    void Load ( const PathType& path_name, const std::string& sregex, bool recurse_subdirs=true );

    /** \brief Returns the number of libraries loaded */
    std::size_t Size();

private:

    std::vector<PathType> m_paths;      // set of paths to be searched when loading
    std::vector<std::string> m_regex;   // set of the regular expression to be matched when loading
    std::vector<std::string> m_plugins; // names of the plugins loaded
    std::map<PathType, void *>  m_libs; // map associating filename to the library handler
};

} // namespace vl

#endif
