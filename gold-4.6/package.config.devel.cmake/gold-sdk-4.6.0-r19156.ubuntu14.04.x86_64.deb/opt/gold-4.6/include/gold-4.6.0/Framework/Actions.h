#ifndef ACTIONS_H
#define ACTIONS_H

#include <boost/function.hpp>
#include <vector>

/**
 * \file Actions.h
 * \brief This file contains macros to manage the actions on modules
 * \author Paolo Grisleri (grisleri@ce.unipr.it)
 */

/**
 * \brief Example of use:
 * \code
 * class MyClass
 * {
 * public:
 * MyClass()
 * {
 *   ACTION_HANDLER(ON_WAKEUP, boost::bind(MyClass::MyHandler, this));
 * }
 *
 * void WakeUp()
 * {
 *  // calls all the recorded handlers
 *  for(unsigned int i=0; i<vct_ON_WAKEUP.size(); ++i)
 *    vct_ON_WAKEUP[i]();
 * }
 *
 * // ...public interface
 * private:
 * DECLARE_ACTION( ON_WAKEUP, void() );
 *
 * void MyHandler()
 * {
 * // handler for the action ON_WAKEUP
 * }
 * };
 *
 *
 * \endcode
 */


#define DECLARE_ACTION(ACTION_ID, CB_TYPE) \
  class ACTION_ID\
  {\
  public:\
  typedef boost::function<CB_TYPE> CallBackType; \
  typedef std::vector<CallBackType> SignalType;\
  };\
  ACTION_ID::SignalType vct_##ACTION_ID;


#define ACTION_HANDLER(ACTION_ID, HANDLER) \
{\
  vct_##ACTION_ID.push_back(HANDLER);\
}

#endif
