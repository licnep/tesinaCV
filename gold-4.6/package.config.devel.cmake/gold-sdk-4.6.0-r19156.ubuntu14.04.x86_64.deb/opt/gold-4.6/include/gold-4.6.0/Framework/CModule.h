/**
 * \file CModule.h
 * \brief Base class for modules called from the engine, such as applications, drivers and commanders.
 * \author Paolo Grisleri (grisleri@vislab.it)
 * \date 2007-04-12
 */

#ifndef __CMODULE
#define __CMODULE

#include <Framework/gold_framework_export.h>

#include <Libs/Threads/CTSQueue.hxx>

#include <Framework/Modes.h>
#include <Framework/CMessage.h>
#include <Framework/Actions.h>

#include <UI/Panel/Widget.h>

#include <boost/array.hpp>
#include <boost/thread/condition.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/bimap.hpp>
#include <boost/function.hpp>
#include <boost/property_tree/ptree.hpp>

#include <set>
#include <vector>

  /**
   * @defgroup Framework Framework
   * \brief Framework is an API provided to the users for writing applications.
   * @{
   * @}
   **/




namespace usr
{ 
  class CSession; 
  class CRecordingCtl;  
  class Transport;
}


/**
 * @ingroup Framework
 * CModule base class
 * @{
 **/

/**
 * @brief Base class for modules called from the engine, such as applications, drivers and commanders.
 **/

namespace usr
{

/**
 * \class CModule
 * This is the base class for every module. The class works as tree node dispatching
 * calls from the father to the children.
 * Public methods are intended to be called from the module owner and are dispatched to the
 * children depending on the propagation mask and the configured policy.
 * Children can be added and removed from the father using the public interface.
 * Children may implement protected virtual methods. Implemented code will be executed when the
 * correspondent public call will be made from the father.
 * Final derived classes are responsible of calling the implementation of the other classes.
 * Most of the public methods of this class are designed to be called only from the engine.
 * If you are implementing an application, a driver or a commander then you are interested
 * to the protected section to see what methods can be implemented.
 *
 * TODO: a way to decide how to propagate the call to the current node and to the children
 * - separate calls: EnableAll, DisableAll, to set the policy for all the children
 * - separate argument to the constructor for setting the propagation policy
 * - argument for each function
 *
 * TODO: status management for storing errors

 * TODO: FLAGS. For some operations such as Refresh and Idle
 * it is necessary to specify:
 * - FORCED: the method is executed independently on the status
 * - PROPAGATE: propagate or inhibits the call to the children
 */
class GOLD_FRAMEWORK_EXPORT CModule
{
public:
    //

	/**
	 * \brief type for the children container
	 * NOTE: typedef boost::ptr_vector<CModule> ListType;
	 * ...this version would also automatically delete the memory
	 */
    typedef std::vector<CModule *> ListType;

    /**
     * \brief Type for the event mask.
     * True means that the propagation for a certain message is enabled,
     * false means that the propagation for that message is disabled
     */
    typedef boost::array<bool, NUM_MESSAGES> EventMaskType;

    /**
     * \brief Type for the GUID
     */
    typedef unsigned int GUIDType;

    // These methods are declared in the calling order

    /**
     * \brief Execute the initialization code
     * If the module has not already been initialized, execute the initialization
     * code of the current node and then those of all children, depending on the
     * propagation mask set.
     */
    void Initialize();

    /**
     * \brief Execute the initialization code for a playback session
     * When the session mode is PLAYBACK execute the initialization
     * code of the current node and then those of all children,
     * depending on the propagation mask set.
     * A reference to the transport is passed for being used by the children
     * \param [in] tr current Transport class
     */
    void Initialize_PlayBack(Transport& tr);

    /**
     * \brief returns the initialization status
     * Returns true if the node has been initialized. false otherwise.
     * \return true when the node has been initialized, false otherwise.
     */
    bool IsInitialized() const {
        return m_is_initialized;
    }

    /**
     * \brief returns a reference to the panel
     * The panel can be used to add, show or hide controls on the user interface
     * \return [out] reference to the panel of this node
     */
    const ui::wgt::Widget& Panel()  {
        return panel;
    }

    /**
     * \brief Called when a new session is opened
     * When a new session is opened this method calls the
     * On_Session_Open method for the current node
     * and dispatch the call to the children
     * \param [in] session const reference to the class session
     * representing the current session
     */
    void Open_Session(const CSession& session);


    /**
     * \brief Enable the current node and its children
     * Enable the current node and dispatch the call to all the children
     * The On_Enable virtual function is executed for the current node
     * and for all the children, depending on the propagation mask
     */
    void Enable();

    /**
     * \brief Disable the current node and its children
     * Disable the current node and dispatch the call to all the children
     * The On_Enable virtual function is executed for the current node
     * and for all the children, depending on the propagation mask
     */
    void Disable();

    /**
     * \brief Enable or disable the current node and its children
     * Enable or disable the current node and dispatch the call to all the children
     * The On_Enable virtual function is executed for the current node
     * and for all the children, depending on the propagation mask
     * \param [in] enabled true or false for enabling or disabling the module
     */
    void SetEnable(bool enabled);

    /**
     * \brief Returns true when the module is enabled, false otherwise
     * \return true when the module is enabled, false otherwise
     */
    bool IsEnabled() const {
        return m_is_enabled;
    }

    /**
     * \brief Returns true when the module is disabled, false otherwise
     * \return true when the module is disabled, false otherwise
     */
    bool IsDisabled() const {
        return !m_is_enabled;
    }

    /**
     * \brief Called when the module starts (play)
     * When the module is enabled, calling this method put the is_awaken flag to true
     * The On_WakeUp virtual function is called for the current node and
     * the call is dispatched to all the children, depending on the propagation mask value
     */
    void WakeUp();

    /**
     * \brief Called when the module stops (stop)
     * When the module is enabled, calling this method put the is_awaken flag to false
     * The On_Suspend virtual function is called for the current node and
     * the call is dispatched to all the children, depending on the propagation mask value
     */
    void Suspend();

    /**
     * \brief returns the status of the is_awaken flag
     * \return true if the module is awaken, false otherwise
     */
    bool IsAwaken() const {
        return m_is_awaken;
    }

    /**
     * \brief Called when the module moves to the previous frame (stop)
     * When the module is enabled the On_Prev virtual function is called for the current node and
     * the call is dispatched to all the children, depending on the propagation mask value
     */
    void Prev();

    /**
     * \brief Called when the module moves to the next frame (stop)
     * When the module is enabled the On_Prev virtual function is called for the current node and
     * the call is dispatched to all the children, depending on the propagation mask value
     */
    void Next();

    /**
     * \brief Called when the module moves to the \em frame-th frame (stop)
     * When the module is enabled the On_Goto virtual function is called for the current node and
     * the call is dispatched to all the children, depending on the propagation mask value
     */
    void Goto(unsigned long frame);

    /**
 	 * \brief Triggers a Refresh processing for the current module
	 * When the module is enabled the On_Refresh virtual function is called for the current node and
	 * the call is dispatched to all the children, depending on the propagation mask value
	 * On_Refresh is called independently on the is_awaken flag value
	 */
    void Refresh();

    /**
 	 * \brief Triggers an Execute processing for the current module
	 * When the module is enabled the On_Execute virtual function is called for the current node and
	 * the call is dispatched to all the children, depending on the propagation mask value
	 * On_Execute is called only when is_awaken is true
	 */
    void Execute();

    /**
 	 * \brief Triggers an Idle processing for the current module
	 * When the module is enabled the On_Idle virtual function is called for the current node and
	 * the call is dispatched to all the children, depending on the propagation mask value
	 * On_Idle is called independently on the is_awaken is false
	 */
    void Idle();

    /**
 	 * \brief Set the mode for the current node
	 * When the module is enabled the On_Mode_Changed virtual function is called for the current node and
	 * the call is dispatched to all the children, depending on the propagation mask value
	 * \param [in] mode Mode for the current node
     */
    void SetMode(session::mode::ModeID mode);

    /**
     * \brief Distribute the recording status across the modules
     * This method calls the On_Recording_Initialization virtual function for the current node
     * and for all the children. The Status of the recording is distributed as reference.
     * \param [in] rc the recording status distributed across different modules
     */
    void Recording_Initialize(const CRecordingCtl& rc);

    /**
     * \brief Create a new recording
     * This method calls the On_Recording_Create virtual function
     * for the current node and for all the children
     */
    void Recording_Create();

    /**
     * \brief Destroys the current recording
     * This method calls the On_Recording_Destroy virtual function
     * for the current node and for all the children
     */
    void Recording_Destroy();

    /**
     * \brief Starts prerecording.
     * This method calls the On_PreRecording_Start virtual function
     * for the current node and for all the children
     */
    void PreRecording_Start();

    /**
     * \brief Stops prerecording.
     * This method calls the On_PreRecording_Stop virtual function
     * for the current node and for all the children
     */
    void PreRecording_Stop();

    /**
     * \brief Starts a new segment in the current recording
     * This method calls the On_Recording_Start virtual function
     * for the current node and for all the children
     */
    void Recording_Start();

    /**
     * \brief Stops the current segment in the current recording
     * This method calls the On_Recording_Stop virtual function
     * for the current node and for all the children
     */
    void Recording_Stop();


    /**
     * \brief Returns the recording status
     * \return [out] const reference to the CRecordingCtl class
     * representing the status of the current recording
     */
    const CRecordingCtl& RecordingCtl() const {
        return *m_recording_ctl;
    }

    /**
     * \brief Enable recording for the current node
     * This is now removed: check the recording status using CRecordingCtl
     * which provides and atomic status for all modules
     */
    // void Recording_Enable() {
    //     m_is_recording_enabled=true;
    // }

    /**
     * \brief Disable recording for the current node
     * This is now removed: check the recording status using CRecordingCtl
     * which provides and atomic status for all modules
     */
    // void Recording_Disable() {
    //     m_is_recording_enabled=false;
    // }

    /**
     * Returns true when the recording is enabled for the current node. False otherwise.
     * This is now removed: check the recording status using CRecordingCtl
     * which provides and atomic status for all modules
     */
    // bool IsRecordingEnabled() const {
    //     return m_is_recording_enabled;
    // }

    // TODO: aggiungere per il debug una macro che stampa questo
    // std::cout << Name() << "::CModule::Clock_Initialized" __PRETTY_FUNCT__<< std::endl;

    /**
     * \brief Execute the shutdown code
     * If the module has been initialized, execute the On_Shutdown virtual function
     * of the current node and then those of all children, depending on the
     * propagation mask set.
     */
    void ShutDown();

    /**
     * \brief true after the ShutDown method has been called
     *
     */
    bool IsShuttingDown() const {
        return m_is_shutdown_pending;
    }

    /**
     * \brief true before the shutdown method is called
     */
    bool IsRunning() {
        return !m_is_shutdown_pending;
    }

    /**
     * \brief Returns the name of the module
     * \return [out] constant reference to a string containing the module name
     * TODO: this shall be generalized using a boost::property_tree
     * and allowing user defined properties.
     */
    const std::string& Name_() const;

    /**
     * \brief Change the current module name
     * \param [in] _name the new name for the module
     */
    void Rename ( const std::string& _name );

    /**
     * This method is part of a different API.
     * Using this API each module can declare a set of path in a bus.
     *
     * TODO: this staff can be placed in a separate base class
     * since user side devices do not derive from CModule
     */
    void CreateMessagePath(const std::string& parent_path="/");
    
protected:

    /**
     * This class can only be constructed from derived classes
     */
    CModule();
    virtual ~CModule();

    /**
     * \brief Add a child for dispatching events
     * Add a child to the list of children of this module
     * After this call events are dispatched to the child
     * \param [in] child reference to the new child
     */
    void AddChild(CModule& child);

    /**
     * \brief Remove a child from the children list
     * Add a child to the list of children of this module
     * After this call events are no more dispatched to the child
     * \param [in] child reference to the new child
     */
    void DelChild(CModule& child);

    /**
     * \brief Called from a derived class to subscribe the dispatching
     * of id messages from the father.
     * This is part of the message passing interface
     * \param [in] id message to subscribe dispatch
     */
    void Subscribe_Cmd_Dispatch(module::MessageID id);

    /**
     * \brief Called from a derived class to unsubscribe the dispatching
     * of id messages from the father.
     * This is part of the message passing interface
     */
    void UnSubscribe_Cmd_Dispatch(module::MessageID id) {}

    /**
     * \brief Called from a derived class to trigger the On_RunMessage virtual function
     * This is part of the message passing interface
     * \param [in] msg the message to be used as parameter for the virtual function
     */
    void RunMessage(module::CMessage& msg);

    /**
     * \brief virtual function called from RunMessage
     * This is part of the message passing interface
     * \param [in] msg the message to be processed
     */
    virtual void On_RunMessage(module::CMessage& cmsg);

    // GUIDType ID() const { return m_ID; }

    /**
     * \brief returns the current propagation mask
     * \return a reference to the internal propagation mask for the current node
     */
    const EventMaskType& PropagationMask() const {
        return m_propagation_mask;
    }

    /**
     * \brief Set the propagation mask for the current node
     * Each bit of the propagation mask decide if the call shall be propagated to the children or not
     * \param [in] mask a reference to the new propagation mask for the current node
     */
    void SetPropagationMask(const EventMaskType& mask);

    /**
     * \brief Check the propagation mask bit for a specified event
     * \param [in] event for propagation mask check
     */
    bool IsPropagatonEnabled(module::MessageID event);

	/**
	 * \brief suspend the current thread while the module is suspended
	 * This method provides an atomic, thread safe wait for loop implementation.
	 * When writing thread loops this call can be used for waiting while the module is suspended
	 * The use of this method simplify the user code avoiding race condition
	 */
    void Wait_While_Suspended();

    /**
	 * \brief suspend the current thread until the module is suspended
	 * This method provides an atomic, thread safe wait for loop implementation.
	 * When writing thread loops this call can be used for waiting until the module is suspended
	 * The use of this method simplify the user code avoiding race condition
	 */
    void Wait_Until_Suspended();

    /**
     * \brief user-implemented function called when initialization must be performed
     * NOTE: Initialization may occur after enabling. A disabled module can be initialized.
     * If the decision of initializing only enabled modules is taken then
     * an appropriate check must be put in front of every method
     */
    virtual void On_Initialization() {};

    /**
     * \brief user-implemented function called in playback mode only when a new Transport object is distributed
     * TODO: use an adapter placed in Framework and instantiated from the engine
     * which encapsulate both methods used by the applications
     */
    virtual void On_Initialization(Transport& tr) {}

    /**
     * \brief user-implemented function called before any initialization, when the mode is changed
     */
    virtual void On_Mode_Changed( session::mode::ModeID mode ) {};

    /**
     * \brief user-implemented function called when a new session is opened
     * Users needing information available in the session object shell implement
     * this method in order to get a reference to the CSession
     */
    virtual void On_Session_Open( const CSession& session )  {}

    /**
     * \brief user-implemented function called when the module is enabled
     */
    virtual void On_Enable()   {}

    /**
     * \brief user-implemented function called when the module is disabled
     */
    virtual void On_Disable()  {}

    /**
     * \brief user-implemented function called when the processing is enabled
     */
    virtual void On_WakeUp()  {}

    /**
     * \brief user-implemented function called when the processing is disabled
     */
    virtual void On_Suspend() {}

    /**
     * \brief user-implemented called when the engine moves to the previous frame
     */
    virtual void On_Prev()    {}

    /**
     * \brief user-implemented called when the engine moves to the next frame
     */
    virtual void On_Next()    {}

    /**
     * \brief user-implemented called when the engine jump to another frame
     */
    virtual void On_Goto(unsigned long frame) {}

    /**
     * \brief user-implemented called when the node must be refreshed node must be refreshed
     */
    virtual void On_Refresh() {}

    /**
     * \brief user-implemented called by Refresh if the node is waken
     */
    virtual void On_Execute() {}

    /**
     * \brief user-implemented called by Refresh if the node is idle
     */
    virtual void On_Idle()    {}

    /**
     * \brief user-implemented method called when the by CRecordingCtl is distributed
     */
    virtual void On_Recording_Initialization(const CRecordingCtl& rc) {}

    /**
     * \brief user-implemented method called when a new recording is initialized
     */
    virtual void On_Recording_Create() {}

    /**
     * \brief user-implemented method called when the current recording is destroyed
     */
    virtual void On_Recording_Destroy() {}

    /**
     * \brief user-implemented method called when prerecording is started
     */
    virtual void On_PreRecording_Start() {}

    /**
     * \brief user-implemented method called when prerecording is stopped
     */
    virtual void On_PreRecording_Stop()  {}

    /**
     * \brief user-implemented method called when a new recording segment is started
     */
    virtual void On_Recording_Start() {}

    /**
     * \brief user-implemented method called when the current recording segment is stopped
     */
    virtual void On_Recording_Stop()  {}

    /**
     * \brief user-implemented method called when the shut down code must be executed
     * In this function all the deallocation must take place, including signal detatching
     * After this call, some module can be unload from memory and further deallocation could
     * lead to unexpected behaviors.
     */
    virtual void On_ShutDown() {}


    /**
     * \brief user-implemented method called when a new message path is created from a child
     */
    virtual void On_CreateMessagePath(std::string& cmd_path) {}

    /**
     * \brief Called from AddChild to allow Subscription of Message Dispatching from parent
     */
    virtual void On_Subscribe_Messages_Dispatch() {}  ///<

    /**
     * WARNING this is preliminary code: do not use it
     */
    DECLARE_ACTION(ON_WAKEUP, void());

    /**
     * WARNING this is preliminary code: do not use it
     */
    DECLARE_ACTION(ON_SUSPEND, void());

    /**
     * \brief handler to the panel
     * FIXME: bring back to the private part and
     */
    ui::wgt::Widget panel;

private:

    /**
     * \brief Set the parent of the current module
     */
    void SetParent(const CModule* parent);

    boost::mutex     m_mtx;          //< mutex for exclusive access
    boost::condition m_cond_wakeup;  //< wakeup condition variable
    boost::condition m_cond_suspended;//< suspend condition variable

    bool m_is_initialized;   //< initialization flag
    bool m_is_enabled;       //< enabled flag
    bool m_is_awaken;        //< awaken flag
    bool m_is_refresh_needed;
    const CRecordingCtl* m_recording_ctl;
    bool m_is_prerecording_enabled;
    bool m_is_recording_enabled;
    bool m_is_shutdown_pending;

    ListType m_children;
    EventMaskType m_propagation_mask;  // gli eventi contenuti in questa maschera vengono progagati ai figli

    typedef boost::bimap<std::string, CModule*> PathsTableType;
    static PathsTableType m_path;

    void RegistrerHandlers()
    {
        // Example: ACTION_HANDLER(ON_WAKEUP, boost::bind(&CModule::On_WakeUp, this));
    }

    const CModule*  m_pparent;
    boost::property_tree::ptree m_properties;
};


} // namespace usr

/**@}*/

#endif
