/**
 * @file Framework/CDeviceManager.h
 * \brief Device manager interface
 * \author Paolo Grisleri (grisleri@vislab.it)
 */

#ifndef _CDEVICE_MANAGER_H
#define _CDEVICE_MANAGER_H

#include <string>
#include <typeinfo>

#include <boost/any.hpp>

#include <Framework/gold_framework_export.h>

#include <Libs/Debug/Demangling.h>
#include <UI/Panel/Widget.h>
#include <Framework/CModule.h>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif


namespace dev
{


/**
 * \brief Base class for a device tree node
 *
 * This class represents one of the device tree nodes.
 * Derived classes can be groups, leafs or links
 */
class GOLD_FRAMEWORK_EXPORT CDeviceNode
{
public:
	/** \brief Type for the nodes storage */
	typedef std::vector<CDeviceNode *> ListType;

	/** \brief Local type for the nodes storage iterator */
	typedef ListType::iterator iterator;

	/** \brief Local type for the node storage const iterator */
	typedef ListType::const_iterator const_iterator;

	/** \brief Type of the operation notified back to the callback */
	typedef enum
	{
		INSERT_CHILD, REMOVE_CHILD, LINK, UNLINK
	} OperationType;

	/** \brief Callback notification type */

#ifdef USE_BOOST_SIGNAL2
	typedef boost::signals2::signal<void(OperationType, const std::string&)> SignalNotificationType;
#else
	typedef boost::signal<void(OperationType, const std::string&)> SignalNotificationType;
#endif


	/**
	 * \brief Constructor
	 * \param name Node name
	 * \param ti type_info of the device
	 */
	CDeviceNode(const std::string& name, const std::type_info& ti);

	/**
	 * \brief Destructor
	 */
	virtual ~CDeviceNode();

	/**
	 * \brief Returns the node name
	 */
	const std::string& Name() const;

	/**
	 * \brief Returns the type stored
	 */
	const std::type_info& Type() const;

	/**
	 * \brief Returns the panel associated to the internal type
	 */
	virtual const ui::wgt::Widget& Panel() = 0;

	/**
	 * \brief Insert a new CDeviceNode as child of this node
	 * \param node CDeviceNode to be added as child
	 */
	virtual CDeviceNode* Insert(CDeviceNode* node) = 0;

	/**
	 * \brief Remove a child node
	 * \param path path of the node to be removed
	 */
	virtual void Remove(const std::string& path) = 0;

	/**
	 * \brief Subscribe a callback for operation notifications
	 *
	 * This method allows to subscribe a user function or method
	 * called whenever the user code needs to be notified of an operation on the node
	 * \see OperationType
	 */
	void Subscribe_Notification(
			boost::function<void(OperationType, const std::string&)> cb);

	/**
	 * \brief Returns a pointer to the node specified by path
	 * \param path path of the node to be returned
	 * \return a pointer to the CDeviceNode found or 0 when the node is not found
	 */
	CDeviceNode* find(const std::string& path);

	/**
	 * \brief Returns a reference to the node specified by path
	 * The lookup begins from the current path
	 * \return a reference to the node specified by path
	 * A path_not_found is thrown when the path is not found
	 */
	CDeviceNode& operator [](const std::string& path);

	/**
	 * \brief Returns a reference to the node specified by path
	 * The lookup begins from the current path
	 * \return a reference to the node specified by path
	 * A path_not_found is thrown when the path is not found
	 * \see operator []
	 */
	CDeviceNode& Node(const std::string& path);

	/**
	 * \brief Returns a reference to the list containing the children of the current node
	 * \return a list containing the children of the current node
	 */
	const ListType& Children() const;

	/**
	 * \brief Cast operator to ListType
	 *
	 * Converts the current object in a reference to the list
	 * containing the children of the current node
	 * \return a list containing the children of the current node
	 * \see Children
	 */
	operator const ListType&();

	/** \brief Alias for the const_iterator type*/
	typedef const_iterator children_const_iterator;

	/** \brief Checks if the internal type is the same passed as template parameter */
	template<class T>
	bool IsA()
	{
		return (&(Dev().type()) == &typeid(T*));
	}

	/** \brief Checks if the internal type is the same passed as template parameter (const version) */
	template<class T>
	bool IsA() const
	{
		return (&(Dev().type()) == &typeid(T*));
	}

	/** \brief Explicit conversion to the requested type passed as template parameter */
	template<class T>
	T& As()
	{
		return *boost::any_cast<T*>(Dev());
	}

	/** \brief Explicit conversion to the requested type passed as template parameter (const version) */
	template<class T>
	const T& As() const
	{
		return *boost::any_cast<T*>(Const_Dev());
	}

	/**
	 * \brief Cast operator, reference version
	 *
	 * A std::runtime_error exception is thrown when a bad conversion is requested
	 */
	template<class T>
	operator T&()
	{
		try
		{
			return *boost::any_cast<T *>(Dev());
		} catch (const boost::bad_any_cast &bac)
		{
			std::string src = vl::Demangle(Type().name());
			std::string dst = vl::Demangle(typeid(T).name());
			throw std::runtime_error(
					"[EE] DeviceManager - Bad conversion requested: " + src
							+ std::string(" -> ") + dst);
		}
	}

	/**
	 * \brief Cast operator, reference version, special case for CDeviceNode
	 *
	 * A std::runtime_error exception is thrown when a bad conversion is requested
	 */
	// operator CDeviceNode&();

	/**
	 * \brief Cast operator, pointer version
	 *
	 * A std::runtime_error exception is thrown when a bad conversion is requested
	 */
	template<class T>
	operator T *()
	{
		try
		{
			return boost::any_cast<T *>(Dev());
		} catch (const boost::bad_any_cast &bac)
		{
			throw std::runtime_error(
					"[EE] DeviceManager - Bad conversion requested: "
							+ vl::Demangle(Type().name()) + std::string("->")
							+ vl::Demangle(typeid(T).name()));
		}
	}

	/**
	 * \brief Cast operator, pointer version, special case for CDeviceNode
	 *
	 * A std::runtime_error exception is thrown when a bad conversion is requested
	 */
	operator CDeviceNode*();

	/** \brief Stream operator for writing the content of a node, as pretty printed names, on a stream*/
	friend GOLD_FRAMEWORK_EXPORT std::ostream & operator <<(std::ostream& os,
			const CDeviceNode &);

	/** \brief Exception class thrown when a requested path is not found */
	class path_not_found
	{
	};

protected:

	// NOTE: These are needed since CDeviceTree and CLinkToDeviceNode needs
	// subnodes as CDeviceNode: the following two methods
	// are not available for users since they allow to modify arbitrarily
	// the node contents

	friend class CLinkToDeviceNode;
	friend class CDeviceTree;

	virtual boost::any& Dev() = 0;

	const boost::any& Dev() const
	{
		return Dev();
	}
	;

	virtual const boost::any& Const_Dev() const = 0;

	void Notify(OperationType op, const std::string& path);

private:
	std::string m_name; ///< node name
	const std::type_info* m_type_info; ///< internal type information

	ListType m_children;        ///< subnodes list
	SignalNotificationType m_signal; ///< callback
};

/**
 * \brief Class for printing the node content
 */
class GOLD_FRAMEWORK_EXPORT CNodePrinter
{
	std::string m_str;
	unsigned int m_indent;

	CNodePrinter(unsigned int indent);

public:

	/** \brief Default constructor */
	CNodePrinter();

	/**
	 * \bref Constructor receiving a node
	 * \param node to be printed
	 */
	CNodePrinter(const CDeviceNode& node);

	/**
	 * \brief Operator for printing a node
	 * \param pointer to the node to be printed
	 */
	void operator()(const CDeviceNode* node);

	/**
	 * \brief Returns the output string
	 */
	std::string String() const;
};

/**
 * \brief Node for modeling a device
 *
 * This is a node of the device tree containing a device
 */
class GOLD_FRAMEWORK_EXPORT CDeviceLeaf: public CDeviceNode
{
	boost::any m_device;  ///< the concrete device
	usr::CModule& m_module;  ///< the same device as CModule

protected:

	boost::any& Dev();
	const boost::any& Const_Dev() const;

public:

	/**
	 * \brief Constructor receiving name and a pointer to the concrete device
	 * \param name name of the concrete device stored internally
	 * \param system_device pointer to the concrete device owned by the node
	 */
	template<class T>
	CDeviceLeaf(const std::string& name, T* system_device) :
			CDeviceNode(name, typeid(typename T::DeviceType)),
			m_device(static_cast<typename T::DeviceType*>(system_device)),
			m_module(*system_device)
	{
	}

	/** \brief Destructor */
	virtual ~CDeviceLeaf();

	/** \brief Panel of the concrete device stored internally */
	virtual const ui::wgt::Widget& Panel();

	/** \brief Insert a new child node */
	CDeviceNode* Insert(CDeviceNode* node);

	/** \brief Remove a children with the specified path */
	void Remove(const std::string& path);
};

/**
 * \brief Device tree released from the device manager to the applications
 *
 */
class GOLD_FRAMEWORK_EXPORT CDeviceTree: public CDeviceNode
{

public:
	friend class CLinkToDeviceNode;

	/** Constructor accepting a name */
	CDeviceTree(const std::string& name = "");

	/** \brief Destructor */
	~CDeviceTree();

	/** Returns the Panel */
	virtual const ui::wgt::Widget& Panel();

	/**
	 * \brief Insert a new node into the tree
	 * \param node pointer to the new node
	 */
	CDeviceNode* Insert(CDeviceNode* node);

	/**
	 * \brief Remove a node from the tree
	 * \param path of the node to be removed
	 */
	void Remove(const std::string& path);

	/** \brief Removes all the nodes stored internally */
	void Clear();

protected:

	boost::any& Dev();
	const boost::any& Const_Dev() const;

private:
	void On_Device_Changed(CDeviceNode::OperationType op,
			const std::string& str);

	boost::any m_me_as_any;     ///< pointer to the current object as boost::any
};

/**
 * \brief Node linking another node in another device tree
 *
 * When a linked object is deleted, the link is not notified about the deletion
 * thus continue to work on a deallocated memory
 */
class GOLD_FRAMEWORK_EXPORT CLinkToDeviceNode: public CDeviceNode
{
private:
	CDeviceNode* m_p_device_node;

	void On_Device_Changed(CDeviceNode::OperationType op,
			const std::string& str);
protected:

	boost::any& Dev();
	const boost::any& Const_Dev() const;

	CDeviceNode& DeviceNode() const;

public:

	/**
	 * \brief Constructor accepting a name and a reference to a CDeviceTree to link
	 * \param name name of the current nod
	 * \param tree reference to a valid CDeviceTree
	 */
	explicit CLinkToDeviceNode(const std::string& name, CDeviceTree& tree);

	/**
	 * \brief Constructor accepting a name and a reference to a CDeviceNode to link
	 * \param name name of the current nod
	 * \param tree reference to a valid CDeviceNode
	 */
	explicit CLinkToDeviceNode(const std::string& name, CDeviceNode& node);

	/** \brief Destructor */
	~CLinkToDeviceNode();

	/** \brief Returns the panel of the linked node */
	virtual const ui::wgt::Widget& Panel();

	/**
	 * \brief Inserts a new node as child of the linked node
	 * \param node node to be added as subnode of the linked node
	 */
	CDeviceNode* Insert(CDeviceNode* node);

	/**
	 * \brief Remove a child of the linked node with specified path
	 * \param path path of the subnode to be removed
	 */
	void Remove(const std::string& path);

};

/**
 * \brief User proxy with read only features
 *
 * This class is an adapter of CDeviceTree.
 * Public methods are designed to be access the internal nodes and being non destructive.
 * Here is an example on how to use this class:
 * \code
 * // the system has one camera at the path "/CAMERAS/A"
 * // the method Dev() returns a dev::CDeviceManager
 *
 * // code for retriving a reference to the camera
 * CCamera& xx= Dev()["CAMERAS/something"];
 *
 * // code for opening the camera panel
 * Devices["/CAMERAS/A"].Panel().Show();
 * \endcode
 */
class GOLD_FRAMEWORK_EXPORT CDeviceManager
{
public:

	/**
	 * Constructor accepting a CDeviceTree
	 * \param device_tree Fully configured CDeviceTree that will be presented to the user
	 */
	CDeviceManager(CDeviceTree& device_tree);

	/**
	 * \brief operator  for retriving the subnode with requested path
	 * \param path path of the subnoded to be returned
	 * An exception of type CDeviceNode::path_not_found will be thrown
	 * if path do not exists
	 */
	CDeviceNode& operator [](const std::string& path);

	/**
	 * \brief Retrives the subnode with requested path
	 * \param path path of the subnoded to be returned
	 * An exception of type CDeviceNode::path_not_found will be thrown
	 * if path do not exists
	 */
	CDeviceNode& Node(const std::string& path);

	/** \brief Returns the list of Children */
	const CDeviceNode::ListType& Children() const;

private:
	CDeviceTree& m_root;                  ///< Device tree root
};

} // namespace dev

#endif  // _CDEVICE_MANAGER_H

