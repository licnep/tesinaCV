/**
 * \file CRecordingCtl.h
 * \brief Class for managing the recording status
 * \author Paolo Grisleri (grisleri@vislab.it)
 */

#ifndef _CRECORDING_STATUS_H
#define _CRECORDING_STATUS_H

#include <boost/thread/mutex.hpp>

#include <Engine/gold_engine_export.h>
#include <Libs/Time/TimeUtils.h>

namespace data { class CEventWriter; }
namespace dev { class CDiskWriter; }

namespace usr
{
  
  class CSession;


/**
 * \brief Enumerator for the recording status
 */
typedef enum
{
    NOT_RECORDING=0,  ///< The engine is not recording
    PRE_RECORDING,    ///< The engine is in pre-recording status
    RECORDING,        ///< The engine is recording
    RECORDING_PENDING,///< The engine is idle and the recording is activated
    FLUSHING          ///< The engine is closing down and the recording is flushing the buffer
} RecStatusID;


/**
 * \brief This is an abstract base class for CSystemRecordingCtl
 * Supplies the methods for accessing the recording and managing the recording
 * NOTE: MSVC10 requires the same visibility as Engine/CSystemRecordingCtl
 */
class GOLD_ENGINE_EXPORT CRecordingCtl
{
public:
	/**
	 * \brief Automatic conversion operator to a variable containing the status of the recording
	 */
    virtual operator const RecStatusID& () const = 0;

    /**
     * \brief Returns the recording status
     */
    virtual const RecStatusID& Status() const = 0;

    /**
     * \brief Returns the prerecording time
     */
    virtual const vl::chrono::TimeType& PreRecordingTime() const  = 0;

    /**
     * \brief Returns the current recording time
     */
    virtual const vl::chrono::TimeType& RecordingTime() const  = 0;

    /**
     * \brief Returns true if the temporary files used for prerecording
     * will be kept after the end of the recording.
     */
    virtual bool KeepTempFiles() const = 0;

    /**
     * \brief Return the start time, relative to the clock origin, of the current recording segment
     */
    virtual const vl::chrono::TimeType& RecStartTime() const  = 0;

    /**
     * \brief Return the stop time, relative to the clock origin, of the current recording segment
     */
    virtual const vl::chrono::TimeType& RecStopTime() const  = 0;

    /**
     * \brief Return the absolute start time of the current recording segment
     */
    virtual const vl::chrono::AbsoluteTimeType AbsRecStartTime() const  = 0;

    /**
     * \brief Return the absolute stop time of the current recording segment
     */
    virtual const vl::chrono::AbsoluteTimeType AbsRecStopTime() const = 0;

    /**
     * \brief Return the current output path
     */
    virtual std::string OPath() const = 0;

    /**
     * \brief Return the string version of the current status
     */
    virtual std::string StrStatus() const = 0;

    /**
     * \brief Return true when the prerecording time is greater than 0 (prerecording activated)
     */
    virtual bool IsPreRecordingActive() const = 0;

    /**
     * \brief Return true if the engine has already prerecorded
     */
    virtual bool HasPreRecorded() const = 0;

    /**
     * \brief Return true if the engine has recorded some data
     */
    virtual bool HasRecorded() const = 0;

    /**
     * \brief Return a reference to the session
     */
    virtual CSession& Session() const  = 0;

    /**
     * \brief Return a reference to Event Writer
     */
    virtual data::CEventWriter& EventWriter() const  = 0;

    /**
     * \brief return a reference to the disk writer
     */
    virtual dev::CDiskWriter&  DiskWriter() const  = 0;

    /**
     * \brief Return the current segment number
     */
    virtual unsigned long RecSegmentNum() const = 0;

    /**
     * \brief Return true if recording is enabled
     */
    virtual bool IsRecordingEnabled() const = 0;

    virtual ~CRecordingCtl() {};

    /**
     * \brief return a reference to the big recording mutex
     * \deprecated
     */
    GOLD_ENGINE_DEPRECATED virtual boost::mutex& BigRecordingMutex() const  = 0;
};

} // namespace usr

#endif // _CRECORDING_STATUS_H
