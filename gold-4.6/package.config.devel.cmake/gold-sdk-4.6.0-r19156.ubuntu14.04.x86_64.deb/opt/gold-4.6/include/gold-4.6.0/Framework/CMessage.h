/**
 * \brief List of the messages supported by modules and available through the messagebus
 */
#ifndef _CMESSAGE_H
#define _CMESSAGE_H

#include <string>
#include <limits>

#include <boost/any.hpp>

#include <Framework/gold_msg_bus_export.h>

namespace module
{

/**
 * \brief Messages supported by modules
 */
typedef enum
{
    INITIALIZE, ///< Initialization
    INITIALIZE_TRANSPORT, ///< Transport initialization
    INITIALIZE_PROFILER,  ///< Profiler initialization
    INITIALIZE_PANELMGR,  ///< Panel manager initialization
    // CHANGE_MODE,
    OPEN_SESSION, ///< Session opening
    ENABLE,
    DISABLE,
    WAKEUP,
    SUSPEND,
    PREV,
    NEXT,
    GOTO,
    REFRESH,
    EXECUTE,
    IDLE,
    INITIALIZE_RECORDER,
    RECORDING_START,
    RECORDING_STOP,
    RECORDING_FLUSH,
    SET_LOOP,
    SET_HZ,
    SHUTDOWN,
    HEART_BEAT,

    STREAM_START,
    STREAM_START_OK,
    STREAM_START_ERR,

    STREAM_STOP,
    STREAM_STOP_OK,
    STREAM_STOP_ERR,

    GET_CHILDREN,  ///< get the children list
    LIST,          ///< get the variables list
    SET,           ///< set a variable value
    GET,           ///< get a variable value
    CUSTOM,        ///< custom command specified in the payload
    // space for custom commands
    EMPTY,

    LAST_MESSAGE = EMPTY
} MessageID;

#define NUM_MESSAGES (module::SHUTDOWN+1)

/**
 * \brief Class for modeling a message
 */
class GOLD_MSG_BUS_EXPORT CMessage
{
public:
	/** \brief Default constructor */
    CMessage() : id(EMPTY), num(0) {}

    /** \brief Synchronization message, only identifier is provided */
    CMessage( MessageID _id ) :
            id(_id), num(0)
    {}

    /** \brief Synchronization message, only identifier and serial number are provided*/
    CMessage(MessageID _id, std::size_t _num)  :
            id(_id), num(_num)
    {}

    /** \brief Message with payload, with _num*/
    template<typename T>
    CMessage(MessageID _id, T& _payload, std::size_t _num)  :
            id(_id), num(_num), payload(_payload)
    {}

    /** \brief Message with payload*/
    template<typename T>
    CMessage(MessageID _id, T& _payload )  :
            id(_id), num(), payload(_payload)
    {}

    /** \brief Maximum serial number allowed */
    static std::size_t max_num() {
        return std::numeric_limits<std::size_t>::max();
    }

    MessageID   id;      ///< Message identifier
    std::size_t num;     ///< Serial number
    boost::any  payload; ///< Custom data
};

} // namespace module


#endif // _CMESSAGE_H
