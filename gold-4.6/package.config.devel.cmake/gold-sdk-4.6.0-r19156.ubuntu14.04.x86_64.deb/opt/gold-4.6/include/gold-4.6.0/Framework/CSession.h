/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.ARGO.ce.unipr.it                                  *
 *                                                                    *
 *  Author: Grisleri Paolo                                            *
 *          Medici Paolo (October 2004)                               *
 **********************************************************************/

/**
 * \file CSession.h
 * \brief Class for managing the current session information
 * \author Paolo Grisleri (grisleri@vislab.it)
 */

#ifndef _CSESSION_H
#define _CSESSION_H

#include <string>
#include <map>

#include <boost/shared_ptr.hpp>

#include <Libs/VarReplacer/VarReplacer.h>

#include <Framework/Modes.h>
#include <Framework/HWS_Version.h>
#include <Framework/CPathManager.h>

#include <Framework/gold_framework_export.h>

namespace vl
{
namespace ini
{
class INIFile;
}
}
using vl::ini::INIFile;

namespace usr
{

/** \brief Class for managing the current session information
 *
 * Session contains the following information
 * - HWS. Data configuration currently used: such as if the system is running on an
 * hardware setup or playing back a recording.
 * - Path. Path of the current system merged with application path
 * - Variables. A set of variables such as IPATH, INAME, OPATH, ONAME
 *
 * The Engine creates the Session and distribute it to all the components in the system
 * Every component derived from CModule, including applications, receive a const reference
 * to the session through the On_Session_Open method.
 *
 * \see CModule::On_Session_Open
 *
 */
class GOLD_FRAMEWORK_EXPORT CSession
{
public:
	/** \brief type for shortening the option map*/
	typedef std::map<std::string, std::string> OptionsType;

	/**
	 * \brief Constructor.
	 * \param path_manager boost::shared_ptr to the path manager created by the engine
	 * \param ini pointer to an INIFile containing the engine options
	 */
	CSession(boost::shared_ptr<CPathManager> path_manager, INIFile *ini);

	/** brief Destructor */
	~CSession()
	{
	}

	/**
	 * \brief Open a new session
	 * \param session_path path of the session file to be opened
	 */
	void Open(const std::string& session_path);

	/**
	 * \brief Closes the current session
	 */
	void Close();

	/**
	 * \brief Returns true if the current session has been open correctly
	 * \return true if the current session has been open correctly, false otherwise
	 */
	bool IsOpen() const;

	/**
	 * \brief Generate a new output path
	 *
	 * The output path, the path used for storing recording and other output
	 * may contain variables such as $AUTONUMBER. Calling this function cause to rescan
	 * the filesystem and generate a new output path.
	 *
	 * \return boost::system::errc::success when everything is ok or
	 * the corresponding error otherwise
	 */
	boost::system::system_error RegenerateOutputPath();

	/**
	 * \brief Returns true when the current session mode is PLAYBACK, false otherwise
	 */
	bool IsPlayBack() const
	{
		return m_mode & session::mode::PLAYBACK;
	}

	/**
	 * \brief Returns true when the current session mode is HARDWARE, false otherwise
	 */
	bool IsHardware() const
	{
		return m_mode == session::mode::HARDWARE;
	}

	/**
	 * \brief Returns the current mode
	 */
	session::mode::ModeID Mode() const
	{
		return m_mode;
	}

	/**
	 * \brief Returns true when the engine is running from a development tree
	 */
	bool RunFromDevel() const
	{
		return m_ppath_manager->Path(BASE_DIR)
				!= m_ppath_manager->Path(INST_DIR);
	}

	/**
	 * \brief Returns true when the engine is running from an installation
	 */
	bool RunFromInstall() const
	{
		return m_ppath_manager->Path(BASE_DIR)
				== m_ppath_manager->Path(INST_DIR);
	}

	/**
	 * \brief Returns the input path
	 *
	 * The input path is the location on the session initialization file
	 * For a playback session this path corresponds to the path of the data
	 * for an HARDWARE session this is the path of the HWS file
	 * This method returns a valid path only when the session is opened correctly
	 */
	const CPathManager::PathType& IPath() const
	{
		return m_ppath_manager->Path(INPUT_DIR);
	}

	/**
	 * \brief Returns the input name
	 *
	 * The input name is the name of the current sequence.
	 * For a PLAYBACK session this is the name used as output name,
	 * the leaf of the recording path, for recording data.
	 * For an HARDWARE session this is the name of the HWS file used.
	 */
	const std::string& IName() const
	{
		return m_iname;
	}

	/**
	 * \brief Returns the output paths
	 *
	 * The output paths is a set of paths that can be used to store
	 * data for output purposes such as recording
	 */
	const CPathManager::PathsType& OPaths() const
	{
		return m_ppath_manager->Paths(OUTPUT_DIRS);
	}
	// std::string OPaths_raw() const { return m_OPaths_raw; /*m_PathManager.MultiPath(OUTPUT_DIRS);*/ }

	/**
	 * \brief Returns the output name
	 *
	 * The output paths is a set of paths that can be used to store
	 * data for output purposes such as recording
	 */
	const std::string& OName()
	{
		m_var_replacer.Replace(m_oname);
		return m_oname;
	}
	// const std::string& OName_raw() const { return m_OName_raw; }  // unexpanded oname

	/**
	 * \brief Returns a const reference to the current session INIFile
	 */
	const INIFile& HWS() const
	{
		return *m_phws;
	}

	/**
	 * \brief Returns a reference to the current session INIFile
	 */
	INIFile& HWS()
	{
		return *m_phws;
	}

	/**
	 * \brief Returns the version of the current session INIFile
	 */
	hws::Version HWS_Version() const
	{
		return m_hws_version;
	}

	/**
	 *  \brief Returns a reference to the CPathManager allocated by the engine
	 *
	 *  This path manager contains system paths as well as application paths
	 */
	// TODO Aggiungere funzioni generiche di accesso diretto ai path
	// per i casi di i casi di utilizzo di PathManager()
	const CPathManager& PathManager() const
	{
		return *m_ppath_manager;
	}

	/**
	 * \brief Merges paths in the pathmanager passed as argument with the current engine paths
	 */
	void MergePaths(const CPathManager::PathsMap& paths)
	{
		m_ppath_manager->Merge(paths);
		// update the local var replacer with the merge
		for (CPathManager::PathsMap::const_iterator itr = paths.begin();
				itr != paths.end(); ++itr)
			m_var_replacer.Insert('$' + itr->first,
					itr->second.begin()->string());
	}

	/**
	 * \brief returns a CVarReplacer containing the session variables such as INAME, IPATH, ONAME, OPATHS
	 */
	const vl::CVarReplacer& VarReplacer() const
	{
		return m_var_replacer;
	}

	/**
	 * \brief Replaces the variables contained in the string with the corresponding values
	 */
	void ReplaceVars(std::string& str) const
	{
		m_var_replacer.Replace(str);
		m_ppath_manager->ReplaceVars(str);
	}
	const OptionsType& Options() const
	{
		return m_options;
	}

private:
	std::string m_iname;  ///< Input  Sequance Name (foglia di INPUT_DIR)
	std::string m_oname;  ///< Output Sequance Name (foglia di OUTPUT_DIR)
	std::string m_oname_raw;
	std::string m_opaths_raw;

	boost::shared_ptr<CPathManager> m_ppath_manager;
	vl::CVarReplacer m_var_replacer;
	OptionsType m_options; ///< header options

	INIFile *m_pini;      ///< The initialization file
	INIFile *m_phws;      ///< Hardware Setup File

	void SetVars();
	void Open(const std::string& IPath, const std::string& IName);

	session::mode::ModeID m_mode;
	hws::Version m_hws_version;
};

} // namespace usr

#endif
