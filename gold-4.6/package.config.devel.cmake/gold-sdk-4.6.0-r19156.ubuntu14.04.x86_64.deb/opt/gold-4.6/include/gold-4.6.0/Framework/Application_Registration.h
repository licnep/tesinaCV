/** \file Application_Registration.h
 *  \brief Factory and macro for registering applications
 *  \authors Paolo Grisleri \<grisleri@ce.unipr.it\>
 **/
#ifndef _C_APPLICATION_REGISTRATION
#define _C_APPLICATION_REGISTRATION

#include <string>
#include <Libs/Patterns/Singleton.h>
#include <Libs/Patterns/Factory.h>
#include <Libs/Patterns/RegisterObject.h>

namespace usr
{

class CApplication;

/** Type for the factory where the applications are registered */
typedef vl::Factory<std::string, usr::CApplication>   CApplicationFactoryType;

} // namespace usr

/**
 * \brief Macro for registering an application
 *
 * This macro allows to register an application into the Application factory (\see CApplicationFactoryType)
 * The macro has to be placed at the end of the application implementatio code
 * \code
 * // Application implementation code
 *
 * REGISTER_FUNCTIONALITY(Dummy,"Dummy");
 * \endcode
 * \param CLASS identifier of the class to be registered in the factory
 * \param NAME key associated to the class for creating an object using the factory
 */
#define REGISTER_APPLICATION(CLASS,NAME) vl::ObjectRegistrar< usr::CApplicationFactoryType, CLASS > drf_##CLASS(NAME);

#endif // _C_APPLICATION_REGISTRATION
