/**
 * @file FrameNumberUtils.h
 * @author Paolo Grisleri
 * @brief Utilities for managing frame number type
 */

#ifndef _FRAMENUMBER_UTILS_H
#define _FRAMENUMBER_UTILS_H

#include <string>
#include <Framework/gold_framework_export.h>

/**
 * \brief Minimum allowed width, in digit, of the framenumber
 */
#define FRAMENUMBER_MIN_WIDTH  6u

/**
 * \brief Maximum allowed width, in digit, of the framenumber
 */
#define FRAMENUMBER_MAX_WIDTH 10u

/** \brief Namespace containing functions for framenumber parameters names */
namespace params
{

/**
 * \brief Returns the name of the framenumber variable
 */
GOLD_FRAMEWORK_EXPORT const char* FrameNumber();

/**
 * \brief Returns the name of the framecounter variable
 */
GOLD_FRAMEWORK_EXPORT const char* FrameCounter();

} // namespace params


/** \brief Namespace including utilities for managing framenumbers */
namespace framenumber
{

/**
 * Type for the framenumber
 */
typedef uint64_t FrameNumberType;

/**
  * \brief Expand the FrameNumber/FrameCounter variables in Location
  * @param Location original string with variable names
  * @param FrameCounter value to be substituted
  * @return The Expanded string
  */
void GOLD_FRAMEWORK_EXPORT Expand(std::string& location, FrameNumberType frame_counter);

/**
 * \brief Sets the number of digits to be used by the functions
 * \param w new width to be used
 */
void GOLD_FRAMEWORK_EXPORT SetWidth(unsigned int w);

/**
 * \brief returns the number of digits used by the function
 * Conversion buffer size  (=width+1)
 * \return the number of digits used by the functions
 */
unsigned int GOLD_FRAMEWORK_EXPORT GetSize();


/**
* \brief Fast converion from an unsigned integer to a string representing a frame number
*
* This is a fast function for printing an integer on a buffer of characters
* using a fixed number of digits. Filling character '0' is used at left.
* The buffer size
* \tparam C the character type
* \tparam I the integer type
* \param buf pointer to the target buffer
* \param cchBuf buffer size; including the null character.
* \param i the source integer to be printed on a buffer
*/
// TODO: sostituire con boost::conversion o boost::spirit
template <class C, class I>
static inline const C *unsigned_integer_to_string ( C* buf, size_t cchBuf, I i )
{
    static const C  s_characters[10] =
    {
        /*'9', '8', '7', '6', '5', '4', '3', '2', '1', */
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'
    };

    C   *psz    =   buf + cchBuf - 1; // Set psz to last char
    *psz = 0;                         // Set terminating null
    do
    {
        unsigned int   lsd = i % 10;    // Get least significant digit
        i /= 10;                        // Prepare for next most significant digit
        --psz;                          // Move back
        *psz = s_characters[lsd];       // Place the digit
    }
    while ( psz!=buf );

    return psz;
}

/**
 * \brief Fast conversion from a string representing a frame number to an unsigned integer
 *
 * \tparam C the character type
 * \tparam I the integer type
 * \param buf pointer to the source buffer
 * \param cchBuf buffer size; including the null character.
 * \param i the target integer to be printed on a buffer
 */
template <class C, class I>
static inline const I& string_to_unsigned_integer( const C* buf, size_t  cchBuf, I& i )
{
    const C* psz = buf + cchBuf - 1; // Set psz to last char
    i=I();                           // Reset the result
    I tmp;                           // temp buffer
    I mul=1;                         // multiplier
    do
    {
        --psz;                          // Move back
        tmp = *psz;
        tmp -= '0';
        tmp *=mul;
        i += tmp;
        mul*=10;
    } while (psz!=buf);

    return i;
}
}

#endif
