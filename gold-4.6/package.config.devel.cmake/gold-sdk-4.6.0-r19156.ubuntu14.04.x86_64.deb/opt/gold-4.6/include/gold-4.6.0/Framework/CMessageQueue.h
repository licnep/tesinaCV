/**
 * @file Framework/CMessageQueue.h
 * \brief Class for managing the recording status
 * \author Paolo Grisleri (grisleri@vislab.it)
 */

#ifndef _CMESSAGEQUEUE_H
#define _CMESSAGEQUEUE_H

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <boost/ptr_container/ptr_map.hpp>
#include <boost/thread.hpp>

#include <Libs/Threads/CTSQueue.hxx>
#include <Framework/CMessage.h>
#include <Framework/gold_msg_bus_export.h>

namespace msgbus
{
/**
 * \brief Message queue for sending and receiving messages
 */
class GOLD_MSG_BUS_EXPORT CMessageQueue
{
    // TODO: mutex for exclusive access?

    vl::thread::CTSQueue<module::CMessage> m_response_queue; ///< Message queue container

public:
    ~CMessageQueue();

    /**
     * \brief Push a message in the queue
     * \params msg The message to be enqueued
     */
    void PushMessage(const module::CMessage& msg);

    /**
     * \brief Pop a message from the queue
     * \params msg The message to be extracted from the queue
     * NOTE: Messages for all modules are dispatched from here.
     * This method can only be called from the Thread waiting on the queue
     * maybe it is more convenient divide it into modules
     */
    void PopMessage(module::CMessage& msg);

    /**
     * \brief Start the dispatching of messages
     * This method is intended is reserved for being called by the engine
     */
    void Dispatch_Start();

    /**
     * \brief Stop the dispatching of messages
     * This method is intended is reserved for being called by the engine
     */
    void Dispatch_Stop();

    /**
     * Type for the callback invoked when a subscribed message is received
     */
	#ifdef USE_BOOST_SIGNAL2
		typedef boost::signals2::signal< void (const module::CMessage&) > SignalType;
	#else
		typedef boost::signal< void (const module::CMessage&) > SignalType;
	#endif

    /**
     * Type for the map associating message IDs to the corresponding callbacks
     */
    typedef boost::ptr_map<module::MessageID, SignalType> SignalMap;

    /**
     * \brief Subscribe a callback for being invoked when a specified MessageID is received
     * \param mdg_id Identifier of the message associated to the specified callback
     * \param slot callback to be invoked when the specified MessageID has been received
     */
    void Subscribe_Message(module::MessageID msg_id, const CMessageQueue::SignalType::slot_type& slot);

    /**
     * \brief Subscribe a callback to be invoked when a message has been received
     * This method register the callback for all messages. A further parsing maybe necessary for
     * determining the message type.
     * \param slot callback to be invoked when a message has been received
     */
    void Subscribe_Messages(const CMessageQueue::SignalType::slot_type& slot) ;

    /**
     * \brief Dispatch a message
     */
    void Dispatch_Message(const module::CMessage& msg);

    /**
     * \brief Thread waiting for message arrivals
     */
    void Thread();
    SignalMap   m_signal_map;   ///< the callback signaler for specific messages
    SignalType  m_signal_all;   ///< the callback signaler for all messages
    boost::thread m_thread;     ///< thread
};

}
#endif // _CMESSAGEQUEUE_H
