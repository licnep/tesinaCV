#ifndef _C_APPLICATION
#define _C_APPLICATION

/**
 * \file CApplication.h
 * \brief Contains the base class for an application.
 * \author Paolo Grisleri e Paolo Medici
 *
 * Example:
 *
 * \code
 *
 * class MyApplication:
 * public:CApplication
 * {
 * protected:
 * void On_Initialization()
 * {
 *  // put initialization code here ...
 * }
 *
 * void On_ShutDown()
 * {
 *  // put shutdown code here ...
 * }
 * void On_Execute
 * {
 *  // put capture data code here ...
 *  // put processing code here ...
 *  // put output code here ...
 * }
 *
 * };
 *
 *  // macro for registering the functionality
 *  REGISTER_FUNCTIONALITY( MyApplication, "MyApp");
 *
 *  \endcode
 *
 * "MyApp" will be the key used for the CLASS_ID parameter in schedule.ini
 *
 **/


#include <Framework/CDeviceManager.h>  // this is included for all the applications
#include <Framework/CModule.h>
#include <Framework/CPathManager.h>
#include <Framework/Synchronizers.h>
#include <Libs/INIFiles/INIFile.h>

#include <string>



 /**
   * @ingroup Framework
   * CApplication base class
   * @{
   **/

/** \brief Namespace containing user stuff */
namespace usr
{

/**
 * \brief Base class for applications
 *
 * This class has to be used as base class for user applications
 * users have to implement three main virtual functions:
 * \code
 *    virtual void On_Initialization()
 *    {
 *    	// user initialization code shall be placed here
 *    	// do not place initialization code in the constructor since
 *    	// some resources could be not available at construction time
 *    }
 * \endcode
 *
 * This method is called after the construction (lazy initialization)
 * and shell contain the initialization procedure
 * The constructor may contains initialization for data members
 * Some resources, such as initialization files, CSession, Transport are available
 * only when the On_Initialization is executed. If these structures are needed for
 * the Application purposes, the code that use them shall be placed in the On_Initialization.
 * The constructor and the destructor are always executed, since every application
 * is instantiated by the scheduler when the session is opened.
 * The code contained in On_Initialization may not be executed during a session,
 * depending on the user commands.
 * \code
 *   virtual void On_ShutDown()
 *   {
 *   	// user deallocation code shall be placed here
 *   	// member variables initialized in the constructor shall be
 *   	// deallocated in the destructor
 *   }
 * \endcode
 *
 * This method is called when the application is closed that is when closing a session before reopening a new one or before exiting.
 * This method shall contains only the destruction code  for objects initialized in the On_Initialization()
 *
 * \code
 *   virtual bool On_Execute ( void )
 *   {
 *   	// processing code shall be placed here
 *   	// this function will be executed from the scheduler
 *   	// depending on the scheduling policy selected
 *   	// for DATA_DRIVEN policy, the execution will be triggered
 *      // when the requested frame is completed
 *      // for PERIODIC policy, the execution will be triggered
 *      // at fixed time intervals
 *
 *      // the function shall return true if everything went fine
 *      // false otherwise
 *
 *   	return true;
 *   }
 * \endcode
 *
 * All the public methods are the application interface used by scheduler.
 *
 * \seealso CModule for other protected methods available for implementation
 *
 **/
class GOLD_FRAMEWORK_EXPORT CApplication  :
            public CModule
{
protected:

    /**
     * \brief User implementable method for initialization code
     */
    virtual void On_Initialization();

    /**
     * \brief User implementable method for destruction code
     */
    virtual void On_ShutDown();

    /**
     * \brief User implementable method for user code execution
     * Processing code shall be placed here. Depending on the scheduling policy
     * This method will be triggered when a new frame has been acquired from the devices (DATA_DRIVEN)
     * or at fixed time intervals (PERIODIC). \seealso CScheduler
     * @return true if everything went fine, false if something went wrong:
     * in this case the application will be disabled from the scheduler
     */
    virtual void On_Execute ();

    /**
     * \brief User implementable method for idle execution
     * This method is called whenever the application is disabled
     */
    virtual void On_Idle ();

    /**
     * \brief User implementable method called whenever the previous frame is loaded
     * This method is called only during a PlayBack Session
     */
    virtual void On_Prev();

    /**
     * \brief User implementable method called whenever the next frame is loaded
     * This method is called only during a PlayBack Session
     */
    virtual void On_Next();

    /**
     * \brief User implementable method called whenever a jump occur
     * This method is called only during a PlayBack Session
     */
    virtual void On_Goto(unsigned long frame);

    /**
     * \brief returns the device manager
     * This method can be used by applications for obtaining a reference to
     * the device manager. The device manager is the object in charge of
     * collecting presenting the available devices to the user through a generic API
     * @return a reference to the dev::CDeviceManager
     */
    dev::CDeviceManager& Dev();

    /**
     * \brief called whenever all the devices have been initialized
     * This method usually do not need to be overwritten since its
     * default action is to link a pointer to the device tree
     * so that Dev() returns the correct reference.
     * However it is provided is provided for users that need to overwrite
     * the custom procedure for specific reasons
     * @param [in] devices dev::CDeviceManager populated with devices initialized so far
     */
    virtual void On_Devices_Share(dev::CDeviceManager& devices);

    /**
     * Deprecated since the identifier is in collision with the class name
     * Please use Options instead;
     * FIXME: for gcc, -fpermissive option is needed to allow this collision
     */
    GOLD_FRAMEWORK_DEPRECATED ::INIFile* INIFile() {
        return m_ini;
    }
    
    /**
     * \brief Access to the options storage
     * Give access to the options stored in a file placed in the right position
     * depending on the usage. If the application is under development, the file 
     * is placed in the development tree. If the application is installed the 
     * file is placed in ~/.config/$PACKAGE_NAME-$VERSION/INI
     * \return a pointer to an INIFile containing the application options
     */    
    ::INIFile* Options() {
        return m_ini;
    }
    

public:

    virtual ~CApplication();

    /**
     * \brief Called from the scheduler to pass the device tree to the application
     * Users can put their custom code in the On_Device_Share method
     * @param [in] devices dev::CDeviceManager to be passed to the application
     */
    virtual void Devices_Share(dev::CDeviceManager& devices);

    /**
     * This is a reserved function, implemented through the DECL_METHODS
     * macro provided for automating the supply of main application paths
     * This method is now deprecated in favor of FillPathManager and SetPath
     */
    GOLD_FRAMEWORK_DEPRECATED virtual const char* SourceINIDir();

    /**
     * This is a reserved function, implemented through the DECL_METHODS
     * macro provided for automating the supply of main application paths
     * This method is now deprecated in favor of FillPathManager and SetPath
     */
    GOLD_FRAMEWORK_DEPRECATED virtual const char* SourceDir();

    /**
     * This is a reserved function, implemented through the DECL_METHODS
     * macro provided for automating the supply of main application paths
     */
    virtual void FillPathManager();

    /**
     * \brief returns the local paths for teh current application
     */
    const CPathManager::PathsMap& Paths() const;

    /**
     * \brief Set a local path for the current application
     * \param [in] name key for the local path
     * \param [in] path path to be stored locally
     */
    void SetPath(const std::string& name, const std::string& path);

    /**
     * \brief replace local paths map with the one supplied
     * \param [in] paths new local path
     */
    void ReplacePaths( const CPathManager::PathsMap& paths);
    
    /**
     * \brief Contains the code for loading the initialization file
     */
    virtual void LoadINI(::INIFile* ini);
    
    /**
     * \brief Supply the synchronizer to the scheduler
     * Synchronyzer is a class provided for simplyfing the user code for capturing data
     * \seealso Synchronizer_Basic
     */
    virtual Synchronizer_Basic* Synchro() { return 0; }

private:

    dev::CDeviceManager* m_pDev;      ///< The Device Tree
    ::INIFile* m_ini_common;       ///< Common Initialization file
    ::INIFile* m_ini;              ///< Local Initialization file
    CPathManager  m_path_manager; ///< Local path manager
};


} // namespace usr
/**@}*/

#endif
