/**
 * \file Framework/Transport.h
 * \brief Abstract classes for representing the playback status
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef TRANSPORT_H
#define TRANSPORT_H

#include <set>
#include <vector>

#include <boost/filesystem/path.hpp>
#include <boost/function.hpp>

#include <Libs/Time/TimeUtils.h>

#include <Framework/CEvent.h>
#include <Framework/Modes.h>

#include <Framework/gold_framework_export.h>

namespace usr
{
/**
 * \brief Abstract class for representing the system framecounter
 *
 * This is the interface designed for the applications to the internal framecounter
 * Users are allowed to check the framecounter value and to convert it automatically to ValueType
 *
 * The framenumber, that is the number of the file that a specific sensor is currently loading
 * is a value provided by the CSampler accessible from each device.
 * @see CSampler
 */
class GOLD_FRAMEWORK_EXPORT FrameCounter
{
public:
	/**
	 * \brief FrameCounter type
	 * Use this type every time you need to declare a variable for containing a framecounter value
	 */
    typedef uint64_t  ValueType;

    /**
     * Return the current framecounter value.
     *
     * Be aware that this value refers to the internal framecounter.
     * The meaning depends on the playback mode selected for the recording.
     * For a recording where a KEY_LESS mode is selected in the HWS file
     * the framecounter is incremented at every frame.
     */
    virtual operator ValueType () const = 0;

    /**
     * Provides an automatic conversion from a FrameCounter to a ValueType
     */
    virtual ValueType operator()() const = 0;
};



/**
 * \brief Abstract classe for representing the playback status
 *
 * This is the interface designed for the applications to the internal Transport
 * All the information about the playback status are accessible using this class.
 */
class GOLD_FRAMEWORK_EXPORT Transport
{
public:
	/** \brief Local Event type for the */
    typedef data::CEvent  EventType;

    /**
     * \brief Type for the notification callback
     *
     * Callback functions subscribed for a certain event shall be of this type
     */
    typedef boost::function< void ( uint64_t, const Transport::EventType& ) > EventNotificationType;


    typedef boost::function< void() > LoopOnFrameType;

    /**
     * \brief Callback function for checking whether a frame is completed or not
     *
     * When no applications are activated, a default fcc is used.
     * Registering its own fcc, an application can say when a frame is completed,
     * controlling the frame transport during next and prev actions.
     */
    typedef boost::function< bool() > FrameCompletedCheckerType;

    /**
     * \brief Callback function for waiting the end of processing from an application
     */
    typedef boost::function< void() > WaitForEndOfProcessingType;

    /**
     * \brief Container for bookmarks
     */
    typedef std::set<FrameCounter::ValueType>   BookmarksType;

    /**
     * \brief Enum for the Transport status
     */
    typedef enum {playback, stop, next, prev, jump} status;

    /**
     * \brief Struct describing a recording segment
     */
    struct RecordingSegment
    {
        const data::CEvent* ev_begin; ///< pointer to the first event of the segment
        const data::CEvent* ev_end;   ///< pointer to the last event of the segment
        vl::chrono::AbsoluteTimeType origin; ///< segment origin
        vl::chrono::TimeType duration; ///< segment duration
    };

    /**
     * \brief Container for segments of the current recording
     */
    typedef std::vector<RecordingSegment> SegmentsType;

    // this is the user part of the TimeLine interface

    /**
     * \brief Path of the current MEF file
     */
    virtual const std::string& Path() const = 0;

    /**
     * \brief Name of the current MEF file
     */
    virtual const std::string& Name() const = 0;

    /**
     * \brief Current playback mode specified in the HWS
     */
    virtual const session::mode::ModeID Mode() const = 0;

    /**
     * \brief Check if the current recording contains events with the specified id
     * \return true if the current recording contains events with the specified id
     * false otherwise
     */
    virtual bool  HasEvents(const std::string& id) const = 0;

    /**
     * \brief Returns a container with the available Event IDs
     * \return a set containing the available Event IDs
     */
    virtual const std::set<std::string>& EventIDs() const = 0;

    /**
     * \brief Returns a reference to the current event
     * \return reference to the current Event
     */
    virtual const EventType& CurrentEvent() const = 0;

    /**
     * \brief Push a new FrameCompletedChecker that will be used by default
     *
     * fcc are managed as a stack, the latest FCC pushed is the one that will be used
     *
     * \param name the name that will be used to identify the FCC
     * \param is_enabled a callback function used to check whether the FCC shall be used or not
     * \param fcc the callback function to be used to check if the current event completes a frame
     */
    virtual void Add_FrameCompletedChecker ( const std::string& name,
            boost::function< bool() > is_enabled,
            FrameCompletedCheckerType fcc
            ) = 0;

    /**
     * \brief Remove an fcc from the stack
     *
     * \param name name of the fcc to be removed
     */
    virtual void Remove_FrameCompletedChecker ( const std::string& name ) = 0;


    /**
     * \brief Push a new WaitForEndOfProcessing (WFEOP) callback function that will be used by default
     *
     * \param name the name that will be used to identify the WFEOP
     * \param is_enabled a callback function used to check whether the WFEOP shall be used or not
     * \param wfeop the callback function to be used to check if the application holding the FCC has ended the processing
     */
    virtual void Add_WaitForEndOfProcessing ( const std::string& name,
            boost::function< bool() > is_enabled,
            WaitForEndOfProcessingType wfeop
                                            ) = 0;

    /**
      * \brief Return the frame counter. Always increasing
      * @return a reference to the framecounter
      */
    virtual const FrameCounter& FrameCounter_() const = 0;

    /**
      * \brief Returns the current frame number. Repeated when looping over the same recording
      * @return the currente framenumber
      */
    virtual uint64_t FrameNumber() const = 0;


    /**
      * \brief Return the current frame number. Repeated when looping over the same recording
      * @return the current framenumber
      */
    virtual uint64_t NumFrames() const = 0;

    /**
      * \brief Return true if the current frame is the first frame of a recording
      * @return true if the current frame is the first frame of a recording
      */
    virtual bool IsFirstFrame() const = 0;

    /**
      * \brief Return true if the current frame is the last frame of a recording
      * @return true if the current frame is the last frame of a recording
      */
    virtual bool IsLastFrame()  const = 0;

    /**
      * \brief Return the absolute time of the recording begin (recording origin)
      * @return the absolute time of the recording begin (recording origin)
      */
    virtual const vl::chrono::AbsoluteTimeType& Origin() const = 0;


    /**
      * \brief Return the number of segments in the current recording
      * @return the number of segments in the current recording
      */
    virtual const SegmentsType& Segments() const = 0;


    /**
      * \brief Return a reference to the RecordingSegment structure describing the current segment
      * @return a reference to the RecordingSegment structure describing the current segment
      */
    virtual const RecordingSegment& CurrentSegment() const = 0;

    /**
      * \brief Return the current segment index
      * @return the current segment index
      */
    virtual uint64_t CurrentSegmentNum() const = 0;


    /**
      * \brief Subscribe the notification of a series of events with a specified identifie
      * \param f the callback to be invoked when an event with ID() == id is reached
      * \param id the Identifier of the events to be subscribed
      * @return true if the required identifier is found
      */
    virtual bool Subscribe_EventNotification ( EventNotificationType f, const std::string& id ) = 0;

    /**
     * \brief Subscribe a callback to be called when the loop on frame flag is checked by the user
     * \param f the function to be called when LOF is checked
     * \return true if the subscription went fine
     */
    virtual bool Subscribe_LoopOnFrame ( LoopOnFrameType f ) = 0;

    /**
     * \brief Returns true when the Loop On Frame (LOF) flag is checked by the user
     * \return true if the LOF flag is checked
     */
    virtual bool LoopOnFrame() const = 0;

    /**
     * \brief Returns true when the Loop On Sequence (LOS) flag is checked by the user
     * \return true if the LOS flag is checked
     */
    virtual bool LoopOnSequence() const = 0;


    /**
     * \brief Returns true when the Obey Physical Time (OPT) flag is checked by the user
     * \return true if the OPT flag is checked
     */
    virtual bool ObeyPhysicalTime() const = 0;


    /**
     * \brief Returns the current speed multiplier used when OPT flag is checked
     *
     * A value of 1.0 indicates the same speed of the recording
     * values between 0.0 and 1.0 indicate a speed slower than the original
     * values between 0.0 and 1.0 indicate a speed faster than the original
     * \return the current speed multiplier
     */
    virtual float Speed() const = 0;
};
  
}


#endif // TRANSPORT_H
