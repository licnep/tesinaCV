/**
 * @file Framework/CPathManager.h
 * @author Paolo Grisleri e Paolo Medici
 * @brief Class implementing a path repository
 **/
#ifndef _PATH_MANAGER_H
#define _PATH_MANAGER_H

#include <string>
#include <vector>
#include <map>

#include <boost/filesystem/path.hpp>
#include <Libs/VarReplacer/VarReplacer.h>
#include <Framework/PathDefs.h>

#include <Framework/gold_framework_export.h>

namespace usr
{

/**
 * \brief Class implementing a path repository
 *
 * This class works as a path repository. Users can store their paths in the repository
 * and retrive them later. The repository can be transferred between components
 * for sharing paths.
 *
 */
class GOLD_FRAMEWORK_EXPORT CPathManager
{
public:
	/** Type for one path */
    typedef boost::filesystem::path PathType;

    /** Type for multiple paths */
    typedef std::vector<PathType> PathsType;

    /** Map for associating a string to an array of paths*/
    typedef std::map<std::string, PathsType > PathsMap;

    /** Constructor */
    CPathManager();

    /** Destructor */
    ~CPathManager();

    /**
     * \brief Register a new set of paths associated with a string key
     *
     *
     * If key is already present in the repository, existing values are replaced
     * Paths can use the variable "$AUTONUMBER" only as leaf
     * If paths="/mnt/data/mypath/$AUTONUMBER" and /mnt/data/mypath exists and is a directory
     * then $AUTONUMBER is replaced with the first 3-digit number available. The autonumbered path is not created.
     * Otherwise the corresponding error is returned
     * \params name the string key for identifying the set of paths
     * \params paths string containing a set of paths separated by {';' ':' ',' ' '}.
     * These characters cannot be used inside the paths
     * All the paths must exists in the current filesystem
     * \return the boost::system::errc::success or the corresponding error
     * {not_a_directory, file_exists, no_such_file_or_directory, invalid_argument}
     */
    boost::system::system_error SetPath(const std::string& name, const std::string& paths);

    /**
     * \brief Merges an existing PathsMap with the current one
     * \param map the PathsMap to be merged
     */
    void Merge(const PathsMap& map);

    /**
     * \brief Remove an existing path
     * \param the key of the existing path do be removed
     */
    void RemovePath(const std::string& name);

    /**
     * \brief Replace the current PathsMap with the argument
     * \param map the PathsMap for replace the current one
     */
    void Replace(const PathsMap& map);

    /**
     * \brief Returns a reference to the internal PathsMap
     */
    const PathsMap& Paths() const;

    /**
     * \brief Returns a reference to the first path associated to key
     */
    const PathType& Path(const std::string& key) const;

    /** 
     * \brief Returns a reference to the list of paths associated to key
     */
    const PathsType& Paths(const std::string& key) const;

    /**
     * \brief Returns a CVarReplacer for substituting the stored paths as variables
     */
    const vl::CVarReplacer&  VarReplacer() const;

    /**
     * \brief Replace the variables contained in the argument with the paths stored internally
     */    
    void ReplaceVars(CPathManager::PathType& path) const;    
    
    /**
     * \brief Replace the variables contained in the argument str with the paths stored internally
     */    
    void ReplaceVars(std::string& str) const;


private:
  
    /**
     * \brief Replace the variables $AUTONUMBER when used as leaf in the paths passed as argument
     * with the first 3-digit number free filename
     * \param name path key, such as OUTPUT_DIR. Used only for error logging
     * @param mp vector of paths that may have "$AUTONUMBER" as leaf
     */
    boost::system::system_error AutoNumber(const std::string& name, PathsType& mp);

    PathsMap       m_paths;
    vl::CVarReplacer   m_var_replacer;
    PathType       m_empty_path;      
    PathsType      m_empty_paths;
};

} // namespace usr


namespace vl
{
/** \brief Namespace with classes and function for working with filesystem and not available in boost::filesystem */
namespace filesystem
{
/**
 * Risolve i link simbolici
 */
GOLD_FRAMEWORK_EXPORT void Resolve_SymLinks ( boost::filesystem::path& _path );


/**
 * Copia un file. FIXME: boost non linka con c++0x attivato
 */
GOLD_FRAMEWORK_EXPORT void Copy_File( const boost::filesystem::path& from, const boost::filesystem::path& to );

} // namespace filesystem
} // namespace vl


#endif // _PATH_MANAGER_H
