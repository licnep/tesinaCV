/**
 * @file HWS_Version.h
 * @author Paolo Grisleri
 * @brief Provides an enumerator for versioning the Hardware Setup File (HWS)
 **/

#ifndef HWS_VERSION
#define HWS_VERSION


/**
 * \brief namespaces for Hardware Setup File (HWS) related stuff
 */
namespace hws
{
/**
 *  \brief Enumerator for versioning the Hardware Setup File (HWS)
 */
typedef enum
{
    V_1_0,
    V_1_1
} Version;
}

#endif
