/**
 * @file PathDefs.h
 * @author Paolo Grisleri
 * @brief Definitions for the common paths
 **/

#ifndef PATH_DEFS
#define PATH_DEFS

// String identifiers definitions for system wide paths

/**
 * \brief Absolute path of the executable
 *
 * Maybe different from the installation dir, when using a development tree
 */
#define BASE_DIR        "BASE_DIR"

/**
 *\brief Absolute path where the executable has been installed
 */
#define INST_DIR        "INST_DIR"

/**
 * \brief Absolute path of the user configuration directory
 *
 * The value of this path is platform depending
 * - linux, $HOME is defined (running from user): $HOME/".config"/PACKAGE_NAME_VERSION
 * - linux, $HOME not defined (running as service): "/etc"/PACKAGE_NAME_VERSION;
 * - win32: %HOMEDRIVE%%HOMEPATH%/"AppData/Local"/PACKAGE_NAME_VERSION
 */
#define USR_DIR         "USR_DIR"

/**
 * \brief Absolute path of the current working directory
 *
 * This path is different from the BASE_DIR which is the location of the executable
 */
#define RUN_DIR         "RUN_DIR"

/**
 * \brief Absolute path of the binaries
 */
#define BIN_DIR         "BIN_DIR"

/**
 * \brief Absolute path of the libraries root directory
 */
#define LIB_DIR         "LIB_DIR"

/**
 * \brief Absolute path of the engine library
 */
#define LIB_ENGINE_DIR  "LIB_ENGINE_DIR"

/**
 * \brief Absolute path of the Drivers Development Kit (DDK) library
 */
#define LIB_DDK_DIR     "LIB_DDK_DIR"

/**
 * \brief Absolute path of the Drivers
 */
#define LIB_DRV_DIR     "LIB_DRV_DIR"

/**
 * \brief Absolute path of the Plugins, including applications and Camera Plugins
 */
#define LIB_PLUGINS_DIR "LIB_PLUGINS_DIR"

/**
 *
 */
#define LIB_RUNTIME_DIR "LIB_RUNTIME_DIR"

/**
 * \brief Absolute path of the user Plugins, including applications and Camera Plugins
 *
 * User plugins directory contains plugins under development or installed from a user
 * when gold is installed.
 */
#define DEV_PLUGINS_DIR "DEV_PLUGINS_DIR"

/**
 * \brief Absolute path of the directory containing the scripts
 */
#define SBIN_DIR        "SCRIPT_DIR"

/**
 * \brief Absolute path of the root directory containing data
 */
#define DATA_DIR        "DATA_DIR"

/**
 * \brief Absolute path of the directory containing the configuration files
 */
#define CONF_DIR        "CONFIGURATION_DIR"

/**
 * \brief Absolute path of the directory containing the HWS file
 */
#define HWS_DIR         "HWS_DIR"

/**
 * \brief Absolute path of the directory containing the current recording (playback mode only)
 */
#define INPUT_DIR       "INPUT_DIR"

/**
 * \brief Absolute path of the directories where the recording will be saved (hardware mode only)
 */
#define OUTPUT_DIRS     "OUTPUT_DIRS"

/**
 * \brief Absolute path of the temporary directory
 */
#define TMP_DIR         "TMP_DIR"

#endif // PATH_DEFS
