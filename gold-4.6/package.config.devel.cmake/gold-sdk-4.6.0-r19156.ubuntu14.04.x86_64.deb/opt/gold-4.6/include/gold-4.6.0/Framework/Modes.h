/**
 * @file Modes.h
 * @author Paolo Grisleri
 * @brief Available modes for a session
 **/

#ifndef _MODES_H
#define _MODES_H

#ifdef WIN32
#undef KEY_EVENT
#endif

/** \brief Namespace including session related stuff */
namespace session
{
/** \brief Available session modes */
namespace mode
{

/**
 * \brief Defines the available modes for a session
 *
 * Two main modes are available.
 * <b>Hardware</b>. In this mode only drivers for hardware device can be used. This mode is used on real systems.
 * Recording from this mode generates files that can be played back later.
 * <b>Playback</b>. In this mode only playback drivers can be used. This mode is used for playing back
 * previously recorded files. Recording from this mode is useful for converting data to a different format.
 *
 * The current mode can be retrived using the CSession object.
 *
 * \see CSession
 *
 * FIXME: windows defines a KEY_EVENT macro which is in conflict with the definition in this file KEY
 * event is now deprecated, and the macro is temporarily undefined
 */
typedef enum
{
    HARDWARE  =  0, ///< The system is running on real hardware: always forward in time
    PLAYBACK  =  1, ///< The system is playing back a prerecorded sequence: time can move back and forth
    NO_INDEX  = PLAYBACK|16, ///< \deprecated Playback mode without index
    KEY_EVENT = PLAYBACK|32, ///< \deprecated Playback mode with index, keyframes taken on events of a specific type
    KEY_TIME  = PLAYBACK|64, ///< \deprecated Playback mode with index, keyframes generated at a specific distance in time
    KEY_LESS  = PLAYBACK|128 ///< Playback mode with index, every event is a keyframe
}ModeID;

//namespace mode
//{
//	class HARDWARE{};
//	class PLAYBACK{};
//	class NO_INDEX : public PLAYBACK{};
//	class KEY_EVENT_: public PLAYBACK{};
//	class KEY_TIME : public PLAYBACK{};
//}

} // namespace mode
} // namespace session


#endif

