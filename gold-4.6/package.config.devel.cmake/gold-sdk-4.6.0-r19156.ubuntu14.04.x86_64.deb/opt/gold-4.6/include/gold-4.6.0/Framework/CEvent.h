/**
 * \file CEvent.h
 * \brief Class modeling an event generated from a device
 * \author Paolo Grisleri (grisleri@ce.unipr.it)
 */

#ifndef _CTEVENT_H
#define _CTEVENT_H

#include <boost/date_time/posix_time/posix_time_types.hpp>
#include <boost/serialization/split_member.hpp>

#include <Framework/gold_framework_export.h>

/**
 * \addtogroup GRP_MEF_FILE_FORMAT
 * @{
 * \section SECTION_MEF_FILE_FORMAT_EVENT Event
 * An event is a database record, containing three fields:
 * - <b>Key</b>. The key is a timestamp, expressed as HHHH:MM:SS.USECS.
 * - <b>ID</b>. A string identifying the event source. The identifier is the name of the sensor generating the sample represented by the event.
 * a shorter name allow a shorter loading time, this should be considered when using sequences with large amounts of events.
 * - <b>FrameNumber</b>. This unsigned integer represent the number of frame to be used for the specific event represented by the record.
 * A dedicated field is needed since recorded framenumbers may be not sequential and may not start from zero.
 * - <b>Data</b>. Depending on the sensor type, data maybe present or not. When data is present, is a
 * string representing the sample captured during the recording. The format of this string is sensor-specific.
 *
 * \see CEvent
 * @}
 */

namespace data
{
//   namespace serialization
//  {
    
/**
 * \brief Class modeling an event generated from a device
 *
 * Events are used for Recording an Playback functions.
 * A system device generates an event when a data is received from a driver.
 * Events are stored by the CEventWriter in a MEF database during recording.
 *
 * \see TimeLine, CRecorder, CDiskWriter
 *
 * An event is a record of containing the following fields:
 * \see GRP_MEF_FILE_FORMAT
 */

class GOLD_FRAMEWORK_EXPORT CEvent
{
public:
    typedef boost::posix_time::time_duration KeyType;
    typedef std::string ObjType;

    static uint64_t FrameNumber_Invalid();

    /// Costruttore di default per un evento vuoto (Key=Default, ID=Data="")
    CEvent();

    /// Costruttore da una stringa
    /// NOTE: Event manager deve capire la versione del MEF e se è vecchio crea la conversione
    CEvent ( const std::string& str );

    /// Costruttore per un evento diretto
    CEvent ( KeyType Key, const std::string& id, uint64_t frame_number=FrameNumber_Invalid(), const ObjType &Data="" );

    // Distruttore
    ~CEvent();

    void SetFrameNumber ( uint64_t frame_number );

    /// @name Metodi di accesso ai dati
    /// Recupera il TimeStamp dell'Evento
    const KeyType& Key ( void ) const;

    /// Recupera l'Identificativo dell'Evento
    const std::string& ID ( void ) const;

    /// ritorna il numero di frame associato all'evento
    uint64_t FrameNumber() const;

    /// Recupera i Dati dell'Evento
    const std::string& Data ( void ) const;

    std::size_t Size() const;
    // TODO da usare nel diskwriter unsigned long WrittenSize() const {return sizeof(m_key)+m_id.size()+sizeof(m_frame_number)+m_data.size();}

    /// Cast
    operator std::string () const;

    /// @name Metodi per I/O delle stringhe su file
    /// Riempie la stringa con i dati dell'evento
    const std::string& GetString ( std::string& Str ) const;

    /// Assegna l'oggetto corrente usando la str
    void operator = ( const std::string& Str );

    /// Operatore di confronto tra due eventi: Ritorna true se il this.TimeStamp < Event.TimeStamp
    bool operator < ( const CEvent &Event ) const;
    
    /// Operatore di confronto tra due eventi: Ritorna true se il this.TimeStamp <= Event.TimeStamp
    bool operator <= ( const CEvent &Event ) const;
    
    /// Operatore di confronto tra due eventi: Ritorna true se il this.TimeStamp > Event.TimeStamp
    bool operator > ( const CEvent &Event ) const;
    
    /// Operatore di confronto tra due eventi: Ritorna true se il this.TimeStamp >= Event.TimeStamp
    bool operator >= ( const CEvent &Event ) const;
    
    /// Operatore di confronto tra due eventi: Ritorna true se il this.ID == Event.ID
    bool operator == ( const CEvent &Event ) const;
    /*@{*/

    // stream operators
    friend GOLD_FRAMEWORK_EXPORT std::ostream & operator << ( std::ostream &ostr, const CEvent& event );

    template<class Archive>
    void save(Archive & ar, const unsigned int version) const;

    template<class Archive>
    void load(Archive & ar, const unsigned int version);

    BOOST_SERIALIZATION_SPLIT_MEMBER()

    static void SetFrameCounterWidth(unsigned int w);

private:
    static unsigned int m_framecounter_width;

    KeyType   m_key;       ///< Event Key
    std::string m_id;      ///< Event Identifier
    unsigned long m_frame_number;///< FrameNumber
    std::string m_data; ///< Event Data

    ///< Update internal string cache from data
    const std::string& ToString ( std::string& str ) const;

    ///< Change the internal data according with the string
    void  FromString ( const std::string& str );
};


// Functor per il confronto della key
template <typename T>
class is_key_eq
{
    typename T::KeyType m_key;
public:
    is_key_eq ( const typename T::KeyType& key ) : m_key ( key ) {}
    bool operator () ( const T* event ) const {
        return event->Key() == m_key;
    }
    // bool operator () ( T* event ) const { return event->Key() == m_key; }
};

template <typename T>
bool compare_keys ( const T* event1, const T* event2 ) {
    return event1->Key() == event2->Key();
}


// Functor per il confronto dell'ID
template <typename T>
class is_id_eq :
            public std::unary_function<const T*, bool>
{
    std::string m_id;
public:
    is_id_eq ( const std::string& id ) : m_id ( id ) {}
    bool operator () ( const T* event ) const {
        return event->ID() == m_id;
    }
};

typedef boost::shared_ptr<CEvent> spEventType;


//   } // namespace serialization
} // namespace data

#endif
