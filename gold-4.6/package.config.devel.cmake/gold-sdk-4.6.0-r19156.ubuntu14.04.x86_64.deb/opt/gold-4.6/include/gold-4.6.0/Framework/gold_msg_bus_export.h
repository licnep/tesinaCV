
#ifndef GOLD_MSG_BUS_EXPORT_H
#define GOLD_MSG_BUS_EXPORT_H

#ifdef GOLD_MSG_BUS_STATIC_DEFINE
#  define GOLD_MSG_BUS_EXPORT
#  define GOLD_MSG_BUS_NO_EXPORT
#else
#  ifndef GOLD_MSG_BUS_EXPORT
#    ifdef gold_msg_bus_EXPORTS
        /* We are building this library */
#      define GOLD_MSG_BUS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define GOLD_MSG_BUS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef GOLD_MSG_BUS_NO_EXPORT
#    define GOLD_MSG_BUS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef GOLD_MSG_BUS_DEPRECATED
#  define GOLD_MSG_BUS_DEPRECATED __attribute__ ((__deprecated__))
#  define GOLD_MSG_BUS_DEPRECATED_EXPORT GOLD_MSG_BUS_EXPORT __attribute__ ((__deprecated__))
#  define GOLD_MSG_BUS_DEPRECATED_NO_EXPORT GOLD_MSG_BUS_NO_EXPORT __attribute__ ((__deprecated__))
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define GOLD_MSG_BUS_NO_DEPRECATED
#endif

#endif
