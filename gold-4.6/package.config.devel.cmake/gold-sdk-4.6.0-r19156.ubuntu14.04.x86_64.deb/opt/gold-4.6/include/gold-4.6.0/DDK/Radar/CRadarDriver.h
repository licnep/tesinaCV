#ifndef _CRADAR_MODULE
#define _CRADAR_MODULE

/** \file CRadarDriver.h
 *  \brief File per la classe CDriver_Radar
 *  \author Luca Gatti \<lucag@ce.unipr.it\>
 **/

#include <DDK/Driver.h>

namespace dev { class CRadar; }

namespace ddk
{
  class CSystemRadar;

  class GOLD_DDK_EXPORT CDriver_Radar :   
    public ddk::CDriver
  {
  public:
    CDriver_Radar(ddk::impl::CDriverInitializer& DrvInit);
    ~CDriver_Radar();

  protected:
    
    virtual DeviceDescriptor ConcreteDevice_Create( ddk::impl::CDeviceInitializer& dev_descr );
    void Register_Device(CSystemRadar& dev);  // NOTE; anche private

  private:

  };

} // namespace ddk


#endif // _CRADAR_MODULE
