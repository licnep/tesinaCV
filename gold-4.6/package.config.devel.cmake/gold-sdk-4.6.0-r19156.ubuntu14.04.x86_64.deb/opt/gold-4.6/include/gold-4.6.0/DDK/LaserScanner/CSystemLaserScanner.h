#ifndef _CSYSTEMLASERSCANNER_H
#define _CSYSTEMLASERSCANNER_H


#include <Devices/LaserScanner/CLaserScanner.h>
#include <DDK/CSystemDevice.h>

#include <UI/CWindows/CWindow.h>

#include <DDK/gold_ddk_export.h>

using data::CScan;
using data::CScanEcho;

namespace ddk
{
class GOLD_DDK_EXPORT CSystemLaserScanner :
      public dev::CLaserScanner,
      public ddk::Device
{
  public:
    typedef CLaserScanner DeviceType;

    CSystemLaserScanner();
    virtual ~CSystemLaserScanner();
    
  protected:
    
    virtual void On_Initialization();
    virtual void On_ShutDown();

    const char* DefaultFileFormat() { return ".txt"; }

    void FrameUpdate( FrameType::DataType& data, const vl::chrono::TimeType& TimeStamp );
    
    void Preprocessing(FrameType& Frame);

    virtual const CLaserScanner::PulsesColorType& PulsesColor();

    ui::wgt::Widget panel; // pannello
    
  private:
    void On_LoadParams( INIFile& ini, hws::Version version );
    void On_SaveParams( INIFile& ini );    
    void Recording_SaveParams ( INIFile& ini );
    
    // TODO: nel pannello
    void UI_Refresh( const FrameType& frame );
    void View_Draw_Background();    
        
    /** 
     * Record the current busy frame
     */
    void FrameRecording( const FrameType& frame );
    
    // New user interface stuff
    void On_ToggleWnd_Action();

    // Display stuff
    // visible area in the bird eye view
    static double Top()    { return 50.0; }
    static double Left()   { return 50.0; }
    static double Bottom() { return -10.0; }
    static double Right()  { return -50.0; }

    static double Zoom()   { return 1.0; } ///< zoom factor: 1 [meter] = Zoom() [pixels]

    static unsigned int DisplayW() { return static_cast<unsigned int> ( Zoom() * ( Left()-Right() )-0.5 ) +1; }
    static unsigned int DisplayH() { return static_cast<unsigned int> ( Zoom() * ( Top()-Bottom() )-0.5 ) +1; }

    static double label_offset() { return 0.1; }    
      
    boost::shared_ptr<ui::win::CWindow> m_spWindow;
    
    FrameType  m_src_frame;
    FrameType  m_out_frame;
        
    data::TransformationType R;        

    static double m_PulseSemiSize;

    static std::vector<double> m_Markers;
    static std::vector<std::string> m_MarkersStr;
};
  
}


#endif
