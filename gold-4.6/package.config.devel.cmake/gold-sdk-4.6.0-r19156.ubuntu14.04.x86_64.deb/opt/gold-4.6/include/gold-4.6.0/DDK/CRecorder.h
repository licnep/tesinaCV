#ifndef _CRECORDER_H
#define _CRECORDER_H

#include <map>
#include <boost/property_tree/ptree_fwd.hpp>

#include <DDK/gold_ddk_export.h>
#include <Libs/Time/TimeUtils.h>
#include <Framework/CRecordingCtl.h>
#include <Framework/CEvent.h>
#include <Framework/FrameNumberUtils.h>

#include <Devices/CDiskWriter/CDiskWriter.h>
#include <Devices/CDiskWriter/CEventWriter.h>
#include <DDK/CPlayBackUtils.h>

#include<Data/Base/FormatsEnumerator.h>




namespace dev {class CDiskWriter;}
namespace data { class CEvent; class CEventWriter; }
namespace vl{ namespace ini {class INIFile;} } using vl::ini::INIFile;
namespace usr 
{ 
  class CRecordingCtl;  
  class CSession;  // serve per l'espansione delle variabili  
}


namespace ddk
{

namespace params
{
namespace recorder
{
GOLD_DDK_EXPORT const char* FileName();
}
}


class GOLD_DDK_EXPORT CRecorder
{
public:
    CRecorder();
    ~CRecorder() {}

    // TODO: va fatta quando anche l'EM è stato inizializzato
    // in alternativa si può creare e leggere l'indice qui dentro
    void Initialize( const usr::CRecordingCtl& rc );

    void Enable()  {
        m_is_enabled=true;
    }
    void Disable() {
        m_is_enabled=false;
    }

    INIFile* INI() {
        return m_pINI;
    }

    bool IsEnabled() {
        return m_is_enabled;
    }

    // TODO: protected
    void LoadParams ( INIFile& ini );
    void SaveParams ( INIFile& ini );

// protected:
    /**
     * Assegna il nome della traccia. Va chiamato prima di RegisterTrack
     * @param track_name stringa con il nome della traccia
     */
    void SetTrackName(const std::string& track_name);

    /**
     * Assegna le informazioni sui formati per un certo tipo di dato.
     * Ad esempio le immagini si possono salvare in diversi formati, ciascuno dei quali ha
     * proprie estensioni, parametri e altre caratteristiche.
     * Questo metodo permette al recorder di vedere le informazioni sul set di formati supportati
     * va chiamata prima di RegisterTrack
     * @param fmt_metadata vector\<data::FormatDescriptor\> contenente i formati supportati. Questo dato
     * viene letto dal FormatEnumerator specifico per un certo tipo di dato
     */
    void SetSerializationInfo(const std::vector<data::FormatDescriptor>& fmt_metadata);

    /**
     * Assegna al recorder un nome e formato di default in cui salvare i dati 
     * nel caso in cui l'utente non specifichi niente
     * @param name striga contenente il nome di default da usare
     * @param format stringa contenente il formato di default da usare
     * viene letto dal FormatEnumerator specifico per un certo tipo di dato
     */    
    void SetDefaultNameAndFormat(const std::string& name, const std::string& format)
    {
        m_filename=name+format;
    }

    typedef boost::property_tree::ptree OptionsType;

    const std::string& FileName() const {
        return m_filename;
    }
    // TODO: far tornare a CSession un percorso ciclico tra OPaths
    // Es get_free_path() che ritorna prima OPaths()[0], poi OPaths()[1] ... ecc
    const std::string& OPath() const {
        return m_path;
    }
    const std::string& Stem() const  {
        return m_stem;
    }
    const std::string& Extension() const {
        return m_ext;
    }

    const boost::property_tree::ptree& Options() const {
        return m_pt_options;
    }

    const std::string& TrackName() const {
        return m_track_name;
    }


    /**
     * Template Method to call the Write after performing common operations
     * such as check Recording is enabled
     * This method is called by the concrete sensor acquisition thread
     * when a new object has been acquired and can be recorded on disk
     */
    void Rec_Direct ( const data::CEvent& Event );
    void Rec_Frame ( dev::spCWritableType Object, uint8_t track_id = 0xff );


    unsigned long Written() const {
        return m_write_completed;
    }
    unsigned long Dropped() const {
        return m_write_requested-m_write_completed;
    }

    /// Questi metodi servono per accedere allo stato della registrazione che è già modellato in CModule
    const usr::CRecordingCtl& RecordingCtl() const {
        return *m_recording_ctl;
    }
    virtual void On_Recording_Create();
    virtual void On_Recording_Destroy();


    data::CEventWriter& EventWriter();
    dev::CDiskWriter& DiskWriter();

    uint64_t Written() {
        return m_write_completed;
    }

    uint64_t Dropped() {
        return m_write_requested-m_write_completed;
    }

    dev::CDiskWriter::ContainerType ContainerType() const {
        return m_container_type;
    }


private:

    void Clear();

    void RegisterTrack();

    INIFile* m_pINI;   // sezione per le opzioni di registrazione
    

    // questo è lo stato della registrazione, si trova già in CModule
    bool m_is_enabled;

    const usr::CRecordingCtl* m_recording_ctl;

    std::string   m_track_name;

    std::string   m_path;
    std::string   m_container;
    std::string   m_filename;      ///< The Location where to write the data (variables NOT expanded)
    std::string   m_stem;
    std::string   m_ext;
    std::string   m_ser_format;
    std::string   m_ser_options;
    std::string   m_mtd_format;    
    std::vector<std::string> m_metadata;    

    vla::Track::SignatureType m_signature_type;

    dev::CDiskWriter::ContainerType m_container_type;

    OptionsType   m_pt_options;  ///< Recording options

    uint64_t m_write_requested;   ///< Counter for requested write data
    uint64_t m_write_completed;   ///< Counter for succesfully write data

    // TODO: rimuovere il vincolo >=1.0: se skip = 0.3 ne salta una ogni 4
    float         m_skip;              ///< Request to be ignored
    float         m_skip_counter;       ///< Counter for skip

    char m_expanded_framecounter[FRAMENUMBER_MAX_WIDTH];
    uint8_t       m_track_handle;
};


} // namespace ddk

#endif
