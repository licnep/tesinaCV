#ifndef _TRIGGER_FACTORY_H
#define _TRIGGER_FACTORY_H

#include <Framework/CModule.h>
#include "CSystemTrigger.h"

#include <Libs/Patterns/Singleton.h>
#include <Libs/Patterns/Factory.h>

namespace ddk
{
  
// tipo per la factory a singleton
typedef  vl::Factory<std::string, CSystemTrigger> CTriggerFactoryType;

#define REGISTER_TRIGGER(CLASS,STRNAME) vl::ObjectRegistrar< ddk::CTriggerFactoryType, CLASS > drf_##CLASS(STRNAME)

}

#endif
