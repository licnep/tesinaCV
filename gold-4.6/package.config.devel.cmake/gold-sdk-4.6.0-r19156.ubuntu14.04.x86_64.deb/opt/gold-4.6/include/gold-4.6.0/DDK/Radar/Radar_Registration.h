/** \file Radar_Registration.h
 *  \brief File per la classe CRadar_FactoryRegister
 *  \author Luca Gatti \<lucag@ce.unipr.it\>
 **/

#ifndef __CRADAR_REGISTRATION
#define __CRADAR_REGISTRATION

#include <Libs/Patterns/Singleton.h>
#include <Libs/Patterns/Factory.h>

#include "CSystemRadar.h"

namespace ddk
{
  
/** Registration stuff **/
// tipo per la factory a singleton
typedef vl::Factory<std::string, CSystemRadar> CRadarFactoryType;

#define REGISTER_RADAR(CLASS,STRNAME) vl::ObjectRegistrar< ddk::CRadarFactoryType, CLASS > drf_##CLASS(STRNAME)

} // namespace ddk
  
#endif // __CRADAR_REGISTRATION
