#ifndef _WRITABLE_CSCAN_H
#define _WRITABLE_CSCAN_H

#include <Data/CScan/CScan.h>
#include <Data/CScan/CScanSerialization.h>
#include <Devices/CDiskWriter/CWritable.h>
// #include <Libs/Logger/Log.h>

namespace data { class CEvent; }

using data::CScan;

namespace dev
{
  

// specializzazione di TWritable per CScan
template <>
class TWritable<CScan> :
      public CWritable
{
  public:
    typedef CScan ObjType;

    TWritable ( boost::shared_ptr<data::CEvent> Event, const std::string& Location, boost::shared_ptr<CScan> Object ) :
        CWritable ( Event, Location ),
        m_object ( Object )
    {}

    virtual ~TWritable() {}
    
    virtual void Destroy_Payload()
    {
       // std::cout << " Destroy_Payload " << m_object->UseCount() << std::endl;
       m_object.reset();
    };    

    virtual uint64_t Size() const
    {
      // TODO: calcolare dimensione
      return sizeof(CScan);
    }

    virtual uint64_t Save() const
    {
      return data::cscan::serialization::Save ( *m_object, Location() );
    }
    
    virtual void Save(std::ostream& ostr) const
    {
      data::cscan::serialization::Save(*m_object, ostr, data::cscan::serialization::BIN /*m_format*/, boost::property_tree::ptree()/*m_options*/);
    }     
    
    virtual void Save_Metadata(std::ostream& ostr) const
    {
      // TODO embed a property_tree in the csca
    }    

    const ObjType operator() () const { return *m_object; }

  private:
    boost::shared_ptr<CScan> m_object;
};

} // namespace dev

#endif // _WRITABLE_CSCAN_H
