/**
 * \file TimeLine.h
 * \brief Class for collecting the events when playing back a recording
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */
#ifndef _TIMELINE_H
#define _TIMELINE_H


#include <string>
#include <vector>
#include <set>

#include <boost/function.hpp>
#include <boost/system/error_code.hpp>
#include <boost/filesystem/path.hpp>

#include <DDK/gold_ddk_export.h>

#include <Libs/Time/Accumulator.h>

#include <Framework/Modes.h>
#include <Framework/CEvent.h>

namespace sys
{

/**
 * @addtogroup GRP_MEF_FILE_FORMAT MEF File Format
 * \brief Description of the MEF file format
 *
 * @{
 * \page MEF_File_Format
 * \section MEF_File_Format_Description Description
 * MEF, acronym for Master Event File, is a file containing information on events recorded from a fixed setup.
 * An header is placed at the head of the file containing the file version and global information.
 *
 * A list of events follows the header. The list can be specified using statements or explicitly, using
 * raw event serialization format.
 * Devices such as can adapters can for example dump the CAN message, or Radars can dump the list of detected objects.
 * When data is not present, the sensor can be a synchronization only sensor, such as a trigger,
 * or a sensor producing samples containing a large amount of data, such as cameras. In the latter case, the framenumber field is
 * used to reconstruct the name of the file containing the recorded sample.
 * Two events of the same type cannot have the same timestamp.
 *
 * Several recording segments are allowed in the same recording, segments maybe separated in time.
 * At least one segment is present in each recording
 * Events in the same segment are contiguous.
 *
 * A typical MEF file looks like the example below
 *
 * \code
 * VisLab MEF 20
 * 0000:00:00.000000               ORIGIN          000000                  20101003T184039.963908
 * 0000:00:00.000000               SEG_BEGIN       000000                  20101003T184053.111711
 * 0000:00:00.010744               CHASSIS         000000                  0430 0 8 04 a4 00 13 04 04 00 00
 * 0000:00:00.010948               CHASSIS         000001                  03f2 0 8 ff 00 00 80 ff 7f ff 7f
 * 0000:00:00.010990               CHASSIS         000002                  03f2 0 8 ff 00 00 80 ff 7f ff 7f
 * 0000:00:00.011028               CHASSIS         000003                  03f2 0 8 ff 00 00 80 ff 7f ff 7f
 * 0000:00:00.011068               CHASSIS         000004                  0602 0 8 17 00 5a 08 f9 ff 10 00
 * 0000:00:00.011111               CHASSIS         000005                  03f2 0 8 ff 00 00 80 ff 7f ff 7f
 * 0000:00:00.011394               CHASSIS         000006                  03f2 0 8 ff 00 00 80 ff 7f ff 7f
 * 0000:00:00.022665               CHASSIS         000007                  03f2 0 8 ff 00 00 80 ff 7f ff 7f
 * 0000:00:00.022707               CHASSIS         000008                  0440 0 8 00 00 23 00 ff 00 00 00
 * 0000:00:00.022760               CHASSIS         000009                  0316 0 8 35 3c 34 15 3c 14 23 82
 * 0000:00:00.022806               CHASSIS         000010                  0260 0 8 0b 00 3d 00 00 a3 00 00
 * 0000:00:00.022850               CHASSIS         000011                  02a0 0 8 00 00 60 1b a9 02 46 00
 * 0000:00:00.022891               CHASSIS         000012                  02b0 0 8 7b ff 00 07 0b 00 d8 7e
 * 0000:00:00.022956               CHASSIS         000013                  0329 0 8 40 b6 81 10 11 2a 12 18
 * 0000:00:00.022997               CHASSIS         000014                  03f2 0 8 ff 00 00 80 ff 7f ff 7f
 * 0000:00:00.023034               CHASSIS         000015                  043f 0 8 03 45 40 ff 6a 70 11 00
 * 0000:00:00.023079               CHASSIS         000016                  03f2 0 8 ff 00 00 80 ff 7f ff 7f
 * 0000:00:00.023116               CHASSIS         000017                  0545 0 8 e0 ac 00 89 00 00 00 00
 * 0000:00:00.023156               CHASSIS         000018                  03f2 0 8 ff 00 00 80 ff 7f ff 7f
 * 0000:00:00.023193               CHASSIS         000019                  03f2 0 8 ff 00 00 80 ff 7f ff 7f
 * 0000:00:00.023232               CHASSIS         000020                  03f2 0 8 ff 00 00 80 ff 7f ff 7f
 * 0000:00:00.023269               CHASSIS         000021                  03f2 0 8 ff 00 00 80 ff 7f ff 7f
 * 0000:09:57.321006               SEG_END         000001                  20101003T185050.432717
 * \endcode
 *
 *
 * \section MEF_File_Format_Header Header
 *
 * This is a description of the MEF header format
 *
 * \subsection MEF_File_Format_Header_Version Header version
 * The first line of the  MEF file contains the version number and looks like the following
 *
 * \code
 * VisLab MEF 20
 * ...
 * \endcode
 *
 * \subsection MEF_File_Format_Data_Declare declare statement
 * The following syntax allow to declare a series of events related to a certain source.
 *
 * \code
 * declare name=C, num=111847, start=0000:00:00.000000, period=0:0:0.001
 * \endcode
 *
 * The line above declares 111847 for the source C starting from time 0000:00:00.000000 separated by 1ms each
 * This statement is useful for building events file for recording taken with other softwares or when using
 * image sequences downloaded from a site.
 *
 * \subsection MEF_File_Format_Data_Import import statement
 *
 * The following syntax allow to import events direclty from an avi file.
 * \code
 * import name=CAM, file=avifilename.avi, start=00:00:00
 * \endcode
 * Images are associated to a sensor called CAM, and the timestamp of the first image will be 0000:00:00.000000.
 * Events will be spaced by a quantity of time obtained by the avi framerate.
 *
 * \subsection MEF_File_Format_Data_Raw Raw events
 * When playing back data recorded with gold, events are expressed in the raw form, which have the following syntax
 * \code
 * 0000:00:00.010744               CHASSIS         000000                  0430 0 8 04 a4 00 13 04 04 00 00
 * HHHH:MM:SS.UUUUUU              \tID           \tFRAMENUM              \tDATA...
 * |               |              |              |                       | ...
 * 0              17             31             47                      71 ...
 * \endcode
 *
 * \section MEF_File_Format_Specials Special events
 * - <b>ORIGIN</b>. This special event is present at the beginning of a recording. The framenumber is always 0.
 * The DATA field contains an absolute timestamp with the UTC time of the begin of the recording.
 * - <b>SEG_BEGIN/SEG_END</b> This two special event indicates a segment, respectively the begin and the end of a segment.
 * These two events are always present since in a MEF, several segments are allowed.
 * Each event contains in the Data field an absolute timestamp with the UTC time of the begin or the end of the segment.
 * This is a \ref Event "Even link"
 * @}
 */



/**
 * \brief Class for loading the event database of a recording
 *
 * This class provides high level access methods for loading and indexing events of a recording
 * using one of the supported modes. KEY_LESS mode is supported and will be fully supported in the future.
 * Currently the KEY_FRAME and KEY_TIME mode are deprecated.
 * Application can inspect the index but they are not allowed to open or close a timeline: this is done by the engine
 */
class GOLD_DDK_EXPORT TimeLine
{
public:
	/**
	 * \brief Local type for the event class
	 */
    typedef data::CEvent EventType;

    /**
     * \brief Type for a query on the events database
     */
    typedef std::vector<const EventType*> ConstSliceType;

    /**
     * \brief Constructor
     */
    TimeLine();

    /**
     * \brief Destructor
     */
    ~TimeLine();

    /**
     * \brief Open an event database. This method shall not be called from applications
     * @param events_filename Index File containing Event sequence
     * @param mode Access Type: NONE
     * @param options map with the options
     * @param hws hws configuration file
     */
    boost::system::error_code Open( const std::string& events_filename,
                  session::mode::ModeID mode,
                  const std::map<std::string, std::string>& options,
                  const boost::filesystem::path& hws );

    /**
     * Checks if an event af specified type is present or not
     * @param ID Event to be checked
     * @return true if the event is available, false if not.
     */
    bool HasEvents ( const std::string& id ) const {
        return m_ids.find ( id ) != m_ids.end();
    }

    /**
     * \brief return the total number of frames
     * @return the total number of frames available in the index
     */
    uint64_t GetFrameNo() const {
        return static_cast<uint64_t>(m_key_frames.size());
    }

    /**
     * \brief Returns the type of current access to the file.
     * @return the total number of frames available in the index
     */
    session::mode::ModeID Mode() const {
        return m_mode;
    }

    /**
     * \brief Returns the path of the current mef
     * @return the path of the current mef
     */
    const std::string& Path() const {
        return m_input_path;
    }

    /**
     * \brief Returns the name of the current mef
     * @return the name of the current mef
     */
    const std::string& Name() const {
        return m_name;
    }

    /**
     * \brief Returns a reference to the events database (actual events)
     * @return a reference to the events database (actual events)
     */
    const std::vector<EventType>& Events() const {
        return m_events;
    }

    /**
     * \brief Returns a reference to an array of pointers to the events
     * @return a reference to an array of pointers to the events
     */
    const ConstSliceType& PEvents() const {
        return m_ptr_events;
    }

    /**
     * \brief Returns a reference to an array of pointers to the keyframes
     * @return a reference to an array of pointers to the keyframes
     */
    const ConstSliceType& KeyFrames() const {
        return m_key_frames;
    }

    /**
     * \brief Returns a reference a set containing the events IDs
     * @return a reference a set containing the events IDs
     */
    const std::set<std::string>& EventIDs() const {
        return m_ids;
    }

    /**
     * \brief Returns a slice of the events database, verifying the predicate
     * @return a slice of the events database, verifying the predicate
     */
    template<typename T>
    void Query(ConstSliceType& dest, T predicate) const
    {
        Query<T>( m_ptr_events, dest, predicate );
    }

    /**
     * \brief Returns a slice of the source slice, verifying the predicate
     * @return a slice of the source slice, verifying the predicate
     */
    template<typename T>
    void Query(const ConstSliceType& source, ConstSliceType& dest, T predicate) const
    {
        dest.reserve ( source.size() );
        std::remove_copy_if ( source.begin(), source.end(), std::back_inserter ( dest ), std::not1(predicate) );
    }

    /**
     * \brief Returns a reference to an empty event
     * @return a reference to an empty event
     */
    const TimeLine::EventType& EmptyEvent() const {
        return m_empty_event;
    }

    /**
     * \brief Returns the type of current access to the file.
     * @return the total number of frames available in the index
     */
    GOLD_DDK_DEPRECATED static const char* VKeyFrameName() {
        return "VFrame";
    }


private:

    struct CMEFHeader
    {
        CMEFHeader();
        unsigned long version; // file version
        unsigned long end_pos; // offset to the end of the header
        bool has_plain_events; // true if the raw events section is not empty

        std::vector<std::string>  lines; // header lines

    };

    boost::system::error_code LoadStructure_MEF( const boost::filesystem::path& input_file );
    boost::system::error_code ReadHeader ( std::ifstream& file, CMEFHeader& Header );

    boost::system::error_code ComputeStatistics();
    boost::system::error_code ComputeStatistics_dummy();

    // TODO: function for generating events with a required spacing

    boost::system::error_code LoadStructure_BMEF( const boost::filesystem::path& input_file );
    boost::system::error_code SaveStructure_BMEF( const boost::filesystem::path& output_file );

    boost::system::error_code BuildStructures_NO_INDEX();
    boost::system::error_code BuildStructures_KEY_TIME(boost::posix_time::time_duration period);
    boost::system::error_code BuildStructures_KEY_EVENT(const std::string& keyframe);
    boost::system::error_code BuildStructures_KEY_LESS();

    typedef vl::chrono::Accumulator AccumulatorType;

    friend class Compute_DeltaTS;

    typedef std::map<std::string, AccumulatorType>    EventStatisticsType;

    std::string m_input_path; ///< path of the indexed files
    std::string m_tmp_path;   ///< temporary path to store cache
    std::string m_name;                   ///< session name

    std::vector<EventType>   m_events;     ///< storage for events sorted by key
    ConstSliceType           m_ptr_events; ///< slice containing the whole database
    std::set<std::string>    m_ids;        ///< IDs set
    ConstSliceType           m_key_frames; ///< slice containing the keyframes

    std::map<std::string, std::string> m_options;

    EventStatisticsType      m_statistics;
    std::vector<std::string> m_str_statistics;

    // TODO: use a policy. Used in : LoadEvents, BuildStructures, JumpToFrame, ReadEvent, GetAccessType
    session::mode::ModeID           m_mode;              ///< Event Manager PlayBackMode: see Modes.h

    static int Version() {
        return 20;
    }

    typedef enum {to_be_loaded, success, bad_mode, file_not_found, load_error} cache_load_status;
    cache_load_status m_cache_loaded;

    // boost function to perform different behaviors depending on configuration
    boost::function<boost::system::error_code()> m_load_structures;
    boost::function<boost::system::error_code()> m_build_structures;
    boost::function<boost::system::error_code()> m_compute_statistics;

    // temporary result for querying events
    std::map< std::string, ConstSliceType > m_events_by_id;

    EventType m_empty_event;              ///< An empty event for zero state
};

}



#endif // _TIMELINE_H
