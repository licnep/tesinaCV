#ifndef _CCAN_MODULE
#define _CCAN_MODULE

#include <DDK/Driver.h>

namespace ddk
{
  

class CSystemCAN;


class GOLD_DDK_EXPORT CCANDriver :
  public ddk::CDriver
{
public:
  CCANDriver(ddk::impl::CDriverInitializer& DrvInit);
  ~CCANDriver();


protected:
  virtual ddk::CDriver::DeviceDescriptor ConcreteDevice_Create( ddk::impl::CDeviceInitializer& dev_descr );  
  void Register_Device(ddk::CSystemCAN& dev);
  
  void On_Devices_Clear();

private:
};

} // namespace ddk

#endif // _CCAN_MODULE
