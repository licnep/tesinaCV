#ifndef _CSYSTEMRADAR_H
#define _CSYSTEMRADAR_H

/** \file CSystemRadar.h
 *  \brief File per la classe CSystemRadar
 *  \author Luca Gatti \<lucag@ce.unipr.it\>
 **/

#include <DDK/CSystemDevice.h>
#include <Devices/Radar/CRadar.h>
#include <UI/CWindows/CWindow.h>

#include <DDK/gold_ddk_export.h>

using data::CRadarScan;

namespace ddk
{
  
class GOLD_DDK_EXPORT CSystemRadar :
      public dev::CRadar,
      public ddk::Device
{
  public:
    typedef CRadar DeviceType;

    CSystemRadar();
    virtual ~CSystemRadar();

  protected:
    
    virtual void On_Initialization();
    virtual void On_ShutDown();

    const char *DefaultFileFormat() { return ".txt"; }

    // Versione distruttiva, ma più efficiente: 
    // il buffer viene swappato con quello del preprocessing
    void FrameUpdate(data::CRadarScan& Scan, const vl::chrono::TimeType &TimeStamp );

    ui::wgt::Widget  panel;

  private:

    // TODO: nel pannello
    void UI_Refresh( const FrameType& frame );
    void View_Draw_Background();
    
    void On_LoadParams( INIFile& ini, hws::Version version );
    void On_SaveParams( INIFile& ini );    
    void Recording_SaveParams( INIFile& ini );    
    
    void FrameRecording( const FrameType& frame );

    // New user interface stuff
    void On_ToggleWnd_Action();

    // Display stuff
    // visible area in the bird eye view
    static double Top()    { return 50.0; }
    static double Left()   { return 50.0; }
    static double Bottom() { return -10.0; }
    static double Right()  { return -50.0; }

    static double Zoom()   { return 1.0; } ///< zoom factor: 1 [meter] = Zoom() [pixels]

    static unsigned int DisplayW() { return static_cast<unsigned int> ( Zoom() * ( Left()-Right() )-0.5 ) +1; }
    static unsigned int DisplayH() { return static_cast<unsigned int> ( Zoom() * ( Top()-Bottom() )-0.5 ) +1; }

    static double label_offset() { return 0.1; }
   
    boost::shared_ptr<ui::win::CWindow> m_spWindow;

    FrameType  m_frame;

    static std::vector<double> m_markers;
    static std::vector<std::string> m_markers_str;
};

} // namespace ddk


#endif // _CSYSTEMRADAR_H
