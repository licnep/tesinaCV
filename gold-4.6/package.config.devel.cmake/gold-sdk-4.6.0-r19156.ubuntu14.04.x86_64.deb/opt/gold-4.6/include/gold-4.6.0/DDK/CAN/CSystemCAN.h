/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2007                  *
 *                                                                    *
 *       http://www.ARGO.ce.unipr.it                                  *
 *                                                                    *
 **********************************************************************/
//
// Authors: Pietro Cerri & Stefano Ghidoni, Dipartimento di Ingegneria dell'Informazione - Palazzina 1, +39(0521)905725-92
// <cerri@ce.unipr.it>, <ghidoni@ce.unipr.it>, (C) 2007
//
// Copyright: See COPYING file that comes with this distribution
//
//

/** \file CSystemCAN.h
 * \date Luglio 2007
 * \author Pietro Cerri (cerri@ce.unipr.it), Stefano Ghidoni (ghidoni@ce.unipr.it)
 * \brief Modulo che gestisce le chiamate di sistema al CAN
 */

#ifndef _CSYSTEMCAN_H
#define _CSYSTEMCAN_H

#include <Devices/Base/CSampler.h>
#include <Devices/CAN/CCAN.h>
#include <DDK/CSystemDevice.h>
#include <DDK/CSystemDevice.h>
#include <DDK/CAN/CCANPreprocessor.h>

#include <set>
#include <map>
#include <stdint.h>


class CCANPreprocessor;
class CWindow;

namespace ddk
{
  
/**
 * Class for calculating statistics on can messages
 */
class CMsgStats
{
    typedef vl::chrono::Accumulator AccumulatorType;
    
    vl::chrono::TimeType m_prev_ts;
    AccumulatorType m_accumulator;
    std::deque<data::CCANData>  m_History;
    static unsigned int HistorySize();

    void ( CMsgStats::*updtime ) (const vl::chrono::TimeType& );

    void TimeUpdate_First(const vl::chrono::TimeType& timestamp);
    void TimeUpdate(const vl::chrono::TimeType& timestamp);

  public:

    CMsgStats();
    void Update ( const data::CCANData& can_data, const vl::chrono::TimeType& timestamp );
    const AccumulatorType& Chrono() const;
    const data::CCANData& LastMsg() const;
};



typedef enum{rx, tx} PacketOperation;

/**
 * Base class for Concrete CAN Devices implementation
 * This class supplies the basic methods to simplify the
 * implementation of Concrete CAN Devices inside the drivers
 */
class GOLD_DDK_EXPORT CSystemCAN :
      public dev::CCAN,
      public ddk::Device
{
  public:
    typedef CCAN DeviceType;
    
    CSystemCAN();

    /////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// PREPROCESSOR STUFF
    virtual void Subscribe_Decoding(const std::string& name, const SignalDecodeType::slot_type &slot);

    // ereditata da CCAN e implementata qui: passare ad un meccanismo a notifica
    virtual boost::any Get_Value(const std::string& name);
    virtual void Send_Value(const boost::any& info , const std::string& name);
    /////////////////////////////////////////////////////////////////////////////////////////////////////////

  protected:
    virtual void On_Initialization();
    virtual void On_ShutDown();

    virtual void On_Session_Open( const usr::CSession& session );

    virtual void On_WakeUp(void);
    virtual void On_Suspend(void);

    void FrameUpdate( FrameType& frame );
    
    void Notify_Message_TX ( const FrameType& frame );
    void Notify_Message_RX ( const FrameType& frame );

    // NOTE: per ora abbiamo un unico device per lettura e scrittura
    // si risparmiano risorse allocando oggetti diversi
    void FrameRecording(const FrameType& frame );
    
    // Dimensione della finestra
    static unsigned int DisplayW() { return 800; }
    static unsigned int DisplayH() { return 400; }    

  private:
    void On_LoadParams( INIFile &ini, hws::Version version );
    void On_SaveParams( INIFile &ini );    
    void Recording_SaveParams( INIFile& ini );
    
    void SetWhiteList( const std::string& WL );
    void UpdateStats_TX ( const data::CCANData& Packet );
    void UpdateStats_RX ( const data::CCANData& Packet );
    
    void Update_Entry( unsigned int id, const vl::chrono::Accumulator& acc, PacketOperation dir );
    
    unsigned int Add_Entry(const std::string& name);

    CWindow* m_pWindow;                  ///< the window showing the device status
    
    std::set<uint32_t> m_WhiteList;      ///< list of the id to be dispatched (empty=>all)
    
    std::map<uint32_t, CMsgStats> m_MsgStats_rx; ///< received message statistics
    std::map<uint32_t, CMsgStats> m_MsgStats_tx; ///< transmitted message statistics

    // stampa della versione binaria sul pannello
    std::vector<uint8_t> m_mask;
    std::string m_S;

    // serve per avviare il preprocessor
    boost::shared_ptr<ddk::CCANPreprocessor> m_preprocessor;
    
    typedef struct
    {
      ui::wgt::Widget id;
      ui::wgt::Widget op;      
      ui::wgt::Widget count;
      ui::wgt::Widget last;
      ui::wgt::Widget min;
      ui::wgt::Widget max;    
      ui::wgt::Widget avg;    
      ui::wgt::Widget var;      
    } widget_row;
    
    std::vector<widget_row> m_rows;
    ui::wgt::GridSizer m_g_sz;
    
    char m_buffer[100];    
    
    boost::shared_ptr<std::ostringstream> m_woss;
    
    boost::property_tree::ptree m_rec_options;
};

} // namespace ddk

#endif
