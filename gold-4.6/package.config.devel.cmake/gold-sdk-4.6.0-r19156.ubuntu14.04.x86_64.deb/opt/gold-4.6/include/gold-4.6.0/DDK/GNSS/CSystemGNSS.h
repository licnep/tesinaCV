#ifndef _CSYSTEMGNSS_H
#define _CSYSTEMGNSS_H

#include <DDK/CUDPRepeater.h> // This must stay first, otherwise VC10 issues "fatal error: WinSock.h has already been included"
#include <DDK/CSystemDevice.h>
#include <DDK/gold_ddk_export.h>

#include <Devices/GNSS/CGNSS.h>
#include <UI/CWindows/CWindow.h>

using data::CGNSSData;

namespace ddk
{
class GOLD_DDK_EXPORT CSystemGNSS :
      public dev::CGNSS,
      public ddk::Device
{
  public:
    typedef CGNSS DeviceType;

    CSystemGNSS();
    virtual ~CSystemGNSS();

    void Enable_Broadcast(const std::string& broadcast);
    void Disable_Broadcast();

  protected:

    virtual void On_Initialization();
    virtual void On_ShutDown();

    /**
     * \brief Update from an NMEA string
     */
    void FrameUpdate( const std::string& nmea_str, vl::chrono::TimeType time_stamp );
    
    /**
     * \brief Update the current GNSS Frame and notify it to all listener
     */
    void FrameUpdate( const data::GNSS& gps_data, vl::chrono::TimeType time_stamp );
    
    void FrameRecording( const FrameType& frame, const std::string& nmea_str );

    ui::wgt::Widget panel; ///< panel

  private:
    void On_LoadParams( INIFile &ini, hws::Version version );
    void On_SaveParams( INIFile &ini );
    void Recording_SaveParams( INIFile &ini );

    // New user interface stuff
    void UI_Update();
    void On_ToggleWnd_Action();
    
    FrameType  m_frame;  ///< last GNSS-FRAME available

    boost::shared_ptr<ui::win::CWindow> m_spWindow;

    CUDPRepeater* m_broadcast; ///< Repeater on UDP object
    boost::property_tree::ptree m_rec_options; ///< recording options
    std::vector<std::string> m_fix_quality;
};
  
}

#endif
