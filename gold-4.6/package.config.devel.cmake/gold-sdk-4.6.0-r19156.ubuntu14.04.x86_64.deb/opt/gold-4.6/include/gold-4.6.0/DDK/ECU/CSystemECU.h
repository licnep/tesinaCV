/** \file CSystemECU.h
 *  \brief File per la classe CSystemECU
 *  \author Luca Gatti \<lucag@ce.unipr.it\>
 **/

#ifndef CSYSTEMECU_H
#define CSYSTEMECU_H

#include <Devices/ECU/CECU.h>
#include <DDK/CSystemDevice.h>
#include <UI/CWindows/CWindow.h>

#include <DDK/gold_ddk_export.h>


namespace ddk
{

  class GOLD_DDK_EXPORT CSystemECU : 
  public dev::CECU, 
  public ddk::Device
{
  public:
    typedef CECU DeviceType;

    CSystemECU();
    virtual ~CSystemECU();

  protected:
    
    const char* DefaultFileFormat() { return ".txt"; }

    virtual void On_Initialization();
    virtual void On_ShutDown();
    
    // Versione distruttiva, ma più efficiente: 
    // il buffer viene swappato con quello del preprocessing
    // La NextBusy si occupa di copiare la Computation in m_Frame con il relativo timestamp
    // Di chiamare Record e Preprocessing
    // Di chiamare BkgUpdate
    // Di chiamare Notify_Frame_Received_Async
    // Di chiamare LogCapture
    // se il pannello è mostrato, allora viene aggiornato con le info sincrone con il thread di acquisizione    
    void FrameUpdate( data::CECUData& computation, const vl::chrono::TimeType& timestamp );

    ui::wgt::Widget panel; // pannello

  private:
    void On_LoadParams( INIFile& ini, hws::Version version );
    void On_SaveParams( INIFile& ini );  
    void Recording_SaveParams( INIFile& ini );
    
    // TODO: nel pannello
    void UI_Refresh( const FrameType& frame );
    void View_Draw_Background();

    // virtual const CLaserScanner::PulsesColorType& PulsesColor();
    
    /**
     * Record the current frame
     */
    void FrameRecording( const FrameType& frame ); 
    
    // New user interface stuff
    void On_ToggleWnd_Action();

    // Display stuff
    // visible area in the bird eye view
    static double Top()    { return 50.0; }
    static double Left()   { return 50.0; }
    static double Bottom() { return -10.0; }
    static double Right()  { return -50.0; }

    static double Zoom()   { return 1.0; } ///< zoom factor: 1 [meter] = Zoom() [pixels]

    static unsigned int DisplayW() { return static_cast<unsigned int> ( Zoom() * ( Left()-Right() )-0.5 ) +1; }
    static unsigned int DisplayH() { return static_cast<unsigned int> ( Zoom() * ( Top()-Bottom() )-0.5 ) +1; }

    static double label_offset() { return 1.0; }

    static std::vector<double> m_markers;
    static std::vector<std::string> m_markers_str;
    
    FrameType  m_frame;

    boost::shared_ptr<ui::win::CWindow> m_spWindow;
};

} // namespace ddk


#endif // CSYSTEMECU_H
