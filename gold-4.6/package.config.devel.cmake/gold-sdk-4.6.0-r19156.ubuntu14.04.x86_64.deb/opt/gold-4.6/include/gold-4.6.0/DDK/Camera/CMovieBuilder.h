#ifndef _CMOVIE_BUILDER_
#define _CMOVIE_BUILDER_

#include <boost/filesystem/path.hpp>
#include <boost/thread/thread.hpp>
#include <vector>
#include <string>

#include <Libs/Time/TimeUtils.h>

namespace ddk
{
  

// struct ResourceDescriptor
// {
//   ResourceDescriptor():framenumber(0u){}
//   TimeType duration;
//   unsigned int framenumber;
//   ///TODO pWriter
// } ;

// typedef std::map <boost::filesystem::path , ResourceDescriptor > ResourcesMapType;


class CMovieBuilder
{
  public:
    
    void BuildAVI (boost::filesystem::path working_path, boost::filesystem::path ofile,
                   const std::vector<boost::filesystem::path>& audio_tracks ,
                   unsigned long num_frames, const vl::chrono::TimeType& duration, float fps,
		   bool keep_tmp_file=false);
    
    ~CMovieBuilder();
    
  private:
    
    void Build( boost::filesystem::path& working_path, boost::filesystem::path& ofile, 
			   const std::vector<boost::filesystem::path>& audio_tracks,
                           unsigned long num_frames, float fps, bool keep_tmp_file  );


/*    boost::posix_time::time_duration GetMP3Duration(const boost::filesystem::path& mp3_file);*/
    
    //TODO si puo fare con una free function  e un vettore di boost::thread, ma
    //FIXME il vettore deve essere svuotato dai thread che finiscono
    // la creazione del video. Servirebbe in alternativa una variabile
    //condizione che attenda la fine del thread e termini.
    //std::vector <boost::thread > m_movie_builder; 
    
    boost::thread m_movie_builder;

    //boost::mutex m_mutex;
    
    std::string m_avidemux_script;
};

}
#endif