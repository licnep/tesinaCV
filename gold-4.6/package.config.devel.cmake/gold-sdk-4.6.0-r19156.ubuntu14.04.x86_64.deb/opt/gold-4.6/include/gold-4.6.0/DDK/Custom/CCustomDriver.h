#ifndef _DRIVER_CUSTOM
#define _DRIVER_CUSTOM

#include <DDK/Driver.h>

namespace dev {class CCustom;}

namespace ddk
{
class CCustom;

class GOLD_DDK_EXPORT CDriver_Custom :
  public ddk::CDriver
{
public:
  CDriver_Custom(ddk::impl::CDriverInitializer& DrvInit);
  ~CDriver_Custom();

protected:
  
  virtual DeviceDescriptor ConcreteDevice_Create( ddk::impl::CDeviceInitializer& dev_descr );
  void Register_Device(ddk::CCustom& dev);  // NOTE; anche private

private:

};
} // namespace ddk
#endif // _DRIVER_CUSTOM
