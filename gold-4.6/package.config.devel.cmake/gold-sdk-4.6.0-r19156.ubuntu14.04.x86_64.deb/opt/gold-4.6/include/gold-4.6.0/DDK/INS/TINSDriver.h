#ifndef _TINSDRIVER_H
#define _TINSDRIVER_H

#include <DDK/Driver.h>
#include <DDK/INS/CSystemINS.h>
#include <DDK/gold_ddk_export.h>

namespace ddk
{
template<typename ConcreteDeviceType>
class GOLD_DDK_EXPORT CDriver_INS:
    public ddk::CDriver
{
public:
    CDriver_INS ( ddk::impl::CDriverInitializer& drv_init ) :
        ddk::CDriver( drv_init )
    {}
    
    virtual ~CDriver_INS() {}
    
    virtual ddk::CDriver::DeviceDescriptor ConcreteDevice_Create( ddk::impl::CDeviceInitializer& dev_descr )

    {
        // ddk::CDriver::DeviceDescriptor retval;
        // T* gnss=new T(dev_descr.INI());
        // retval.pdev = gnss;
        // retval.reg = boost::bind(&TINSDriver<T>::Register_Device, this, boost::ref(*gnss));
        // return retval;

        CDriver::DeviceDescriptor retval;

        // Estrae dall'HWS tutti i nomi delle camere ed il driver da usare
        INIFile& ini=dev_descr.INI();       // alias per il nodo in esame
        {
            // carica VENDOR e MODEL del LS in esame
            std::string vendor=ini.Value<std::string> ( "VENDOR", "Not specified" );
            std::string model=ini.Value<std::string> ( "MODEL", "Not specified" );

            std::string key=vendor+"::"+model;

            // INSFactoryType::AbstractAllocatorType allocator = vl::Singleton<INSFactoryType>::Instance().GetAllocator( key );

	    ddk::CSystemINS* pdev = new ConcreteDeviceType();
	    retval.pdev = pdev;
	    retval.reg = boost::bind(&CDriver_INS::Register_Device, this, boost::ref(*pdev));
	    // TODO: retval.unreg = boost::bind(&CDriver_LaserScanner::AddChild, this, pls);
        }
        return retval;
    }

    void Register_Device( ddk::CSystemINS& dev )
    {
        Insert_DeviceNode ( new dev::CDeviceLeaf ( dev.Name_(), &dev ) );
    }
};
} // namespace ddk

#endif