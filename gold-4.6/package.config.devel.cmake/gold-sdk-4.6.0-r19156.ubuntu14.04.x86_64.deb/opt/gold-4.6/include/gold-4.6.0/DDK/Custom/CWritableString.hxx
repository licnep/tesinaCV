#ifndef _WRITABLE_STRING_H
#define _WRITABLE_STRING_H

#include <string>
#include <Devices/CDiskWriter/CWritable.h>
// #include <Libs/Logger/Log.h>

namespace data { class CEvent; }

namespace dev
{
  

// specializzazione di TWritable per std::string
template <>
class TWritable<std::string> :
      public CWritable
{
  public:
    typedef std::string ObjType;

    TWritable ( boost::shared_ptr<data::CEvent> Event, 
                const std::string& Location, 
                const ObjType& Object ) :
        CWritable ( Event, Location ),
        m_object ( Object )
    {}

    virtual ~TWritable() {}
    
    virtual void Destroy_Payload()
    {
       // std::cout << " Destroy_Payload " << m_object->UseCount() << std::endl;
       m_object.clear();
    }

    virtual uint64_t Size() const
    {
      // TODO: calcolare dimensione
      return m_object.size();
    }

    virtual uint64_t Save() const
    {
      return 0uL; // cscan::serialization::Save ( *m_object, Location() );
    }
    
    virtual void Save(std::ostream& ostr) const
    {
      ostr << m_object << std::endl; // TODO: boost serialization
      // cscan::serialization::Save(*m_object, ostr, cscan::serialization::BIN /*m_format*/, boost::property_tree::ptree()/*m_options*/);
    }         
    
    virtual void Save_Metadata(std::ostream& ostr) const {}        

    const ObjType operator() () const { return m_object; }

  private:
    std::string m_object;
};

} // namespace dev

#endif // _WRITABLE_CSCAN_H
