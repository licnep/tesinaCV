#ifndef _CSYSTEM_CAMERA_H
#define _CSYSTEM_CAMERA_H

#include <Devices/Camera/CCamera.h>
#include <Devices/Camera/CPreprocessor.h>
#include <Framework/CMessageBus.h>
#include <DDK/CSystemDevice.h>
#include <Data/CImage/CImage.h>
#include <Data/CImage/IO/Video.h>

#include "CMovieBuilder.h"

class CCameraGUI;
class CCameraGUI_NT;

namespace ddk
{
class GOLD_DDK_EXPORT CSystemCamera :
      public dev::CCamera,
      public ddk::Device
{
public:
  typedef CCamera DeviceType;
  
  CSystemCamera();
  ~CSystemCamera();

  void Initialize_Preprocessor( dev::CDeviceManager& DevMan, dev::CCameraMap& Cams );

  // ci vuole questo bridge perchè bind non vede il metodo di CCamera
  void Preprocess ( const FrameType& Frame ) { CCamera::Preprocess(Frame); }
  
protected:
  typedef dev::camera::VideoProperty::ShPtrType VPShPtrType;  

  
  virtual void On_Initialization();
  virtual void On_ShutDown();
  
  virtual void On_Recording_Create ();
  virtual void On_Recording_Destroy();  
  virtual void On_PreRecording_Start();
  virtual void On_PreRecording_Stop();
  virtual void On_Recording_Start();
  virtual void On_Recording_Stop();

  virtual void On_Prev();
  virtual void On_Next();
  virtual void On_Goto( unsigned long Frame );
  virtual void On_Suspend() ;     

    /**
   * Chiamata dai driver di playback quando è stata caricata un'immagine
   * L'immagine viene successivamente distribuita alle strutture interne della CCamera per il preprocessing
   * @param
   */
  void FrameUpdate( cimage::CImage::SharedPtrType& image, const vl::chrono::TimeType& timestamp );
  void FrameUpdate( cimage::CImage::SharedPtrConstType& image, const vl::chrono::TimeType& timestamp );
  
  /**
   * Chiamata dai driver hardware per generare la cimage a partire dalla memoria del driver
   * L'immagine viene successivamente distribuita alle strutture interne della CCamera per il preprocessing
   * @param
   */
   void FrameUpdate(const void* buffer, unsigned long size, const vl::chrono::TimeType& timestamp);
 
  
  void LoadRoI();

  virtual void On_RoIChanged(dev::camera::CRoI& RoI);

  void Build_Page_VideoProps(); // deve essere chiamata dopo la On_Init della Concrete camera
  void Build_Page_Plugins();
  
  void On_BtnPanel_Pressed();
  void On_BtnWindow_Pressed();
  void On_BtnAdd_Pressed();
  void On_BtnRemove_Pressed();
  void On_BtnSetAsOut_Pressed();
  
  void SetRemoteVideoConnectionStatus(bool status);
  bool GetRemoteVideoConnectionStatus() const;    
  
  ui::wgt::Widget panel; // pannello
  ui::wgt::Widget  m_remote_output;
  ui::var::Value<bool> m_toggle_remote_video_connection;
  ui::wgt::TreeBook m_pg_plugin;
  
  // variabili per la pagina dei plugin
  std::string m_plugins_tree;  
  
  std::string m_plugin_type;
  std::string m_plugin_name;
  // std::string m_plugin_source;
  std::string m_plugin_params;
  ui::var::Choice<std::string> m_enum_plugin_sources;
  std::string m_selected_plugin_source; // FIXME x PM, perchè non riesco a leggerlo dalla variabile sopra?
  
  ui::var::Choice<std::string> m_enum_plugin_sources_sel;

  private:
    void On_LoadParams( INIFile &ini, hws::Version version );
    void On_SaveParams( INIFile &ini );  
    void Recording_SaveParams( INIFile &ini );
    
    void FrameUpdate_internal( cimage::CImage::SharedPtrConstType& image, const vl::chrono::TimeType& timestamp );
    void FrameRecording( const FrameType& frame );
    
    void On_Stream_Start( const module::CMessage& msg );
    void On_Stream_Stop( const module::CMessage& msg );  
    
    typedef enum{VM_VIDEO, VM_IMAGES} WritingModeType;
    WritingModeType m_writing_mode;
    
    boost::mutex m_video_writer_mtx;
    boost::shared_ptr<cimage::io::video::Writer>  m_video_wrt;
      
    CCameraGUI    *m_GUI;
    CCameraGUI_NT *m_GUI_NT;

    ddk::CMovieBuilder m_movie_builder;
    
    double m_frame_rate;
    uint32_t m_codec;
    uint32_t m_bit_rate;
    
    boost::filesystem::path m_chunk_path;
    
    std::vector<boost::filesystem::path> m_audio_tracks;
        
    msgbus::CEndPoint m_ep;
    msgbus::CEndPoint::IDType m_engine_out;      
};
  
}



#endif
