#ifndef _CSYSTEMINS_H
#define _CSYSTEMINS_H

#include <DDK/CUDPRepeater.h> // Deve stare per prima, se no VC10 segnala fatal error: WinSock.h has already been included
#include <Devices/INS/CINS.h>
#include <DDK/CSystemDevice.h>

#include <UI/CWindows/CWindow.h>
#include <UI/CWindows/TimeGraph.h>

#include <DDK/gold_ddk_export.h>

namespace ui{ namespace win { class CWindow; } }
using data::CINSData;

namespace ddk
{

class GOLD_DDK_EXPORT CSystemINS :
            public dev::CINS,
            public ddk::Device
{
public:
    typedef CINS DeviceType;

    CSystemINS();
    virtual ~CSystemINS();

    void Enable_Broadcast(const std::string& broadcast);
    void Disable_Broadcast();


protected:
    virtual void On_Initialization();
    virtual void On_ShutDown();
    
    /// recording of the current frame
    void FrameRecording();

    /// update the current INS Frame and notify it to all listener
    void FrameUpdate(const data::CINSData& ins_data, vl::chrono::TimeType time_stamp);

    /// Return the unbiased data
    void GetUnBiasedINSData(data::CINSData& data );

    /// Calcola m_curBias
    bool EvaluateBIAS();

    ui::wgt::Widget panel; // pannello

private:
    void On_LoadParams( INIFile& ini, hws::Version version );
    void On_SaveParams( INIFile& ini );
    void Recording_SaveParams( INIFile& ini );
    void UI_Update();
    
    enum BiasType {
      VEL_BIAS,
      VELX_BIAS,
      VELY_BIAS,
      VELZ_BIAS,
      
      ACCX_BIAS,
      ACCY_BIAS,
      ACCZ_BIAS,
      
      YAW_BIAS,
      PITCH_BIAS,
      ROLL_BIAS,

      YAWRATE_BIAS,
      PITCHRATE_BIAS,
      ROLLRATE_BIAS,

      MAG_X_BIAS,
      MAG_Y_BIAS,
// reserved
      BIAS_SIZE
    } ;    

    /// return the bias associated with @a type at the @a temp (or throw an exception if it is not available)
    float GetBiasValue(BiasType type, float temp) const;
    void On_ToggleWnd_Action();    
    
    boost::mutex m_mutex; ///< Mutex per accedere ai dati della classe
    boost::shared_ptr<ui::win::CWindow> m_spWindow;

    FrameType  m_frame;  ///< last INS-FRAME available
    FrameType  m_frame_unbiased;  ///< last INS-FRAME UnBiased available

    data::CINSData m_current_bias;  ///< Bias Corrente
    bool m_is_current_bias_valid; ///< La struttura m_curBias e' valida?
    std::map<float, float> m_bias_table[BIAS_SIZE]; /// Look Up Table per il BIAS

    // bool m_bias_correction_available; /// E' disponibile la correzione del bias?

    bool m_is_visible;
    CUDPRepeater *m_broadcast; ///< Repeater on UDP object
    std::string m_rec_str;    ///< string buffer for recording
    
    boost::property_tree::ptree m_rec_options; ///< recording options

	typedef std::deque<CSystemINS::FrameType> HistoryType;

	bool m_enable_history;
    vl::chrono::TimeType m_history_size;
    std::vector<TimeGraph> gds;


};

}

#endif
