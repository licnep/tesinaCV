#ifndef _CFRAMECOUNTER_H
#define _CFRAMECOUNTER_H

#include <string>
#include <Framework/Transport.h>
#include <DDK/gold_ddk_export.h>


namespace sys
{
  
class GOLD_DDK_EXPORT FrameCounter:
            public usr::FrameCounter
{
public:
    FrameCounter();

    /// assegna il range dei frame
    void SetRange ( ValueType min, ValueType max );

    void SetLoop(bool loop);

    /// Avanza di 1 tenendo conto di m_loop
    void Next();

    /// Avanza di -1 tenendo conto di m_loop
    void Prev();

    /// assegna un nuovo valore (salto)
    /// se Value è fuori dal range, viene assegnato il valore nel range più vicino
    void Goto(ValueType new_value);

    /// ritorna il valore corrente
    operator FrameCounter::ValueType () const;
    FrameCounter::ValueType operator ()() const;

    ValueType NumFrames() const;

    bool IsAtBOS() const;
    bool IsAtEOS() const;

    /// ostream output
    friend GOLD_DDK_EXPORT std::ostream& operator <<(std::ostream& os, const FrameCounter& fc);

private:

    /// ripristina la consistenza tra m_Value ed il valore a cui punta l'iteratore
    /// torna true se l'elemento c'e' ed e' nuovo, false se e' lo stesso o non c'era
    bool Refresh();

    ValueType m_min, m_max, m_max_mod, m_curr;
    bool      m_loop;
    bool      m_1st;   /// true if the 1st update or assignement has to be done
};

}





#endif
