/** \file ECU_Registration.h
 *  \brief File per la classe CECU_FactoryRegister
 *  \author Luca Gatti \<lucag@ce.unipr.it\>
 **/

#ifndef __CECU_REGISTRATION
#define __CECU_REGISTRATION

#include "CSystemECU.h"

#include <Libs/Patterns/Singleton.h>
#include <Libs/Patterns/Factory.h>

namespace ddk
{

// tipo per la factory a singleton
typedef vl::Factory<std::string, CSystemECU> CECUFactoryType;

#define REGISTER_ECU(CLASS,STRNAME) vl::ObjectRegistrar< ddk::CECUFactoryType, CLASS > drf_##CLASS(STRNAME)

} // namespace ddk

#endif
