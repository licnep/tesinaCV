/*
 * CCANPreprocessor.h
 *
 *  Created on: 20-apr-2009
 *      Author: Gargioni Manuel Matricola 150093 e Paolo Grisleri
 */

#ifndef CCANPREPROCESSOR_H
#define CCANPREPROCESSOR_H

// TODO: rivedere
#include <typeinfo>
#include <map>

#include <stdint.h>
#include <boost/any.hpp>
#include <boost/property_tree/ptree_fwd.hpp>

#include <platform.h>

// Le seguenti combinazioni di boost e gcc 
// generano errori di compilazione nel parser json
// boost>1.46.0 e gcc<4.7.0 non funziona
#if ( (GCC_VERSION < 40700) &&\
       ((BOOST_VERSION >= 104600) && (BOOST_VERSION < 104800))\
     )
   #include <boost/property_tree/json_parser.hpp>
#else
  #warning you are using a problematic combination of boost version and gcc: the CAN preprocessor will not be available
  // check this before using json functions
  #define JSON_PARSER_DISABLED
#endif 

#include <boost/filesystem.hpp>
#include <boost/ptr_container/ptr_map.hpp>


#include <Data/CCANData/CANData.h>
#include <Devices/CAN/CCAN.h>
#include <Framework/CDynamicModulesLoader.h>

// foward declaration mi permette di sapere che da qualche parte c'è CCANCodec
namespace dev
{
namespace can
{
class CDecoder;
class CEncoder;
}
}

namespace ddk
{
class CCANPreprocessor 
{
  public:
    /// caricamento dei plugins
    void LoadPlugins(const std::string& path); 
    
    // Inizializzazione delle strutture dati per decoders ed encoders
    void Initialize_Decoders();    
    void Initialize_Encoders();
    
    // Funzione che mi richiama la funzione necessaria al calcolo dei dati
    void Process(const dev::CCAN::FrameType& frame);
    
    /// Gestione recupero Dati tramite signal
    void Subscribe_Decoding(const std::string& name, const dev::CCAN::SignalDecodeType::slot_type& slot);

    /// Gestione recupero dati manuale
    boost::any ReturnValue(const std::string& name);
    void SendData(const boost::any& info , const std::string& name);
    
    void Do_On_EncodeCompleted(const dev::CCAN::SignalDirectSendType::slot_type& slot);

    // Elemento che mi contiene i dati letti dal file json
    boost::property_tree::ptree DatiFile_Decoder;
    boost::property_tree::ptree data_file_encoder;

    //Contiene il path del file .json
    boost::filesystem::path m_Path_Decoder;
    boost::filesystem::path m_Path_Encoder;

  private:
    // e una mappa che ha come chiave l'id e come valori un vettore del tipo CDecoder
    typedef std::map<data::CCANData::IDType,std::vector<dev::can::CDecoder*> > DecodersMap;
    DecodersMap m_decoders_map;
    
    // e una mappa che contiene i valori finali e come chiave ha il nome
    typedef std::map <std::string, dev::can::CDecoder*> NameIndex;
    typedef std::map <std::string, dev::can::CEncoder*> NameEncodeIndex;
    NameIndex m_name_index ;
    NameEncodeIndex m_name_encode_index;
    
    dev::CCAN::SignalDirectSendType m_on_encode_completed;
    vl::CDynamicModulesLoader m_dml;
};
} // namespace dev
#endif /* CCANPREPROCESSOR_H */
