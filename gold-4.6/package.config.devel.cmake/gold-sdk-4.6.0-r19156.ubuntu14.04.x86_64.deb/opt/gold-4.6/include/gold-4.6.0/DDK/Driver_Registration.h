#ifndef _CDRIVER_REGISTRATION
#define _CDRIVER_REGISTRATION

#include <Libs/Patterns/Singleton.h>
#include <Libs/Patterns/Factory.h>
#include <Libs/Patterns/RegisterObject.h>

#include <DDK/gold_ddk_export.h>


namespace ddk
{
class CDriver;

namespace impl
{
class CDriverInitializer;

// tipo per la factory a singleton
typedef boost::function<CDriver*(CDriverInitializer&)> CDriverAllocatorType;
typedef vl::Factory<std::string, CDriver, CDriverAllocatorType> CDriverFactoryType;
}
}

#define REGISTER_DRIVER(CLASS,STRNAME) vl::ObjectRegistrar< ddk::impl::CDriverFactoryType, CLASS > drf_##CLASS(STRNAME)

#endif
