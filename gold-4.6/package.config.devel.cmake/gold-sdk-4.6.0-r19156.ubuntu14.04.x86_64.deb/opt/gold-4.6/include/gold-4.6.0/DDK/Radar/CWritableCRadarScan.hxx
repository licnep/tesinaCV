#ifndef _RADARSCANWRITER
#define _RADARSCANWRITER

#include <Data/CRadarScan/CRadarScan.h>
#include <Data/CRadarScan/CRadarScanSerialization.h>
#include <Data/CRadarScan/CRadarScanSerialization.hxx>
#include <Devices/CDiskWriter/CWritable.h>
#include <Libs/Logger/Log.h>

namespace data { class CEvent; }

using data::CRadarScan;

namespace dev
{
  
// specializzazione di TWritable per CRadarScan
template <>
class TWritable<CRadarScan> :
      public CWritable
{
  public:
    typedef CRadarScan ScanType;

    TWritable ( boost::shared_ptr<data::CEvent> event, 
                const std::string& location, 
                boost::shared_ptr<CRadarScan> scan ) :
        CWritable ( event, location ),
        m_scan ( scan )
    {}

    virtual ~TWritable() {}
    
    virtual void Destroy_Payload()
    {
       m_scan.reset();
    };    

    virtual uint64_t Size() const
    {
      // TODO: calcolare dimensione
      return sizeof(CRadarScan);
    }

    virtual uint64_t Save() const
    {
      boost::filesystem::path path(Location()); // TODO evitare questo temporaneo
      return data::cradar::serialization::Save ( path, *m_scan );
      // FIXME: non vede la funzione sopra
      // return 0uL;
    }
    
    virtual void Save(std::ostream& ostr) const
    {
     std::cout << "TWritable<CRadarScan>::Save(std::ostream& ostr) TBD" << std::endl;
    }
    
    virtual void Save_Metadata(std::ostream& ostr) const
    {
      // TODO embed a property_tree in the data
    }    

    const ScanType operator() () const { return *m_scan; }

  private:
    boost::shared_ptr<CRadarScan> m_scan;
};


} // namespace dev

#endif
