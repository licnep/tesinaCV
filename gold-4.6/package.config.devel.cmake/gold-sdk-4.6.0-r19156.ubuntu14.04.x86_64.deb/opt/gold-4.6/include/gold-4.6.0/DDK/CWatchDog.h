#ifndef _CWATCHDOG_H
#define _CWATCHDOG_H

#include <boost/date_time/posix_time/posix_time_types.hpp>

#include <boost/thread/mutex.hpp>
#include <boost/thread/condition.hpp>
#include <boost/thread/xtime.hpp>

namespace ddk
{

/** \file CWatchDog.h
  * \author Paolo Grisleri (grisleri@ce.unipr.it)
  * \brief WatchDog object for blocked threads detection.
  **/

class CWatchDog
{
public:
    CWatchDog(boost::posix_time::time_duration duration);
    ~CWatchDog();

    void HeartBeat();
    bool IsAlive();

private:
    boost::posix_time::time_duration m_duration;
    boost::xtime m_timeout;

    boost::mutex      m_mutex;
    boost::condition  m_condition;
};

} // namespace ddk

#endif
