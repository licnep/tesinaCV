#ifndef _CSYSTEMDEVICE_H
#define _CSYSTEMDEVICE_H

#include <DDK/gold_ddk_export.h>

#include <Framework/CModule.h>

#include <UI/Panel/Widgets.h>

#include <DDK/CRecorder.h>
#include <DDK/CSampler.h>

#include <Devices/Base/TFrame.h>
#include <Framework/HWS_Version.h>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif


namespace vl{ namespace ini {class INIFile;} } using vl::ini::INIFile;
namespace dev{ class CDeviceManager; }
namespace usr { class CPathManager; }

namespace ddk
{
class  GOLD_DDK_EXPORT Device:
            public usr::CModule
{
public:
    virtual ~Device() {}

    void Initialize_Clock(const vl::chrono::CTSChronometer &clock);
    void Initialize_Paths(const usr::CPathManager& path_mgr);
    void Initialize_Transport( usr::Transport& tr );
    void Initialize_INI(INIFile& ini, hws::Version version);

    void Devices_Share(dev::CDeviceManager& devices);

    void Add(const ui::wgt::Widget& panel);

    /**
     *  Exception thrown in construction/initialization
     */
    class CreationException :
                public std::runtime_error
    {
    public:

        CreationException(const std::string& ErrorDescription="") :
                runtime_error(ErrorDescription) {}
    };

    void LoadParams( INIFile& ini, hws::Version version );
    void SaveParams( INIFile& ini );
    void SaveSequenceParams_NT ( INIFile& ini );

protected:
    Device();

    const usr::CPathManager& PathManager() const;

    template<typename T>
    void FrameUpdate( dev::TFrame<T>& frame, const T& data, const vl::chrono::TimeType& timestamp, const vl::chrono::TimeType& duration=vl::chrono::TimeType() )
    {
        m_sampler.Update ( timestamp, duration );

        frame.Name = Name_();

        frame.AbsTimeStamp = m_sampler.VirtualOrigin(); ///< Timestamp assoluto. In playback è quello della registrazione
        frame.AbsTimeStamp += m_sampler.TimeStamp();
        frame.Data = data;
        frame.TimeStamp = m_sampler.TimeStamp();  ///< Timestamp relativo all'origine
        frame.Duration  = m_sampler.Duration();   ///< durata del campione

        frame.Number =  m_sampler.FrameNumber();  ///< numero di frame. Può ripetersi in playback
        frame.Counter = m_sampler.FrameCounter(); ///< contatore del numero di frame (sempre crescente)
    }

    virtual void On_Initialization();
    virtual void On_ShutDown();

    virtual void On_Initialization(const vl::chrono::CTSChronometer &Clock) {}    ///< Called when the Clock must be initialized
    virtual void On_Initialization(const usr::CPathManager& path_mgr) {}           ///< Called when the Clock must be initialized
    virtual void On_Devices_Share(dev::CDeviceManager &Devices) {}

    virtual void On_Recording_Initialization(const usr::CRecordingCtl& rc);
    virtual void On_Recording_Create();
    virtual void On_Recording_Destroy();

    void LogCapture();

#ifdef USE_BOOST_SIGNAL2
    typedef boost::signals2::signal<void( INIFile& ini, hws::Version )> LoadParamsType;
    typedef boost::signals2::signal<void( INIFile& ini)> SaveParamsType;
#else
    typedef boost::signal<void( INIFile& ini, hws::Version )> LoadParamsType;
    typedef boost::signal<void( INIFile& ini)> SaveParamsType;
#endif

    void PushSaveParams( SaveParamsType::slot_type slot, int pos=0 )
    {
#ifdef USE_BOOST_SIGNAL2
        m_sp_signal.connect(pos, slot, boost::signals2::at_front);
#else
        m_sp_signal.connect(pos, slot, boost::signals::at_front);
#endif
    }

    void PushLoadParams( LoadParamsType::slot_type slot, int pos=0 )
    {

#ifdef USE_BOOST_SIGNAL2
        m_lp_signal.connect(pos, slot, boost::signals2::at_back);
#else
        m_lp_signal.connect(pos, slot, boost::signals::at_back);
#endif
    }

    void PushSaveSequenceParams( SaveParamsType::slot_type slot, int pos=0 )
    {
#ifdef USE_BOOST_SIGNAL2
    	m_ssp_signal.connect(pos, slot, boost::signals2::at_back);
#else
    	m_ssp_signal.connect(pos, slot, boost::signals::at_back);
#endif
    }


    /////////////////////////////////////////////////////////////////////////
    INIFile& INI() {
        return *m_pini;
    }
    
    hws::Version HWS_Version() {
        return m_hws_version;
    }
    
    INIFile* m_pini;
    hws::Version m_hws_version;

    /////////////////////////////////////////////////////////////////////////
    
    ddk::CSampler& Sampler() { return m_sampler; } // TODO const
    ddk::CRecorder& Recorder() { return m_recorder; } // TODO const
    
    const vl::chrono::CTSChronometer& Clock() { return m_sampler.Clock(); }

private:
  
    // salta alla classe più specializzata che poi chiama all'indietro la sua classe base, fino a qui
    void On_LoadParams( INIFile& ini, hws::Version version );
    void On_SaveParams( INIFile& ini );
    void Recording_SaveParams( INIFile& ini );
    void Recording_SaveParams2( INIFile& ini );

    SaveParamsType m_ssp_signal;
    SaveParamsType m_sp_signal;
    LoadParamsType m_lp_signal;

    ui::wgt::NoteBook m_tabs;
    bool m_log_capture;
    const usr::CPathManager* m_ppath_mgr;
    ddk::CRecorder m_recorder;
    ddk::CSampler m_sampler;
};
}


#endif
