#ifndef _CSYSTEMCUSTOM_H
#define _CSYSTEMCUSTOM_H


#include <Devices/Custom/CCustom.h>
#include <DDK/CSystemDevice.h>

#include <UI/CWindows/CWindow.h>

#include <DDK/gold_ddk_export.h>

namespace ddk
{
class GOLD_DDK_EXPORT CCustom :
      public dev::CCustom,
      public ddk::Device
{
  public:
    typedef dev::CCustom DeviceType;

    CCustom();
    virtual ~CCustom();
    
  
    virtual void Notify(const FrameType& frame);
    
  protected:
    virtual void On_Initialization();
    virtual void On_ShutDown();
    
    virtual void On_WakeUp();
    virtual void On_Suspend();

    const char* DefaultFileFormat() { return ".txt"; }

    void FrameUpdate(const FrameType::DataType& data, const vl::chrono::TimeType& timestamp );
    
    void Preprocessing(FrameType& Frame);

    // void UI_Refresh(const FrameType::DataType& data);


    ui::wgt::Widget panel; // pannello
    
  private:
    void On_LoadParams( INIFile& ini, hws::Version version );
    void On_SaveParams( INIFile& ini );    
    void Recording_SaveParams ( INIFile& ini );
    
    void FrameRecording( const FrameType& frame );
      
    boost::shared_ptr<ui::win::CWindow> m_pWindow;
    FrameType m_src_frame;
};

} // namespace ddk 

namespace data
{
  
/** \brief Data used by dev::CCustom */
namespace stdstring
{
namespace serialization
{
  
typedef enum {TXT, BIN} FormatType;

GOLD_DDK_EXPORT void Load_BIN( std::istream& is, std::string& data, boost::property_tree::ptree& options );
GOLD_DDK_EXPORT void Load_TXT( std::istream& is, std::string& packet, boost::property_tree::ptree& options );

GOLD_DDK_EXPORT void Save_BIN( const std::string& packet, std::ostream& os, const boost::property_tree::ptree& options );
GOLD_DDK_EXPORT void Save_TXT( const std::string& packet, std::ostream& os, const boost::property_tree::ptree& options );

GOLD_DDK_EXPORT data::TFormatEnumerator<std::string>& FormatEnumerator();

} // namespace serialization
} // namespace stdstring
} // namespace data

  



#endif
