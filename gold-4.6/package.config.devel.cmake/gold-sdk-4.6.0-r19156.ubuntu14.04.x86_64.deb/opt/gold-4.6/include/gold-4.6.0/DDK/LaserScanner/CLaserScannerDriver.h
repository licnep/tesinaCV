#ifndef _DRIVER_LASERSCANNER
#define _DRIVER_LASERSCANNER

#include <DDK/Driver.h>

namespace dev {class CLaserScanner;}

namespace ddk
{
class CSystemLaserScanner;

class GOLD_DDK_EXPORT CDriver_LaserScanner :
  public ddk::CDriver
{
public:
  CDriver_LaserScanner(ddk::impl::CDriverInitializer& DrvInit);
  ~CDriver_LaserScanner();

protected:
  
  virtual DeviceDescriptor ConcreteDevice_Create( ddk::impl::CDeviceInitializer& dev_descr );
  void Register_Device(ddk::CSystemLaserScanner& dev);  // NOTE; anche private

private:

};
} // namespace ddk
#endif // _DRIVER_LASERSCANNER
