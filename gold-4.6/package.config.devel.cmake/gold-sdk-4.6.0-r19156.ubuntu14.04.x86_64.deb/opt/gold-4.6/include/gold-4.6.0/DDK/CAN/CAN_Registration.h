#ifndef __CCAN_REGISTRATION
#define __CCAN_REGISTRATION


#include <Libs/Patterns/Singleton.h>
#include <Libs/Patterns/Factory.h>
#include <Libs/Patterns/RegisterObject.h>

#include <DDK/CAN/CSystemCAN.h>

/** Registration stuff **/
namespace ddk
{
  
typedef vl::Factory< std::string, CSystemCAN> CCANFactoryType;

#define REGISTER_CAN(CLASS,STRNAME) vl::ObjectRegistrar< ddk::CCANFactoryType, CLASS > drf_##CLASS(STRNAME)
} // namespace ddk

#endif
