#ifndef _CPLAYBACK_UTILS_H
#define _CPLAYBACK_UTILS_H

#include <DDK/gold_ddk_export.h>

namespace ddk
{
namespace params
{
GOLD_DDK_EXPORT const char* SequenceName();
GOLD_DDK_EXPORT const char* SensorName();
GOLD_DDK_EXPORT const char* DefaultFileName();
}
}

#endif
