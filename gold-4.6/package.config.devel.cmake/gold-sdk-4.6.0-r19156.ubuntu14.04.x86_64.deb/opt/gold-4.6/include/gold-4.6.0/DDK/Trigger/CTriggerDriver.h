#ifndef _CTRIGGER_DRIVER
#define _CTRIGGER_DRIVER

#include <DDK/Driver.h>

namespace dev {class CTrigger;}

namespace ddk
{
  class CSystemTrigger;

class GOLD_DDK_EXPORT CDriver_Trigger :
  public ddk::CDriver
{
public:
  CDriver_Trigger(ddk::impl::CDriverInitializer& DrvInit);
  ~CDriver_Trigger();

protected:
  virtual ddk::CDriver::DeviceDescriptor ConcreteDevice_Create( ddk::impl::CDeviceInitializer& dev_descr );
  void Register_Device(CSystemTrigger& dev);

private:
};

} // namespace ddk

#endif // _CLASERSCANNER_MODULE
