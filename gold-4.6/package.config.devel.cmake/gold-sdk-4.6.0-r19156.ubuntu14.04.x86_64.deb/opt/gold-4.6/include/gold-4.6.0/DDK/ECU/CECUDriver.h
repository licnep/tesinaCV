/** \file CECUDriver.h
 *  \brief File per la classe CECUDriver
 *  \author Luca Gatti \<lucag@ce.unipr.it\>
 **/

#ifndef _CECU_MODULE
#define _CECU_MODULE

#include <DDK/Driver.h>


namespace dev { class CECU; }


namespace ddk
{
  
class CSystemECU;


class GOLD_DDK_EXPORT CDriver_ECU :
  public ddk::CDriver
{
public:
  CDriver_ECU(ddk::impl::CDriverInitializer& drv_init);
  ~CDriver_ECU();

protected:
  
  virtual DeviceDescriptor ConcreteDevice_Create( ddk::impl::CDeviceInitializer& dev_descr );
  void Register_Device(ddk::CSystemECU& dev);  // NOTE; anche private

private:

};

} // namespace ddk

#endif // _CECU_MODULE
