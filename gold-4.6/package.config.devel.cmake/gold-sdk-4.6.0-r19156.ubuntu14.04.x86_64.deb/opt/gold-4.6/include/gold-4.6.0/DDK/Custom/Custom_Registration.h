#ifndef __CCUSTOM_REGISTRATION
#define __CCUSTOM_REGISTRATION

#include <Libs/Patterns/Singleton.h>
#include <Libs/Patterns/Factory.h>
#include <Libs/Patterns/RegisterObject.h>

#include "CSystemCustom.h"

namespace ddk
{

/** Registration stuff **/
typedef vl::Factory<std::string, ddk::CCustom> CCustomFactoryType;

#define REGISTER_CUSTOM(CLASS,STRNAME) vl::ObjectRegistrar< ddk::CCustomFactoryType, CLASS > drf_##CLASS(STRNAME)
  
} // namespace ddk

#endif
