#ifndef SYSTEM_TRANSPORT_H
#define SYSTEM_TRANSPORT_H

#include <DDK/gold_ddk_export.h>

#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/thread/condition.hpp>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <queue>

#include <Framework/Transport.h> // TODO: integrare il framecounter qui dentro

#include <DDK/CFrameCounter.h> // TODO: integrare il framecounter qui dentro
#include <Libs/Threads/CTSQueue.hxx>
#include "TimeLine.h"

#include <Libs/Time/CChronometer.h>
#include <map>
#include <string>


//

// Probabilmente contiene due classi:
// - quella di sistema (wakeup, suspend ecc..)
// - quella utente (FrameCounter ecc..)
namespace sys
{
class GOLD_DDK_EXPORT Transport :
            public usr::Transport
{
public:
    Transport();
    
    virtual ~Transport();
    
    void Open ( const sys::TimeLine& tl );
    void Close();

    void WakeUp();
    void Suspend();
    void Next();
    void Prev();
    void Goto ( FrameCounter::ValueType frame );

    void Loop_OnFrame ( bool enabled );
    void Loop_OnSequence ( bool enabled );
    void Speed ( float speed );
    void ObeyPhysicalTime( bool obey );


    virtual const std::string& Path() const;
    virtual const std::string& Name() const;
    virtual const session::mode::ModeID Mode() const;
    virtual bool  HasEvents(const std::string& id) const;
    virtual const std::set<std::string>& EventIDs() const;



    virtual void Add_FrameCompletedChecker ( const std::string& name,
            boost::function<bool() > is_enabled,
            FrameCompletedCheckerType fcc
                                           );

    virtual void Remove_FrameCompletedChecker ( const std::string& name );

    virtual void Add_WaitForEndOfProcessing ( const std::string& name,
            boost::function<bool() > is_enabled,
            WaitForEndOfProcessingType wfeop
                                            );

    /**
      * return the frame counter
      * @return
      */
    virtual const FrameCounter& FrameCounter_() const
    {
        return m_frame_counter;
    }

    /**
      * return the current frame number
      * @return
      */
    virtual uint64_t FrameNumber() const
    {
        return m_frame_counter();
    }

    virtual uint64_t NumFrames() const
    {
        return m_frame_counter.NumFrames();
    }


    /**
      * Returns the current keyframe
      * @return reference to the the current keyframe
      */
    virtual const TimeLine::EventType& CurrentEvent() const
    {
        return *m_pCurrentFrame;
    }

    virtual bool IsFirstFrame() const;
    virtual bool IsLastFrame()  const;

    virtual const vl::chrono::AbsoluteTimeType& Origin() const;
    virtual const SegmentsType& Segments() const {
        return m_segments;
    }
    virtual const RecordingSegment& CurrentSegment() const {
        return m_segments[m_current_segment];
    }
    virtual uint64_t CurrentSegmentNum() const {
        return m_current_segment;
    }

    virtual bool Subscribe_EventNotification ( EventNotificationType f, const std::string& ID );
    virtual bool Subscribe_LoopOnFrame ( LoopOnFrameType f );

    virtual bool LoopOnFrame() const;
    virtual bool LoopOnSequence()const;
    virtual bool ObeyPhysicalTime()const;
    virtual float Speed()const;

    /// Bookmarks management
    void AddBookmark ( const std::string& Name="" );
    void AddBookmarks ( const std::string& Bookmarks );
    const BookmarksType&  Bookmarks() const;
    std::string Bookmarks_String() const;

    void GotoBookmark ( const std::string& Name="" );
    void NextBookmark();
    void PrevBookmark();
    void FirstBookmark();
    void LastBookmark();

private:
    typedef std::vector<boost::function<void ( uint64_t, const EventType& ) > > SignalType;


    /**
     * Frame Complete Checker Descriptor
     */
    struct FCC_Descriptor
    {
        FCC_Descriptor ( const std::string& _name,
                         boost::function< bool() > _is_enabled,
                         boost::function< bool() > _fcc
                       ) :
                name ( _name ),
                is_enabled ( _is_enabled ),
                fcc ( _fcc )
        {}
        std::string name;
        boost::function<bool() > is_enabled;
        boost::function<bool() > fcc;
    };

    bool fccd_has_name ( const FCC_Descriptor& fcd, const std::string& name );

    std::list<FCC_Descriptor>  m_fccd;
    typedef std::list<FCC_Descriptor>::iterator fcd_iterator;
    fcd_iterator m_selected_fcd; // fcd selected by the user
    fcd_iterator m_curr_fcd;     // current fcd: depends on apps status

    /**
     * Default frame complete checker:
     * every data complete a frame
     */
    bool def_fcc()
    {
        return true;
    }

    /**
     * Default frame complete checker name
     */
    const char* def_fcc_name() const {
        return "default";
    }

    /**
     * Default wait for end of processing function
     */
    void def_wfeop() {}

    void find_enabled_fccd();
    void find_enabled_wfeop();

    /**
     * Wait For End Of Processing Descriptor
     */
    struct WFEOP_Descriptor
    {
        WFEOP_Descriptor( const std::string& _name,
                          boost::function< bool() > _is_enabled,
                          boost::function< void() > _wfeop
                        ):
                name ( _name ),
                is_enabled ( _is_enabled ),
                wfeop ( _wfeop )
        {}
        std::string name;
        boost::function<bool() >  is_enabled;
        boost::function< void() > wfeop;
    };

    std::list<WFEOP_Descriptor>  m_wfeop;
    typedef std::list<WFEOP_Descriptor>::iterator wfeop_iterator;
    wfeop_iterator m_selected_wfeop; // wfeop selected by the user
    wfeop_iterator m_curr_wfeop;     // current wfeop: depends on apps status

    void Notify();

    void MoveTo ( unsigned long N );
    void MoveTo ( TimeLine::EventType::KeyType key  );
    void FindCurrentSegment();


    void playback_thread();
    boost::thread m_pb_thread;

    /// Condition Variable for syncronous commands
    boost::mutex        m_mutex;
    boost::condition    m_cond;
    status              m_status;
    status              m_prev_status;
    boost::condition    m_cond_sleep;
    boost::posix_time::time_duration first_event_key;
    boost::posix_time::time_duration m_last_notified;
    boost::posix_time::ptime first_event_abs;
    boost::posix_time::ptime now;

    bool                m_reset;  ///< true quando occorre eseguire il codice dopo un cambio di parametri

    float               m_speed;

    const TimeLine*     m_ptl;

    sys::FrameCounter   m_frame_counter;

    static uint64_t m_frame;


    uint64_t            m_current_frame_number;     ///< The current frame
    uint64_t            m_current_segment;          ///< The current segment
    const EventType*    m_pCurrentFrame;            ///< Pointer to the current frame in m_Events

    typedef std::map<std::string, SignalType*> SignalMap; /// type for mapping ID to the corresponding signal

    // NOTE: mutable per consentire ai players di registrare le callback da un oggetto const
    mutable SignalMap m_signals; ///< vettore di slot per la notifica degli eventi (ampio come il numero di id diversi)

    struct CNotificationInfo
    {
        SignalType*      pSignal;
        const EventType* pEvent;
        uint64_t         frame_number;
    };

    typedef std::vector<CNotificationInfo> SignalVectorType;
    std::vector<SignalVectorType> m_signal_vector;   ///< vector (with keyframes size) to signal the callbacks


#ifdef USE_BOOST_SIGNAL2
    typedef boost::signals2::signal<void()> LoopOnFrameSignalType;
#else
    typedef boost::signal<void()> LoopOnFrameSignalType;
#endif


    LoopOnFrameSignalType m_lof_signal;

    BookmarksType m_Bookmarks;

    bool m_loop_s;  ///< loop on sequence
    bool m_loop_f;  ///< loop on frame

    bool m_obey_physical_time;

    typedef enum {cmd_play, cmd_stop, cmd_next, cmd_prev, cmd_jump, cmd_speed, cmd_lof, cmd_los, cmd_ops} CmdType;
    struct Command
    {
        Transport::CmdType type;
        uint64_t frame;
        float speed;
        bool enabled;
    };

    vl::thread::CTSQueue<Command>  m_cmd_queue;
    vl::thread::CTSQueue<bool>     m_cmd_complete;


    SegmentsType m_segments;
    
    std::map<std::string, vl::chrono::Accumulator> m_stats;  // cronometro per profilare i tempi di caricamento

};

}


#endif // SYSTEM_TRANSPORT_H
