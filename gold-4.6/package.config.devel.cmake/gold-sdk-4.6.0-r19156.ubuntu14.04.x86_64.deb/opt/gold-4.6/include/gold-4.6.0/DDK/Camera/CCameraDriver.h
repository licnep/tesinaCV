#ifndef _CAMERA_DRIVER_H
#define _CAMERA_DRIVER_H

/** \file CCameraDriver.h
 *  \brief Acquisition Device Interface Files
 *  Inteface for class ddk::TCameraDriver
 *  \author Paolo Grisleri \<grisleri@ce.unipr.t\>
 **/

#include <string>
#include <map>

#include <Framework/CDynamicModulesLoader.h>
#include <Framework/CPathManager.h>
#include <Framework/CSession.h>
#include <Devices/Camera/CCamera.h>

#include <DDK/Driver.h>
#include <DDK/Camera/CSystemCamera.h>


/// Prototipo della classe ddk::TCameraDriver
namespace dev {class CDeviceManager;}

namespace ddk
{

template <class ConcreteDev, class UsrDev=dev::CCamera>
class TCameraDriver :
  public ddk::CDriver
{
public:

    TCameraDriver(ddk::impl::CDriverInitializer& Initializer) :
            ddk::CDriver(Initializer)
    {
    }


    virtual ~TCameraDriver(void) {}               /// dtor

protected:

    typedef ConcreteDev ConcreteDevType;
    typedef UsrDev UsrDevType;    
    typedef ddk::impl::DeviceInitializersType::const_iterator ItrType;
    typedef std::vector<ConcreteDevType *> ConcreteDevList;

    void Cameras_Create() {std::cout << "CCameraDriver::Cameras_Create called exiting. This driver needs to be updated" << std::endl; exit(0); }
    
    virtual DeviceDescriptor ConcreteDevice_Create( ddk::impl::CDeviceInitializer& dev_descr )
    {
      DeviceDescriptor retval;
      ConcreteDevType* tmp_dev = new ConcreteDevType();
      retval.pdev = tmp_dev;
      On_ConcreteDevice_Creation(dev_descr, *tmp_dev);
      retval.reg = boost::bind(&ddk::TCameraDriver<ConcreteDev,UsrDev>::Register_Device, this, boost::ref(*tmp_dev));
      retval.unreg = boost::bind(&ddk::TCameraDriver<ConcreteDev,UsrDev>::Unregister_Device, this, boost::ref(*tmp_dev));
      return retval;
    }
    
    // questa serve se il driver deve fare delle configurazioni al device 
    // prima che il device esegua la sua procedura di inizializzazione
    virtual void On_ConcreteDevice_Creation(ddk::impl::CDeviceInitializer& dev_init, ConcreteDevType& obj) {}
    
    // TODO questa dealloca il singolo device
    virtual void ConcreteDevice_Destroy( SysDevType::value_type ) {}
    
   /**
     * Register one single camera in the internal structures of the ddk::TCameraDriver
     * @param Camera pointer to the camera to be registered
     * @param LocalCameras The local camera map of the derived ADI
     */
    void Register_Device(ConcreteDevType& dev)
    {
        m_cameras.insert(std::make_pair(dev.Name_(), &dev));
        m_sys_cams.push_back( &dev );
        Insert_DeviceNode(new dev::CDeviceLeaf(dev.Name_(), &dev));  // NOTE: UsrDevType here?
    }
    
    void Unregister_Device(ConcreteDevType& dev)
    {
      Remove_DeviceNode(dev.Name_());
      delete &dev;
    }    
    
    void On_Devices_Clear() 
    {
        Cameras_Destroy();
    }
        

    virtual void On_Preprocessor_Initialization(dev::CDeviceManager& devices, const usr::CPathManager& path_manager)
    {
        // std::cout << "preprocmod: CCameraDriver::On_Preprocessor_Initialization"<< m_sys_cams.size() << std::endl;
        for ( typename ConcreteDevList::iterator itr=m_sys_cams.begin(); itr!=m_sys_cams.end(); ++itr )
            (*itr)->Initialize_Preprocessor(devices, m_cameras);
    }


    void Cameras_Destroy()
    {
        // TODO: spostare questo codice in ddk::CDriver
        m_cameras.clear();
        m_sys_cams.clear();
    }


    /**
     *  metodo che permette di eseguire la stessa operazione su tutte le camere
     *
     * @param f operazione da eseguire
     */
    template<typename Function>
    void for_each_device(Function f)
    {
        std::for_each(m_sys_cams.begin(), m_sys_cams.end(), f);
    }

    typename ConcreteDevList::iterator SysCams_begin() 
    {
        return m_sys_cams.begin();
    }
    
    typename ConcreteDevList::iterator SysCams_end()   
    {
        return m_sys_cams.end();
    }

    bool SysCams_empty() const 
    {
        return m_sys_cams.empty();
    }

private:
    
    dev::CCameraMap m_cameras;  ///< Mappa delle camere utente (nec x preproc)
    ConcreteDevList m_sys_cams;  ///< Lista dei ConcreteDevType allocati (nec x preproc)
    vl::CDynamicModulesLoader m_dml; ///< oggetto statico per il caricamento dei plugin
};

} // namespace ddk

#endif
