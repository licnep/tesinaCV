#ifndef _DRIVER_H
#define _DRIVER_H

#include <string>
#include <list>

#include <boost/function.hpp>
#include <DDK/gold_ddk_export.h>

#include <Framework/CModule.h>
#include <Framework/CDeviceManager.h> // serve per CLinkToDeviceNode
#include <Framework/HWS_Version.h>
#include <DDK/CSystemDevice.h>
#include <Libs/Time/CChronometer.h>

namespace vl{ namespace ini {class INIFile;} } using vl::ini::INIFile;
class TimeLine;
namespace usr
{
class CPathManager;
class Transport;
}


/** \brief Namespace for drivers */
namespace drv {}

/** \brief Classes and declaration of the Driver Development Kit*/
namespace ddk
{
// NOTE: queste servono a chi istanzia il driver e non a chi lo implementa
// impl non è il namespace corretto: ci vuole un altro namespace o un altro file
// da fare dopo l'arrivo del tool per sostituire projectwide
namespace impl
{
// oggetti necessari per la inizializzazione di un device
struct GOLD_DDK_EXPORT CDeviceInitializer
{
public:
    CDeviceInitializer() : m_ini(0), m_ini_version(hws::V_1_0) {}
    CDeviceInitializer(const std::string& name,
                       const std::string& path,
                       INIFile& ini_section,
                       hws::Version ini_version
                      ) :
            m_name(name),
            m_path(path),
            m_ini(&ini_section),
            m_ini_version(ini_version)
    {}

    const std::string& Name() const {
        return m_name;
    }

    const std::string& Path() const {
        return m_path;
    }
    INIFile& INI() {
        return *m_ini;
    }

    hws::Version INIVersion() const {
        return m_ini_version;
    }

private:
    std::string  m_name;
    std::string  m_path; // percorso nell'albero dei device
    INIFile*     m_ini;  // oggetto per l'accesso alle variabili
    hws::Version m_ini_version;
};

typedef std::vector<CDeviceInitializer> DeviceInitializersType;

class GOLD_DDK_EXPORT CDriverInitializer
{
public:
    void AddSubNode(const std::string& name,
                    const std::string& path,
                    INIFile& ini_section,
                    hws::Version ini_version);
    DeviceInitializersType SubNodes;
};

} // namespace impl


// oggetti necessari per la inizializzazione di un device
class GOLD_DDK_EXPORT CDriver :
            public usr::CModule
{
public:


    CDriver(impl::CDriverInitializer& initializer);
    virtual ~CDriver();

    void Connect(const usr::CPathManager& path_manager);

    void Initialize( usr::Transport& tr );
    void Initialize_Clock(const vl::chrono::CTSChronometer& clock);
    void Initialize_Preprocessor(dev::CDeviceManager& Devices, const usr::CPathManager& path_manager );

    void  Devices_Build();
    void  Devices_Clear();

    void  Devices_Share(dev::CDeviceManager& devices);

    /// Propaga il comando di preprocessing alle camere
    /// TODO: deve ricevere tutto l'albero dei devices
    void Preprocess();

    typedef std::vector<ddk::Device*> SysDevType;
    SysDevType& SysDev() {
        return m_base_sys_dev;
    }

    dev::CDeviceNode& Devices();

protected:
    void Insert_DeviceNode(dev::CDeviceNode* node);
    void Remove_DeviceNode(const std::string& path);

    const impl::DeviceInitializersType & DeviceInitializers() const;

    void AddChild(ddk::Device& device);
    void DelChild ( ddk::Device& dev );

    void On_Initialization ( const vl::chrono::CTSChronometer& Clock );

    virtual void On_Initialization( usr::Transport& tr ) {}  ///< Called when the player must be initialized

    // TODO in modo analogo si può memorizzare una mappa con tutte features: nome,register,unregister
    struct DeviceDescriptor
    {
        ddk::Device* pdev;
        boost::function<void()> reg;
        boost::function<void()> unreg;
    };

    virtual DeviceDescriptor ConcreteDevice_Create(impl::CDeviceInitializer& dev_init)
    {
        // TODO: questa deve essere implementata da tutti i driver
        throw std::runtime_error("Unimplemented ConcreteDevice_Create");
    }


    /**
    * Quando questa viene chiamata i dispositivi registrati sono già cancellati
    */
    virtual void On_Devices_Clear() {}

    /**
    * Chiamata quando tutti i dispositivi sono stati inizializzati
    * @param Devices DeviceManager popolato con i dispositivi nativi
    */
    virtual void On_Devices_Share(dev::CDeviceManager& devices) {};

    /**
    * Chiamata dopo la Device_Share, quando anche i device di secondo livello sono stati inizializzati
    * @param Devices permette l'inizializzazione dei preprocessori
    */
    virtual void On_Preprocessor_Initialization(dev::CDeviceManager& devices, const usr::CPathManager& path_manager) {}

    // NOTE Il driver non decide dove i device salveranno i dati:
    // lo fa CDriverManager.

    // Salvare qui eventuali parametri di funzionamento del driver
    virtual void On_SaveParams(INIFile& ini) {}

private:
    void DeviceTree_delete();

    dev::CDeviceTree     m_device_tree;    ///< the local device tree
    impl::DeviceInitializersType m_device_initializers;

    std::vector<DeviceDescriptor> m_device_descriptors;

    SysDevType m_base_sys_dev;

    // TODO: eseguire qui la cancellazione dei device ed eliminare le mappe locali
    const usr::CPathManager* m_ppath_mgr;
};

} // namespace ddk


#endif
