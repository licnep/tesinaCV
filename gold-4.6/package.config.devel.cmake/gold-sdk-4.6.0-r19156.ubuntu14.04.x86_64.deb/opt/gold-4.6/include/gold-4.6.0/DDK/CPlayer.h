#ifndef _CPLAYER_H
#define _CPLAYER_H

#include <Libs/Time/CChronometer.h>

#include <Devices/Base/CSampler.h>
#include <Framework/CEvent.h>

#include <Framework/Transport.h>
#include <Framework/FrameNumberUtils.h>
#include <DDK/CSampler.h>
#include <Framework/HWS_Version.h>

// TODO: raccogliere i Devices/Base o in Libs
#include <Devices/CDiskWriter/VLA_Archive.h>
#include <Devices/CDiskWriter/TAR_Archive.h>

namespace ddk
{

typedef enum {DIRECT, FRAME} StoragePolicy;

namespace params
{
namespace player
{
GOLD_DDK_EXPORT const char* FileName();
}
}

class GOLD_DDK_EXPORT CPlayer
{
public:

protected:
    typedef enum {NONE, TAR, VLA} ContainerType;

    CPlayer ();
    virtual ~CPlayer() {}

    void Initialize ( usr::Transport& tr, StoragePolicy sp, ddk::CSampler& sampler, const std::string& track_name );
    void Close();


    void On_LoadParams( INIFile& ini, hws::Version version );
    void On_SaveParams( INIFile& ini );

    const std::string& Container() const {
        return m_container;
    }
    const std::string& IPath() const {
        return m_ipath;
    }
    const std::string& IName() const {
        return m_iname;
    }
    
    const std::string& TrackName() const {
        return m_track_name;
    }    

    const std::string& FileName() const;
    const std::string& Extension() const;

    usr::Transport& Transport_() {
        return *m_pTr;
    }

    const std::string& _Name() const;

    bool CheckVersion() const {
        return m_check_version;
    }

    /**
     * Metodo invocato al termine del caricamento (con successo) di un nuovo oggetto
     */
    virtual void On_Load(const std::string& file_name, const data::CEvent& event) {}
    virtual void On_Build(const data::CEvent& event) {}

    vla::Reader m_vla_reader;
    tar::Reader m_tar_reader;

private:

    void On_Event_Notification(uint64_t frame_number, const data::CEvent& event);
    void (CPlayer::*Do_Load)(uint64_t frame_number, const data::CEvent& event);

    template <StoragePolicy S>
    void Load(uint64_t frame_number, const data::CEvent& event);

    std::string m_track_name;
    std::string m_url;
    std::string m_ipath;
    std::string m_container;
    std::string m_iname;

    std::string m_preexpanded_filename;
    std::string m_filename;
    std::string m_extension;

    usr::Transport*  m_pTr;

    bool m_check_version;

    ddk::CSampler* m_psampler;

    vl::chrono::CChronometer m_chrono;  // cronometro per profilare i tempi di caricamento
    INIFile* m_pini;
};


}


#endif //_CPLAYER_H

