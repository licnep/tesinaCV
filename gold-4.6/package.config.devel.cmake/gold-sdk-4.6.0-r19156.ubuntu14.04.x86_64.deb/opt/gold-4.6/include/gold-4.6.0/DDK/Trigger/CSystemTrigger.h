#ifndef _CSYSTEMTRIGGERX_H
#define _CSYSTEMTRIGGERX_H

#include <Devices/Trigger/Trigger.h>
#include <DDK/CSystemDevice.h>


class CWindow;

namespace ddk
{
  
class GOLD_DDK_EXPORT CSystemTrigger :
      public dev::CTrigger,
      public ddk::Device
{
  public:
    typedef CTrigger DeviceType;

    CSystemTrigger();
    virtual ~CSystemTrigger();
    
  protected:

    virtual void On_Initialization();
    virtual void On_ShutDown();


    // virtual void On_Deadline_Expired() = 0;
    // The thread function can be overwritten 
    // to implement driver complex behaviors 
    virtual void Thread() = 0;
    
    void WriteEventToDisk ();
  
  private:
    void On_LoadParams( INIFile& ini, hws::Version version );
    void On_SaveParams( INIFile& ini );    
    void Recording_SaveParams( INIFile& ini );    
    
    ddk::CSampler::CounterType  m_counter;
};

} // namespace ddk

#endif
