#ifndef __CLASERSCANNER_REGISTRATION
#define __CLASERSCANNER_REGISTRATION

#include <Libs/Patterns/Singleton.h>
#include <Libs/Patterns/Factory.h>
#include <Libs/Patterns/RegisterObject.h>

#include "CSystemLaserScanner.h"

namespace ddk
{

/** Registration stuff **/
typedef vl::Factory<std::string, ddk::CSystemLaserScanner> CLaserScannerFactoryType;

} // namespace ddk

#define REGISTER_LASERSCANNER(CLASS,STRNAME) vl::ObjectRegistrar< ddk::CLaserScannerFactoryType, CLASS > drf_##CLASS(STRNAME)


#endif
