/** \file   DDK/CSampler.h
 *  \brief  Base class device that can sample data like sensors and buses
 *  Documentation here
 *  \example:
 *      TODO
 */

#ifndef _DDK_SAMPLER_H
#define _DDK_SAMPLER_H

#include <string>
#include <boost/date_time/posix_time/posix_time_types.hpp>

#include <UI/Panel/Widgets.h>

#include <Libs/Time/TimeUtils.h>
#include <Libs/Time/CChronometer.h>
#include <Devices/Base/CSampler.h>
#include <DDK/gold_ddk_export.h>


namespace ddk
{
class GOLD_DDK_EXPORT CSampler :
            public dev::CSampler
{
public:
    CSampler();
    virtual ~CSampler();
    
    /**
     * Returns the current framenumber. 
     * The framenumber of a certain data is the same 
     * across multiple playback of the same recording
     * It has no meaning in HW mode.
     * @return
     */
    virtual CounterType FrameNumber() const {
        return m_frame_number;
    }

    /**
     * Returns the number of captured samples
     * Always increasing in both hardware and playback
     * @return
     */
    virtual CounterType FrameCounter() const;
    
    /**
     * Returns the number of captured samples
     * Always increasing in both hardware and playback
     * @return
     */
    virtual CounterType NumSamples() const;

    /// User interface for sensor timestamp
    virtual const vl::chrono::AbsoluteTimeType& VirtualOrigin() const;
    
    virtual const vl::chrono::TimeType& TimeStamp() const {
        return m_TimeStamp;
    }
    virtual const vl::chrono::TimeType& Duration() const {
        return m_Duration;
    }

    /**
     * Ritorna il tempo trascorso tra la ricezione
     * degli ultimi due campioni
     * @return TimeType: periodo tra gli ultimi due campioni
     */
    virtual const vl::chrono::TimeType& LastDelta() const {
        return m_DeltaT;
    }

    /**
     * Ritorna true se il LastDelta è valido, false altrimenti
     * Il LastDelta è invalido al primo frame dopo un wakeup
     * @return bool: LastDelta valido
     */
    virtual bool IsLastDeltaValid() const {
        return !m_skip_first;
    }

    /**
     * Metodi di accesso alle statistiche sui tempi di arrivo dei campioni
     * User_Accumulator per i campioni resi disponibili all'utente
     * Capture_Accumulator per i campioni del thread di cattura
     * @return AccumulatorType, see boost::accumulators library doc
     */
    virtual const AccumulatorType& Accumulator() const {
        return m_acc;
    }

    /** 
     * Returns the average framerate computed from the samples
     * \return the current fps in [Hz]
     */
    virtual double Avg_FrameRate() const;

    virtual void Print(const AccumulatorType& acc, unsigned int indent=2) const; 

    void SetFrameNumber(CounterType FrameNumber) {
        m_frame_number = FrameNumber;
    }
    void PushStatistics(const std::string& label, const AccumulatorType& acc);
    void Pause();
    
// protected:

    void Initialize ( const vl::chrono::CTSChronometer& Clock ) {
        m_pClock = &Clock;
    }
    void Initialize ( usr::Transport& tr ) {
        m_pTR = &tr;
    }

    // manca l'info nell'identificativo che rende conto del fatto che è teorico/dichiarato
    void SetFramePeriod(const vl::chrono::TimeType& frame_period) {
        m_frame_period = frame_period;
    }

    void Update ( const vl::chrono::TimeType& TimeStamp, const vl::chrono::TimeType& Duration=vl::chrono::TimeType() );

    const vl::chrono::CTSChronometer& Clock() const {
        return *m_pClock;
    }

    void Reset();

    /**
     * This method remove the registered callbacks
     */
    void UnregisterObservers();

    ui::wgt::Widget panel;

private:
    const vl::chrono::CTSChronometer* m_pClock; ///< Accesso al clock di sistema
    const usr::Transport* m_pTR;

    bool m_skip_first;

    vl::chrono::TimeType m_TimeStamp;
    vl::chrono::TimeType m_DeltaT;
    vl::chrono::TimeType m_Duration;

    vl::chrono::TimeType m_frame_period;

    CounterType m_frame_number;///< numero del frame (quello nel nome del file o l'indice nel MEF) in una sequenza

    AccumulatorType m_acc;

    ui::wgt::VSizer  m_vs;

    struct stat_entry
    {
        ui::wgt::Widget label;
        ui::wgt::Widget unit;
        ui::wgt::Widget value;
    };

    struct stat_group
    {
        stat_entry count;
        stat_entry last;
        stat_entry min;
        stat_entry max;
        stat_entry avg;
        stat_entry sdv;
    };

    std::vector<stat_group> m_stats;
    char m_buffer[100]; // buffer per la conversione
    void Update_UI(unsigned int offset, const AccumulatorType& acc);
};

} // namespace dev

#endif // _CSAMPLER_H
