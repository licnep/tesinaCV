#ifndef _TGNSSDRIVER_H
#define _TGNSSDRIVER_H

#include <DDK/Driver.h>
#include <DDK/GNSS/CSystemGNSS.h>
#include <DDK/gold_ddk_export.h>

namespace ddk
{
template<typename ConcreteDeviceType>
class GOLD_DDK_EXPORT CDriver_GNSS:
    public ddk::CDriver
{
public:
    CDriver_GNSS ( ddk::impl::CDriverInitializer& drv_init ) :
        ddk::CDriver( drv_init )
    {}
    
    virtual ~CDriver_GNSS() {}
    
    virtual ddk::CDriver::DeviceDescriptor ConcreteDevice_Create( ddk::impl::CDeviceInitializer& dev_descr )

    {
        // ddk::CDriver::DeviceDescriptor retval;
        // T* gnss=new T(dev_descr.INI());
        // retval.pdev = gnss;
        // retval.reg = boost::bind(&TGNSSDriver<T>::Register_Device, this, boost::ref(*gnss));
        // return retval;

        CDriver::DeviceDescriptor retval;

        // Estrae dall'HWS tutti i nomi delle camere ed il driver da usare
        INIFile& ini=dev_descr.INI();       // alias per il nodo in esame
        {
            // carica VENDOR e MODEL del LS in esame
            std::string vendor=ini.Value<std::string> ( "VENDOR", "Not specified" );
            std::string model=ini.Value<std::string> ( "MODEL", "Not specified" );

            std::string key=vendor+"::"+model;

            // GNSSFactoryType::AbstractAllocatorType allocator = vl::Singleton<GNSSFactoryType>::Instance().GetAllocator( key );

	    ddk::CSystemGNSS* pdev = new ConcreteDeviceType();
	    retval.pdev = pdev;
	    retval.reg = boost::bind(&CDriver_GNSS::Register_Device, this, boost::ref(*pdev));
	    // TODO: retval.unreg = boost::bind(&CDriver_LaserScanner::AddChild, this, pls);
        }
        return retval;
    }

    void Register_Device( ddk::CSystemGNSS& dev )
    {
        Insert_DeviceNode ( new dev::CDeviceLeaf ( dev.Name_(), &dev ) );
    }
};
} // namespace ddk

#endif
