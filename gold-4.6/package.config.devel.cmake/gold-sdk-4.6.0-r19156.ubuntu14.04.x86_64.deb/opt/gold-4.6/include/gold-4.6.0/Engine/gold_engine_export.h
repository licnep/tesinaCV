
#ifndef GOLD_ENGINE_EXPORT_H
#define GOLD_ENGINE_EXPORT_H

#ifdef GOLD_ENGINE_STATIC_DEFINE
#  define GOLD_ENGINE_EXPORT
#  define GOLD_ENGINE_NO_EXPORT
#else
#  ifndef GOLD_ENGINE_EXPORT
#    ifdef gold_engine_EXPORTS
        /* We are building this library */
#      define GOLD_ENGINE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define GOLD_ENGINE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef GOLD_ENGINE_NO_EXPORT
#    define GOLD_ENGINE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef GOLD_ENGINE_DEPRECATED
#  define GOLD_ENGINE_DEPRECATED __attribute__ ((__deprecated__))
#  define GOLD_ENGINE_DEPRECATED_EXPORT GOLD_ENGINE_EXPORT __attribute__ ((__deprecated__))
#  define GOLD_ENGINE_DEPRECATED_NO_EXPORT GOLD_ENGINE_NO_EXPORT __attribute__ ((__deprecated__))
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define GOLD_ENGINE_NO_DEPRECATED
#endif

#endif
