#ifndef GOLD_COMMANDS_H
#define GOLD_COMMANDS_H

#include "Command.h"
#include <Engine/gold_engine_export.h>

// comandi delle implementazioni interfacce utente

class CEngine;

namespace engine
{
namespace cmd
{
class GOLD_ENGINE_EXPORT Start :
            public Command
{
public:
    void Execute(sys::CEngine& engine);
};

class GOLD_ENGINE_EXPORT Stop :
            public Command
{
public:
    void Execute(sys::CEngine& engine);
};

class GOLD_ENGINE_EXPORT Start_Stop :
            public Command
{
public:
    void Execute(sys::CEngine& engine);
};


class GOLD_ENGINE_EXPORT Next :
            public Command
{
public:
    void Execute(sys::CEngine& engine);
};

class GOLD_ENGINE_EXPORT Prev :
            public Command
{
public:
    void Execute(sys::CEngine& engine);
};


class GOLD_ENGINE_EXPORT  Goto :
            public Command
{
    unsigned long m_Frame;
public:
    Goto(unsigned long Frame);
    void Execute(sys::CEngine& engine);
};


class GOLD_ENGINE_EXPORT Refresh :
            public Command
{
public:
    void Execute(sys::CEngine& engine);
};


class GOLD_ENGINE_EXPORT Quit :
            public Command
{
public:
    void Execute(sys::CEngine& engine);
};


namespace playback
{
class GOLD_ENGINE_EXPORT  Speed :
            public Command
{
    double m_pb_speed;
public:
    Speed(double pb_speed);
    void Execute(sys::CEngine& engine);
};


class GOLD_ENGINE_EXPORT ObeyPhysicalTime :
            public Command
{
    bool m_obey_physical_time;
public:
    ObeyPhysicalTime(bool obey);
    void Execute(sys::CEngine& engine);
};


class GOLD_ENGINE_EXPORT LoopOnSequence :
            public Command
{
    bool m_Loop;
public:
    LoopOnSequence(bool Loop);
    void Execute(sys::CEngine& engine);
};

class GOLD_ENGINE_EXPORT LoopOnFrame :
            public Command
{
    bool m_Loop;
public:
    LoopOnFrame(bool Loop);
    void Execute(sys::CEngine& engine);
};

}





namespace session
{


class GOLD_ENGINE_EXPORT Open :
            public Command
{
public:
    Open(const std::string& session_path);
    void Execute(sys::CEngine& engine);

private:
    std::string m_session_path;
};


namespace rec
{


class GOLD_ENGINE_EXPORT Start :
            public Command
{
public:
    void Execute(sys::CEngine& engine);
};

class GOLD_ENGINE_EXPORT Stop :
            public Command
{
public:
    void Execute(sys::CEngine& engine);
};

class GOLD_ENGINE_EXPORT Flush :
            public Command
{
public:
    void Execute(sys::CEngine& engine);
};

} // namespace rec

namespace bookmark
{
class GOLD_ENGINE_EXPORT Add :
            public Command
{
public:
    void Execute(sys::CEngine& engine);
};

class GOLD_ENGINE_EXPORT Prev :
            public Command
{
public:
    void Execute(sys::CEngine& engine);
};


class GOLD_ENGINE_EXPORT Next :
            public Command
{
public:
    void Execute(sys::CEngine& engine);
};

} // namespace bookmark

} // namespace session

namespace scheduler
{

class GOLD_ENGINE_EXPORT EnableApp :
            public Command
{
public:
    EnableApp(const std::string& Name, bool Enable);
    void Execute(sys::CEngine& engine);
};

} // namespace scheduler

} // namespace cmd

} // namespace engine
#endif
