/** \file schedule.h
 *  \brief Classe per controllare le applicazioni
 **/
#ifndef _SCHEDULE_H
#define _SCHEDULE_H

#include <vector>

#include <boost/thread/thread.hpp>
#include <boost/ptr_container/ptr_vector.hpp>

#include <Framework/CDynamicModulesLoader.h>
#include <Framework/CModule.h>
#include <Framework/CDeviceManager.h>
#include <Framework/CPathManager.h>
#include <Libs/Time/CChronometer.h>
#include <Libs/Threads/CSuspendable.hxx>

#include <Engine/gold_engine_export.h>

namespace vl{ namespace ini {class INIFile;} } using vl::ini::INIFile;
namespace usr { class CApplication; }
namespace dev { class CProfiler; }


namespace sys
{

/** Scheduler delle applicazioni
 **/
class GOLD_ENGINE_EXPORT CScheduler :
            public usr::CModule
{
    /// Azione da compiere in uscita
    enum SaveState_t
    {
        Save_None,
        Save_Ask,
        Save_Always
    };

    typedef enum {INSTALLED, UNDER_DEV} AppModeType;
    typedef enum {PERIODIC, DATA_DRIVEN} SchedType;

    /// Tipo di azione possibile a seguito di una eccezione
    enum OnException_t
    {
        OnException_Disable_App,
        OnException_Restart_App,
        OnException_Quit
    };
    
    struct Options
    {
      std::string app_name;
      std::string class_id;
      bool exists;
      bool visible;
      bool enabled;
      bool compat_4_5;
      SchedType sched_type;
      vl::chrono::TimeType period;
      AppModeType mode;
    };    

    /// Contesto dell'applicazione schedulata
    struct AppContext
    {
        usr::CApplication*  app;     ///< Application
        vl::chrono::CChronometer*     timings; ///< Profiling info
        bool              retval;  ///< Last Returned value
        std::string       err;     ///< Error returned via exception
        unsigned int      enable_counter; ///< Count how many times the apps has been activated
        unsigned int      restart_count;  ///< Restart counter
        boost::mutex*     mtx;     ///< mutex for exclusive access to the application
        boost::condition* cnd;     ///< thread wait when application is disabled
        SchedType         sched_type; ///< user selected scheduling type
        bool              compat_4_5; ///< false: execute the synchronization stuff here
        vl::chrono::TimeType          period;  ///< period to respect
        boost::thread*    thread;  ///< The application thread
        bool              tokens;
        AppModeType       mode;    ///< Application mode
        vl::thread::Semaphore* m_eop_sem;  ///< semaphore for end of processing notification to the Transport
        OnException_t     exception_behaviour; /// azione da compiere dopo una eccezione

        AppContext();

        /**
          * metodo thread per la gestione di una applicazione
          * @param AppContext contesto dell'applicazione
          */
        void Thread_FS();
        void Thread_HZ();
        void Thread_DD();

        void Initialize(usr::CApplication* _app,
                        const Options& options,
                        const std::string& _err,
                        usr::Transport* ptr);

        void ShutDown();

        ~AppContext();

        // TODO: spostarlo nella classe?
        // INIFile *ini; /// File INI per questo oggetto
        // int priority; /// valore della priorita' di questa funzione

        class NameIs
        {
            std::string m_name;

        public:
            NameIs(const std::string& name) : m_name(name) {}
            bool operator()(const AppContext& TaskInfo);
        };
    };


    typedef boost::ptr_vector< usr::CApplication > AppsList; /// Tipo per elenco delle applicazioni
    typedef std::vector< AppContext > AppCtxList;       /// Tipo per elenco delle info correlate



private:
    vl::CDynamicModulesLoader m_DML;
    INIFile*     m_pINI; /// file con le opzioni dello scheduler
    AppsList     m_apps; /// lista delle informazioni aggiuntive correlate ai task
    AppCtxList   m_ctxs; /// lista delle informazioni aggiuntive correlate ai task
    SaveState_t  m_save; /// azione da compiere in uscita

    bool m_merge_private;              /// Merge using private parameters
    usr::CPathManager::PathsMap m_Paths;    /// store paths for the application

    /// dynamic module loader
    unsigned int m_tokens;

public:
    CScheduler ( );
    ~CScheduler();

    void Initialize_Activated_Apps();

    void SetININode(INIFile *ini ) {
        m_pINI = ini;
    }
    void SetPaths(const usr::CPathManager::PathsMap& paths) {
        m_Paths=paths;
    }
    // FIXME: serve un modo per sapere se siamo in buil o installation mode
    void SetSession(usr::CSession& session) {
        m_pSession=&session;
    }
    
    /** Aggiunge una applicazione alla lista
     * Permette di lanciare una applicazione a RUN-TIME!
     * @return true se la applicazione' e' stata trovata, false altrimenti
     */
    void CreateTask ( const Options& options );

    /// ritorna la lista dei task
    AppsList& Tasks() {
        return m_apps;
    }
    const AppsList& Tasks() const {
        return m_apps;
    }

    /// imposta lo stato della applicazione
    void Task_SetStatus ( const std::string& name, bool enabled );

    /// trova una applicazione dal nome
    CScheduler::AppContext& Task_Find( const std::string& name );

    void Devices_Share(dev::CDeviceManager& Devices);
    void Initialize_Profiler(dev::CProfiler& Profiler);

protected:

    virtual void On_Initialization();
    virtual void On_Initialization(usr::Transport& tr);
    virtual void On_ShutDown();

    virtual void On_WakeUp();
    virtual void On_Suspend();
    virtual void On_Next();
    virtual void On_Prev();
    virtual void On_Goto(unsigned long frame);

    /**
     * Chiamata quando tutti i dispositivi sono stati inizializzati
     * @param Devices DeviceManager popolato con i dispositivi nativi
     */
    virtual void On_Devices_Share(dev::CDeviceManager& devices)
    {
        m_pDev=&devices;
    }

private:

    /**
      * metodo interno per il settaggio dello status
      * @param task AppContext di cui settare lo stato
      * @param enabled true se abilitato, false altrimenti
      */
    void Task_SetStatus ( AppContext& task, bool enabled );

    dev::CProfiler* m_pProfiler; ///< The profiler
    dev::CDeviceManager* m_pDev; ///< The Device Tree
    usr::CSession* m_pSession;   ///< The session
    usr::Transport* m_ptr;            ///< The transport
    
    // TODO: convertire in un boost::property_tree
    std::map<std::string, Options> m_options;    ///< mappa con le opzioni lette da file 
};

}
#endif


