#ifndef SYS_PATH_MANAGER
#define SYS_PATH_MANAGER

#include <Framework/CPathManager.h>
#include <Engine/SessionBrowsingInfo.h>

#include <Engine/gold_engine_export.h>

namespace sys
{
class GOLD_ENGINE_EXPORT PathManager:
            public usr::CPathManager
{
public:
    PathManager();
    ~PathManager();

    /** 
     * Crea una serie di percorsi scrivibili
     * Deve esistere il percorso superiore
     * @param multi_path lista di percorsi separati da {',' ' ' }
     * @return boost::system::system_error con il valore di errore corrispondente
     * boost::system::errc::success se ha creato
     */
    boost::system::system_error CreateMultiPath(const std::string& multi_path) const;

    /** 
     * Crea un file scrivibile nel primo percorso di output
     * ritorna il nome completo del file creato
     */
    std::string BuildName(const std::string& path, const std::string& name) const;

    /** 
     * Sfoglia il filesystem locale in base al contenuto di SessionBrowsingInfo
     * @param sbi informazioni di browsing
     */
    void Browse(engine::SessionBrowsingInfo& sbi);

    
    /** 
     * Stampa i percorsi su std::cout
     */
    void PrintPaths();

private:
};

}

#endif // SYS_PATH_MANAGER
