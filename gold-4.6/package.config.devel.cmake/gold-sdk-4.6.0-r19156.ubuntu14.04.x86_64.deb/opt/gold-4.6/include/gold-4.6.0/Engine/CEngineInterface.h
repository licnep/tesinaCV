/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.ARGO.ce.unipr.it                                  *
 *                                                                    *
 **********************************************************************/

#ifndef _GOLD_H
#define _GOLD_H

/** @file gold.h
 *  @brief Interfaccia pubblica di GOLD
 *  @note
 **/
#include <Engine/gold_engine_export.h>
#include "Command.h"

/// forward declarations
namespace usr{class CSession;} 
namespace dev
{
class CDeviceManager;
}
namespace sys
{
class CScheduler;
}

// Questa non deve essere visibile dall'interfaccia
namespace module
{
class CMessage;
}

namespace engine
{
class SessionBrowsingInfo;

/** Interface class to control the framework
 *
 * This class is used by those software who see the framework as a component (e.g. multirun, gui)
 * Allow to issue commands trough the PushCommand method
 * and to inquire the internal FSA status
 *
 **/
class GOLD_ENGINE_EXPORT CEngineInterface
{
public:

	/**
	 * Allow to issue a software command to the framework
	 * to cause an FSA status change. Commands can be found in Commands.h
	 *
	 * @param Cmd
	 */
	virtual void PushCommand(const engine::spCmdType& cmd) = 0;
	virtual void SendMessage(const module::CMessage& msg,
			const std::string& url) = 0;
	// virtual std::string QueryCommand(std::string str) = 0;

	virtual const usr::CSession& Session() const = 0;
	virtual const dev::CDeviceManager& Devices() const = 0;
	virtual const sys::CScheduler& Scheduler() const = 0;

	virtual void Browse(engine::SessionBrowsingInfo& sbi) = 0;

	virtual ~CEngineInterface()
	{
	}

	// versioni non const e deprecate per consentire una modifica graduale del control_panel
	GOLD_ENGINE_DEPRECATED virtual usr::CSession& Session() = 0;GOLD_ENGINE_DEPRECATED virtual dev::CDeviceManager& Devices()= 0;GOLD_ENGINE_DEPRECATED virtual sys::CScheduler& Scheduler() = 0;

};

} // namespace engine

#endif
