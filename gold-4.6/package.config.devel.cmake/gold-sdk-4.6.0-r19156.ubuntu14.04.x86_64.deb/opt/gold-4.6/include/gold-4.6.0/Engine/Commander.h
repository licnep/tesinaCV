#ifndef _USER_INTERFACE_H
#define _USER_INTERFACE_H

#include <Framework/CModule.h>
#include "Command.h"           // serve solo per lo shared pointer
#include "CEngineInterface.h"  // TODO occultarlo nel .cpp
#include <Libs/Logger/Logger.h>

class CLogMessage;
namespace vl{ namespace ini {class INIFile;} } using vl::ini::INIFile;
class CDeviceNode;

// TODO: questa potrebbe andare in Framework
// in modo che sia possibile costruire interfacce esterne

/** \brief Namespace containing the engine controllers */
namespace cmdr
{

/**
 * \brief Base class for engine command interfaces
 *
 * This class can be registered as a framework interface using Attach and Detach
 * The framework calls the Update method each time it has to notify a status change
 * Each time an attached interface change the framework status the change is notified
 * to the other interfaces
 *
 */
// TODO: rename to Controller
class Commander: public usr::CModule
{
public:
	// TODO: metodo di late-initialization per ricevere:
	// - l'engine (da qui dovrebbe riuscire a prendere devices e scheduler)
	// si potrebbe ricevere solo un canale di comunicazione bidirezionale
	// - un file di inizializzazione specifico
	void Initialize(engine::CEngineInterface& Engine, INIFile &INIFile)
	{
		m_pEngine = &Engine;
		m_pINIFile = &INIFile;
	}

	virtual void Notify_LogMsg(const vl::logger::CLogMessage& msg)
	{
		// common code here
		On_LogMsg_Received(msg);
	}

	virtual ~Commander()
	{
	}

protected:
	Commander()
	{
	} // classe solo derivabile

	engine::CEngineInterface &Engine()
	{
		return *m_pEngine;
	}
	const engine::CEngineInterface &Engine() const
	{
		return *m_pEngine;
	}

	virtual void On_LogMsg_Received(const vl::logger::CLogMessage& msg)
	{
	}

	void PushCommand(const engine::spCmdType& cmd)
	{
		m_pEngine->PushCommand(cmd);
	}
	INIFile& INI()
	{
		return *m_pINIFile;
	}

	// dev::CDeviceManager& Device(const std::string& dev) { return m_pEngine->Devices()[dev]; }

private:
	engine::CEngineInterface *m_pEngine;
	INIFile *m_pINIFile;
};

} // namespace cmdr

#endif
