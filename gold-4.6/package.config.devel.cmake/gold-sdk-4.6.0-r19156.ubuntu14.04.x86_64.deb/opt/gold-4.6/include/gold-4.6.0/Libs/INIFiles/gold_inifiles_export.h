
#ifndef GOLD_INIFILES_EXPORT_H
#define GOLD_INIFILES_EXPORT_H

#ifdef GOLD_INIFILES_STATIC_DEFINE
#  define GOLD_INIFILES_EXPORT
#  define GOLD_INIFILES_NO_EXPORT
#else
#  ifndef GOLD_INIFILES_EXPORT
#    ifdef gold_inifiles_EXPORTS
        /* We are building this library */
#      define GOLD_INIFILES_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define GOLD_INIFILES_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef GOLD_INIFILES_NO_EXPORT
#    define GOLD_INIFILES_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef GOLD_INIFILES_DEPRECATED
#  define GOLD_INIFILES_DEPRECATED __attribute__ ((__deprecated__))
#  define GOLD_INIFILES_DEPRECATED_EXPORT GOLD_INIFILES_EXPORT __attribute__ ((__deprecated__))
#  define GOLD_INIFILES_DEPRECATED_NO_EXPORT GOLD_INIFILES_NO_EXPORT __attribute__ ((__deprecated__))
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define GOLD_INIFILES_NO_DEPRECATED
#endif

#endif
