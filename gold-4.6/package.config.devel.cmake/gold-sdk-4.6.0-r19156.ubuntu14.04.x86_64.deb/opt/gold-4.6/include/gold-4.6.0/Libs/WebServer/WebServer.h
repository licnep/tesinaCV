/**
 * \file WebServer.h
 * \brief A minimalistic WebServer based on boost::asio
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>, Paolo Medici\<grisleri@ce.unipr.it\>
 */

#ifndef _WEBSERVER_H
#define _WEBSERVER_H

#include <Libs/WebServer/gold_ws_export.h>

#include <boost/asio.hpp>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <boost/thread/thread.hpp>
#include <boost/function.hpp>

#include <string>
#include <map>
#include <vector>

/** \brief Namespace for a minimalistic WebServer and related classes */
namespace ws
{

/** \brief Events handled by WebServer */
enum HttpdEvent
{

	HTTPD_MSG_NONE,  ///< reserved

	HTTPD_MSG_GET,  ///< http request
	HTTPD_MSG_HEAD, ///< http request
	HTTPD_MSG_POST, ///< http request

	HTTPD_MSG_OPTIONS, ///< rtsp request
	HTTPD_MSG_DESCRIBE, ///< rtsp request
	HTTPD_MSG_SETUP,   ///< rtsp request
	HTTPD_MSG_PLAY,    ///< rtsp request
	HTTPD_MSG_PAUSE,   ///< rtsp request
	HTTPD_MSG_GETPARAMETER, ///< rtsp request
	HTTPD_MSG_TEARDOWN, ///< rtsp request

	HTTPD_MSG_MAX ///< just to track the count of MSG
};

/**
 * \brief The client request parsed/session
 */
struct Request
{
	std::string url; ///< Resource name
	std::map<std::string, std::string> options; ///< Query Options
	std::map<std::string, std::string> http_options;	///< HTTP/RTSP Options
	boost::asio::ip::tcp::iostream *os; 	///< the IO stream
	bool keep_alive; ///< keep alive flag
	long session; 	///< session guid
	std::vector<unsigned char> session_param; 	///< session attributes

#ifdef USE_BOOST_SIGNAL2
	boost::signals2::signal<void(Request&)> OnClosingSession; /// callback invoked when the session is terminated
#else
	boost::signal<void(Request&)> OnClosingSession; /// callback invoked when the session is terminated
#endif

public:

	/** \brief Returns the out stream */
	inline std::ostream& out()
	{
		return *os;
	}

	/** \brief Test if exist the option */
	bool has_option(const std::string& key, std::string& value) const
	{
		std::map<std::string, std::string>::const_iterator i = http_options.find(
				key);
		if (i != http_options.end())
		{
			value = i->second;
			return true;
		}
		else
			return false;
	}

	/** \brief Returns the remote endpoint ip:port */
	inline GOLD_WS_EXPORT boost::asio::ip::tcp::endpoint remote_endpoint() const
	{
		return os->rdbuf()->remote_endpoint();
	}
};


/**
 * \brief The WebServer object
 *
 * This example shows how to create a MultiThread WebServer listening port 4000
 * 80 is the default for HTTP: the root privilegese are needed to open this port
 *
 * \code
 * WebServer ws(boost::asio::ip::host_name(), 4000);
 *
 * // add some file to WebServer
 * ws.RegisterFile("/","Data/Calzoni/index.html", "text/html");              // a real file
 * ws.RegisterFile("/index.html","Data/Calzoni/index.html", "text/html");    // a real file
 * ws.RegisterFile("/shoot.jpg","mem:///shoot.jpg", "image/jpeg");           // a mem object
 * // add some user callback to WebServer
 * ws.RegisterCallback("/cgi-bin",boost::bind(&MyClass::MyFun, this, _1));
 * \endcode
 **/
class GOLD_WS_EXPORT WebServer
{
public:
	/**
	 * \brief The callback type
	 * \note return 0 to keep-alive the connection
	 */
	typedef boost::function1<int, Request&> CallbackType;

	/**
	 * \brief Alias for structure mapping between url name and callbacks
	 */
	typedef std::map<std::string, CallbackType> URLToCallbacksType;

private:

	boost::asio::io_service io; ///< the io service
	boost::asio::ip::tcp::acceptor acceptor; ///< acceptor
	boost::scoped_ptr<boost::thread> serviceThread; ///< the io_service thread
	boost::thread_group thread_pool_; ///< list of thread created to handle accepted connection
	boost::asio::ip::tcp::endpoint localhost_endpoint; ///< the local ip address
	URLToCallbacksType m_res_mapping[HTTPD_MSG_MAX]; ///< Map between URL and the source provider
	std::string auth_realm; 	///< Authentication realm
	std::vector<std::string> authorized_users; ///< Authorized users USERNAME:PASSWORD
	long guid; ///< session guid

private:

	/** \brief thread called when each new connection take place */
	void new_connection(boost::asio::ip::tcp::iostream *os, long guid);

	/** \brief callback invoked from async_accept in the ios thread */
	void handle_accept(boost::asio::ip::tcp::iostream *os,
			const boost::system::error_code& error);

	/** \brief inserts a new connection request */
	void prepare_new_connection();

public:
	/** \brief Default constructor: creates an empty webserver */
	WebServer();

	/**
	 * \brief Costructor accepting the listen port
	 * \param address binding address (boost::asio::ip::host_name() or 0.0.0.0 for all eth) unimplemented yet
	 * \param port port of running server (80 is the default, but only root can open)
	 */
	WebServer(const std::string & address, unsigned short port);

	/** \brief Destructor */
	~WebServer();

	/** \brief Add the requested netmask to the allowed addresses */
	void AddMask(unsigned int net_mask);

	/** \brief Set Authentication Realm and enable auth mode */
	void EnableAuth(const std::string& realm);

	/** \brief Adds and authenticated user specifying username and password separately */
	void AddAuthUser(const std::string & user, const std::string & pass);

	/** \brief Adds and authenticated user using the format `username:password' */
	void AddAuthUser(const std::string & digest);

	/**
	 * \brief Register a new file associated to an url exposed by the webserver
	 * \param url url called by the http client
	 * \param file valid html local file
	 * \param mime Additional Mime-Type (text/html or image/jpeg for example). Default is an empty string
	 */
	void RegisterFile(const std::string& url, const std::string& file,
			const std::string& mime = std::string());

	/**
	 * \brief Register a new directory associated to an url exposed by the webserver
	 * \param url url chiamata dal client http
	 * \param file path locale
	 */
	void RegisterPath(const std::string& url, const std::string& path);

	/**
	 * \brief Register a new callback assocuated to an url
	 * \param url the url associated with the callback
	 * \param fn the callback invoked whenever a user browse the url
	 * \param evt the http event associated to the callback invocation
	 */
	void RegisterCallback(const std::string& url, CallbackType fn,
			HttpdEvent evt = HTTPD_MSG_GET);

	/**
	 * \brief release an URL previously registered
	 * \param url the URL to be free
	 * \param the optional event associated to the URL
	 * \return true if the operation succeded, false otherwise
	 */
	bool UnRegister(const std::string& url, HttpdEvent evt = HTTPD_MSG_GET);

	/** \brief Returns the webserver port number (in host format) */
	unsigned short Port() const;

	/** \brief Return the webserver address (in dot format) */
	std::string Address() const;

	/** \brief Return the localhost address */
	const boost::asio::ip::tcp::endpoint& localhost() const;
};
} // namespace ws

#endif
