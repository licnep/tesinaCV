
#ifndef GOLD_WS_EXPORT_H
#define GOLD_WS_EXPORT_H

#ifdef GOLD_WS_STATIC_DEFINE
#  define GOLD_WS_EXPORT
#  define GOLD_WS_NO_EXPORT
#else
#  ifndef GOLD_WS_EXPORT
#    ifdef gold_ws_EXPORTS
        /* We are building this library */
#      define GOLD_WS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define GOLD_WS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef GOLD_WS_NO_EXPORT
#    define GOLD_WS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef GOLD_WS_DEPRECATED
#  define GOLD_WS_DEPRECATED __attribute__ ((__deprecated__))
#  define GOLD_WS_DEPRECATED_EXPORT GOLD_WS_EXPORT __attribute__ ((__deprecated__))
#  define GOLD_WS_DEPRECATED_NO_EXPORT GOLD_WS_NO_EXPORT __attribute__ ((__deprecated__))
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define GOLD_WS_NO_DEPRECATED
#endif

#endif
