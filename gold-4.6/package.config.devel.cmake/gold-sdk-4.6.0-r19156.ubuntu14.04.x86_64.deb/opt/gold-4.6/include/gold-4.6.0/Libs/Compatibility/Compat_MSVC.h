/**
 * \file Compat_MSVC.h
 * \brief Microsoft Visual C++ compiler compatibility work-around.
 */

#ifndef __COMPAT_MSVC
#define __COMPAT_MSVC

#ifdef _MSC_VER

# endif

# endif
