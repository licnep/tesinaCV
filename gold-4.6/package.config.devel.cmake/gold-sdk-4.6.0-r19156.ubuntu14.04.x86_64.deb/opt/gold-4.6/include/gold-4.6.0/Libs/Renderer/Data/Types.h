#ifndef _TYPES_H
#define _TYPES_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * \file Types.h
 * \author Paolo Zani <zani@vislab.it>
 * \date 2010-12-20
 **/

#include <Libs/Renderer/Data/renderer_dataconverter_export.h>

#include <boost/mpl/if.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/type_traits/is_enum.hpp>
#include <boost/utility/enable_if.hpp>

#include <stdint.h>
#include <string>
#include <vector>

namespace ui
{
namespace var
{
namespace types
{
template<typename T, typename IsEnum = void> struct type_name
{
	static std::string str()
	{
		return "undefined";
	}
};

template<typename T> struct type_name<T,
		typename boost::enable_if<boost::is_enum<T> >::type>
{
	static std::string str()
	{
		return "enum";
	}
};

template<> struct type_name<bool>
{
	static std::string str()
	{
		return "bool";
	}
};

template<> struct type_name<uint8_t>
{
	static std::string str()
	{
		return "uint8";
	}
};

template<> struct type_name<int8_t>
{
	static std::string str()
	{
		return "int8";
	}
};

template<> struct type_name<uint16_t>
{
	static std::string str()
	{
		return "uint16";
	}
};

template<> struct type_name<int16_t>
{
	static std::string str()
	{
		return "int16";
	}
};

template<> struct type_name<uint32_t>
{
	static std::string str()
	{
		return "uint32";
	}
};

template<> struct type_name<int32_t>
{
	static std::string str()
	{
		return "int32";
	}
};

template<> struct type_name<uint64_t>
{
	static std::string str()
	{
		return "uint64";
	}
};

template<> struct type_name<int64_t>
{
	static std::string str()
	{
		return "int64";
	}
};

template<> struct type_name<float>
{
	static std::string str()
	{
		return "float";
	}
};

template<> struct type_name<double>
{
	static std::string str()
	{
		return "double";
	}
};

template<> struct type_name<std::string>
{
	static std::string str()
	{
		return "string";
	}
};

template<> struct type_name<const char*>
{
	static std::string str()
	{
		return "string";
	}
};

template<typename T>
// struct RENDERER_DATACONVERTER_EXPORT value // PG dll import/export patch
struct value
{
	typedef T value_type;

	struct actions
	{
		enum
		{
			SELECT = 0
		};
	};

	static std::string type_name()
	{
		return std::string("value<") + ui::var::types::type_name<T>::str() + ">";
	}
};

template<typename T>
// struct RENDERER_DATACONVERTER_EXPORT range
struct range
{
	typedef struct
	{
		T min;
		T max;
		T step;
	} attributes_type;
	typedef T value_type;

	struct actions
	{
		enum
		{
			SELECT = 0
		};
	};

	static std::string type_name()
	{
		return std::string("range<") + ui::var::types::type_name<T>::str() + ">";
	}
};

template<typename T>
// struct RENDERER_DATACONVERTER_EXPORT collection
struct collection
{
	typedef typename boost::mpl::if_<boost::is_enum<T>, std::vector<int32_t>,
			typename std::vector<T> >::type attributes_type;
	typedef std::vector<int32_t> value_type;

	struct actions
	{
		enum
		{
			SELECT = 0, OPEN
		};
	};

	static std::string type_name()
	{
		return std::string("collection<") + ui::var::types::type_name<T>::str()
				+ ">";
	}
};

struct RENDERER_DATACONVERTER_EXPORT _enum
{
};

template<>
// struct RENDERER_DATACONVERTER_EXPORT collection<_enum>
struct collection<_enum>
{
	typedef std::vector<int32_t> attributes_type;
	typedef std::vector<int32_t> value_type;

	struct actions
	{
		enum
		{
			SELECT = 0, OPEN
		};
	};

	static std::string type_name()
	{
		return std::string("collection<enum>");
	}
};

template<typename T>
// struct RENDERER_DATACONVERTER_EXPORT tree
struct tree
{
	typedef boost::property_tree::basic_ptree<T, int32_t> attributes_type;
	typedef std::vector<int32_t> value_type;

	struct actions
	{
		enum
		{
			SELECT = 0, OPEN
		};
	};

	static std::string type_name()
	{
		return std::string("tree<") + ui::var::types::type_name<T>::str() + ">";
	}
};
} // namespace types
} // namespace var
} // namespace ui

#endif
