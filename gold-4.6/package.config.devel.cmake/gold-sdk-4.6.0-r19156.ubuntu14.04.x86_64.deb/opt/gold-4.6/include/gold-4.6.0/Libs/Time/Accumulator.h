/**
 * \file Accumulator.h
 * \brief Accumulator class for collecting statistics on sample values
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _VLTIME_ACCUMULATOR_H
#define _VLTIME_ACCUMULATOR_H

#include <Libs/Time/TimeUtils.h>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <Libs/Time/gold_time_export.h>

namespace vl
{
namespace chrono
{
namespace detail
{
class Accumulator; // Forward decl for the implementation
}

/**
 * \brief Template for representing an accumulator.
 *
 * The accumulator accept a parameter which is the type managed by 
 * AccumulatorBase (an alias for boost:.accumulator)
 * This parameter is an unsigned number representing an amount of time, 
 * such as microseconds.
 * The accumulator is used by the chronometer to collect statistics 
 * on the measured interval time, such as mean, min, max, variance, ...
 */
class GOLD_TIME_EXPORT Accumulator
{
public:
	/**
	 * \brief Type of the samples used by the accumulator
	 */
	typedef unsigned long SampleType;

	/**
	 * \brief floating point type for results such as variance
	 */
	typedef double FloatType;

	/**
	 * \brief type for counters
	 */
	typedef uint64_t CounterType;

	Accumulator();

	/**
	 * \brief Operator to assign a sample
	 * \param t the new time sample to be accumulated
	 */
	void operator()(SampleType t);

	/**
	 * \brief Returns the number of submitted
	 * through the operator() since the last reset
	 */
	CounterType Count() const;

	/**
	 * \brief Returns the last sample submitted
	 * through the operator() since the last reset
	 */
	SampleType Last() const;

	/**
	 * \brief Returns the sum of the samples submitted
	 * through the operator() since the last reset
	 */
	SampleType Sum() const;

	/**
	 * \brief Returns the min sample submitted
	 * through the operator() since the last reset
	 */
	SampleType Min() const;

	/**
	 * \brief Returns the max sample submitted
	 * through the operator() since the last reset
	 */
	SampleType Max() const;

	/**
	 * \brief Returns the average sample submitted
	 * through the operator() since the last reset
	 */
	SampleType Mean() const;

	/**
	 * \brief Returns the variance of sample submitted
	 * through the operator() since the last reset
	 */
	FloatType Variance() const;

	/**
	 * \brief Reset the accumulator
	 */
	void Reset();

	/**
	 * \brief Typedef for the observer callback
	 *
	 * Users can define their own callback, which is called whenever there is
	 * a change in the accumulator
	 */
	#ifdef USE_BOOST_SIGNAL2
		typedef boost::signals2::signal<void(const Accumulator&)> SignalType;
	#else
		typedef boost::signal<void(const Accumulator&)> SignalType;
	#endif

	/**
	 * \brief Method for registering a callback for observing internal changes
	 *
	 * User interface should connect to this method instead of polling the object
	 * The minimum update interval can be set through the SetUpdateThreshold method
	 * This is a const method since changing the connected observers
	 * do not change the internal status.
	 */
	void RegisterObserver(const SignalType::slot_type& slot) const;

	/**
	 * \brief Method for unregistering all the registered callbacks
	 *
	 * After calling this method all the previous registered observers
	 * will not be called any more.
	 * This is a const method since changing the connected observers
	 * do not change the internal status.
	 */
	void UnregisterObservers() const;

	/**
	 * \brief Set the minumum threshold of the accumulator
	 *
	 * This is to avoid excessive cpu load during updates
	 * \param time_th the minimum time interval between two observer updates
	 */
	void SetUpdateThreshold(const TimeType& time_th) const;

protected:

	/**
	 * \brief Triggers a notification to the observers
	 */
	void NotifyObservers();

private:
	boost::shared_ptr<detail::Accumulator> m_pimpl; ///< Pointer to the accumulator implementation

	SampleType m_last;  ///< last sample submitted
	boost::shared_ptr<SignalType> m_sp_observers; ///< signal to the observers
	AbsoluteTimeType m_last_update; ///< absolute time of the last update
	AbsoluteTimeType m_now;  ///< buffer for current time
	mutable TimeType m_time_th; ///< minimum time threshold between notifications // TODO FIXME
};

} // namespace chrono
} // namesopace vl

#endif // _VLTIME_ACCUMULATOR_HXX
