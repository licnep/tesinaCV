/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.ARGO.ce.unipr.it                                  *
 *                                                                    *
 **********************************************************************/

/** \file   Log.h
 *  \brief  Macros and definitions for managed log
 *
 *  The engine instantiate a configurable filter on std::cout which provides
 *  several functions, such as, type, multiple sinks, fields and filtering support,
 *  automatic fields generation.
 *
 *  This file contains the macros for shortening the access to the log.
 *
 *  There are several types of log types: INFORMATION, DEBUG, WARNING, ERROR.

 *  Logs produced using the macros contained in this file can be removed automatically
 *  defining the appropriate macro value for VERBOSITY_{INFO, DEBUG, WARN, ERROR}
 *  when compiling. When the macro value is set to true, than the code is active, while
 *  if the macro value is set to false, then the log code is completely removed.
 *
 *  When DNDEBUG is defined, the VERBOSITY_DEBUG is automatically set to false;
 *
 *  The log has the following format:
 *
 *  [type] location: message
 *
 *  where:
 *  \b type is the log type requested in the code, using the appropriate macro (log_info, log_debug, log_warn, log_error);
 *  it belongs to: II, DD, WW, o EE
 *  \b location is the location where the log has been produced: the default is set to the class or function name.
 *  It is possible to change the defautl location using the __LOCATION__ macro at the beginning of the file
 *  \b message is the message to be printed
 *  DO NOT: include log.h in an header file;
 *  DO NOT: define configuration macros in an header file;
 *
 *  Always terminate your log with "<<std::endl" which triggers a flush (DO NOT use "\n")
 *  Always specifies your configuration macros at the beginning of the file
 *
 *  Below there is an example:
 *
 *  \code
 *    #define __LOCATION__ __CLASS__
 *    #define VERBOSITY_INFO  true
 *    #incldue "CLog.h"*
 *      log_info   << "This is my information message" << std::endl;
 *  \endcode
 *
 *  produces, depending on the logger configuration:
 *
 *  \code
 *  0000.00.12.345678 [II] Location: This is my information message.
 *  \endcode
 *
 *  The following code:
 *  \code
 *      log_info   << "This is my information message ";
 *      log_info_  << " [OK]" << std::endl;
 *  \endcode
 *
 *  produces:
 *
 *  \code
 *  0000.00.12.345678 [II] Location: This is my information message [OK]
 *	\endcode
 *
 *  The following code:
 *
 *  \code
 *      log_info_m  << "This is my information message" << std::endl;
 *  \endcode
 *
 *	produces:
 *
 *  \code
 *  [II] This is my information message.
 *  \endcode:
 **/

#ifndef _LOG_H
#define _LOG_H

#include <boost/current_function.hpp>

// Configuration definition
// Enable or disable the different log levels
// MSVC9 do not recognize true/false, thus constants are used
#ifndef VERBOSITY_INFO
#define VERBOSITY_INFO  1
#endif

#ifndef VERBOSITY_DEBUG
#define VERBOSITY_DEBUG 0
#endif

#ifndef VERBOSITY_WARN
#define VERBOSITY_WARN  1
#endif

#ifndef VERBOSITY_ERROR
#define VERBOSITY_ERROR 1
#endif

/// Location di default
#ifndef __LOCATION__
#define __LOCATION__ __CLASS__
#endif

/** \brief string to be printed before location */
#define LOCATION_PROLOGUE ' '

/** \brief string to be printed after location */
#define LOCATION_EPILOGUE ": "

// default labels for indicating the log type
// these can be redefined for inhibiting the filtering through the cout streambuf
#ifndef __i_mark
#define __i_mark "[II]"
#endif
#ifndef __d_mark
#define __d_mark "[DB]"
#endif
#ifndef __w_mark
#define __w_mark "[WW]"
#endif
#ifndef __e_mark
#define __e_mark "[EE]"
#endif

// enable or disable different types of events
#if (VERBOSITY_INFO)
#define __log_i_prologue
#else
#define  __log_i_prologue while(0)
#endif

#if (VERBOSITY_DEBUG)
#define __log_d_prologue
#else
#define  __log_d_prologue while(0)
#endif

#if (VERBOSITY_WARN)
#define __log_w_prologue
#else
#define  __log_w_prologue while(0)
#endif

#if (VERBOSITY_ERROR)
#define __log_e_prologue
#else
#define  __log_e_prologue while(0)
#endif

#define LOC_SEP ":"

// These are already defined
// __FILE__
// __LINE__
// __PRETTY_FUNCTION__
// __func__
#ifndef __MODULE
#define __MODULE       __Location_Module(__FILE__)
#endif

#ifndef __MODULE_LINE__
#define __MODULE_LINE__  __Location_Module(__FILE__) + LOC_SEP + __Location_Line(__LINE__)
#endif

#ifndef __FILE_LINE__
#define __FILE_LINE__  __Location_File(__FILE__) + LOC_SEP + __Location_Line(__LINE__)
#endif

#ifndef __CLASS__
#define __CLASS__  __Location_Class(BOOST_CURRENT_FUNCTION)
#endif

#ifndef __CLASS_METHOD__
#define __CLASS_METHOD__  __Location_ClassMethod(BOOST_CURRENT_FUNCTION)
#endif

#define __PROEPILOGUE(x) LOCATION_PROLOGUE << x << LOCATION_EPILOGUE

#ifndef DISABLE_LOG

#include <iostream>
#include <string>

inline std::string __Location_File(const std::string& name)
{
	std::string::size_type Start = name.rfind('/');
	return name.substr(Start + 1, name.length() - Start - 1);
}

inline std::string __Location_Module(const std::string& name)
{
	std::string::size_type Start = name.rfind('/');
	std::string::size_type Stop = name.rfind('.');
	return name.substr(Start + 1, Stop - Start - 1);
}

inline std::string __Location_Line(unsigned int line_number)
{
	typedef char C;
	C buf[30];
	std::size_t cchBuf = 30; // std::floor(std::log(LineNo))+1;
	const C s_characters[10] =
	{
	/*'9', '8', '7', '6', '5', '4', '3', '2', '1', */
	'0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };

	C *psz = buf + cchBuf - 1; // Set psz to last char
	*psz = 0;                         // Set terminating null
	do
	{
		unsigned int lsd = line_number % 10;    // Get least significant digit
		line_number /= 10;            // Prepare for next most significant digit
		--psz;                          // Move back
		*psz = s_characters[lsd];       // Place the digit
	} while (line_number);

	return std::string(psz);
}

inline std::string __Location_Class(const std::string& name)
{
	// find the arguments
	std::string::size_type start = 0;
	std::string::size_type stop = name.rfind('(');

	// class or function
	if (stop != std::string::npos)
	{
		// how to distinguish between a class and a function in a namespace?
		stop = name.rfind("::", stop - 1);
		start = name.rfind("::", stop - 1);
		if (start == std::string::npos)
		{
			start = name.rfind(' ', stop - 1);
			if (start == std::string::npos)
				start = 0;
		}
	}

	return name.substr(start + 2, stop - start - 2);
}

inline std::string __Location_Method(const std::string& name)
{
	std::string::size_type start = name.find("::");

	// if not a method then "::" are missing
	if (start != std::string::npos)
		start += 2;
	else
		start = name.find(' ');

	std::string::size_type Stop = name.find("(", start);
	return name.substr(start, Stop - start);
}

inline std::string __Location_ClassMethod(const std::string& name)
{
	/*
	 unsigned long long int Pre = Name.find("::");

	 unsigned long long int Start = Name.rfind(' ', Pre)+1;
	 unsigned long long int Stop  = Name.find("(", Pre);

	 // if not a method then "::" are missing
	 if(Pre==std::string::npos)
	 Start = Name.find(' ')+1;
	 */
	return name; //.substr(Start, Stop-Start);
}

#else

#include <iostream>

#define __Location_Module(x)      ""
#define __Location_Line(x)        ""
#define __Location_Class(x)       ""
#define __Location_Method(x)      ""
#define __Location_ClassMethod(x) ""

#endif

// ///////////////////////////////////////////////////////// //
// These are the macros to be used for printing log messages //
// ///////////////////////////////////////////////////////// //

/// Es: log_* << MyMessage << endl; 

/** \brief Continue the printing of the previous INFO line */
#define log_info_  __log_i_prologue std::cout

/** \brief Continue the printing of the previous DEBUG line */
#define log_debug_ __log_d_prologue std::cout

/** \brief Continue the printing of the previous WARNING line */
#define log_warn_  __log_w_prologue std::cout

/** \brief Continue the printing of the previous ERRROR line */
#define log_error_ __log_e_prologue std::cout

/** \brief Prints the INFO marker */
#define log_info_m  log_info_  << __i_mark << LOCATION_PROLOGUE

/** \brief Prints the DEBUG marker */
#define log_debug_m log_debug_ << __d_mark << LOCATION_PROLOGUE

/** \brief Prints the WARNING marker */
#define log_warn_m  log_warn_  << __w_mark << LOCATION_PROLOGUE

/** \brief Prints the ERROR marker */
#define log_error_m log_error_ << __e_mark << LOCATION_PROLOGUE

/** \brief Prints the INFO marker, and location */
#define log_info   log_info_m  << __LOCATION__ << LOCATION_EPILOGUE

/** \brief Prints the DEBUG marker, and location */
#define log_debug  log_debug_m << __LOCATION__ << LOCATION_EPILOGUE

/** \brief Prints the WARNING marker, and location */
#define log_warn   log_warn_m  << __LOCATION__ << LOCATION_EPILOGUE

/** \brief Prints the ERROR marker, and location */
#define log_error  log_error_m << __LOCATION__ << LOCATION_EPILOGUE

#endif
