#ifndef _USERINTERFACE_H
#define _USERINTERFACE_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * \file UserInterface.h
 * \brief frame creation utiity
 * \author Paolo Zani <zani@vislab.it>
 * \date 2010-12-09
 **/

#include <boost/property_tree/ptree.hpp>
#include <boost/any.hpp>

#include <string>

namespace ui
{
	typedef boost::property_tree::basic_ptree<std::string, boost::any> UserInterface;
}

#endif 
