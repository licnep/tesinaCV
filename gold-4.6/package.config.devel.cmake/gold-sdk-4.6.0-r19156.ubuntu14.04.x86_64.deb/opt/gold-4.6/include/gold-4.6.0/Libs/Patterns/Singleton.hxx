#ifndef _SINGLETON_HXX
#define _SINGLETON_HXX
#include <Libs/Patterns/Singleton.h>
#include <boost/shared_ptr.hpp>

namespace vl
{
  
template<class T, DestructorType D>  T* Singleton<T, D>::m_pInstance=0;
template<class T, DestructorType D>  boost::shared_ptr<T> Singleton<T, D>::m_spInstance;

template<class T, DestructorType D>
T& Singleton<T, D>::Instance()
{
    if (m_pInstance == 0)
    {
        // create sole instance
        m_pInstance = new T;
        if (D==DESTRUCTOR_AUTO)
            m_spInstance.reset(m_pInstance);
    }

    return *m_pInstance;
}

template<class T, DestructorType D>
Singleton<T, D>::Singleton()
{
}

template<class T, DestructorType D>
Singleton<T, D>::~Singleton()
{
    // std::cout << "REMOVING " << typeid(T).name() << std::endl;
}

} // namespace vl

#endif
