/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2009                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * \file DataConverter.h
 * \author Paolo Zani (zani@vislab.it)
 * \date 2009-11-19
 **/

#ifndef _DATACONVERTER_H
#define _DATACONVERTER_H

#include <Libs/Renderer/Data/renderer_dataconverter_export.h>
#include <Libs/Patterns/Singleton.h>

#include <boost/any.hpp>
#include <boost/ref.hpp>

#include <functional>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <typeinfo>

namespace ui
{
class RENDERER_DATACONVERTER_EXPORT DataConverterImpl
{
public:

	typedef std::pair<boost::reference_wrapper<const std::type_info>,
			boost::reference_wrapper<const std::type_info> > KeyType;
	typedef boost::any (*ConversionFunctionType)(const boost::any& v);

	template<typename Data, typename Protocol>
	bool Add(ConversionFunctionType encode, ConversionFunctionType decode)
	{
		const KeyType e_key = std::make_pair(boost::cref(typeid(Data)),
				boost::cref(typeid(Protocol)));
		const KeyType d_key = std::make_pair(boost::cref(typeid(Protocol)),
				boost::cref(typeid(Data)));

		m_functions.insert(std::make_pair(e_key, encode));
		m_functions.insert(std::make_pair(d_key, decode));

		return true;
	}

	// Widget -> Client
	boost::any Encode(const std::type_info& protocol)
	{
		KeyType key = std::make_pair(boost::cref(typeid(void)),
				boost::cref(protocol));

		if (m_functions.find(key) != m_functions.end())
			return m_functions[key](boost::any());
		else
		{

			std::cout << "[EE] DataConverterImpl::Encode(): key not found! ("
					<< boost::unwrap_ref(key.first).name() << ", "
					<< boost::unwrap_ref(key.second).name() << ")";
			throw;
		}

		return boost::any();
	}

	template<typename S>
	boost::any Encode(const S& s, const std::type_info& protocol)
	{
		KeyType key = std::make_pair(boost::cref(typeid(S)),
				boost::cref(protocol));

		if (m_functions.find(key) != m_functions.end())
			return m_functions[key](boost::any(s));
		else
		{

			std::cout << "[EE] DataConverterImpl::Encode(): key not found! ("
					<< boost::unwrap_ref(key.first).name() << ", "
					<< boost::unwrap_ref(key.second).name() << ")";
			throw;
		}

		return boost::any();
	}

	// Client -> Widget
	template<typename D>
	D Decode(const boost::any& s, const std::type_info& protocol)
	{
		KeyType key = std::make_pair(boost::cref(protocol),
				boost::cref(typeid(D)));

		try
		{
			if (m_functions.find(key) != m_functions.end())
				return boost::any_cast < D > (m_functions[key](s));
			else
			{

				std::cout
						<< "[EE] DataConverterImpl::Decode(): key not found! ("
						<< boost::unwrap_ref(key.first).name() << ", "
						<< boost::unwrap_ref(key.second).name() << ")\n"
						<< std::endl;
				throw;
			}
		} catch (const boost::bad_any_cast& e)
		{

			std::cout
					<< "[EE] DataConverterImpl::Decode(): conversion failed! ("
					<< boost::unwrap_ref(key.first).name() << ", "
					<< s.type().name() << " -> "
					<< boost::unwrap_ref(key.second).name() << ")\n"
					<< std::endl;
			throw e;
		}

		return D();
	}

private:

	struct less: public std::binary_function<KeyType, KeyType, bool>
	{
		inline bool operator()(const KeyType& x, const KeyType& y) const
		{
			return boost::unwrap_ref(x.first).before(y.first)
					|| (!(boost::unwrap_ref(y.first).before(x.first))
							&& boost::unwrap_ref(x.second).before(y.second));
		}
	};

	std::map<KeyType, ConversionFunctionType, less> m_functions;
};

typedef vl::Singleton<DataConverterImpl> DataConverter;
}


#if !defined(__rdc_PASTE)
#define __rdc_PASTE2(x, y) x##y
#define __rdc_PASTE(x, y) __rdc_PASTE2(x, y)
#endif

#define REGISTER_DATA_CONVERSION(Data, Protocol, Enc, Dec) static bool __rdc_PASTE(rdc, __LINE__) = ui::DataConverter::Instance().Add<Data, Protocol>(Enc, Dec);

#endif
