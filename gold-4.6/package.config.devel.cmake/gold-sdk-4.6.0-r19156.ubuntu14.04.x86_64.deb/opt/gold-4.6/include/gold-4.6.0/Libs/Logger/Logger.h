/** \file TimeUtils.h
 *  \brief Set of classes for modifying the behavior of cout to get a flexible log
 *  \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _LOGGER_H
#define _LOGGER_H

#include <string>
#include <vector>
#include <bitset>
#include <set>


#include <streambuf>
#include <boost/iostreams/filtering_stream.hpp>
#include <boost/date_time/posix_time/posix_time_types.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/thread/thread.hpp>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <Libs/VarReplacer/VarReplacer.h>
#include <Libs/Logger/gold_logger_export.h>


/**
  * \brief  Set of classes for logging on cout.
  *
  *  Supported features:
  *   - messages are divided by thread. A message is enqued separately for each thread
  *     until a flush is requested.
  *     printing std::cout << "begin message" << std::flush; std::cout << "end message" << std::endl;
  *     the message will be produced on a single line when the flush (std::endl) is received
  *     without mixing, between "begin message" and "end message", text arrived in the meantime from other threads
  *   - Fields: at configuration time it is possible to decide whic fields produce using the enumeration:
  *     THREADID, TIME, ABS_TIME, TYPE, LOCATION e MESSAGE
  *   - Filters: messages of a certain type can be filtered out as well as messages coming from a predefined set of sources
  * 
  *   Una riga viene codificata se viene riconosciuto un opportuno marcatore dopo un flush (quindi anche endl)
  *   L'output viene generato contemporaneamente tu tutti gli stream
  *   configurati come specificato nella stringa di configurazione.
  *   La stringa di configurazione viene passata al costruttore di CLogger.
  *   Si può scegliere ad esempio se abilitare la "Console"
  *   e/o un file specifico. In particolare il nome del file può contenere
  *   una variabile $DATE-TIME per differenziare i log nel tempo.
  *   Il marcatore deve essere una tra le seguenti stringhe:
  *   "[II]", "[WW]", "[DD]", "[EE]"
  *   Example:
  *   \code
  *     std::cout << "[EE] " << __MODULE__ << "This is my log message" << std::endl;
  *   \endcode
  *     genera una riga del tipo:
  *   \code
  *     hh:mm:ss:us#### [xx] location - message
  *   \endcode
  *   Alla distruzione dell'oggetto CLogger viene ripristinato il comportamento originale
  **/

// TODO: inserire i tools per filtrare, conteggiare ed eliminare i vecchi file di log
// TODO: trovare un altro nome. Questo non dice niente e log è già il logaritmo
namespace vl
{
namespace logger
{
  /**
   * Enumerator for fields of a log message
   */
typedef enum
{
    THREAD,   ///< thread identifier
    TIME,     ///< time, relative to the session start
    ABS_TIME, ///< absolute time
    TYPE,     ///< message type
    LOCATION, ///< message source 
    MESSAGE   ///< message body
} LOG_FIELD;

  /**
   * Enum for the log type
   */
typedef enum
{
    INFO, ///< information messages
    DEBUG,///< debug messages
    WARN, ///< warning messages
    _ERROR, ///< error messages
    FREE, ///< free (not formatted) messages
} LOG_TYPE;



/**
 * Abstract class returning a streambuf
 */
class GOLD_LOGGER_NO_EXPORT SBLog
{
public:
    // void Rename ( const std::string& Name ) { m_Name=Name; }
    virtual std::streambuf* PSB() = 0;
    virtual ~SBLog() {}
};

/**
 * StreamBuf to log on a null device
 */
class GOLD_LOGGER_NO_EXPORT SBOStream_Null :
            public SBLog
{
    std::streambuf *m_sb;
public:
    SBOStream_Null ( std::ostream* out ) :
            m_sb ( out->rdbuf() )
    {}
    virtual std::streambuf* PSB() {
        return m_sb;
    }
};

/**
 * StreamBuf to log on a stream (console)
 */
class GOLD_LOGGER_NO_EXPORT SBOStream :
            public SBLog
{
    std::streambuf* m_sb;
public:
    SBOStream ( std::ostream* out ) :
            m_sb ( out->rdbuf() )
    {}
    virtual std::streambuf *PSB() {
        return m_sb;
    }
};



/**
 * StreamBuf to log on a file
 */
class GOLD_LOGGER_NO_EXPORT SBFile:
            public SBLog
{
    boost::iostreams::filtering_ostream out;
public:
    SBFile();
    SBFile ( const std::string& FileName );
    virtual std::streambuf *PSB() {
        return out.rdbuf();
    }
};


/**
 * Class representing a log message
 */
class GOLD_LOGGER_NO_EXPORT CLogMessage
{
public:
    CLogMessage();
    void Parse();
    bool HasType () const;
    vl::logger::LOG_TYPE DecodeType () const;
    void Clear();

    /**
     * NOTE qui usiamo il tipo nativo del thread e non thread_id
     * perchè in alternativa il logger tutti gli handle ai thread
     * 
     * andrebbero distrutti prima di eseguire la dlclose
     * sugli shared object.
     * usando una mappa <boost::thread::id, CLogMessage>
     * per mantenere un elemento per ciascun thread che scrive messaggi
     * quando questa mappa viene distrutta, gli elementi
     * che puntano a thread creati da shared object su cui è stata
     * eseguita la dlclose, generano un segfault alla distruzione dell
     * boost::thread::id per come questo è fatto internamente
     */
    typedef uint64_t         ThreadIDType;
    ThreadIDType             thread_id;      ///< thread who produced the message
    boost::posix_time::ptime abs_timestamp;  ///< absolute timestamp
    boost::posix_time::time_duration timestamp;  ///< timestamp
    std::string ibuf;     ///< The input buffer
    vl::logger::LOG_TYPE type;  ///< index for the message type
    std::string location; ///< source of the message
    std::string text;     ///< message body
};


/**
 * Class for collecting multiple StreamBuf and offering a streambuf interface
 */
class GOLD_LOGGER_NO_EXPORT SBCollector :
            public SBLog,
            protected std::streambuf
{
public:
    typedef std::bitset<7> EnabledFieldsType;
    typedef std::bitset<5> SuppressedTypesType;
    typedef std::set<std::string> SuppressedLocationsType;

    SBCollector ();
    ~SBCollector ();

    void SetTimeOrigin(const boost::posix_time::ptime& origin );

    typedef enum { fmt_with_colors, fmt_wo_colors} FormatType;
    void Add ( SBLog* sbl, FormatType fmt_type=fmt_wo_colors);

    const boost::posix_time::ptime& Origin() const;

    void SetEnabledConsoleColors ( bool enabled );
    void SetEnabledFields ( const EnabledFieldsType& Fields );
    void SetSuppressedTypes ( const SuppressedTypesType& SuppressedTypes );
    void SetSuppressedLocations ( const SuppressedLocationsType& SuppressedLocations );

    virtual std::streambuf* PSB();

#ifdef USE_BOOST_SIGNAL2
    typedef boost::signals2::signal<void (const CLogMessage&)> SignalType;
#else
    typedef boost::signal<void (const CLogMessage&)> SignalType;
#endif

    void Dispatching_Start() {
#ifdef USE_BOOST_SIGNAL2
    	m_connection.connected();
#else
    	m_connection.unblock();
#endif
    }

    void Dispatching_Stop()  {
#ifdef USE_BOOST_SIGNAL2
    	m_connection.blocked();
#else
        m_connection.block();
#endif
        m_signal.disconnect_all_slots();
    }

    void Do_On_Dispatch_Message(const SBCollector::SignalType::slot_type slot)
    {
        m_connection = m_signal.connect(slot);
        // m_connection.block();
    }

    void print_queue();

    bool   m_configured;   ///< caches messages arrived before configuration
    bool   m_dispatch;     ///< true when the dispatch is enable

private:
    std::vector<std::streambuf *> m_sb_colored;
    std::vector<SBLog *>          m_logs_colored;

    std::vector<std::streambuf *> m_sb;
    std::vector<SBLog *>          m_logs;

    static const char* types[5];

    // preliminary color support
    static const unsigned int GOLD_LOGGER_MAX_COLORS=9;
    static const char* colors[GOLD_LOGGER_MAX_COLORS];
    static const char* type_to_color[5];
    static const char* message_to_color[5];
    // preliminary color support

    boost::mutex m_mtx;                 // mutex per accesso condiviso
    EnabledFieldsType   m_enabled_fields; // campi abilitati
    SuppressedTypesType m_suppressed_types;     // tipi filtrati
    SuppressedLocationsType m_suppressed_locations;     // locations filtrate
    boost::posix_time::ptime m_origin;    // origine del tempo

    // cache per i messaggi di ciascun thread prima della configuraziones
    typedef std::map<CLogMessage::ThreadIDType, std::vector<CLogMessage> > PreConfCacheType;
    PreConfCacheType m_preconf_cache;

    // mappa thread, messaggi: ogni elemento è il messaggio corrente di un certo thread
    typedef std::map<CLogMessage::ThreadIDType, CLogMessage > ThreadMessageType;
    ThreadMessageType m_messages;

    std::string obuf;     // stringa di buffer per la composizione della riga corrente

    SignalType m_signal;  // The callback signaler


#ifdef USE_BOOST_SIGNAL2
    boost::signals2::connection m_connection; // The callback connection
#else
    boost::signals::connection m_connection; // The callback connection
#endif


    CLogMessage& GetCurrentThreadMessage();

    template<FormatType fmt_type>
    void FormatMessage(CLogMessage& Message);

    void Dispatch(CLogMessage& message/*, boost::mutex::scoped_lock& lock*/);


    /**
     * virtual function called from the stream to write a block of characters
     */
    virtual std::streamsize xsputn ( const char_type* s, std::streamsize n );

    /**
     * virtual function called from the stream to write  character
     * usually here are catched '\n' and std::endl;
     */
    virtual int_type overflow ( int_type c );

    /**
     * virtual funciton called from the stream whenever a flush occurs
     */
    virtual int sync();
};



/** 
 * The Logger class. The program shall instantiate it befor producing any message
 * Output is buffered until the Configure function is called.
 * After configuration all the buffered output is produced to the configured sinks
 * This class is a singleton.
 */
class GOLD_LOGGER_EXPORT CLogger
{
public:
    typedef std::map<std::string, std::string> ParamsType;

    /** 
     * This class is a singleton. This method supply the one and only class instance
     */
    static CLogger& Instance();
    
    /**
     * Set the time origin used for producing messages
     * \param origin the time origin as absolute time
     */
    void SetTimeOrigin(const boost::posix_time::ptime& origin );

    /**
     * Configure the logger class. Between the first call to Instance() and 
     * the first call to this method, the message production is hinibited
     * Messages are accepted in input but not produced in output.
     * Once this function has been called all teh buffered messages are produced.
     * 
     * \param params a map of name-value-pairs containing the class parameters
     */
    void Configure(const std::map<std::string, std::string>& Params);

    /**
     * This method allows to register a callback which is called every time a 
     * message is produced.
     * \param slot the callback
     */
    void Do_On_Dispatch_Message(const SBCollector::SignalType::slot_type slot);
    
    /**
     * Enable the message dispatching to the registered callbacks
     */
    void Dispatching_Start();
    
    /**
     * Disable the message dispatching to the registered callbacks
     */
    void Dispatching_Stop();

    /**
     * Debug method: print the message queue
     */
    void print_queue();

    ~CLogger();

private:
    CLogger ();

    void AddFile ( const std::string& FileName );

    SBCollector SB; ///< StreamBuf collector

    
    std::streambuf             *m_old_sb; ///< buffer for the original cout
    const  ParamsType           m_params; ///< configuration params
    vl::CVarReplacer            m_var_replacer; ///< variable replacer
    SBOStream*                  m_psbostr; ///< The Console
};

} // namespace logger
} // namespace vl

#endif
