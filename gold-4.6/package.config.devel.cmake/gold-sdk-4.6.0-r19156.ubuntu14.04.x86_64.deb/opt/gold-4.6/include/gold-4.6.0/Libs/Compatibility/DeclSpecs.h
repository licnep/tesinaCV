/**
 * \file DeclSpecs.h
 * \brief Common declarator specifiers
 */

#ifndef _DECLSPECS_H
#define _DECLSPECS_H


#ifndef DECLSPEC_NORETURN
#if defined(_MSC_VER) && (_MSC_VER >= 1200) && !defined(MIDL_PASS)
#define DECLSPEC_NORETURN __declspec(noreturn)
# elif defined(__GNUC__)
#define DECLSPEC_NORETURN __attribute__((noreturn))
#else
#define DECLSPEC_NORETURN
#endif
#endif


#ifndef DECLSPEC_ALIGN
#if defined(_MSC_VER) && (_MSC_VER >= 1300) && !defined(MIDL_PASS)
#define DECLSPEC_ALIGN(x) __declspec(align(x))
#elif defined(__GNUC__)
#define DECLSPEC_ALIGN(x) __attribute__((aligned(x)))
#else
#define DECLSPEC_ALIGN(x)
#endif
#endif



#ifndef DECLSPEC_FORCEINLINE
#if defined(_MSC_VER) && (_MSC_VER >= 1200)
#define DECLSPEC_FORCEINLINE __forceinline
#elif defined(__GNUC__)
#define DECLSPEC_FORCEINLINE __attribute__((always_inline))
#else
#define DECLSPEC_FORCEINLINE
#endif
#endif


#ifndef DECLSPEC_ISLIKELY
#if defined(_MSC_VER)
#define DECLSPEC_ISLIKELY(x)(x)
#elif defined(__GNUC__)
#define DECLSPEC_ISLIKELY(x)  __builtin_expect(!!(x),1)
#else
#define DECLSPEC_ISLIKELY(x) (x)
#endif
#endif


#ifndef DECLSPEC_ISUNLIKELY
#if defined(_MSC_VER)
#define DECLSPEC_ISUNLIKELY(x)(x)
#elif defined(__GNUC__)
#define DECLSPEC_ISUNLIKELY(x)  __builtin_expect(!!(x),0)
#else
#define DECLSPEC_ISUNLIKELY(x) (x)
#endif
#endif


#ifndef DECLSPEC_PACK
#if defined(_MSC_VER)
#define DECLSPEC_PACK
#elif defined(__GNUC__)
#define DECLSPEC_PACK __attribute__((__packed__))
#else
#define DECLSPEC_PACK
#endif
#endif


#ifndef DECLSPEC_WEAK_SYMBOL
#if defined(_MSC_VER)
#define DECLSPEC_WEAK_SYMBOL
#elif defined(__GNUC__)
#define DECLSPEC_WEAK_SYMBOL  __attribute__((__weak__))
#else
#define DECLSPEC_WEAK_SYMBOL
#endif
#endif


#ifndef DECLSPEC_MUST_USE_RESULT
#if defined(_MSC_VER)
#define DECLSPEC_MUST_USE_RESULT
#elif defined(__GNUC__)
#define DECLSPEC_MUST_USE_RESULT __attribute__((__warn_unused_result__))
#else
#define DECLSPEC_MUST_USE_RESULT
#endif
#endif


///////////////////////////////////////////////////////////////////////////////
// ELIMINARE: USARE QUELLE DI CMAKE
#ifndef DECLSPEC_DEPRECATED
# if defined(_MSC_VER) && (_MSC_VER >= 1300) && !defined(MIDL_PASS)
#define DECLSPEC_DEPRECATED __declspec(deprecated)
#elif defined(__GNUC__) && ((__GNUC__ > 3) || ((__GNUC__ == 3) && (__GNUC_MINOR__ >= 2)))
#define DECLSPEC_DEPRECATED __attribute__((deprecated))
#else
#define DECLSPEC_DEPRECATED
#endif
#endif


#ifndef DECLSPEC_EXPORT
#ifdef _MSC_VER
#define DECLSPEC_EXPORT __declspec(dllexport)
#elif defined(__MINGW32__)
#define DECLSPEC_EXPORT __attribute__((dllexport))
#elif defined(__GNUC__) && ((__GNUC__ > 3) || ((__GNUC__ == 3) && (__GNUC_MINOR__ >= 3)))
#define DECLSPEC_EXPORT __attribute__((visibility ("default")))
#else
#define DECLSPEC_EXPORT
#endif
#endif

#ifndef DECLSPEC_IMPORT
#ifdef _MSC_VER
#define DECLSPEC_IMPORT __declspec(dllimport)
#elif defined(__MINGW32__)
#define DECLSPEC_IMPORT __attribute__((dllimport))
#elif defined(__GNUC__) && ((__GNUC__ > 3) || ((__GNUC__ == 3) && (__GNUC_MINOR__ >= 3)))
#define DECLSPEC_IMPORT __attribute__((visibility ("default")))
#else
#define DECLSPEC_IMPORT
#endif
#endif

#ifndef DECLSPEC_HIDDEN
#if defined(__MSC_VER) || defined(__MINGW32__) || defined(__CYGWIN__)
#define DECLSPEC_HIDDEN
#elif defined(__GNUC__) && ((__GNUC__ > 3) || ((__GNUC__ == 3) && (__GNUC_MINOR__ >= 3)))
#define DECLSPEC_HIDDEN __attribute__((visibility ("hidden")))
#else
#define DECLSPEC_HIDDEN
#endif
#endif
///////////////////////////////////////////////////////////////////////////////

#endif // _DECLSPECS_H

