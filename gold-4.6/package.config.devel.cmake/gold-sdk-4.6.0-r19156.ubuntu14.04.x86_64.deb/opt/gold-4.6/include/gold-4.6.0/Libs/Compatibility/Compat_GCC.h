

#ifndef __COMPAT_GCC
#define __COMPAT_GCC

#ifdef __GNUC__

#endif

#endif

