/** \file SysInfo.h
 *  \brief Functions for inspecting the system status
 *  \authors Mirko Felisa \<grisleri@ce.unipr.it\>, Paolo Grisleri \<grisleri@ce.unipr.it\>
 **/

#ifndef _SYSINFO_H
#define _SYSINFO_H

#include <string>
#include <stdint.h>

#include <Libs/SysInfo/gold_sysinfo_export.h>


namespace vl
{
namespace sysinfo
{

/**
 * \brief Returns the total amount of RAM available in the current system
 * \return total size of the RAM [bytes]
 */
GOLD_SYSINFO_EXPORT uint64_t TotalRAMSize();

/**
 * \brief Returns the current amount of free RAM available
 * \return size of the free RAM [bytes]
 */
GOLD_SYSINFO_EXPORT uint64_t FreeRAMSize();


/**
 * \brief Returns the total size of the disk containing the requested path
 * \param path path contained in the disk where the total size is requested
 * \return size of the disk containing the requested path [bytes]
 */
GOLD_SYSINFO_EXPORT uint64_t TotalDiskSize(const std::string& path);

/**
 * \brief Returns the free space on the disk containing the requested path
 * \param path path contained in the disk where the free space is requested
 * \return Free space available on the disk containing the requested path [bytes]
 */
GOLD_SYSINFO_EXPORT uint64_t FreeDiskSpace(const std::string& path);

/**
 * \brief Class for formatting a value to a human readable version
 *
 * This object allows to format a certain value passed to the constructor
 * using parameters such as Width, Precision, Filling characters and Unit
 * that can be set through dedicated methods.
 *
 * The objects converts the value into a properly formatted string.
 *
 * \see HumanReadableSize
 */
class GOLD_SYSINFO_EXPORT HRValue
{
    float m_value;
    std::string m_suffix;
    std::string m_unit;
    unsigned int m_width;
    unsigned int m_precision;
    char m_fill;
    
  public:
    /**
     * \brief Constructor accepting the value and a suffix for the formatted string
     */
    HRValue(float value, const std::string& suffix);
    
    /**
     * \brief Set the width of the output string
     * \param width total size of the output string
     */
    HRValue& SetWidth(unsigned int width);

    /**
     * \brief Set the precision of the formatted value
     * \param precision number of digits after the decimal mark
     */
    HRValue& SetPrecision(unsigned int precision);

    /**
     * \brief set the filling character
     * \param fill character to be used as for filling
     */
    HRValue& SetFill(char fill);

    /**
     * \brief Set the physical unit
     * \param unit string representing the physical unit, such as m, s.
     * The magnitude will be provided by the class
     */
    HRValue& SetUnit(const std::string& unit);
    
    // TODO measurement unit formatting
    
    // Accessors

    /** \brief Returns the value passed to the constructor */
    const float Value() const;

    /** \brief Returns the suffix passed to the constructor */
    const std::string& Suffix() const;

    /** Returns the measurement unit */
    const std::string& Unit() const;
    
    /** \brief Returns the output string */
    std::string String();
};



/**
 * \brief Returns an HRValue for printing the requested size in a human readable version
 * \tparam T type of the value to be converted
 * \tparam base numeric base to be used for conversion
 * \return an HRValue that can be used for printing the value
 */
template<class T, int base>
HRValue HumanReadableSize(T Size)
{
  // TODO Espandere per: milli, micro, nano pico, femto, atto
  const char *suffixes_big[] = {"", "K", "M", "G", "T", "P"};
  T Size2=Size;
  int i=0;
  for(;(Size>>10)>1;++i)
    Size=(Size>>10);
  return HRValue(((1.0f*Size2)/( /*std::pow(2,10*i) */ 1<<(10*i)  )), suffixes_big[i]);
}

} // namespace sysinfo
} // namespace vl


#endif // _SYSINFO
