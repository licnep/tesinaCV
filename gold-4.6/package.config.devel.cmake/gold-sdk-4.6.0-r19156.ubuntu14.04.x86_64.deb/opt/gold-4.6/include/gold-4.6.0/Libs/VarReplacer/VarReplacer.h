/** \file VarReplacer.h
 *  \brief Object for managing variables value to be expanded in string
 *  \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 **/

#ifndef _VAR_REPLACER_H
#define _VAR_REPLACER_H

#include <string>
#include <vector>

#include <boost/function.hpp>

#include <Libs/VarReplacer/gold_var_replacer_export.h>

namespace vl
{

/**
 * \brief Class for substituting a variables of different types in a string.
 *
 * This class can manage the following variables:
 * - static variables: values associated to a name and stored through the Insert Remove API
 * - variables obtained from a callback: the object stores a set of callbacks each associated to a name
 * - $DATE, $TIME: these two variables are predefined in the object and threated as a separate case
 * - environment variables: allows to use variables such as $ENV{HOME}
 */
class GOLD_VAR_REPLACER_EXPORT CVarReplacer
{
public:

	/**
	 * \brief Type for a static NVP entry
	 */
	typedef std::pair<std::string, std::string> NVPType;

	/**
	 * \brief Type for the container of the NVPs
	 */
	typedef std::vector<NVPType> NVPSet;

	/**
	 * \brief Type for an NVP entry where the value is obtained from a callback
	 */
	typedef std::pair<std::string, boost::function<const std::string&()> > NCBPType;

	/**
	 * \brief Type for the container of the callback-NVPs
	 */
	typedef std::vector<NCBPType> NCBPSet;

	/**
	 * \brief NVP types bitmask
	 */
	typedef enum
	{
		var_static = 1,    //< static variable
		var_callback = 2,  //< variable obtained from a callback
		var_date_time = 4, //< DATE and  TIME variables
		var_env = 8        //< Environment variables
	} var_type;

	/**
	 * \brief Adds a new NVP at the end of the substitution list
	 * If the placeholder contains previous placeholders they are ignored
	 * @param var_name placeholder for the string to be expanded
	 * @param value value of the string to be substituted to the placeholder
	 *
	 * @see Remove, Replace
	 */
	void Insert(const std::string& var_name, const std::string& value);

	/**
	 * \brief Remove a NVP from the substitution list
	 * @param var_name name of the entry to be removed
	 *
	 * @see Insert, Replace
	 */
	void Remove(const std::string& var_name);

	/**
	 * \brief Register a value returning callback associated with a name
	 * Variables with the name registered using this method will be
	 * replaced with the value returned from the callback
	 *
	 * @params var_name name associated to the callback
	 * @params callback the callback for obtaining the value
	 *
	 * @see Unregister, Replace
	 */
	void Register(const std::string& var_name,
			boost::function<const std::string&()> callback);

	/**
	 * \brief Remove a variable associated with a callback
	 * After calling this method the variable will not
	 * be no more substituted from Replace

	 *
	 * @params var_name name associated to the callback
	 * @params callback the callback for obtaining the value
	 *
	 * @see Register, Replace
	 */
	void UnRegister(const std::string& var_name);

	/**
	 * \brief Replace the variables specified from the bitmask in the string
	 * @param str the string where the variables have to be replaced
	 * @param vt bitmask defining the variable types to be replaced. Default is all types.
	 * @return the string passed as argument
	 */
	std::string& Replace(std::string& str,
			int vt = var_static | var_callback | var_date_time | var_env) const;


	/**
	 * \brief Merges all the variables of the argument into the current object
	 * @param vr CVarReplacer to be merged
	 */
	void Merge(const CVarReplacer& vr);

	/**
	 * \brief Prints the container content on a stream
	 * @param ostr ostream to be used as output for printing the container content
	 */
	void Print(std::ostream& ostr) const;

private:

	NVPSet m_nvp_set;
	bool nvpair_has_name(const std::string& var_name, const NVPType& value);

	NCBPSet m_ncbp_set;
	bool ncbpair_has_name(const std::string& var_name, const NCBPType& value);
};

} // namespace vl

#endif // _VAR_REPLACER_H
