/** \file Factory.h
 *  \brief Generic Factory for registering and instantiating plugins
 *  \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _FACTORY_H
#define _FACTORY_H

#include <boost/functional/factory.hpp>
#include <boost/function.hpp>

#include <map>
#include <vector>

/** \brief Namespace for VisLab libraries. Includes: patterns such as Factory and Singleton. */
namespace vl
{

/**
 * \brief Generic Factory for registering and instantiating plugins
 *
 * Factories can be used for registering plugins and instantiate them later
 * using a run time selected key associated to the plugin.
 *
 * \see RegisterObject.h
 *
 */
template<
  typename K,  // Key
  typename AP, // Abstract Product
  typename AA = boost::function<AP*()>  // AbstractAllocator
  >
class Factory
{
public:
  

  typedef K  KeyType;  ///< Type for the key needed for looking-up
  typedef AP AbstractProductType;  ///< Abstract Type of the Product
  typedef AA AbstractAllocatorType; ///< Allocator Type for the abstract product
  
  typedef std::map<KeyType, AbstractAllocatorType> MapType; ///< Allocators map
  typedef std::vector<KeyType> IDCollectionType; ///< Collection of the keys
  
  /**
   * \brief Register a new for a ConcreteProduct allocator
   * associated to the specified key
   *
   * \param [in] key the key of the allocator to be registered
   *
   * \return the return value is an AbstractAllocatorType type
   * when key is new, the allocator is stored in the object is returned
   * when key is already present the default allocator is returned
   *
   * \see boost::function
   */
  template<typename ConcreteProduct>
  AbstractAllocatorType RegisterObject(const KeyType& key)
  {
    std::pair<typename MapType::iterator, bool> retval =
    m_allocators.insert( std::make_pair(key, boost::factory<ConcreteProduct*>() ));
    return (retval.second)?
      retval.first->second:
      AbstractAllocatorType();
  }
  
  /**
   * \brief Retrives the allocator corresponding to a requested key
   * \param [in] key the key of the required allocator
   * \return the allocator registered with the required key
   * if key is present in the map, an empty boost function is returned.
   *
   * \see boost::function
   */
  AbstractAllocatorType GetAllocator(const KeyType& key)
  {
    typename MapType::iterator itr = m_allocators.find(key);
    return (itr!=m_allocators.end())?
      itr->second:
      AbstractAllocatorType();
  }
  
  /**
   * \brief Returns a const reference to the allocators map
   * \return a const reference to the allocators map
   */
  const MapType& Allocators() const  { return m_allocators; }
  
  /**
   * \brief Extract and returns the stored IDs in a vector
   *
   * This method can be used to enumerate the available ids and present them
   * on a user interface.
   * \return a container with the registered ids
   */
  IDCollectionType RegisteredIds() const
  {
    IDCollectionType ids;
    ids.reserve(m_allocators.size());
    for(typename MapType::const_iterator c_itr = m_allocators.begin(); 
        c_itr!=m_allocators.end(); 
        ++c_itr)
      ids.push_back(c_itr->first);
    return ids;
  }

private:
  
  std::map<KeyType, AbstractAllocatorType> m_allocators;  
};


} // namespace vl

#endif
