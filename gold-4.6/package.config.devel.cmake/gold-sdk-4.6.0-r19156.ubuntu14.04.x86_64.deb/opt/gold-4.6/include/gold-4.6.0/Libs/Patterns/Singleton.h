/**
 * \file Singleton.h
 * \brief Generic Singleton for creating single instance object
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _SINGLETON_H
#define _SINGLETON_H

#include <boost/shared_ptr.hpp>

/**
 * Types for the destruction policy
 */
typedef enum
{
	DESTRUCTOR_NONE, ///< the destructor will not be invoked
	DESTRUCTOR_AUTO  ///< the destructor will be executed
}
DestructorType;

namespace vl
{
/**
 * \brief Generic Singleton for creating single instance object
 *
 * Singleton is a pattern for creating unique instances of an object
 * visible from the whole process.
 *
 * The singleton instance must be placed in a cpp file linked to
 * the objects that will use it.
 * The sigleton instance must be declared visible.
 *
 * \code
 * // singleton_declaration.cpp
 * #include <Libs/Patterns/Singleton.hxx>
 * #include <DDK/gold_file_export.h>
 * template class GOLD_FILE_EXPORT vl::Singleton<SingletonClass>;
 * \endcode
 *
 * Singleton users, the source code where the singleton is accessed
 * must include Singleton.hxx and see the symbol of the singleton class
 *
 * \code
 * // Singleton usage
 * #include <SingletonClass.h>
 * #include <Singleton.hxx>
 *
 * vl::Singleton<SingletonClass>::Instance().Method();
 * \endcode
 */
template<class T,
	DestructorType D=DESTRUCTOR_AUTO>
class Singleton
{
public:
	/**
	 * \brief Static method for accessing the unique instance of the class T
	 */
    static T& Instance();

protected:

    /**
     * As required by the pattern, a Singleton object cannot be declared
     * since it is only accessible from the Instance method
     * \see Instance
     */
    Singleton();

    /**
     * Destructor
     */
    ~Singleton();

private:

    /**
     * Raw pointer to the unique class instance
     */
    static T* m_pInstance;

    /**
     * When AUTO destruction is selected, the raw pointer
     * the object instance is destroyed closing the program
     * using this shared pointer.
     */
    static boost::shared_ptr<T> m_spInstance;
};

} // namespace vl

#endif

