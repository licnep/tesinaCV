/**
 * \file Parallelize.h
 * \brief Split a processing function on several threads
 * \author Pietro Versari \<versari@ce.unipr.it\>
 */

#ifndef PARALLELIZE_H
#define PARALLELIZE_H

#include <boost/thread/thread.hpp>
#include <boost/ref.hpp>

/**
 * \bief Split a processing function on several threads
 *
 * This template allows to take advantage of multicore processors in a very simple way.
 *
 * The template receive a function which is called several times, each in a separate thread,
 * depending on the parallelism available on the target architecture.
 *
 * The called function may have an arbitrary number of arguments, which may need to be locked
 * for concurrent access by the user and can be specified using boost::bind as explained in the code below.
 * When called, the function receive two additional arguments which are the current thread number
 * and the total number of threads currently used for splitting the processing. The function can use these two
 * arguments for its finding the slice of processing, without touching the slices of other functions.
 *
 * Any interaction between functions need to be carefully managed in order to avoid races or deadlocks.
 * \tparam F function type, usually deduced by the compiler
 * \param  f the function to be called
 * \param num_threads number of threads or parallel function calls to be created.
 * Default is the number of logic processors returned by boost::thread::hardware_concurrency
 *
 * Here is an example on how to use Parallelize
 *
 * \code
 * // To parallelize a free function
 * void free_func(CImageMono& dst, const CImageMono& src, int th, uint32_t threadID, uint32_t threadNum);
 * // ... this is how to do for parallelizing a free function:
 * Parallelize(
 *   boost::bind(&free_func,         // a function pointer to the free function to be parallelized
 *               boost::ref(dst),    // the parameters to be passed to the function: for passing by reference boost::ref needs to be used
 *               boost::cref(src),   // or alternatively boost::cref for const references
 *               30,                 // parameters passed by copy do not need boost::ref
 *               _1, _2));           // finally two place holders, that will be replaced at call time with threadID and threadNum
 * 
 * // To parallelize a member function
 * class A{ foo(CImageMono& dst, const CImageMono& src, int th, uint32_t threadID, uint32_t threadNum) } a;
 * // ... ecco come fare:
 * Parallelize(
 *   boost::bind(&A::foo,            // the pointer to member of the member to be parallelized (this is more similar to an offset than to a pointer)
 *               &a,                 // the pointer to the class instance whose member needs to be parallelized
 *               boost::ref(dst),    // the parameters to be passed to the function: for passing by reference boost::ref needs to be used
 *               boost::cref(src),   // or alternatively boost::cref for const references
 *               30,                 // parameters passed by copy do not need boost::ref
 *               _1, _2));           // finally two place holders, that will be replaced at call time with threadID and threadNum
 * \endcode
 **/
template <typename F>
void Parallelize(const F& f,
		uint32_t num_threads = std::max(boost::thread::hardware_concurrency(), 1U))
{
    boost::thread_group g;
    for(uint32_t core = 0; core < num_threads; core++)
        g.create_thread(boost::bind(f, core, num_threads));
    g.join_all();
}

#endif
