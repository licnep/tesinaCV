/**
 * \file Backtrace.h
 * \brief Macro for getting the current backtrace
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _BACKTRACE_H
#define _BACKTRACE_H

#include <execinfo.h>


namespace vl
{

/**
 * Declare and fills a void pointer called array containing the current backtrace
 * \code
 * BACKTRACE();
 * \endcode
 */
#define BACKTRACE() { void *array[16]; size_t size; size = backtrace (array, 16); backtrace_symbols_fd(array,size,1); }
} // namespace vl

#endif
