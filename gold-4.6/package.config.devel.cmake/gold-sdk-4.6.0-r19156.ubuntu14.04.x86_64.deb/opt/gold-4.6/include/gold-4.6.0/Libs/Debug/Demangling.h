#ifndef _DEMANGLING_H
#define _DEMANGLING_H

#ifdef HAVE_GCC_ABI_DEMANGLE
#include <cxxabi.h>
#include <string>

namespace vl
{
	inline const std::string Demangle(const char* name)
	{
		int status = -4;
		char* res = abi::__cxa_demangle(name, NULL, NULL, &status);
		const char* const demangled_name = (status==0)?res:name;
		std::string ret_val(demangled_name);
		free(res);
		return ret_val;
	}
} // namespace vl
#else

namespace vl
{

inline const std::string Demangle(const char* mangled)
{
	return mangled;
}
} // namespace vl
#endif

#endif // _DEMANGLING_H
