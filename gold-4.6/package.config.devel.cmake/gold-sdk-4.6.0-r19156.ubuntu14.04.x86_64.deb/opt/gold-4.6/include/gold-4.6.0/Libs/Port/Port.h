/**
 * \file Port/Port.h
 * \authors Paolo Grisleri <grisleri@ce.unipr.it>
 * \brief Abstract base class for a generic port.
 *
 * This is a base class for a generic boost::asio based port.
 * The class offers the basic methods for a port such as reading bytes until a
 * requested delimiter, or writing bytes.
 *
 * This is an abstract interface for concrete classes: \see vl::SerialPort and vl::TCPPort
 */

#ifndef _PORT_H
#define _PORT_H

#include <boost/property_tree/ptree.hpp>
#include <boost/thread.hpp>
#include <boost/asio.hpp>

#include <string>

#include <Libs/Port/gold_vlport_export.h>


namespace vl
{

/**
 * \brief base class for modeling a phisical port such as serial or TCP.
 */
class GOLD_VLPORT_EXPORT Port
{
public:
	typedef boost::property_tree::ptree OptionsType;

	/**
	 * \brief Possible Return types
	 */
	typedef enum Result
    {
        Available,  //< The result is available
        InProgress, //< The action is still in progress
        Success,    //< The operation has been completed succesfully
        Error,      //< The operation has been completed with an error
        Timeout     //< The operation has timed out
    } ResultType;


    /**
     * \brief Default constructor
     */
    Port();

    /**
     * \brief Virtual destructor
     */
    virtual ~Port();

    /**
     * \brief Open the port with the requested parameters.
     *
     * 	This function has to be reimplemented in the concrete class.
     * \param params property tree containing the parameters specific for a port
     * \return The result of the operation
     */
    virtual Result Open(const boost::property_tree::ptree& params) = 0;

    /**
     * \brief Closes the port.
     *
     * The port is automatically closed when the object is destroyed
     */
    virtual void Close() = 0;

    /**
     * \brief Flushes the read buffer.
     *
     * Removes all the bytes from the read buffer
     */
    virtual bool Flush() = 0;

    /**
     * \brief Enable or disable the verbosity
     * \param enabled true to enable the verbosity, false to disable
     */
    void SetVerbosity(bool enabled) { m_verbose = enabled; }

    /**
     * \brief Set the current timeout for the port operations
     */
    void SetTimeout(const boost::posix_time::time_duration& timeout) { m_timeout = timeout; }

    /**
     * \brief Set the delimiter used for ReadUntil
     */
    inline void SetDelimiter( const std::string& delimiter ){ m_delimiter = delimiter; }

    /**
     * \brief Write a string of bytes on the port
     * \param buf source buffer to be written on the port
     * \return The result of the operation
     */
    virtual ResultType Write( const std::string& str ) = 0;

    /**
     * \brief Read bytes in the string buf, until the delimiter is found
     * \param buf destination buffer where the bytes will be stored
     * \return The result of the operation
     */
    virtual ResultType ReadUntil( std::string& buf ) = 0;

    /**
     * \brief Read n bytes in buf
     * \param buf destination buffer where the bytes will be stored
     * \param n number of bytes to be read
     * \return The result of the operation
     */
    virtual ResultType ReadN( std::string& buf, std::size_t n ) = 0;

    /**
     * \brief return true if the port is currently open
     */
    virtual bool IsOpen() const = 0;

    /**
     * \brief Returns true if the verbosity is currently enabled
     */
    bool Verbose() const { return m_verbose; }

protected:
    // asio stuff available for the implementations

    boost::asio::io_service io_service;  ///< boost asio io service
    boost::asio::io_service::work work;  ///< boost asio work object

    OptionsType m_options; ///< Options
    boost::posix_time::time_duration m_timeout; ///< Timeout
    std::string m_delimiter; ///< delimiter
    bool m_verbose;  ///< Verbosity

private:
    /**
     * \brief asio thread
     */
    void Thread();

    boost::thread m_thread; ///< the thread object

    enum Result m_result;  ///< Used by read with timeout


};

} // namespace vl

#endif
