
#ifndef GOLD_VLPORT_EXPORT_H
#define GOLD_VLPORT_EXPORT_H

#ifdef GOLD_VLPORT_STATIC_DEFINE
#  define GOLD_VLPORT_EXPORT
#  define GOLD_VLPORT_NO_EXPORT
#else
#  ifndef GOLD_VLPORT_EXPORT
#    ifdef gold_vlport_EXPORTS
        /* We are building this library */
#      define GOLD_VLPORT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define GOLD_VLPORT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef GOLD_VLPORT_NO_EXPORT
#    define GOLD_VLPORT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef GOLD_VLPORT_DEPRECATED
#  define GOLD_VLPORT_DEPRECATED __attribute__ ((__deprecated__))
#  define GOLD_VLPORT_DEPRECATED_EXPORT GOLD_VLPORT_EXPORT __attribute__ ((__deprecated__))
#  define GOLD_VLPORT_DEPRECATED_NO_EXPORT GOLD_VLPORT_NO_EXPORT __attribute__ ((__deprecated__))
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define GOLD_VLPORT_NO_DEPRECATED
#endif

#endif
