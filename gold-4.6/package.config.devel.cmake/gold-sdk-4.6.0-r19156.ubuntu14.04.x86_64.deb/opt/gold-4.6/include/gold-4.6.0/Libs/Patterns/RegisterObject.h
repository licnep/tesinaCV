/**
 * \file RegisterObject.h
 * \brief Utilities for registering automatically components such as plugins
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef _REGISTER_OBJECT_H
#define _REGISTER_OBJECT_H

#include <Libs/Patterns/Singleton.h>

// #define REGISTER_OBJECT_VERBOSE

#ifdef REGISTER_OBJECT_VERBOSE
#include <Libs/Debug/Demangling.h>
#include <iostream>
#include <typeinfo>
#endif

namespace vl
{
/**
 * \brief Template providing a constructor for registering an object into the proprer singleton factory
 *
 * This template works in a very specific manner together with the classes in defined in Singleton.h
 * and Factory.h. The template accept as parameters the factory where the component will be registered
 * and the component type.
 *
 * The template constructor, accesses the factory instance using the singleton interface and
 * register into the factory, an allocator for the required component using the required key.
 *
 * \tparam F Factory where the allocator shall be created. The factory must be accessible through the Singleton interface
 * \tparam T Class whose allocator has to be registered in the factory
 *
 * \see Singleton, Factory
 *
 * this is an example
 * \example Driver_Registration.h
 *
 * this is code
 * \code
 * #ifndef _CDRIVER_REGISTRATION
 * #define _CDRIVER_REGISTRATION
 * #include <Libs/Patterns/Singleton.h>
 * #include <Libs/Patterns/Factory.h>
 * #include <Libs/Patterns/RegisterObject.h>
 *
 * #include <DDK/gold_ddk_export.h>
 * namespace ddk
 * {
 *   class CDriver;
 *   namespace impl
 *   {
 *     class CDriverInitializer;
 *     // tipo per la factory a singleton
 *     typedef boost::function<CDriver*(CDriverInitializer&)> CDriverAllocatorType;
 *     typedef vl::Factory<std::string, CDriver, CDriverAllocatorType> CDriverFactoryType;
 *   }
 * }
 *
 * #define REGISTER_DRIVER(CLASS,STRNAME) vl::ObjectRegistrar< ddk::impl::CDriverFactoryType, CLASS > drf_##CLASS(STRNAME)
 *
 * #endif
 * \endcode
 */
template<typename F, typename T>
class ObjectRegistrar
{
public:
	/**
	 * \brief constructor for registering an object in the factory using the required key
	 *
	 * \param key key for registering and retrieving the object in the factory
	 */
	ObjectRegistrar(const typename F::KeyType& key)
	{
#ifdef REGISTER_OBJECT_VERBOSE
		std::cout << "ObjectRegistrar::ObjectRegistrar " << "\n"
		<< " Register " << gold::Demangle(typeid(T).name()) << "\n"
		<< " Factory " << gold::Demangle(typeid(typename F::AbstractProductType).name()) <<"    ( " << gold::Demangle(typeid(F).name()) << " )" <<"\n"
		<< " @" << (void*)&(vl::Singleton<F>::Instance()) << "\n"
		<< std::endl;
#endif // REGISTER_OBJECT_VERBOSE
		vl::Singleton<F>::Instance().template RegisterObject<T>(key);
	}
};
} // namespace vl

/**
 * \brief Registration macro for self registering components
 *
 * \param FACTORY the factory where the allocator will be created
 * \param CLASS the class to be registered into the factory
 * \param STRNAME the name to be used for accessing the allocator for CLASS
 *
 * This macro is provided for automatically registering components.
 * The macro declares a static instance of vl::ObjectRegistrar object
 * passing to the constructor the proper arguments for registering the
 * class into the factory.
 * The macro shall be placed at the end of the file and should look as follows.
 *
 * \code
 * // self_registering_componentfile.cpp
 * class SRClass
 * {
 *   // ...
 * };
 *
 * REGISTER_OBJECT(MyFactory, SRClass, "Name");
 *
 * \endcode
 */
#define REGISTER_OBJECT(FACTORY, CLASS, STRNAME) vl::ObjectRegistrar< FACTORY, CLASS  > drf##FACTORY_##CLASS(STRNAME)
// NOTE: si può fare una macro che genera altre macro?
// in alternativa si può specializzare questa nella register

#endif // _REGISTER_OBJECT_H
