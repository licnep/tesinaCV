/** \file strcast.h
 *  \brief Helper function per castare da numero a stringa e viceversa
 *  \author Paolo Medici (medici@ce.unipr.it)
 **/
#ifndef _STRCAST_H
#define _STRCAST_H

#include <cstring>
#include <sstream>
#include <boost/type_traits/is_enum.hpp>
#include <boost/utility/enable_if.hpp>
#include <vector>
#include <stdexcept>
#include <boost/algorithm/string/predicate.hpp>

#if __cplusplus==201103L
#include <type_traits>
#endif


#define ENABLE_LEXICAL_CAST_SPECIALIZATIONS

#ifdef ENABLE_LEXICAL_CAST_SPECIALIZATIONS

#include <boost/lexical_cast.hpp>

#include <sstream>
#include <boost/type_traits/is_enum.hpp>
#include <boost/utility/enable_if.hpp>

template<typename T>
inline typename boost::enable_if<boost::is_enum<T>, std::ostream&>::type
operator <<(std::ostream& s, const T& value)
{
#if __cplusplus==201103L
  // With C++11 there is a formally correct solution
  typedef typename std::underlying_type<T>::type safe_type;
#else
  // this is not formally correct: see http://stackoverflow.com/questions/1528374
  typedef long safe_type;
#endif
  safe_type x = static_cast<safe_type>(value);
  s << x;
  return s;
}


template<typename T>
inline typename boost::enable_if<boost::is_enum<T>, std::istream&>::type
operator >>(std::istream& s, T& value)
{
#if __cplusplus==201103L
  // With C++11 there is a formally correct solution
  typedef typename std::underlying_type<T>::type safe_type;
#else
  // this is not formally correct: see http://stackoverflow.com/questions/1528374
  typedef long safe_type;
#endif
  safe_type x;
  s >> x;
  value = T (x);
  return s;
}


// boost lexical cast specialization version
namespace boost 
{

template<>
inline int lexical_cast(const std::string& arg)
{
    char* stop;
    int res = strtol( arg.c_str(), &stop, 10 );
    if ( *stop != 0 ) throw_exception(bad_lexical_cast(typeid(int), typeid(std::string)));
    return res;
}

template<>
inline std::string lexical_cast(const int& arg)
{
    char buffer[65]; // large enough for arg < 2^200
    snprintf(buffer, 10, "%d",  arg );
    return std::string( buffer ); // RVO will take place here
}

/**
 * overload per std::string (per migliorare le performance)
 * (in teoria non si deve fare un numeric_cast per castare
 * una stringa a stringa comunque!)
 */

template<>
inline std::string lexical_cast(const std::string& arg)
{
    return arg;
}

template<>
inline const char* lexical_cast(const std::string& str)
{
    return str.c_str();
}

template<>
inline unsigned char lexical_cast(const std::string& str)
{
    // TODO this is very slow
    unsigned int m_value;
    std::istringstream(str) >> m_value;
    return m_value;  
}
	
template<>
inline std::string lexical_cast(const bool& arg)
{
    return arg ? std::string("TRUE") : std::string("FALSE");
}

template<>
inline bool lexical_cast(const std::string& str)
{
        if ( boost::iequals(str, "1") ||
             boost::iequals(str, "true") ||
             boost::iequals(str,"y") ||
             boost::iequals(str, "yes") ||
             boost::iequals(str, "on") )
            return true;
        else if ( boost::iequals(str, "0") ||
             boost::iequals(str, "false") ||
             boost::iequals(str, "n") ||
             boost::iequals(str, "no") ||
             boost::iequals(str, "off") )
            return false;
        //  throw exception // bad_lexical_cast
        throw_exception(bad_lexical_cast(typeid(bool), typeid(std::string)));
}


// boost::lexical_cast cannot be specialized for all the enums
// specialization for enums requires partial function template specialization
// which is not available on the language.
// On the other hand this overloading is ambiguous
// template<typename Target, typename Source>
// inline typename boost::enable_if<boost::is_enum<Source>, Source>::type
// lexical_cast(const Source& arg)
// {
//   std::cout << "specialization for enums" << std::endl;
//   return Target();
// }

}//namespace boost

// these two wrappers are now deprecated
namespace vl
{

template <typename T>
inline std::string string_cast(const T& value)
{
        return boost::lexical_cast<std::string>(value);
}

template <typename T>
inline T numeric_cast(const std::string& value)
{
        return boost::lexical_cast<T>(value);
}

} // namespace vl

#else
        namespace vl
        {
        namespace detail
        {
	  // ok. better covered by lexical_cast
          template<class T, typename IsEnum = void>
          struct string_cast
          {
              static std::string cast(const T & value)
              {
                   std::ostringstream oss;
                   oss << value;
                   return oss.str();
              }
          };

	  // ok. covered by lexical_cast
          template<class T>
          struct string_cast<T, typename boost::enable_if<boost::is_enum<T> >::type > {
              static std::string cast(const T & value)
              {
                   std::ostringstream oss;
                   oss << (int) value;
                   return oss.str();
              }
          };
        }


        /** converte un tipo qualsiasi in una stringa
          *
          * se un tipo ammette l'operatore << puo' essere convertito in questo modo a una stringa
          * \code
          * DrawText(string_cast(12));
          * \endcode
          **/
	// ok. covered by lexical_cast
        template <typename T>
        inline std::string string_cast(const T& value)
        {
             return vl::detail::string_cast<T>::cast(value);
        }

        /// specializzazione per per cast da string a string
        template<>
        inline std::string string_cast<std::string>(const std::string& value)
        {
            return value;
        }


        typedef char* c_string ; ///< un typedef per semplicare la specializzazione del template per char*

        /// specializzazione per per cast da const char * a string (per migliorare le performance)
        template<>
        inline std::string string_cast<c_string>(const c_string& value)
        {
            return value;
        }

	// ok. specialized lexical_cast
        template<>
        inline std::string string_cast<bool>(const bool & value)
        {
            return value ? std::string("TRUE") : std::string("FALSE");
        }

        template<>
        inline std::string string_cast<char>(const char & value)
        {
            return string_cast<int>(value);
        }

        template<>
        inline std::string string_cast<unsigned char>(const unsigned char & value)
        {
            return string_cast<unsigned int>(value);
        }

        template<class T, typename IsEnum = void>
        struct numeric_cast_detail {
            static T cast(const std::string& str)
            {
                T m_value;
                std::istringstream ss(str); // devo allocarlo esplicitamente
                ss >> m_value;
                return m_value;
            }
        };

        template<class T>
        struct numeric_cast_detail<T, typename boost::enable_if<boost::is_enum<T> >::type > {
            static T cast(const std::string& str)
            {
                int m_value;
                std::istringstream ss(str); // devo allocarlo esplicitamente
                ss >> m_value;
                return T(m_value);
            }
        };

        template<class T>
        struct numeric_cast_detail<std::vector<T> > {
            static std::vector<T> cast(const std::string& str)
            {
                std::istringstream in(str);
                std::vector<T> out;
                // TODO
                return out;
            }
        };

        // TODO: fare l'override per i char e i boolean
        /** Converte una stringa in un tipo designato
         *
         * In generale non e' proprio un numeric_cast,
         * ma piuttosto un cast che accetta l'operatore >>
         * \code
         * int value = numeric_cast<int>(std::string("12"));
         * \endcode
         * @note il cast da string a bool e' particolare e accetta in
         * ingresso anche `true','false','yes','no', etc etc
         **/
        template <class T>
        inline T numeric_cast(const std::string& str)
        {
            return numeric_cast_detail<T>::cast(str);
        }

        // ok. specialized lexical_cast
        template<>
        inline unsigned char numeric_cast<unsigned char>(const std::string& str)
        {
            unsigned int m_value;
            std::istringstream(str) >> m_value;
            return m_value;
        }


        /**
         * overload per std::string (per migliorare le performance)
         * (in teoria non si deve fare un numeric_cast per castare
         * una stringa a stringa comunque!)
         */

        template<>
        inline std::string numeric_cast<std::string>(const std::string& str)
        {
            return str;
        }

        /**
         * overload per const char*
         */
        template<>
        inline const char * numeric_cast<const char *>(const std::string& str)
        {
            return str.c_str();
        }

        /**
         * Cast specifico per castare da stringhe a bool
         * usando i valori stringa 0,1,true,false,yes,no,on,off
         * E' nel file H perche' COMMON non ha uno shared object
         */
	// ok. specialized lexical_cast	
        template<>
        inline bool numeric_cast<bool>(const std::string& str)
        {

            if ( boost::iequals(str, "1") ||
                 boost::iequals(str, "true") ||
                 boost::iequals(str,"y") ||
                 boost::iequals(str, "yes") ||
                 boost::iequals(str, "on") )
                return true;
            else if ( boost::iequals(str, "0") ||
                 boost::iequals(str, "false") ||
                 boost::iequals(str, "n") ||
                 boost::iequals(str, "no") ||
                 boost::iequals(str, "off") )
                return false;
            //  throw exception
            throw std::runtime_error("Invalid numeric_cast<bool> from `" + str + "'");
            return false;
        }


        } // namespace vl

#endif // ENABLE_LEXICAL_CAST_SPECIALIZATIONS





#endif

