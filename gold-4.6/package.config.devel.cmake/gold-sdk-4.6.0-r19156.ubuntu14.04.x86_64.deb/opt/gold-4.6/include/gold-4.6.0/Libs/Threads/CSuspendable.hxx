/**
 * \file CSuspendable.hxx
 * \brief Threads synchronization with Semaphore and CSuspendable
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */


#ifndef _C_SUSPENDABLE_H
#define _C_SUSPENDABLE_H

#include <boost/thread/mutex.hpp>
#include <boost/thread/condition.hpp>
#include <Libs/Compatibility/DeclSpecs.h>

namespace vl
{
namespace thread
{

/**
 * \brief Classic semaphore implementation for thread synchronization.
 *
 * Semaphores have a number of places and a very simple wait/signal API.
 * When the number of places is 0, the wait is blocking.
 * When the wait is invoked the number of places is decreased.
 * When the signal is invoked the number of places is increased-
 *
 */
class DECLSPEC_EXPORT Semaphore
{
public:
	/** \brief constructor */
	Semaphore() :
			m_places(0u)
	{
	}

	/**
	 * \brief Suspends a thread while the number of places is 0
	 */
	void wait()
	{
		boost::mutex::scoped_lock lock(m_mutex);
		// std::cout <<"Semaphore.wait@"<<(void*)this<<" " <<m_places<< std::endl;
		while (m_places == 0)
			m_cond.wait(lock);
		--m_places;
	}

	/**
	 * \brief Signal the availability of a new place
	 */
	void signal()
	{
		{
			boost::mutex::scoped_lock lock(m_mutex);
			++m_places;
			// std::cout <<"Semaphore.signal@"<<(void*)this<<" " <<m_places<< std::endl;
		}

		m_cond.notify_all();
	}

private:
	boost::mutex m_mutex;  ///< mutual exclusion
	boost::condition m_cond;   ///< condition variable suspending
	unsigned int m_places; ///< storage for the number of places
};

/**
 * \brief class for suspending and resuming thread
 *
 * This class can be encapsulated in other classes running threads that shall be
 * suspended and resumed depending on external conditions
 * Do not use this class as base for other classes since this choice may rise
 * synchronization problems and races in the derived classes.
 * Prefer encapsulation instead.
 * \code
 * class ClassWithThread
 * {
 * 	bool m_suspend_condition;
 * 	boost::thread m_thread;
 *  CSuspendable m_suspendable;
 * 	public:
 *     ClassWithThread()
 *     {
 *     	m_thread=boost::thread(boost::bind(ClassWithThread::Thread, this));
 *     }
 *     void Thread()
 *     {
 *  	   while(1)
 *     		{
 *     			if(m_suspend_condition)
 *     			{
 *     				suspendable.Suspend();
 *     			}
 *
 *     			// thread work here ...
 * 		    }
 *     }
 *
 *     // user code for resuming the thread
 *     void Resume()
 *     {
 *      	suspendable.WakeUp();
 *     }
 *
 *	   // user code for suspending the thread
 *     void Suspend()
 *     {
 *     		m_suspend_condition=true;
 *     }
 * };
 * \endcode
 */
class DECLSPEC_EXPORT CSuspendable
{
public:
	/**
	 * Default constructor
	 */
	CSuspendable() :
			m_signaled(false)
	{
	}
	;

	/**
	 * Destructor
	 */
	~CSuspendable()
	{
	}

	/**
	 * \brief Suspends the thread and resume it after a timeout
	 *
	 * \param timeout timeout value
	 * \return true if the timeout has been reached, false if the object has been waked up
	 */
	bool Suspend(const boost::posix_time::time_duration& timeout)
	{
		boost::mutex::scoped_lock lock(m_mutex);
		bool retval = m_cond.timed_wait(lock, timeout);
		m_signaled = !retval;
		return retval;
	}

	/**
	 * \brief Suspends the thread indefinitely
	 *
	 * Be careful to avoid thread blocked, especially when closing the process
	 */
	void Suspend()
	{
		boost::mutex::scoped_lock lock(m_mutex);

		// std::cout << "suspend begin ("<<(void*) this << ") status was " << m_signaled << std::endl;
		while (!m_signaled)
			m_cond.wait(lock);

		m_signaled = false;
		// std::cout << "suspend end ("<<(void*) this << ") status is " << m_signaled << std::endl;
	}

	/**
	 * \brief Wake up blocked threads
	 */
	void WakeUp()
	{
		// std::cout << "wakeup begin ("<<(void*) this << ") status was " << m_signaled << std::endl;
		{
			boost::mutex::scoped_lock lock(m_mutex);
			m_signaled = true;
		}
		m_cond.notify_all();
		// std::cout << "wakeup end ("<<(void*) this << ") status is " << m_signaled << std::endl;
	}

private:

	boost::mutex m_mutex; ///< mutex for exclusive access
	boost::condition m_cond;  ///< condition variable for blocking threads
	bool m_signaled;     ///< true when WakeUp has been called
};

} // namespace thread
} // namespace vl

#endif

