/** \file TimeUtils.h
 *  \brief Cross platform time retrival and printing functions
 *  \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 **/

#ifndef _TIME_UTILS_H
#define _TIME_UTILS_H

#include <boost/date_time/posix_time/posix_time_types.hpp>

#include <cstdio>

#if defined(_MSC_VER)
   #include <windows.h>
#endif 

#include <Libs/Time/gold_time_export.h>


namespace vl
{
  
/**
 * \brief namespace containing the time management functions
 */
namespace chrono
{
  
/**
 * \brief Time relative to an absolute origin.
 * \see boost::posix_time::time_duration for more information
 */
typedef boost::posix_time::time_duration TimeType;

/**
 * \brief Absolute time
 * \see boost::posix_time::ptime for more information
 */
typedef boost::posix_time::ptime AbsoluteTimeType;

/**
 * \brief Fills the parameter with the current UTC clock value.
 * \param [out] abs_time the current UTC time in boost::posix_time::posix_time
 * \see GetClock_RealTime
 */
GOLD_TIME_EXPORT void GetClock(AbsoluteTimeType& abs_time);


/**
 * \brief Fills the parameter with the current UTC clock value.
 * On posix platforms, where librt is available,
 * clock_gettime(CLOCK_MONOTONIC, &ts) is used to read the clock value
 * On the other platforms boost::posix_time::microsec_clock::universal_time is called
 * \param [out] abs_time the current UTC time in boost::posix_time::posix_time
 */
GOLD_TIME_EXPORT void GetClock_RealTime(AbsoluteTimeType& abs_time);


/**
 * \brief Fills the parameter with the current UTC monotonic clock value.
 * On posix platforms, where librt is available,
 * clock_gettime(CLOCK_MONOTONIC, &ts) is used to read the clock value
 * On the other platforms boost::posix_time::microsec_clock::universal_time is called
 * \param [out] abs_time the current UTC time in boost::posix_time::posix_time
 */
GOLD_TIME_EXPORT void GetClock_Monotonic(AbsoluteTimeType& abs_time);

/**
 * \brief Fills the parameter with time spent by the CPU executing the current thread.
 * On posix platforms, where librt is available,
 * clock_gettime(CLOCK_THREAD_CPUTIME_ID, &ts) is used to read the clock value
 * On the other platforms this function do not modify the argument
 * \param [out] abs_time the current UTC time in boost::posix_time::posix_time
 */
GOLD_TIME_EXPORT void GetThreadTime(TimeType& abs_time);


/**
 * \brief Fills the parameter with the time spent by the CPU executing the current process.
 * On posix platforms, where librt is available,
 * clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &ts) is used to read the clock value
 * On the other platforms this function do not modify the argument
 * \param [out] abs_time the current UTC time in boost::posix_time::posix_time
 */
GOLD_TIME_EXPORT void GetProcessTime(TimeType& abs_time);


/**
 * \brief Returns a reference to an Epoch=01/01/1970 AbsoluteTimeType instance.
 * The instance is statically allocated thus no allocations
 * are executed when calling this function
 * \return reference to the Epoch instance
 */
GOLD_TIME_EXPORT const AbsoluteTimeType& Epoch();

/**
 * \brief Returns a reference to an Zero TimeType instance.
 * The instance is statically allocated thus no allocation
 * are executed when calling this functions
 * \return reference to the Zero TimeType instance
 */
GOLD_TIME_EXPORT const TimeType& TimeZero();


/**
 * Prints the time duration on char array
 * The output array must be already allocated by the user
 * print changes depending on the duration of the argument
 * for short durations the value in [us], [ms], or [s] is printed
 * for durations longer than one minute, the "hhmmss.us" format is used
 * and must be wide enough to host the string.
 * @param [out] str char array to be filled with the print
 * @param [in]    d time duration to be printed
 */
GOLD_TIME_EXPORT void time_to_str ( char* str, const TimeType& d );

} // namespace chrono
} // namespace vl



#include <boost/version.hpp>

#if not defined (__APPLE__)
#if BOOST_VERSION >= 104700    

#include <boost/chrono.hpp>

namespace vl
{
namespace chrono
{
template <typename OStreamType, 
          class DurationType,
          int digits>
void format(OStreamType& os, DurationType d)
{
    // fill with '0' up to digits
    if(digits)
    {
      int d2k[8]={0, 1, 10, 100, 1000, 10000, 100000, 1000000};
      for(int i=digits; i>0; --i)
        if(d<DurationType(d2k[i]))
          os<<'0';    
    }
    os << d.count();
}

// format duration as [-]d/hh::mm::ss.cc
template <class CharT, class Traits, class Rep, class Period>
std::basic_ostream<CharT, Traits>&
display(std::basic_ostream<CharT, Traits>& os,
        boost::chrono::duration<Rep, Period> d)
{
    // boost::chrono::thread_clock::duration start = boost::chrono::thread_clock::now().time_since_epoch();

    // typedef boost::chrono::duration<long long, boost::ratio<86400> > days;
    typedef boost::chrono::duration<long long, boost::micro> microseconds;

    // if negative, print negative sign and negate
    if (d < boost::chrono::duration<Rep, Period>(0))
    {
        d = -d;
        os << '-';
    }
    // round d to nearest centiseconds, to even on tie
    microseconds us = boost::chrono::duration_cast<microseconds>(d);
    // if (d - us > boost::chrono::milliseconds(5) || 
    //    (d - cs == boost::chrono::milliseconds(5) && cs.count() & 1))
    //    ++cs;
    // separate seconds from centiseconds
    boost::chrono::seconds s = boost::chrono::duration_cast<boost::chrono::seconds>(us);
    us -= s;
    // separate minutes from seconds
    boost::chrono::minutes m = boost::chrono::duration_cast<boost::chrono::minutes>(s);
    s -= m;
    // separate hours from minutes
    boost::chrono::hours h = boost::chrono::duration_cast<boost::chrono::hours>(m);
    m -= h;
    
    typedef std::basic_ostream<CharT, Traits> OStreamType;
    format<OStreamType, boost::chrono::hours, 4>(os, h);
    os << ':';     
    format(os, m);
    os << ':';
    format(os, s);            
    os << '.';
    format<OStreamType, microseconds, 6>(os, us);
    
    // os << std::setw(6) << std::setfill('0') << us.count() << ':';
    // boost::chrono::thread_clock::duration stop = boost::chrono::thread_clock::now().time_since_epoch();
    // os << "  (done in " << stop-start << ")"; 
    
    return os;
}

} // namespace chrono
} // namesopace vl

#endif // BOOST_VERSION >= 104700   

#endif // not defined (__APPLE__)

#endif // _TIME_UTILS_H
