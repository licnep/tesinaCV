/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2009                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/
/** @file INIFile.h
  * @brief This file contain classes (INIFile) to manage configuration file (INI/HWS)
  *
  * In generale quello che deve fare la libreria di gestione dei fili di configurazione e'
  * - gestire file di testo in lettura e scrittura, supportando commenti
  * - gestire i file in maniera gerarchica con nodi (embedded o facenti parte di altri file)
  * - modalita' di accesso ai valore con parametro di default se questo non esiste (INIFile::Get)
  * - modalita' di accesso ai valori con lancio di eccezione se questo non esiste (INIFile::Value)
  * - possibilita' di aggiungere o modificare un valore se esistente (INIFile::set)
  * - possibilita' di accedere sia al valore stringa (INIFile::efind) che al record completo INIFileLine (INIFile::ifind).
  * - gestione IO di tipi base
  *
  * - READ: template<class T> INIFile::Value(), template<class T> INIFile::Value(const T & default)
  * - WRITE: template<class T> INIFile::Set(const std::string & key, const T & value);
  * - INIFile::Node(key name, bool create_if_not_exist = true)
  *
  * file INI 4.0
  * - RW: INIFile::operator []
  * - regular expression?
  * @author Paolo Medici (medici@ce.unipr.it)
  **/
#ifndef _INIFILE_H
#define _INIFILE_H

#include <vector>
#include <string>

#include <Libs/INIFiles/strcast.h>

#include <Libs/INIFiles/gold_inifiles_export.h>

namespace vl
{
  namespace ini
  {
/** proxy class per stringhe.
 *   Utile quando la massima informazione che si possiede e' la stringa ma
 *     si vuole usare specializzare un template per castare a numero.
 *
 * \code
 * string_proxy Get()
 *   { return string_proxy("1"); }
 * // ...
 * int pippo = Get();
 * std::string pluto = Get(); // attenzione che potrebbe avere dei problemi questa versione
 * \endcode
 *
 *  allo stesso modo puo' essere usato per castare una stringa a un qualsiasi valore che soddisfa il tipo.
 * \code
 * void Funzione(int x);
 * // ...
 * Funzione(string_proxy("1"));
 * \endcode
**/
class string_proxy {
    std::string m_s;
public:
    string_proxy(std::string s): m_s(s) {}
    string_proxy(const string_proxy & s) : m_s(s.m_s) {}

    /// oggetto che si occupa di castare questa classe al valore richiesto
    template<class T>
    inline operator T() const {
        return numeric_cast<T>(m_s);
    }
    /// overload per le stringhe (per migliorare le performance)
    inline operator std::string() const
    {
        return m_s;
    }
};

/// comment line delimiter
#define CH_COMMENT  '#'

/// Variable identifier
#define CH_VARIABLE '$'

// disabled line signature character
// #define CH_DISABLE  '!'

// Forward Declaration for node
class INIFile;
class CINIFileCache;

/// to help migration to shared_ptr is suggested to use PINIFile instead of INIFile *
typedef INIFile *PINIFile;
/// to help migration to shared_ptr is suggested to use PINIFile instead of INIFile *
typedef const INIFile * PCINIFile;

/// Tipo del nodo, per ricerca
enum ININodeType {
    Node_Unknown = 0,   ///< Unknown Node
    Node_Item = 1,      ///< Item
    Node_Section = 2,   ///< Section
    Node_Include = 4,   ///< Include
    Node_All = 7        ///< Item + Section + Include
};

/** la struttura che raccoglie ogni linea del file di configurazione
  *
  *  Si possono considerare coppie chiave - valore, anche se poi al loro interno
  *  ci sono diverse variabili di formattazione.
  *
  * Dalla nuova versione un INIFileLine puo' contenere dei sotto-file/sezioni per
  *  creare una specie di gerarchia di classi
  **/
class GOLD_INIFILES_EXPORT INIFileLine {
public:
    /// Elenco delle flag di m_flags
    enum Flags {
        Disabled = 1,       ///< disabilitato (i Get ritornano dato non trovato)
        Const = 2,          ///< dato costante. Set non ha effetto.
        Inheritable = 4,    ///< ereditabile: i figli ereditano questo valore
        Volatile = 8,       ///< valore volatile: non verra' salvato su disco in salvataggio (es. dati ereditati)
        Private = 16,       ///< dato privato, i parenti (genitori) non possono leggerlo
        Parsing = 32,       ///< forza il parsing del nodo a ogni Get invece che in fase di load
        Parsed  = 64,       ///< Il dato conteneva un $ che e' stato rimosso
        Owned = 128   ///< dato da rimuovere
    };
public:
    int m_flags;        ///< flags da Flags

    std::string key;        ///< key of che parameter (can be empty)
    std::string value;      ///< value of parameter (can be empty if key is empty)
    std::string original;   ///< valore originale (quando Parsing sara' pronto puo' essere tolto)
    /// Se m_node e' diverso da NULL questo INIFile rimanda a un child, o a una section
    ///  m_node e value sono mutuamente esclusivi.
    PINIFile m_node;

    // parte cosmetica:
    unsigned int m_empty_line;  ///< numero di linee bianche precedenti
    std::string m_comment;      ///< comment (can be empty)
    std::string m_type;         ///< type of data (can be used to validate value) [unused yet]

public:
    INIFileLine() : m_flags(0), m_node(NULL), m_empty_line(0) {}
    INIFileLine(const std::string & _key, const std::string & _value = std::string()) : m_flags(0), key(_key), value(_value), m_node(NULL), m_empty_line(0) {}
    ~INIFileLine() {}

    /// riporta al default i parametri
    void reset();

    /// Return the Key
    inline const std::string & Key() const {
        return key;
    }
    /// Return the Value
    inline const std::string & Value() const {
        return value;
    }

    /// Questo Item e' un sotto nodo (m_node valido e value empty)
    inline bool IsNode() const {
        return m_node != NULL;
    }

    /// Return the associated node to this object (can be NULL.. lanciare una eccezione?)
    inline PINIFile Node() const {
        return m_node;
    }

    /// Salva i dati contenuti nel INIFile in un ostream (come se fossero in un file INI)
    bool Export(std::ostream & stream, unsigned int indentation=0) const;

    /// write a debug line
    void debug() const;
};

inline  std::ostream& operator<<(std::ostream & out, const INIFileLine & in)
{
    in.Export(out);
    return out;
}


/**
 * The old definition is deprecated
 */
typedef GOLD_INIFILES_DEPRECATED INIFile IniFile;


#ifdef _INIFILE3
/// Classe per manipolare il contenuto di un INI File usando []
/// preliminary release.
class ini_item_proxy {
    std::string m_key;     ///< la chiave: serve nel set se m_line==NULL
    INIFile *m_file;       ///< il file: serve nel set
    INIFileLine *m_line;   ///< l'oggetto: serve nel set e nel get
public:
    ini_item_proxy(const std::string & key, INIFile *file, INIFileLine *line): m_key(key), m_file(file), m_line(line) {}

    /// la chiave esiste?
    /// \code
    /// m_ini["key"].exist()
    /// \endcode
    inline bool exist() const
    {
        return m_line != NULL;
    }

    /// replace or insert a new value in file
    /// Usanto internamente dall'operator =
    INIFileLine *set(const std::string & new_value) const;

    /// Assegnamento
    /// (wrapper per set)
    /// \code
    /// m_ini["key"] = value;
    /// \endcode
    /// @note se la chiave non esiste, la crea
    template<class T>
    void operator = (const T & value) const
    {
        m_line = set (  string_cast<T>(value) );
    }

    /// oggetto che si occupa di castare questa classe al valore richiesto
    /// \code
    /// value = m_ini["key"];
    /// \endcode
    /// @note lancia una eccezione se la chiave non esiste.
    template<class T>
    operator T() const {
        if (!m_line)
            throw std::runtime_error
            ("key " + m_key + "not exist");
        return numeric_cast<T>( m_line->Value() );
    }


};
#endif

/** Class to manager configuration file
 *
 * This class can read and write INI file, get and set data from this file
 *
 * @note se si dispone di un dato proprio e si forniscono gli operatori >> e << e'
 *       possibile importare ed esportare direttamente questi dati dagli INIFile.
 **/
class GOLD_INIFILES_EXPORT INIFile {

    friend class INIFileLine;
#ifdef _INIFILE3
    friend class ini_item_proxy;
#endif

    /// un tipo vettore di linee
    typedef std::vector<INIFileLine> LineList_t;

public:

    /// some bit flags
    enum Flags {
        Section = 1, ///< File is a Section (Cannot be saved autonomous)
        Const   = 2, ///< File is Read Only (cannot be saved)
        Unflat  = 4  ///< Original file have inclusion. Cannot be saved
    };

    /// struttura che tiene traccia dei parametri per proseguire una ricerca di una particolare chiave
    /// TIPS: usare un template con un oggetto funzione?
    class GOLD_INIFILES_EXPORT iterator {
    private:
        /// la wildcard della ricerca
        std::string m_filter;
        /// filtro sul tipo di nodo
        ININodeType m_type;
        /// iteratore del punto dove INIFile::FindNext deve continuare la ricerca
        std::vector<INIFileLine>::iterator m_p;
        /// iteratore del punto dove INIFile::FindNext deve continuare la ricerca
        std::vector<INIFileLine>::iterator m_end;
    private:
        bool init();
    public:
        /// argument value
        std::vector<std::string> argv;
        /// argument count (deprecated: use argv.size())
        int argc;
    public:
        /** costruttore (usare Search di INIFile o chiamarlo direttamente)
          * \code
          * INIFile::iterator i(m_ini, "MASK*");
          *   // alternativamente
        * INIFile::iterator i = m_ini->Search("MASK*");
          * \endcode
          **/
        iterator(INIFile *ini, const std::string & key);
        ~iterator() {}

        /** metodo per testare se l'iteratore e' ancora valido
              * \code
              * for (INIFile::iterator i =  ...; (i) ; ++i)
              * \endcode
              **/
        operator bool () const {
            return m_p!=m_end;
        }

        /// Return the last INIFileLine detected
//      inline INIFileLine * operator *() const { return (m_p!=m_end) ? (&(*m_p)) : NULL; }
        inline INIFileLine & operator *() const {
            return (*m_p);
        }
        // inline INIFileLine & operator ->() const { return (*m_p); }

        /** metodo per incrementare l'operatore
              * \code
              * for (INIFile::iterator i =  ...; (i) ; ++i)
              * \endcode
              **/
        void operator ++ ();

    };

    /// struttura che tiene traccia dei parametri per proseguire una ricerca di una particolare chiave
    /// TIPS: usare un template con un oggetto funzione?
    class GOLD_INIFILES_EXPORT const_iterator {
    private:
        /// la wildcard della ricerca
        std::string m_filter;
        /// filtro sul tipo di nodo
        ININodeType m_type;
        /// iteratore del punto dove INIFile::FindNext deve continuare la ricerca
        std::vector<INIFileLine>::const_iterator m_p;
        /// iteratore del punto dove INIFile::FindNext deve continuare la ricerca
        std::vector<INIFileLine>::const_iterator m_end;
    private:
        bool init();
    public:
        /// argument value
        std::vector<std::string> argv;
        /// argument count (deprecated: use argv.size())
        int argc;
    public:
        /** costruttore (usare Search di INIFile o chiamarlo direttamente)
          * \code
          * INIFile::iterator i(m_ini, "MASK*");
          *   // alternativamente
        * INIFile::iterator i = m_ini->Search("MASK*");
          * \endcode
          **/
        const_iterator(const INIFile *ini, const std::string & key);
        ~const_iterator() {}

        /** metodo per testare se l'iteratore e' ancora valido
              * \code
              * for (INIFile::iterator i =  ...; (i) ; ++i)
              * \endcode
              **/
        operator bool () const {
            return m_p!=m_end;
        }

        /// Return the last INIFileLine detected
//      inline INIFileLine * operator *() const { return (m_p!=m_end) ? (&(*m_p)) : NULL; }
        inline const INIFileLine & operator *() const {
            return (*m_p);
        }
        // inline INIFileLine & operator ->() const { return (*m_p); }

        /** metodo per incrementare l'operatore
              * \code
              * for (INIFile::iterator i =  ...; (i) ; ++i)
              * \endcode
              **/
        void operator ++ ();

    };

private:

    /// The unique instance of INIFile Manager
    CINIFileCache *m_manager;

    /// file name (URL) of this INIFile
    std::string m_filename;

    /// (optional) comment at beginning of file
    std::string m_comment;

    /// vector that collect all the line in source file
    mutable LineList_t m_file;

    int m_flags;    ///< Ini File Flags. @see Flags
    mutable bool m_should_save; ///< The file is modified?

    /// questa struttura mantiene lo stato del file aperto (per debug)
    struct ifile {
        std::string filename;
        unsigned int line;

        ifile(const std::string & _filename) : filename(_filename) , line(0) { }
    };

    friend std::ostream & operator << (std::ostream & stream, const ifile & file);

private:

    /// return string parsed using current INIFile
    std::string parse_value(const std::string & str) const;

    /// Cerca una occorrenza e se non la trova ne alloca una nuova.
    ///  Visto che esiste la funzione INIFile::set questa serve piu' che altro per i nodi.
    /// @note garantisce che comunque un oggetto INIFileLine venga sempre ritornato
    /// @note m_should_save non viene toccato, visto che ikey viene usato in fase di load del file
    /// @note Mutable
    INIFileLine & ikey(const std::string & key) const;

    /// Verifica che non esista gia' un sottonodo (se no ritorna false)
    /// successivamente carica il file
    /// @note m_should_save non viene toccato, visto che isection viene usato in fase di load del file
    bool inode(const std::string & node, const std::string & filename);

    /// Crea una nuova section ma non la aggiunge al file (si comporta come loadNode).
    /// Non tocca pertanto m_should_save
    INIFile * section(const std::string & node);

    /// Sostituisce o aggiunge una occorrenza della chiave @a key.
    ///  solo se il valore @a value differisce dal precedente forza il
    ///  salvataggio del file in uscita.
    /// @return the INIFileLine
    INIFileLine & set(const std::string & key, const std::string & value);
    /// MUTABLE VERSION
    INIFileLine & set(const std::string & key, const std::string & value) const;

    // internal find
    /// trova la entry della key
    /// @note non ha la ricerca gerarchica: usare INIFile::Find invece
    /// @return NULL se @a key non esiste
    const INIFileLine * ifind(const std::string &key) const;
    /// trova la entry della key
    /// @note non ha la ricerca gerarchica: usare INIFile::Find invece
    /// @return NULL se @a key non esiste
    INIFileLine * ifind(const std::string &key);

    /// cerca la entry di @a key tra il file e le variabili di ambiente
    /// @param key chiave da cercare
    /// @return value if key is found or false if found but it is an empty string
    /// @note ammette la ricerca gerarchica
    bool efind(const std::string &key, std::string & out) const;

    /// Aggiunge un file al progetto corrente
    bool AppendFile(std::istream & in, ifile & status);

    /// Cancella il progetto corretto, e lo sostituisce usando il nuovo file specificato
    bool ImportFile(const std::string & file);

    /// Salva i dati contenuti nel INIFile in un ostream
    bool Export(std::ostream & stream, unsigned int indentation = 0) const;

    /// (only) if verbose is true `print key not found'
    void print_knf(const std::string & key) const;
    /// (only) if verbose is true `print key not found, using default'
    void print_knf_default(const std::string & key) const;
    /// throw key not found
    // void throw_knf(const std::string & key) const ;

    /** Il costruttore di copia, che non fa nulla! Non si puo' fare la copia di questo oggetto
     * altrimenti le modifiche apportate alla copia non si ripercuotono al padre e creano inconsistenza **/
    /// Non puo' esssere usato (pertanto lo piazzo privato e comunque genera un errore)
    INIFile(const INIFile & src);

    /// Non puo' esssere usato, questa funzione lancia una eccezione
    INIFile & operator = (const INIFile &src);

///@name metodi usati dall'interfaccia proxy_ini_file
    /*@{*/
    /// Questa funzione analizza un INIFileLine e ritorna il Value associato, eseguendo il parsing
    ///  della chiave
    std::string parse(const INIFileLine & pair) const;

    /// mark file modified if @a new_value is different from @a item->value
    void replace(INIFileLine *item, const std::string & new_value);

    /// add a new INIFileLine to project.
    /// deve essere usato quando si e' sicuri proprio che la chiave non esiste
    INIFileLine *insert(const std::string &key, const std::string & new_value);
    /*@}*/

public:

    static bool print_read_values;

    /// preliminary. Setta la verbosita' della libreria
    static bool SetVerbosity(bool Verbose);

public:

    /** Open (or Create) a INIFile. _filename must be an absolute path
     *
     *  Take care, that only one copy of any file is open at same time!
     * @param m_manager una istanza di CINIFileCache.
     * @param _filename un percorso (opzionalmente asssoluto)
     **/
    INIFile(CINIFileCache *m_manager, const std::string & _filename, bool section = false);

    /// dtor
    ~INIFile();

///@name Debug
    /*@{*/
    /// usa i parametri della linea di comando, modificandoli, per eseguire operazioni sui file INI
    bool ParseCmdLine(int *argc, char ***argv);

    /// Debug Purpose: print ini file and child
    bool print_tree(std::ostream & stream, int level=0) const;
    /// Debug Purpose: print the key
    bool print_contain(std::ostream & stream, bool inside=false, int level=0) const;
    /*@}*/

///@name Flags
    /*@{*/
    /// Questo file INI e' una Section?
    inline bool IsSection() const {
        return m_flags & Section;
    }
    /*@}*/

///@name gestione del nome del file
    /*@{*/
    /** Ritorna il nome del file di configurazione per questo oggetto
      * @note potrebbe essere anche non usabile direttamente, nel caso sia una sezione
      **/
    inline const std::string & GetFileName() const {
        return m_filename;
    }

    /** Change the absolute path of filename
      * @note ATTENZIONE: non cambia il suo nome in CINIFileCache
      * @note non fa Touch del file... va fatto manualmente
      **/
    void SetFileName(const std::string & filename);
    /*@}*/

    /// Esegue una copia del file corrente in un file nuovo e ritorna l'handle al file generato
    /// @note se e' gia' stata fatta una Clone o il file e' gia' stato aperto in precedenza ritorna
    ///       l'istanza precedente e non ne istanzia una nuova.
    INIFile *Clone(const std::string & file) const;

    /** Apre un file usando il manager corrente
     *
     * Non aggiunge il file aperto al file corrente.
     * @note Internamente usa gli xstream, pertanto puo' essere una URL
     * @note file dovrebbe essere un percorso assoluto (in maniera tale da essere univoco).
     **/
    INIFile *OpenFile(const std::string & file) const;

    /** Carica un altro file usando il corrente come percorso di ricerca e usando il corrente CINIFileCache
     * @note il file caricato non e' comunque in nessuna relazione con il file corrente, ma viene usato solo come trampolino per il percorso.
     * @param file e' un file
     * @note file dovrebbe essere un percorso relativo al file corrente
     **/
    INIFile *LoadNode(const std::string & file);

    /// Aggiunge il contenuto di un file esterno al file corrente
    /// @note attenzione a questa funzione!
    bool AppendFile(const std::string & file);

    /// Salva i dati contenuti nel INIFile nel file 'filename'
    bool ExportFile(const std::string & file) const;

///@name gestione modifiche
    /*@{*/
    /// Check current and embedded section is a Flush is required!
    bool IsModified() const;

    /// Flush modify onto configuration file
    bool Flush(void);

    /// Reload INIFile, discarding modify
    bool Reload(void) {
        // TODO: solo se e' un FILE... attenzione che ImportSovrascrive!
        return ImportFile(m_filename.c_str());
    }

    /// Indica al file di essere stato modificato dall'esterno
    inline void Touch() {
        m_should_save = true;
    }
    /// Rimuove la flag di modifica (nota: non modifica le flag dei sottonodi)
    inline void UnTouch() {
        m_should_save = false;
    }
    /*@}*/

    /** retrieve a child of current configuration file and if not exist, create it
      * @param node the name of sub-node
      **/
    PINIFile Node(const std::string & node);

    /** retrieve a child of current configuration file
      * @param node the name of sub-node
      * @return INIFile * or NULL if node not exist (or the param is not a node, for example a variabile)
      **/
    /*{*/
    PCINIFile FindNode(const std::string & node) const;
    PINIFile FindNode(const std::string & node);
    /*}*/

    /** cerca una occorrezza di key all'interno del file
    * @param key una stringa da cercare
    * @return il puntatore associato alla chiave se individuata, altrimenti NULL
    */
    INIFileLine *Find(const std::string & key);

    /** cerca una occorrezza di key all'interno del file
    * @param key una stringa da cercare
    * @return il puntatore associato alla chiave se individuata, altrimenti NULL
    */
    const INIFileLine *Find(const std::string & key) const;

    /** @name Get parameters from file */
    /*@{*/

    /** extract a generic parameter from file
    * @return a string_proxy object capable of cast to string and any value (that admit operator >>)
    * @note se il parametro non c'e' lancia una eccezione
    * @note non e' cosi' comodo per castarlo a stringa al momento!
    * \code
    * //...
    *  valore = ini.Value("CHIAVE");
    * // ...
    *  XMIN = ini->Value("XMIN");
    *  LeftLUTFileName = ini->Value("LEFTLUT").operator std::string(); // ugly!!!!
    * \endcode
    **/
    string_proxy Value(const std::string & key) const;

    /** forza il cast della chiave a un determinato valore
     * @note se il parametro non c'e' lancia una eccezione
     * \code
     * int i = Value<int>("KEY");
     * \endcode
     **/
    template<class T>
    T Value(const std::string & key) const;

    /** cerca una particolare chiave all'interno del file e se non la trova ritorna il default
    * @note se il parametro non c'e' ritorna il default
    * \code
    * XMIN = ini->Value("XMIN",1.0);
    * offs= ini->Value("OFFSET",10u);
    * \endcode
    **/
    template<class T>
    T Value(const std::string & key, const T & __default) const;

#ifdef _INIFILE3
    /** Preliminary **/
    ini_item_proxy operator [] (const std::string & key);
    // manca la versione const
#endif

////
    /// extract a generic parameter from file (compatibility mode)
    template<class T>
    bool Get(const std::string & key, T *param) const;

    /// extract a generic parameter from file (compatibility mode)
    ///  if the @a key does not exist, @a __default will be used
    /// @return true if key exist
    template<class T>
    void Get(const std::string & key, T *param, T __default) const;

    /// extract parameter @a key from file.
    /// if not exist false is returnet and param is untouched.
    /// @return true if key exist
    template<class T>
    inline bool Get(const std::string & key, T & param) const
    {
        return Get(key, &param);
    }

    /// versione con &. Vedere la versione *
    template<class T>
    void Get(const std::string & key, T & param, const T & __default) const
    {
        return Get(key, &param, __default);
    }

    /// Versione per il default in const char
    /// @note non e' possibibile usare la versione a template, infatti da come errore, per esempio:
    ///       error: no matching function for call to 'INIFile::Get(const char [23], std::string&, const char [13])'
    void Get(const std::string & key, std::string & param, const std::string & __default) const
    {
        Get<std::string>(key, &param, __default);
    }

    /** esegue il confronto tra la stringa del valore di key con gli elementi della lista di stringhe in list
     *   ritorna l'indice positivo della stringa altrimenti ritorna -1
     * @param key chiave
     * @param list un array di puntatori a stringhe, terminata con NULL. Guarda l'esempio.
     * @return l'indice positivo all'interno dell'array, altrimenti -1 se non lo trova
     *
     * \code
     * const char *example[]={"PIPPO","PLUTO",PAPERINO",NULL};
     * //...
     * index = Ini->GetFromList("CHAR", example);
     * \endcode
     **/
    int GetFromList(const std::string & key, const char **list) const;
    /*@}*/

    /** @name Set (or add) parameters to file
     * \code
     * ini->Set("CHIAVE", m_value);
     * \endcode
     */
    /*@{*/
    /// assegna alla chiave @a key il valore di @a object
    template<class T>
    void Set(const std::string &key, const T & object)
    {
        set( key, string_cast<T>(object) );
    }
    /*@}*/

    /** Cerca la prima occorrezza dell'espressione puntata da 'key' e inizializza le strutture per le ricerche successive
     *
     * \code
     * INIFile *ini;
     * // esempio di ciclo for
     * for(INIFile::iterator i = ini->Search("GridX?"); i; ++i)
     *  {
     *  // ... do something ...
     *  }
     * \endcode
     *
     *  @param filter una stringa che puo' contenere WildCard
     *  @note se filter e' vuoto restituisce l'intero FILE in ordine
     **/
    iterator Search(const std::string & filter) {
        return iterator(this, filter);
    }

    const_iterator Search(const std::string & filter) const     {
        return const_iterator(this, filter);
    }

    /** Esegue una richiesta di un particolare pattern
     *  E' una versione con una interfaccia standard rispetto a FindFirst,FindNext
     **/
    bool EnumAttribute(std::vector<INIFileLine *> & result, const std::string & filter);

    /** Esegue una richiesta di un particolare pattern, tra i figli o le sotto sezioni
     ***/
    bool EnumChild(std::vector<INIFile *> & result, const std::string & filter);

};

/// typedef per essere leggermente retrocompatibile
typedef INIFile::iterator INIFileLineSearch;

/// @brief Apply a function to every element of a sequence
/// @param filter a wildcard base filter
/// @param f      A unary function object that accept a INIFileLine * object
/// \code
/// ini.for_each("*", print_section);
/// \endcode
template<typename _Function>
void for_each(INIFile & ini, const std::string & filter, _Function __f)
{
    for (INIFile::iterator i = ini.Search(filter);(i); ++i) __f(i);
}


// Non-inline to reduce compile time overhead...
// #include <stdio.h>

template<class T>
inline T INIFile::Value(const std::string & key, const T & __default) const
{
    std::string value;
    if (!efind(key, value))
    {
        set( key, string_cast<T>(__default) );
        return __default;
    }
    else
    {
        return numeric_cast<T>(value);
    }
}

template<class T>
inline T INIFile::Value(const std::string & key) const
{
    std::string value;
    if (!efind(key, value))
        throw std::runtime_error( "`" +key + "' not found in " + m_filename);

    return numeric_cast<T>(value);
}

template<class T>
bool INIFile::Get(const std::string & key, T *param) const
{
    std::string value;
    if (efind(key, value))
    {
        *param = numeric_cast<T>(value);
        return true;
    }
    else
    {
        print_knf(key);
        return false;
    }
}

template<class T>
void INIFile::Get(const std::string & key, T *param, T __default) const
{
// cerca la chiave (anche in sottosezioni)
    std::string value;
    if (efind(key, value))
    {
        *param = numeric_cast<T>( value);
//     return true;
    }
    else
    {
        // non trova la chiave (tuttavia non scrive nulla)
        // print_knf_default(key);
        set( key, string_cast<T>(__default) );
        *param = __default;
//      return false;
    }
}

// Template Specialization write true or false according to value
/// Per debug purpose
inline std::ostream& operator<<(std::ostream & o, const INIFile & p)
{
    p.print_contain(o,true);
    return o;
}
    
  } // namespace ini

} // namespace vl

using namespace vl::ini; // this is to make more confortable the transition to namespaces

#endif
