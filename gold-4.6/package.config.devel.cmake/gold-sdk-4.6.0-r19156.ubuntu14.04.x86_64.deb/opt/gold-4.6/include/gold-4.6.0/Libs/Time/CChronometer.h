/** \file CChronometer.h
 *  \brief Chronometer for profiling and time measurements and profiling
 *  \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 **/

#ifndef _CCHRONOMETER_H
#define _CCHRONOMETER_H

#include <Libs/Time/TimeUtils.h>
#include <Libs/Time/Accumulator.h>

#include <boost/thread/mutex.hpp>

#include <Libs/Time/gold_time_export.h>

namespace vl
{
namespace chrono
{
  /**
    * \brief Class for measuring time intervals multiple times and collecting statistics
    * Both the system clock and the tread clock (on the platform where available) 
    * can be used.
    * \code
    *  Esempio di utilizzo:
    *  CChronometer chrono;
    *  ...
    *  chrono.Start();
    *  // ... code to be profiled
    *  chrono.Stop();
    *  std::cout << chrono() << std::endl;
    *  \endcode
    */
  class GOLD_TIME_EXPORT CChronometer
  {
    public:
      
      /**
       * \brief Type for the accumulator used
       */
      typedef Accumulator AccumulatorType;


      /**
       * \brief Clock type to be used for time measurement
       */      
      typedef enum
      {
        REAL_TIME_CLOCK, ///< measure the absolute time
        THREAD_TIME      ///< measure just the time spent in the current thread
      } ClockType;

      /**
       * \brief Default Constructor
       * \param clock_id specify the clock type to be used.
       */
      CChronometer(ClockType clock_id=THREAD_TIME);
      
      /**
       * \brief Costructor for specifying a name for the object and a clock type
       * \param name a string containing a name for identifying the object
       * \param clock_id specify the clock type to be used.
       */
      CChronometer(const std::string& name, ClockType clock_id=THREAD_TIME);
      
      /**
       * \brief Rename the object
       * \param name string containing the new name of the object
       */
      void Rename(const std::string& name);


      // Object control Methods

      /**
       * \brief Starts the chronometer.
       * The new active interval starts when this method is called
       */
      void Start();
      
      /**
       * \brief Stops  the chronometer (begins measuring a new sample)
       */
      void Stop();
      
      /**
       * \brief Pause  the chronometer (still measuring same sample)
       */
      void Pause();
      
      /**
       * \brief Stops and reset the chronometer
       */
      void Clear();
      
      /**
       * \brief Short method for Clear + Start
       */
      void ClearAndStart();
      
      /**
       * \brief Cast to TimeType for converting automatically
       * a Chronometer into a TimeType
       */
      operator TimeType () const { return Sum_A(); }

      // Accessors
      
      /**
       * \brief return the name of the current object
       * \return reference to a string containing the name of the current object
       */
      const std::string& Name() const { return m_name; }
      
      /**
       * \brief return the clock identifier for the current object
       * \return the clock identifier for the current object
       */
      ClockType ClockID() const { return m_clock_id; }      
      
      /**
       * \brief return the lifetime of the object (time from first start)
       * \return the lifetime of the object (time from first start)
       */
      const TimeType& LifeTime() const;
      

      /**
       * \brief return the origin of the object (absolute time of the first start)
       * \return the origin of the object (absolute time of the first start)
       */
      const AbsoluteTimeType& Origin() const { return m_origin; }

      /** 
       * \brief return the Duration of the last completed Active segment
       * \return Duration of the last completed Active segment
       */
      const TimeType& Last() const { return m_lcas; }

      // Time retrival functions
      
      /** 
       * \brief return Total duration of Active time
       * \return Total duration of Active time
       */
      const TimeType& SumActive() const { return Sum_A(); }
      
      /** 
       * \brief Total duration of Idle
       * \return Total duration of Idle
       */
      const TimeType& SumIdle()   const { return Sum_I(); }
      
      /**
       * \brief Accumulator with the statistics of the active time
       * \return Accumulator with the statistics of the active time
       */
      const AccumulatorType& Accumulator_A() const { return m_acc_a; }
      
      /** 
       * \brief Accumulator with the statistics of the idle time
       * \return Accumulator with the statistics of the idle time
       */
      const AccumulatorType& Accumulator_I() const { return m_acc_i; }
      
      /** 
       * \brief Number of calls to the Start Method
       * \return Number of Start
       */
      std::size_t StartCounter() const;
      
      /** 
       * \brief Number of calls to the Stop Method
       * \return Number of Stop
       */
      std::size_t StopCounter()  const;
      
      /** 
       * \brief Number of measurements taken
       * \return Number of measurements (segments counter)
       */
      std::size_t Counter() const;

      // statistics
      
      /**
       * \brief  Duration of the minimum Start-Stop interval (active)
       * \return Duration of the minimum Start-Stop interval (active)
       */      
      const TimeType& Min() const;
      
      /** 
       * \brief Duration of the maximum Start-Stop interval (active)
       * \return Duration of the maximum Start-Stop interval (active)
       */      
      const TimeType& Max() const;
      
      /** 
       * \brief  Average duration of a Start-Stop interval (active)
       * \return Average duration of a Start-Stop interval (active)
       */      
      const TimeType& Avg() const;
      
      /** 
       * \brief  Variance for the duration of Start-Stop intervals (active)
       * \return Variance for the duration of Start-Stop intervals (active)
       */      
      double Var() const;
      
      // deprecated API

      /**
       * \brief Operator for printing the chronometer value on a stream
       */
      GOLD_TIME_EXPORT friend std::ostream& operator << (std::ostream& ostr, const CChronometer& chrono);
      
    protected:

      /** 
       * \return Update and returns the Total Active Time (RTC)
       */            
      const TimeType& Sum_A() const;
      
      /** 
       * \return Update and returns the Total Idle Time (RTC)
       */            
      const TimeType& Sum_I() const;

    private:
      
      /** 
       * \enum for the current status
       */         
      typedef enum {ACTIVE, STOPPED} STATUS;
            
      /** 
       * Notification to the observers
       */               
      void NotifyObservers();
      
      /** 
       * Common part for all constructor
       * NOTE to be removed when using C++11
       */               
      void _delegate_constructor();
      
      /**
       * Return the lenght of the current segment using the selected clock
       */
      const TimeType& (CChronometer::*Curr)() const; 

        /**
         * Update cache for current segment
         */
      const TimeType& Curr_RTC() const;
      
      /**
       * Update cache for current segment
       */
      const TimeType& Curr_THR() const;

      std::string  m_name;  ///< Chronometer name

      ClockType  m_clock_id; ///< Clock ID type: RealTimeClock or ThreadClock

      mutable TimeType        m_transactions[2]; ///< transaction matrix
      
      STATUS                   m_status;     ///< true=Started, false=Stopped (NOTE anche m_StartCounter>m_StopCounter)

      AbsoluteTimeType         m_origin;     ///< The time origin: system date_time of the first start
      
      AccumulatorType          m_acc_a;      ///<< accumulator for active mode
      AccumulatorType          m_acc_i;      ///<< accumulator for idle mode

      TimeType                 m_lcas;       ///< Last Completed Active Segment
      TimeType                 m_lcis;       ///< Last Completed Idle Segment

      mutable AbsoluteTimeType m_rtc_begin;  ///< Beginning of the last segment (Real Time Clock)
      mutable TimeType         m_thr_begin;  ///< Beginning of the last segment (Thread Time)

      mutable TimeType         m_min, m_max; ///< Segment lenght min/max 
      mutable TimeType         m_avg;        ///< Segment average value (RealTime Clock)
      mutable double           m_var;        ///< Segments Variance (RealTime Clock)

      mutable TimeType         m_sum_a;      ///< cache for the Cumulative Active time
      mutable TimeType         m_sum_i;      ///< cache for the Cumulative Idle time
      mutable TimeType         m_curr;       ///< cache for the duration of current segment

      mutable TimeType         m_life_time;  ///< cache for Lifetime from the Clock creation

      mutable AbsoluteTimeType m_rtc_now;    ///< cache for the current Real Time Clock
      mutable TimeType         m_thr_now;    ///< cache for the current Thread Time

      static TimeType          m_zero;       ///< Initialized for 0
  };


  //
  // NOTE: questa potrebbe andare anche in /Devices/Base

  /**
   * The thread safe version of a chronometer.
   * This class has an interface similar to chronometer but every
   * method is protected interally with a mutex
   */
  class GOLD_TIME_EXPORT CTSChronometer :
    protected CChronometer
  {
    mutable boost::mutex m_mutex;

    public:
    /**
     * \brief Default constructor
     */
      CTSChronometer();

      /**
       * \brief Constructor taking the clock type
       */
      CTSChronometer(CChronometer::ClockType ct);

      /**
       * \brief Constructor taking the clock type and a name
       * @param [in] name name to be used internally by the clock
       * @param [in] ct clock type to be used for measurements
       */
      CTSChronometer(const std::string& name, CChronometer::ClockType ct=THREAD_TIME);

      /**
       * \brief Destructor
       */
      ~CTSChronometer();

      /**
       * \brief Starts the chronometer. The new active interval starts when this method is called
       */
      void Start();

      /**
       * \brief Stops the chronometer (begins measuring a new sample)
       */
      void Stop();

      // Object control Methods

      /**
       * \brief Stops and reset the Timer
       */
      void Clear();

      /**
       * \brief Short method for Clear + Start
       */
      void ClearAndStart();

      // Accessors

      /**
       * \brief Access to the chronometer name
       */
      const std::string& Name() const { return CChronometer::Name(); }

      /**
       * \brief Returns the lifetime: time passed from the obejct creation
       * \return the chronometer lifetime
       */
      TimeType LifeTime() const;

	/**
	 * \brief Returns the origin: time of the object creation
	 */
      const AbsoluteTimeType& Origin() const { return CChronometer::Origin(); }

      /**
       * \brief Time of the last completed Active segment
       */
      TimeType Last() const;

      /**
       * \brief Returns the total time time spent in active mode up to now
       */
      TimeType SumActive() const;

      /**
       * \brief Returns the total time spent in idle mode up to now
       */
      TimeType SumIdle()   const;

      /**
       * \brief Operator for converting automatically a chronometer into a TimeType
       * \return SumActive()
       *
       * \see SumActive
       */
      operator TimeType () const;

      /*
       * \brief Returns the number of times the chronometer has been started
       */
      std::size_t StartCounter() const { return CChronometer::StartCounter(); }

      /*
       * \brief Returns the number of times the chronometer has been stopped
       */
      std::size_t StopCounter()  const { return CChronometer::StopCounter(); }

      /*
       * \brief Returns the number of times the chronometer has been stopped
       * \see StopCounter
       */
      std::size_t Counter()  const { return CChronometer::StopCounter(); }

      // statistics

      /**
       * \brief Returns the lenght of the minimum Start-Stop interval
       */
      TimeType Min() const { return CChronometer::Min(); }

      /**
       * \brief Returns the lenght of the maximum Start-Stop interval
       */
      TimeType Max() const { return CChronometer::Max(); }

      /**
       * \brief Returns the average of the Start-Stop intervals
       */
      TimeType Avg() const { return CChronometer::Avg(); }

      /**
       * \brief Returns the variance of the Start-Stop intervals
       */
      double Var()   const { return CChronometer::Var(); }

      /**
       * \brief Operator for printing a chronometer on a stream
       */
      GOLD_TIME_EXPORT friend std::ostream& operator << (std::ostream& ostr, const CTSChronometer& chrono);
  };
  
} // namespace chrono
} // namesopace vl

#endif
