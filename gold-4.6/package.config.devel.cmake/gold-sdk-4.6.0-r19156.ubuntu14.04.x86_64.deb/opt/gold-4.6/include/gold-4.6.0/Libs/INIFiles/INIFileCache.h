/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2007                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/
/** @file INIFileCache.h
 *  @brief Cache di INIFile
 *  @author Paolo Medici
 **/
#ifndef _INIFILECACHE_H
#define _INIFILECACHE_H

#include <map>
#include <boost/thread/mutex.hpp>

#include <Libs/INIFiles/INIFile.h>

#ifdef _MSC_VER  // boost::mutex non viene esportata
  #pragma once
  #pragma warning(push)
  #pragma warning(disable: 4275)  // Disable warning C4275: non dll-interface class
#endif 
namespace vl
{
  namespace ini
  {
/** INIFileCache raccoglie tutti i file aperti in GOLD che soddisfano il formato dei file di inizializzazione
 * 
 *  In generale gli INIFile raccolti da questo manager possono essere anche file DSC o qualunque file nel
 *   formato standard.
 *  Siccome questo oggetto dovrebbe essere unico in GOLD, provvedere in qualche maniera alla sua instanziazione
 *
 * @note users should not call directly this class. 
 *  Tuttavia in progetti esterni a GOLD per poter accedere ai file INI allocare un oggetto CINIFileCache
 **/
class GOLD_INIFILES_EXPORT CINIFileCache: public boost::mutex {
    typedef std::map<std::string,INIFile* > cache_t;
    typedef std::map<std::string,std::string> string_map_t;

    /// Mappa tra nome assoluto dei file e oggetto ::INIFile
    cache_t cache;

    /// Variabili comuni a tutti i file di inizializzazione
    string_map_t common_vars;

    public:
    CINIFileCache();
    ~CINIFileCache();

    /// Set an Environment variabile, common to any INI files
    void SetEnv(const std::string& key, const std::string& value);
    /// Get an Environment variabile
    std::string GetEnv(const std::string& key) const;
    
    bool GetEnv(const std::string& key, std::string& out) const;

    /** cerca il file di inizializzazione nella cache
     * 
     * Se il file non esiste nella cache, questo viene aggiunto.
     * @param filename percorso assoluto del file da caricare nella cache
     * @return una struttura ::INIFile. Se il file non esiste viene comunque ritornato un oggetto vuoto
     **/
    INIFile*  OpenFile(const std::string&filename);
    
    /** Cerca all'interno di un file della cache l'occorrenza di una particolare chiave.
     * @param Filename percorso assoluto (bisogna usare ExpandPath) di un file nella cache
     * @param key una stringa da cercare come chiave
     * @return una struttura ::INIFileLine se la chiave esiste, altrimenti NULL
     */
    const INIFileLine* SearchKey(const std::string& Filename, const char* key)
      {
      INIFile* ini = OpenFile(Filename);
      return (ini) ? (ini->Find(key)) : NULL;
      }

    /// Rimuove un file dalla cache. 
    /// TODO: usare un reference count tipo shared_ptr
    /// @return true se era in cache, false se non lo era.
    bool UnCache(const char* filename);
    
    /// toglie la flag di modifica a tutti i file in cache.
    void UnTouchAll(void);

    /// Debug
    friend std::ostream& operator<<(std::ostream & out, const CINIFileCache & mgr);

} ;   

   
  }
}

#ifdef _MSC_VER
 #pragma warning(pop)
#endif 

#endif
