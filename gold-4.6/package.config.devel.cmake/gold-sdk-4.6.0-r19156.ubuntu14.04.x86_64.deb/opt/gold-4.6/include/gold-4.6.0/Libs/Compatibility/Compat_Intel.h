/**************************************************************************
 *   Copyright (C) 2007 by Johannes Singler                                *
 *   singler@ira.uka.de                                                    *
 *   Distributed under the Boost Software License, Version 1.0.            *
 *   (See accompanying file LICENSE_1_0.txt or copy at                     *
 *   http://www.boost.org/LICENSE_1_0.txt)                                 *
 *   Part of the MCSTL   http://algo2.iti.uni-karlsruhe.de/singler/mcstl/  *
 ***************************************************************************/

/**
 * \file Compat_Intel.h
 * \brief Intel compiler compatibility work-around.
 */

#ifndef __COMPAT_INTEL
#define __COMPAT_INTEL

#ifdef __ICC
#ifndef __sync_fetch_and_add
/** \brief Replacement of unknown atomic function. Bug report submitted to Intel. */
#define __sync_fetch_and_add(ptr,addend) _InterlockedExchangeAdd(const_cast<void*>(reinterpret_cast<volatile void*>(ptr)), addend);
#endif
#ifndef __builtin_fpclassify
#define __builtin_fpclassify( a, b, c, d, e, f ) ::fpclassify( f )
#endif
#endif

#endif
