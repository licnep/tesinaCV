/** \file CTSQueue.hxx
 *  \brief Class implementing a synchronized queue (Thread Safe Queue)
 *  \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 **/

#ifndef _C_TSQUEUE_H
#define _C_TSQUEUE_H

#include <queue>
#include <boost/thread/mutex.hpp>
#include <boost/thread/condition.hpp>

// #define CTSQ_VERBOSE       false

namespace vl
{
namespace thread
{

/**
 * \brief Class implementing a synchronized FIFO queue (Thread Safe Queue)
 *
 * The queue size is only limited by the amount of memory available
 *
 */
template<class CElement> class CTSQueue
{
public:
	/**
	 * \brief Constructor: creates a TreadSafe Queue limited by the amount of memory
	 */
	CTSQueue();

	/**
	 * \brief Push a copy of element at the back of the queue
	 *
	 * This call is blocking when there is no more memory available
	 * \param element Reference the user space element to be copied and pushed in the queue
	 */
	void Push(const CElement& element);

	/**
	 * \brief Copies the front of the queue in element and remove it from the queue
	 *
	 * This call is blocking while there are no element in queue,
	 * that is when if the queue is empty, the thread is suspended
	 * calling boost::thread::interrupt() will end the wait
	 * but in that case this function will exit with an exception that need to be catched
	 * \param [out] element user space object that will be overwritten
	 * with the one extracted from the queue
	 */
	void Pop(CElement& element);

	/**
	 * \brief Returns true when the queue is empty
	 *
	 * \return true when the queue is empty, false otherwise
	 * Warning: this function does not necessarily reflects the current object status
	 * Another thread may have changed the status after the calling
	 * In order to achieve that external synchronization is needed
	 */
	bool IsEmpty();

	/**
	 * \return the number of elements in the queue
	 * WARNING: this function does not necessarily reflects the current object status
	 * Another thread may have changed the status after the calling
	 * In order to achieve that external synchronization is needed*
	 */
	uint64_t Size();

	// void ShutDown();

private:
	boost::mutex m_mutex;        ///< mutex for exclusive access
	boost::condition m_cnd_empty;///< condition variable for waiting when the queue is empty
	boost::condition m_cnd_full; ///< condition variable for waiting when the queue is full
	bool is_full;

	std::queue<CElement> m_queue; ///< The STL Queue used for objects storage
};

template<class CElement>
vl::thread::CTSQueue<CElement>::CTSQueue() :
		is_full(false) // ,
// m_verbose ( CTSQ_VERBOSE )
{
}

template<class CElement>
void vl::thread::CTSQueue<CElement>::Push(const CElement& element)
{
	boost::mutex::scoped_lock lock(m_mutex);

	// if ( CTSQ_VERBOSE )
	//     std::cout << "Push " << m_queue.size() << std::endl;
	do
	{
		// push a new element in the queue
		try
		{
			m_queue.push(element);
			m_cnd_empty.notify_all();
		}
		// when a std::bad_alloc exception is thrown
		// the thread is suspended
		catch (const std::bad_alloc&)
		{
			is_full = true;
			m_cnd_full.wait(lock);
		}
	} while (is_full);
}

template<class CElement>
void vl::thread::CTSQueue<CElement>::Pop(CElement& element)
{
	boost::mutex::scoped_lock lock(m_mutex);

	// if ( CTSQ_VERBOSE )
	//     std::cout << "Pop ";

	while (m_queue.size() == 0)
		m_cnd_empty.wait(lock);

	// copy the element from the queue to the user space
	element = m_queue.front();

	// remove the element from the queue
	m_queue.pop();

	// signals all threads waiting for space
	if (is_full)
	{
		is_full = false;
		m_cnd_full.notify_all();
	}
}

template<class CElement>
bool vl::thread::CTSQueue<CElement>::IsEmpty()
{
	boost::mutex::scoped_lock lock(m_mutex);
	return m_queue.empty();
}

template<class CElement>
uint64_t vl::thread::CTSQueue<CElement>::Size()
{
	boost::mutex::scoped_lock lock(m_mutex);
	return m_queue.size();
}


} // namespace vl
} // namespace thread

#endif

