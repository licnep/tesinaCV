
#ifndef GOLD_LOGGER_EXPORT_H
#define GOLD_LOGGER_EXPORT_H

#ifdef GOLD_LOGGER_STATIC_DEFINE
#  define GOLD_LOGGER_EXPORT
#  define GOLD_LOGGER_NO_EXPORT
#else
#  ifndef GOLD_LOGGER_EXPORT
#    ifdef gold_logger_EXPORTS
        /* We are building this library */
#      define GOLD_LOGGER_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define GOLD_LOGGER_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef GOLD_LOGGER_NO_EXPORT
#    define GOLD_LOGGER_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef GOLD_LOGGER_DEPRECATED
#  define GOLD_LOGGER_DEPRECATED __attribute__ ((__deprecated__))
#  define GOLD_LOGGER_DEPRECATED_EXPORT GOLD_LOGGER_EXPORT __attribute__ ((__deprecated__))
#  define GOLD_LOGGER_DEPRECATED_NO_EXPORT GOLD_LOGGER_NO_EXPORT __attribute__ ((__deprecated__))
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define GOLD_LOGGER_NO_DEPRECATED
#endif

#endif
