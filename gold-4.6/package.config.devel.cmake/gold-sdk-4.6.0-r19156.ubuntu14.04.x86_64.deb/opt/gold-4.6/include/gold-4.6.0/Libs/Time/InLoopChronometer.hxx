#include <Libs/Time/CChronometer.h>

/**
 * \file InLoopChronometer.hxx
 * \brief Simple chronometer for measuring the cumulative time spent inside a processing loop
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 **/


namespace vl
{
namespace chrono
{
/**
 * \brief InLoopChronometer is a template specialized class to perform in-loop benchmarks
 * 
 * Sometimes when performing benchmarks it is interesting to measure the cumulative time 
 * spent inside a part of a loop excluding other parts or the overhead of the loop itself.
 * This class allows to perform such measurements.
 * The template parameter specifies the type of clock to be used for the measurement
 * It can be: 
 *   vl::chrono::CChronometer::REAL_TIME_CLOCK measure the overall clock time spent, even 
 *   executing other threads, between start and stop.
 *   or vl::chrono::CChronometer::THREAD_TIME measure the time spent executing the current 
 *   thread between start and stop
 * Here is a usage example:
 * \code
 * vl::chrono::InLoopChronometer< vl::chrono::CChronometer::REAL_TIME_CLOCK > chrono;
 * for(unsigned int i=0; i<100; ++i)
 * {
 *   chrono.Start();
 *   // we want to measure the cumulative time spent doing some processin here ... 
 *   boost::this_thread::sleep(boost::posix_time::milliseconds(100));
 *   chrono.Stop();
 *   // ... excluding from the measure this part of the loop
 *   boost::this_thread::sleep(boost::posix_time::milliseconds(100));
 * }
 * 
 * chrono.Reset();
 * 
 * std::cout << boost::accumulators::count(chrono.Accumulator()) << std::endl;
 * std::cout << boost::posix_time::microseconds(boost::accumulators::mean(chrono.Accumulator())) << std::endl;
 * \endcode
 *
 */  
template<vl::chrono::CChronometer::ClockType T>
class InLoopChronometer
{
public:
	/**
	 * \brief Type for the internal accumulator
	 */
    typedef vl::chrono::Accumulator<unsigned long> AccumulatorType;

    /**
     * \brief Start the measurment
     */
    void Start();
    
    /**
     * \brief Stop the measurment and increase the cumulative value
     * by the amount of time between start and stop
     */
    void Stop();
    
    /**
     * \brief Accumulate statistics for the current cumulative value and
     * reset the object for another measurement
     */
    void Reset();
    
    /**
     * \brief Returns a const reference to the internal accumulator
     * \return const reference to the internal accumulator
     */
    const vl::chrono::Accumulator& Accumulator();    
private:
};

/**
 * \brief Specialization of InLoopChronometer using real time clock
 */
template<>
class InLoopChronometer<vl::chrono::CChronometer::REAL_TIME_CLOCK>
{
public:

    /**
     * \brief start implementation using the thread time
     *
     */
    void Start()
    {
      GetClock ( m_start );
    }
    
    /**
     * \brief stop implementation using the thread time
     */
    void Stop()
    {
      GetClock ( m_stop );
      m_cum+=m_stop-m_start;
    }
    
    /**
     * \brief reset implementation
     */
    void Reset()
    {
      // passa la somma all'accumulatore       
      m_acc(m_cum.total_microseconds());
      m_cum=TimeZero();
    }   
    
    /**
     * \brief Returns a const reference to the internal accumulator
     */
    const vl::chrono::Accumulator& Accumulator() const { return m_acc; }

private:
    vl::chrono::Accumulator m_acc;             ///< Internal accumulator
    mutable AbsoluteTimeType   m_start;    ///< Beginning of the current segment
    mutable AbsoluteTimeType   m_stop;     ///< End of the current segment    
    mutable TimeType           m_cum;      ///< Cumulative value
};


/*
 * \brief Specialization of InLoopChronometer for Thread Time
 */
template<>
class InLoopChronometer<vl::chrono::CChronometer::THREAD_TIME>
{
public:
    /**
     * \brief start implementation using the thread time
     */
    void Start()
    {
      GetThreadTime ( m_start );
    }
    
    /**
     * \brief stop implementation using the thread time
     */
    void Stop()
    {
      GetThreadTime ( m_stop );
      m_cum+=m_stop-m_start;
    }
    
    /**
     * \brief reset implementation
     */
    void Reset()
    {
      // passa la somma all'accumulatore       
      m_acc(m_cum.total_microseconds());
      m_cum=TimeZero();      
    }   

    /**
     * \brief Returns a const reference to the internal accumulator
     */
    const vl::chrono::Accumulator& Accumulator() const { return m_acc; }

private:
    vl::chrono::Accumulator m_acc;     ///< Internal accumulator
    mutable TimeType   m_start;    ///< Beginning of the current segment
    mutable TimeType   m_stop;     ///< End of the current segment    
    mutable TimeType   m_cum;      ///< Cumulative value
};

} // namespace chrono
} // namesopace vl
