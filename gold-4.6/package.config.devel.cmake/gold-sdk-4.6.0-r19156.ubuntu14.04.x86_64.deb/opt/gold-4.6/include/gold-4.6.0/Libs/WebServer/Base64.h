/**
 * \file Base64.h
 * \brief Conversion from string to Base64 format
 */

#ifndef _BASE64_H
#define _BASE64_H

#include <string>

/**
 * \brief Converts a string in the corresponding Base64 version
 * \param str the string to be converted, may be a binary string.
 * \return the conversion of str in the corresponding Base64 value
 */
std::string StrToBase64(const std::string& str);

#endif
