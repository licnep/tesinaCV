#ifndef PLATFORM_H
#define PLATFORM_H

/* endiannes */
#define PLATFORM_LITTLE_ENDIAN
/* #undef PLATFORM_BIG_ENDIAN */

// TODO: this is deprecated. Remove after elimination from Disparity.
// use boost::thread::hardware_concurrency() insted
#define PLATFORM_CPU_CORES  8
 
#define PLATFORM_CPU_NAME "Intel(R) Core(TM) i7-4700MQ CPU @ 2.40GHz"
#define PLATFORM_OS "Linux-3.13.0-35-generic"

/* platform */
#if (defined(__GNUC__) && defined(__x86__)) || (defined(_MSC_VER) && defined(_M_IX86)) 
    #define PLATFORM_X86
    #define PLATFORM_ARCH "x86"
#elif (defined(__GNUC__) && defined(__x86_64__)) || (defined(_MSC_VER) && defined( _M_X64)) 
    #define PLATFORM_X86_64
    #define PLATFORM_ARCH "x86_64"
#elif defined(__GNUC__) && defined(__arm__)
    #define PLATFORM_ARM
    #define PLATFORM_ARCH "arm"
#else
    #define PLATFORM_ARCH ""
#endif


/* instruction set */
# if defined(__GNUC__)
  #ifdef __MMX__
    #define PLATFORM_MMX
  #endif

  #ifdef __SSE__
    #define PLATFORM_SSE
  #endif

  #ifdef __SSE2__
    #define PLATFORM_SSE
  #endif

  #ifdef __SSE3__
    #define PLATFORM_SSE3
  #endif

  #ifdef __SSSE3__
    #define PLATFORM_SSSE3
  #endif

  #ifdef __SSE4__
    #define PLATFORM_SSE4
  #endif

  #ifdef __SSE4_1__
    #define PLATFORM_SSE4_1
  #endif

  #ifdef __SSE4_2__
    #define PLATFORM_SSE4_2
  #endif

  #ifdef __AVX__
    #define PLATFORM_AVX
  #endif

# elif defined(_MSC_VER) && (_MSC_VER >= 1200) && !defined(MIDL_PASS)
// TODO
# else
// TODO
# endif

/* Support for C++11 */
/* #undef __CPP_11__ */

/* gcc version */
#ifdef __GNUC__
#define GCC_VERSION (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__)
#endif

#endif  // PLATFORM_H
