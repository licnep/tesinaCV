#ifndef _PANEL_H
#define _PANEL_H

/** @file Panel.h
  * @brief Convenience header
  **/

#include <UI/Panel/Widgets.h>
#include <UI/Panel/Vars.h>
#include <UI/Panel/Conf.h>

#endif