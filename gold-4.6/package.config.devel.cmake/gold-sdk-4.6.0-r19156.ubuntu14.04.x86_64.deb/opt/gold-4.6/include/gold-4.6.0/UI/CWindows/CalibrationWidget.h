#ifndef _CW_CALIBRATION_WIDGET_H
#define _CW_CALIBRATION_WIDGET_H

/** @file CalibrationWidget.h
  * @brief Widget di aiuto per calibrare
  * @author Paolo Medici
  **/

#include <vector>

#include <UI/CWindows/CWindowTypes.h>
#include <UI/CWindows/CWidget.h>
#include <Data/Math/Points.h>
#include <UI/CWindows/CWindowFwd.h> // Forward Declaration

namespace ui {
namespace win {


/** Un widget che permette di muovere dei puntini a volonta' dell'utente */
template<class T>
class GOLD_UI_EXPORT CalibrationWidget : public CWidget
{
    std::vector< math::Point2<T> > m_points; ///< i punti
    int m_style; ///< Stile di disegno
    float m_size; ///< size dei punti
    math::Point2<T> * m_active;
    public:
    
    static const T Undefined; 
    
        CalibrationWidget();
        CalibrationWidget(const std::vector< math::Point2<T> > & initial_point);
        
        ~CalibrationWidget();

	// TODO: aggiungere una callback chiamata allo spostamento dei punti
	//  o almeno una flag per indicare che i punti sono stati cambiati
        
        /// Imposta la dimensione del puntino
        inline void setSize(float size) { m_size = size; }
        /// Imposta lo stile di rendering
        inline void setStyle(int style) { m_style = style; }  
        /// Accede al vettore per aggiungere, leggere, modificare i punti
        inline std::vector< math::Point2<T> > & Points() { return m_points; }
              
        /* used internally */
        const char* getName() const;
        bool Interact(CWindowCoreManager* pWindow, const CWindowEvent& event);
        int Draw(CWindowCore* pWindow);
};

} // namespace win
} // namespace ui

#endif
