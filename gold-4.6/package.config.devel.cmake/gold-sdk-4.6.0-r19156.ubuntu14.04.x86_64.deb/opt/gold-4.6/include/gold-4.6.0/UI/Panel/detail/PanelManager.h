#ifndef _PANEL_MANAGER_H
#define _PANEL_MANAGER_H

/** @file PanelManager.h
  * @brief PanelManager, classe necessarie per raccogliere i pannelli all'interno del sistema
  **/


#include <Libs/Patterns/Singleton.h>

#include <UI/Panel/detail/PanelTypes.h>
#include <UI/Panel/detail/WidgetCore.h>
#include <UI/gold_ui_export.h>

#include <boost/thread/mutex.hpp>

#ifdef _MSC_VER  //boost::mutex non è esportata
  #pragma once
  #pragma warning(push)
  #pragma warning(disable: 4275)  // Disable warning C4275: non dll-interface class
#endif

// fw
namespace vl{ namespace ini {class INIFile;} } using vl::ini::INIFile;

namespace ui {

namespace detail {
    
class PanelListener;

/// Questo e' un singleton (o unica istanza nel sistema) che fa da tramite verso i server gui/listener
///  I ServerListener usano questo oggetto per avere un elenco dei pannelli usando un path relativo,
///   e ottenere un oggetto ModuleInterface con il quale registrarsi al pannello,
///   leggere e scrivere i dati.
///  Contemporaneamente i PanelInterface (i pannelli) si registrano a questa risorsa per indicare
///   al mondo la loro esistenza
/// 
/// TODO: decidere se il Lock, inserito per evitare che avvengano accessi simultanei alle risorse, debba
///       essere locked da chi lo usa, o dalle funzioni interne alla classe.
class GOLD_UI_EXPORT PanelManager: public boost::mutex {
    public:

    /// numero massimo di listener (in teoria su un 64 bit sarebbero il doppio)
    static const int max_listener = 32;

    /// elenco dei listener (numero massimo limitato dai bit)
    PanelListener * m_listener[max_listener];

    /// Elenco totale Item bindati
    widget_list_t m_widgets;
    
    /** database mutex */
    mutable boost::mutex m_mutex;
    
    /** current listener id (during syncronous Set) */
    int m_cur_listener;
    
    bool m_lock_to_current_listener;
    
    private:

    boost::mutex m_guid_mutex;
    widget_guid_t m_guid;
        
      /// avoid copy (cioe'.. puo' essere copiato senza problemi, ma penso non sia quello che si voglia
    ///             da una simile struttura)
    PanelManager(const PanelManager & s) { }

    /// Internal Update
    bool Update(widget_list_t::const_iterator i) const;

    bool NotifyDataChanged(widget_list_t::const_iterator i) const;

    /// Aumenta il reference count di un widget (e dei suoi figli)
    bool AddRef( WidgetCore & w, int inc_value = 1, int debug=0);

    /// Riduce il reference count di un widget
    /// @param guid,w guid e descrittore del parametro interno
    bool InternalRelease(widget_guid_t guid, WidgetCore & w, int debug=0);

    /** rilascia la memoria associata al @a guid
      *  chiamata in maniera iterativa da una Release (non puo' corrompere percio' la m_children list del parent)
      */
    bool InternalRelease(widget_guid_t guid, int debug=0);

    /** return true if @a k is listening widget @a s */
    inline bool InListen(int k, const WidgetCore & s) const
		{
		// TODO: correct s.listener if m_listener[k]==NULL
    		return ((m_listener[k])&&(s.listener & (1<<k)));
		}
		
    public:
    /// costruisce il manager
    PanelManager();
    /// rilascia il manager
    ~PanelManager();

    /// Crea un nuovo GUID, ma non lo registra nella mappa (questo deve essere fatto quando effettivamente serve).
    widget_guid_t CreateGUID(bool self_register=false);
    
    /** associa al guid, l'adapter @a x **/
    bool Bind(widget_guid_t uid, Serializable * x);
    /** associa all'guid lo storage su disco (key+INI) **/
    bool Bind(widget_guid_t uid, const std::string & url, INIFile *ini);
    /** associa all'guid lo storage su disco (key+INI) **/
    bool Bind(widget_guid_t uid, const std::string & url, INIFile *ini, const std::string & def);
    bool Bind(widget_guid_t uid, const std::string & url, INIFile *ini, const boost::any & def);

    /** Broadcast to listener new widget value **/
    bool Update(widget_guid_t uid) const;

    /** Broadcast to listener new widget data **/
    bool NotifyDataChanged(widget_guid_t uid) const;

    /** registra a un guid (e tutti i suoi figli) a un client **/
    bool Register(widget_guid_t uid, listener_id_t client_id);
    /** registra a un guid (e tutti i suoi figli) un client **/
    bool UnRegister(widget_guid_t uid, listener_id_t client_id);

    /** registra un nuovo listener e ritorna un client_id */
    listener_id_t Register(PanelListener *listener);
    /** deregistra un listener **/
    bool UnRegister(listener_id_t client_id);

    /** imposta il valore associato al guid
      * @param guid a GUID
      * @param value a Value
      **/
    bool Set(widget_guid_t guid, const std::string & value, AccessMode mode = ui::detail::InternalType);

    /** imposta il valore associato al guid
      * @param guid a GUID
      * @param value a Value
      **/
    bool Set(widget_guid_t guid, const boost::any & value, int EventId = 0, AccessMode mode = ui::detail::InternalType);

    /** imposta il valore associato al guid
      * @param guid a GUID
      * @param value an archive
      **/
    bool Set(widget_guid_t guid, boost::archive::polymorphic_iarchive & value, int EventId = 0, AccessMode mode = ui::detail::InternalType);
    
    /** imposta il valore associato al guid ma non esegue il broadcast a client_id
      * @param guid a GUID
      * @param value a Value
      * @param client_id a Client Id hidden to this communication
      * @note a Lazy Controller for default not sent to anyone 
      **/
    bool Set(widget_guid_t guid, const std::string & value, unsigned int client_id, int EventId = 0, AccessMode mode = ui::detail::InternalType);

    /** imposta il valore associato al guid
      * @param guid a GUID
      * @param value a Value
      * @param client_id a Client Id hidden to this communication
      **/
    bool Set(widget_guid_t guid, const boost::any & value, unsigned int client_id, int EventId = 0, AccessMode mode = ui::detail::InternalType);
    
   /** imposta il valore associato al guid ma non esegue il broadcast a client_id
      * @param guid a GUID
      * @param value a Value
      * @param client_id a Client Id hidden to this communication
      * @note a Lazy Controller for default not sent to anyone
      **/
    bool Set(widget_guid_t guid, boost::archive::polymorphic_iarchive & value, unsigned int client_id,  int EventId = 0, AccessMode mode = ui::detail::InternalType);
    
    /** ritorma il valore associato al guid **/
    bool Get(widget_guid_t guid, std::string & value) const; 

    /** ritorma il valore associato al guid **/
    bool Get(widget_guid_t guid, boost::archive::polymorphic_oarchive& value, AccessMode mode = ui::detail::InternalType) const;
    
    /** ritorma il valore associato al guid **/
    bool Get(widget_guid_t guid, boost::any & value, AccessMode mode = ui::detail::InternalType) const;
    
    /** Aumenta il Reference Count di un guid e dei figli **/
    bool AddRef(widget_guid_t guid, int inc_value = 1, int debug =0);

    /** Clona il widget, creando una copia esatto con guid diversi */
    widget_guid_t Clone(widget_guid_t guid, widget_guid_t parent);

    /** Decrease @a guid reference count without notify client
      * @param guid a GUID
      * @return true if guid is release
      */
    bool Release(widget_guid_t guid);

    /** rilascia la memoria associata al @a guid,
      *  decrementando il Reference Count, suo e dei figli.
      *  Notifica al client la rimozione quando il ref_count raggiunge lo 0
      *   ma non notifica le distruzioni dei figli ai client
      * @param guid a GUID
      * @return true if guid is release
      **/
    bool Detach(widget_guid_t guid);

    /** appende il widget child al parent **/
    bool Attach(widget_guid_t parent, widget_guid_t child);

    /** return the GUID of a parent **/
    widget_guid_t Parent(widget_guid_t guid) const;
    
    /// collega @a dst a @a src Alla distruzione di @a src viene rimosso il reference count a @a dst
    bool Link(widget_guid_t src, widget_guid_t dst);
    
    /// rimuove il collegamento tra @a dst e @a src
    bool UnLink(widget_guid_t src, widget_guid_t dst);

    /** Legge l'attributo @a attr dal @a guid
     * @note se il guid o l'attributo non esistono una std::runtime_error viene lanciata.
      **/
    const std::string & ReadAttr(widget_guid_t guid, const std::string & attr) const ;
    
    /** Testa se il guid e l'attributo esistono **/
    bool HasAttr(widget_guid_t guid, const std::string & attr) const ;

    /** Testa se il guid e l'attributo esistono e lo mette in @a value **/
    bool HasAttr(widget_guid_t guid, const std::string & attr, std::string &value) const ;
    
    /// Modifica piu attributi a un widget
    bool Attr(widget_guid_t guid, const std::vector<std::pair<std::string, std::string> > & attr);
    /// Modifica un singolo attributo a un widget
    bool Attr(widget_guid_t guid, const std::string & key, const std::string &value);

    /// Forza l'apertura o chiusura di un pannello lato Client, e lo mette o lo toglie dalla Visible List
    /// @param guid panel ID
    /// @param show status (Show or Hide)
    void Show(widget_guid_t guid, bool show);
    
    inline int GetCurrentClientID() const { return m_cur_listener; }
    
    void LockToCurListener();
    void UnLockToCurListener();
    
    /// Enumera i pannelli sotto determinate caratteristiche
    template<class T>
    void Find(std::vector<widget_guid_t> & res, T op) const
	{
	for(widget_list_t::const_iterator i = m_widgets.begin(); i!=m_widgets.end(); ++i)
                if(op(*i->second))
			res.push_back(i->first);
	}

/// ThreadSafe find
  widget_list_t::iterator tsfind(widget_guid_t guid)
    {	
	    boost::mutex::scoped_lock lock(m_mutex);
	    widget_list_t::iterator i = m_widgets.find(guid);
	    return i;
    }
/// ThreadSafe find (const)    
  widget_list_t::const_iterator tsfind(widget_guid_t guid) const
    {	
	    boost::mutex::scoped_lock lock(m_mutex);
	    widget_list_t::const_iterator i = m_widgets.find(guid);
	    return i;
    }

     /** ThreadSafe Find. cerca un guid, se non esiste viene lanciata una std::exception **/
     WidgetCore & Find(widget_guid_t guid);

    /** Non-ThreadSafe Find. Cerca il widget, ma se non esiste lancia una eccezione
     * */
    WidgetCore & UnsafeFind(widget_guid_t guid);
    
    /** Non-ThreadSafe Find. la funzione Widget accede direttamente al widget, lo crea se non esiste,
      *  ma non notifica ai listener alcuna modifica */
    WidgetCore & Widget(widget_guid_t guid);
    

    

    /** Test if guid exists
      * @param guid the GUID
      * @return true or false
      */
    bool IsValid(widget_guid_t guid) const {
		return m_widgets.find(guid) != m_widgets.end();
		}
    
    bool IsActive(widget_guid_t guid) const {
      return m_widgets.find(guid)->second->listener != 0;
    }

    /** Return the ref count of object
      */
    int RefCount(widget_guid_t guid) const;

    /// viene forzato il reloading di tutti i guid bindati con un file ini
    bool Reload(INIFile *ini);

    /// viene fatto il salvataggio di tutti i guid legati a un file ini
    bool Save(INIFile *ini) const;

    void Cleanup();

    /// debug
    friend GOLD_UI_EXPORT std::ostream & operator << (std::ostream&o, const PanelManager & p);
};

typedef vl::Singleton<PanelManager> PanelManagerSingleton;
}

GOLD_UI_EXPORT detail::PanelManager& PanelManagerInstance();

}

#ifdef _MSC_VER
 #pragma warning(pop)
#endif 

#endif
