/** @file AnnWidget.h
  * @brief Questo file contiene widget utili in `annotazione' 
  **/
#ifndef _ANNOTATION_WIDGET_H
#define _ANNOTATION_WIDGET_H

#include <boost/thread/mutex.hpp>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <boost/date_time/posix_time/posix_time_types.hpp>

#include <vector>
#include <set>

#include <Data/Math/Points.h>
#include <Data/Math/Rects.h>
#include <Data/Math/Lines.h>
#include <UI/CWindows/CWidget.h>
#include <UI/gold_ui_export.h>

namespace ui {
namespace win {

#ifdef DEPRECATED_ANNWIDGET

/** Ogni oggetto che viene annotato possiede le seguenti caratteristiche:
  * - un rettangolo di applicazione
  * - una mappa (rappresentata dal vettore) tra una caratteristica e il valore che essa assume
  **/
struct AnnotationBox {
    /// a rectangle
    Rect2f rect;
    /// a id to track the same object on multiple frames
    long guid;
    /// an id rapresenting the class of object
    int category;

    AnnotationBox() : guid(-1), category(-1) { }
};

// std::istream & operator >> (std::istream & in, AnnotationBox & s);
// std::ostream & operator << (std::ostream & out, const AnnotationBox & s);

typedef std::vector<AnnotationBox> AnnObjectsType;

/** Un Frame annotato e' un vettore di Box identificativi, identificativo del frame e del timestamp */
struct AnnotationFrame {
  int frame_number;
  boost::posix_time::time_duration timestamp;
  AnnObjectsType objects;

public:
  
  AnnotationBox *find_by_guid(long guid);
  const AnnotationBox *find_by_guid(long guid) const;
  
  inline bool empty() const { return objects.empty(); }
};

// std::istream & operator >> (std::istream & in, AnnotationFrame & s);
// std::ostream & operator << (std::ostream & out, const AnnotationFrame & s);

typedef std::map<int, AnnotationFrame> AnnotationSequence;

// per mappare gli ids nei dati serve un dizionario

/** Policy **/
class AnnotationPolicy {
	public:
	virtual ~AnnotationPolicy() { }
	virtual bool NewItem(AnnotationBox & box) = 0;
	virtual bool SwitchItem(AnnotationBox & box) = 0;
	virtual cimage::RGBA8 IdToColor(int id) = 0;
	cimage::RGBA8 IdToColor(const AnnotationBox & box) { return IdToColor(box.category); }
};

class GOLD_UI_EXPORT DefaultAnnotationPolicy : public AnnotationPolicy
{
    /// IDs Colors
    std::map<int, cimage::RGBA8> m_colors;
    
    int m_curCategory;
    
    long m_nextGUID;

     public:
    DefaultAnnotationPolicy();
    virtual ~DefaultAnnotationPolicy();

    /// Set the Color for ID (from min to max)
    void SetColor(int category, cimage::RGBA8 color);
 	
    void SetCurCategory(int n) { m_curCategory = n; }
    int GetCurCategory() const { return m_curCategory; }

    virtual bool NewItem(AnnotationBox & box);
    virtual bool SwitchItem(AnnotationBox & box);
    virtual cimage::RGBA8 IdToColor(int box);
    

};

/// Class to handle IO of AnnotationSequence on Disk
struct GOLD_UI_EXPORT AnnotationIO {
    AnnotationSequence m_list;
    
public:
    AnnotationIO();
    ~AnnotationIO();

    AnnotationSequence & Sequence() { return m_list; }
    const AnnotationSequence & Sequence() const { return m_list; }
    
    /// Access RW to Frame
    AnnotationFrame & Frame(long frameNo) { return m_list[frameNo]; }
    const AnnotationFrame & Frame(long frameNo) const { return m_list.find(frameNo)->second; }

    /// Save an Annotation Data on Disk
    bool Save(const char *fileName) const;
    /// Load an Annotation Data from Disk
    bool Load(const char *fileName);

    /// Test if Frame exists
    bool Exists(long frame) const;
    /// Test if Frame exist and it is not empty
    bool IsEmpty(long frame) const;

    /// Copia un frame su un altro
    void Copy(long fromNumber, long toNumber);
};

#endif


#ifdef DEPRECATED_ANNWIDGET
/**  Un Widget che permette sia di annotare che mantenere lo stato dell-annotazione
 *  in memoria e gestire l'IO attraverso la classe AnnotationIO
 * \code
 * boost::shared_ptr<window::CWidgetAnnotator> m_annotator;
 * // ...
 * m_annotator = boost::shared_ptr<window::CWidgetAnnotator> (new window::CWidgetAnnotator() );
 * m_annotator->Load("annotationfile.txt");
 * // .... On_Execute ....
 * m_annotator->SetCurFrame(curFrame);
 * win->Push(m_annotator);
 * //  .... On_ShutDown ....
 * m_annotator->Save("annotationfile.txt");
 * \endcode
 **/
class GOLD_UI_EXPORT CWidgetAnnotator : public CWidget, public AnnotationIO {
  
    /// raggiio di azione dell'ancora
    static const int border = 3;

    /// cur frames
    long m_curFrame;
    /// Box attualmente selezionato dal mouse
    int m_selectedBox;
    /// Box attualmente evidenziato dal mouse ma non selezionato
    int m_highlightBox;

    // bool m_captured;    ///< captured

    int  m_v_anchor;      ///< which anchor are engage?
    int  m_h_anchor;      ///< which anchor are engage?  

    /// una copia di un frame
    AnnObjectsType m_copyFrame;
    /// una copia di un oggetto
    AnnotationBox m_copyObj;
    
    int interpolate_guid;
    int interpolate_frame;
    
    /// BBox policy
    boost::shared_ptr<AnnotationPolicy> m_policy;

    private:
    void DrawAnchor(CWindowCore *Window, double x, double y);
    void DrawAnchors(CWindowCore *Window, const Rect2f & r);

    int Draw(CWindowCore *Window, const AnnotationBox & frame, int special);
    int Draw(CWindowCore *Window, const AnnotationFrame & frame);

    public:
    CWidgetAnnotator(int curFrame = 0);
    ~CWidgetAnnotator();

    /// Set the Current Frame in m_list
    void SetCurFrame(int frameNo);

    /// Cancella il fotogramma corrente
    void Clear();
    /// Copia il frame corrente su @a dst
    void Copy(AnnObjectsType & dst);
    /// Copia il frame corrente nella memoria interna
    void Copy();
    /// Incolla @a src sul frame corrente sostituendolo
    void Paste(const AnnObjectsType & src);
    /// Incolla la memoria interna sul frame corrente
    void Paste();
    
    void Interpolate();

    /// Change the Allocation Policy
    void SetPolicy(boost::shared_ptr<AnnotationPolicy> policy) { m_policy = policy; }
    
// standard methods //
    const char *getName() const;
    int Draw(CWindowCore *Window);
    bool Interact(CWindowCoreManager *Window, const CWindowEvent & event);
};
#endif


// Anchor:
// 1 2 3
// 4   5  0 = none
// 6 7 8 

/// Base of Annotation Widget
class GOLD_UI_EXPORT CResizableBox: public CWidget {
  
    static const int border = 3;

#ifdef USE_BOOST_SIGNAL2
    typedef boost::signals2::signal<void (const math::Rect2f &)> callbackType;
#else
    typedef boost::signal<void (const math::Rect2f &)> callbackType;
#endif

    math::Rect2f m_limit; ///< border limit
    math::Rect2f m_soft_limit; ///< soft limit
    math::Rect2f m_box;   ///< drawing box
    math::Point2f m_point;    ///< current point

    bool m_visible;     ///< Anchor are visible?
    bool m_filled;

    bool m_captured;    ///< captured

    int  m_v_anchor;      ///< which anchor are engage?
    int  m_h_anchor;      ///< which anchor are engage?  

    /// funzioni da chiamare quando il box viene ridimensionato
    callbackType m_callback;	

    private:
    bool left() const;
    bool right() const;
    bool top() const;
    bool bottom() const;

    static void DrawAnchor(CWindowCore *Window, double x, double y);

    public:
    /// ctor: 
    /// @param box un rettangolo iniziale
    /// @param limit dimensioni massime su cui il box si puo' espandere
    CResizableBox(const math::Rect2f &box, const math::Rect2f & limit, bool filled);
    ~CResizableBox();

    const char *getName() const;
    int Draw(CWindowCore *Window);
    bool Interact(CWindowCoreManager *Window, const CWindowEvent & event);

    /// Espone la variabile m_callback;
    callbackType & callback() { return m_callback; }
    
    /// Ritorna il box (IO)
    math::Rect2f & Box() { return m_box; }
};

/** Classe che permette di deformare un poligono usando delle maniglie
 *   modificando direttamente la memoria utente, un Mutex viene usato per impedire l'accesso
 *   contemporaneo a tale risorsa.
 * \code
 * win->Push(new CPolyWidget<Point2d>(mialista,4,8.0f));
 * \endcode
 */
template<class T>
class GOLD_UI_EXPORT CPolyWidget : public CWidget, public boost::mutex {
    T *m_list;
    unsigned int m_points;

    float marker_size;
    int m_vertex;   ///< vertice correntemente selezionato
    
    cimage::RGBA8 marker, active;
    math::Point2f *m_poly;

    int find_near(float x, float y);

public:
    /// Costruttore
    /// @param pt_list un array che verra' modificato
    /// @param n_points number of points. numero di punti (massimo)
    /// @param ms   MarkerSize. Size of Marker in pixels
    CPolyWidget(T *pt_list, unsigned int n_points, float ms);
    ~CPolyWidget();
    const char *getName() const;
    int Draw(CWindowCore *Window);
    bool Interact(CWindowCoreManager *Window, const CWindowEvent & event);
};

/// Un fascio di rette customizzabile
class GOLD_UI_EXPORT CLinesSheaf : public CWidget, public boost::mutex {
	math::Point2f m_c;
    std::vector<math::Point2f> m_v;
    math::Rect2f m_limit; ///< border limit
    bool captured;
    int object; /// -1,0..N

    math::Line3f vector_to_line(const math::Point2f & p) const;

public:
    CLinesSheaf(math::Point2f c, math::Rect2f limit);
    ~CLinesSheaf();
    const char *getName() const;
    int Draw(CWindowCore *Window);
    bool Interact(CWindowCoreManager *Window, const CWindowEvent & event);
    math::Point2f Center() const { return m_c; }
};

} // namespace win
} // namespace ui

#endif
