/** \file CFontManager.h
 *  \brief Header per la classe FontManager, un gestore con cache dei font verso FTGL
 *  \author Paolo Medici medici@ce.unipr.it
 **/

#ifndef _CFONTMANAGER_H
#define _CFONTMANAGER_H

#include <map>
#include <string>
#include <Data/Math/Points.h>
// #include <UI/gold_ui_export.h>

// Fw Declaration of the FreeType font type
class FTFont;

namespace ui
{
namespace win
{

/// L'oggetto FontManager che alloca e ritorna on demand oggetti FTFont
class FontManager {

/// mappa tra HASH, FTFont object :)
typedef std::map< std::string, FTFont *> FontMap_t;

/// cache 
FontMap_t FontCache;

/// Font correntemente selezionato
FTFont *curFont;

// un fattore di scala per tenere conto della differenza del font size interno e quello reale
double InternalScaleFactorX, InternalScaleFactorY;

/** Return a match using font-config
 * @see CWindow.h CWindow::SetFontName for the sintax
 */
std::string FontMatch(const std::string & font);

// public:
//static std::string g_fontPath; /// 
public:
  FontManager();
  ~FontManager();

  /// Alloca (o prende dalla cache) un font dall dimensione 'size' con il nome 'name' e un fattore moltiplicativo (ratio)
  /// @param isize dimensione del font interna (per allocare il font, in pixel)
  /// @param esize dimensione del font esterna (per disegnare il font, in coordinate logiche)
  /// @note @a isize in effetti viene ulteriormente processato per fornire un numero ridotto di font e limintarne la dimensione massima
  FTFont *SetFont(const std::string & name, double isize, double osizex, double esizey);
  
  /// Disegna una stringa nella posizione X,Y,Z
  bool DrawText(const math::Point3d& p, const char *text);
  
  /// Disegna una stringa nella posizione corrente con lo scale factor impostato da SetFont
  /// @note usa il sistema di riferimento OpenGL bottom-up
  bool DrawText(const char *text);
  
  /// Return Width and Height of text
  bool GetTextSize(double &width, double &height, const char *text);
  
  // se i font possono essere cancellati e' necessaria una politica di gestione del numero di utenti che possiedono un deteminato font:
  // per ora questa funzione non fa nulla
  bool Release(void);

  /// Svuota la lista dei font. Essendo dei glDeleteTexture devono essere eseguiti
  /// all'interno del contesto OpenGL
  bool ReleaseAll(void);
  
  ///  costruisce dal nome e dalla dimensione del font una stringa che identifica unicamente
  ///  il font 
  static std::string make_font_name(const std::string & name, unsigned int size);
};

  
} // namespace win
} // namespace ui

#endif
