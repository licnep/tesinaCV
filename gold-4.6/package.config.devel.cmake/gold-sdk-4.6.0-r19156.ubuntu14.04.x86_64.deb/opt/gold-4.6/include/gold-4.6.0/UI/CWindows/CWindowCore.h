/**
 * \file CWindowCore.h
 * \brief GOLD CWindow Draw Server (CWindowCore)
 * \author Paolo Medici (medici@ce.unipr.it)
 * \date 7-7-2004
 */

#ifndef _C_WINDOW_CORE_H
#define _C_WINDOW_CORE_H

#include <string>

#include "CWindowCamera.h"
#include "CWindowCommand.h"
#include "CWindowSurface.h"

#include <UI/CWindows/CWindowTypes.h> 
#include <UI/CWindows/CWidget.h>
#include <UI/CWindows/CWindowViewPort.h>
#include <UI/CWindows/CWindowInternal.h>

#include <Data/Math/TMatrices.h>
#include <Data/Math/Rects.h>

#include <UI/gold_ui_export.h>

namespace ui
{
namespace win
{

/** CWindowCore e' la classe che si occupa dell'effettivo rendering
 *   e viene passata ai DrawingObject e ai CWidget
 * 
 * Questa classe e' quella che dialoga direttamente con il driver, per questo e' abbastanza
 *  austera.
 **/
class GOLD_UI_EXPORT CWindowCore
{
public:
	CWindowCore();
	virtual ~CWindowCore();

	///// VIEWPORT HANDLING ////////////

	/// Set a new Window Rendering ViewPort, mode and camera
	virtual void SetViewPort(ViewPortMode mode = WCVM_INHERIT,
			CWindowViewPort * viewPort = 0, sharedPtrWindowCamera camera =
					sharedPtrWindowCamera());

			/// Import the current ViewPort
			const CWindowViewPort & GetViewPort() const
	{
		return m_viewport;
	}
	/// return the current viewport
	ViewPortMode GetViewPortMode(void) const
	{
		return m_viewport_mode;
	}
	/// Return the Current Camera
	sharedPtrWindowCamera GetCamera()
	{
		return m_camera;
	}

	/// Return the Current Projection Matrix
	const math::TMatrix<double, 3, 4> & GetProjectionMatrix() const
	{
		return m_viewMatrix;
	}

	/// Return the current viewport
	const math::Rect2i & GetPhysicalViewPort() const
	{
		return m_phyViewport;
	}

	/// Ritorna il Viewport corrente 3d originale (non quello modificato dall'utente)
	void GetProjectionMatrix(math::TMatrix<double, 3, 4> & M);

	/// Ritorna la matrice inversa a riposo della camera
	void GetRestInverseUVWMatrix(math::TMatrix<double, 3, 4> & M);

	/// return the screen width and height (GetSize for Core)
	unsigned int Width() const
	{
		return m_width;
	}
	unsigned int Height() const
	{
		return m_height;
	}

	/// return the screen width and height wanted by user by last call
	unsigned int UserWidth() const
	{
		return m_userWidth;
	}
	unsigned int UserHeight() const
	{
		return m_userHeight;
	}

	/// Return current top-left screen coordinate of window
	math::Point2i GetPosition() const
	{
		return math::Point2i(m_x, m_y);
	}

	/// Return the Custom Text
	const std::string & GetCustomText() const
	{
		return m_customText;
	}

	/// return the Window Title
	const std::string & GetTitle() const
	{
		return m_title;
	}

	/// Associa una immagine al Rendering Context
	virtual bool BindImage(const cimage::CImage::SharedPtrConstType& img)
	{
		return false;
	}

	/// Disegna una CImage su un poligono tridimensionale dati i 4 vertici
	///  Internamente usa BindImage + DrawQuads, pero' una CWindowCore puo' sovrascrivere questo comportamento per ottenerne uno piu' efficiente
	virtual bool DrawImage(const math::Point3f * quads,
			const cimage::CImage::SharedPtrConstType & img);

	/// Disegna una CImage sul piano Z=0 tra i due vertici
	///  Internamente usa BindImage + DrawQuads, pero' una CWindowCore puo' sovrascrivere questo comportamento per ottenerne uno piu' efficiente
	virtual bool DrawImage(const math::Point2f &a, const math::Point2f & b,
			const cimage::CImage::SharedPtrConstType & img);

	/// Disegna una linea
	virtual bool DrawLine(double X0, double Y0, double X1, double Y1)
	{
		return false;
	}

	/// Disegna un Box
	virtual bool DrawBox(double X0, double Y0, double X1, double Y1,
			bool Filled)
	{
		return false;
	}
	/// Disegna un ellisse
	/// @param X0,Y0 coordinata top-left del bounding box dell'ellisse
	/// @param X1,Y1 coordinata top-left del bounding box dell'ellisse
	/// @param a0,a1 angolo di inizio e angolo di fine dell'ellisse (solitamente 0.0 e 2*PI)
	/// @param Filled true se e' pieno, false se e' solo contorno
	virtual bool DrawEllipse(double X0, double Y0, double X1, double Y1,
			double a0, double a1, bool Filled)
	{
		return false;
	}

	/*@{*/
	/// Disegna dei pixel
	virtual bool DrawPixels(const math::Point2f *points, unsigned int PointNo)
	{
		return false;
	}
	/// Disegna dei pixel in 3d
	virtual bool DrawPixels(const math::Point3f *points, unsigned int PointNo)
	{
		return false;
	}
	/// Disegna dei pixel in 3d/2d colorati
	virtual bool DrawPixels(const C4UB_V3F_t *points, unsigned int PointNo)
	{
		return false;
	}
	/// Disegna dei pixel in 3d/2d textured
	virtual bool DrawPixels(const T2F_V3F_t *points, unsigned int PointNo)
	{
		return false;
	}
	/*@}*/

	/*@{*/
	/// Disegna una linea spezzata
	virtual bool DrawPolyLine(const math::Point2f *vertex,
			unsigned int VertexNo, bool Filled)
	{
		return false;
	}
	/// Disegna una Polilinea in 3d
	virtual bool DrawPolyLine(const math::Point3f *p, unsigned int n_points,
			bool filled)
	{
		return false;
	}
	/*@}*/

	/*@{*/
	/// Disegna un array segmenti: sono punti che presi due a due rappresentano una linea
	virtual bool DrawLineStream(const math::Point2f *vertex,
			unsigned int LineCount)
	{
		return false;
	}
	/// Disegna un array segmenti: sono punti che presi due a due rappresentano una linea
	virtual bool DrawLineStream(const math::Point3f *vertex,
			unsigned int LineCount)
	{
		return false;
	}
	/// Disegna un array segmenti: sono punti che presi due a due rappresentano una linea
	virtual bool DrawLineStream(const C4UB_V3F_t *vertex,
			unsigned int LineCount)
	{
		return false;
	}
	/*@}*/

	/*@{*/
	/// Disegna un array di triangoli: ogni 3 punti rappresentano un triangolo 2D
	virtual bool DrawTriangles(const math::Point2f *vertex, unsigned int Count)
	{
		return false;
	}
	/// Disegna un array di triangoli: ogni 3 punti rappresentano un triangolo 3D
	virtual bool DrawTriangles(const math::Point3f *vertex, unsigned int Count)
	{
		return false;
	}
	/// Disegna un array di triangoli: ogni 3 punti rappresentano un triangolo colorato
	virtual bool DrawTriangles(const C4UB_V3F_t *vertex, unsigned int Count)
	{
		return false;
	}
	/// Disegna un array di triangoli: ogni 3 punti rappresentano un triangolo texturato
	virtual bool DrawTriangles(const T2F_V3F_t *vertex, unsigned int Count)
	{
		return false;
	}

	/*@}*/

	/*@{*/
	/// Disegna un array di quads: ogni 4 punti rappresentano un rettangolo
	virtual bool DrawQuads(const math::Point2f *vertex, unsigned int Count)
	{
		return false;
	}
	/// Disegna un array di quads in 3d: ogni 4 punti rappresentano un rettangolo
	virtual bool DrawQuads(const math::Point3f *vertex, unsigned int Count)
	{
		return false;
	}
	/// Disegna un array di Quads in 3D colorati
	virtual bool DrawQuads(const C4UB_V3F_t *vertex, unsigned int Count)
	{
		return false;
	}
	/// Disegna un array di Quads in 3D colorati
	virtual bool DrawQuads(const T2F_V3F_t *vertex, unsigned int Count)
	{
		return false;
	}
	/*@}*/

	/// Imposta il font corrente
	virtual bool SetFontName(const char *FontName);

	/// Imposta la dimensione del font nelle due direzioni e se e' agganciato al viewport fisico o quello logico
	/// @param XSize dimensione del font lungo la direzione X (puo' essere anche negativo per invertirlo)
	/// @param YSize dimensione del font lungo la direzione Y (puo' essere anche negativo per invertirlo)
	/// @param absolute se true il font e' relativo al display fisico, mentre se false e' relativo al display logico
	virtual bool SetFontSizeEx(double XSize, double YSize, bool absolute);

	/// Imposta la dimensione del font
	bool SetFontSize(double Size)
	{
		return SetFontSizeEx(Size, Size, false);
	}

	/// Disegna del testo in 3d
	virtual bool DrawText(const math::Point3d & p, const char *Texte)
	{
		return false;
	}

	template<class T>
	bool DrawText(T x, T y, const char *Text)
	{
		return DrawText(math::Point3d(x, y, 0.0), Text);
	}

	template<class T>
	bool DrawText(T x, T y, const std::string & Text)
	{
		return DrawText(math::Point3d(x, y, 0.0), Text.c_str());
	}

	template<class T>
	bool DrawText(const math::Point3<T> & p, const std::string & Text)
	{
		return DrawText(p, Text.c_str());
	}

	/// Ritorna la dimensione del testo
	virtual bool GetTextSize(double &X, double &Y, const char *Texte)
	{
		return false;
	}

	/// Imposta il colore corrente di disegno
	virtual bool SetColor(cimage::RGBA8 pColor)
	{
		return false;
	}

	/// Ritorna il colore corrente di disegno
	virtual bool GetColor(cimage::RGBA8 *pColor)
	{
		return false;
	}

	/** ZBuffer function **/
	virtual void EnableZBuffer(double near, double far);
	virtual void DisableZBuffer();

	/// Ritorna il colore sotto il mouse
	virtual bool GetHighlightColor(cimage::RGBA8 *pColor)
	{
		return false;
	}

	/// Imposta il tema per la GUI
	void SetTheme(const CWindowTheme & theme);
	/// Return the current GUI colors
	const CWindowTheme & Theme(void) const
	{
		return m_theme;
	}

	/*    virtual bool SetRotation(double angle);        */
	virtual bool SetTranslation(double dx, double dy, bool absolute);

	/// Abilita l'alpha blending
	virtual bool SetBlend(BlendType_t _blend)
	{
		blend = _blend;
		return true;
	}
	BlendType_t GetBlendStatus(void) const
	{
		return blend;
	}

	virtual bool SetLineSmooth(bool Enabled)
	{
		return false;
	}
	virtual bool SetLineWidth(float Width)
	{
		return false;
	}
	virtual bool SetPointSize(float Size)
	{
		return false;
	}

	/** Proprietary Extension **/
	virtual void RunExtension(const char *cmd)
	{
	}

	// Riempie un buffer di memoria con il contenuto della finestra
	// e' da core? forse e' piu' da Manager. Riflettere
	virtual bool GetImage(cimage::CImage & dst);

	void SetTextAlign(TextAlign_t h, TextAlign_t v)
	{
		text_h_align = h;
		text_v_align = v;
	}
	// utility fn

	/// Magic: ritorna se una FLAG e' settata
	inline bool IsFlagSet(CWINDOW_FLAG F) const
	{
		return (m_style & F) != 0;
	}

	/// Magic imposta o meno una Flag
	template<CWINDOW_FLAG F>
	inline void SetFlag(bool status)
	{
		if (status)
			m_style |= F;
		else
			m_style &= ~F;
	}

	/// Cambia lo stato di una flag
	template<CWINDOW_FLAG F>
	inline void ToggleFlag(void)
	{
		SetFlag<F>(!IsFlagSet(F));
	}

	/// Restituisce se la finestra e' nello stato FullScreen
	inline bool IsFullScreen(void) const
	{
		return (m_style & CWF_FULLSCREEN) != 0;
	}

	/// Restituisce se la finestra e' visibile
	inline bool IsVisible(void) const
	{
		return (m_style & CWF_VISIBLE) != 0;
	}

	/// L'aspect ratio e' bloccato? !CWF_STRETCH
	inline bool IsAspectRatioLocked(void) const
	{
		return (m_style & CWF_STRETCH) == 0;
	}

/// Projective Mapping
	/*@{*/
	/** Funzione che proietta un punto 3D X,Y,Z in un punto Schermo
	 * @note T puo' essere solo int o float
	 * @note usa la matrice viewport corrente
	 * \code
	 *  Point2i screen = win->WindowToScreen<int>(world);
	 * \endcode
	 */
	template<class T>
	math::Point2<T> WindowToScreen(const math::Point3f & p) const;

	/** funzione che converte un punto logico in un punto dello schermo
	 * @note T puo' essere solo int o float
	 * @note usa la matrice viewport corrente
	 * \code
	 *  Point2i screen = win->WindowToScreen<int>(wx,wy,wz);
	 * \endcode
	 **/
	template<class T>
	math::Point2<T> WindowToScreen(float x, float y, float z = 0.0) const
	{
		return WindowToScreen<T>(math::Point3f(x, y, z));
	}
	/*@}*/

/// Information
	/*@{*/
	/// Return the average drawing time
	float GetDrawingTime() const
	{
		return m_drawing_time;
	}
	/// Return the time between two subsequent Refresh request
	float GetRefreshRate() const
	{
		return m_cycle_time;
	}

	/// The number of complete frames (software)
	unsigned long GetRefreshCount() const
	{
		return m_refreshCounter;
	}
	/// The number of drawed frames
	unsigned long GetDrawedCount() const
	{
		return m_drawCounter;
	}
	/// The number of dumped frames
	unsigned long GetDumpedCount() const
	{
		return m_frameCounter;
	}

	/// Return the number of Drawed Objects
	unsigned int GetDrawedObjectCount() const
	{
		return m_drawed_object;
	}
	/*@}*/

protected:
	///////////////////////////////////////////////////////////////////
	/// Window Title
	std::string m_title;

	/// Current Window Size
	unsigned int m_width, m_height;

	/// dimensioni della finestra fissate dall'utente
	unsigned int m_userWidth, m_userHeight;

	/// Z-Buffer Range
	double m_zNear, m_zFar;

	/// Position of Window on Screen
	int m_x, m_y;

	/// Window Style
	unsigned int m_style;

	/// GUI COLOR
	CWindowTheme m_theme;

	/// Type of Blending
	BlendType_t blend;

	/// Align text
	TextAlign_t text_h_align, text_v_align;

	/// Selected Font Name
	std::string FontName;

	/// Current Viewport mode (SCREEN, OGL, CAMERA)
	ViewPortMode m_viewport_mode;

	/// Current Viewport coordinate
	CWindowViewPort m_viewport;

	/// Current Physical ViewPort
	math::Rect2i m_phyViewport;

	/// Current camera Viewport
	sharedPtrWindowCamera m_camera;

	/// Current Projection Matrix
	/// (u*z,v*z,z) = M (X,Y,Z,1)
	math::TMatrix<double, 3, 4> m_viewMatrix;

	/// Custom Text
	std::string m_customText;

	float m_drawing_time; ///< tempo (sec) di disegno
	float m_cycle_time;   ///< tempo tra due chiamate successive alla Refresh

	/// Number of frames dumped
	unsigned long m_frameCounter;
	/// Number of frame drawed
	unsigned long m_drawCounter;
	/// Number of Software Refresh arrived
	unsigned long m_refreshCounter;

	/// Numero di oggetti disegnati in the last call
	int m_drawed_object;

	boost::posix_time::ptime old_cycle_master_time;	///< ultima refresh
	boost::posix_time::ptime window_creation_time;///< tempo di creazione della finestra
	boost::posix_time::ptime timer;   	 ///< timer per benchmarkare le window

};

} // namespace win
} // namespace ui

#endif
