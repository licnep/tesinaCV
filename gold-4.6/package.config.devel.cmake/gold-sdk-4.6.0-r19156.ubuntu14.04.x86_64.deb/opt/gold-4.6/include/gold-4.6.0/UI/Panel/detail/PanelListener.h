#ifndef _UI_PANELLISTENER_H
#define _UI_PANELLISTENER_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * \file PanelListener.h
 * \author Paolo Medici(medici@vislab.it), Paolo Zani (zani@vislab.it)
 * \date 2010-12-30
 **/

#include <UI/Panel/detail/PanelTypes.h>
#include <UI/Panel/detail/WidgetCore.h>

#include <string>
#include <vector>

namespace ui
{
    namespace detail
    {
        /// il panel Listener viene avvertito quando la GUI cambia
        class PanelListener
        {
            public:

                virtual ~PanelListener() { };

                /// Quando viene aggiunto al pannello parente un nuovo widget
                virtual void On_Widget_Add(widget_guid_t parent_guid, widget_guid_t guid, const WidgetCore& widget) = 0;
                /// Quando un widget cambia geometria
                virtual void On_Widget_Changed(widget_guid_t guid, const WidgetCore& widget) = 0;
                /// Quando un widget viene rimosso
                virtual void On_Widget_Remove(widget_guid_t guid) = 0;
                /// Quando un widget cambia valore *
                virtual void On_Value_Changed(widget_guid_t guid, const WidgetCore& widget) = 0;
                /// Quando un widget cambia attributi nella parte del dato
                virtual void On_Data_Changed(widget_guid_t guid, const WidgetCore& widget) = 0;

                /// Quando un pannello diventa visible
                virtual void On_Panel_Opened(widget_guid_t guid, const WidgetCore& widget) = 0;
                /// Quando un widget viene nascosto
                virtual void On_Panel_Close(widget_guid_t guid) = 0;
        };
    }
}

#endif
