/** \file glutils.h
 *  \brief Funzioni comuni per usare le chiamate OpenGL
 **/
#ifndef _GL_UTILS_H
#define _GL_UTILS_H

#ifdef WIN32
# include <Windows.h>
#endif

#include <GL/gl.h>
#include <cstring>

#include <Data/Math/Rects.h>
#include <Data/CImage/CImage.h>
#include <Libs/Logger/Log.h>
#include <UI/CWindows/CWindowInternal.h>
namespace ui
{
  namespace win
  {
    
/// Vertice usato normalmente per disegnare una texture
typedef struct T2F_V3F_t TexVertex;

/// crea, partendo dai due estremi, le coordinate del QUAD per una texture.
///  Il Quad e' fullsize, ovvero ricopre tutta la texture.
void BoxToTexVertex(TexVertex *V, float x0, float y0, float x1, float y1);

struct GLSurface {
  unsigned char *texture;
  unsigned int width, height;
  GLint format;
};

bool GLSquareTexture(GLSurface &dst, const GLSurface & src);

/** Muove una texture in memoria video
 * @param Texture un puntatore a memoria
 * @param TxtWidth,TxtHeight Dimensioni della texture (potenze di 2 o rettangolari)
 * @param img_format Tipo di immagini GL_LUMINANCE, GL_RGB, ...
 * @param internal_format formato interno (GL_LUMINANCE, GL_RGB, GL_BGR, ...)
 * @param TextureType tipo di texture (GL_TEXTURE_2D o una del tipo rettangolare) TODO: automatico?
 * @param mipmap Generate mipmap subtexture (slow)
 * @return un id di texture
 **/
GLuint GLLoadImage(const GLSurface & src, GLint internal_format=-1, GLuint TextureType = GL_TEXTURE_2D, bool mipmap = false);

/** Esegue il rendering della texture, settando i parametri per il rendering
 * @param textureid un id di una texture
 * @param linear_texture_filter applica un filtragio bilineare per magnificare la texture
 * @param Vertices un array di 4 TexVertex contenentei coordinate del rettangolo da disegnare
 * @return true se i parametri sono corretti
 **/
bool GLDrawTexVertex(GLuint textureid, bool linear_texture_filter, const TexVertex *Vertices, GLuint TextureType = GL_TEXTURE_2D);

template<class T, int format, int iformat>
int GLPrepareTexture(math::Rect2f & t, const T & img,  bool mipmap, GLuint TextureType)
{
  GLSurface src;
  src.texture = (unsigned char *) img.Buffer();
  src.width = img.W();
  src.height = img.H();
  src.format = format;

//   std::cout << TextureType << std::endl;

  if(TextureType == GL_TEXTURE_2D)
    {
    GLSurface dst;
    dst.texture = NULL;
    // TODO: check for square texture
    GLSquareTexture(dst, src);

    t.x0 = 0.0;
    t.x1 = (float) src.width / (float) dst.width;
    t.y0 = 0.0;
    t.y1 = (float) src.height / (float) dst.height;
    
    int ret = GLLoadImage(dst, iformat, TextureType, mipmap);

    // liebro la memoria allocata da GLSquareTexture
    delete [] dst.texture;

    return ret;
    }
    else
    {

    t.x0 = 0;
    t.x1 = img.W();
    t.y0 = 0;
    t.y1 = img.H();
 
    return GLLoadImage(src, iformat, TextureType, mipmap);
    }
}

template<class T, int format, int iformat>
bool GLDraw(const math::Point3f *pt, const T & img,  bool mipmap, bool linear_texture, GLuint TextureType)
{
  TexVertex Vertices[4];
  math::Rect2f t;
  GLuint textureid;
  GLenum error;

//    std::cout << "mipmap: " << mipmap << " linear_texture:" << linear_texture << " TextureType:" << TextureType << std::endl;

// se voglio la mipmap devo sare una texture2D
  if(mipmap)
   TextureType = GL_TEXTURE_2D;

  // Carico la CImage in una Texture OpenGL
  textureid = GLPrepareTexture<T, format, iformat>(t, img, mipmap, linear_texture, TextureType);

  //Genera il rettangolo su cui applicare la texture
  Vertices[0] = TexVertex(pt[1], t.x1, t.y0);
  Vertices[1] = TexVertex(pt[0], t.x0, t.y0);
  Vertices[2] = TexVertex(pt[3], t.x0, t.y1);
  Vertices[3] = TexVertex(pt[2], t.x1, t.y1);
    
  // attenzione che ora la gestione del blend non e' attivata sempre
  GLDrawTexVertex(textureid, linear_texture, Vertices, TextureType);
  
  // Libera le risorse allocate per la texture (questo non permette il disegno in parallelo di piu' texture)
  // TODO: 
   glDeleteTextures(1, &textureid);
  
  if((error=glGetError())!=GL_NO_ERROR)
        log_error << "glDeleteTextures: " << error << std::endl; 
 
 return true;
}

template<class T, int format, int BytesPerPixel>
bool GLCapture(T & img)
{
  unsigned int ImgWidth = img.W();
  unsigned int ImgHeight = img.H();
  GLint error;
  long pitch;
  bool ret;
  pitch = ImgWidth * BytesPerPixel;
  
  unsigned char *Buffer = new unsigned char [pitch*ImgHeight];
  
  // Nota: gli altri modi GL_PACK_* sono di default (speriamo)
  glPixelStorei(GL_PACK_ALIGNMENT, 1);

  error = glGetError();
  if(error != 0)
	log_warn << "glPixelStorei failed: " << error << std::endl;
  // NOTA: se ora usa il glReadBuffer di default. legge dal Back buffer!!!!
  
    // Estrae il buffer dalla memoria video
  glReadPixels(0, 0,
                (GLsizei) ImgWidth, (GLsizei) ImgHeight,
                format,
                GL_UNSIGNED_BYTE,
                Buffer);
  
  error = glGetError();
  if(error != 0)
	{
	log_error << "glReadPixels failed: " << error << std::endl;
	ret = false;
	}
   else
	{
		int i;
		unsigned char *Dst = (unsigned char *) img.Buffer();
		// Inverte il Buffer (e' bottom-up) 
		// TODO: si puo' evitare???
		i = ImgHeight;
		do {
			
		memcpy(Dst + (i-1)*pitch, Buffer + (ImgHeight - i) * pitch, pitch);
		
		} while(--i);
		
		ret = true;
	}

    delete [] Buffer;
    return ret;
}

  } // namespace win
} // namespace ui
#endif
