/** @file CWindowAddOn.h
  * @brief This file handle miscellaneous Widget not included in CWindow class
  *        Widget che usano chiamate dirette alla libreria di disegno senza passare dal Server CWindowCore
  * @author Paolo Medici (medici@ce.unipr.it)
  **/

#ifndef _WINDOW_ADDON_H
#define _WINDOW_ADDON_H

#include <UI/CWindows/CWidgets.h>

namespace ui {
namespace win {


/** @name flag per le progress bar **/
/*@{*/
/** Mostra la percentuale testo **/
#define PBF_SHOW_PERC       0x00000001
/** SetBlend(BLEND_ALPHA) **/
#define PBF_ALPHA           0x00010000
/** colore che cambia a seconda della percentuale **/
#define PBF_COLOR_CHANGE    0x00020000
/*@}*/

/** @name flag per CWindow::DrawScaleBar **/
/*@{*/
/// Orizzontale (il default e' verticale)
#define SBF_HORZ            0x00000001
/// Scala di hue, invece che toni di grigio (default)
#define SBF_HUE             0x00000002
/// Inverte la scala
#define SBF_INVERT          0x00000004
/// Legenda dalla parte opposta
#define SBF_FLIP_TEXT       0x00000008
/// Nessuna legenda
#define SBF_NO_TEXT         0x00000010
/*@}*/

/** Disegna una scala colorata 
* \image html DrawScaleBar.png
*/
CDrawingQueue GOLD_UI_EXPORT ScaleBar(double x, double y, double w, double h, double top_value, double bottom_value, unsigned int style);

/** Disegna una barra di progresso
 * @param x0,y0,x1,y1 un rettangolo che contiene la ProgressBar
 * @param percentage un numero compreso tra 0 e 1.
 * @param fx un fx tra i PBF_SHOW_PERC PBF_ALPHA PBF_COLOR_CHANGE
 * \code
 * *m_pMainWindow << window::ProgressBar(10,10, 630,30, (float) i / (float) m_history.size(), PBF_SHOW_PERC);	
 * \endcode
 * \image html DrawProgressBar.png
 **/
CDrawingQueue GOLD_UI_EXPORT ProgressBar(double x0, double y0, double x1, double y1, double percentage, unsigned int fx=0);

}
}

#endif
