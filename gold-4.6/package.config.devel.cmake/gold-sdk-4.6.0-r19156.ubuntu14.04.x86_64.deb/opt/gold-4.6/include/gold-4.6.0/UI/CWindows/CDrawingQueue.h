/** \file CDrawingQueue.h
 *  \brief File che contiene la classe CDrawingQueue, classe che implementa una collezione di oggetti da disegnare
 *  \author Paolo Medici \<medici@ce.unipr.it\> Paolo Grisleri \<grisleri@ce.unipr.it\>
 **/
#ifndef _CDRAWINGQUEUE_H
#define _CDRAWINGQUEUE_H

#include <vector>
#include <boost/shared_ptr.hpp>

#include <UI/CWindows/CWidget.h>
#include <UI/gold_ui_export.h>


namespace ui{
  namespace win{

typedef boost::shared_ptr<CWidget> SPDrawingObject;

/// Gestisca una singola istanza della coda di disegno. 
class GOLD_UI_EXPORT CDrawingQueue
{
  public:
  typedef std::vector<SPDrawingObject> SPDrawingObjectList;
   /// Dimensione massima della coda. Serve per evitare che il sistema non venga appesantito eccessivamente, in caso di errore.
  static const unsigned int MaxQueueSize=10000;
 
  public:
    /// costrutture della coda
    CDrawingQueue();
    ~CDrawingQueue();
    
    /// pulisce completamente la coda
    int  Clear(void);  
     /// disegna la lista (ritorna il numero di oggetti disegnati, o -1 per errore
    int Draw(CWindowCore *window);  
    
    bool Interact(CWindowCoreManager *window, const CWindowEvent & event);
    
    /// Aggiunge un oggetto gia' avvolto dentro a un shared_ptr
    bool Push(const SPDrawingObject & DrawObj);
   
    /// Aggiunge una coda alla coda.
    bool Push(const SPDrawingObjectList & queue);

    /// Aggiunge una coda alla coda.
    bool Push(const CDrawingQueue & queue) { return Push(queue.DrawingQueue); }
    
  /** permette di inserire un widget generico T nella CWindow attraverso la sintassi:
    * \code
    * myQueue->Push( new MyCustomDrawing(parameters) );
    * \endcode
    **/
   void Push (CWidget * obj) { Push(SPDrawingObject(obj)); }
    
    
    #if 0
    /// permette di aggiungere oggetto che ammettono l'operatore di copia.
    template<class T>
    inline bool Push (T obj) { return Push(SPDrawingObject(new T(obj))); }
    #endif
    
    /// Debug: stampa il contenuto della coda nello stdout
    void Print(void) const;  
    
    /// restiuisce la lunghezza della coda
    inline std::size_t QueueLength() const {
       return DrawingQueue.size();
    };
    
    /// confronta due code
    CDrawingQueue& operator =(const CDrawingQueue& _DrawingQueue);
    
    SPDrawingObjectList & operator * () { return DrawingQueue; }
	const SPDrawingObjectList & operator * () const { return DrawingQueue; }

    /// Abilita/Disabilita la coda
    inline void Enable(bool enable) { m_enabled = enable; }
    /// La coda e' abilita?
    inline bool IsEnabled(void) const { return m_enabled; }

    /// Blocca la coda
    inline void Lock() { m_locked = true; }
    /// Sblocca la coda
    inline void UnLock() { m_locked = false; }
    /// La coda e' abilita?
    inline bool IsLocked(void) const { return m_locked; }
    
  protected:
    /// Lista di SmartPointer a CDrawingObject
    SPDrawingObjectList DrawingQueue;
  private:
   /// Questa coda di disegno e' abilitata?
    bool m_enabled;
   /// La coda di disegno e' bloccata? non si puo' cancellare ne aggiungere elementi
    bool m_locked;
};

  } // namespace win
} // namespace ui
#endif
