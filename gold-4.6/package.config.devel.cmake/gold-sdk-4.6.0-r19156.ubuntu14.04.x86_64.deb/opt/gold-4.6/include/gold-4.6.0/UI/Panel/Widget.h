#ifndef _WIDGET_H
#define _WIDGET_H

/** @file Widget.h
  * @brief widget class
  **/

#include <UI/gold_ui_export.h>
#include <Libs/INIFiles/strcast.h>
#include <UI/Panel/detail/PanelTypes.h>

#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/iteration/local.hpp>

#include <typeinfo>

#ifndef UI_WIDGET_ADD_MAX_ARITY
#define UI_WIDGET_ADD_MAX_ARITY 30
#endif

namespace ui {

/** \brief Namespace for creating user interface layout */
namespace wgt {

/** widget is only a reference to Widget
  * La classe widget e' un container di GUID e si fa carico di interfacciarsi con il manager
  *
  * it implements some common method to access to widget attributes
  **/
class GOLD_UI_EXPORT Widget {
    /// the inner reference
    detail::widget_guid_t m_guid;

    public:

    /// costruttore da widget_guid_t gia' creato: il ref_count viene incrementato
    Widget(detail::widget_guid_t guid);

    /// costruttore da widget_guid_t
    Widget();
    
    /// costruttore da widget_guid_t
    Widget(const Widget& w);
    
    void operator =(const Widget& w);

    /// costruttore tipico: nome classe + il guid a cui bindarlo
    /// se il guid e' -1 il guid viene creato
    Widget(const std::string & c, detail::widget_guid_t guid);

    ~Widget();

    #define DECL(z, n, text) text(w## n);
    #define BOOST_PP_LOCAL_MACRO(n) inline Widget& operator()(BOOST_PP_ENUM_PARAMS(n, const Widget& w)) { BOOST_PP_REPEAT(n, DECL, this->Add) return *this; }
    #define BOOST_PP_LOCAL_LIMITS (0, UI_WIDGET_ADD_MAX_ARITY)
    #include BOOST_PP_LOCAL_ITERATE()
    #undef DECL

    #define DECL(z, n, text) text(w## n);
    #define BOOST_PP_LOCAL_MACRO(n) inline Widget& Add(BOOST_PP_ENUM_PARAMS(n, const Widget& w)) { BOOST_PP_REPEAT(n, DECL, this->Add) return *this; }
    #define BOOST_PP_LOCAL_LIMITS (2, UI_WIDGET_ADD_MAX_ARITY)
    #include BOOST_PP_LOCAL_ITERATE()
    #undef DECL

    /// Add a widget like a child
    /// @return return THIS!
    Widget & Add(const Widget & guid);

    /// Return the parent widget of current
    Widget Parent() const;
    
    /// crea un link simbolico tra due widget
    void Link(detail::widget_guid_t guid);
    /// rimuove un link simbolico tra due widget
    void UnLink(detail::widget_guid_t guid);

    /// si rimuove dal genitore
    bool Detach();

    /// Costruttore di copia (esegue una Clone di se e dei figli. Perde il parent)
    Widget Clone() const;
    
    /// Broadcast to any listener the "value" binded to widget 
    void Update();
    
    /// Test if widget is shown (observed) by a client
    bool IsActive() const;

    Widget& Attr(const std::string & attr, const std::string & value);
    
    /// @name set/get layout attribute
    /*@{*/
    /// Imposta un attributo di un widget
    /// Attr the internal attribute
    template<class T>
    Widget& Attr(const std::string & attr, const T& value) { return Attr(attr, vl::string_cast(value)); }

   /** ritorna un generico attributo del widget
    * @note se l'attributo non esiste lancia una std::runtime_error
    **/
    const std::string& Attr (const std::string & key) const;
    
    /// Test the existance of an attribute
    bool Has(const std::string & key) const;
    /*@}*/

    /// @name common functions
    /*@{*/
    /// Return the class of control
    const std::string& Class(void) const;

    /// Return the inner GUID
    inline detail::widget_guid_t GUID() const { return m_guid; }

    /// Set/Get Widget Reference for this control
    Widget & Ref(detail::widget_guid_t value);
    inline Widget Ref(void) const { return Widget(vl::numeric_cast<detail::widget_guid_t>(Attr("ref"))); }

    /// Attr the label for this control
    inline Widget & Label(const std::string & value) { Attr("label", value); return *this; }
    inline const std::string& Label(void) const { return Attr("label"); }

    /// Attr the visible flag
    inline Widget & Visible(bool value) { Attr("visible", value); return *this;}
    inline bool Visible(void) const { return vl::numeric_cast<bool>(Attr("visible")); }

    /// Attr the enable flag
    inline Widget & Enable(bool value) { Attr("enabled", value); return *this;}
    inline bool Enable(void) const { return vl::numeric_cast<bool>(Attr("enabled")); }

    /// Attr the enable flag
    inline Widget & Border(int value) { Attr("border", value); return *this;}
    inline int Border(void) const { return vl::numeric_cast<int>(Attr("border")); }

    /// Attr the tooltip for the control
    inline Widget & Tooltip(const std::string & tooltip) { Attr("tooltip", tooltip); return *this;}
    inline const std::string& Tooltip(void) const { return Attr("tooltip"); }

    /// Attr the help page reference (unimplemented?)
    inline Widget & Help(const std::string & help) { Attr("help", help); return *this;}
    inline const std::string& Help(void) const { return Attr("help"); }

    /// Attr the hotkey for the control
    inline Widget & HotKey(const std::string & hotkey) { Attr("hotkey", hotkey); return *this;}
    inline const std::string& HotKey(void) const { return Attr("hotkey"); }

    /// Attr whether the control should expand horizontally or not
    inline Widget & HExpand(int proportion = 1) { Attr("hexpand", proportion); return *this;}
    inline int HExpand(void) const { return vl::numeric_cast<int>(Attr("hexpand")); }

    /// Attr whether the control should expand vertically or not
    inline Widget & VExpand(int proportion = 1) { Attr("vexpand", proportion); return *this;}
    inline int VExpand(void) const { return vl::numeric_cast<int>(Attr("vexpand")); }

    /// Attr the measure unit for the control
    inline Widget & Unit(const std::string & unit) { Attr("unit", unit); return *this;}
    inline const std::string& Unit(void) const { return Attr("unit"); }

    /// Color Entity
    inline Widget & Color(const std::string & color) { Attr("color", color); return *this;}
    inline const std::string& Color(void) const { return Attr("color"); }

    /// imposta la geometria del widget
    Widget & Geometry(int x, int y, int width, int height) {  Attr("x", x); Attr("y", y); Attr("width", width); Attr("height", height); return *this; }

    /// imposta la geometria del widget
    Widget & Geometry(int width, int height) {  Attr("width", vl::string_cast(width)); Attr("height", height); return *this; }
    /*@}*/
};


template<typename T>
T& widget_cast(Widget& widget)
{
    if(widget.Class() == T::Class())
        return *reinterpret_cast<T*>(&widget);
    else
        throw(std::bad_cast());
}

template<typename T>
const T& widget_cast(const Widget& widget)
{
    if(widget.Class() == T::Class())
        return *reinterpret_cast<const T*>(&widget);
    else
        throw(std::bad_cast());
}

template<typename T>
T* widget_cast(Widget* widget)
{
    if(widget->Class() == T::Class())
        return reinterpret_cast<T*>(widget);
    else
        return NULL;
}

template<typename T>
const T* widget_cast(const Widget* widget)
{
    if(widget->Class() == T::Class())
        return reinterpret_cast<const T*>(widget);
    else
        return NULL;
}

} // widget

} // ui

#endif
