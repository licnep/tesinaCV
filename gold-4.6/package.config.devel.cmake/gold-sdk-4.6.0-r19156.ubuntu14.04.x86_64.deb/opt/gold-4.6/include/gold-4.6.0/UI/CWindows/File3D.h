#ifndef _3D_FILE_H
#define _3D_FILE_H

#include <vector>
#include <Data/Math/TMatrices.h>
#include <Data/CImage/Pixels/RGBA8.h>
#include <UI/CWindows/CWidget.h>
#include <UI/gold_ui_export.h>

namespace ui
{
namespace win
{
class GOLD_UI_EXPORT File3DS: public CWidget
{
	struct Material
	{
		cimage::RGBA8 color;
		char name[64];
		std::vector<math::Point3f> triangles;
	};

	std::vector<Material> meshes;

	int find_material(const char *name) const;

public:
	File3DS();
	File3DS(const char *filename);
	virtual ~File3DS();

	/// Open
	bool Open(const char *filename);
	/// Scale
	void Scale(float sx, float sy, float sz);
	/// Move
	void Move(float sx, float sy, float sz);
	/// Rotate
	void Rotate(float yaw, float pitch, float roll);
	/// Transform
	void Transform(const math::TMatrix<float, 3, 3>& M);

	virtual const char *getName() const;
	virtual int Draw(CWindowCore *Window);

};

} // namespace win
} // namespace ui

#endif
