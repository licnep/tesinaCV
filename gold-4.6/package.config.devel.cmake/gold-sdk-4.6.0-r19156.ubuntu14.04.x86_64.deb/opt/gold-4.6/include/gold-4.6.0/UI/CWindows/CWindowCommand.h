/** \file CWindowCommand.h
 *  \brief Header per la classe pura CWindowCommand, elemento base per la comunicazione di messaggi tra client e server.
 *  \author Paolo Medici medici@ce.unipr.it
 **/

#ifndef _CWINDOWCOMMAND_H
#define _CWINDOWCOMMAND_H

#include <boost/shared_ptr.hpp>
#include <Libs/Threads/CSuspendable.hxx>
#include <UI/CWindows/CWindowFwd.h>

#include <UI/gold_ui_export.h>

namespace ui{
  namespace win {
      
  /// I messaggi CWindowCommand sono inseriti nella coda dal client CWindow, e letti ed eseguiti dal thread server.
  class GOLD_UI_EXPORT CWindowCommand:  public vl::thread::CSuspendable
  {
    public:
      // destructor
      virtual ~CWindowCommand() {};
      /// Esegue il comando specificato sulla finestra corrente nel thread.
      virtual void Execute(CWindowCoreManager *window) = 0;         
  };

  /// SmartPointer to a CWindowCommand
  typedef boost::shared_ptr<CWindowCommand> SPWindowCommand;

  }
}

#endif // _CWINDOWCOMMAND_H
