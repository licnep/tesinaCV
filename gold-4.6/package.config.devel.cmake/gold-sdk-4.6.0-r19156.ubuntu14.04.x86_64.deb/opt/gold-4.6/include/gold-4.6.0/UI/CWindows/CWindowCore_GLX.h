#ifndef _CWINDOWCORE_GLX_H
#define _CWINDOWCORE_GLX_H

/** @file CWindowCore_GLX.h
  * @brief implementa i metodi di CWindowCore_OpenGL che dipendono dal sistema operativo e non da OpenGL
  **/

#include "CWindowCore_OpenGL.h"
//

#include <GL/glx.h>
#include <X11/keysym.h>
#include <X11/Xutil.h>
#include <UI/CWindows/GLXThreadManager.h>
#include <UI/CWindows/CWindowX11Common.h>

namespace ui {
  namespace win {

/// implementa una astrazione per CWindow basate su GLX.
class CWindowCore_GLX: public CWindowCore_OpenGL, public CWindowX11
{
    /// SKIN WINDOW. Initial Mouse Position for moving
    math::Point2i init_delta;

    /// interacting with skin window
    bool m_interact_with_window;

  protected:
    void *XEventHandlerThread(void);

    // Thread methods
    static void *XEventHandler_Thread(void *_param);

    /// @name Callback per gli eventi X
    /*@{*/
    void XEventHandlerKeyboard(KeySym Key, unsigned int state);
    void XEventHandlerMouseButtonPress(int x, int y, unsigned int state, unsigned int button);
    void XEventHandlerMouseButtonRelease(int x, int y, unsigned int state, unsigned int button);
    void XEventHandlerMouseMotion(int x, int y, unsigned int state);

    /// Questa funzione intercetta alcuni eventi X (non tutti)
    /// @return true se l'evento e' intercettato, altrimenti false
    bool XEventHandler(const XEvent & e);
    /*@}*/

    bool GLSwapBuffers()
    {
        // inverto i buffer video
    glXSwapBuffers(GetDisplay(), CWindowX11::GetWindow());
    return true;
    }
    
    /// L'istanza del GLXTHreadManager e' ritornata dalle classi sottostanti che la possono
    ///  implementare in modalita' SingleThread o MultiThread
    virtual GLXThreadManager *getManager(void) = 0;
    
    Display  *GetDisplay() { return getManager()->GetDisplay(); }
    Window    GetRootWindow() { return getManager()->GetRootWindow(); }
    int       GetScreen() { return getManager()->GetScreen(); }

/*@{*/
    bool SendRedraw() {
        return getManager()->sendRedraw(CWindowX11::GetWindow());
        }

    bool RaiseWindow() {
       return getManager()->raiseWindow(CWindowX11::GetWindow());
       }

    bool MapWindow() {
      return getManager()->mapWindow(CWindowX11::GetWindow());
      }

    bool WithdrawWindow() {
      return getManager()->withdrawWindow(CWindowX11::GetWindow());
      }

    bool UnmapWindow() {
      return getManager()->unmapWindow(CWindowX11::GetWindow());
      }

    /// return current pointer in (coordinate)
    bool QueryPointer(math::Point2i & pt) {
        return getManager()->queryPointer(CWindowX11::GetWindow(), pt);
        }

     /// Muove la finestra
     bool MoveWindow(int x, int y)  {
        return getManager()->moveWindow(CWindowX11::GetWindow(), x, y);
        }

     /// Ridimensiona la finestra
     bool ResizeWindow(int W, int H) {
        return getManager()->resizeWindow(CWindowX11::GetWindow(), W, H);
        }

     bool SetWindowTitle(const char *str) {
        return getManager()->setWindowTitle(CWindowX11::GetWindow(), str);
        };
    
    bool GLWindowCreate(void);
    bool GLWindowDestroy(void);

        /// Return Texture Type
    GLuint TextureType() { return getManager()->TextureType(); }
    /// Return Max Texture Size
    unsigned int MaxTextureSize() { return getManager()->MaxTextureSize(); }

  public:
    CWindowCore_GLX(const WindowCreationParams & p) : CWindowCore_OpenGL(p),   m_interact_with_window(false) {}
    virtual ~CWindowCore_GLX();
    
    bool SetWindowShape(const unsigned char *mask, unsigned int width, unsigned int height);
    bool SetFullScreenMode(bool mode);

    // 
    bool GetScreenGeometry(ScreenGeometry * pGeometry) {
      pGeometry->width = getManager()->ScreenWidth();
      pGeometry->height = getManager()->ScreenHeight();
      return true;
    }

}; // _

  }
}

#endif
