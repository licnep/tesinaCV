/** @file CWindowCore_OpenGLMT.h 
  * @author Paolo Medici
  **/

#ifndef _CWINDOWCORE_OPENGLMT_H
#define _CWINDOWCORE_OPENGLMT_H

#include <UI/CWindows/CWindowCore_GLX.h>

namespace ui{
  namespace win{

/// Classe che implementa le funzioni di CWIndowCore_OpenGL MultiThread
class CWindowCore_OpenGLMT:  public CWindowCore_GLX, 
			      public GLXThreadManager
{
  private:
     /// expose event
    bool expose;

    /// Fonts allocati da questo contesto OpenGL
    FontManager *m_fonts;
   private:
    void *Thread(void);

    // Thread methods
    static void *XEventHandler_Thread(void *_param);

    virtual GLXThreadManager *getManager(void)
    {
      return this;
    }
        
  protected:
	bool GLGetContext(void);
	bool GLReleaseContext(void);
		
  public:
    CWindowCore_OpenGLMT(const WindowCreationParams & params);
    virtual ~CWindowCore_OpenGLMT(void);

    std::string GetConnectionString() const;

    bool GLWindowCreate(void);  
    bool GLWindowDestroy(void);
      
    bool PushCommand(const SPWindowCommand & Command); /// Metodo per inserire un CWindowCommand dentro alla coda X
      
    bool DrawText(const math::Point3d & p, const char *Text);
    bool GetTextSize(double &X, double &Y, const char *Texte);

	CWindowCore & Core(void) { return *this; }

    /// Multi Thread Event Handler
    bool XEventHandler(const XEvent & e);      

    void Quit(void);

};

  }
}

#endif
