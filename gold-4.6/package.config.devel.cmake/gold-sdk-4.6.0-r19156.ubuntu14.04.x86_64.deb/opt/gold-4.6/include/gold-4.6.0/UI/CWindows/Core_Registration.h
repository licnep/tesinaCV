/**
 * \file Core_Registration.h
 * \author Paolo Medici (medici@ce.unipr.it)
 * \brief Registration factory ad macros for CWindowCore
 */
#ifndef _CWINDOW_CORE_FACTORY_H
#define _CWINDOW_CORE_FACTORY_H

#include <UI/CWindows/CWindowCoreManager.h>
#include <Libs/Patterns/Singleton.h>
#include <Libs/Patterns/Factory.h>
#include <Libs/Patterns/RegisterObject.h>

namespace ui{
  namespace win{
    
  typedef boost::function<CWindowCoreManager*(const CreationParams &)> CWindowCoreManagerAllocatorType;
  typedef vl::Factory<std::string, CWindowCoreManager, CWindowCoreManagerAllocatorType> CWindowCoreManagerFactoryType;

  } // namespace win
} // namespace ui

#define REGISTER_WINDOWCORE(CLASS,STRNAME) vl::ObjectRegistrar< ui::win::CWindowCoreManagerFactoryType, ui::win::CLASS > drf_##CLASS(STRNAME)

#endif
