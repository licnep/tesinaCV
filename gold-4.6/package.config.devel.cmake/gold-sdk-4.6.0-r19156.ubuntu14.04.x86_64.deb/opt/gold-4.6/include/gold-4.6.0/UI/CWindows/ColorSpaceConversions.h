#ifndef _CSC_H
#define _CSC_H

// funzioni copiate da ImgLL per non fare dipendenze circolari

#include <boost/math/constants/constants.hpp>

#include <Data/CImage/PixelTraits/PixelTraits.h>
#include <Data/CImage/Pixels/RGBA8.h>
#include <Data/CImage/Pixels/RGB8.h>

#include <UI/gold_ui_export.h>

namespace ui
{
namespace win
{

/* definisco HUE_UNDEFINED, per indicare il caso in cui s=0.0f e pertanto la
	hue perde di significato */
#define HUE_UNDEFINED	(-1.0f)

/* HUE_MAX permette di modificare se si vuole il rapporto di scaling della hue */
#define HUE_MAX		((float)(2.0 * boost::math::constants::pi<float>()))

void rgb24ck_to_rgb32(unsigned char* dst, const unsigned char * src, unsigned int width, unsigned int height, unsigned char red, unsigned char green, unsigned char blue, unsigned char alpha);

struct GOLD_UI_EXPORT HSVPIXEL
{
   unsigned char v; ///< value (0..255) 
   float h; ///< hue: (0..2pi radiant)
   float s; ///< 0.0f (shade of gray) to 1.0f (pure color)
};

typedef HSVPIXEL* LPHSVPIXEL;

struct GOLD_UI_EXPORT HLSPIXEL
{
   float h; ///< hue (0..2pi radiant)
   float l; ///< brightness (0..1)
   float s; ///< saturation (0..1)
};

typedef HLSPIXEL* LPHLSPIXEL;

void GOLD_UI_EXPORT pix_rgb_to_hls(HLSPIXEL *dst,
	unsigned char r,
	unsigned char g,
	unsigned char b);

void GOLD_UI_EXPORT pix_rgb_to_hsv(HSVPIXEL *dst,
	unsigned char r,
	unsigned char g,
	unsigned char b);

template<typename S>
/**
 * @brief Internally used
 */
inline cimage::RGBA8 RGBA8HueFromMono(const S input,const float step, const  S topValue,const  S bottomValue,const unsigned char maxIntensity=255,const unsigned char minIntensity=0)
  {
  typedef typename cimage::PixelTraits<S>::FastSignedType type_t;
  const type_t value = static_cast <type_t> (input) - bottomValue;
//   const int value = static_cast <int> (input) - bottomValue;
  const unsigned char span=maxIntensity-minIntensity;
  if (value<0)
    return cimage::RGBA8(0,0,0,0);
  else if (value < step) 
    return cimage::RGBA8(maxIntensity,minIntensity+uint8_t(span*(value-(step*0))/step),minIntensity,255);
  else if (value < step*2)
    return cimage::RGBA8(maxIntensity-uint8_t(span*(value-(step*1))/step),maxIntensity,minIntensity,255);
  else if (value < step*3)
    return cimage::RGBA8(minIntensity,maxIntensity,minIntensity+uint8_t(span*(value-(step*2))/step),255);
  else if (value < step*4)
    return cimage::RGBA8(minIntensity,maxIntensity-uint8_t(span*(value-(step*3))/step),maxIntensity,255);
  else if (value < step*5)
    return cimage::RGBA8(minIntensity+uint8_t(span*(value-(step*4))/step),minIntensity,maxIntensity,255);
  else if (value <= topValue-bottomValue)
    return cimage::RGBA8(maxIntensity,minIntensity,maxIntensity-uint8_t(span*(value-(step*5))/(step +1)),255 );
    //Il +1 serve per evitare che il colore del valore massimo combaci con il colore del valore minimo
  else
    return cimage::RGBA8(255,255,255,127);
}



template<typename S>
//TODO Creare una tabella di conversione, che sarebbe pi veloce,
//anche se questa funzione non ha bisogno di essere veloce perch��solo per la visualizzazione
/**
 * @brief Da un tono mono a valori compresi tra topValue e bottomValue (interi, char, unsigned char, non importa)
          ottiene un colore RGBA8 adatto al disegno.
 * Per sfruttare la trasparenza, ricordarsi di abilitare il blending nella finestra di output.
 * I valori inferiori a bottomValue vengono settati completamente trasparenti,
 * i valori superiori a topValue vengono settati a bianco con trasparenza a 127,
 * tutti gli altri a completamente opaco.
 * @param input Valore mono sorgente
 * @param topValue Valore massimo VALIDO. I valori superiori saranno settati a bianco, con una trasparenza a 127. E' necessario un casting al tipo di dato sorgente.
 * @param bottomValue Valore minimo VALIDO. I valori inferiori saranno settati a trasparente. E' necessario un casting al tipo di dato sorgente.
 * @param maxIntensity,minIntensity Definiscono il range di profondit�di colore che verr�usato, di default il massimo
 */
inline cimage::RGBA8 RGBA8HueFromMono(const S input,const  S topValue,const  S bottomValue,const unsigned char maxIntensity=255,const unsigned char minIntensity=0)
  {
  const float step = ( (float)topValue-bottomValue)/6;  // mi aspetto sia > 0
  return RGBA8HueFromMono(input,step,topValue,bottomValue,maxIntensity,minIntensity);
  }



template<typename S>
/**
 * @brief Internally used
 */
inline cimage::RGB8 RGB8HueFromMono(const S input,const float step, const  S topValue,const  S bottomValue,const unsigned char maxIntensity=255,const unsigned char minIntensity=0)
  {
  cimage::RGBA8 temp = RGBA8HueFromMono(input,step,topValue,bottomValue,maxIntensity,minIntensity);
  return cimage::RGB8(temp.R,temp.G,temp.B);
  }
} // namespace win
} // namespace ui
#endif

