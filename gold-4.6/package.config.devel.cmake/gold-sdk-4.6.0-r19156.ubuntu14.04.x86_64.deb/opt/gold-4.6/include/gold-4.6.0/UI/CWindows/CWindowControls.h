#ifndef _CWINDOWCONTROLS_H
#define _CWINDOWCONTROLS_H

#include <boost/function.hpp>
#include <Data/CImage/Pixels/RGBA8.h>
#include <UI/CWindows/CWidget.h>
#include <UI/CWindows/CWindowFwd.h> // Forward Declaration
#include <UI/gold_ui_export.h>

namespace ui {
namespace win {

/** \brief Il bordo di un pulsante
 *   Questo widget disegna un pulsante (premuto o non premuto) ma non e' interattivo
 *    ma puo' essere usato come genitore di pulsanti interattivi.
 **/
class GOLD_UI_EXPORT CDrawingButtonShade : public CWidget
{
  public:
  CDrawingButtonShade(double _X0, double _Y0, double _X1, double _Y1, bool _pressed) :
        X0(_X0), Y0(_Y0), X1(_X1), Y1(_Y1), Pressed(_pressed) { }

    int Draw(CWindowCore *Window);

    inline bool IsInside(float x, float y) 
      { 
      return (x>X0) && (y>Y0) && (x<X1) && (y<Y1);
      }

    /// Set the button state (pressed or not)
    inline void SetState(bool _press) { Pressed = _press; }

  protected:
    double X0,Y0,X1,Y1; ///< Dimensioni
    bool Pressed;       ///< Stato
};

/** \brief Un pulsante con testo non interattivo
 *   Disegna un pulsante con sopra del testo. Non e' interattivo ma puo' essere usato
 *   come padre per altri controlli.
 **/
class GOLD_UI_EXPORT CDrawingButton : public CDrawingButtonShade
{
  public:
  CDrawingButton(double _X0, double _Y0, double _X1, double _Y1, const std::string & _text, bool _pressed) :
        CDrawingButtonShade(_X0, _Y0, _X1, _Y1, _pressed),  text(_text) { }
    
    int Draw(CWindowCore *Window);    

  protected:
    std::string text; ///< Testo
};


/**  Aggiunge un pulsante interattivo sullo schermo.
*
* Un pulsante che viene premuto e rilasciato pusha un ID
* \image html AddButton.png
* @note suggerimento: usarlo su un layer diverso da quello di disegno!
* \code
*  win->SetColor(0);
*  win->SetTextAlign(TA_CENTER_, TA_CENTER_);
*  win->AddButton(5,5,100,25, "Quit", 1);
* \endcode
*/
class CButtonWidgetId: public CDrawingButton {
  unsigned int m_id; ///< un id che verra' restituito alla finestra quando premuto il pulsante
  bool m_captured;      ///
  public:
  CButtonWidgetId(double x0, double y0, double x1, double y1, const std::string & text, unsigned int id) :
    CDrawingButton(x0,y0,x1,y1, text, false) , m_id(id), m_captured(false) {}
  
  //unsigned int ID() const;
  bool Interact(CWindowCoreManager *Window, const CWindowEvent & event);
  
  bool Export(std::ostream & out) { return false; }
};

/** Un pulsante che viene premuto e rilasciato
  *  chiama una callback
  * \code
  * myWin.SetColor(0);
  * myWin.SetTextAlign(TA_CENTER_, TA_CENTER_);
  * myWin << CButtonWidget(x0,y0,x1,y1, "Text", boost::bind(&MyClass::Callback, this) );
  * \endcode
  **/
class GOLD_UI_EXPORT CButtonWidget: public CDrawingButton {
  public:
  typedef boost::function< void () > OnPressCallback;
  public:

  CButtonWidget(double x0, double y0, double x1, double y1, const std::string & text, OnPressCallback callback) :
    CDrawingButton(x0,y0,x1,y1, text, false) , m_callback(callback), m_captured(false) {}
  
  bool Interact(CWindowCoreManager *Window, const CWindowEvent & event);

  bool Export(std::ostream & out) { return false; }  

  private:
  OnPressCallback m_callback; 
  bool m_captured;      ///
};

/** Un pulsante che viene premuto e rilasciato
  *  chiama una callback
  * \code
  * myWin.SetColor(0);
  * myWin.SetTextAlign(TA_CENTER_, TA_CENTER_);
  * myWin << CButtonWidget(x0,y0,x1,y1, "Text", boost::bind(&MyClass::Callback, this) );
  * \endcode
  **/
class GOLD_UI_EXPORT CTwoStateButtonWidget: public CDrawingButton {
  public:
  typedef boost::function< void (bool) > OnPressCallback;
  public:

  CTwoStateButtonWidget(double x0, double y0, double x1, double y1, const std::string & text, OnPressCallback callback, bool initial_state = false) :
    CDrawingButton(x0,y0,x1,y1, text, false) , m_callback(callback), m_state(initial_state) {}
  
  bool Interact(CWindowCoreManager *Window, const CWindowEvent & event);

  bool Export(std::ostream & out) { return false; }  

  private:
  OnPressCallback m_callback; 
  bool m_state;
};

/// Una rappresentazione di un menu verticale
class CMenuWidget: public CWidget {
  const char ** m_menu;
  double m_x, m_y;  ///< origine del menu
  
  bool inited;  ///< inizializzato?
  
  double m_width, m_height; ///< dimensioni del menu (le calcola automaticamente)
  double m_line_height; ///< salto tra una riga e l'altra
  unsigned int n_elements;  ///< Numero di elementi
  
  int m_selected; ///< Elemento selezionato
  
  void Init(CWindowCore *Window);
  
  bool IsInside(float x, float y) { return (x>m_x) && (y>m_y) && (x<m_x + m_width) && (y < m_y + m_height) ; }
  
  public:
  CMenuWidget(double x, double y, const char **text) : m_menu(text), m_x(x), m_y(y), inited(false), m_selected(-1) {}
  
  const char *getName() const;
  
  int Draw(CWindowCore *Window);
  bool Interact(CWindowCoreManager *Window, const CWindowEvent & event);
};

/// Tool. Disegna in una CWindowCore il bordo di un pulsante (premuto o no)
GOLD_UI_EXPORT int DrawFrame(CWindowCore *Window, double X0, double Y0, double X1, double Y1, bool Pressed);

} // namespace win
} // namespace ui

#endif
