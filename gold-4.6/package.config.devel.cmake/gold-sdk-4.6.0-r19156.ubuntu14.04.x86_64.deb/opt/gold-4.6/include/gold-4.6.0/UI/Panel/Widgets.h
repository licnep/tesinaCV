#ifndef _UI_WIDGETS_H
#define _UI_WIDGETS_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * \file Widgets.h
 * \author Paolo Medici(medici@vislab.it), Paolo Zani (zani@vislab.it)
 * \date 2010-12-22
 **/


#include <UI/gold_ui_export.h>
#include <UI/Panel/Widget.h>
#include <UI/Panel/Vars.h>

#include <boost/filesystem/path.hpp> 

#define DECLARE_WGT_CLASS( X ) static const std::string Class() { return #X; }

namespace ui
{
    namespace wgt
    {
        struct GOLD_UI_EXPORT Button: public Widget
        {
            DECLARE_WGT_CLASS(button)
            
            Button() : Widget() {}
            
            Button(const ui::var::Popup& guid, const std::string& label, bool enabled = true) : Widget(Class(), nullguid) { Label(label); Ref(guid); Enable(enabled); HExpand(0); VExpand(0); }

            Button(ui::var::Callback guid, const std::string& label, bool enabled = true) : Widget(Class(), guid) { Label(label); Enable(enabled); HExpand(0); VExpand(0); }
        };

        struct Style
        {
            enum Id
            {
                Ok = 0,
                Yes,
                Apply,
                Help,
                No,
                Cancel,
                Close
            };
        };
        
        template<enum Style::Id ID>
        // class GOLD_UI_EXPORT SystemButton: public Widget // patch dllimportexport
		class SystemButton: public Widget
        {
            public:

                static const std::string Class() { return "button_" + str(ID); }

                SystemButton(const ui::var::Popup& guid, bool enabled = true) : Widget(Class(), nullguid) { Ref(guid); Enable(enabled); HExpand(0); VExpand(0); }

                SystemButton(ui::var::Callback guid, bool enabled = true) : Widget(Class(), guid) { Enable(enabled); HExpand(0); VExpand(0); }
        
                SystemButton(bool enabled = true) : Widget(Class(), nullguid) { Enable(enabled); HExpand(0); VExpand(0); }
    
            private:

                inline static std::string str(int32_t type)
                {
                    switch(type) {
                        case Style::Ok:
                            return "ok";
                        case Style::Yes:
                            return "yes";
                        case Style::Apply:
                            return "apply";
                        case Style::Help:
                            return "help";
                        case Style::No:
                            return "no";
                        case Style::Cancel:
                            return "cancel";
                        case Style::Close:
                            return "close";
                    }
                    
                    return "";
                }
        };
        
        typedef SystemButton<Style::Ok> SystemButton_Ok;

        typedef SystemButton<Style::Yes> SystemButton_Yes;

        typedef SystemButton<Style::Apply> SystemButton_Apply;

        typedef SystemButton<Style::Help> SystemButton_Help;

        typedef SystemButton<Style::No> SystemButton_No;

        typedef SystemButton<Style::Cancel> SystemButton_Cancel;

        typedef SystemButton<Style::Close> SystemButton_Close;

        struct GOLD_UI_EXPORT BitmapButton: public Widget
        {
            DECLARE_WGT_CLASS(bitmapbutton)
            
            BitmapButton() : Widget() {}
            
            BitmapButton(const ui::var::Popup& guid, const boost::filesystem::path& path, const std::string& label = "", bool enabled = true) :
                Widget(Class(), nullguid)
            {
                Bitmap(path);
                Label(label);
                Ref(guid);
                Enable(enabled);
                HExpand(0);
                VExpand(0);
            }

            BitmapButton(ui::var::Callback guid, const boost::filesystem::path& path, const std::string& label = "", bool enabled = true) :
                Widget(Class(), guid)
            {
                Bitmap(path);
                Label(label);
                Enable(enabled);
                HExpand(0);
                VExpand(0);
            }
            
            inline BitmapButton& Bitmap(const boost::filesystem::path& path) { Attr("bitmap", path.string()); return *this; }
            
            inline boost::filesystem::path Bitmap(void) const { return boost::filesystem::path(Attr("bitmap")); }
        };


        struct GOLD_UI_EXPORT Toggle : public Widget { DECLARE_WGT_CLASS(toggle) Toggle() : Widget() {} Toggle(detail::widget_guid_t guid, const std::string& label = "", bool enabled = true) : Widget(Class(), guid) { Label(label); Enable(enabled); HExpand(0); VExpand(0); } };

        struct GOLD_UI_EXPORT BitmapToggle : public Widget
        {
            DECLARE_WGT_CLASS(bitmaptoggle)
            
            BitmapToggle() : Widget() {}
            
            BitmapToggle(detail::widget_guid_t guid, const boost::filesystem::path& path, const std::string& label = "", bool enabled = true) :
                Widget(Class(), guid)
            {
                Bitmap(path);
                Label(label);
                Enable(enabled);
                HExpand(0);
                VExpand(0);
            }
            
            inline BitmapToggle& Bitmap(const boost::filesystem::path& path) { Attr("bitmap", path.string()); return *this; }
            
            inline boost::filesystem::path Bitmap(void) const { return boost::filesystem::path(Attr("bitmap")); }
        };

        struct GOLD_UI_EXPORT CheckBox : public Widget { DECLARE_WGT_CLASS(checkbox) CheckBox() : Widget() {} CheckBox(detail::widget_guid_t guid, const std::string& label = "", bool enabled = true) : Widget(Class(), guid) { Label(label); Enable(enabled); HExpand(0); VExpand(0); } };

        
        struct GOLD_UI_EXPORT Slider : public Widget { DECLARE_WGT_CLASS(slider) Slider() : Widget() {} Slider(detail::widget_guid_t guid, const std::string& label = "", bool enabled = true) : Widget(Class(), guid)  { Label(label); Enable(enabled); HExpand(1); VExpand(0); } };

        struct GOLD_UI_EXPORT Spin : public Widget { DECLARE_WGT_CLASS(spin) Spin() : Widget() {} Spin(detail::widget_guid_t guid, const std::string& label = "", bool enabled = true) : Widget(Class(), guid) { Label(label); Enable(enabled); HExpand(0); VExpand(0); } };

        struct GOLD_UI_EXPORT Gauge : public Widget { DECLARE_WGT_CLASS(gauge) Gauge() : Widget() {} Gauge(detail::widget_guid_t guid, const std::string& label = "", bool enabled = true) : Widget(Class(), guid) { Label(label); Enable(enabled); HExpand(0); VExpand(0); } };


        struct GOLD_UI_EXPORT ComboBox : public Widget { DECLARE_WGT_CLASS(combobox) ComboBox() : Widget() {} ComboBox(detail::widget_guid_t guid, const std::string& label = "", bool enabled = true) : Widget(Class(), guid) { Label(label); Enable(enabled); HExpand(0); VExpand(0); } };

        struct GOLD_UI_EXPORT RadioBox : public Widget { DECLARE_WGT_CLASS(radiobox) RadioBox() : Widget() {} RadioBox(detail::widget_guid_t guid, const std::string& label = "", bool enabled = true) : Widget(Class(), guid) { Label(label); Enable(enabled); HExpand(0); VExpand(0); } };

        struct GOLD_UI_EXPORT ListBox : public Widget { DECLARE_WGT_CLASS(listbox) ListBox() : Widget() {} ListBox(detail::widget_guid_t guid, const std::string& label = "", bool enabled = true) : Widget(Class(), guid) { Label(label); Enable(enabled); HExpand(0); VExpand(0); } };

        struct GOLD_UI_EXPORT Tree : public Widget { DECLARE_WGT_CLASS(tree) Tree() : Widget() {} Tree(detail::widget_guid_t guid, const std::string& label = "", bool enabled = true) : Widget(Class(), guid) { Label(label); Enable(enabled); HExpand(0); VExpand(0); } };
        
        struct GOLD_UI_EXPORT TextBox : public Widget
        {
            DECLARE_WGT_CLASS(textbox)

            TextBox() : Widget() {}

            TextBox(detail::widget_guid_t guid, const std::string& label = std::string(), bool enabled = true) : Widget(Class(), guid) { Label(label); Enable(enabled); HExpand(1); VExpand(0); }
            
            inline TextBox& Multiline(bool multiline = true) { Attr("multiline", multiline); return *this; }
            
            inline bool Multiline(void) const { return vl::numeric_cast<bool>(Attr("multiline")); }
        };

        struct GOLD_UI_EXPORT Text : public Widget { DECLARE_WGT_CLASS(text) Text() : Widget() {} Text(const std::string& label, bool enabled = true) : Widget(Class(), nullguid) { Label(label); Enable(enabled); HExpand(1); VExpand(0); } };
        
        struct GOLD_UI_EXPORT Video : public Widget { DECLARE_WGT_CLASS(video) Video() : Widget() {} Video(const std::string& url, bool enabled = true) : Widget(Class(), nullguid) { Attr("href", url); Enable(enabled); HExpand(1); VExpand(0); } };


        struct GOLD_UI_EXPORT Frame: public Widget
        {
            DECLARE_WGT_CLASS(frame)
            
            Frame(const std::string& title = "", bool visible = false, bool resizable = true) : Widget(Class(), nullguid) { Visible(visible); Resizable(resizable); }

            inline Frame& Resizable(bool resizable = true) { Attr("resizable", resizable); return *this; }

            inline bool Resizable(void) const { return vl::numeric_cast<bool>(Attr("resizable")); }
        };

        struct GOLD_UI_EXPORT Dialog: public Widget { DECLARE_WGT_CLASS(dialog) Dialog(const std::string& title = "", bool visible = false, bool modal = true) : Widget(Class(), nullguid) { Label(title); Visible(visible); Attr("modal", vl::string_cast(modal)); } };


        struct GOLD_UI_EXPORT Panel: public Widget { DECLARE_WGT_CLASS(panel) Panel(const std::string& title = "", bool visible = false) : Widget(Class(), nullguid) { Label(title); Visible(visible); } };

        struct GOLD_UI_EXPORT NoteBook: public Widget { DECLARE_WGT_CLASS(notebook) NoteBook() : Widget(Class(), nullguid) { HExpand(1); VExpand(1); } };

        struct GOLD_UI_EXPORT TreeBook: public Widget { DECLARE_WGT_CLASS(treebook) TreeBook() : Widget(Class(), nullguid){} TreeBook(detail::widget_guid_t guid) : Widget("treebook", guid) { HExpand(1); VExpand(1); } };

        struct GOLD_UI_EXPORT Page: public Widget { DECLARE_WGT_CLASS(page) Page(const std::string& title = "") : Widget(Class(), nullguid) { Label(title); } };


        struct GOLD_UI_EXPORT PropertyGrid: public Widget { DECLARE_WGT_CLASS(propertygrid) PropertyGrid() : Widget(Class(), nullguid) { HExpand(1); VExpand(1); } };
        
        struct GOLD_UI_EXPORT PropertyCategory: public Widget { DECLARE_WGT_CLASS(propertycategory) PropertyCategory() : Widget(Class(), nullguid) {} };
        
        struct GOLD_UI_EXPORT PropertyGroup: public Widget { DECLARE_WGT_CLASS(propertygroup) PropertyGroup() : Widget(Class(), nullguid) {} };


        struct GOLD_UI_EXPORT Scroll: public Widget { DECLARE_WGT_CLASS(scroll) Scroll() : Widget(Class(), nullguid) { HExpand(1); VExpand(1); } };
        
        struct GOLD_UI_EXPORT Splitter: public Widget { DECLARE_WGT_CLASS(splitter) Splitter() : Widget(Class(), nullguid) { HExpand(1); VExpand(1); } };


        struct GOLD_UI_EXPORT Menubar: public Widget { DECLARE_WGT_CLASS(menubar) Menubar() : Widget(Class(), nullguid) {} };
        
        struct GOLD_UI_EXPORT Menu: public Widget { DECLARE_WGT_CLASS(menu) Menu() : Widget() {} Menu(const std::string& label, bool enabled = true) : Widget(Class(), nullguid) { Label(label); Enable(enabled); } };

        struct GOLD_UI_EXPORT MenuItem: public Widget
        {
            DECLARE_WGT_CLASS(menuitem)
            
            MenuItem() : Widget() {}
            
            MenuItem(ui::var::Popup guid, const std::string& label, bool enabled = true) : Widget(Class(), guid) { Ref(guid); Label(label); Enable(enabled); HExpand(0); VExpand(0); }

            MenuItem(ui::var::Callback guid, const std::string& label, bool enabled = true) : Widget(Class(), guid) { Label(label); Enable(enabled); HExpand(0); VExpand(0); }
        };

        struct GOLD_UI_EXPORT MenuItem_Radio: public Widget { DECLARE_WGT_CLASS(menuitem_radio) MenuItem_Radio(detail::widget_guid_t guid, const std::string& label, bool enabled = true) : Widget(Class(), guid) { Label(label); Enable(enabled); HExpand(0); VExpand(0); } };

        struct GOLD_UI_EXPORT MenuItem_Check: public Widget { DECLARE_WGT_CLASS(menuitem_check) MenuItem_Check(detail::widget_guid_t guid, const std::string& label, bool enabled = true) : Widget(Class(), guid) { Label(label); Enable(enabled); HExpand(0); VExpand(0); } };

        struct GOLD_UI_EXPORT MenuItem_Separator: public Widget { DECLARE_WGT_CLASS(menuitem_separator) MenuItem_Separator() : Widget(Class(), nullguid) { HExpand(0); VExpand(0); } };


        struct GOLD_UI_EXPORT Spacer: public Widget { DECLARE_WGT_CLASS(spacer) Spacer(int size, bool stretch = false) : Widget(Class(), nullguid) { Attr("size", vl::string_cast(size)); Attr("stretch", vl::string_cast(stretch)); } };

        struct GOLD_UI_EXPORT SzCell: public Widget
        {
            DECLARE_WGT_CLASS(szcell)

            SzCell() : Widget() {}
            
            SzCell(unsigned int row, unsigned int col, unsigned int row_span = 1, unsigned int col_span = 1) : Widget(Class(), nullguid)
            {
                Attr("row", row);
                Attr("column", col);
                Attr("row_span", row_span);
                Attr("column_span", col_span);
                HExpand(0);
                VExpand(0);
            }
        };

        struct GOLD_UI_EXPORT VSizer: public Widget { DECLARE_WGT_CLASS(vsizer) VSizer() : Widget(Class(), nullguid) { HExpand(1); VExpand(1); } };

        struct GOLD_UI_EXPORT HSizer: public Widget { DECLARE_WGT_CLASS(hsizer) HSizer() : Widget(Class(), nullguid) { HExpand(1); VExpand(1); } };

        struct GOLD_UI_EXPORT GridSizer : public Widget
        {
            DECLARE_WGT_CLASS(gridsizer)
            
            GridSizer(unsigned int hgap = 0, unsigned int vgap = 0) : Widget(Class(), nullguid) { Attr("hgap", hgap); Attr("vgap", vgap); HExpand(1); VExpand(1); }
            
            inline GridSizer& Add(const Widget& guid, unsigned int row, unsigned int col, int row_expand = 0, int col_expand = 0, unsigned int row_span = 1, unsigned int col_span = 1)
            {
                Widget::Add(SzCell(row, col, row_span, col_span).VExpand(row_expand).HExpand(col_expand).Add(guid));
                return *this;
            }
        };

        struct GOLD_UI_EXPORT HBoxSizer : public Widget { DECLARE_WGT_CLASS(hboxsizer) HBoxSizer(const std::string& label = "") : Widget(Class(), nullguid) { Label(label); HExpand(1); VExpand(1); } };

        struct GOLD_UI_EXPORT VBoxSizer : public Widget { DECLARE_WGT_CLASS(vboxsizer) VBoxSizer(const std::string& label = "") : Widget(Class(), nullguid) { Label(label); HExpand(1); VExpand(1); } };


        struct GOLD_UI_EXPORT Log: public Widget { DECLARE_WGT_CLASS(log) Log() : Widget() {} Log(detail::widget_guid_t guid, const std::string& label = "", bool enabled = true) : Widget(Class(), guid) { Label(label); Enable(enabled); HExpand(0); VExpand(0); } };
    };
};

#undef DECLARE_CLASS

#endif
