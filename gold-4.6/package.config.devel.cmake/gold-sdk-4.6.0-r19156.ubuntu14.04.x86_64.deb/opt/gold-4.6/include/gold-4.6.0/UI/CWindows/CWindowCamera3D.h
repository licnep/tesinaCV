#ifndef _CWINDOW_CAMERA3D_H
#define _CWINDOW_CAMERA3D_H

#include <vector>

#include <boost/math/constants/constants.hpp>

#include <Data/Math/Rects.h>
#include <Data/Math/TMatrices.h>

#include <Data/Base/CCameraParams.h>

#include <UI/CWindows/CWindowTypes.h>
#include <UI/CWindows/CWindowFwd.h> // Forward Declaration
#include <UI/CWindows/CWindowCamera.h>
#include <UI/gold_ui_export.h>


namespace ui {
namespace win {

/** A free 3D Camera.
  *  Example to set a camera using Camera Parameters
  *
  * \code
  * win->SetCamera( boost::shared_ptr\<ui::win::CCamera3D\>(new ui::win::CCamera3D(0.569313 , 0.309703, 0.0, 0.0, 5.4675, 0.665, 0.0, -6.65127 , -11.777, 8.83153) ) );
  * \endcode
  * @see CWindowCamera3D::CWindowCamera3D
  **/
class GOLD_UI_EXPORT CCamera3D: 
  public CCamera
  {
  public:
    /// parametri camera salvati
    struct Parameters {
        double ku;
        double ratio;
        double u0, v0;
        double yaw, pitch, roll; //
        double x0, y0, z0;       // pin
    };
    
  private:
    

/// Punti di vista salvati
    std::vector<Parameters> m_camera_set;

/// Parametri correnti
//         double tan_hfov, tan_vfov;
    double ku, kv;
    Parameters m_camera;
/// Movimento
    int m_state;
/// Tipo di navigazione
    int m_navigation_mode;

/// GUI abilitata
    bool m_gui;
/// flag utilizzata quando si vogliono fare filmati con la camera in movimento.
///  il refresh viene eseguito solamente quando viene un vero refresh piuttosto che ad ogni movimento
    bool m_refresh;

    math::Point3f m_prev_world;
    math::Point3f m_prev_camera;
    math::Point2f m_prev;

    /// last Matrix
    ViewPortMatrix m_matrix;

    /** velocita' */
    float m_base_speed;

    /** locked point */
    math::Point3d m_look_at;

private:
    /// Imposta la camera @a camera_no e poi la mette come viewport corrente
    // void SetTanCamera(int camera_no, double tan_hfov, double tan_vfov, double u0, double v0, double yaw, double pitch, double roll, double x0, double y0, double z0);

    void SetKCamera(int camera_no, double ku, double kv, double u0, double v0, double yaw, double pitch, double roll, double x0, double y0, double z0);

    /// mette il viewport alla camera @a camera_no
    void GoToCamera(int camera_no);

    /// da @a param ottiene la matrice di vista @a M
    void KCameraMatrix(ViewPortMatrix& M, const Parameters& param);

public:

    CCamera3D();

    /** Projection view using GOLD camera params
      *  @param hfov,vfov               half field of view (alpha,beta)
          *  @param u0,v0               principal point in 0..1 units (cx/width-0.5, cy/height-0.5)
          *  @param yaw,pitch,roll      rotation angles (rad)
      *  @param x0,y0,z0                pin-hole coordiantes (m)
          **/
    CCamera3D(double hfov, double vfov, double u0, double v0, double yaw, double pitch, double roll, double x0, double y0, double z0);

    /// Costructor from CameraParams
    CCamera3D(const dev::CameraParams& camera);

    /** BirdEyeView using a cartesian or GOLD reference frame (X UP, Y LEFT)
      * @param x0 MIN X coordinate
          * @param y0 MIN Y coordinate
          * @param x1 MAX X coordinate
          * @param y1 MAX Y coordinate
          * @param angle using -PI/2 enable a Cartesian reference (X LEFT, Y UP) instead of Gold Reference (X LEFT, Y UP)
          * @param z initial Z height
          *
      * @note z=50m~ininfluente
      *
      * \code
          * \\ examples of a GOLD 40mx40m area
          * boost::shared_ptr<ui::win::CCamera3D> camera(new ui::win::CCamera3D( -20.0, -20.0, 20.0, 20.0 ) );
          * \\ examples of a 2km x 2km Cartesian Area
          * boost::shared_ptr<ui::win::CCamera3D> camera(new ui::win::CCamera3D( -1000.0, -1000.0, 1000.0, 1000.0, -M_PI/2.0 ) );
      * \endcode
          **/
    CCamera3D(double x0, double y0, double x1, double y1, double angle = 0.0, double z = 50.0 );

    // dtor
    virtual ~CCamera3D();
    
    
    /// Change the X position
    void X(double x);
    /// Change the Y position
    void Y(double y);
    /// Change the Z position
    void Z(double z);


    /// Change the Yaw Angle
    void Yaw(double yaw);
    /// Change the Pitch Angle
    void Pitch(double pitch);
    /// Change the Roll Angle
    void Roll(double roll);

    void SetSpeed(float speed) {
        m_base_speed = speed;
    }
    
    void SetPixelFocalLenght( double ku, double ratio);

    /// Reset the camera to the Default
    // void Reset();

    ///
    math::Point3f NormalizedToCamera(const math::Point2f& p) const;
    ///
    math::Point3f CameraToWorld(const math::Point3f& p) const;
    
    /** change the navigation mode
     *  0: press and move
     *  1: rotate
     *  2: lookat
     */
    void SetNavigationMode(int mode) {
        m_navigation_mode = mode;
    }
    
    void Move_WC_Rel(const math::Point3d& dir);
    void Rotate_WC_Rel(const math::Point3d& dir);

    /// Muove la camera di [x, y, z] dove z è l'asse ottico della camera
    typedef enum{PM_X=1, PM_Y=2, PM_Z=4} PositionMaskType;
    void Move_CC_Rel(const math::Point3d& dir, int mask=PM_X|PM_Y|PM_Z);
    
    /// Ruota la camera di [yaw, pitch, roll] [rad] attorno all'asse ottico della camera
    typedef enum{AM_YAW=1, AM_PITCH=2, AM_ROLL=4} AnglesMaskType;
    void Rotate_CC_Rel(const math::Point3d& dir, int mask=AM_YAW|AM_PITCH|AM_ROLL);
    
    
    /// fa avanzare la camera lungo la direzione z della camera (avanti in coordinate camera)
    void FWD(double ammount);

    /// Lock angle in order to look always to this point. m_navigation_mode is set to 2
    void LookAt(const math::Point3d& p);

    /** Imposta i parametri della camera
      * @param camera_no Identificativo della camera da impostare. 0 e' la camera corrente. Da 1 in poi sono camere speciali a cui passare con un tasto
      * @param hfov,vfov Field of view
      * @param u0,v0     optical center offset (per ora in coordinate opengl)
      * @param yaw,pitch,roll angles
      * @param x0,y0,z0  pin-hole location
      **/
    void SetCamera(int camera_no, double hfov, double vfov, double u0, double v0, double yaw, double pitch, double roll, double x0, double y0, double z0);

    /** Imposta i parametri della camera di default
      * @param hfov,vfov Field of view
      * @param u0,v0     optical center offset (per ora in coordinate opengl)
      * @param yaw,pitch,roll angles
      * @param x0,y0,z0  pin-hole location
      **/
    void SetCamera(double hfov, double vfov, double u0, double v0, double yaw, double pitch, double roll, double x0, double y0, double z0)  {
        SetCamera(0, hfov, vfov, u0, v0, yaw, pitch, roll, x0, y0, z0);
    };
    
    /** Imposta i parametri della camera di default */
    void SetCamera(const CCamera3D::Parameters& params, int num_cam=0);

    /** Imposta i parametri della camera di default */
    void SetCamera(const dev::CameraParams& camera);
    
    const Parameters& Params() const;

    virtual void GetRestInverseUVWMatrix(CWindowCore *core, InverseViewPortMatrix& M);

    /// return current view matrix
    virtual void GetMatrix(CWindowCore *core, ViewPortMatrix& M);

    /// should modify internal structure in order to set logical coordinate
    virtual bool Interact(CWindowCoreManager *core, const CWindowEvent& Event);

    /// Eventually it should draw a HUD
    virtual int Draw(CWindowCore *core);
};

typedef CCamera3D CWindowCamera3D;

} // namespace win
} // namespace ui

#endif // _CWINDOW_CAMERA3D_H
