#ifndef _DEBUGWIDGETS_H
#define _DEBUGWIDGETS_H

#include <UI/CWindows/CWindowTypes.h>
#include <UI/CWindows/CWindowCore.h>
#include <UI/CWindows/CWindowCoreManager.h>
#include <UI/CWindows/CWidget.h>
#include <UI/gold_ui_export.h>

namespace ui {
  namespace win {

/** il KeyboardEventWidget chiama una callback utente ogni qual volta viene premuto un tasto su una finestra.
  *  La callback riceve il tasto e deve ritornare true se il tasto e' stato processato e non vuole che venga
  *   passato ad altri widget o al controllo stesso della finestra.
  * \code
  *
  * bool MyClass::OnKeyPress(int key)
  *  {
  *  // do something using key
  *  }
  *  ...
  *  m_win << KeyboardEventWidget( boost::bind(&MyClass::OnKeyPress, this, _1) );
  * \endcode
  */
class GOLD_UI_EXPORT KeyboardEventWidget : public CWidget {
	typedef boost::function<bool (int)> OnKeyboardPress;

	OnKeyboardPress m_func;
	public:
	KeyboardEventWidget( OnKeyboardPress func) : m_func(func) { }
	virtual ~KeyboardEventWidget();
        const char* getName() const;
	bool Interact(CWindowCoreManager* pWindow, const CWindowEvent& event);
	int Draw(CWindowCore* pWindow);
};

/** Callback quando il mouse esegue un evento tra quelli sotto indicati */
class GOLD_UI_EXPORT MouseEventWidget : public CWidget {
	typedef boost::function<bool (float, float)> OnMouseEvent;
	OnMouseEvent m_func;
	unsigned int m_mask;
	public:
        /// Seleziona la callback che viene chiamata a ogni evento, selezionato dalla @a event_mask
	/// @param event_mask vale una combinazione OR di WEF_MOUSE_MOTION | WEF_BUTTON_DOWN | WEF_BUTTON_UP
	MouseEventWidget( OnMouseEvent func, unsigned int event_mask) : m_func(func), m_mask(event_mask) { }
	virtual ~MouseEventWidget() { }
        const char* getName() const { return "MouseEventWidget"; }
	bool Interact(CWindowCoreManager *w, const CWindowEvent& event)
	{
	  if((event.event & m_mask) != 0)
	  {
	    return m_func(event.pos.x, event.pos.y);
	  }
	  else
	    return false;
	}

	int Draw(CWindowCore* pWindow)
	{
	  return 0;
	}
};

  }
}


#endif
