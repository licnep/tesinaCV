/**
 * \file CWindowCoreManager.h
 * \brief Server Side CWindow
 * \author Paolo Medici (medici@ce.unipr.it)
 * \date 7-7-2004 (v1) 26-10-2006 (v2)
 */

#ifndef _CWINDOWCOREMANAGER_H
#define _CWINDOWCOREMANAGER_H

#include <vector>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <boost/thread/mutex.hpp>
#include <boost/thread/condition.hpp>

#include <UI/CWindows/CWindowLayer.h>
#include <UI/CWindows/CWindowCommand.h>
#include <UI/CWindows/CWindowTypes.h>
#include <UI/CWindows/CWindowCore.h>
#include <UI/CWindows/CWindowFwd.h> // Forward Declaration


namespace cimage{class CImage;}

/// Callback chiamata dopo il disegno per elaborazioni client-side (es. salvataggi, streaming, etc)
#ifdef USE_BOOST_SIGNAL2
typedef boost::signals2::signal<void (const cimage::CImage &)> GrabCImageSignalType;
#else
	typedef boost::signal<void (const cimage::CImage &)> GrabCImageSignalType;
#endif

typedef GrabCImageSignalType::slot_type OnGrabCImageType;

namespace vl{ namespace ini {class INIFile;} } using vl::ini::INIFile;


namespace ui{
  namespace win{

/// Callback chiamata appena prima di disturggere la window per permettere il salvataggio dello stato su disco
typedef boost::function<void ( CWindowCoreManager *core  ) > OnCWindowDestroyType;

/** CWindowCoreManager e' la classe che si occupa di dialogare tra la CWindow
 *   e il dispositivo di rendering CWindowCore
 *  
 * L'utente deve usare CWindow, mentre CWindowCoreManager e' un'interfaccia a piu basso livello all'hardware 
 * @note le funzioni Set sono virtuali, le funzioni Get no
 **/
class GOLD_UI_EXPORT CWindowCoreManager : public CWindowCore
{
  public:
    /// oggetto plugin: una coppia di widget e stato (abilitato/disabilitato)
    /// copiable swappable
    struct Plugin {
      bool enabled;
      SPDrawingObject widget;
    };
    
    /// Lista di Widget per i Plugin
    typedef std::vector<Plugin> PluginList_t;

  protected:

    /// Interagisce con gli oggetti
    bool InteractWithChild(CWindowEvent & event);
    
    /// Interagisce con i plugins
    bool InteractWithPlugins(const CWindowEvent & event);

    /// Esegue interazione tra evento e oggetti vari
    /// Interact before with PLUGINS and after with LAYERS (Cameras and Widgets)
    /// @return true se qualcuno ha preso l'evento, altrimenti false
    bool Interact(CWindowEvent & event);

    /// Verifica se tra gli oggetti e i plugin c'e' iterazione, altrimenti mette l'evento in coda 
    void InteractOrPush(CWindowEvent & event);

    /** copia tutti gli eventi dalla coda locale alla coda fornita dall'utente
     * @param mylist un buffer che la CWindow passa a cui veranno appessi gli eventi
     * @note GetEvent non esegue nessuna forma di Lock, ma dopotutto e' una funzione protetta non visibile dal Client
     **/
    void GetEvents(CWindowEventList &mylist);
    
    /// Execute before all Drawing Command
    void OnPre();
    
    /// Execute at the End of Drawing Command
    void OnPost();
    
    /** execute the drawing operations */
    int Draw();
    
  public:
    CWindowCoreManager(const WindowCreationParams & param);
    virtual ~CWindowCoreManager();

    /// ritorna una stringa per identificare univocamente la finestra, anche tra macchine diverse
    /// @note metodo molto provvisorio
    virtual std::string GetConnectionString() const = 0;
    
    /// Imposta il titolo della finestra
    virtual bool SetTitle(const std::string & Title);
    
    /// Imposta la posizione della finestra sullo schermo
    virtual bool SetPosition(int X, int Y);

    /// Imposta la dimensione della finestra
    virtual bool SetSize(int W,  int H);

    /// Imposta il colore di background della CWindow
    /// @note non tutti i device lo supportano
    virtual bool SetBackgroundColor(cimage::RGBA8 color) { return false; }

    /// Permette di impostare un messaggio che compare nella Custom Status Bar
    virtual bool SetCustomStatusBar(const std::string & text);

    /// Imposta la window di rendering
    virtual bool SetWindowShape(const unsigned char *mask, unsigned int width, unsigned int height);

    virtual bool SetFullScreenMode(bool FullScreen)  {
        SetFlag<CWF_FULLSCREEN>(FullScreen);
        return true;
        }
    
    virtual bool SetVisibility(bool Visibility) {
        SetFlag<CWF_VISIBLE>(Visibility);
        return true;
        }

    virtual bool SetDecoration(bool Decoration) {
        SetFlag<CWF_NODECORATION>(!Decoration);
        return true;
        }

    //
    /// Richiede la dimensione fisica dello schermo
    virtual bool GetScreenGeometry(ScreenGeometry * pGeometry) { 
      pGeometry->width = 0;
      pGeometry->height = 0;
      pGeometry->depth = 0;
      return false; 
    }
    //

    /// a seconda dello stato di CWF_KEY_HANDLE
    /// TRUE se CWF_KEY_HANDLE != ctrl altrimenti FALSE
    inline bool Redirect(bool ctrl) const    {
        return IsFlagSet(CWF_KEY_HANDLE) != ctrl;
        }

    bool LockAspectRatio(bool Lar)
    {
    SetFlag<CWF_STRETCH>(!Lar);
    return true;
    }

    virtual void EnableKeyboardHandle(bool key)
    {
    SetFlag<CWF_KEY_HANDLE>(key);
    }

    /// Restituisce se la finestra e' ridotta ad icona
    inline bool IsIconic(void) const { return m_isIconic; }
    
    /// Forza un refresh software
    virtual bool Refresh(bool force=false);

    /// Esegue un comando di refresh. 
    /// Aggiorna la coda di disegno locale, aggiorna le statistiche e chiama la Refresh().
    bool Replace(const CDrawerList & queue);

    /// mette un SPWindowCommand nella coda dei comandi da processare dal Server
    virtual bool PushCommand(const SPWindowCommand & Command);

    /// [SERVER] Comando per forzare l'uscita dal loop del thread, ove implementato
    virtual void Quit(void);
    
    /** GetPixel Color */
    virtual bool GetPixel(cimage::RGBA8 *color, int x, int y);
    
    /// Notifica che il nuovo buffer e' pronto da essere post-processato
    /// @param soft indica se la richiesta del draw e' stata software o hardware
    void NotifyBufferReady(bool soft);
    
    /// Save a cimage @a src on disk @a filename using local variabile to inizialize @a filename
    /// @param _Image normally a cimage::CImageRGB8
    template<class _Image>
    bool SaveImageOnDisk(const _Image & src, const std::string & filename = std::string());
    
    /// Salva uno screenshoot della finestra su disco    
    bool DumpImage(const std::string & filename = std::string());
    
    /// Esporta in vettoriale
    bool Export(std::string filename = std::string());   
    
    ///////////////////// Event //////////////////////
    void SetEventMask(unsigned int _EventMask);
    
    /// Aspetta che un evento sia messo nella coda (bloccante)
    bool WaitForEvent(CWindowEventList &mylist);
    
    /// copia tutti gli eventi dalla coda (ma non si blocca se non ci sono eventi)
    bool FlushEvent(CWindowEventList &mylist);
    
    /// mette un evento nella coda degli eventi e risveglia eventuali client in pausa
    void PushEvent(const CWindowEvent &newevent);

    /// Emette un Object Event
    void PushObjectEvent(unsigned int id);
    
    /// Salva la posizione della finestra nel file windows.ini
    bool SaveStatusOnDisk(void);
    
    /// carica la posizione della finestra nel file windows.ini. Restituisce true se la riga esiste
    bool LoadStatusFromDisk(int &sX, int &sY, unsigned int &sW, unsigned int &sH);
    
    /// Applica lo stato alla finestra
    bool ApplyStatus(int &sX, int &sY, unsigned int &sW, unsigned int &sH);
    
    /// carica la posizione e la imposta (la finestra deve essere tuttavia stata creata)
    bool LoadAndApplyStatusFromDisk();
    
    /** Direct accces to inner widget list */
    CDrawerList & GetDrawerList() { return m_drawer; } 

    /** @name Plugin SubSystem 
     * @todo spostare tutta questa parte in un oggetto comune che viene visto da tutti i CWindowCore (es PluginLayer)
     *       Attenzione che attualmente non c'e' nessuna interazione tra CWindow e CWindowCore, e questa sarebbe la prima.
     */
    /*@{*/

    /** Enable/Disable a plugin. If it not exists, will be created */
    bool EnablePlugin(const std::string & plugin_name, bool status);
    
    /** Cerca un plugin gia' istanziato e se esiste ne cambia lo stato, altrimenti ritorna false 
     * @note unusefull
     */
    bool SwitchPlugin(const std::string & plugin_name);
    
    /** cerca un plugin e se non e' istanziato lo istanzia, prima di cambiarne lo stato 
     */
    CWidget *SwitchPluginEx(const std::string &  plugin_name);
    
    /** cambia tutte le istanze! @note non ha piu' molto senso ora **/
    bool SwitchAllPlugin(void);

    /** cerca un plugin. if it not exist return 0 **/
    Plugin * FindPlugin(const std::string & pluginame);
    /** search for a plugin and if it not exist, create it */
    Plugin * FindPluginEx(const std::string & pluginame);
    
    /** aggiunge un plugin al Core, usando la factory **/
    Plugin *InsertPlugin(const std::string & pluginame);
    /** aggiunge un plugin al Core, passato dall'utente **/
    Plugin * InsertPlugin(SPDrawingObject widget, bool state = true);

    /** Load ALL AVAILABLE plugins.
     *  Istanzia TUTTI i plugin registrati attraverso la REGISTER_WIDGET
     */
    bool PopulatePlugin();
    
    /** rilascia tutti i plugin allocati e ne libera la memoria */
    void ReleasePlugins(void);
    /*@}*/
    
    /** Set the widget who capture ALL events */
    void CaptureEvent(CWidget *wgt) { m_captureEventWidget = wgt; }
    /** Release Capture */
    void ReleaseCapture() { m_captureEventWidget = 0; }

    /** Registra una callback che viene chiamata a ogni nuovo frame renderizzato **/
    void RegisterExposeCallback(OnGrabCImageType slot);
    /** Registra una callabck chiamata quando la CWindow viene distrutta **/
    void RegisterOnDestroyCallback(OnCWindowDestroyType slot);


  public:
    
  static INIFile * m_ini; ///< windows.ini    
  static std::string g_outputPath;   /// 
  static std::string g_resourcePath; ///

  /// drivers list, used to create this cwindow
  std::string m_drvName;

  protected:

    /// The Widget who capture all events
    CWidget *m_captureEventWidget;
    
    /// Window is Iconic? (true=iconic, false=normal state)
    bool m_isIconic;          	

    /// Old Window State prior to FullScreen
    int wSX, wSY, wSW, wSH; 

    /// formato file per il dump
    std::string output_file_format;	

    /// elenco di eventi che vengono analizzati    
    unsigned int m_eventMask;

///////////////////////////////////////////////////////////////////

    /// lista di plugin da associare alla finestra.
    PluginList_t m_plugins;
    
    /// Drawing List
    CDrawerList m_drawer;

    /// list of feeders on this Window
    GrabCImageSignalType m_feeders;
   
  private:
    
    /// Lista degli eventi lato server
    CWindowEventList m_events; 

    /// Callback called on CWindow Destroy
    OnCWindowDestroyType OnDestroy;
   
    /// Mutex event queue
    boost::mutex m_mutexOnEvent;
    /// ConditionVar event queue
    boost::condition m_cndOnEvent;
};

  }
}

#define	CWINDOW_NULL_DRIVER "None"

#endif
