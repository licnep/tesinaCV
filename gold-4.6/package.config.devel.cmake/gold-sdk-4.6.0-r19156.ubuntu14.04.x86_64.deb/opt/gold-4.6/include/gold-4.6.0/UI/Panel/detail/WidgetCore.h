 /** @file WidgetCore.h
  * @brief Internal structure for widget
  * @author Paolo Medici
  **/
#ifndef _WIDGET_DETAIL_H
#define _WIDGET_DETAIL_H

#include <string>
#include <vector>
#include <boost/ptr_container/ptr_map.hpp>

#include <Libs/INIFiles/strcast.h>
#include <Libs/INIFiles/INIFile.h>
#include <UI/Panel/detail/PanelTypes.h>
#include <UI/Panel/detail/Serializable.h>
#include <boost/utility.hpp>

// fw
namespace vl{ namespace ini {class INIFile;} } using vl::ini::INIFile;

namespace ui {

namespace detail {

/// Attributes
typedef std::map< std::string,std::string > attr_list_t;
/// Children
typedef std::vector<widget_guid_t> children_list_t;

/// const per indicare un widget senza parent
static const widget_guid_t no_parent = widget_guid_t(-1);

/// struttura widget usata internamente e non mostrata agli utilizzatori
struct WidgetCore: public boost::noncopyable {

    /// Widget Class Name
    std::string m_class;
    /// Attributes
    attr_list_t m_attr;
    /** genitore (NOTA: alcuni widget potrebbero essere frame o pannelli embeddati in piu parent.
      *   in tale caso tale valore ha un puro significato cosmetico e rappresenta l'ultimo Add) */
    widget_guid_t m_parent;
    
    /// Children
    children_list_t m_children;
    
    /// widget a cui questo GUID e' legato
    std::vector<widget_guid_t> m_links;

    /// E' un controllo lazy (viene forzata l'update solo a comando)
    bool lazy;

    /// Optional INI File
    INIFile *ini;
    /// KEY in INIFILE
    std::string key;
    /// Serializer
    Serializable *serializer;
    /// LISTENER BITMASK
    unsigned long listener;
    /// reference count
    int m_ref_count;
    /// e' nella visible list?
    bool m_visible;

    /// default widget ctor
    WidgetCore() : m_parent(widget_guid_t(-1)), lazy(false), ini(NULL), serializer(NULL), listener(0), m_ref_count(1), m_visible(false) { }
    
    ~WidgetCore() { delete serializer; }

    /// Costruttore di copia "esplicito"
    void CloneFrom(const WidgetCore & src)
	{
	m_class = src.m_class;
	m_attr = src.m_attr;
// 	m_parent = da fare a mano
// 	m_children = da fare a mano
	lazy = src.lazy;
	ini = src.ini;
	key = src.key;
	serializer = src.serializer;
	listener = 0;	//
	m_ref_count = 1;
	}

    void Link(widget_guid_t a)
    {
      m_links.push_back(a);
    }

    void UnLink(widget_guid_t a)
    {
      m_links.erase(std::find(m_links.begin(), m_links.end(),a));
    }

    /// increase referece count
    inline void AddRef(int inc) { m_ref_count += inc; }
    /// decreare reference count
    inline bool Release() { m_ref_count--; return m_ref_count!=0;}

    /// valuta se tra gli attributi c'e' l'attributo @a attr
    inline bool Has(const std::string & attr) const { return m_attr.find(attr) != m_attr.end();  }

    /// valuta se tra gli attributi c'e' l'attributo @a attr
    bool Hast(const std::string & attr, std::string & value) const 
    {
	attr_list_t::const_iterator i = m_attr.find(key);
	if(i!=m_attr.end()) 
	{ 
	  value = i->second;  
	  return true; 
	}
	else
	  return false;
    }

    /// Set an Attribute
    inline void Set(const std::string &key, const std::string & value)
	{
	m_attr[key] = value;
	}

    /** Get an Attribute
      * @note if not exist std::runtime_error is thrown
      **/
    const std::string & Get(const std::string &key) const
	{
	attr_list_t::const_iterator i = m_attr.find(key);
	if(i!=m_attr.end()) { return i->second; }
		else throw std::runtime_error("Attribute " + key + " not found");
	}

    /// Get an Attribute
    template<class T>
    T Get(const std::string &key, T __default) const {
	attr_list_t::const_iterator i = m_attr.find(key);
        if(i!=m_attr.end())
		{
		return vl::numeric_cast<T>(i->second);
		}
		else
		return __default;
	}

    /// Set a Lazy Control. Un Controllo Lazy viene aggiornato solo attraverso una chiamata esplicita a Update
    void SetLazy(bool l) { lazy = l; }

    /// Aggiunge un figlio
    inline void Attach(widget_guid_t guid) {
	m_children.push_back(guid);
	}
	
    /// Rimuove un figlio
    inline void Detach(widget_guid_t guid) {
	// TODO
	}

    /// Si interroga se il controllo e' serializzabile
    inline bool IsSerializable() const { return serializer!=NULL; }

    /// Ritorna il valore associato al serializzatore
    std::string Value() const { 
      if(serializer)
	{
	std::string str; 
	serializer->Get(str);
	return str; 
	}
	else
	  throw std::runtime_error("Get with no serializer");
    }

    /// imposta il valore associato al widget
    void Value(const std::string & value) const 
    { 
      if(serializer)
	  serializer->Set(value); 
      else
	  throw std::runtime_error("Set with no serializer");
    }

  /// debug
    friend std::ostream & operator << (std::ostream&o, const WidgetCore & p);

    void Load(const std::string & def)
    {
        serializer->Set( ini->Value<std::string>(key, def) );
    }

    void Load(const boost::any & def)
    {
      std::string value;
        if(!ini->Get<std::string>(key, value))
        {
          serializer->Set(def, ui::detail::InternalType);
          serializer->Get(value, ui::detail::ExternalType);
          ini->Set(key, value);
        }
        else
        {
          try
          {
            serializer->Set(  value, ui::detail::ExternalType );  
          }
          catch( const std::runtime_error& )
          {
            serializer->Set(def, ui::detail::InternalType);
            serializer->Get(value, ui::detail::ExternalType);
            ini->Set(key, value);
          }
        }
    }

    /// Carica il dato dal file INI associato.
    void Reload(ui::detail::AccessMode mode = ui::detail::ExternalType)
    {
        serializer->Set(  ini->Value<std::string>(key), mode );
    }

    /// Salva il dato sul file INI associato
    void Save(ui::detail::AccessMode mode = ui::detail::ExternalType) const
    {
        if(!serializer)
            throw std::runtime_error("Save failed: no serializer");

        std::string value;
        serializer->Get(value, mode);
        ini->Set(key, value);
    }
};

/// vettore globale
typedef boost::ptr_map<widget_guid_t, WidgetCore> widget_list_t;
// Il widget vero e proprio GUID+DATI
// typedef widget_list_t::value_type widget_internal;

} // namespace ui

} // namespace detail

#endif
