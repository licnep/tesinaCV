#ifndef _CWINDOW_CAMERA_H
#define _CWINDOW_CAMERA_H

#include <vector>

#include <boost/math/constants/constants.hpp>

#include <Data/Math/Rects.h>
#include <Data/Math/TMatrices.h>

#include <Data/Base/CCameraParams.h>

#include <UI/CWindows/CWindowTypes.h>
#include <UI/CWindows/CWindowFwd.h> // Forward Declaration
#include <UI/gold_ui_export.h>


namespace ui {
namespace win {

/** A ViewPortMatrix 3x4
 *
 * (u,v,1) = (u',v',z)=M(X,Y,Z,1)
 *
 * - u,v in coordinate immagine
 * -   z in coordinate mondo usato per fare il clipping dello z-buffer
 **/
typedef math::TMatrix<double, 3, 4> ViewPortMatrix;

/** an inverse viewport matrix
 * (X,Y,Z,1) = M (u,v,Z)
 *
 **/
typedef math::TMatrix<double, 3, 4> InverseViewPortMatrix;

class GOLD_UI_EXPORT CCamera {
    /// ViewPort
	math::Rect2f m_logical_viewport;
	math::Rect2d m_viewport;
/// true: relative to the window, false: absolute
    bool m_viewport_relative;
public:
    CCamera();
    virtual ~CCamera();

    /// return current view matrix
    virtual void GetMatrix(CWindowCore *core, ViewPortMatrix& M) = 0;


    /// return the inverse camera for DrawImage
    /// @param M a reduced matrix
    virtual void GetRestInverseUVWMatrix(CWindowCore *core, InverseViewPortMatrix& M) = 0;

    /// should modify internal structure in order to set logical coordinate
    virtual bool Interact(CWindowCoreManager *core, const CWindowEvent& Event) = 0;

    /// Draw a GUI over the screen at the end of rendering
    virtual int Draw(CWindowCore *core) = 0;

    /** assign the camera viewport to a subpart of window */
    void SetViewPort(float x0, float y0, float x1, float y1, bool relative) {
        m_logical_viewport.x0 = x0;
        m_logical_viewport.y0 = y0;
        m_logical_viewport.x1 = x1;
        m_logical_viewport.y1 = y1;
        m_viewport_relative = relative;
    };

    /// Return SubWindow Viewport
    const math::Rect2d& GetViewPort(CWindowCore *core);

//  	/// Converte un punto da schermo a coordinate logiche (supponendo per esempio Z=0)
//  	Point3f ScreenToLogical(CWindowCore *core, const Point2i& w);
};

typedef CCamera CWindowCamera;


} // namespace win
} // namespace ui

#endif
