/** @file XImgProc.h
 *  @brief Funzioni di trasformazioni di immagini rivolte all'output
 *  
 *  Funzioni di trasformazioni di immagini non propriamente di elaborazione, ma 
 *   piuttosto per il rendering e il disegno. Usate Internamente da DrawXSubImage
 * 
 **/
#ifndef XIMGPROC_H
#define XIMGPROC_H

#include <Data/CImage/Pixels/RGB8.h>   // RGBA8

namespace ui
{
namespace win
{
  
/** None: Nessuna elaborazione. **/
struct XNone {
};

/** PROC_CONVERSION. Conversione spazio colore.
   * Solo verso RGBA @a alpha1 viene usato
   **/
struct XConversion {
 float alpha;
 XConversion(float a) : alpha(a) { }
};

/** PROC_COLORKEY: nell'immagine di input tutto cio' che e' @a colorkey viene messo
 *   a @a alpha1, mentre il resto dell'immagine a @a alpha2
 * converte RGB/GREY in RGBA
 **/
struct XColorKey {
 cimage::RGB8 key;
 float alpha1, alpha2;
 XColorKey(cimage::RGB8 _key, float _alpha1 = 0.0f, float _alpha2 = 255.0f) : key(_key), alpha1(_alpha1), alpha2(_alpha2) { }
};

/** PROC_OPACITY: disegna una immagine come se fosse una mappa di opacita'.
 *  Se bianco e nero il colore viene modulato con il colore di @a colorkey, e
 *  i due limiti di alpha vengono interpolati tra @a alpha1 e @a alpha2
 * converte RGB/GREY in RGBA
 ***/
struct XOpacity {
 cimage::RGB8 key;
 float alpha1, alpha2;
 XOpacity(cimage::RGB8 _key, float _alpha1= 0.0f, float _alpha2 = 255.0f) : key(_key), alpha1(_alpha1), alpha2(_alpha2) { }
};

/** PROC_FILTER: trasforma l'immagine di input moltiplicandola per il colorkey 
  *          l'immagine e' comunque opaca. Se non si vuole opaca usare PROC_OPACITY
  * converte RGB/GREY in RGB
  **/
struct XFilter {
 cimage::RGB8 key;
 XFilter(cimage::RGB8 _key) : key(_key) { }
};

  } // namespace win
} // namespace ui
#endif
