#ifndef _CWINDOW_LAYER_H
#define _CWINDOW_LAYER_H

#include <UI/CWindows/CDrawingQueue.h> // The Queue
#include <UI/CWindows/CWindowViewPort.h> // The ViewPort
#include <map>
#include <UI/gold_ui_export.h>

#include <UI/gold_ui_export.h>

namespace ui {
 namespace win {
   
 /** A single layer: extend the Drawing Queue */
 class GOLD_UI_EXPORT CWindowLayer: public CDrawingQueue {
   
   
   ViewPortMode m_viewPortMode;
   
   bool m_viewportValid;   
   CWindowViewPort m_viewport;
   
   /// Set the Camera Layer
   sharedPtrWindowCamera m_camera;
   
   /// Current ViewPort
   math::Rect2i m_curViewPort;
    
   /// Matrice di inversione del ViewPort
   math::TMatrix<double, 3,3> m_curViewPortMatrix;
   
 public:
   
   CWindowLayer() : m_viewPortMode(WCVM_INHERIT), m_viewportValid(false) { }
   ~CWindowLayer();
   
   /// change the viewport mode
   inline void SetViewPortMode(ViewPortMode mode) { m_viewPortMode = mode; }
   
   /// change the viewport
   inline void SetViewPort(const CWindowViewPort & viewport) { m_viewport = viewport; m_viewportValid = true; }
   inline void DeleteViewPort() { m_viewportValid = false; }
   
   /// Change the camera
   inline void SetCamera(sharedPtrWindowCamera camera) { m_camera = camera; m_viewPortMode = WCVM_CAMERA; }
   inline void DeleteCamera() { m_camera.reset(); }
   
   /// Convert a screen coordinate in viewport coordinate using Layer Reference Frame
   /// @note the viewport and projection matrix used are the last involved in a Draw operation
   inline math::Point2i ScreenToViewPort(const math::Point2i & screen) const {
	return ui::win::ScreenToViewPort(screen, m_curViewPort);
   }

   /// Convert a viewport coordinate in OGL coordinate using Layer Reference Frame
   /// @note the viewport and projection matrix used are the last involved in a Draw operation
   inline math::Point2f ViewPortToNormalized(const math::Point2i & viewport) const {
	return ScreenToGL<float>(math::Point2f(viewport), m_curViewPort.width(), m_curViewPort.height());
   }

   /// Convert a Viewport coordinate in Logical Coordinate using Layer Reference Frame
   /// @note the viewport and projection matrix used are the last involved in a Draw operation
   inline math::Point2f ViewPortToLogical(const math::Point2i & viewport) const {
	return ui::win::ScreenToWindow<float>(m_curViewPortMatrix, viewport, m_curViewPort.width(), m_curViewPort.height() );   
   }
   
   /** Draw all widget of Layer */
    int Draw(CWindowCore *Window);
    
    /** Interact with all Layer Widget */
    bool Interact(CWindowCoreManager *Window, CWindowEvent & event);
 };
 
 
/// Layers 
class GOLD_UI_EXPORT CDrawerList {
  typedef std::map<int, CWindowLayer> CWindowLayerListType;
  
  CWindowLayerListType m_list;
public:
  CDrawerList();
  ~CDrawerList();
  // release all objects
   inline void Clear() { m_list.clear(); }
   // Debug
   void Print();
   
   /// return the inner list
   const CWindowLayerListType & List() const { return m_list; }
   
   inline CWindowLayer & operator [] (int n) { return m_list[n]; }
//    const CWindowLayer & operator [] (int n) const { return m_list.find(n)->second; }
   
   /** Draw all widget of Layer */
    int Draw(CWindowCore *Window);
    /** Interact with all Layer Widget */
    bool Interact(CWindowCoreManager *Window, CWindowEvent & event);
};
 
 }
}

#endif
