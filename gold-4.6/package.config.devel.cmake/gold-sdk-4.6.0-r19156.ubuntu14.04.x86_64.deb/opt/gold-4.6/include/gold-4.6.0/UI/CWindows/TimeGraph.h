#ifndef TIMEGRAPH
#define TIMEGRAPH

#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>
#include <UI/CWindows/CWindow.h>
#include <Data/Math/Points.h>

class GOLD_UI_EXPORT TimeGraph
{
public:
	TimeGraph();

	TimeGraph( boost::shared_ptr<ui::win::CWindow> _sp_wnd,
			const std::string& _title,
			double _x0, double _y0,
			double _w, double _h,
			double _x_border, double _y_border,
			double _x_min, double _x_max,
			double _y_min, double _y_max,
			// boost::function<double()> _value,
			const std::string& _x_unit,
			const std::string& _y_unit
		);

	void Rescale();
	void Update(const math::Point2f& p);

	ui::win::CWindow& Wnd() { return *sp_wnd; }

	boost::shared_ptr<ui::win::CWindow> sp_wnd;
	double x0, y0;
	double w, h;
	double x_min, x_max;
	double y_min, y_max;
	double x_border, y_border;
	double x_scale;
	double y_scale;
	double y_zero;

	std::vector<math::Point2f> f_video;
	std::vector<math::Point2f> f_raw;

	std::string title;
	std::string x_unit;
	std::string y_unit;

	// boost::function<double()> x_value;
	// boost::function<double()> y_value;

};

#endif // TIMEGRAPH
