/**
 * \file UI/CWindows/Navigation.h
 * \brief CWindow Widget for managing viewing camera paths
 * \author Paolo Grisleri \<grisleri@ce.unipr.it\>
 */

#ifndef NAVIGATION_H
#define NAVIGATION_H

#include <UI/CWindows/CWidget.h>
#include <UI/CWindows/CWindowCore.h>
#include <UI/CWindows/CWindowCoreManager.h>
#include <UI/CWindows/CWindowCamera3D.h>

#include <boost/filesystem/path.hpp>

#include <UI/gold_ui_export.h>

namespace ui
{
namespace win
{


/**
 * \brief Class for modeling a Button widget on a window
 *
 *	A spline is define as an array of control points
 *	\see ControlPoint
 */
class GOLD_UI_EXPORT Button:
    public ui::win::CWidget
{
    boost::shared_ptr<boost::thread> m_thread;

public:

    math::Rect2i m_area;
    std::string m_label;
    boost::function<void(void)> action;

    int Draw(ui::win::CWindowCore* win);
    bool Interact(ui::win::CWindowCoreManager* win, const ui::win::CWindowEvent& event);

    void Periodic_Refresh(ui::win::CWindowCoreManager* win,
                          boost::posix_time::time_duration td);

};

/**
 * \brief Class for modeling a Cubic Spline
 *
 *	A spline is define as an array of control points
 *	\see ControlPoint
 */
class GOLD_UI_EXPORT Spline
{
public:

    /**
     * \brief This structure defines a single control point of the spline
     */
    struct ControlPoint
    {
        math::Point3d pos; ///< 3d vector of doubles describing the cp position
        math::Point3d tang; ///< 3d vector of double describing the spline tangent in pos
    };


    /**
     * \brief Remove all the control points of the current spline
     */
    void Clear();

    /**
     * \brief Add a new segment at the end of the current spline
     */
    void AddSegment( const ControlPoint& cp1,  const ControlPoint& cp2);

    /**
     * \brief Recompute the spline coefficients
     */
    void Compute_Spline();

    /**
     * \brief Returns the position of a point on the current spline
     * corresponding to the given segment and position
     * \param [in] s segment where the returned point will be computed
     * \param [in] t position belonging to [0.0, 1.1] where the returned point will be computed
     * \param [in] pos the Point3d belonging to the spline
     */
    void GetPosition(unsigned int s, double t, math::Point3d& pos) const;

    /**
     * \brief Returns the orientation in the current spline corresponding to the given position
     * \param [in] s segment where the returned point will be computed
     * \param [in] t position belonging to [0.0, 1.1] where the returned point will be computed
     */
    void GetOrientation(double t, math::Point3d& ort) const;
    
    /**
     * \brief Compute the vector orthogonal to o1, centered in p1, in the p2 direction
     * This is an helper function to compute control points
     */
    static void ComputeTang(const math::Point3d& p1,
                            const math::Point3d& o1,
                            const math::Point3d& p2,
                            math::Point3d& tang );

private:
    /**
     * \brief Structure containing the spline coefficients for a given segment
     * The coefficients used in the following function $f(t)=a*t^3+b*t^2+c^t+d$
     * for approximating the spline in a given segment.
     */
    struct Coefficients
    {
        double a, b, c, d;
    };

    /**
     * \brief struct containing the path coefficients for a given segment
     */
    struct PathCoefficients
    {
        Coefficients x; ///< spline coefficients for the x coordinate
        Coefficients y; ///< spline coefficients for the y coordinate
        Coefficients z; ///< spline coefficient for the z coordinate
        Coefficients yaw; ///< spline coefficients for yaw
        Coefficients pitch; ///< spline coefficients for pitch
        Coefficients roll; ///< spline coefficients for roll
    };

    /**
     * \brief Returns Compute the 1-D spline value for a given
     * Compute the function $f(t)=a*t^3+b*t^2+c^t+d$ for a given t
     * \param [in] coeff Coefficients to be used as argument
     * \param [in] t position where the function has to be computed. Belongs to [0,1.0]
     * \param [out] value of the function in t
     */
    void Calc(const Coefficients& coeff, double t, double& result) const;  
    
    /**
     * \brief Returns the coefficients of a spline segment, given the position and the orientation
     * \param [in] x0
     * \param [in] x1
     * \param [in] dx0
     * \param [in] dx1
     * \param [out] Coefficients
     */
    void Compute_Coeff(double x0, double x1,
                       double dx0, double dx1,
                       Coefficients& coeff);    
  
    std::vector<ControlPoint> m_cp;
    std::vector<PathCoefficients> m_path_coeff;
};




/**
 * \brief CWindow Widget for managing viewing camera paths
 *
 * Attaching this widget to the window allows to edit, save or load a path
 * for the camera framing the 3D scene drawn on the window.
 * A loop mode is also available so the POV can move along the path and the orientation
 * is changed from the code and using a non-interactive way.
 * How to insert the widget in the CWindow
 * \code
 *   ///////////////////////////////////////////////////////////////////////////
 *   //// sample code for navigation plugin
 *   ///////////////////////////////////////////////////////////////////////////
 *   boost::shared_ptr<ui::win::Navigation> viewer( new  ui::win::Navigation() );
 *
 *   // Insert the first segment
 *   ui::win::Navigation::Segment segment;
 *   segment.begin.ku=1.0;
 *   segment.begin.ratio=1.0;
 *
 *   segment.begin.u0=0.0;
 *   segment.begin.v0=0.0;
 *
 *   segment.begin.x0=0.0;
 *   segment.begin.y0=0.0;
 *   segment.begin.z0=20.0;
 *
 *   segment.begin.yaw=0.0;
 *   segment.begin.pitch=0.5;
 *   segment.begin.roll=0.0;
 *
 *   segment.end=segment.begin;
 *
 *   segment.look_at_begin = math::Point3d(0.0, 0.0, 0.0);
 *   segment.look_at_end = math::Point3d(0.0, 0.0, 0.0);
 *
 *   viewer->AddSegment(segment);
 *
 *   // set the filename to be used
 *   viewer->m_fs_path = "camera_path-"+ CSensor::Name()+".txt";
 *   // viewer->Load();
 *
 *   // insert the plugin in the CWindow
 *   m_spWindow->InsertPlugin( viewer );
 *
 *	 // set the CWindow camera to be the camera provided by the plugin
 *   // assegna all finestra la camera del viewer
 *   m_spWindow->SetCamera ( viewer->Camera() );
 *   ///////////////////////////////////////////////////////////////////////////
 * \endcode
 *
 * Here is a table of the interactive commands available during the interactive mode
 * The logic is that 3 areas of the keyboard are mapped to control all the functions of this plugin.
 *
 * Camera Pose controls with keypad:
 * Using the keypad arrows, the absolute (in the world reference system)
 * position and orientation of the camera can be changed.
 * - UP|'8': increment x absolute position
 * - DOWN|'2': decrement x absolute position
 * - LEFT|'4': increment y absolute position
 * - RIGHT|'6: decrement y absolute position
 * - PG_UP|'9': increment z absolute position
 * - PG_DN|'3': decrement z absolute position
 * - SHIFT+{UP|'8'}: decrement absolute pitch
 * - SHIFT+{DOWN|'2'}: increment absolute pitch
 * - SHIFT+{LEFT|'4'}: increment absolute yaw
 * - SHIFT+{RIGHT|'6'}: decrement absolute yaw
 * - SHIFT+{PG_UP|'9'}: increment absolute roll
 * - SHIFT+{PG_DN|'3'}: decrement absolute roll
 * - '+': increment the focal length
 * - '-': decrement the focal length
 *
 * Camera Pose controls with arrows keypad:
 * Using the arrows, the relative (in the reference system of the camera )
 * position and orientation of the camera can be changed.
 * - UP: increment the x position (the camera moves forward)
 * - DOWN: decrement the x position (the camera moves backward)
 * - LEFT: increment the y position (the camera moves left)
 * - RIGHT: decrement the y position (the camera moves right)
 * - SHIFT+UP: decrement the pitch
 * - SHIFT+DOWN: increment the x pitch
 * - SHIFT+LEFT: increment the y yaw
 * - SHIFT+RIGHT: decrement the y yaw
 *
 * Camera Pose controls with mouse:
 * - Right key: allows to drag the ground
 * - SHIFT+Right key: allows to change the camera orientation (pitch+yaw)
 *
 * Segments and KeyPoints management:
 * A path is divided in segments. A segments has a begin and an end keypoint, speed, and policy.
 * Every keypoint has: position, orientation, focal lenght.
 * Positions and orientation interpolated between two keypoints of the same segment
 * can be determined using different policies:
 * - LINEAR: each coordinate is obtained as linear interpolation between begin and end
 * - SPLINE: a spline is used to obtain the intermediate values
 * - LOOK_AT: this is used for orientation only, the position changes and the orientation
 * changes consequently to frame a certain point in the middle of the image.
 * The point must be edited directly in the path file.
 *
 * - INS|0: Insert a kew point (begin, end) of the current segment.
 * after the insertion of the end point the segment appended to the path
 * - CANC|'.': remove the current segment
 *
 * - KeyPad_ENTER: toggles between editing and follow path mode.
 * - CTRL+KeyPad_ENTER: save the path file
 * - SHIFT+KeyPad_ENTER: load the path file
 * - Home: moves the current point to the begin of the next segment
 * - SHIFT+Home: moves the current point to the begin of the previous segment
 * - End: moves the current point to the end of the next segment
 * - SHIFT+End: moves the current point to the end of the previous segment
 *
 * Playback control:
 * - '/': toggles the GUI
 * - CTRL+KeyPad '+': increment the speed by 1/100 of the current speed. Belongs to [1E-4, 1E-2]
 * - CTRL+KeyPad '-': decrement the step by 1/100 of the current speed. Belongs to [1E-4, 1E-2]
 */
class GOLD_UI_EXPORT Navigation:
    public ui::win::CWidget
{
public:

	/**
	 * \brief Structure modeling a segment
	 *
	 * A segment is part of a path. A path is a sequence of segments.
	 * Segments are not necessarily joint. joint segment can be obtained setting
	 * the begin of the next segment to the same value of the end of the previous.
	 * Closed path are obtained setting the end of the last segment equal to the
	 * begin of the first segment.
	 */
    struct Segment
    {
      /** \brief end parameters of the segment */
      ui::win::CCamera3D::Parameters begin;

      /** \brief end parameters of the segment */
      ui::win::CCamera3D::Parameters end;
      
      /** \brief begin point to look at when the LOOK_AT policy is specified for orientation */
      math::Point3d look_at_begin;

      /** \brief end point to look at when the LOOK_AT policy is specified for orientation */
      math::Point3d look_at_end;
      
      /**
       * \brief Smoothing type policy for position, orientation, and focal length
       */
      typedef enum {LINEAR, CUBIC_SPLINE, LOOK_AT} SmoothingType;

      /**
       * \brief Decode the requested SmoothingType.
       *
       * \param [in] str string to be converted to the corresponding SmoothingType
       * Valid values are: "LINEAR"->LINEAR, "CUBIC_SPLINE"->CUBIC_SPLINE, "LOOK_AT"->LOOK_AT
       * \return SmoothingType corresponding to the argument
       */
      static SmoothingType SmoothingTypeDecode(const std::string& str);

      /**
       * \brief Decode the requested SmoothingType.
       *
       * \param [in] st to be converted into the corresponding
       * \return const char* to the string corresponding to the argument:
       * LINEAR->"LINEAR", CUBIC_SPLINE->"CUBIC_SPLINE", LOOK_AT->"LOOK_AT"
       */
      static const char* SmoothingTypeEncode(SmoothingType st);
      
      SmoothingType smoothing_position;  ///< SmoothingType for position
      SmoothingType smoothing_orientation; ///< SmoothingType for orientation
      SmoothingType smoothing_focal; ///< SmoothingType for focal
      
      boost::posix_time::time_duration duration; ///< Duration of the whole trip, \see m_speed
    };

    
    /** \brief Default constructor */
    Navigation();

    /** \brief Constructor accepting a reference to the INIFile */
    Navigation(INIFile& ini);

    /** \brief Destructor */
    ~Navigation();

    /**
     * \brief Returns the plugin name
     *
     * Virtual function required from ui::win::CWidget
     */
    const char *getName(void) const {
        return "3DNavigation";
    }
    
    /**
     * \brief Custom drawing code
     *
     * Draws the user interface to be used with by the mouse
     * Virtual function required from ui::win::CWidget
     */
    virtual int Draw(ui::win::CWindowCore* win);

    /**
     * \brief Custom event handling code
     *
     * Virtual function required from ui::win::CWidget
     */
    virtual bool Interact(ui::win::CWindowCoreManager* Window, 
                          const ui::win::CWindowEvent& event);
    
    /** \brief Called for timed refresh */
    void Periodic_Refresh(ui::win::CWindowCoreManager* win,
                          boost::posix_time::time_duration td);

    /**
     * \brief The 3D window camera used to generate the view
     * It is necessary to add this camera to the controlled window
     * from the user code. 
     * Virtual function required from ui::win::CWidget
     */        
    boost::shared_ptr<ui::win::CCamera3D> Camera()
    {
        return m_spcam;
    }

    /**
     * \brief Add a segment to the current path
     * The segment is added at the end
     * \param segment the segment to be added
     */    
    void AddSegment(const ui::win::Navigation::Segment& segment);
    // void RemoveSegment(unsigned int segment_num);    
    
    /**
     * \brief Load a path from file
     * The filename m_fs_path is specified by m_fs_path
     * \see m_fs_path
     */
    void Load();
    
    /**
     * \brief Save the current path to m_fs_path
     * The filename is specified by m_fs_path
     * \see m_fs_path
     */
    void Save();
    

    /** \brief Increment the yaw angle by m_speed radiants */
    void YawInc()   {
        m_spcam->Rotate_CC_Rel(math::Point3d(m_speed, 0.0, 0.0));
    }

    /** \brief Decrement the yaw angle by m_speed radiants */
    void YawDec()   {
        m_spcam->Rotate_CC_Rel(math::Point3d(-m_speed, 0.0, 0.0));
    }

    /** \brief Increment the pitch angle by m_speed radiants */
    void PitchInc() {
        m_spcam->Rotate_CC_Rel(math::Point3d(0.0, m_speed, 0.0));
    }

    /** \brief Decrement the pitch angle by m_speed radiants */
    void PitchDec() {
        m_spcam->Rotate_CC_Rel(math::Point3d(0.0, -m_speed, 0.0));
    }

    /** \brief Increment the roll angle by m_speed radiants */
    void RollInc()  {
        m_spcam->Rotate_CC_Rel(math::Point3d(0.0, 0.0, m_speed));
    }

    /** \brief Decrement the roll angle by m_speed radiants */
    void RollDec()  {
        m_spcam->Rotate_CC_Rel(math::Point3d(0.0, 0.0, -m_speed));
    }

    /** \brief Put the roll angle value to 0.0 radiants */
    void RollZero()
    {
        // ui::win::CCamera3D::Parameters& params = m_spcam->Params(params);
        m_spcam->Rotate_CC_Rel(math::Point3d(0.0, 0.0, 0.0),
                        ui::win::CCamera3D::AM_PITCH|ui::win::CCamera3D::AM_YAW);
    }

    /** \brief Increments the current X coordinate by m_speed*/
    void XInc() {
        m_spcam->Move_CC_Rel(math::Point3d(m_speed, 0.0, 0.0));
    }

    /** \brief Decrements the current X coordinate by m_speed*/
    void XDec() {
        m_spcam->Move_CC_Rel(math::Point3d(-m_speed, 0.0, 0.0));
    }

    /** \brief Increments the current X coordinate by m_speed*/
    void YInc() {
        m_spcam->Move_CC_Rel(math::Point3d(0.0, m_speed, 0.0));
    }

    /** \brief Decrements the current X coordinate by m_speed*/
    void YDec() {
        m_spcam->Move_CC_Rel(math::Point3d(0.0, -m_speed, 0.0));
    }

    /** \brief Increments the current X coordinate by m_speed*/
    void ZInc() {
        m_spcam->Move_CC_Rel(math::Point3d(0.0, 0.0, m_speed));
    }

    /** \brief Decrements the current X coordinate by m_speed*/
    void ZDec() {
        m_spcam->Move_CC_Rel(math::Point3d(0.0, 0.0, -m_speed));
    }
    
    boost::filesystem::path m_fs_path;   ///< filename to save or load a path
    std::vector< boost::shared_ptr<Button> > buttons;  ///< user interface buttons
    
private:
    // INIFile& m_ini;

    boost::shared_ptr<ui::win::CCamera3D> m_spcam;  ///< The camera instance
    std::vector<Segment> m_path;                    ///< Path storage
    bool m_gui;                                     ///< Show or hide the gui
    bool m_follow_path;                             ///< true when camera moves along path
    
    math::Point2i old_pos; ///< Last mouse position to compute movement amplitude

    unsigned int m_current_segment;  ///< Number of the current segment
    double m_current_position;       ///< Position in the current segment (normalized)
    double m_speed;                  ///< Camera movement speed along the path
    
    int m_insertion_status;          ///< Current status of the segment construction
    Segment m_segment;               ///< Current segment (construction)
    
    bool m_is_spline_initialized;    ///< true if the cubic-spline has been initialized
    ui::win::Spline m_spline;        ///< Cubic-spline object

    std::vector<math::Point3f> m_cam_trajectory_map;    ///< Buffer for drawing 2d trajectory
    math::Point3d m_look_at;               ///< Temporary
    
    
    void RegeneratePath_CubicSpline();
    void GetPath_LinearInterpolation(ui::win::CCamera3D::Parameters& params);
    void GetPath_CubicSpline3D(ui::win::CCamera3D::Parameters& params);
    void GetPath_LinearInterpolation_Look_At(ui::win::CCamera3D::Parameters& params);
    
    void Move_Looking_At_Rel(double delta_theta, double delta_phi, const math::Point3d& target=math::Point3d(0.0, 0.0, 0.0));
    void Look_At(const math::Point3d& p, ui::win::CCamera3D::Parameters& params);
};

} // namespace ui
} // namespace win


#endif // NAVIGATION_H
