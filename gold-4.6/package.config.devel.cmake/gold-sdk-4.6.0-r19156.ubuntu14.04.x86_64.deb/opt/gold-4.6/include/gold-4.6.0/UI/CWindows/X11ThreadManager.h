/** @brief dichiarazioni comuni per WindowCore basati su X (X11ThreadManager)
  * @file X11ThreadManager.h
  * @author Paolo Medici
  * @date 27-09-2006
  **/
#ifndef _X11_THREAD_MANAGER_H
#define _X11_THREAD_MANAGER_H

#include <UI/CWindows/CWindowCore.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h> // XVisualInfo  
#include <sys/ioctl.h>	// FIONREAD
#include <boost/thread/thread.hpp>

#include "Motif.h"

namespace ui{
  namespace win{

/** la struttura STMessage contiene messaggi che vengono inviati a un Thread X11 attraverso le pipe */
struct STMessage {
  /** Opzionale. Serve solo nel caso della modalita' SingleThread per specificare a che finestra si riferisce il comando */
  CWindowCoreManager *window; 
  /** comando (uno smart pointer) che verra eseguito sul thread X11 */
  SPWindowCommand *spcmd;
};

/// Questa struttra serve per salvare lo stato precedente del Decor delle finetre
struct WindowDecor {
    /// Motif
    unsigned int decor;
    unsigned int funcs;
    /// KDE
    long KWMHints;
    /// GNOME
    long GNOMEHints;
};

/// Classe base di utility per chi usa X su un Thread separato (per una o piu finestre)
/// il Display X e' associato comunque al thread (1Thread,1Display) per il fatto che X non e' thread safe.
class X11ThreadManager {
protected:
    Atom WM_USER;              ///< comando utente (alternativa alla pipe, ma richiede supporto multithread XLib)
    Atom WM_PROTOCOLS;         ///< WM_PROTOCOL
    Atom _EXODE_SESSION_QUIT;  ///< _EXODE_SESSION_QUIT
    Atom _MOTIF_WM_HINTS;      ///< Motif Decoration
    Atom KWM_WIN_DECORATION;   ///< KDE Decoration
    Atom _WIN_HINTS;	       ///< Gnome Decoration
    Atom _NET_WM_WINDOW_TYPE;  ///< UFFFFFFFFFFFFFF!!!
    Atom WM_DELETE_WINDOW;
    Atom _NET_WM_STATE_FULLSCREEN;  ///< _NET_WM_STATE_FULLSCREEN
    Atom _NET_WM_STATE;             ///< _NET_WM_STATE

    /// Thread stuff
    boost::thread *threadObj;
    vl::thread::CSuspendable ThreadCreation;

    /// canale di comunicazione verso il server X
    Display  *xDisplay;
    /// schermo attuale
    int      xScreen;
    /// id della root window
    Window   rootWindow;

    /// pipe di comunicazione Asincrona verso il server X
    int compipe[2];       

    /// richiesta di uscita dal ciclo del thread
    bool quit;     

private:
    /// gnome
    void ewmh_fullscreen(Window w, int action);

protected:
    /// l'effettiva funzione che implementa il thread
    virtual void *Thread() = 0;
    /// crea il thread
    bool begin_thread();
    /// rimuove il thread
    bool end_thread();

public:     
    X11ThreadManager();
    virtual ~X11ThreadManager();

    /// Crea una connessione con il Display
    /// @param display_name nome del display o se NULL usa il valore della variabile di ambiente DISPLAY
    bool X11_CreateDevice(const char *display_name = NULL);
    /// Chiude la connessione con X
    bool X11_DeleteDevice(void);

    /// Forza la chiusura del thread
    void Quit(void) { quit=true; }


/// metodi associati alla Window w
/*@{*/
    void setWindowSizeHint(Window w, int x, int y, int width, int height);
    void setWindowDecoration(Window w, bool d, WindowDecor *decor);
    bool getWindowDecoration(Window w, WindowDecor *decor);
    void setWindowInput(Window w, bool grab);

    bool sendRedraw(Window w) {
        :: XClearArea (xDisplay, w, 0, 0, 0, 0, True);
        return true;
        }

    bool raiseWindow(Window w) {
      ::XRaiseWindow(xDisplay, w);
      return true;
      }    

    bool mapWindow(Window w) {
      ::XMapWindow(xDisplay, w);
      return true;
      }

    bool withdrawWindow(Window w) {
      // ::XWithdrawWindow(xDisplay, w, mScreen);
      return false;
      }

    bool unmapWindow(Window w) {
      ::XUnmapWindow(xDisplay, w);
      return true;
      }

    /// return current pointer in (coordinate)
    bool queryPointer(Window w, math::Point2i & pt) const {
        Window wbidon;
        int bidon;
        unsigned int ubidon;
        ::XQueryPointer (xDisplay, w, &wbidon, &wbidon, &pt.x, &pt.y, &bidon, &bidon, &ubidon);
        return true;
        }

     /// Muove la finestra
     bool moveWindow(Window w, int x, int y)  {
     ::XMoveWindow(xDisplay, w, x, y);
     return true;
     }

     /// Ridimensiona la finestra
     bool resizeWindow(Window w, int W, int H) {
     ::XResizeWindow(xDisplay, w, W, H);
     return true;
     }

     /// Set The Window Title
     bool setWindowTitle(Window w, const char *str)
     {
     ::XSetStandardProperties(xDisplay, w, str,
                             str, None, NULL, 0, NULL);
     return true;
     }

    /// mette la finestra in fullscreen
    bool setFullScreen(Window w, WindowDecor *decor, int x, int y, int width, int height, bool fullscreen);
/*@}*/

/// metodi associati allo Screen
/*@{*/
    /// Ritorna la dimesnione fisica del display
    unsigned int ScreenWidth(void) const;
    /// Ritorna la dimesnione fisica del display
    unsigned int ScreenHeight(void) const;
/*@}*/

    
    /// Questa funzione crea la finestra
    /// @param X,Y coordinata top left
    /// @param Width,Height dimensione della finestra. Se FullScreen questi valori in output sono della dimensione dello schermo
    /// @param FullScreen FullScreen Attivo
    /// @param Visible Visibile o meno
    /// @param vi [in] XVisualInfo
   Window CreateWindow(const char *Title, 
        int X, 
        int Y, 
        unsigned int & Width, 
        unsigned int & Height, 
        CWINDOW_FLAGS flags,
		XVisualInfo *vi);

    /** Crea una finestra in TrueColor per X (non GLX) e ritorna il XVisualInfo */
        Window CreateTrueColorWindow(const char *Title, int X, int Y, unsigned int & width, unsigned int & height, CWINDOW_FLAGS flags, XVisualInfo *vi)
        {  
        if(!XMatchVisualInfo(xDisplay,xScreen,24,TrueColor, vi) &&
           !XMatchVisualInfo(xDisplay,xScreen,32,TrueColor, vi))
                {
                // non ha senso lanciare l'eccezione: uscirebbe solo il thread
                std::cout << "[EE] *** XMatchVisualInfo failed: at least 24 bit per pixel required ***\n";
                return 0;
                }
        else
                {
                std::cout << "[X11] Display Depth: " << vi->depth << "\n";
                return CreateWindow(Title, X, Y, width, height, flags, vi);
                }
        }

///@name gestione messaggi
/*@{*/
    /// mette un messaggio nella coda messaggi
    bool SendMessage(const struct STMessage *msg)
      {
      return write(compipe[1], msg, sizeof(struct STMessage))!=-1;
      }

    /// legge un messaggio dalla coda messaggi
    bool ReadMessage(struct STMessage *msg)
      {
      return read(compipe[0], msg, sizeof(STMessage))==sizeof(STMessage);
      }
    
    /// Legge e dispaccia un comando dalla coda locale. win se inserito e' solamente di controllo
    bool OnMessage(CWindowCore *win=NULL);

    /// Svuota la pipe
    bool FlushMessage(CWindowCore *win=NULL);

    /// conta il numero di messaggi in coda
    unsigned int GetMessageCount()
   	{
	unsigned int nMessages;
	// int status;
        ioctl (compipe[0], FIONREAD, &nMessages);
	return nMessages / sizeof(STMessage);
   	}
/*@}*/

///@name template
/*@{*/
    Display  *GetDisplay() const { return xDisplay; }
    Window    GetRootWindow() const { return rootWindow; }
    int       GetScreen() const { return xScreen; }
/*@}*/
};

/////////////// Funzioni comuni ai metodi X11 //////////////////////

unsigned int X11StateToWindowCoreState(unsigned int state);
unsigned int X11ButtonToWindowButton(unsigned int button);
int X11KeySymToASCII(KeySym key);

  }
}

#endif
