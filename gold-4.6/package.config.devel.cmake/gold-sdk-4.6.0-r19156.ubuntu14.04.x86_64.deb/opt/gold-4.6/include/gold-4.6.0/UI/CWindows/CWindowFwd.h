#ifndef _CWINDOW_FWD_H
#define _CWINDOW_FWD_H

// CWindow Forward declaration

namespace ui{
  namespace win{
  //fwd
  class CWindow;
  class CWindowCore;
  class CWindowCoreManager;
  }
}

#endif
