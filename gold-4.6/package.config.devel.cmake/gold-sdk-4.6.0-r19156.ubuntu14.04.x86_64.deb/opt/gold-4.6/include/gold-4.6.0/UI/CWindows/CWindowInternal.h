#ifndef _CWINDOW_INTERNAL_H
#define _CWINDOW_INTERNAL_H

namespace ui
{
  namespace win
  {
    /// Vertice OpenGL con TextureVertex e coordinate
    /// da usare con glInterleavedArrays GL_T2F_V3F
    /// Nota: questa e' una struttura fisica e non puo' essere cambiata
    struct T2F_V3F_t
    {
	float tu, tv;
	float x, y, z;

	T2F_V3F_t():  tu(0.0f), tv(0.0f), x(0.0f), y(0.0f), z(0.0f) {}
	T2F_V3F_t(float _x, float _y, float _z, float _u, float _v) : tu(_u), tv(_v), x(_x), y(_y), z(_z) {}
	T2F_V3F_t(const math::Point3f& p, float _u, float _v) : tu(_u), tv(_v), x(p.x), y(p.y), z(p.z) {}

	// deprecato direi
	inline void Set(float _x, float _y, float _z, float _u, float _v) { tu=_u, tv=_v, x=_x, y=_y, z=_z; }

    };

    /// da usare con glInterleavedArrays GL_C4UB_V3F
    ///  per renderizzare quadrati con i vertivi colorati (non usato in gold al momento)
    /// Nota: questa e' una struttura fisica e non puo' essere cambiata
    struct C4UB_V3F_t {
      unsigned char r,g,b,a;
      float x, y, z;
      
      C4UB_V3F_t():
	      r(0),g(0),b(0),a(0),
	  x(0.0f), y(0.0f), z(0.0f)
      {}
      C4UB_V3F_t(float _x, float _y, float _z,
		      unsigned char _r, unsigned char _g, unsigned char _b, unsigned char _a) :
			      r(_r), g(_g), b(_b), a(_a), x(_x), y(_y), z(_z) {}
    };
    
  }
}




#endif
