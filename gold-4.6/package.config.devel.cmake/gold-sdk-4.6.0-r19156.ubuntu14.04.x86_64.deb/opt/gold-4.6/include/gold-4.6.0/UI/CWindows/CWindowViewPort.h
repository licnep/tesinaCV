#ifndef _CWINDOW_VIEWPORT_H
#define _CWINDOW_VIEWPORT_H

#include <Data/Math/Points.h>
#include <Data/Math/Rects.h>
#include <Data/Math/TMatrices.h>
#include <UI/gold_ui_export.h>

/** @file CWindowViewPort.h
 *  @brief contains API to access to Viewport
 **/

/*********************************** 2D VIEWPORT *******************************************/

namespace ui
{
  namespace win
  {
    
/** The Viewport Rect */
struct CWindowViewPort {
  /// Viewport Range (a rectangle)
  float x0,x1,y0,y1;
  /// Viewport Meanging (true: relative, false absolute)
  bool rx0, rx1, ry0, ry1; 
  
  CWindowViewPort() : x0(0.0f), x1(1.0f), y0(0.0f), y1(1.0f), rx0(true), rx1(true), ry0(true), ry1(true) { }
  
  /// convert The Viewport in an Absolute ViewPort
  math::Rect2i GetViewPort(unsigned int width, unsigned int height) const {
    math::Rect2i out;
    out.x0 = rx0 ? x0 * width : x0;
    out.y0 = ry0 ? y0 * height : y0;
    out.x1 = rx1 ? x1 * width : x1;
    out.y1 = ry1 ? y1 * height : y1;    
    return out;
  };
};


/// Convert a screen point in a ViewPort point
inline math::Point2i ScreenToViewPort(const math::Point2i & screen, const math::Rect2i & viewport)
    {
      return math::Point2i(screen.x - viewport.x0, screen.y - viewport.y0);
    }
    


/** A ViewPortMatrix 3x4
 *
 * (u,v,1) = (u',v',z)=M(X,Y,Z,1)
 *
 * - u,v in coordinate immagine
 * -   z in coordinate mondo usato per fare il clipping dello z-buffer
 **/
typedef math::TMatrix<double, 3, 4> ViewPortMatrix;

/**  (1) Il viewport fisico e' diverso, e va da 0..w, 0..h in coordinate immagine.(left-right, top-down)
 *   (1) Il opengl-viewport e' un ViewPort Cartesiano
 *    con in alto a sinistra le coordinate -1, +1 (left-right), e in basso a destra le coordinate +1, -1 (bottom-up)
 *   (1) il viewport logico/virtuale infine e' un viewport qualsiasi definito dall'utente, ma riferito a una matrice che rimappa 
 *      le coordinate al viewport-opengl
 **/

/** Viewport Ortogonale classico, con la X in orizzontale, e Y in verticale con i range espressi dai limit 
 * @param x0,y0 Top-Left coordinate
 * @param x1,y1 Bottom-Right Coordinate
 **/
ViewPortMatrix GOLD_UI_EXPORT OrthoViewPort(double x0, double y0, double x1, double y1);

/** Viewport per GOLD in metri, con la X in verticale crescente verso l'alto, 
 *   e Y in orizontale crescente verso sinistra con i range espressi dai limiti
 *   e Z crescente verso la camera
 * @param x0,y0 Bottom-Right coordinate (in meters, for example)
 * @param x1,y1 Top-Left Coordinate (in meters, for example)
 **/
ViewPortMatrix GOLD_UI_EXPORT BirdEyeViewPort(double x0, double y0, double x1, double y1, double z0=1.0);

/*********************************** 3D VIEWPORT *******************************************/

/// Return the Frustrum Matrix
ViewPortMatrix GOLD_UI_EXPORT FrustrumMatrix(double left, double right, double bottom, double top, double nearVal, double farVal);

/// Return the Frustrum Matrix
/// @note genera una matrice di proiezione tale che u=a*x + u0z, v=b*y + v0z, z
ViewPortMatrix GOLD_UI_EXPORT FrustrumMatrix(double hfov, double vfov, double u0 = 0.0, double v0 = 0.0);

void GOLD_UI_EXPORT InverseTanFrustrumMatrix(math::TMatrix<double, 3,3> & P, double tan_hfov, double tan_vfov, double u0, double v0);

/// Versione che accetta le tangenti di hfov, vfov
ViewPortMatrix GOLD_UI_EXPORT TanFrustrumMatrix(double tan_hfov, double tan_vfov, double u0, double v0);

/// Versione che accetta ku e kv
ViewPortMatrix GOLD_UI_EXPORT KFrustrumMatrix(double ku, double kv, double u0, double v0);

///
void GOLD_UI_EXPORT RotoTraslationMatrix(ViewPortMatrix & R, double yaw, double pitch, double roll, double xPos, double yPos, double zPos);

///
void GOLD_UI_EXPORT RotationMatrix(math::TMatrix<double,3,3> & R, double yaw, double pitch, double roll);

/// e' la trsposta (spero che sia corretta)
void GOLD_UI_EXPORT InverseRotationMatrix(math::TMatrix<double,3,3> & R, double yaw, double pitch, double roll);

/// Return a Viewport matrix using GOLD reference frame
/// (X,Y,Z,1) -> (x,y,z)
/// @param hfov,vfov half camera FOV
/// @param u0,v0 normalized coordinate for principal point offset
/// @param yaw,pitch,roll angle (rad)
/// @param x0,y0,z0 position of pin-hole [m]
void GOLD_UI_EXPORT CameraMatrix(ViewPortMatrix &M, double hfov, double vfov, double u0, double v0, double yaw, double pitch, double roll, double x0, double y0, double z0);

///
void GOLD_UI_EXPORT TanCameraMatrix(ViewPortMatrix & M, double tan_hfov, double tan_vfov, double u0, double v0, double yaw, double pitch, double roll, double xPos, double yPos, double zPos);

///
void GOLD_UI_EXPORT KCameraMatrix(ViewPortMatrix & M, double ku, double kv, double u0, double v0, double yaw, double pitch, double roll, double xPos, double yPos, double zPos);

/************************************ TOOOLS ***************************************************/
/** Compose affine transformation 
 * @return A o B
 **/
ViewPortMatrix GOLD_UI_EXPORT Compose(const ViewPortMatrix & A, const ViewPortMatrix & B);

/** Invert transformation on a defined Z 
 *   from (X,Y,Z,1) -> (u,v,1) matrix obtain a 
 *   (u,v,1) ->(X,Y,1) matrix (with Z=const)
 **/
math::TMatrix<double,3,3> GOLD_UI_EXPORT ViewPortInvertZ(const ViewPortMatrix & A, double Z = 0.0);

/** from (X,Y,Z,1) -> (u,v,1) matrix obtain a 
 * (u,v,w,1) -> (X,Y,Z) matrix
 **/
math::TMatrix<double,3,4> GOLD_UI_EXPORT ViewPortInvertUVW(const ViewPortMatrix & A);

/** Set The Identity ViewPort
  *  (x,y,z,1) -> (x,y,z)
  */
void GOLD_UI_EXPORT Identity(ViewPortMatrix & A);

/** Clear Viewport Matrix */
void GOLD_UI_EXPORT Zero(ViewPortMatrix & A);

/// Return the Width of Virtual ViewPort
/// metodo da rimuovere (nessun senso)
inline double VirtualWidth(const ViewPortMatrix & v) { return 2.0 / v[0]; }

/// Return the height of Virtual ViewPort
/// metodo da rimuovere (nessun senso)
inline double VirtualHeight(const ViewPortMatrix & v) { return 2.0 / v[4]; }

/// Funzione per convertire un numero in coordinate opengl-viewport -1 .. 1 in coordinate fisiche 0..w
template<class T>
inline T GLToScreenX(T x, T w)
{
 return (x+T(1))*w/T(2);
}

/// Funzione per convertire un numero in coordinate opengl-viewport -1 .. 1 (bottom-up) in coordinate fisiche 0..h (top-down)
template<class T>
inline T GLToScreenY(T y, T h)
{
 return (T(1)-y)*h/T(2);
}

/// Funzione per convertire un numero da coordinate fisiche a coordinate opengl-viewport
template<class T>
inline T ScreenToGLX(T i, T w)
{
 return (T(2) * i)/w - T(1);
}

/// Funzione per convertire un numero da coordinate fisiche a coordinate opengl-viewport
template<class T>
inline T ScreenToGLY(T j, T h)
{
 return T(1) - (T(2)*j)/h;
}

/// Converte un punto opengl-viewport in coordinate fisiche
template<class T>
inline math::Point2<T> GLToScreen(const math::Point2<T> & g, T w, T h)
{
  return math::Point2<T>( GLToScreenX(g.x, w), GLToScreenY(g.y, h));
}

/// Converte un punto fisico in coordinate opengl-viewport
template<class T>
inline math::Point2<T> ScreenToGL(const math::Point2<T> & s, T w, T h)
{
  return math::Point2<T>( ScreenToGLX(s.x, w), ScreenToGLY(s.y, h));
}



/// Converte da coordinate virtuali logiche a fisiche (tra 0..W in orizzontale, crescente verso dx)
/// @param m la matrice di proiezione, che trasforma un punto da coordinate logiche a coordinate opengl-viewport
template<class T>
inline T WindowToScreenX(const ViewPortMatrix & m, const math::Point3<T> & p, T w)
	{
	double u = (m[0] * p.x + m[1] * p.y + m[2] * p.z + m[3])/(m[8] * p.x + m[9] * p.y + m[10] * p.z + m[11]);
	return GLToScreenX<T>(u, w);
	}
	
/// Converte da coordinate virtuali a fisiche (tra 0..h in verticale, crescente verso il basso)	
/// @param m la matrice di proiezione, che trasforma un punto da coordinate logiche a coordinate opengl-viewport
template<class T>
inline T WindowToScreenY(const ViewPortMatrix & m, const math::Point2<T> & p, T h)
	{
	double v = (m[4] * p.x + m[5] * p.y + m[6] * p.z + m[7])/(m[8] * p.x + m[9] * p.y + m[10] * p.z + m[11]);
	return GLToScreenY<T>(v, h);
	}

/// Converte da coordinate logiche (x,y,z) a opengl-viewport (-1..1) (proiezione)
template<class D, class S>
inline math::Point2<D> WindowToGL(const ViewPortMatrix & m, const math::Point3<S> & p)
	{
	D u = m[0] * p.x + m[1] * p.y + m[2] * p.z + m[3];
	D v = m[4] * p.x + m[5] * p.y + m[6] * p.z + m[7];
	D w = m[8] * p.x + m[9] * p.y + m[10] * p.z + m[11];
	return math::Point2<D>( u/w, v/w );
	}
/// calcola la proiezione 	
template<class T>
inline math::Point2<T> Project(const ViewPortMatrix & m, const math::Point3<T> & p)
	{
	T u = m[0] * p.x + m[1] * p.y + m[2] * p.z + m[3];
	T v = m[4] * p.x + m[5] * p.y + m[6] * p.z + m[7];
	T w = m[8] * p.x + m[9] * p.y + m[10] * p.z + m[11];
	return math::Point2<T>( u/w, v/w );
	}
	
/// calcola il prodotto per una matrice viewport e un punto 3D, ottenendo un punto (u*z,v*z,z)
template<class T>
inline math::Point3<T> Multiply(const math::TMatrix<double, 3,4> & m, const math::Point3<T> & p)
        {
        return math::Point3<T>( m[0] * p.x + m[1] * p.y + m[2] * p.z + m[3],
                          m[4] * p.x + m[5] * p.y + m[6] * p.z + m[7],
                          m[8] * p.x + m[9] * p.y + m[10] * p.z + m[11]  );
        }       

/// calcola la proiezione di un punto (u',v',w') = M (u,v,1)
template<class T>
inline math::Point3<T> Project(const math::TMatrix<double,3,3> & M, const math::Point2<T> & p)
        {
        T u = M[0] * p.x + M[1] * p.y + M[2];
        T v = M[3] * p.x + M[4] * p.y + M[5];
        T w = M[6] * p.x + M[7] * p.y + M[8];
        return math::Point3<T>(u,v,w);
        }
/// calcola la proiezione di un punto (u',v',1) = M (u,v,1)
template<class T>
inline math::Point2<T> BackProject(const math::TMatrix<double,3,3> & M, const math::Point2<T> & p)
        {
        T u = M[0] * p.x + M[1] * p.y + M[2];
        T v = M[3] * p.x + M[4] * p.y + M[5];
        T w = M[6] * p.x + M[7] * p.y + M[8];
        return math::Point2<T>(u/w,v/w);
        }

/// Converte da coordinate logiche a fisiche (0,0 .. w,h) (proiezione)
template<class D, class S>
inline math::Point2<D> WindowToScreen(const ViewPortMatrix & m, const math::Point3<S> & p, D w, D h)
	{
	math::Point2<D> g = WindowToGL<D, S>(m, p);
	return math::Point2<D>( GLToScreenX<D>(g.x, w), GLToScreenY<D>(g.y, h)  );
	}

/// Dato un punto in coordinate opengl (-1..1) lo converte nei punti x,y (con z fissato dentro la matrice inversa I)
template<class T>
inline math::Point2<T> GLToWindow(const math::TMatrix<double,3,3> & I, const math::Point2<T> & p)
	{
	T u = I[0] * p.x + I[1] * p.y + I[2];
	T v = I[3] * p.x + I[4] * p.y + I[5];
	T w = I[6] * p.x + I[7] * p.y + I[8];
	return math::Point2<T>( u/w, v/w );
	}

/// Dato un punto in coordinate opengl (-1..1) lo converte nei punti x,y (con z fissato dentro la matrice inversa I)
template<class T>
inline math::Point3<T> GLToWindow(const math::TMatrix<double,3,3> & I, const math::Point2<T> & p, double z)
	{
	T u = I[0] * p.x + I[1] * p.y + I[2];
	T v = I[3] * p.x + I[4] * p.y + I[5];
	T w = I[6] * p.x + I[7] * p.y + I[8];
	return math::Point3<T>( u/w, v/w, z);
	}

/// Dato un punto in coordinate schermo (0..w, 0..h) lo converte in coordinate x,y (con z fissata dentro la matrice inversa I)
template<class T>
inline math::Point2<T> ScreenToWindow(const math::TMatrix<double,3,3> & I, const math::Point2<T> & p, T w, T h)
{
      return GLToWindow(I, ScreenToGL(p, w, h) );
}

/// Ritorna la matrice per convertire da coordinate viewport-opengl in coordinate schermo
ViewPortMatrix GOLD_UI_EXPORT ScreenMatrix(double w, double h);

/// Ritorna la matrice per convertire da coordinate logiche (m) a coordinate schermo
ViewPortMatrix GOLD_UI_EXPORT ScreenMatrix(const ViewPortMatrix & m, double w, double h);


  } // namespace win
} // namespace ui

#endif
