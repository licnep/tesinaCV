#ifndef _CSKINWIDGETS_H
#define _CSKINWIDGETS_H

#include <boost/function.hpp>

#include <UI/CWindows/CWidget.h>
#include <Data/CImage/CImage.h>
#include <UI/CWindows/CWindowTypes.h>
#include <UI/CWindows/CWindowCore.h>
#include <UI/CWindows/CWindowCoreManager.h>
#include <Data/CImage/Pixels/RGBA8.h>
#include <UI/gold_ui_export.h>

namespace ui {
namespace win {

/// Pulsante multistato
/// @note la callback viene chiamata prima di eseguire la refresh del pulsante. Pertanto qualunque modifica apportata al pulsante all'interno della callback
///       sara' mostrata dalla refresh successiva interna alla interact.
class GOLD_UI_EXPORT CSkinButton : public CWidget
{
public:
        typedef boost::function<void ()> OnClick;

public:
        /** @param x,y coordinata dove mettere il pulsante
         *  @param callback una boost::function chiamato quando il pulsante viene premuto
         *  @param Button Immagine del pulsante in stato normale
         *  @param ButtonPressed Immagine quando viene premuto
         *  @param status iniziale stato del pulsante (0: normale, 1: premuto, 2: disabilitato, 3: illuminato)
         **/
        CSkinButton(float x, float y, OnClick callback, const cimage::CImage & Button, const cimage::CImage & ButtonPressed, int status = 0) :
                m_x(x), m_y(y), m_w(Button.W()), m_h(Button.H()), m_callback(callback), m_button(Button.Clone()), m_buttonPressed(ButtonPressed.Clone()), m_status(status)
        {
                
        }

        /** @param x,y coordinata dove mettere il pulsante
         *  @param w,h dimensioni logiche del pulsante
         *  @param callback una boost::function chiamato quando il pulsante viene premuto
         *  @param Button Immagine del pulsante in stato normale
         *  @param ButtonPressed Immagine quando viene premuto
         *  @param status iniziale stato del pulsante (0: normale, 1: premuto, 2: disabilitato, 3: illuminato)
         **/
        CSkinButton(float x, float y, float w, float h, OnClick callback, const cimage::CImage & Button, const cimage::CImage & ButtonPressed, int status = 0) :
                m_x(x), m_y(y), m_w(w), m_h(h), m_callback(callback), m_button(Button.Clone()), m_buttonPressed(ButtonPressed.Clone()), m_status(status)
        {
                
        }

	// req
	virtual ~CSkinButton();


        /// Enable/Disabilita il pulsante
        /// 0: normale, 1: premuto, 2: disabilitato, 3: illuminato
        /// @note non esegue la refresh
        inline void SetStatus(int status) { m_status = status; }

        /// Seleziona l'immagine del pulsate quando il controllo e' disabilitato
        /// @note non esegue la refresh
        inline void SetDisableImage( const cimage::CImage & Button) { m_buttonDisabled = Button.Clone(); }

        /// Seleziona l'immagine quando il mouse e' sopra il controllo
        /// @note non esegue la refresh
        inline void SetHighlightImage( const cimage::CImage & Button) { m_buttonHighLight = Button.Clone(); }

        /// Seleziona l'immagine  del pulsante normale
        /// @note non esegue la refresh
        inline void SetImage( const cimage::CImage & Button) { m_button = Button.Clone(); } 

        /// Seleziona l'immagine quando il pulsante e' premuto
        /// @note non esegue la refresh
        inline void SetPressedImage( const cimage::CImage & Button) { m_buttonPressed = Button.Clone(); }

        /// Sposta il controllo
        /// @note non esegue la refresh
        inline void Move(float x, float y) { m_x=x;m_y=y;}

        /// Cambia la callback
        inline void SetCallback(OnClick callback) { m_callback = callback; }

        // metodo di interazione
        bool Interact(CWindowCoreManager* window, const CWindowEvent& event);
        // metodo di disegno
        int Draw(CWindowCore* window);
private:
        float m_x;
        float m_y;
        float m_w;
        float m_h;
        
        OnClick m_callback;
        cimage::CImage::SharedPtrType m_button, m_buttonPressed, m_buttonDisabled, m_buttonHighLight;
        // 0: normale, 1: premuto, 2: disabilitato, 3: illuminato
        int m_status;
};

/// Un pulsante che possiede due stati (0 1 2:Disattivo)
/// @note la callback viene chiamata prima di eseguire la refresh del pulsante. Pertanto qualunque modifica apportata al pulsante all'interno della callback
///       sara' mostrata dalla refresh successiva interna alla interact.
class GOLD_UI_EXPORT CSkinCheckBox : public CWidget
{
public:
        typedef boost::function<void (int)> OnClick;

public:
        /** @param x,y coordinata dove mettere il pulsante
         *  @param callback una boost::function chiamato quando il pulsante viene premuto con lo stato del pulsante (0,1)
         *  @param Button0 Immagine del pulsante in stato 0
         *  @param Button1 Immagine del pulsante in stato 1
         *  @param status iniziale stato del pulsante (0 1 2:disattivo)
         **/
        CSkinCheckBox(float x, float y, OnClick callback, const cimage::CImage & Button0, const cimage::CImage & Button1, int status = 0) :
                m_x(x), m_y(y), m_w(Button0.W()), m_h(Button0.H()), m_callback(callback), m_status(status)
        {
                m_button[0] = Button0.Clone();
                m_button[1] = Button1.Clone();
		if(m_status>1)
		  throw std::runtime_error("CSkinCheckBox status out of bound");
        }

        /** @param x,y coordinata dove mettere il pulsante
         *  @param w,h dimensioni logiche del pulsante
         *  @param callback una boost::function chiamato quando il pulsante viene premuto
         *  @param Button0 Immagine del pulsante in stato 0
         *  @param Button1 Immagine del pulsante in stato 1
         *  @param status iniziale stato del pulsante (0, 1 2: disabilitato)
         **/
        CSkinCheckBox(float x, float y, float w, float h, OnClick callback, const cimage::CImage & Button0, const cimage::CImage & Button1, int status = 0) :
                m_x(x), m_y(y), m_w(w), m_h(h), m_callback(callback), m_status(status)
        {
                m_button[0] = Button0.Clone();
                m_button[1] = Button1.Clone();
		if(m_status>1)
		  throw std::runtime_error("CSkinCheckBox status out of bound");
        }

        /// Imposta lo stato interno del pulsante
        /// @note non esegue la refresh
        inline void SetStatus(int status) { 
		m_status = status; 
		if(m_status>1)
		  throw std::runtime_error("CSkinCheckBox::SetStatus status out of bound");
	}

        /// Seleziona l'immagine del pulsante (0,1,2)
        /// @note non esegue la refresh
        inline void SetImage(int index, const cimage::CImage & Button) { m_button[index] = Button.Clone(); } 

        /// Sposta il controllo
        /// @note non esegue la refresh
        inline void Move(float x, float y) { m_x=x;m_y=y;}

        /// Cambia la callback
        inline void SetCallback(OnClick callback) { m_callback = callback; }

        // metodo di interazione
        bool Interact(CWindowCoreManager* window, const CWindowEvent& event);
        // metodo di disegno
        int Draw(CWindowCore* window);
private:
        float m_x;
        float m_y;
        float m_w;
        float m_h;
        
        OnClick m_callback;
        cimage::CImage::SharedPtrType m_button[3];
        int m_status;
};

#if 0


class CSkinDial : public CWidget
{
    public:

        typedef boost::signal<void (float)>::slot_type OnClick;

        CSkinDial(const std::string& caption, float x, float y, float width, OnClick callback_fun, const CImage& graphics, bool enabled = true);

        bool Interact(CWindowCoreManager* window, const CWindowEvent& event);

        int Draw(CWindowCore* window);

        bool m_enabled;

    private:

        std::string m_caption;
        float m_x;
        float m_y;
        float m_width;
        float m_w;
        float m_h;

        boost::signal<void (float)> m_callback;

        CWindowSurface m_cursor;
        CWindowSurface m_disabled_cursor;
        CWindowSurface m_bg;
        CWindowSurface m_disabled_bg;

        float m_position;
        float m_mouse_x;
        float m_mouse_y;
        bool m_status;
};

#endif

} // namespace win
} // namespace ui

#endif
