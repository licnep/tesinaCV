// la guida Doxy sulle CWindow si trova in http://vislab.unipr.it/GOLD/doxy/html/classCWindow.html
//  una breve introduzione in http://vislab.unipr.it/GOLD/doxy/html/win.html
#ifndef _C_WINDOWS_H
#define _C_WINDOWS_H

/** \file CWindow.h
 * \author Paolo Medici (medici@ce.unipr.it)
 * \brief This file handle the class CWindow. The (client) interface to manage and draw on window.
 * 
 * la classe CWindow e' la classe che lo sviluppatore di GOLD usa per disegnare e gestire le finestre e 
 *  l'output grafico. Una breve introduzione \ref win
 */
#include <vector>

#include <boost/function.hpp>

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <UI/CWindows/CWindowTypes.h> // alcune dichiarazioni
#include <UI/CWindows/CWindowLayer.h>  // 
#include <UI/CWindows/TPointCast.h>    // cast
#include <UI/CWindows/XImgProc.h>
#include <UI/CWindows/CWindowInternal.h>

#include <Processing/Math/Lines.h>     // clip
#include <Data/CImage/TImage.h>

#include <UI/gold_ui_export.h>


// FIXME: Windows definisce una macro chiamata DrawText che va in conflitto con un metodo delle CWindows
// bisognerebbe cambiare il nome, intanto che ci pensiamo undefiniamo la  macro.
// Questo impone di includere CWindow.h come ultimo file nei moduli che generano problemi
#ifdef WIN32
#undef DrawText
#endif

#ifdef ENABLE_XML_WINDOW
// forward declaration
class TiXmlDocument;
class TiXmlElement;
#endif

namespace vl{ namespace ini {class INIFile;} } using vl::ini::INIFile;



namespace ui {

/** \brief Namespace for data visualization: the CWindow library */
namespace win {

  // FW
class CWindowCoreManager;
class CWindowCommand;
class CDrawingObject;

typedef boost::shared_ptr<CWindowCommand> SPWindowCommand;
}
}

//
// namespace boost {
    // template<>
    // void delete_clone<ui::win::CWindowCoreManager>( const ui::win::CWindowCoreManager* r );
// }

/// Broadcast a message to all Cores
#define BC_ALL_CORES	-1

namespace ui {
namespace win {

#ifdef USE_BOOST_SIGNAL2
	typedef boost::signals2::signal<void (const cimage::CImage& )> GrabCImage_t;
#else
	typedef boost::signal<void (const cimage::CImage& )> GrabCImage_t;
#endif

typedef GrabCImage_t::slot_type OnGrabCImage;

////////////////////////////////////////////////////////////////////////

/** \brief CWindow e' la classe base per accedere al rendering e alla gestione di finestre in GOLD
 * 
 * CWindow permettono di disegnare primitive grafiche astraendo l'hardware.
 * L'hardware e le librerie su cui CWindow si basa sono specificate all'interno di windows.ini, 
 *  nella chiave GUI DRIVER.
 *
 * Il sistema delle finestre e' in genere basato su un architettura Client-Server, su thread separati. 
 * I comandi di disegno pertanto non sono bloccanti, tantomento le chiamate Refresh nei suoi parametri 
 *  di default.
 * I comandi di disegno vengono impilati su una coda di costruzione dei disegni. Tale coda deve essere 
 *  svuotata attraverso chiamate a funzione come Clear. Infatti, anche se non visibili, le primitive disegnate 
 *  ma sovrascritte rimangono nella coda.
 * Le primitive di proprieta' (SetColor,SetBlend) sono da considerarsi come primitive a tutti gli effetti.
 *  La Clear agisce anche su di loro e le cancella. 
 *
 * Il comando refresh non fa altro che copiare gli elementi della coda di costruzione, nella coda di disegno.
 * Per come e' strutturato il sistema client-server le chiamate di disegno sono asincrone, mentre le chiamate 
 *  di richiesta di info (GetSize, GetTitle) sono sincrone.
 *
 * Le coordinate dei punti nelle finestre sono nel formato standard per i video, percio' la X crescente verso 
 *  destra, e la Y crescente verso il basso.
 * Le coordinate sono relative alla risoluzione logica della finestra, percio' indipendenti dalla effettiva 
 *  dimensione che questa ha sullo schermo.
 *  
 * In questa versione e' possibile disegnare anche su piu' layer sovrapposti, attraverso le chiamate SetLayer.
 *  La Clear cancella solo il Layer corrente! Per Cancellare tutti i Layer usare la ClearAllLayers.
 *
 * Oltre alle primitive base (punti, cerchi, rettangoli, immagini, testo) sono disponibili forme di disegno 
 *  complesse, come poligoni, istogrammi, crocette, frecce e cosi via.
 *
 * \code
 * ui::win::CWindow *win;
 * // ... create the Window:
 * win = new ui::win::CWindow("Title", Width, Height);
 * // ... show the window;
 * win->Show();
 * // ...
 * win->Clear();
 * win->DrawSomething(...);
 * win->Refresh();
 * // ...
 * delete win;
 * \endcode
 *
 * Esempio di disegno semplice di una CImage:
 * \code
 * win->Clear();
 * win->DrawImage(img);
 * win->Refresh();
 * \endcode
 *
 * CWF_RESET cancella lo sfondo, a differenza di CWF_DEFAULT che cancella lo sfondo, ma obbliga l'uso del CTRL per 
 *  premere il pulsante.
 *
 * Normalmente per poter usare i pulsanti o altri widget e' necessario impostare la flag CWF_KEY_HANDLE. In questa
 *  modalita' i Widget hanno priorita' sullo spostamento della finestra.
 *
 * Guardare l'elenco delle flag di creazione per la finestra in CWINDOW_FLAG (stretched, fullscreen, etc etc).
 *
 * Elementi di disegno extra sono presenti nei seguenti file: CWindowControls.h ExtraWidget.h TDebugWidget.h
 *
 * Per quanto riguarda i viewport e le camere 3D guardare anche gli esempi nel file CWindowCamera.h per settare le camere
 */
class GOLD_UI_EXPORT CWindow 
{
  typedef std::vector<boost::shared_ptr<CWindowCoreManager> > core_t;
  
 private:
 
  /// Driver used to allocate object (TODO: move in CWindowLibManager)
  static std::string g_driver; 

  /// Client Side Layer list. 
  ///  Attuale coda di disegno (una mappa di Layer)
  CDrawerList m_queue;
  
  /// Il Layer corrente di disegno
  unsigned int m_curLayer; 

  /// L'oggetto Window-Server associato a questa CWindow che eseguira' il rendering vero e proprio
  mutable core_t m_windowCores;
  
  /// Number of soft refresh poned
  unsigned int m_softRefreshCount;
  
  /// Lista eventi locali
  CWindowEventList Event; 

private:
  // Avoid CWindow be copied
  CWindow(CWindow const& src) {}

  /*@{*/
  // push interno, non deprecato
  bool push(CWidget * DObj)   {
	  Layer(m_curLayer).Push(SPDrawingObject(DObj));
  	  return true;
  	}
  bool push(const SPDrawingObject& DObj)   {
	  Layer(m_curLayer).Push(DObj);
  	  return true;
  	}
  bool push(const CDrawingQueue& DObj)   {
	  Layer(m_curLayer).Push(DObj);
  	  return true;
  	}
  /*@}*/
  
    /** Disegna un Point2f. Funzione interna **/
   bool _DrawPixel(const math::Point2f& p);
   /** Disegna un Point3f. Funzione interna **/
   bool _DrawPixel(const math::Point3f& p);
   /** Disegna un C4UB_V3F_t. Funzione interna **/
   bool _DrawPixel(const C4UB_V3F_t& p);
   /** Disegna un T2F_V3F_t. Funzione interna **/
   bool _DrawPixel(const T2F_V3F_t& p);

 // funzioni interne: per ridurre il numero di copie viene usato std::swap
 /*@{*/

   /** Disegna una serie di Point2f. Funzione interna. Buffer is destroyed **/
   bool _DrawPixels(std::vector<math::Point2f>& p);
   /** Disegna una serie di Point3f. Funzione interna. Buffer is destroyed **/
   bool _DrawPixels(std::vector<math::Point3f>& p);
   /** Disegna una serie di C4UB_V3F_t. Buffer is destroyed **/
   bool _DrawPixels(std::vector<C4UB_V3F_t>& p);
   /** Disegna una serie di T2F_V3F_t. Buffer is destroyed **/
   bool _DrawPixels(std::vector<T2F_V3F_t>& p);
  
   /** Disegna un poligono in 2 dimensioni**/
   bool _DrawPolygon(std::vector<math::Point2f>& v, bool filled);
   /** Disegna un poligono in 3 dimensioni **/
   bool _DrawPolygon(std::vector<math::Point3f>& v, bool filled);
//    /** Disegna un poligono in 3 dimensioni, con i vertici colorati **/
//    bool _DrawPolygon(std::vector<C4UB_V3F_t>& v, bool filled);

   /// used internally by TDrawTriangles. Buffer is destroyed
   bool _DrawTriangles(std::vector<math::Point2f>&  vertex);
   /// used internally by TDrawTriangles. Buffer is destroyed
   bool _DrawTriangles(std::vector<math::Point3f>&  vertex);
   /// used internally. Buffer is destroyed
   bool _DrawTriangles(std::vector<C4UB_V3F_t>& p);
   /// used internally. Buffer is destroyed
   bool _DrawTriangles(std::vector<T2F_V3F_t>& p);

   /// Disegna una collezione di linee formate dalle coppie di due vertici (segmento)
   ///  Questa non crea una polilinea, ma e' solo una forma di rendering ottimizzato (quando possibile) di 
   ///  un numero di linee (segmenti)
   /// DrawPolygon dall'altra parte permette di disegnare polilinee.
   bool _DrawLines(std::vector<math::Point2f>& vertex);
   bool _DrawLines(std::vector<math::Point3f>& vertex);
   bool _DrawLines(std::vector<C4UB_V3F_t>& vertex);
 
   /** Disegna un array di quadrilateri. Buffer is destroyed **/
    bool _DrawQuads(std::vector<math::Point2f>& vertex);
    /** Disegna un array di quadrilateri. Buffer is destroyed **/
    bool _DrawQuads(std::vector<math::Point3f>& vertex);
   /** Disegna una serie di C4UB_V3F_t. Buffer is destroyed **/
    bool _DrawQuads(std::vector<C4UB_V3F_t>& p);
   /** Disegna una serie di T2F_V3F_t. Buffer is destroyed **/
    bool _DrawQuads(std::vector<T2F_V3F_t>& p);
   
/*@}*/

// funzioni interne a template
/*@{*/
   /// Internal function of DrawCrossArray
   template<class D, class T>
   bool TDrawCrossArray(const T& v, unsigned int nCross, double size)
   {
        std::vector<D> vertex(nCross * 4);
	for(unsigned int i=0;i<nCross;i++)
		{
		vertex[i*4 + 0].x = v[i].x;
		vertex[i*4 + 0].y = v[i].y - size * 0.5;
		vertex[i*4 + 1].x = v[i].x;
		vertex[i*4 + 1].y = v[i].y + size * 0.5;
		
		vertex[i*4 + 2].x = v[i].x - size * 0.5;
		vertex[i*4 + 2].y = v[i].y;
		vertex[i*4 + 3].x = v[i].x + size * 0.5;
		vertex[i*4 + 3].y = v[i].y;
		} 
	return _DrawLines(vertex);
	}
	
   /// Used internally by DrawQuads e DrawQuads3
   template<class D, class T>
   bool TDrawQuads(const T& v, unsigned int nBoxes, bool filled)
   {
   if(filled)
    {
    // Converto in Point2f
    std::vector<D> vertex(nBoxes * 4);
    ccopy_n(vertex, v, nBoxes * 4);
    return _DrawQuads(vertex);
    }
    else
    {
    // trasformo in lineStream (TODO: compattare)
    std::vector<D> line(nBoxes * 8);
    for(unsigned int i =0;i<nBoxes;i++)
        {
        line[i * 8 + 0] = v[i*4 + 0];
        line[i * 8 + 1] = v[i*4 + 1];

        line[i * 8 + 2] = v[i*4 + 1];
        line[i * 8 + 3] = v[i*4 + 2];

        line[i * 8 + 4] = v[i*4 + 2];
        line[i * 8 + 5] = v[i*4 + 3];

        line[i * 8 + 6] = v[i*4 + 3];
        line[i * 8 + 7] = v[i*4 + 0];
        }
    return _DrawLines(line);
    }
   }

   /** Disegno di poligono con conversione dei punti.
    *
    * Chiede all'oggetto @a obj un elenco di punti usando l'operatore [] 
    * @param obj un oggetto a cui chiedere i @a _VertexNo punti
    * @param _VertexNo numero di vertici del poligono
    * @param closed chiuso?
    * @param filled riempito
    * @note i punti richiesti a obj devono essere castabili a Point2f 
    */
   template<class D, class T>
   bool TDrawPolygon(const T& obj, unsigned int VertexNo, bool closed, bool filled)
	{
	unsigned int FinalVertexNo = (closed) ? (VertexNo + 1) : (VertexNo);
	std::vector<D> Vertex (FinalVertexNo);
	ccopy_n(Vertex, obj, VertexNo);
	if(closed)
		Vertex[VertexNo]=Vertex[0];
	return _DrawPolygon(Vertex, filled);
	}

   /** Funzione disegno di vettori di segmenti (line stream)  
    * @note i punti richiesti a obj devono essere castabili a Point2f */
   template<class D, class T>
   bool TDrawLines(const T& obj, unsigned int nLines)
   {
   std::vector<D> vertex(nLines * 2);
   ccopy_n(vertex, obj, nLines * 2);
   return _DrawLines(vertex);
   }

   /** Funzione disegno di vettori di segmenti (line stream)  
    * @note i punti richiesti a obj devono essere castabili a Point2f */
   template<class D, class T>
   bool TDrawColorLines(const T& obj, unsigned int nLines)
   {
   std::vector<D> vertex(nLines * 2);
   ccopy_n(vertex, obj, nLines * 2);
   return _DrawLines(vertex);
   }
   
   template<class D, class T>
   bool TDrawTriangles(const T& v, unsigned int nTriangles, bool filled)
   {
   if(filled)
    {
    // Converto in Point2f
    std::vector<D> vertex(nTriangles * 3);
    ccopy_n(vertex, v, nTriangles * 3);
    return _DrawTriangles(vertex);
    }
    else
    {
    // trasformo in lineStream
    std::vector<D> vertex(nTriangles * 6);
    for(unsigned int i =0;i<nTriangles;i++)
        {
        vertex[i*6+0] = vertex[i*6+5] = v[i*3];
        vertex[i*6+2] = vertex[i*6+1] = v[i*3+1];
        vertex[i*6+4] = vertex[i*6+3] = v[i*3+2];
        }
    return _DrawLines(vertex);
    }
   }


/*@}*/

protected:  
  /// Ritorna il layer associato al layer @a layer
  CWindowLayer& Layer(int layer);

public:
   // Constructor.
   /** costruttore
    * @param Title una stringa che indica il titolo che compararira' sulla finestra
    * @param XPos,YPos le coordinate x,y dell'angolo superiore a sinistra della finestra. Se impostate a -1 viene lasciato al WindowManager il loro posizionamento
    * @param Width,Height Dimensione della finestra (logica e fisica)
    * @param Flags (opzionale) Flag speciali della finestra CWINDOW_FLAGS
    * @see CWINDOW_FLAGS
    **/
   CWindow(const std::string& Title, int XPos, int YPos, unsigned int Width, unsigned int Height, int Flags=CWF_DEFAULT);
   /** costruttore
    * @param Title una stringa che indica il titolo che compararira' sulla finestra
    * @param Width,Height Dimensione della finestra (logica e fisica)
    * @param Flags (opzionale) Flag speciali della finestra CWINDOW_FLAGS
    * @see CWINDOW_FLAGS
    **/
   CWindow(const std::string& Title = std::string(), unsigned int Width=320, unsigned int Height=240, int Flags=CWF_DEFAULT);

   /** Costruttore
    *
    * Esempio per creare una Dummy window:
    * \code
    * CWindow *win = new CWindow(CWindow::Null);
    * \endcode
    **/
   CWindow(const WindowCreationParams& params);

   /** \brief Distruttore della classe CWindow
   * Serve per distruggere CWindowCore e liberare tutta la memoria allocata dalla finestra
   */
   ~CWindow(void);

  /** Reset the window parameters and create one new
   * @param params WindowCreationParams
   **/
  bool ResetWindow(const WindowCreationParams& params);
  
  /** Allocate a new CWindow Back-End. @return the Backend ID */
  int AllocateNewBackend(const std::string& driver, const WindowCreationParams& params);

  /** Remove all BackEnd */
  bool RemoveAllBackend();
  
  /** searches in core list the core name and returns the ID associated */
  int GetCoreID(const std::string& coreName) const;
  
  /////////////////////////////////////////////////////////////////////////////////////////
  /** @name Custom control/object command */
  /*@{*/
  /** Custom control can be sended using this functions */
  bool SendCommand(CWindowCommand * WCmd, int Target = BC_ALL_CORES) const;

  bool SendCommand(const SPWindowCommand& WCmd, int Target = BC_ALL_CORES) const;

  /** Aggiunge un controllo gia' con lo shared_pointer. L'utente esterno detiene l'istanza 
   * \code
   *  m_cal = boost::shared_ptr< CalibrationWidget<double> > ( new CalibrationWidget<double>() );
   *  // .. do something ... 
   *  win->Push(m_cal); // note: increase reference count by 1
   *  // or (if you do not need to have a copy of the object but only push custom object in queue)
   *  win->Push(SPDrawingObject( new MyWidget(parameters)  ) ); 
   * \endcode
  **/
  bool Push(const SPDrawingObject& spobj) { return push(spobj); }
  
  /** It is possibile to push an entire DrawingQueue at the time 
    */
  bool Push(const CDrawingQueue& queue) { return push(queue); }

  /** Return a string containing information on existing driver in order to handle it externally */
  std::string GetConnectionString(int idx = 0) const;

  /** stub per il CWindow::Push */
   inline CWindow& operator << (const SPDrawingObject& obj) { push(obj); return *this; }
  /** stub per inserire altri oggetti coda */   
   inline CWindow& operator << (const CDrawingQueue& obj) { push(obj); return *this; }

  /** permette di inserire un widget generico T nella CWindow attraverso la sintassi:
    * \code
    * *myWin << MyCustomDrawing(parameters);
    * \endcode
    **/
  template<class T>
  inline CWindow& operator << (const T& obj) {
      T* p = new T(obj);
      push(SPDrawingObject(p));
      return *this; 
      
  }

//   /// Inserisce il contenuto di una CWINDOW dentro un'altra!
//   void operator << (const CWindow& src);

//   /// Inserisce il contenuto di una CWINDOW dentro un'altra!
//   void operator >> (CWindow& src) const;

  /*@}*/
  /////////////////////////////////////////////////////////////////////////////////////////
  
  /// Allocate and/or Enable a GUI plugin
  bool AllocatePlugin(const std::string& pluginname);
  
  /// Insert an User Plugin in all the CWindowCore
  bool InsertPlugin(SPDrawingObject widget);
  
  /////////////////////////////////////////////////////////////////////////////////////////
  
  /** test if this window is for an embedded environment: no output **/
  bool IsEmbedded() const; /* { return m_windowCores.empty(); } */
  
  /** @name Comandi di gestione della finestra */
  /*@{*/
   /// Mostra la finestra o la Nasconde
   bool SetVisibility(bool _visibility);
   
   /// Show the window
   inline bool Show(void) { return SetVisibility(true); }
   
   /// Hide the window
   inline bool Hide(void) { return SetVisibility(false); }

   /// Mostra le decorazioni della finestra o le toglie
   bool SetDecoration(bool dec, int Target = BC_ALL_CORES);
   
   /** ottiene lo stato di visibilita' della finestra
    *   visto che capita spesso che la chiamata IsVisible venga fatta dalle funzionalita, 
    *   esiste anche la versione ThreadSafe. 
    *  @param ThreadSafe se fare la chiamata ThreadSafe (e bloccante) o meno. 
    *  @note la versione ThreadSafe presenta alcuni problemi con alcuni Window Manager (fluxbox)
    **/
   bool IsVisible(bool ThreadSafe=false) const;

   /// Set the window title
   bool SetTitle(const std::string& _title);
   
   /// Ottiene il titolo della finestra (chiamata sincrona)
   bool GetTitle(std::string& buffer) const;

   /// Imposta la posizione sullo schermo della finestra
   bool SetPosition(int _x,  int _y);
   
   /// Ritorna la posizione sullo schermo della finestra (chiamata sincrona)
   bool GetPosition(int& _x, int& _y);
   
   /// Return the screen geometry in pixels (chiamata sincrona)
   bool GetScreenGeometry(ScreenGeometry& geometry);
   
   /** set the virtual coordinate in the 2d viewport
    *  Imposta il viewport
    * @param x0,y0 the logical coordinates of Top-Left window corner
    * @param x1,y1 the logical coordinates of Bottom-Right window corner
    * @param widget se gestire questo metodo come widget o come comando
    * \code
    * SetVirtualView(0,0,640,480); // default
    * SetVirtualView(10.0,10.0,-10.0,0.0); // a kind of World Viewport in meters
    * \endcode
    * @note vedi i commenti di SetVirtualView riguardo all'utilizzo come CWidget
    **/
   bool SetVirtualView(double x0, double y0, double x1, double y1);
   
   /** Imposta le coordinate virtuali di disegno
    * @param baseWidth,baseHeight dimensioni logiche della finestra
    * @param widget se gestirlo come widget o come comando: 
    *                se true viene usato il widget e vale per tutti i widget successivi,
    *                se false e' usato come comando e vale globalmente sulla finestra
    * @note SetVirtualView puo' essere anche un CWidget di disegno
    *       pertanto viene attivato alla successiva Refresh ma comunque
    *       mantiene il suo stato fino a una nuova SetBaseSize
    **/
   bool SetVirtualView(unsigned int baseWidth,  unsigned int baseHeight);
   
   /** Set the Camera Layer.
    * @note in this version any Layer is bounded with a Camera.
    * \code
    *   // camera 2D
    *   win->SetCamera (sharedPtrWindowCamera(new CWindowCamera2D(x0,y0,x1,y1)) );
    *   // camera 3D
    *   boost::shared_ptr<CWindowCamera3D> m_camera;
    *   m_camera = boost::shared_ptr<CWindowCamera3D>(new CWindowCamera3D(0.569313 , 0.309703, 0.0, 0.0, 5.4675, 0.665, 0.0, -6.65127 , -11.777, 8.83153) );
    *   win->SetCamera(m_camera);
    * \endcode
    * @see examples in CWindowCamera3D in CWindowCamera.h
    **/
   bool SetCamera(sharedPtrWindowCamera camera);

   /** change the viewport mode:
     * @param mode choose between WCVM_CAMERA o WCVM_SCREEN 
     * @see CWindowTypes.h
     * @note it is a widget and affect all following widget. WCVM_CAMERA is a normal camera (2D or 3D based on SetCamera),
     *       WCVM_SCREEN uses screen coordinate (1pixel)
     **/
   bool SetViewportMode(ViewPortMode mode);
   
   /** Set The Layer ViewPort. Any Layer can have a different ViewPort. 
    *imposta la dimensione del viewport in modo da realizzare delle sottoregioni della finestra */
   bool SetViewport(const CWindowViewPort& viewport);

   /// imposta la dimensione (fisica) della finestra 
   /// @param width,height dimensioni fisiche della finestra (pixels)
   bool SetSize(unsigned int width, unsigned int height);
   /// ritorna le dimensioni della finestra
   bool GetSize(unsigned int& _width, unsigned int& _height);

   /// imposta la modalita FullScreen per la finestra. Ctrl+F e' il tasto associato a questa feature.
   bool SetFullScreenMode(bool _fullScreenMode);
   
   /// chiede alla finestra se e' in stato Fullscreen
   bool IsFullScreen(void) const;

   /// chiede alla finestra se e' in stato ridotto a icona
   bool IsIconic(void) const;
      
   /// imposta il testo nella status bar utente
   bool SetCustomStatusBar(const std::string& text);
   
   /// Set the background color
   bool SetBackgroundColor(const cimage::RGBA8& color, int Core = BC_ALL_CORES);  

   /// Set an opacity Mask to be applyed on window
   template<class T>
   bool SetWindowShape(const T& img, const cimage::RGBA8& colorkey);
   
   /*@}*/

   /** return the count of software refresh */
   unsigned int GetSoftRefreshCount() const { return m_softRefreshCount; }
   
   /** \brief Chiede che la finestra venga aggiornata e che cominci un nuovo frame.
    * @note Questa chiamata puo' essere opzionalmente sincrona
    * @param sync (opzionale) se true la chiamata e' bloccante e attende che la finestra sia ridisegnata prima di ritornare
    * **/
   bool Refresh(bool sync=false);

//    /// Riempie la coda @a queue con i widget della CWindow corrente
//    void ExportWidget(CDrawingQueue& queue);

   /** Force system to dump image
    * @param filename an optional file where save image. Null save in the OUTPUT PATH with WINDOW OUTPUT FILE NAME
    * @note there are no way to know if this operation success! 
    **/
   bool Dump(const std::string& filename = std::string(), int SrcCore=0) const;
   
   /** Grab an Image from a CWindowCore */
   cimage::SharedPtrConstType GrabImage(int SrcCore=0) const;

   // Drawing Context Modifiers
   
    /** @name Imposta il colore di disegno
    * \code
    * RGBA8 border(255,255,255, 230);  // ~90% trasparent white    
    * // ...
    * win->SetColor(border);
    * win->SetColor(0,0,255);           // opaque blue
    * \endcode
    **/
   /*@{*/

    /** Set using an RGBA8 color
    * \code
    * RGBA8 white(255,255,255);    // white
    * /// ...
    * win->SetColor(white);
    * \endcode
    **/
   bool SetColor(const cimage::RGBA8& color);
   
   /** Set using an RGB8 Color **/
   inline bool SetColor(const cimage::RGB8& c) 
   	{ 
   	return SetColor(cimage::RGBA8(c.R, c.G, c.B, 255)); 
   	}
   
   /** Set a greyscale color **/
   inline bool SetColor(unsigned char grey, unsigned char alpha=255) 
   	{ 
   	return SetColor(cimage::RGBA8(grey, alpha)); 
   	}
    
    /**
    * \code
    * win->SetColor(255,0,0);   // Red
    * win->SetColor(255,0,0,127);   // 50% transparency
    * \endcode
    **/
   inline bool SetColor(unsigned char red, unsigned char green, unsigned char blue, unsigned char alpha=255) 
     	{ 
     	return SetColor(cimage::RGBA8(red, green, blue, alpha)); 
     	}
   /*@}*/

   ///@name ZBuffer
   /*@{*/
   /** Abilita lo ZBuffer
     * @param near la distanza minima dalla telecamera (deve essere > 0 strettamente)
     * @param far la distanza massima dalla telecamera 
     **/
   void EnableZBuffer(double near, double far);

   /** Disabilita lo ZBuffer **/
   void DisableZBuffer();
   /*@}*/

   ///@name Blending
   /*@{*/
   /** imposta se abilitare o meno l'alpha bleending
    *
    * Gli elementi disegnati di seguito verrano influenzati dalle impostazioni dell'Alpha Blend selezionato. 
    *  Il valore della trasparenza e' specificato nel canale alpha di SetColor 
    * @param blend uno dei valori di BlendType_t.
    * \code
    * win->SetBlend(BLEND_ALPHA); // abilita l'alpha blending
    * win->SetBlend(BLEND_OFF);   // disabilita l'alpha blending
    * \endcode
    */
   bool SetBlend(BlendType_t blend);
   
   /** abilita l'alpha blending **/
   inline bool EnableBlend(void) {
        return SetBlend(BLEND_ALPHA);
        }
   /** disabilita l'alpha blending **/
   inline bool DisableBlend(void) {
        return SetBlend(BLEND_OFF);
        }
   /*@}*/

   /// Enable or Disabel Antialiasing on Line (line, polyline, rectangles, ...)
   bool SetLineSmoothing(bool enabled);

   /// Enable or Disabel Antialiasing on Points.
   bool SetPointSmoothing(bool enabled);

   /// Set the line width
   bool SetLineWidth(double lineWidth);

   /// Set the point size
   bool SetPointSize(double pointSize);

   /** Imposta la traslazione a cui tutte le successive chiamate saranno soggette.
    *   @param dx,dy valore di cui verranno traslate le successive primitive di disegno
    *   @param absolute se il valore e' assoluto (true) o relativo (false)
    *  @note attenzione che translate non agisce su Interact dei widget, i quali ricevono coordinate 
    *         mouse non traslate
    **/
   GOLD_UI_DEPRECATED bool Translate(double dx, double dy, bool absolute=false);

   // Drawing Functions: gestione dei Layer
   
   /** \brief Pulisce la coda di disegno
    *
    * la gestione delle finestre multithread obbliga a tenere una coda di disegno remota.
    *  I comandi di disegno infatti vengono posti in questa coda e mostrati al successivo Refresh.
    *  Gli oggetti in coda tuttavia non vengono cancellati automaticamente, ma un comando Clear deve essere inviato
    *  prima di cominciare un nuovo disegno
    *
    * @note Con la gestione a Layer viene cancellato solo il Layer selezionato in questo momento
    **/
   bool Clear(void);

   /** cancella uno specifico layer, anche diverso da quello corrente **/
   bool ClearLayer(int layer_no);
   
   /** cancella tutti i layer 
    *
    *   cancella tutti i layer superiori a quello fornito
    */
   bool ClearAllLayers(int layer0 = 0);

   /** \brief Tutto il codice delle CWindow scritto dopo SetLayer verra inserito in uno strato di disegno.
    * 
    * Nelle finestre possono esistere n layer di disegno sovrapposti.
    * Di default il Layer di disegno e' lo 0, ma altri layer sono disponibili al momento di farne la richiesta.
    * Tutte le chiamate di disegno e clear eseguite dopo questa chiamata si riferiscono al layer specificato.
    * \code
    * win->SetLayer(0); 
    * win->Clear(); // clear layer 0
    * // draw layer 0
    * // ...
    * {
    * win->SetLayer(1);
    * win->Clear(); // clear layer 1
    * // draw onto layer 1
    * win->Refresh(); // copy all queue
    * }
    * \endcode
    * @param LayerID un identificativo, positivio, del layer di lavoro. Per esempio 0 per background e per il 1 disegno normale
    * @return the old layer value
    **/
   int SetLayer(int LayerID);

   /** \brief Abilita/Disabilita un layer di disegno
    * @param LayerID un identificativo del layer. 
    * @param enable se abilitare (true) o meno (false) questo layer
    * @see SetLayer
    **/
   bool EnableLayer(int LayerID, bool enable);

   /** \brief Blocca un layer da modifiche
    * @param LayerID un identificativo del layer. 
    * @see SetLayer
    **/
   bool LockLayer(int LayerID);

   /** \brief Sblocca un layer da modifiche
    * @param LayerID un identificativo del layer. 
    * @see SetLayer
    **/
   bool UnLockLayer(int LayerID);

   /// Verifica se il Layer @a LayerID e' bloccato
   bool IsLayerLocked(int LayerID);

   // --- funzioni di disegno ---

   /** Disegna un pixel (2D function)
    * \code
    * win->DrawPixel(20,20);
    * \endcode
    **/
   template<class T>
   inline bool DrawPixel(T x, T y) {
   	return _DrawPixel(math::Point2f(x,y));
   }
   
   /** Disegna un pixel nello spazio tridimensionale
    * \code
    * win->DrawPixel(20,20,10);
    * \endcode
    **/
   template<class T>
   inline bool DrawPixel(T x, T y, T z)  {
   	return _DrawPixel(math::Point3f(x,y,z));
   }

    /** Disegna un pixel
    * \code
    * Point2d p (20,20);
    * // ...
    * win->DrawPixel(p);
    * \endcode
    **/
   template<class T>
   inline bool DrawPixel(const math::Point2<T>& t) {
   	return _DrawPixel(math::Point2f(t.x, t.y));
   	}

   /// Disegna un pixel in un environment 3D
   template<class T>
   inline bool DrawPixel(const math::Point3<T>& t) {
   	return _DrawPixel(math::Point3f(t.x, t.y, t.z));
   	}

   /// Disegna un Pixel Colorato
   inline bool DrawPixel(const C4UB_V3F_t& t) {
   	return _DrawPixel(t); 
   	}

   /// Disegna un Pixel Texturato
   inline bool DrawPixel(const T2F_V3F_t& t) {
   	return _DrawPixel(t);
   	}

   /** Disegna un array (o un std::vector) di punti
    * @param v un oggetto che possiede operator [] di oggetti che hanno variabili x e y
    * @param count numero di punti 
    * \code
    * Point2i p[100];
    * // ...
    * win->DrawPixels(p,100);
    * \endcode
    */
   template<class T>
   inline bool DrawPixels(const T * v, unsigned int NoPoints)
    {
	std::vector< math::Point2f > p(NoPoints);
	ccopy_n(p, v, NoPoints);
	return _DrawPixels(p);
    }

   /** Draw an array of Point3D in a 3D Viewport */
   template<class T>
   inline bool DrawPixels3(const T * v, unsigned int NoPoints)
    {
	std::vector< math::Point3f > p(NoPoints);
	std::copy(v[0], v[NoPoints], p.begin());
	return _DrawPixels(p);
    }

   /** Draw an array of Colored Point3D in a 3D Viewport */
   template<class T>
   inline bool DrawColorPixels3(const T * v, unsigned int NoPoints)
    {
	std::vector< C4UB_V3F_t > p(NoPoints);
	std::copy(v[0], v[NoPoints], p.begin());
	return _DrawPixels(p);
    }

   /** Draw an array of texture Point3D in a 3D Viewport */
   template<class T>
   inline bool DrawTexturePixels3(const T * v, unsigned int NoPoints)
    {
	std::vector< T2F_V3F_t > p(NoPoints);
	std::copy(v[0], v[NoPoints], p.begin());
	return _DrawPixels(p);
    }

   /** Disegna un std::vector di punti
    * @param v un oggetto che possiede operator [] di oggetti che hanno variabili x e y
    * @note se non si ha il metodo size o si vogliono disegnare meno punti usare la versione a 2 parametri di DrawPixels 
    * \code
    * std::vector<math::Point2i> p;
    * // ... some push_back 
    * win->DrawPixels(p);
    * \endcode
    */
   template<class T>
   inline bool DrawPixels(const T& v)
    {
	std::vector< math::Point2f > p( v.size() );
	ccopy_n(p, v, v.size());
	return _DrawPixels(p);
    }
    /// disegna un std::vector di punti 3D
    template<class T>
    inline bool DrawPixels3(const T& v)
    {
	std::vector< math::Point3f > p( v.size() );
	ccopy_n(p, v, v.size());
	return _DrawPixels(p);
    }
    
    /// disegna un std::vector di punti 3D colorati
    template<class T>
    inline bool DrawColorPixels3(const T& v)
    {
	std::vector< C4UB_V3F_t > p( v.size() );
	std::copy(v.begin(), v.end(), p.begin());
	return _DrawPixels(p);
    }

    /// disegna un std::vector di punti 3D colorati
    template<class T>
    inline bool DrawTexturePixels3(const T& v)
    {
	std::vector< T2F_V3F_t > p( v.size() );
	std::copy(v.begin(), v.end(), p.begin());
	return _DrawPixels(p);
    }

   /** Disegna una lista di punti
    * @param X,Y vettori o array (o qualunque cosa che ha l'operator [])
    * \code
    * int X[16], Y[16]
    * // ... 
    * win->DrawPixels(X,Y,16);
    * \endcode
    **/
   template<class T>
   inline bool DrawPixels(const T& X, const T& Y, unsigned int NoPoints)
    {
	std::vector< math::Point2f > p( NoPoints );
	for(unsigned int i=0;i<NoPoints;i++) 
		p[i].x = X[i], p[i].y = Y[i];
	return _DrawPixels(p);
    }
   
    template<class T>
    inline bool DrawPixels(const T& X, const T& Y, const T& Z, unsigned int NoPoints)
    {
	std::vector< math::Point3f > p( NoPoints );
	for(unsigned int i=0;i<NoPoints;i++) 
		p[i].x = X[i], p[i].y = Y[i], p[i].z = Z[i];
	return _DrawPixels(p);
    }

   /** Disegna una Linea
    * \code
    * win->DrawLine(20,20, 100,100);
    * \endcode
    **/
   bool DrawLine(double x0, double y0, double x1, double y1);

   /** Disegna una Linea
    * \code
    * Point2d a,b;
    * // ...
    * win->DrawLine(a,b);
    * \endcode
    **/
   template<class T>
   bool DrawLine(const math::Point2<T>& a, const math::Point2<T>& b);

   /// Draw 3D Line between two points
   template<class T>
   bool DrawLine(const math::Point3<T>& a, const math::Point3<T>& b);

   /// Disegna una Line3<T> eseguendo un clipping con un rettangolo @a clip_plane
   /// @return true se la linea e' dentro il rettangolo, altrimenti false.
   /// \code
   /// m_pInputMonoWindow->DrawLine(lp, Rect2d(0,0,width,height));
   /// \endcode
   template<class T>
   bool DrawLine(const math::Line3<T>& a, const math::Rect2<T>& clip_plane)
    {
	   math::Point2d p[2];
    if(clip_line3(a, p, clip_plane))
        return DrawLine(p[0],p[1]);
       else
        return false;
    }
   
   /// Disegna una freccia di dimensione @a size. @a x0,y0 e' la coda. @a x1,y1 e' la testa
   bool DrawVector(double x0, double y0, double x1, double y1, double size);
   
   /** Disegna un rettangolo pieno (o vuoto)
    * @param x0,y0,x1,y1 coordinate del rettangolo
    */
   bool DrawBox(double x0, double y0, double x1, double y1, bool filled = true);

   /// Disegna un rettangolo pieno
  template<class T>
   inline bool DrawBox(const math::Rect2<T>& r, bool filled=true)
    { return DrawBox(r.x0, r.y0, r.x1, r.y1, filled); }
   
   /** Disegna un rettangolo vuoto
    * @param x0,y0,x1,y1 coordinate del rettangolo
    */
   bool DrawRectangle(double x0, double y0, double x1, double y1);
   
   /// disegna il contorno di un rettangolo
   template<class T>
   inline bool DrawRectangle(const math::Rect2<T>& r)
    { return DrawRectangle(r.x0, r.y0, r.x1, r.y1); }

   /// Disegna un array di QUADRILATERI. Ogni 4 punti e' un QUADRILATERO (richiede 4 * n_boxes punti)
   template<class T>
   inline bool DrawQuads(const T& v, unsigned int n_boxes, bool filled=true)
    {  return TDrawQuads<math::Point2f>(v, n_boxes, filled);    }

   /// Disegna un array di QUADRILATERI Tridimensionali. Ogni 4 punti e' un QUADRILATERO (richiede 4 * n_boxes punti)
   template<class T>
   inline bool DrawQuads3(const T& v, unsigned int n_boxes, bool filled=true)
    {  return TDrawQuads<math::Point3f>(v, n_boxes, filled);    }

   /// Draw an array of Colored Quadlets. 
   template<class T>
   inline bool DrawColorQuads3(const T * v, unsigned int n_boxes)
    {
        std::vector< C4UB_V3F_t > p(n_boxes*4);
        std::copy(&v[0],& v[n_boxes*4], p.begin());
        return _DrawQuads(p);
    }

   /// Draw an array of Colored Quadlets. 
   template<class T>
   inline bool DrawColorQuads3(const T& v)
    {
        std::vector< C4UB_V3F_t > p(v.size());
        std::copy(v.begin(), v.end(), p.begin());
        return _DrawQuads(p);
    }

   /// Draw an array of Colored Quadlets.
   template<class T>
   GOLD_UI_DEPRECATED bool DrawColoredQuads3(const T * v, unsigned int n_boxes)
    {
        std::vector< C4UB_V3F_t > p(n_boxes*4);
        std::copy(&v[0],& v[n_boxes*4], p.begin());
        return _DrawQuads(p);
    }

   /// Draw an array of Colored Quadlets.
   template<class T>
   GOLD_UI_DEPRECATED bool DrawColoredQuads3(const T& v)
    {
        std::vector< C4UB_V3F_t > p(v.size());
        std::copy(v.begin(), v.end(), p.begin());
        return _DrawQuads(p);
    }

   /// Draw an array of Textured Quadlets.
   template<class T>
   inline bool DrawTextureQuads3(const T * v, unsigned int n_boxes)
    {
        std::vector< T2F_V3F_t > p(n_boxes*4);
        std::copy(&v[0],& v[n_boxes*4], p.begin());
        return _DrawQuads(p);
    }

   /// Draw an array of Textured Quadlets.
   template<class T>
   inline bool DrawTextureQuads3(const T& v)
    {
        std::vector< T2F_V3F_t > p(v.size());
        std::copy(v.begin(), v.end(), p.begin());
        return _DrawQuads(p);
    }
    
   /// Disegna un array/vector di rettangoli pieni. Ogni T Rect2 o Rect2_t e' un rettangolo
    /// @note in generale disegna ogni array/vector di oggetti che ha metodi top,left,bottom,right
   template<class T>
   inline bool DrawBoxes(const T& v, unsigned int n_boxes)
    {  
    std::vector<math::Point2f> vertex(n_boxes * 4);
    for(unsigned int i =0;i<n_boxes;i++)
        {
        vertex[i*4+0] = math::Point2f(v[i].left(), v[i].top() );
        vertex[i*4+1] = math::Point2f(v[i].right(), v[i].top() );
        vertex[i*4+2] = math::Point2f(v[i].right(), v[i].bottom() );
        vertex[i*4+3] = math::Point2f(v[i].left(), v[i].bottom() );
        }
    return _DrawQuads(vertex);
    }

   template<class T>
   inline bool DrawBoxes(const T& v)
    {
    return DrawBoxes(v, v.size());
    }

    // TODO: aggiungere la versione di DrawBoxes con gli iteratori

   /// Disegna un array/vector di rettangoli. Ogni T Rect2 o Rect2_t e' un rettangolo
   /// @note in generale disegna ogni array/vector di oggetti che ha metodi top,left,bottom,right
   template<class T>
   bool DrawRectangles(const T& v, unsigned int n_boxes)
    {  
    std::vector<math::Point2f> vertex (n_boxes * 8);
    for(unsigned int i =0;i<n_boxes;i++)
        {
        vertex[i*8+7] = vertex[i*8+0] = math::Point2f(v[i].left(),  v[i].top() );
        vertex[i*8+2] = vertex[i*8+1] = math::Point2f(v[i].right(), v[i].top() );
        vertex[i*8+4] = vertex[i*8+3] = math::Point2f(v[i].right(), v[i].bottom() );
        vertex[i*8+6] = vertex[i*8+5] = math::Point2f(v[i].left(),  v[i].bottom() );
        }
    return _DrawLines(vertex);
    }

   // TODO: aggiungere la versione di DrawRectangles con gli iteratori

   template<class T>
   inline bool DrawRectangles(const T& v)
    {
    return DrawRectangles(v, v.size());
    }

   /** @name Disegna un poligono
    *
    * Primitive per disegnare poligoni dati i vertici 
    **/
   /*@{*/ 
   
   /** Costruttore interno di poligoni che utilizza un Point2f direttamente, senza usare il template
    * @note e' corretto fatto in questo modo? si sovrascrive con gli altri template?
    * @param p un array di Point2f/Point3f
    * @param _numVertexes numero dei vertici da importare
    * @param filled il poligono e' pieno?
    **/
   bool DrawPolygon(const math::Point2f *p, unsigned int _numVertexes, bool filled);
   bool DrawPolygon(const std::vector<math::Point2f>& v, bool filled);
   bool DrawPolygon(const math::Point3f *p, unsigned int _numVertexes, bool filled);
   bool DrawPolygon(const std::vector<math::Point3f>& v, bool filled);

   /** Disegna un poligono di coppie di valori (x,y), convertendolo dalla coppia.
    * @param _x,_y due array (o std::vector) che rappresentano coppie (x,y) di punti che formano gli spigoli
    * @param _numVertexes numero dei vertici da importare
    * @param closed il poligono e' chiuso?
    * @param filled il poligono e' pieno?
    * @note questo e' un esempio dell'utilizzo della classe CCastFeed
    * @note i poligoni concavi riempiti vengono disegnati male
    * \code
    * int X[16], Y[16]
    * // ... 
    * win->DrawPolygon(X,Y,16,true,false);
    * \endcode
    **/
   template<class T>
   inline bool DrawPolygon(const T& _x, const T& _y, unsigned int _numVertexes, bool closed, bool filled)
    {
    return TDrawPolygon<math::Point2f>(CCastFeed2<T>(_x,_y), _numVertexes, closed, filled);
    }

   /** Disegna un array o un std::vector di punti con coppie (x,y)
    * @param v un array o un std::vector di oggetti che hanno due variabili x e y.
    * @param count numero di vertici
    * @param closed poligono chiuso?
    * @param filled poligono pieno?
    * @note se @a v e' un vector si puo' usare la drawPolygon con 3 parametri
    * \code
    * Point2d v[4]
    * // ...
    * win->DrawPolygon(v,4,true,true);
    * \endcode
    *
    * @note Uno puo' implementare il proprio feeder, basta che la classe T abbia il metodo 
    *           Point2d operator [] (int i) 
    *       implementato.
    * \code
    * DrawPolygon(CMyAdapter(myArray), count, closed, filled);
    * \endcode
    **/
   template<class T>
   inline bool DrawPolygon(const T& v, unsigned int count, bool closed, bool filled)
    {    return TDrawPolygon<math::Point2f>(CCastFeedArray2<T>(v), count, closed, filled);    }

   template<class T>
   inline bool DrawPolygon3(const T& v, unsigned int count, bool closed, bool filled)
    {    return TDrawPolygon<math::Point3f>(CCastFeedArray3<T>(v), count, closed, filled);    }


   /** Disegna uno std::vector di punti con coppie (x,y)
    * @param v un array o un std::vector di oggetti che hanno due variabili x e y.
    * @param closed poligono chiuso?
    * @param filled poligono pieno?
    * @note @a v deve possedere un metodo size() che ritorna il numero di punti da disegnare
    *       se cio' non e' possibile usare la DrawPolygon con 4 parametri
    * \code
    * std::vector<Point2d> v;
    * // ... some push_back s
    * win->DrawPolygon(v,true,true);
    * \endcode
    **/
   template<class T>
   inline bool DrawPolygon(const T& v, bool closed, bool filled)
    {   return TDrawPolygon<math::Point2f>(CCastFeedArray2<T>(v), v.size(), closed, filled);   }

   template<class T>
   inline bool DrawPolygon3(const T& v, bool closed, bool filled)
    {   return TDrawPolygon<math::Point3f>(CCastFeedArray3<T>(v), v.size(), closed, filled);   }
    
   /** Disegna un istogramma a base verticale con valori orizzontali
    * @param StartX,StartY punto dell'immagine da cui far partire l'istogramma
    * @param vector_y un array o un std::vector delle coordinate Y
    * @param _numVertexes numero di valori
    * @param filled l'istogramma e' pieno?
    * @see DrawHHistogram
    *
    * @note uno puo' implementare la propria funzione di feeder, basta che T sia una classe in cui
    *       sia implementato il metodo 
    *           double operator [](int i).
    *   \code
    *   DrawHistogram(StartX, StartY, MyAdapter(myArray), numVertexes, filled) 
    *   \endcode
    **/
   template<class T>
   inline bool DrawHistogram(float StartX, float StartY, const T& vector_y, unsigned int _numVertexes, bool filled)
    {       return TDrawPolygon<math::Point2f>(CHHistoFeed<T>(vector_y, StartX, StartY), _numVertexes, false, filled);    }
   
   /**  Disegna un istogramma a base verticale (e valori che vanno in orizzontale) con piu parametri
    * @param StartX,StartY punto dell'immagine da cui far partire l'istogramma
    * @param dx fattore di scala orizzontale (il segno permette di fare istogrammi che vanno da destra a sinistra)
    * @param dy fattore di scala verticale , ovvero quanti pixel avanzare per unita'
    * @param vector_x un array o un std::vector delle coordinate X,
    * @param _numVertexes numero di valori
    * @param filled l'istogramma e' pieno?
    * @note questo e' un esempio dell'utilizzo della classe CVHistoFeed
    * @note usando dx,dy opportuni (negativi, per esempio) e' possibile cambiare la direzione dell'istogramma
    * @note usando poligoni per disegnare gli istogrammi, poligoni pieni concavi vengono disegnati male dai moduli OpenGL
    * \code
    * unsigned int values[240];
    * // ...
    * win->DrawVHistogram(0,0,1.0,1.0,values, 240, false);
    * \endcode
    **/
   template<class T>
   inline bool DrawVHistogram(float StartX, float StartY, float dx, float dy, const T& vector_x, unsigned int _numVertexes, bool filled)
    {    return TDrawPolygon<math::Point2f>(CVHistoFeed<T>(vector_x, StartX, StartY,dx,dy), _numVertexes, false, filled);    }

   /** Come sopra, ma se @a vector_x e' un std::vector chiede a lui la dimensione del vector
    * \code
    * std::vector<unsigned int> values;
    * // ...
    * win->DrawVHistogram(0,0,1.0,1.0,values, false);
    * \endcode
    */
   template<class T>
   inline bool DrawVHistogram(float StartX, float StartY, float dx, float dy, const T& vector_x, bool filled)
    {    return TDrawPolygon<math::Point2f>(CVHistoFeed<T>(vector_x, StartX, StartY,dx,dy), vector_x.size(), false, filled);    }
   
   /** Disegna un istogramma a base orizzontale (e valori che vanno in verticale) con piu parametri
    * @param StartX,StartY punto dell'immagine da cui far partire l'istogramma
    * @param dx fattore di scala orizzontale , ovvero quanti pixel avanzare per unita'
    * @param dy fattore di scala verticale (il segno permette di fare istogrammi che vanno da basso ad alto)
    * @param vector_y un array o un std::vector delle coordinate y
    * @note quando @a StartY punta alla base della finestra, @a dy si usa negativo per far andare i valori verso l'alto
    * @note questo e' un esempio dell'utilizzo della classe CHHistoFeed
    * @note usando poligoni per disegnare gli istogrammi, poligoni pieni concavi vengono disegnati male dai moduli OpenGL
    * \code
    * unsigned int values[320];
    * // ...
    * win->DrawHHistogram(0,240,1.0,-1.0,values,320, false);
    * \endcode
    **/
   template<class T>
   inline bool DrawHHistogram(float StartX, float StartY, float dx, float dy, const T& vector_y, unsigned int _numVertexes, bool filled)
    {    return TDrawPolygon<math::Point2f>(CHHistoFeed<T>(vector_y, StartX, StartY,dx,dy), _numVertexes, false, filled);    }
   
   /** Come sopra, ma se @a vector_y e' un std::vector (o qualcosa che ha un metodo @a size e accede attraverso [])
    *     chiede a lui la dimensione dell'oggetto
    * \code
    * std::vector<unsigned int> values;
    * win->DrawHHistogram(0,240,1.0,-1.0,values, false);
    * // Esempio con una deque:
    * std::deque<float> values;
    * win->DrawHHistogram(0.0f,240.0f,1.0f,-1.0f,values, false);
    * \endcode
    *
    */
   template<class T>
   inline bool DrawHHistogram(float StartX, float StartY, float dx, float dy, const T& vector_y, bool filled)
    {    return TDrawPolygon<math::Point2f>(CHHistoFeed<T>(vector_y, StartX, StartY,dx,dy), vector_y.size(), false, filled);    }

   /*@}*/
   
   /*@{*/

   /// Disegna un array di segmenti formati da coppie (x,y)
   /// @param count numero di segmenti (il numero di punti nell'array dovra' essere 2 * count)
   template<class T>
   inline bool DrawLines(const T& v, unsigned int count)    {
    return TDrawLines<math::Point2f>(CCastFeedArray2<T>(v), count);
    }

   /// Disegna un std::vector segmenti formati da coppie (x,y)
   template<class T>
   inline bool DrawLines(const T& v)    {
    return TDrawLines<math::Point2f>(CCastFeedArray2<T>(v), v.size()/2);
    }

   /// Disegna un array di punti con tuple (x,y,z)
   /// @param count numero di segmenti (il numero di punti nell'array dovra' essere 2 * count)
   template<class T>
   inline bool DrawLines3(const T& v, unsigned int count)    {
    return TDrawLines<math::Point3f>(CCastFeedArray3<T>(v), count);
    }

   /// Disegna un std::vector di punti con tuple (x,y,z)
   template<class T>
   inline bool DrawLines3(const T& v)    {
    return TDrawLines<math::Point3f>(CCastFeedArray3<T>(v), v.size()/2);
    }

   /// Disegna un array di punti con tuple (x,y,z,r,g,b,a). 
   /// @param nLines numero di righe (numero di punti = nLines * 2)
   template<class T>
   inline bool DrawColorLines3(const T * v, int nLines)  {
     std::vector< C4UB_V3F_t > p(nLines*2);
     std::copy(&v[0],& v[nLines*2], p.begin());
    return _DrawLines(p);
    }    
   /// Disegna un std::vector di punti con tuple (x,y,z,r,g,b,a)
   template<class T>
   inline bool DrawColorLines3(const T& v)  {
     std::vector< C4UB_V3F_t > p(v.size());
     std::copy(v.begin(), v.end(), p.begin());
    return _DrawLines(p);
    }

   /*@}*/

   /*@{*/

   /// Disegna un array (o un std::vector) di triangoli. Ogni 3 punti (x,y) un triangolo
   template<class T>
   bool DrawTriangles(const T& v, unsigned int nTriangles, bool filled=true)
    {  return TDrawTriangles<math::Point2f>(CCastFeedArray2<T>(v), nTriangles, filled);    }

   /// Disegna un array (o un std::vector) di triangoli. Ogni 3 punti (x,y) un triangolo
   template<class T>
   inline bool DrawTriangles(const T& v,  bool filled=true)
    {  return DrawTriangles<math::Point2f>(v, v.size(), filled);    }

   /// Disegna un array (o un std::vector) di triangoli. Ogni 3 punti (x,y) un triangolo
   template<class T>
   bool DrawTriangles3(const T& v, unsigned int nTriangles, bool filled=true)
    {  return TDrawTriangles<math::Point3f>(CCastFeedArray3<T>(v), nTriangles, filled);    }

   /// Disegna un array (o un std::vector) di triangoli. Ogni 3 punti (x,y) un triangolo
   template<class T>
   inline bool DrawTriangles3(const T& v,  bool filled=true)
    {  return DrawTriangles<math::Point3f>(v, v.size(), filled);    }

   /// Draw a triangle array with colored vertex in a 3D environment
   template<class T>
   inline bool DrawColorTriangles3(const T * v, unsigned int nTriangles)
    {
        std::vector< C4UB_V3F_t > p(nTriangles*3);
        std::copy(&v[0],& v[nTriangles*3], p.begin());
        return _DrawTriangles(p);
    }

   /// Draw a triangle vector with colored vertex in a 3D environment
   template<class T>
   inline bool DrawColorTriangles3(const T& v)
    {
        std::vector< C4UB_V3F_t > p(v.size());
        std::copy(v.begin(), v.end(), p.begin());
        return _DrawTriangles(p);
    }

   /// Draw a triangle array with textured vertex in a 3D environment
   template<class T>
   inline bool DrawTextureTriangles3(const T * v, unsigned int nTriangles)
    {
        std::vector< T2F_V3F_t > p(nTriangles*3);
        std::copy(&v[0],& v[nTriangles*3], p.begin());
        return _DrawTriangles(p);
    }

   /// Draw a triangle vector with textured vertex in a 3D environment
   template<class T>
   inline bool DrawTextureTriangles3(const T& v)
    {
        std::vector< T2F_V3F_t > p(v.size());
        std::copy(v.begin(), v.end(), p.begin());
        return _DrawTriangles(p);
    }    

   /*@}*/

   /** Disegna una crocetta
    * @param x,y centro della croce
    * @param size dimensione della croce
    **/
   bool DrawCross(double x, double y, double size);
   
    /** Disegna una crocetta
    * @param p centro della croce
    * @param size dimensione della croce
    **/
   template<class T>
   bool DrawCross(const T& p, double size) {
    return DrawCross(p.x, p.y, size);
    };
   
   /// Disegna un'array di crocette (stesso colore)
   /// TODO: rinominarlo in DrawCrosses
   template<class T>
   bool DrawCrossArray(const T& x, const T& y, unsigned int nCross, double size)
   {
   return TDrawCrossArray<math::Point2f>(CCastFeed2<T>(x,y), nCross, size);
   }
   
   /// Disegna un'array di crocette (stesso colore)
   /// TODO: rinominarlo in DrawCrosses
   template<class T>
   bool DrawCrossArray(const T& v, unsigned int nCross, double size)
   {
   return TDrawCrossArray<math::Point2f>(CCastFeedArray2<T>(v), nCross, size);
   }

   /// Disegna un'array di crocette (stesso colore)
   /// TODO: rinominarlo in DrawCrosses
   template<class T>
   bool DrawCrossArray(const T& v, double size)
   {
   return TDrawCrossArray<math::Point2f>(CCastFeedArray2<T>(v), v.size(), size);
   }

   /** Disegna un ellisse
    * @param X0,Y0,X1,Y1 estremi dell'ellisse
    * @param Filled pieno o vuoto?
    */
   bool DrawEllipse(double X0, double Y0, double X1, double Y1, bool Filled);

   /// Disegna un ellisse partendo dal bounding box
  template<class T>
   inline bool DrawEllipse(const math::Rect2<T>& r, bool filled)
    { return DrawEllipse(r.x0, r.y0, r.x1, r.y1, filled); }
   
   /// Disegna un cerchio
   bool DrawCircle(double X, double Y, double Radius, bool Filled);

   /// Disegna un cerchio
   template<class T, class R>
    inline bool DrawCircle(const T& r, R radius, bool filled)
    { return DrawCircle(r.x, r.y, radius, filled);    }

   /// Disegna un cerchio da una classe con x0,y0,r
   template<class T>
    inline bool DrawCircle(const T& c, bool filled)
    { return DrawCircle(c.x0, c.y0, c.r, filled);    }

   /** Disegna un arco di ellisse
     * @param a0 start angle, in radiants
     * @param a1 end angle, in radiants
     */
   bool DrawSlicedEllipse(double X0, double Y0, double X1, double Y1, double a0, double a1, bool Filled);

   /** Disegna un arco di circonferenza
     * @param a0 start angle, in radiants
     * @param a1 end angle, in radiants
     */
   bool DrawSlicedCircle(double X, double Y, double Radius, double a0, double a1, bool Filled);

   /** @name interactive object */
   /** @todo move externally from CWindow in CWindowGUI object? */
   /*@{*/
   
   /** Associa una area dello schermo a una azione che verra' chiamata quando viene soddisfatta una azione
    * 
    * la callback @a action viene chiamata nel thred di disegno quando l'evento @a event viene soddisfatto e il puntatore e' dentro
    *   l'area.
    * \code
    * win->SetRegionCallback(20,20,100,100,WEF_BUTTON_DOWN,boost::bind(foo));
    * win->SetRegionCallback(120,20,200,100,WEF_BUTTON_UP|WEF_BUTTON_DOWN,boost::bind(foo2));
    * \endcode
    *  @param x0,y0,x1,y1 area rettangolare dello schermo
    *  @param event bitmask che segna quali eventi sono attivi
    *  @param action una callback che viene chiamata quando la bitmask e' attiva
    * @note la callback viene eseguita nel thread di disengo! percio' in maniera concorrente rispetto al 
    *       flusso normale del programma. Se si vuole usare il sistema concorrente usare CWindow::AddRegion
    * @see SetRegionAction
    **/
   bool SetRegionCallback(double x0, double y0, double x1, double y1, CWindowEvent_ID event, boost::function<void (void)> action);
   
   /** Associa una area dello schermo un evento Object con id scelto
    *
    *  viene pushato un evento WEF_OBJECT nella coda un evento con l' @a id specificato quando l'evento @a event e' soddisfatto
    *   e il puntatore e' dentro l'area di disegno.
    * \code
    * win->SetRegionAction(20,20,100,100,WEF_BUTTON_DOWN,100);
    * \endcode
    *  @param x0,y0,x1,y1 area rettangolare dello schermo
    *  @param event bitmask che segna quali eventi sono attivi
    *  @param id un id che verra' inserito nella coda eventi della finestra
    * @see SetRegionCallback
    * @note per poter usare SetRegionAction la flag WEF_OBJECT deve essere attiva sulla finestra per intercettare l'ID
    **/
   bool SetRegionAction(double x0, double y0, double x1, double y1, CWindowEvent_ID event, unsigned int id);
   
   /** Questo Widget permette di specificare due blocchi di disegno
     *  in caso che il mouse sia interno al rettangolo specificato o fuori.
     * @param x0,y0,x1,y1 un rettangolo in coordinate logiche
     * @param inside una coda di disegno da disegnare quando il mouse e' dentro
     * @param outside una coda di disegno da disegnare quando il mouse e' fuori
     **/
   bool SetActiveRegion(double x0, double y0, double x1, double y1,
	const CDrawingQueue& inside,
	const CDrawingQueue& outside = CDrawingQueue());

   /// Imposta il theme dei widget per questa finestra [stiky]
   bool SetTheme(const CWindowTheme& theme);

   /*@}*/
       
   /** @name Testo */
   /*@{*/
   
   /** Select the font Family Name
     *
     * Il nome del font al momento corrisponde a una famiglia come ritornata da fc-list
     * La sintassi estesa e' nel formato \<chiave\>=\<valore\>[,...]
     * esempio:
     * \code
     * win->SetFontName("Liberation Sans");
     * win->SetFontName("family=Liberation Sans");
     * win->SetFontName("family=Liberation Sans,slant=italic");
     * win->SetFontName("family=Liberation Sans,weight=bold");
     * \endcode
     * - family = una famiglia ritornata da fc-list
     * - slant = roman|italic|oblique
     * - weight = thin|light|book|normal|medium|bold|black
     * - spacing = mono|proportional
     **/
   bool SetFontName(const char *fontFamilyName);

   /// Scegli la dimensione del font in punti
   ///
   /// @param fontSize dimensione del font
   /// @param absolute se la dimensione del font e' assoluta o relativa (default)
   bool SetFontSize(double fontSize, bool absolute = false);

   /// Setta la dimensione e la direzione del font
   ///
   /// @param fontX dimensione e direzione del font lungo l'asse X
   /// @param fontY dimensione e direzione del font lungo l'asse Y
   /// @param absolute coordinate assolute o logiche
   bool SetFontSizeEx(double fontX, double fontY, bool absolute=false);

   /** Imposta l'allineamento del testo
    * @param horiz,vert un valore di TextAlign_t per indicare l'allineamento
    **/
   bool SetTextAlign(TextAlign_t horiz = TA_LEFT_, TextAlign_t vert = TA_BOTTOM_);
	
   /** Disegna una linea di testo
    * \code
    * win->DrawText(0,100,"Hello World");
    * \endcode
	**/
   bool DrawText(double x, double y, const std::string& text);

   /// vector
   template<class T>
   bool DrawText(const math::Point2<T>& p, const std::string& text)
        {
        return DrawText(p.x, p.y, text);
        }
   
   /** Disegna una linea di testo in 3 dimensioni
    * \code
    * win->DrawText(1,1,1, "Hello World");
    * \endcode
    **/
   bool DrawText(double x, double y, double z, const std::string& text);

   /// vector
   template<class T>
   bool DrawText(const math::Point3<T>& p, const std::string& text)
        {
        return DrawText(p.x, p.y, p.z, text);
        }
   
   /** Disegna una linea di testo formattata
    * \code
    * win->DrawTextF(20,20,"speed: %.1f", speed);
    * \endcode
    * @note ha i problemi di buffer overflow tipici di questo approccio
    **/
   bool DrawTextf(double x, double y, const char *_fmt, ...);

   /// Disegna testo con ombra
   bool DrawShadowText(double x, double y, const std::string& text);
   
   /*@}*/
    

   /** @name Disegno di immagini */
   /*@{*/

   /** \brief Draw a Full Screen Image (stretching)
    * @param image un puntatore a un buffer contenente un'immagine
    * @param imgWidth,imgHeight dimensioni dell'immagine
    *
    * \code
    * // esempio: disegno un'immagine in toni di grigio 320x240. buffer deve essere un array di unsigned char
    * win->DrawImage(buffer,320,240);
    * // esempio: disegno un'immagine a colori RGB 320x240. buffer puo' essere un array di unsigned char
    * win->DrawImage((const cimage::RGB8*)buffer,320,240);
    * \endcode
    **/
   template<class T>
   bool DrawImage(const T *image, unsigned int imgWidth, unsigned int imgHeight);
   
   /** Disegna un'immagine in una posizione stabilita dello schermo, dalle dimensioni logiche dell'immagine stessa
    * @param xDest,yDest top-left corner di dove disegnare l'immagine
    * @param image un puntatore a un buffer
    * @param imgWidth,imgHeight dimensione dell'immagine e corrispondente dimensione al momento del disegno
    *
    * \code
    * // buffer puo' essere un array di unsigned char
    * win->DrawImage(0.0,200.0, (const cimage::RGB8*) buffer,40,40);
    * \endcode
    **/
   template<class T>
   bool DrawImage(double xDest, double yDest, const T *image, unsigned int imgWidth, unsigned int imgHeight);
   
   /** Disegna un'immagine in una posizione stabilita dello schermo dalle dimensioni logiche stabite
    * @param xDest,yDest top-left su cui disegnare
    * @param _destWidth,_destHeight dimensione disegno
    * @param image puntatore a un buffer immagine
    * @param imgWidth,imgHeight dimensione del buffer
    * \code
    * // buffer should be unsigned char or cimage::RGB8 buffer
    * win->DrawImage(0,0,160,120, buffer,640,480);
    * win->DrawImage(0,0,160,120, buffer,640,480);
    * \endcode
    **/
   template<class T>
   bool DrawImage(double xDest, double yDest, double _destWidth, double _destHeight, const T *image, unsigned int imgWidth, unsigned int imgHeight);
    
   /// Disegna solo una sottoparte del buffer
   template<class T>
   bool DrawClippedImage(double xDest, double yDest, double _destWidth, double _destHeight, const T *image, unsigned int imgWidth, unsigned int imgHeight, const math::Rect2i& rect);
   
   /** Disegna un immagine a schermo intero
    * @note it works good only on 2D Viewport
    * @param copy_image (optional) image will be copied instead of cloned
    * \code
    * win->DrawImage(img);
    * \endcode
    * @note con copy_image=false l'immagine non viene copiata ma viene aumentato il ref_count dello sharedptr
    **/
   bool DrawImage(const cimage::CImage& image);
   bool DrawImage(const cimage::CImage::SharedPtrConstType spimage);
   /** Disegna un immagine mantenendo costante la risoluzione
    * @param X,Y coordinate della parte superiore sinistra dove disegnare l'immagine
    * @param image una CImage
    * @param copy_image (optional) image will be copied instead of cloned
    * \code
    * win->DrawImage(0,100,img);
    * \endcode
    * @note l'immagine non viene copiata ma viene aumentato il ref_count dello sharedptr
    **/
   bool DrawImage(double X, double Y, const cimage::CImage& image);
   bool DrawImage(double X, double Y, const cimage::CImage::SharedPtrConstType& image);
   
   /** Disegna un immagine definendo X,Y,W,H
    * @param X,Y coordinate della parte superiore sinistra dove disegnare l'immagine
    * @param W,H dimensioni con i quali l'immagine sara' disegnata
    * @param image una CImage
    * @param copy_image (optional) image will be copied instead of cloned
    * \code
    * win->DrawImage(0,0,160,120, img);
    * \endcode
    * @note l'immagine non viene copiata ma viene aumentato il ref_count dello sharedptr
    **/
   bool DrawImage(double X, double Y, double W, double H, const cimage::CImage& image);
   bool DrawImage(double X, double Y, double W, double H, const cimage::CImage::SharedPtrConstType& image);
   
   
   /** Draw a CImage over a 3D Polygon formed by 4 points
    * @param poly a 3D polygon. L'ordine dei punti e' in senso orario. il punto 0 e' la coordinata (0,0) della texture, il punto 1 e' coordinata (1,0), il punto 2 e' coordinata (1,1), infine il 3 coordinata (0,1)
    * @param image an Image
    * @param copy_image (optional) image will be copied instead of cloned
    **/
   template<class T>
   bool DrawImage(const typename math::Point3<T>*poly, const cimage::CImage& image);
   template<class T>
   bool DrawImage(const math::Point3<T> *poly, const cimage::CImage::SharedPtrConstType& image);
   
   /** Draw a C buffer over a 3D Polygon formed by 4 points
    * @param poly a 3D polygon
    * @param image pointer to first pixel of image buffer
    * @param width,height buffer size (in pixels)
    **/
   template<class R, class T>
   bool DrawImage(const math::Point3<T> *poly, const R * image, unsigned int width, unsigned int height);

   /** Draw a subpart of a C buffer over a 3D Polygon formed by 4 points
    * @param poly a 3D polygon
    * @param image pointer to first pixels of ROI
    * @param stride length of stride of image in bytes
    * @param width,height buffer size in pixels
    **/
   template<class R, class T>
   bool DrawImage(const math::Point3<T> *poly, const R * image, long stride, unsigned int width, unsigned int height);
  
   /// Disegna solo una sottoparte del buffer
   /// @note non fa il lock su image. se necessario farlo esternamente.
   template<class T>
   bool DrawClippedImage(double xDest, double yDest, double _destWidth, double _destHeight, const cimage::TImage<T>& image, const math::Rect2i& rect);
   
   /** Disegna su schermo un immagine caricata da file 
    * @param filename un immagine
    * @param x,y coordinate schermo di dove inserire l'immagine
    * @param width,height dimensioni o fattore di scala a seconda del valore di scale
disegno
    * @note Ogni file immagine viene caricato da disco e pertanto questa funzione ha senso se usata congiuntamente ai Layer di disegno.
    **/
   bool DrawImageFile(const std::string& filename, float x, float y, float width, float height);

   /** associa una immagine al drawing context. Viene usata come base per le texture **/
   bool BindImage(const cimage::CImage& image);
   bool BindImage(const cimage::CImage::SharedPtrConstType& image);
   
   /** @name external image processing before put in drawing queue */
   /*@{*/
   /** Disegna una immagine (al momento solo PPM/PGM) caricandola da disco
    * @param filename un file PPM/PGM (anche gzip)
    * @param x,y coordiante dove inserire l'immagine
    * @param widht,height dimensione dell'immagine su schermo
    * @param proc una struttura IMAGEPROCPARAM che raccoglie le operazioni da applicare all'immagine
    * @note l'immagine viene caricata ogni volta, pertanto ha senso se associata ai layer di disegno
    **/
   template<class T, class X>
   bool DrawXImageFile(const std::string& filename, float x, float y, float width, float height, const X& proc);

   /** Funzione che disegna un immagine applicando una serie di filtraggi per la rappresentazione,
    *   tra cui la scelta del colorkey o la creazione di una mappa di opacita'
    *
    * Questa funzione serve per renderizzare direttamente in una texture delle
    *  elaborazioni veloci su un immagine, con motivazioni puramente estetiche
    *  e non di elaborazione.
    *
    * @param destX,destY coordinate TopLeft del rettangolo dove disegnare
    * @param destWidth,destHeight dimensione del rettangolo destinazione disegno
    * @param image puntatore a un buffer immagine
    * @param imgWidth,imgHeight dimensioni del buffer immagine
    * @param proc una struttura X che descrive i parametri del processing
    * @note il processing viene fatto Client Side
    * @see i tipi di filtri sono descritti in XImgProc.h
    **/ 
   template<class T, class X>
   bool DrawXImage(double destX, double destY, double destWidth, double destHeight,
                      const T *image, unsigned int imgWidth, unsigned int imgHeight,
                      const X& fn);

   /** DrawXSubImage per CImage
    *
    * Converte durante il disegno una CImageMono in una RGBA usando il tono di grigio come livello di opacita'
    *  e colorando il resto in rosso:
    * \code
    *	m_win.EnableBlend();
    *	m_win.DrawXImage(0,0, 100, 100, m_imageMono, XOpacity(cimage::RGB8(255,0,0), 0, 255) );
    *	m_win.DisableBlend();
    * \endcode
    **/
    template<class T, class X>
   bool DrawXImage(double destX, double destY, double destWidth, double destHeight,
                      const T& image,
                      const X& fn);

  /*@}*/

    /** Registra una callback che viene chiamata a ogni nuovo frame renderizzato **/
    void Subscribe_RefreshComplete(OnGrabCImage slot, int coreID = 0);
  
   /** @name Gestione Eventi */
   /*@{*/

   /** \brief Imposta quali eventi il server deve tenere traccia
   * @note tenere traccia degli eventi implica che l'utente deve farsi carico di svuotare la coda
   * @param mask uno o piu valori in OR tra quelli proposti in CWindowEvent_ID
   * \code
   * // per esempio:
   * // a) vengono memorizzate solo le pressioni del bottone del mouse:
   * win->SetEventMask(WEF_BUTTON_DOWN);
   * // b) viene memorizzati i diversi stati del mouse
   * win->SetEventMask(WEF_BUTTON_DOWN | WEF_BUTTON_UP | WEF_MOUSE_MOTION);
   * // c) non viene memorizzato nessun evento:
   * win->SetEventMask(WEF_NONE);
   * \endcode
   **/
  void SetEventMask(unsigned int mask, int Source = 0);
   
   /** \brief Si mette in attesa di un evento dal server CWindowCore e quando arriva li copia nella versione locale
   * @note questa funzione e' bloccante. Deve essere usata per esempio in thread separati dal processo principale
   * \code
   *  while(WaitForEvent())
   *     {
   *     while(GetNextEvent(event))
   *         {
   *         // ...
   *         }
   *     }
   * \endcode
   * @return sempre e solo true. TODO: far ritornare false se la finestra e' in chiusura (difficile)
   **/
  bool WaitForEvent(int Source = 0);

   /** \brief Sposta tutti i messaggi che ci sono sulla coda Server nella coda Client. Se non ci sono messaggi non aspetta tuttavia.
   * Nell'architettura delle finestre MultiThread di GOLD esistono due code di eventi:
   *  una remota e una locale. Tale funzione sposta i messaggi da una coda remota a
   *  quella locale.
   *
   * Gli eventi con callback registrate vengono chiamate.
   *
   * \code
   * FlushEvent();
   *  while(GetNextEvent(event))
   *   {
   *   // ...
   *   }
   * \endcode
   * @return ritorna true se ci sono messaggi da processare
   **/
  bool FlushEvent(int Source = 0);

   /** \brief Estrae un evento dalla coda locale degli eventi
   * \code
   * CWindowEvent event;
   * // ...
   * while(GetNextEvent(event))
   *    switch(event.event)
   *         {
   *         // ...
   *         }
   * \endcode
   * @note questa funzione non legge eventi dalla coda remota, ma solo dalla coda locale. Usare WaitForEvent o FlushEvent 
   * @return true se c'e' un evento nella coda locale. false se non c'e' nessun evento
   */
  bool GetNextEvent(CWindowEvent& event);
 
  /** \brief Abilita o meno l'uso dei tasti speciali all'interno delle finestre OpenGL. I tasti, anche se disabilitati, possono essere usati usando CTRL + tasto
   * @param value true permette di usare indipendentemente CTRL + tasto e tasto per eseguire comandi. false solo CTRL + tasto e gli altri
   *              tasti vengono passati al gestore eventi e poi all'utente (se gestiti)
   * @note Utente esperto che sa quello che sta facendo.
   **/
  void EnableKeyboardHandle(bool value);
             
   /*@}*/
   //---------------------------

 // funzioni speciali:
 /// Restituisce il colore del pixel sotto il mouse
 bool GetColorUnderMouse(cimage::RGBA8 *pColor, int Core = 0) const;

 //////////////////////////////////////// CWINDOW MODULE CONTROL ///////////////
 
 /** @name GUI control **/
 /*@{*/
  /// Set Default Driver
  static void setDriver(const std::string& drivername);
  /// Set configuration file used by CWindow
  static bool setINIFile(INIFile *ini);
  /// Set Output Path
  static std::string setOutputPath(const std::string& outputPath);
  /// Set Output Path
  static std::string setResourcePath(const std::string& resPath);
  /// Set Fonts Path
  static std::string setFontsPath(const std::string& fontsPath);
  /// Return default driver
  static std::string getDriver(void);
 /*@}*/
 
  /** Parameters to create Dummy CWindow
   * \code
   * CWindow *dummy = new CWindow(CWindow::Null);
   * \endcode
   **/
  static WindowCreationParams Null;
 };
 
} // win

} // ui
 
#endif  // _C_WINDOWS_H
