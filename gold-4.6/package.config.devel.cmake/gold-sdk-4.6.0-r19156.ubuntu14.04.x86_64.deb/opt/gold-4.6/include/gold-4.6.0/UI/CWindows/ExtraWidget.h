/** @file ExtraWidget.h
  * @brief This file handle miscellaneous Widget not included in CWindow class
  *        Widget che usano chiamate dirette alla libreria di disegno senza passare dal Server CWindowCore
  * @author Paolo Medici (medici@ce.unipr.it)
  **/

#ifndef _EXTRA_WIDGET_H
#define _EXTRA_WIDGET_H

#include <UI/CWindows/CWidget.h>
#include <UI/gold_ui_export.h>

#ifdef HAVE_X
 #include "GLUtils.h"
#endif


#ifdef HAVE_X

namespace ui {
namespace win {

/** Esempio di DrawingObject custom in C++
 *   Questa classe disegna un frame rosso trasparente intorno alle finestre
 * @note richiede OpenGL/OpenGLST
 **/
class GOLD_UI_EXPORT FlashingBorder : public CWidget {
  unsigned char alpha1, alpha2;
  float size;
  math::Rect2d v;
  
  static void _set(C4UB_V3F_t & p, unsigned char alpha, float x, float y)
  {
  p = C4UB_V3F_t(x,y,0.0f, 255,0,0,alpha);
  }

  public:
  FlashingBorder(const math::Rect2d & rect, float _size, unsigned char _alpha1, unsigned char _alpha2) : alpha1(_alpha1), alpha2(_alpha2), size(_size), v(rect) {}
  int Draw(CWindowCore *Window);
};
} // namespace win
} // namespace ui

#endif


#endif
