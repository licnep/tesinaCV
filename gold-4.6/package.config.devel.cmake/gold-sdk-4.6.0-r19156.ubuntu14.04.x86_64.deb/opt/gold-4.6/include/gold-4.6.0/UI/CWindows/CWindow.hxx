#ifndef _CWINDOW_HXX
#define _CWINDOW_HXX

#include "CWidgets.h"

namespace ui{
  namespace win{

template<class T>
bool CWindow::DrawImage(const T *image, unsigned int imgWidth, unsigned int imgHeight)
{
  return push(new ui::win::CopyImage(image, imgWidth, imgHeight));
}

template<class T>
bool CWindow::DrawImage(double xDest, double yDest, const T *image, unsigned int imgWidth, unsigned int imgHeight)
{
  return push(new ui::win::CopyImage(xDest, yDest, (double) imgWidth, (double) imgHeight, image, imgWidth, imgHeight));
}

template<class T>
bool CWindow::DrawImage(double xDest, double yDest, double destWidth, double destHeight, const T *image, unsigned int imgWidth, unsigned int imgHeight)
{
  return push(new ui::win::CopyImage(xDest, yDest, destWidth, destHeight, image, imgWidth, imgHeight));
}

template<class T>
bool CWindow::DrawImage(const math::Point3<T> *poly, const cimage::CImage & image)
{
 return push(new ui::win::CopyImageTexture(poly, image));
}

template<class T>
bool CWindow::DrawImage(const math::Point3<T> *poly, const cimage::CImage::SharedPtrConstType & image)
{
 return push( new ui::win::ImageTexture(poly, image) );
}

 template<class R, class T>
bool CWindow::DrawImage(const math::Point3<T> *poly, const R * image, unsigned int width, unsigned int height)
{
 return push(new ui::win::CopyImageTexture(poly, image, width, height));
}


 template<class R, class T>
bool CWindow::DrawImage(const math::Point3<T> *poly, const R * image, long stride, unsigned int width, unsigned int height)
{
 return push(new ui::win::CopyImageTexture(poly, image, stride, width, height));
}

template<class T>
bool CWindow::DrawClippedImage(double xDest, double yDest, double _destWidth, double _destHeight, const T *image, unsigned int imgWidth, unsigned int imgHeight, const math::Rect2i & rect)
{
unsigned int width, height;
width = rect.x1 - rect.x0;
height = rect.y1 - rect.y0;
typename cimage::TImage<T>::SharedPtrType pdst(new cimage::TImage<T>(width, height) );

image += rect.y0 * imgWidth;
T * ptr = pdst->Buffer();
for(unsigned int i=0;i<height;i++)
{
 std::copy(image + rect.x0, image + rect.x1, ptr);
 image += imgWidth;
 ptr += width;
}

return push(new ui::win::Image(xDest, yDest, _destWidth, _destHeight, pdst) );

}

template<class T>
bool CWindow::DrawClippedImage(double xDest, double yDest, double _destWidth, double _destHeight, const cimage::TImage<T> & image, const math::Rect2i & rect)
   {
   return DrawClippedImage<T>(xDest, yDest, _destWidth, _destHeight, image.Buffer(), image.W(), image.H(), rect);
   }

  } // namespace win
} // namespace ui

#endif
