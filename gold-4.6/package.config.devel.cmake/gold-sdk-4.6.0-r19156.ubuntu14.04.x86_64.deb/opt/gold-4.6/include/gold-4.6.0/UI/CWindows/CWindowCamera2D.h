#ifndef _CWINDOW_CAMERA2D_H
#define _CWINDOW_CAMERA2D_H

#include <vector>

#include <boost/math/constants/constants.hpp>

#include <Data/Math/Rects.h>
#include <Data/Math/TMatrices.h>

#include <Data/Base/CCameraParams.h>

#include <UI/CWindows/CWindowTypes.h>
#include <UI/CWindows/CWindowFwd.h> // Forward Declaration
#include <UI/CWindows/CWindowCamera.h>
#include <UI/gold_ui_export.h>


namespace ui {
namespace win {
  
/// A typical 2D View
/// (x0,y0)-(x1,y1) <=> (-1,1) - (1,-1)
class GOLD_UI_EXPORT CCamera2D: 
public CCamera 
{
private:
    /// affine projection matrix
    double m_mat[6];
    ///
    double dx,dy,ws,hs;

    // field of view a riposo:
    double m_x0, m_y0, m_x1, m_y1;

    double m_zoom, m_dx, m_dy, m_angle;

    int m_state;

    math::Point2f m_prev;

private:

    void Prepare();

    void SmoothZoom(CWindowCoreManager *core, float zoom, float x0, float y0);

public:
    CCamera2D();
    /// Imposta i limiti del Viewport (problemi pero' a usare un piano cartesiano)
    /// @param x0,y0 TOP-LEFT coordinate
    /// @param x1,y1 BOTTOM_RIGHT coordinate
    CCamera2D(double x0, double y0, double x1, double y1);
    virtual ~CCamera2D();

    /// Reset the camera to the Default
    void Reset();

    /// Set a New Default
    void SetView(double x0, double y0, double x1, double y1);

    /// return current view matrix
    virtual void GetMatrix(CWindowCore *core, ViewPortMatrix& M);

    /// return the inverse camera for DrawImage
    virtual void GetRestInverseUVWMatrix(CWindowCore *core, InverseViewPortMatrix& M);

    /// should modify internal structure in order to set logical coordinate
    virtual bool Interact(CWindowCoreManager *core, const CWindowEvent& Event);

    /// Eventually it should draw a HUD
    virtual int Draw(CWindowCore *core) {
        return 0;
    }
};

typedef CCamera2D CWindowCamera2D;

} // namespace win
}// namespace ui

#endif // _CWINDOW_CAMERA2D_H
