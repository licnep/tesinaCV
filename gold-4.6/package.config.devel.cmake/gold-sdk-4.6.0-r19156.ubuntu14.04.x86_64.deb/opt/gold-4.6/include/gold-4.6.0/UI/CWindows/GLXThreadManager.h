/** @file GLXThreadManager.h
 *  @brief classe GLXThreadManager
 *  @author Paolo Medici (medici@ce.unipr.it)
 **/

#ifndef _GLX_THREAD_MANAGER_H
#define _GLX_THREAD_MANAGER_H

#include <UI/CWindows/CWindowCore.h>
#include "CWindowCommand.h"
#include "X11ThreadManager.h"

#include <GL/glx.h> 
#include <X11/Xlib.h> 
#include <sys/ioctl.h>

#include <map>

namespace ui{
  namespace win{

/** La classe GLXThreadManager gestisce un singolo thread OpenGL
 *  Nel caso della modalita' MultiThread ogni finestra ha un thread, mentre nella modalita
 *  SingleThread questa classe sara' instanziata una sola volta **/
class GLXThreadManager: public X11ThreadManager {
    protected:
    /// canale di comunicazione verso il server GLX
    GLXContext    gLXCtx;
    XVisualInfo *vi;

    bool m_init;

    public:
    /// Massima dimensione della texture
    unsigned int m_max_texture_size;
    /// GL_TEXTURE_2D o una delle rettangolari
    GLuint m_texture_type;

    // Texture Supported:
    bool m_rgba; 

    public:
    GLXThreadManager();
    ~GLXThreadManager();

    /// Crea un device X11 atto a contenere un contensto OpenGL
    bool X11_CreateDevice(void);
    bool X11_DeleteDevice(void);

	/// Crea il contesto OpenGL
    bool GLX_CreateContext(void);
    bool GLX_DestroyContext(void);
    
	/// Crea una finestra atta a contenere un contesto OpenGL
    Window CreateWindow(const char *Title, int X, int Y, unsigned int & Width, unsigned int & Height, CWINDOW_FLAG flag);

      /// Assegna il contesto OpenGL/GLX alla finestra specificata
     bool AssignContext(Window xWindow);
     /// rimuove il contesto OpenGL/GLX 
     inline
     bool ReleaseContext(void)
      { 
      return glXMakeCurrent(xDisplay, None, NULL);
      }

    /// Return Texture Type
    GLuint TextureType() const { return m_texture_type; }
    /// Return Max Texture Size
    unsigned int MaxTextureSize() const { return m_max_texture_size; }
};

  }
}

#endif
