/** \file WindowsMap.h
 *  \brief Classe base per una mappa di finsetre
 *  \author Paolo Grisleri
 **/
#ifndef _CHASWINDOWS_H
#define _CHASWINDOWS_H

#include <string>
#include <map>
#include <vector>

#include <boost/shared_ptr.hpp>
#include <boost/optional.hpp>

#include <UI/CWindows/CWindowFwd.h>

#include <UI/gold_ui_export.h>

namespace ui
{
namespace win
{
/// Permette agli utenti esterni di modificare
/// gli attributi di visibilita' della finestra
class GOLD_UI_EXPORT CWindowVisibilityProxy
{
  boost::shared_ptr<ui::win::CWindow> m_sp_win;
  public:
  CWindowVisibilityProxy();

  CWindowVisibilityProxy(boost::shared_ptr<ui::win::CWindow> Window);

  void Show();
  void Hide();
  bool IsVisible();
};


/// HasWindows permette ai suoi derivati di disporre di una lista di finestre
class GOLD_UI_EXPORT WindowsMap
{
    typedef std::map <std::string, boost::shared_ptr<ui::win::CWindow> > CWindowsMap;
    
  public:
    
    typedef std::map <std::string, CWindowVisibilityProxy> CWindowsProxiesMap;
    typedef CWindowsProxiesMap::iterator ItrType;
    typedef CWindowsProxiesMap::const_iterator ConstItrType;    

    /// Crea una finestra nella mappa
    void Insert( const std::string& name, unsigned int w=320, unsigned int h=240);    

    /// Inserisce una finestra estrena nella mappa
    void Insert( const std::string& name, boost::shared_ptr<ui::win::CWindow> sp_win);

    /// Elimina dalla mappa una finestra con un certo nome
    void Remove(const std::string& name);

    /// ripulisce la mappa
    void Clear();
    
    void PrintNodes();

    boost::optional<CWindowVisibilityProxy&> Window(const std::string& name="");
    CWindowsProxiesMap&     Windows();
    
    /**
     * Ritorna un riferimento ad una finestra specificata
     * @param Name Nome della finestra a cui accedere
     * @return riferimento alla finestra memorizzata nella mappa
     */
    ui::win::CWindow& Wnd(const std::string& name="");
    const ui::win::CWindow& Wnd(const std::string& name="") const;
    
    const std::vector<std::string> WindowNames() const;

  private:
    CWindowsProxiesMap m_proxies;
    CWindowsMap        m_windows;
};

} // namespace win
  
} // namespace ui
#endif
