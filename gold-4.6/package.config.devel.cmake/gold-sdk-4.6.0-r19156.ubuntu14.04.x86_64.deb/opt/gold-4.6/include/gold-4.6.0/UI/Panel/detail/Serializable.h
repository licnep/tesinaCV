#ifndef _DETAIL_SERIALIZABLE_H
#define _DETAIL_SERIALIZABLE_H


/* Motivazioni:
 * StringAdapter e' una classe virtuale pura che permette di astrarre un dato fisico
 *  o virtuale (puo' essere una risorsa remota per esempio).
 *
 * boost::function permettono di fare un solo compito alla volta: o impostare un valore, o richiederlo
 *  servirebbero pertanto due boost::function, una per scrivere un valore e uno per leggerlo. 
 *  dall'altra parte sarebbe possibile avere piu' listener (in ascolto) e un unico punto dove scrivere il valore (fisicamente)
 *
 * Gli StringAdapter permettono anche di mettere in un unica interfaccia (pertanto un contenitore omogeneo)
 *  la gestione di IO di variabili, e le callback utente.
 *
 * 1) Accedere in maniera virtuale a variabili in memoria eseguendo la conversione tra stringa e la memoria stessa
 *    string 
 *
 **/

#include <UI/Panel/detail/PanelTypes.h>
#include <boost/any.hpp>

#include <boost/property_tree/ptree_fwd.hpp>
#include <boost/archive/polymorphic_oarchive.hpp>
#include <boost/archive/polymorphic_iarchive.hpp>

#include <string>

namespace ui {
 namespace detail {

/// Modi possibili con cui accedere al dato
 enum AccessMode {
      InternalType, ///< tipo interno (esempio indice) non castato
      ValueType,    ///< tipo valore (esempio Enum)   non castato
      String,       ///< tipo valore castato a stringa
      ExternalType  ///< tipo esterno (esempio stringa)
    };

/// Interfaccia verso una classe che fa IO di stringhe
///  Questa classe e' l'unico requisito, essendo interfaccia tra PanelManager e dato
///  Deve permettere di serializare IO un valore  e degli attributi
class Serializable
{
public:
 virtual ~Serializable() { }

 /// return an extended_type_info  
 virtual std::string GetTypeID() const = 0;

 /// Return true if this class has valid value (or it is a callback, for example)
 virtual bool HasValue() const = 0;
 /// convert a string to internal value (usanto principalmente dai file INI)
 virtual void Set(const std::string & value, AccessMode mode = InternalType, int EventID = 0) = 0;
 /// convert internal value to string (usanto principalmente dai file INI)
 virtual void Get(std::string & value, AccessMode mode = InternalType) const = 0;
 /// set T to internal value
 virtual void Set(const boost::any & value, AccessMode mode, int EventID = 0) = 0;
 /// convert internal value to T
 virtual void Get(boost::any &, AccessMode mode) const = 0;
 /// set the internal value using a polymorphic_iarchive
 virtual void Set(boost::archive::polymorphic_iarchive&, AccessMode mode, int EventID = 0) = 0;
 /// get the internal value using a polymorphic_oarchive
 virtual void Get(boost::archive::polymorphic_oarchive&, AccessMode mode) const = 0;

 /// Return true if this class has valid attribute
  virtual bool HasAttributes() const = 0;
 /// convert in string the internal attribute (READ-ONLY)
  virtual void GetAttribute(boost::property_tree::ptree&) const = 0;
 /// serialize the internal attribute using a polymorphic_oarchive
  virtual void GetAttribute(boost::archive::polymorphic_oarchive&) const = 0;
 /// serialize the internal attribute using a boost::any
  virtual void GetAttribute(boost::any &) const = 0;
};

} // namespace detail
} // namespace ui
#endif
