/** @file CImageDrawConvert.h
 * @brief Layer di astrazione per convertire CImage tra loro per il rendering
 * @author Paolo Medici (medici@ce.unipr.it)
 * @date 17Apr2008
 **/
#ifndef _CIMAGE_COMPATIBILITY_H
#define _CIMAGE_COMPATIBILITY_H

#include <Data/CImage/CImage.h>
#include <UI/gold_ui_export.h>


namespace ui
{
namespace win
{

/// to provide debug of TypeInfo (NOTA: spostarlo in TypeInfo.h ???)
inline std::ostream & operator << (std::ostream &o, const cimage::CImage::Type & t) { /*o << t.name(); */return o; }

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/// Yet Another Conversion Structure
typedef cimage::CImage::SharedPtrConstType (* ConvertProc_t)(const cimage::CImage::SharedPtrConstType & src) ;

/// Yet Another Conversion Structure
struct ConvertImage {
    int priority;
    ConvertProc_t proc;
    ConvertImage() : priority(255),proc(NULL) {}
    ConvertImage(int _p, ConvertProc_t _proc) : priority(_p), proc(_proc) { }
};

/// Un singleton che contiene tutte le associazioni tra coppie di immagini e una funzione che converte una CImage in un altra
class GOLD_UI_EXPORT CImageConvertPool {
public:
 /// Chiave INPUT,OUTPUT
 typedef std::pair<cimage::CImage::Type, cimage::CImage::Type> KeyType;
 typedef std::map<KeyType, ConvertImage> MapType;
 MapType callbackMap_;
public:
    CImageConvertPool();
    ~CImageConvertPool();

    static CImageConvertPool & Instance();
    
    /// Cerca una coppia SRC,DST e ritorna il convertitore.
    /// @return se non esiste, ritorna NULL
    bool Find(const KeyType & key, ConvertImage & out) const;
    
    /// Trova il miglior Match tra il tipo sorgente e un array di destinazione,
    /// @return l'indice in @a dsts scelto o altrimenti -1 
    int FindBestMatching(const cimage::CImage::Type & src, const cimage::CImage::Type *dsts, int n_type, ConvertImage & out) const ;
    
    /// Converte la CImage @a src in uno dei tipi supportati
    cimage::CImage::SharedPtrConstType Convert(const cimage::CImage::SharedPtrConstType & src, const cimage::CImage::Type *dsts, int n_type);

    /// Aggiunge una conversione IN,OUT a una Conversione
    bool DoAdd(const cimage::CImage::Type & lhs, const cimage::CImage::Type & rhs, const ConvertImage & value);
};



/// Registra un cast che trasforma CImage (S) in D usando uno static_cast
template<class S, class D> 
struct StaticCastConvert {
  static cimage::CImage::SharedPtrConstType CreateObject(const cimage::CImage::SharedPtrConstType & src) { 
      // return static_cast<const D &>(src);
      return src;
    }
  
  StaticCastConvert() {
      CImageConvertPool::Instance().DoAdd(S::type_info(),D::type_info(), ConvertImage(0, CreateObject) );
    } 
};

/// Registra una conversione che porta S su D usando l'operator >>
template<class S, class D>
class DrawConvert {
public:
static cimage::CImage::SharedPtrConstType ConvertObject(const cimage::CImage::SharedPtrConstType & _src)
{
    const S & src = static_cast<const S &>(*_src);
    D *dst = new D(src.W(),src.H());
    src >> *dst;
    return cimage::CImage::SharedPtrConstType(dst);
}

  DrawConvert(int priority) {
      CImageConvertPool::Instance().DoAdd(S::type_info(),D::type_info(),ConvertImage(priority, ConvertObject));
    } 
};

/// Registra una conversione che porta S su D passando da T
template<class S, class T, class D>
class DrawConvert2 {
public:
static cimage::CImage::SharedPtrConstType ConvertObject(const cimage::CImage::SharedPtrConstType &_src)
    {
    const S & src = static_cast<const S &>(_src);
    T tmp(src.W(),src.H());
    D *dst = new D(src.W(),src.H());
    src >> tmp >> *dst;
    return  cimage::CImage::SharedPtrConstType(dst);
    }

  DrawConvert2(int priority) {
      CImageConvertPool::Instance().DoAdd(S::type_info(),D::type_info(),ConvertImage(priority, ConvertObject));
    } 
};

  
} // namespace win
} // namespace ui


/// Praticamente forza il cast da A ad B
#define CIMAGE_CAST(A,B)  ui::win::StaticCastConvert<A,B> di_##A##_##B; 

/// Esegue la conversione da A ad B
#define CIMAGE_CONVERT(A,B,PRIORITY)  ui::win::DrawConvert<A,B> cv_##A##_##B(PRIORITY); 

/// Esegue la conversione da A ad B, passando da C
#define CIMAGE_CONVERT2(A,C,B, PRIORITY)  ui::win::DrawConvert2<A,B,C> cx_##A##_##B(PRIORITY); 

#endif
