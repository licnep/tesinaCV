#ifndef _DETAIL_SERIALIZERS_H
#define _DETAIL_SERIALIZERS_H

#include <UI/Panel/detail/Serializable.h>
#include <Libs/Renderer/Data/Types.h>

// NOTE: viene usato strcast per 2 motivi:
//       (1) la conversione tra stringa a double/float non lancia una eccezione se manca il .
//       (2) la conversione tra e a stringa e bool gestisce casi come y,n,true,false,on,off (tuttavia potrebbe far parte del protocollo e infischiarsene)
//      si potrebbe usare lexical_cast se si potesse comunicare al client l'errore e lasciare al client la gestione dell'errore.
#include <Libs/INIFiles/strcast.h>

#include <stdexcept>
#include <stdint.h>

#include <boost/function.hpp> // generic callback

#ifdef USE_BOOST_SIGNAL2
#include <boost/signals2.hpp>
#else
#include <boost/signal.hpp>
#endif

#include <boost/property_tree/ptree.hpp>
#include <boost/lexical_cast.hpp>

// TODO: dovrebbe essere forse l'utente a istanziare questi include?
#include <boost/serialization/string.hpp>
#include <boost/serialization/vector.hpp>
#include <boost/serialization/map.hpp>

#include <boost/preprocessor/seq/for_each.hpp>

#define RANGE_ATTR_TYPES (bool) (int8_t) (uint8_t) (int16_t) (uint16_t) (int32_t) (uint32_t) (int64_t) (uint64_t) (float) (double)


#define DECLARE_RANGE_ATTR_SERIALIZE(r, n, data) \
namespace boost\
{\
    namespace serialization\
    {\
        template<class Archive>\
        void serialize(Archive& ar, ui::var::types::range<data>::attributes_type& attr, const unsigned int version)\
        {\
             ar & attr.min;\
             ar & attr.max;\
             ar & attr.step;\
        }\
    }\
}

BOOST_PP_SEQ_FOR_EACH(DECLARE_RANGE_ATTR_SERIALIZE, ~ , RANGE_ATTR_TYPES)

/*

 VALUE T=X=INDEX -> T=X=INDEX Set(stringa, boost::any, access:any, boost::ioarchive)
       Metodo per convertire std::string <-> T

 RANGE expand VALUE + ATTRIBUTES

 CHOICE   T=X -> T=X Set(stringa),
        INDEX -> T

 MAP        X -> X
	    T -> X
        INDEX -> X

 TREE       X -> X
            T -> X
        INDEX -> X

*/

namespace ui {

namespace detail {

/// Tipi interni basi dei tipi finali
/*@{*/

/// a boost_function generic adapter
///  implements base costructors, string conversions and callback system
/// implementa il livello piu' basso di dialogo con il sottosistema
template<class T>
class adapter {
    static const int max_events = 3;
public:
    typedef T Type;
    typedef boost::function0< T > OnGet;
    typedef boost::function1<void, T> OnSet;
private:
#ifdef USE_BOOST_SIGNAL2
    boost::signals2::signal<void (T)> m_set[max_events];
#else
    boost::signal<void (T)> m_set[max_events];
#endif

    OnGet m_get;

    static void internal_set_pointer(T *dst, T src)
    {
        *dst = src;
    }

    static T internal_get_pointer(const T *src)
    {
        return *src;
    }

    adapter(const adapter<T> & pr) { }

public:

    /// nothing
    adapter() {
    }
    /// costruttore con un puntatore.
    adapter(T *ptr) {
        ConnectToPointer(ptr);
    }
    /// costruttore con due boost::function
    adapter(const typename adapter<T>::OnSet & s, const typename  adapter<T>::OnGet & g)
    {
        ConnectSet(s);
        ReplaceGet(g);
    }

    /// virtual dtor
    virtual ~adapter() { }

    /// Set Diretta
    /// call the OnSet values (for the set/get policy described below)
    /// Tutte le chiamate verso la memoria passano per questa funzione
    void set(T value, int EventID) {
        m_set[EventID](value);
    }

    /// Set usando la stringa per i file di configurazione
    void internal_set(const std::string & value, int EventID)
    {
       	set( vl::numeric_cast< T >(value), EventID );
    }

    /// Set usando boost::any
    void internal_set(const boost::any & value, int EventID)
    {
        set( boost::any_cast< T >(value), EventID );
    }

    /// Set usando un boost::archive::polymorphic_iarchive
    void internal_set(boost::archive::polymorphic_iarchive&i, int EventID) {
        T clone;
        i & clone;
        set(clone, EventID);
    }

    /// Get Diretta
    /// call the OnGet values (for the set/get policy described below)
    /// Tutte le chiamate verso la memoria passano per questa funzione
    T get() const {
        return m_get();
    }

    /// conversione interna per il file di configurazione
    void internal_get (std::string & value) const
    {
        value = vl::string_cast(m_get());
    }

    /// Get di boost::any
    void internal_get (boost::any & value) const
    {
        value = boost::any(m_get());
    }

    void internal_get(boost::archive::polymorphic_oarchive&o) const {
        T value = m_get();
        o & value;
    }

    /// Scollega le Set
    void DisconnectAllSet(int EventID = 0)
    {
        m_set[EventID].disconnect_all_slots();
    }

    /// Aggiunge una nuova callback chiamata per settare un valore
    void ConnectSet(const OnSet & t, int EventID = 0)
    {
        m_set[EventID].connect(t);
    }

    /// Collega la Set con un puntatore a T
    void ConnectSetToPointer(T *ptr, int EventID = 0)
    {
        m_set[EventID].connect( boost::bind(adapter<T>::internal_set_pointer, ptr, _1) );
    }

    /// Collega la Get con un puntatore a T
    void ConnectGetToPointer(T *ptr)
    {
        m_get = boost::bind(adapter<T>::internal_get_pointer, ptr);
    }

    /// collega le Set/Get con un puntatore
    void ConnectToPointer(T *ptr)
    {
        ConnectSetToPointer(ptr);
        ConnectGetToPointer(ptr);
    }

    /// Sostituisce la Get con un'altra callback
    void ReplaceGet(const OnGet & t)
    {
        m_get = t;
    }

};

/** il collection_adapter espande l'adapter nel caso di collezioni di oggetti
  *  genitore di choice e map (non so bene se di tree)
  *  LabelType e' il tipo della label (stringa for es), T e' il tipo interno (esempio enum)
  * Di fatto esistono 3 Elementi: Il tipo esterno (la label, stringa) che viene usata per comunicare con l'umano,
  *  Il tipo interno (che puo' essere qualunque cosa e comunica con la propria macchina), il tipo indice
  *  che serve per comunicare ad alta efficienza tra macchine */
template<class LabelType_, class T>
struct collection_adapter : public Serializable, public adapter<T> {
public:
    /// Tipo della Label
    typedef LabelType_ LabelType;
    /// Tipo Indice
    typedef int IndexType;

    typedef typename ui::var::types::collection< LabelType >::attributes_type LabelTypeList;

    typedef typename ui::var::types::collection< LabelType >::value_type ValueType;

    typedef std::vector<LabelType> choice_attributes;

    /// Lista di oggetti scambiata con l'esterno (nel caso delle choice e delle map)
    ///   non viene usato nei tree
    LabelTypeList m_labels;

public:

    collection_adapter() { }
    collection_adapter(T *ptr) : adapter<T>(ptr) { }
    collection_adapter(const  typename adapter<T>::OnSet & s, const typename boost::function0< T > & g) : adapter<T>(s,g) { }

    virtual ~collection_adapter() { }

    /// Metodi per convertire un indice in un T interno
    virtual const T & IndexToInternalValue(int i) const = 0;

    /// Metodi per convertire un T nell'indice interno
    virtual int InternalValueToIndex(const T & t) const = 0;

    /// Metodi per convertire una label nell'indice interno
    int LabelToIndex(const LabelType & t) const
    {
        for(typename LabelTypeList::const_iterator i = m_labels.begin(); i!=m_labels.end(); ++i)
            if( *i == t)
                return i - m_labels.begin();
        return -1;
    }

    /// Metodi per convertire una label nell'indice interno
    const LabelType & IndexToLabel(int i) const
    {
        return m_labels[i];
    }

    /// Converte una label nel valore interno
    const T & LabelToInternalValue(const LabelType & t) const
    {
        int idx = LabelToIndex(t);
        if(idx == -1)
            throw std::runtime_error("Impossible convert label");
        return IndexToInternalValue(idx);
    }

    const LabelType & InternalValueToLabel(const T & t) const
    {
        int idx = InternalValueToIndex(t);
        if(idx == -1)
            throw std::runtime_error("Impossible convert label");
        return IndexToLabel(idx);
    }


    bool HasValue() const {
        return true;
    }

    void Set (const std::string & value, AccessMode mode, int EventID)
    {
        if(mode == ui::detail::InternalType)
        {
            this->internal_set( value, EventID );
        }
        else if(mode == ui::detail::ValueType)
        {
            throw std::runtime_error("unimplemented");
        }
        else if(mode == ui::detail::String)
        {
            throw std::runtime_error("unimplemented");
        }
        else if(mode == ui::detail::ExternalType)
        {
            this->set( LabelToInternalValue( boost::lexical_cast<LabelType>(value) ), EventID );
        }
    }

    void Get(std::string & value, AccessMode mode) const
    {
        if(mode == ui::detail::InternalType)
        {
            this->internal_get(value);
        }
        else if(mode == ui::detail::ValueType)
        {
            throw std::runtime_error("unimplemented");
        }
        else if(mode == ui::detail::String)
        {
            throw std::runtime_error("unimplemented");
        }
        else if(mode == ui::detail::ExternalType)
        {
            value = boost::lexical_cast<std::string>( InternalValueToLabel(this->get()) ) ;
        }
    }


    ///
    void SetByIndex(const ValueType & indexes, int EventID) {
        /*	  if(indexes.empty())
        	      throw std::out_of_range("choice");*/
        for(std::vector<int>::const_iterator i = indexes.begin(); i != indexes.end(); ++i)
            this->set( IndexToInternalValue ( *i ), EventID );
    }
    ///
    void GetByIndex(ValueType & indexes) const {
        indexes.clear();
        indexes.push_back( InternalValueToIndex( this->get() ) );
    }

    /// implements set T to internal value
    void Set (const boost::any & value, AccessMode mode, int EventID)
    {
        if(mode == ui::detail::InternalType)
        {
            this->internal_set(value, EventID);
        }
        else if(mode == ui::detail::ValueType)
        {
            SetByIndex(boost::any_cast< ValueType >(value), EventID);
        }
    }

    /// implements convert internal value to T
    void Get (boost::any & value, AccessMode mode) const
    {
        if(mode == ui::detail::InternalType)
        {
            this->internal_get(value);
        }
        else if(mode == ui::detail::ValueType)
        {
            ValueType list;
            GetByIndex(list);
            value = boost::any(list);
        }
    }

    void Set(boost::archive::polymorphic_iarchive&i, AccessMode mode, int EventID) {
        if(mode == ui::detail::InternalType)
        {
            this->internal_set(i, EventID);
        }
        else if(mode == ui::detail::ValueType)
        {
            ValueType list;
            i & list;
            SetByIndex(list, EventID);
        }
    }

    void Get(boost::archive::polymorphic_oarchive&o, AccessMode mode) const {
        if(mode == ui::detail::InternalType)
        {
            this->internal_get(o);
        }
        else if(mode == ui::detail::ValueType)
        {
            ValueType list;
            GetByIndex(list);
            o & list;
        }
    }

    bool HasAttributes() const {
        return !m_labels.empty();
    }

    void GetAttribute(boost::archive::polymorphic_oarchive&o) const
    {
        o & m_labels;
    }

    void GetAttribute(boost::any &a) const {
        a = boost::any(m_labels);
    }

    void GetAttribute(boost::property_tree::ptree&pt) const
    {
        boost::property_tree::ptree item;
        for(typename LabelTypeList::const_iterator i = m_labels.begin(); i!=m_labels.end(); ++i)
            // item.put(*i);
            item.push_back(boost::property_tree::ptree::value_type(vl::string_cast(*i), boost::property_tree::ptree( vl::string_cast(*i) )));
        pt.push_back(boost::property_tree::ptree::value_type("item", item));
    }

};

/// Il map adapter estende il collection_adapter aggiungendo una collezioni di tipi diversa dal Label usata internamente per la conversione
template<class LabelType, class T>
struct map_adapter: public collection_adapter<std::string, T>  {
public:

/// Il tipo interno
    typedef T InnerType;

/// il tipo di lista che viene usata per fare il lookup tra indice e T
    typedef typename std::vector< T > KeyTypeList;

/// Le chiavi interne
    KeyTypeList m_keys;
public:

    map_adapter(const typename adapter<T>::OnSet & s, const typename boost::function0< T > & g) : collection_adapter<std::string, T>(s,g) { }

    map_adapter(T* t) : collection_adapter<std::string, T>(t) {}

    map_adapter() : collection_adapter<std::string, T>() { }

    virtual ~map_adapter() { }

    /// Metodi per convertire un indice in un T interno
    virtual const T & IndexToInternalValue(int i) const
    {
        return m_keys[i];
    }

    ///
    virtual int InternalValueToIndex(const T & t) const
    {
        throw std::runtime_error("choice::InternalValueToIndex unimplemented");
    }

/// Convert a @a label to a internal type T
    const T & label_to_value(const std::string & label)
    {
        for(int i = 0 ; i < this->m_labels.size(); ++i)
            if(this->m_labels[i] == label)
                return m_keys[i];
        throw std::out_of_range("label " + label + " not exists");
    }

/// Convert a @a value in a @a label
    void value_to_label(std::string & label, const T & value)
    {
        // FIND Second, return value
        for( unsigned int i =0; i < m_keys.size(); ++i)
            if(m_keys[i] == value)
                return this->m_labels[i];
        // throw exception
        throw std::out_of_range("tree: value not found");
    }

};

/*@}*/

////////////////////////////////////////////////////////////////////////////////

/** @brief Adapter che ha uno stato interno non accessibile
 *  mantiene lo stato di una variabile sotto forma di stringa e lo ritorna.
 * serve quando l'utente non fornisce uno storage per un binding.
 **/
class storage: public Serializable {
    std::string m_value;
public:
    storage(const std::string & value=std::string()) : m_value(value) { }
    virtual ~storage() { }

    std::string GetTypeID() const {
        return "value<string>";
    }
    bool HasValue() const {
        return true;
    }
    void Set(const std::string & value, int UnusedID) {
        m_value = value;
    }
    void Get(std::string & value) const {
        value = m_value;
    }

    void Set(const boost::any & value, AccessMode mode, int UnusedID) {
        m_value = boost::any_cast<std::string>(value);
    }
    void Get(boost::any & value, AccessMode mode) const {
        value = boost::any(m_value);
    }

    void Set(boost::archive::polymorphic_iarchive&i, AccessMode mode, int EventID) {
        i & m_value;
    }
    void Get(boost::archive::polymorphic_oarchive&o, AccessMode mode) const {
        o & m_value;
    }

    bool HasAttributes() const {
        return false;
    }
    void GetAttribute(boost::property_tree::ptree&) const { }
    void GetAttribute(boost::archive::polymorphic_oarchive&) const { }
    void GetAttribute(boost::any &) { }
};


// ============================= callback ======================

/*@{*/
/// Queste funzioni non sono degli adapter, ma delle semplici callback avvisate quando viene eseguita una azione
class callback: public Serializable {
    static const int max_events = 3;
public:
    ///
#ifdef USE_BOOST_SIGNAL2
    typedef boost::signals2::signal<void()> OnEvent;
#else
    typedef boost::signal<void()> OnEvent;
#endif

    OnEvent m_event[max_events];
public:
    explicit callback(const OnEvent::slot_type &callback) {
        m_event[0].connect(callback);
    }
    virtual ~callback() {}

    std::string GetTypeID() const {
        return "action";
    }

    bool HasValue() const {
        return false;
    }
    void connect(const OnEvent::slot_type &callback, int EventID = 0) {
        m_event[EventID].connect(callback);
    }
    void disconnect(int EventID = 0) {
        m_event[EventID].disconnect_all_slots();
    }

    void Set(const std::string & value, AccessMode mode, int EventID) {
        m_event[EventID]();
    }
    void Get(std::string & value, AccessMode mode) const {  }

    void Set(const boost::any & value, AccessMode mode, int EventID) {
        m_event[EventID]();
    }
    void Get(boost::any & value,  AccessMode mode) const {  }

    void Set(boost::archive::polymorphic_iarchive&i, AccessMode mode, int EventID) {
        m_event[EventID]();
    }
    void Get(boost::archive::polymorphic_oarchive&o, AccessMode mode) const { }

    bool HasAttributes() const {
        return false;
    }
    void GetAttribute(boost::property_tree::ptree&) const { }
    void GetAttribute(boost::archive::polymorphic_oarchive&) const { }
    void GetAttribute(boost::any &) const { }

};
/*@}*/

template<class T>
class value: public Serializable, public adapter<T> {

public:

    typedef typename ui::var::types::value<T>::actions Actions;

    /// nothing
    value() { }
    /// costruttore con un puntatore.
    value(T *ptr) : adapter<T>(ptr) { }
    /// costruttore con due boost::function
    value(const typename adapter<T>::OnSet & s, const typename adapter<T>::OnGet & g) : adapter<T>(s,g) { }

    virtual ~value() {}

    bool HasValue() const {
        return true;
    }

    void Set (const std::string & value, AccessMode mode, int EventID)
    {
        this->internal_set( value, EventID );
    }

    void Get(std::string & value, AccessMode mode) const
    {
        this->internal_get(value);
    }

    /// implements set T to internal value
    void Set (const boost::any & value, AccessMode mode, int EventID)
    {
        this->internal_set(value, EventID);
    }

    /// implements convert internal value to T
    void Get (boost::any & value, AccessMode mode) const
    {
        this->internal_get(value);
    }

    void Set(boost::archive::polymorphic_iarchive&i, AccessMode mode, int EventID) {
        this->internal_set(i, EventID);
    }

    void Get(boost::archive::polymorphic_oarchive&o, AccessMode mode) const {
        this->internal_get(o);
    }

    std::string GetTypeID() const {
        return ui::var::types::value<T>::type_name();
    }

    bool HasAttributes() const {
        return false;
    }
    void GetAttribute(boost::property_tree::ptree&) const { }
    void GetAttribute(boost::archive::polymorphic_oarchive&) const { }
    void GetAttribute(boost::any &) const { }
};

/// detail for range object
///  espande un value a gestire un range di valori
template<class T>
class range: public value<T> {
    typename ui::var::types::range<T>::attributes_type m_attr;
public:

    typedef typename ui::var::types::range<T>::actions Actions;

    range() { }
    range(T *ptr) : value<T>(ptr) { }
    range(const typename adapter<T>::OnSet & s, const typename boost::function0< T > & g) : value<T>(s,g) { }

//  range(T min, T max, T step=T(1)) : m_min(min), m_max(max), m_step(step) { }
    virtual ~range() { }

    std::string GetTypeID() const {
        return ui::var::types::range<T>::type_name();
    }

    void Set(T min, T max, T step)
    {
        m_attr.min = min;
        m_attr.max = max;
        m_attr.step = step;
    }

    bool HasAttributes() const {
        return true;
    }

    void GetAttribute(boost::archive::polymorphic_oarchive&o) const
    {
        o & m_attr;
    }

    void GetAttribute(boost::any &a) const {
        a = boost::any(m_attr);
    }

    void GetAttribute(boost::property_tree::ptree&pt) const
    {
        pt.put("min", vl::string_cast(m_attr.min));
        pt.put("max", vl::string_cast(m_attr.max));
        pt.put("step", vl::string_cast(m_attr.step));
        pt.put("type", ui::var::types::type_name<T>::str());
    }

};

/// detail for choice object
///  espande un adapter a gestire una scelta di azioni
///  il valore collegato e' l'indice nella scelta
/// la choice ha un vector<T> che comunica all'esterno (LABEL=INTERNALVALUE)
template<class T>
class choice: public collection_adapter<T, T> {
public:

    choice() { }
    choice(T *ptr) : collection_adapter<T, T>(ptr) { }
    choice(const  typename adapter<T>::OnSet & s, const typename boost::function0< T > & g) : collection_adapter<T, T>(s,g) { }

    typedef typename ui::var::types::collection<T>::actions Actions;

    virtual ~choice() { }

    /// Metodi per convertire un indice in un T interno
    virtual const T & IndexToInternalValue(int i) const
    {
        return this->m_labels[i];
    }

    ///
    virtual int InternalValueToIndex(const T & t) const
    {
        for(typename collection_adapter<T, T>::LabelTypeList::const_iterator ii = this->m_labels.begin(); ii != this->m_labels.end(); ++ii)
            if(t == *ii)
                return std::distance(this->m_labels.begin(), ii);

        return -1;
//       throw std::runtime_error("choice::InternalValueToIndex unimplemented");
    }


    template<class _Iterator>
    void add(_Iterator begin, _Iterator end)
    {
        for(_Iterator i=begin; i!=end; ++i)
            this->m_labels.push_back(*i);
    }

    template<class _Iterator>
    void add(const _Iterator & value)
    {
        this->m_labels.push_back(value);
    }

    void clear()
    {
        this->m_labels.clear();
    }

    template<class _Iterator>
    void reset(_Iterator begin, _Iterator end)
    {
        this->m_labels.clear();
        add(begin, end);
    }

    std::string GetTypeID() const {
        return  ui::var::types::collection<T>::type_name();
    }

};

/// bidirectional 'map'. id and label are the same, conversion client-side.
/// do not use strcast policy but use the map directly
/// Il tramite con la classe e' il tipo T, mentre con il mondo esterno e' attraverso la stringa
/// la map ha un vector<X> (LabelTypeList) che comunica all'esterno  e un vector<T> interno con in valori interni (KeyTypeList)
template<class T>
class map: public map_adapter<std::string, T>  {
public:

    map(T *ptr) : map_adapter<std::string, T>(ptr) { }
    map(const typename adapter<T>::OnSet & s, const typename boost::function0< T > & g) : map_adapter<std::string, T>(s,g) { }
    map() : map_adapter<std::string, T>() { }

    typedef typename ui::var::types::collection<std::string>::actions Actions;

    virtual ~map() { }

    bool HasValue() const {
        return true;
    }

/// insert a single element in map
    void insert(const typename map_adapter<std::string, T>::LabelType & label, const T & key)
    {
        this->m_labels.push_back(label);
        this->m_keys.push_back(key);
    }

    template<class _Iterator>
    void add(_Iterator begin, _Iterator end)
    {
        for(_Iterator i=begin; i!=end; ++i)
            add(*i);
    }

    template<class _Iterator>
    void set(_Iterator begin, _Iterator end)
    {
        clear();
        add(begin, end);
    }

    template<class _Iterator>
    void add(const _Iterator & value)
    {
        insert(value.first, value.second);
    }

    void clear()
    {
        this->m_labels.clear();
        this->m_keys.clear();
    }

    /// Metodi per convertire un indice in un T interno
    virtual const T & IndexToInternalValue(int i)
    {
        return this->m_keys[i];
    }

    ///
    virtual int InternalValueToIndex(const T & t) const
    {
        for(typename map_adapter<std::string, T>::KeyTypeList::const_iterator ii = this->m_keys.begin(); ii != this->m_keys.end(); ++ii)
            if(t == *ii)
                return std::distance(this->m_keys.begin(), ii);

        return -1;
//       throw std::runtime_error("choice::InternalValueToIndex unimplemented");
    }

    std::string GetTypeID() const {
        return  ui::var::types::collection<std::string>::type_name();
    }

};

/** tree
 * L'utente inserisce un albero di LABEL, T
 *  L'unica differenza rispetto alla mappa e' il modo in cui viene serializzato l'attributo
 *  L'importante e' come vengono costruiti i vettori di label e chiavi.
 */
template<class T>
class tree: public map_adapter<std::string, T> {
public:

    typedef std::string LabelType;


    /// user tree
    typedef boost::property_tree::basic_ptree<LabelType, T> ptree;

    typedef typename ui::var::types::range<LabelType>::actions Actions;

    /// external tree
    typedef typename ui::var::types::tree< LabelType >::attributes_type eptree;

    /// user tree
    eptree m_exchange;

    int m_guid;

public:

    tree(const typename adapter<T>::OnSet & s, const typename boost::function0< T > & g) : map_adapter<std::string, T>(s,g), m_guid(0) { }
    tree() : map_adapter<std::string, T>() { }

    virtual ~tree() { }

    bool HasValue() const {
        return true;
    }

/// appende a @a root un albero utente @a user
    void insert(const ptree & user, eptree & root)
    {
        for(typename ptree::const_iterator itr = user.begin();
                itr != user.end();
                ++itr)
            if((*itr).second.empty()) {
                // non ha figli: allora e' un figlio e non un nodo
                this->m_keys.push_back( (*itr).second.data() );
                this->m_labels.push_back( (*itr).first );
                root.push_back(eptree::value_type((*itr).first, m_guid));
                m_guid++;
            }
            else
            {
                // ha figli: e' un nodo
                eptree child;
                insert((*itr).second, child);
                root.push_back(eptree::value_type((*itr).first, child));
            }
    }

/// replace the inner tree with an external tree
    void replace(const ptree & user)
    {
        m_guid = 0;
        this->m_keys.clear();
        this->m_labels.clear();
        m_exchange.clear();

        insert(user, m_exchange);
    }

    std::string GetTypeID() const {
        return ui::var::types::tree<T>::type_name();
    }

    /// Metodi per convertire un indice in un T interno
    virtual const T & IndexToInternalValue(int i)
    {
        return this->m_keys[i];
    }

    ///
    virtual int InternalValueToIndex(const T & t) const
    {
        for(typename map_adapter<std::string, T>::KeyTypeList::const_iterator ii = this->m_keys.begin(); ii != this->m_keys.end(); ++ii)
            if(t == *ii)
                return std::distance(this->m_keys.begin(), ii);

        return -1;
        // throw std::runtime_error("choice::InternalValueToIndex unimplemented");
    }

    bool HasAttributes() const
    {
        return m_guid > 0;
    }

    void GetAttribute(boost::archive::polymorphic_oarchive&o) const
    {
        o & m_exchange;
    }

    void GetAttribute(boost::any &a) const {
        a = boost::any(m_exchange);
    }

    void GetAttribute(boost::property_tree::ptree&pt) const
    {
        /*	boost::property_tree::ptree item;
        	for( unsigned int i =0; i < m_keys.size(); ++i)
        		item.push_back(boost::property_tree::ptree::value_type(m_labels[i], boost::property_tree::ptree( m_labels[i] )));
        	pt.push_back(boost::property_tree::ptree::value_type("item", item));*/
    }

};

} // detail

};

#endif
