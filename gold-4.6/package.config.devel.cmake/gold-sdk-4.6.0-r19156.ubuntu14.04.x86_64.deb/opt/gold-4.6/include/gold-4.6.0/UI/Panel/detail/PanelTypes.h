#ifndef _UI_PANELTYPES_H
#define _UI_PANELTYPES_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * \file PanelTypes.h
 * \author Paolo Medici(medici@vislab.it)
 * \date 2010-12-30
 **/

#include <stdint.h>

namespace ui
{
    namespace detail
    {
        /// The GUID for Listener
        typedef int32_t listener_id_t;

        /// The GUID for widget used internally
        typedef int64_t widget_guid_t;
	
    #define nullguid	ui::detail::widget_guid_t(-1)
    }
}

#endif
