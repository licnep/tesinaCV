#ifndef _SINGLE_THREAD_WINDOW_H
#define _SINGLE_THREAD_WINDOW_H
#include "CDrawingQueue.h"

namespace ui{
  namespace win{

/// classe glue tra il gestore thread e il window manager in caso di single thread
template<class ThreadManager, class WindowManager>
class SingleThreadWindow: public ThreadManager, public WindowManager {
 public:

/*@{*/
    bool SendRedraw() {
        return ThreadManager::sendRedraw(WindowManager::GetWindow());
        }

    bool RaiseWindow() {
       return ThreadManager::raiseWindow(WindowManager::GetWindow());
       }

    bool MapWindow() {
      return ThreadManager::mapWindow(WindowManager::GetWindow());
      }

    bool WithdrawWindow() {
      return ThreadManager::withdrawWindow(WindowManager::GetWindow());
      }

    bool UnmapWindow() {
      return ThreadManager::unmapWindow(WindowManager::GetWindow());
      }

    /// return current pointer in (coordinate)
    bool QueryPointer(math::Point2i & pt) {
        return ThreadManager::queryPointer(WindowManager::GetWindow(), pt);
        }

     /// Muove la finestra
     bool MoveWindow(int x, int y)  {
        return ThreadManager::moveWindow(WindowManager::GetWindow(), x, y);
        }

     /// Ridimensiona la finestra
     bool ResizeWindow(int W, int H) {
        return ThreadManager::resizeWindow(WindowManager::GetWindow(), W, H);
        }

     bool SetWindowTitle(Window w, const char *str) {
        return ThreadManager::setWindowTitle(WindowManager::GetWindow(), str);
        };
/*@}*/

};
  } // namespace win
} // namespace ui

#endif
