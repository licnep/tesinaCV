/** @file CWindowCore_OpenGLST.h 
  * @author Paolo Medici
  **/
#ifndef _CWINDOWCORE_OPENGLST_H
#define _CWINDOWCORE_OPENGLST_H

#include "CWindowCore_OpenGL.h"
#include "CWindowCore_GLX.h"

namespace ui{
  namespace win{

/// Classe che implementa le funzioni di CWIndowCore_OpenGL SingleThread
class CWindowCore_OpenGLST: public CWindowCore_GLX
{ 
  public:
     /// expose event
    bool expose;
  private:
    virtual GLXThreadManager *getManager(void);
  protected:
    bool GLGetContext(void);
    bool GLReleaseContext(void);
  public:
    CWindowCore_OpenGLST(const WindowCreationParams & param);
    virtual ~CWindowCore_OpenGLST(void);

    virtual std::string GetConnectionString() const;

    bool GLWindowCreate(void);  
    bool GLWindowDestroy_internal(bool last_window);
    
    bool GetImage(cimage::CImage & img);
    
    /// Metodo per inserire un CWindowCommand dentro alla coda X
    bool PushCommand(const SPWindowCommand & Command); 
      
    bool DrawText(const math::Point3d & p, const char *Text);
    bool GetTextSize(double &X, double &Y, const char *Texte);
    
    virtual bool GLRefresh(bool soft=true);

    /// Single Thread Event Handler
    bool XEventHandler(const XEvent & e);      

	CWindowCore & Core(void) { return *this; }
};

  } // namespace win
} // namespace ui

#endif
