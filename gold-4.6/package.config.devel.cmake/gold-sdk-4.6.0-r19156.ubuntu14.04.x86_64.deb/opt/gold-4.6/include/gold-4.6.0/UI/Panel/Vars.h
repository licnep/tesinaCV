/** \file Vars.h
  * \brief classi per istanziare tipo di dati bindabili
  *
  * Available type are:
  * - ui::var::Callback    a callback type
  * - ui::var::Value       a singular value (pointer or set/get callback)
  * - ui::var::Range       a value bounded by a range
  * - ui::var::Choice      a value bounded to a limited list of choices
  * - ui::var::map         a value bounded to a map of choices
  **/

#ifndef _UI_VARS_H
#define _UI_VARS_H


#include <UI/gold_ui_export.h>
#include <UI/Panel/Widget.h>

#include <UI/Panel/detail/PanelManager.h>
#include <UI/Panel/detail/PanelTypes.h>
#include <UI/Panel/detail/Serializers.h>

#include <boost/any.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/iteration/local.hpp>
                    
namespace ui
{
	/** \brief Namespace for managing user interface variables */
    namespace var
    {
        /** a pure container to give a type to GUID for embedding in a button */
        class GOLD_UI_EXPORT Popup
        {
            detail::widget_guid_t m_guid;

            public:

                explicit Popup(detail::widget_guid_t guid);
                explicit Popup(const ui::wgt::Widget& w);
		~Popup();

                operator detail::widget_guid_t() const { return m_guid; }
                
                
        };

        /// Tipo base per le variabili. Implementa solo la raccolta dei guid e le chiamate per chiedere il broadcast dei valori
        ///  a tutti i listener
        struct GOLD_UI_EXPORT Base
        {
            detail::widget_guid_t m_guid;

            public:

                Base();
                explicit Base(detail::widget_guid_t guid);
		// costruttore di copia
		Base(const Base & guid);
		
                ~Base(); 
		
		void operator = (const Base & guid);

                operator detail::widget_guid_t() const { return m_guid; }

                /// broadcast changes of linked value to all listener
                void Update();

                template<class T>
                T GetValue() const
                {
                    boost::any value;
                    PanelManagerInstance().Get(m_guid, value);
                    return boost::any_cast<T>(value);
                }

                template<class T>
                void SetValue(const T& value)
                {
                    PanelManagerInstance().Set(m_guid, boost::any(value));
                }
        };

        class GOLD_UI_EXPORT Callback : public Base
        {
            detail::callback *m_obj;

            public:
	      
	      Callback():m_obj(0)
                {
                   
                }

                /** Declare a callback type
                * \code
                * ui::var::Callback( boost::bind(&myClass::Callback, this) );
                * \endcode
                **/
                explicit Callback(const boost::function0<void> & fn)
                {
                    PanelManagerInstance().Widget(m_guid).serializer = m_obj = new detail::callback(fn);
                }

                /** this action permit to connect to multiple callback on event **/
                inline void Connect(const boost::function0<void> & fn) { m_obj->connect(fn); }

                /** Disconnect all the event */
                inline void Disconnect() { m_obj->disconnect(); }
        };

        enum ConnectTypes
        {
            set,
            get,
            both
        };

        /// Extend the widget in order to use a dynamic_tbase with set/get functions
        ///  this is only an internal type
        template<class _Adapter>
        // class GOLD_UI_EXPORT TBase : public Base // PG: patch for dll import/export
		class TBase : public Base
        {
            typedef typename _Adapter::Type Type;
            typedef typename boost::function1<void, Type> OnSetType;
            typedef typename boost::function0< Type > OnGetType;

            protected:

                /// a copy of inner object
                _Adapter *m_this;

            public:

                typedef typename _Adapter::Actions Actions;
                
                /** TODO: se si richiede la costruzione da un guid (recupero dell'oggetto),
                *  implementare un costruttore da guid_widget usando adapter_cast + dinamyc_cast internamente */

                /// declare an empty T binder
                TBase()
                {
                    PanelManagerInstance().Widget(m_guid).serializer = m_this = new _Adapter;
                }

                /// declare a value and bind to pointer
                TBase(Type * obj)
                {
                    PanelManagerInstance().Widget(m_guid).serializer = m_this = new _Adapter(obj);
                }

                /// declare a T bound to a Set/Get boost functions
                TBase(const OnSetType & s, const OnGetType & g)
                {
                    PanelManagerInstance().Widget(m_guid).serializer = m_this = new _Adapter(s,g);
                }

                /** Release all Set **/
                void DisconnectAllSet(int EventGUID = 0) { m_this->DisconnectAllSet(EventGUID); }

                /** Connect a new Set **/
                void Connect(const OnSetType & t, const OnGetType & g)
                {
                    m_this->ConnectSet(t);
                    m_this->ReplaceGet(g);
                }

                /** Connect a new Set **/
                void ConnectSet(const OnSetType & t, int EventGUID = 0) { m_this->ConnectSet(t, EventGUID); }

                /** Replace current Get with a boost::function callback
                * \code
                * my_data_binder.ReplaceGet(boost:bind(&MyClass::Foo, &MyClass));
                * \endcode
                */
                void ConnectGet(const OnGetType & t) { m_this->ReplaceGet(t); }

                /** Collega la Set, la Get o entrambe con un puntatore a T
                * \code
                * my_data_binder.Connect(&my_int, ui::var::both);
                * my_data_binder.Connect(&my_int, ui::var::set);
                * my_data_binder.Connect(&my_int, ui::var::get);
                * \endcode
                */
                void Connect(Type *ptr, ConnectTypes v = ui::var::both)
                {
                    if(v == set || v == both)
                        m_this->ConnectSetToPointer(ptr);

                    if(v == get || v == both)
                        m_this->ConnectGetToPointer(ptr);
                }
        };

        /** Declare a value type
        **/
        template<class T>
        // class GOLD_UI_EXPORT Value : public TBase< detail::value<T> > // PG: patch for dll import/export
		class Value : public TBase< detail::value<T> > 
        {
            public:

                explicit Value() {}

                /** declare a value and bind to pointer
                * \code
                * ui::var::Value<T>(&myVar)
                * ui::var::Value<int>(&myVar)
                * ui::var::Value<float>(&myVar)
                * \endcode
                **/
                explicit Value(T * obj) :
                    TBase< detail::value<T> >(obj) {}

                /// declare a T binded to a Set/Get boost functions
                explicit Value(const typename boost::function1<void, T> & s, const typename boost::function0< T > & g) :
                    TBase< detail::value<T> >(s,g) {}
        };

        /** Declare a range variable
        **/
        template<class T>
        // class GOLD_UI_EXPORT Range : public TBase< detail::range<T> > // PG: patch for dll import/export
		class Range : public TBase< detail::range<T> > 
        {
            public:

                Range() {}

                Range(const typename boost::function1<void, T> & s, const typename boost::function0< T > & g, T min, T max, T step=T(1)) :
                    TBase< detail::range<T> >(s,g)
                { TBase<detail::range<T> >::m_this->Set(min, max, step); }

                /** create a range variabile bound to local variable
                * \code
                * ui::widget_guid_t guid1 = ui::var::Range<int>(&value1, 0, 255);
                * ui::widget_guid_t guid1 = ui::var::Range<int>(&value1, 0, 255, 1);
                * \endcode
                **/
                Range(T * ptr, T min, T max, T step=T(1)) :
                    TBase< detail::range<T> >(ptr)
                { TBase<detail::range<T> >::m_this->Set(min, max, step); }

                /** Change data range
                */
                void Set(T min, T max, T step=T(1))
                {
                    TBase<detail::range<T> >::m_this->Set(min, max, step);
                    PanelManagerInstance().NotifyDataChanged(this->m_guid);
                }
        };

#define UI_VAR_CHOICE_MAX_ARITY 10

#define DECL(z, n, text) text(a## n);

#define BOOST_PP_LOCAL_MACRO(n) Choice(T * ptr, BOOST_PP_ENUM_PARAMS(n, T a)) :\
                                    TBase< detail::choice<T> > (ptr)\
                                    { BOOST_PP_REPEAT(n, DECL, TBase<detail::choice<T> >::m_this->add) }\
                                Choice(const typename boost::function1<void, T> & s, const typename boost::function0< T > & g, BOOST_PP_ENUM_PARAMS(n, T a)) :\
                                    TBase< detail::choice<T> > (s,g)\
                                    { BOOST_PP_REPEAT(n, DECL, TBase<detail::choice<T> >::m_this->add) }
#define BOOST_PP_LOCAL_LIMITS (1, UI_VAR_CHOICE_MAX_ARITY)
        
        /// Declare a choice type
        template<class T>
        // class GOLD_UI_EXPORT Choice : public TBase< detail::choice<T> > // PG: patch for dll import/export
		class Choice : public TBase< detail::choice<T> > 
        {
            public:

               /** allocate a choice object linked to a variable pointer
                \code
                ui::var::Choice<int> c(&obj);
                c.Add(1124);
                c.Add(2123);
                \endcode
                **/
                template<class _Iterator>
                Choice(T * ptr) :
                    TBase< detail::choice<T> > (ptr)
                { }
		
                /** allocate a choice object linked to nothing
                **/
                Choice() {}

                template<class _Iterator>
                Choice(const typename boost::function1<void, T> & s, const typename boost::function0< T > & g, _Iterator begin, _Iterator end) :
                    TBase< detail::choice<T> > (s,g)
                { TBase<detail::choice<T> >::m_this->add(begin, end); }

                /** allocate a choice object linked to a variable pointer
                \code
                ui::var::Choice c(&obj, vector.begin(), vector.end());
                \endcode
                **/
                template<class _Iterator>
                Choice(T * ptr, _Iterator begin, _Iterator end) :
                    TBase< detail::choice<T> > (ptr)
                { TBase<detail::choice<T> >::m_this->add(begin, end); }

                // Choice(T * ptr, T a0 , T a1, ..., T a9) :
                //     TBase< detail::choice<T> > (ptr)
                // { TBase<detail::choice<T> >::m_this->add(a0); TBase<detail::choice<T> >::m_this->add(a1); ... TBase<detail::choice<T> >::m_this->add(a9);}
                /** allocate a choice object inserting the values
                \code
                ui::var::Choice<std::string> c(&obj, a, b, c);
                \endcode
                **/
                #include BOOST_PP_LOCAL_ITERATE()

                /** Add a single element to data range */
                void Add(const T& value)
                {
                    TBase<detail::choice<T> >::m_this->add(value);
                    PanelManagerInstance().NotifyDataChanged(this->m_guid);
                }

                /** Add elements to data range */
                template<class _Iterator>
                void Add(_Iterator begin, _Iterator end)
                {
                    TBase<detail::choice<T> >::m_this->add(begin, end);
                    PanelManagerInstance().NotifyDataChanged(this->m_guid);
                }

                /** Clear all previous values and add new values to data */
                void Clear()
                {
                    TBase<detail::choice<T> >::m_this->clear();
                    PanelManagerInstance().NotifyDataChanged(this->m_guid);
                }
        };

#undef DECL
#undef BOOST_PP_LOCAL_MACRO
#undef BOOST_PP_LOCAL_LIMITS

#define UI_VAR_MAP_MAX_ARITY 10

#define DECL(z, n, text) text(a## n.first , a## n.second);

#define BOOST_PP_LOCAL_MACRO(n) Map(T * ptr, BOOST_PP_ENUM_PARAMS(n, pair_type a)) :\
                                    TBase< detail::map<T> > (ptr)\
                                    {\
                                        BOOST_PP_REPEAT(n, DECL, TBase<detail::map<T> >::m_this->insert)\
                                    }\
                                Map(const typename boost::function1<void, T> & s, const typename boost::function0< T > & g, BOOST_PP_ENUM_PARAMS(n, pair_type a)) :\
                                    TBase<detail::map<T> > (s,g)\
                                    {\
                                        BOOST_PP_REPEAT(n, DECL, TBase<detail::map<T> >::m_this->insert)\
                                    }
#define BOOST_PP_LOCAL_LIMITS (1, UI_VAR_MAP_MAX_ARITY)
        
        /// Declare a bidirectional map type. ID is converted and not transmitted over wire
        template<class T>
        // class GOLD_UI_EXPORT Map : public TBase< detail::map<T> >  // PG: patch for dll import/export
		class Map : public TBase< detail::map<T> >
        {
            typedef std::pair<const char*, T> pair_type;
            public:

                Map() {};
                
                /** Bind the variable with a local pointer 
		 * \code
		 * ui::var::Map<int> myData(&m_myData);
		 * \endcode
		 */
                Map(T * ptr) :
                    TBase<detail::map<T> >(ptr)
                { }

                /** Bind the variable with a local set/get functions 
		 * \code
		 * ui::var::Map<int> varItem(boost::bind(&App::SetParam, this, _1), boost::bind(&App::GetParam, this)  );
		 * \endcode
		 */
                Map(const typename boost::function1<void, T> & s, const typename boost::function0< T > & g) :
                    TBase<detail::map<T> >(s,g)
                { };
		
                /** allocate a map type linked with a variable pointer
                *  @param ptr a pointer to a T owned by a class
                *  @param begin,end iterator of a std::pair<std::string, T > collection
                \code
                ui::var::Map<int> c(&obj, vector.begin(), vector.end());
                \endcode
                **/
                template<class _Iterator>
                Map(T * ptr, _Iterator begin, _Iterator end) :
                    TBase<detail::map<T> >(ptr)
                { TBase<detail::map<T> >::m_this->add(begin, end); }

                template<class _Iterator>
                Map(const typename boost::function1<void, T> & s, const typename boost::function0< T > & g, _Iterator begin, _Iterator end) :
                    TBase<detail::map<T> >(s,g)
                { TBase<detail::map<T> >::m_this->add(begin, end); };

                // Map(T * ptr, std::pair<std::string, T> a0, std::pair<std::string, T> a1, ..., std::pair<std::string, T> an) :
                //     tbase< detail::map<T> > (ptr)
                // { tbase<detail::map<T> >::m_this->add(a0.first, a0.second); tbase<detail::map<T> >::m_this->add(a1.first, a1.second); ... tbase<detail::map<T> >::m_this->add(an.first, an.second);}
                /** allocate a map object inserting the values
                \code
                ui::var::Map<int> c(&obj, make_pair("key0", v0), make_pair("key1", v1), ..., make_pair("keyn", vn));
                \endcode
                **/
                #include BOOST_PP_LOCAL_ITERATE()
                
                /** Add a single element to the map and notify the event 
		 * \code
		 * c.Add("label", value);
		 * \endcode
		 */
                void Add(const std::string & label, const T & value)
                {
                    TBase<detail::map<T> >::m_this->insert(label, value);
                    PanelManagerInstance().NotifyDataChanged(this->m_guid);
                }

                /** Add a list of elements to the map and notify the event */
                template<class _Iterator>
                void Add(_Iterator begin, _Iterator end)
                {
                    TBase<detail::map<T> >::m_this->set(begin, end);
                    PanelManagerInstance().NotifyDataChanged(this->m_guid);
                }
                
		/** Remove all elements from the map and notify the event */
                void Clear()
                {
                    TBase<detail::map<T> >::m_this->clear();
                    PanelManagerInstance().NotifyDataChanged(this->m_guid);
                };
        };

#undef DECL
#undef BOOST_PP_LOCAL_MACRO
#undef BOOST_PP_LOCAL_LIMITS
     
//         /// una variabile albero
//         template<class T>
//         class GOLD_UI_EXPORT Tree : public TBase< detail::tree<T> >
//         {
//             public:
// 
//                 Tree() {}
// 
//                 Tree(T * ptr, const typename boost::property_tree::basic_ptree<std::string, T> & ptree) :
//                     TBase< detail::tree<T> >(ptr)
//                 { Replace(ptree); }
// 
//                 Tree(const typename boost::function1<void, T> & s, const typename boost::function0< T > & g, const typename boost::property_tree::basic_ptree<std::string, T> & ptree) :
//                     TBase< detail::tree<T> >(s, g)
//                 { Replace(ptree); }
// 
//                 // TODO: poter costruire l'albero a runtime
// 
//                 void Replace(const typename boost::property_tree::basic_ptree<std::string, T> & ptree)
//                 {
//                     TBase<detail::tree<T> >::m_this->replace(ptree);
//                     PanelManagerInstance().NotifyDataChanged(TBase<detail::tree<T> >::base::m_guid);
//                 }
//         };
    } // var
} // ui

#endif
