/** @file TPointCast.h
  * @brief Oggetti funzioni per convertire liste di oggetti
  * @author Paolo Medici (medici@ce.unipr.it)
  * @date 24-10-2006
  *
  * Queste classi possono servire come esempio per implementare delle proprie funzioni che fungono da stub tra il proprio dato e l'output
  * @note la scelta del default Point2f e' richiesta per via del Hardware ottimizzato delle OpenGL
  **/
#ifndef _TPOINT_CAST_H
#define _TPOINT_CAST_H

#include <Data/Math/Points.h>

// namespace window::detail
namespace ui
{
namespace win
{
  
/** Classe per convertire array o vettori di coppie di dati (x,y) di tipo qualsiasi in un Point2f
 * @see CWindow::TDrawPolygon, CWindow::TDrawPixels
 **/
template<typename T>
class CCastFeed2 {
  const T & m_x; ///< vettore contenente la coordinata x da convertire
  const T & m_y; ///< vettore contenente la coordinata y da convertire
  public:
  CCastFeed2(const T & x, const T & y) : m_x(x), m_y(y) {}
  inline math::Point2f operator[](int i) const { return math::Point2f(m_x[i],m_y[i]);}
};

template<typename T>
class CCastFeed3 {
  const T & m_x; ///< vettore contenente la coordinata x da convertire
  const T & m_y; ///< vettore contenente la coordinata y da convertire
  const T & m_z; ///< vettore contenente la coordinata y da convertire
  public:
  CCastFeed3(const T & x, const T & y, const T & z) : m_x(x), m_y(y), m_z(z) {}
  inline math::Point3f operator[](int i) const { return math::Point3f(m_x[i], m_y[i], m_z[i]);}
};

/** Classe per convertire array/std::vector di punti in Point2f 
 * @see CWindow::TDrawPolygon, CWindow::TDrawPixels
 **/
template<typename T>
class CCastFeedArray2 {
  const T & m_v; ///< L'array/std::vector da convertire
  public:
  CCastFeedArray2(const T & v) : m_v(v) {}
  inline math::Point2f operator[](int i) const { return math::Point2f(m_v[i].x, m_v[i].y);}
};

template<typename T>
class CCastFeedArray3 {
  const T & m_v; ///< L'array/std::vector da convertire
  public:
  CCastFeedArray3(const T & v) : m_v(v) {}
  inline math::Point3f operator[](int i) const { return math::Point3f(m_v[i].x, m_v[i].y, m_v[i].z);}
};

/** classe per importare array in istogrammi verticali (span orizzontale)
 * @see CWindow::DrawHistogram
 **/
template<typename T, typename D=math::Point2f>
class CVHistoFeed {
  const T & m_x; ///< L'array da convertire
  float x0,y0,dx,dy;  ///< I parametri di disegno e di riscalatura
  public:
  CVHistoFeed(const T & _x, float _x0, float _y0, float _dx=1.0f, float _dy=1.0f) : m_x(_x), x0(_x0), y0(_y0), dx(_dx), dy(_dy) {}
  inline D operator[](int i) const { return D(x0+m_x[i]*dx,y0+i*dy);}
};

/** classe per importare array in istogrammi orizzontali (span verticale)
 * @see CWindow::DrawVHistogram
 **/
template<typename T, typename D=math::Point2f>
class CHHistoFeed {
  const T & m_y; ///< L'array da convertire
  float x0,y0,dx,dy; ///< I parametri di disegno e di riscalatura
  public:
  CHHistoFeed(const T & _y, float _x0, float _y0, float _dx=1.0f, float _dy=1.0f) : m_y(_y), x0(_x0), y0(_y0), dx(_dx), dy(_dy) {}
  inline D operator[](int i) const { return D(x0+i*dx,y0+m_y[i]*dy);}
};

// siccome manca alle STL
template<class D, class S>
void ccopy_n(D & dst, const S & src, int n)
{
for(int i=0;i<n;i++) 
	    dst[i] = src[i];
}
	    
}  // namespace win
} // namespace ui
	    
#endif
