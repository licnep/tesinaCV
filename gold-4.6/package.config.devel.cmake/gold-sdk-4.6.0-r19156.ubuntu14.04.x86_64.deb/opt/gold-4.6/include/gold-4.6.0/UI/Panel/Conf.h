#ifndef _UI_CONF_H
#define _UI_CONF_H

/** @file Conf.h
  * @brief metodi per bindare a file INI widget
  **/

#include <UI/gold_ui_export.h>
#include <UI/Panel/detail/PanelTypes.h>

#include<boost/any.hpp>
#include <string>

// fw
namespace vl{ namespace ini {class INIFile;} } using vl::ini::INIFile;


namespace ui
{
    /** \brief Namespace for binding data in the configuration files to the user interface variables */
    namespace conf
    {
        /** metodo per bindare un GUID con un file INI
        * @param guid a guid returned by a declare
        * @param key a key in a INI FILE
        * @param ini a ini file
        *
        * \code
        * ui::conf::Bind(guid, "KEY", m_ini);
        * \endcode
        **/
        detail::widget_guid_t GOLD_UI_EXPORT Bind(detail::widget_guid_t guid, const std::string & key, INIFile *ini);

        detail::widget_guid_t GOLD_UI_EXPORT Bind(detail::widget_guid_t guid, const std::string & key, INIFile *ini, const std::string & def);
        detail::widget_guid_t GOLD_UI_EXPORT Bind(detail::widget_guid_t guid, const std::string & key, INIFile *ini, const char * def);
        detail::widget_guid_t GOLD_UI_EXPORT Bind(detail::widget_guid_t guid, const std::string & key, INIFile *ini, const boost::any & def);

        /** metodo per bindare un GUID con un file INI
        * @param guid a guid returned by a declare
        * @param key a key in a INI FILE
        * @param ini a ini file
        * @param def a default value for param (a string)
        *
        * \code
        * ui::conf::Bind(guid, "KEY", m_ini, "Default Value");
        * \endcode
        **/
        template<class T>
        detail::widget_guid_t /*GOLD_UI_EXPORT*/ Bind(detail::widget_guid_t guid, const std::string & key, INIFile *ini, const T& def)
        {
            return Bind(guid, key, ini, boost::any(def));
        }

        /** Force Re-Loading of a INIFILE.
        *  Any object binded to the same m_ini file will be reloaded
        * \code
        * ui::conf::Load(m_ini);
        * \endcode
        **/
        bool GOLD_UI_EXPORT Load(INIFile *ini);

        /** Force Saving on a INIFILE
        *  Any object binded to the same m_ini file will be saved
        * \code
        * ui::conf::Save(m_ini);
        * \endcode
        **/
        bool GOLD_UI_EXPORT Save(INIFile *ini);

        class GOLD_UI_EXPORT Configuration
        {
            public:
                
                Configuration() : m_pIni(NULL) {}
                
                Configuration(INIFile* pIni) : m_pIni(pIni) {}
                
                Configuration(INIFile& ini) : m_pIni(&ini) {}

                Configuration(const Configuration& c) : m_pIni(NULL) { *this = c; }
                
                Configuration& operator=(const Configuration& c) { if(this != &c) m_pIni = c.m_pIni; return *this; }

                template<class T>
                detail::widget_guid_t Bind(detail::widget_guid_t guid, const std::string& key, const T& def) { return ui::conf::Bind(guid, key, m_pIni, def); }

                detail::widget_guid_t Bind(detail::widget_guid_t guid, const std::string& key) { return ui::conf::Bind(guid, key, m_pIni); }
                
                inline bool Load() { return ui::conf::Load(m_pIni); }
                
                inline bool Save() { return ui::conf::Save(m_pIni); }

            private:
                
                INIFile* m_pIni;
        };
    }
}

#endif
