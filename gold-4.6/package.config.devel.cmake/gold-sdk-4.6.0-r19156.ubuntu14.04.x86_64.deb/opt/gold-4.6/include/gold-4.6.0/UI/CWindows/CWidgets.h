/** \file CWidgets.h
 * \brief Classi Privte di CWindow che portano i meta comandi di disegno.
 * \author Paolo Medici \<medici@vislab.it\> (C) 2004-2009
 **/
 
#ifndef _CDRAWINGOBJECT_IMPLEMENTATION_H
#define _CDRAWINGOBJECT_IMPLEMENTATION_H

#include <string>
#include <list>
#include <boost/function.hpp>

#include <Data/Math/TMatrices.h>
#include <UI/CWindows/CWidget.h>
#include <UI/CWindows/CWindowTypes.h>
#include "CWindowCamera.h"
#include "CWindowViewPort.h"
#include <Data/CImage/CImage.h>
#include <Processing/Vision/CImage/BasicOperations/BasicOperations.h>

/// widget
namespace ui {
namespace win {

// Pixels, Lines, Rectangles, Ellipses, Boxes
// Drawing Command Parameters

/// Oggetto CWidget per disegni di polilinee e linee singole
/// T = Point2f o Point3f
template<class T>
class PolyLine : public CWidget
{
  public:
    PolyLine(double X0, double Y0, double X1, double Y1);
    PolyLine(const T & a, const T & b);
    PolyLine(const T *Vertex, unsigned int VertexNo, bool filled);
    PolyLine(const std::vector<T> & Vertex, bool filled) : m_vertex(Vertex), m_filled(filled) { }
    PolyLine(std::vector<T> & Vertex, bool filled) : m_filled(filled) { std::swap(m_vertex, Vertex); }
    
    virtual ~PolyLine();
    
    /// Metodo di Disegno
    int Draw(CWindowCore *Window);                
  
  protected:
    PolyLine(bool filled) : m_filled(filled) {}
    
    /// Vertex Array
    std::vector<T> m_vertex;   
    /// Is the shaped to be filled?
    bool m_filled;       
};

// per compatibilita' con la versione precedente
typedef PolyLine<math::Point2f> Line;

/// Oggetto CWidget per disegni di immagini
class BindImage : public CWidget
{
  public:
/// costruttore di copia
     BindImage(const cimage::CImage & buffer) :
     	m_image( buffer.Clone() )
     	{
     	}
/// Costruttore di clonazione     	
    BindImage(cimage::SharedPtrConstType image) :  m_image(image)
    	{
    	}

    virtual ~BindImage();

    int Draw(CWindowCore *Window);

    const char *getName() const;

  protected:
    /// L'immagine
    cimage::SharedPtrConstType m_image;
};


/// Oggetto CWidget per disegni di immagini
/// L'oggetto CImage viene mantenuto attraverso uno shared pointer in modo da eliminare ogni copia di immagine
class Image : public CWidget
{
  public:
    Image(cimage::SharedPtrConstType image) : FitToScreen(true), m_image(image)
    	{
    	}
   
   Image(float x, float y, float w, float h, cimage::SharedPtrConstType image) :  
   	a(x,y), b(x+w,y+h), FitToScreen(false), m_image(image)
	{
	}

   virtual ~Image();
    
    int Draw(CWindowCore *Window);

    const char *getName() const;

  protected:
    /// 2D Image
    math::Point2f a,b;
    
    /// X,Y,W e H non sono impostati perche' inglobano tutta la finestra
    bool FitToScreen;  
    /// L'immagine
    cimage::SharedPtrConstType m_image;
    /// TODO: Eventuali precalcoli e conversioni
};

/// Un oggetto che quando istanziato esegue una copia del buffer: 
///  indispensabile per i buffer di char, opzionale per le CImage
class CopyImage: public Image {
 public:
     CopyImage(const cimage::CImage & buffer) :
     	Image( buffer.Clone() )
     	{
	// copio il buffer su m_image
     	// Copy(buffer, *m_image);
     	}

     CopyImage(float X, float Y, float W, float H, const cimage::CImage & buffer)	:
     	Image(X, Y, W, H, buffer.Clone() )
        {
        // Copy(buffer, *m_image);
     	}
     
     // FULL SCREEN
     template<class T>
     CopyImage(const T *buffer, unsigned int imgWidth, unsigned int imgHeight) :
     	Image( cimage::SharedPtrConstType(new cimage::TImage<T>(imgWidth, imgHeight) ) )
     	{
     	std::copy((uint8_t*)buffer, ((uint8_t*)buffer)+m_image->Size(), (uint8_t*)m_image->Buffer());
     	}
     
     // GENERIC
     template<class T>
     CopyImage(float X, float Y, float W, float H, const T *buffer, unsigned int imgWidth, unsigned int imgHeight)	:
     	Image(X, Y, W, H, cimage::SharedPtrConstType( new cimage::TImage<T>(imgWidth, imgHeight) ) )
        {
        std::copy((uint8_t*)buffer, ((uint8_t*)buffer)+m_image->Size(), (uint8_t*)m_image->Buffer());
     	}
     	
     virtual ~CopyImage();
};

class ImageTexture : public CWidget {
  public:
    template<class T>
    ImageTexture(const math::Point3<T> *pt, cimage::SharedPtrConstType image) : m_image(image) { std::copy(&pt[0], &pt[4], m_pt); }
    template<class T>
    ImageTexture(const math::Point3<T> *pt, const cimage::CImage & image) : m_image(image.Clone()) { std::copy(&pt[0], &pt[4], m_pt); }
    
    virtual ~ImageTexture();
       
    virtual int Draw(CWindowCore *Window);
    virtual const char *getName() const  { return "ImageTexture"; }
  public:
    /// 3D Image
    math::Point3f m_pt[4];

    cimage::SharedPtrConstType m_image;
};

// questa viene chiamata quando l'utente esplicitamente fa richiesta di copiare il buffer (opzionale per le CImage, obbligatorio per i buffer C)
class CopyImageTexture : public ImageTexture {
       public:
       template<class T>
       CopyImageTexture(const math::Point3<T> *pt, const cimage::CImage & buffer)	:
     	ImageTexture( pt, buffer.Clone() )
        {
        // cimage::Copy(buffer, *m_image);
     	}
     
       template<class T, class R>
       CopyImageTexture(const math::Point3<R> *pt, const T *buffer, unsigned int imgWidth, unsigned int imgHeight)	:
     	ImageTexture(pt, cimage::TImage<T>(imgWidth, imgHeight) )
        {
        std::copy((uint8_t*)buffer, ((uint8_t*)buffer)+m_image->Size(), (uint8_t*)m_image->Buffer());
     	}

       template<class T, class R>
       CopyImageTexture(const math::Point3<R> *pt, const T *buffer, long stride, unsigned int imgWidth, unsigned int imgHeight)    :
        ImageTexture(pt, cimage::TImage<T>(imgWidth, imgHeight) )
        {
        for(unsigned int j=0;j<imgHeight;++j)
                std::copy((uint8_t*)buffer + j * stride, ((uint8_t*)(buffer + imgWidth))+ j * stride, (uint8_t*)&((T*)m_image->Buffer())[j * imgWidth]);
        }
     	
       virtual ~CopyImageTexture();	
};

/// Un rettangolo pieno
class Box : public CWidget
{
  public:
  Box(double _X0, double _Y0, double _X1, double _Y1) :
        X0(_X0), Y0(_Y0), X1(_X1), Y1(_Y1) { }
  virtual ~Box();
  int Draw(CWindowCore *Window);

  const char *getName() const { return "Box"; }

  protected:
    double X0,Y0,X1,Y1; ///< Dimensioni
};

/// rettangolo vuoto
class Rectangle : public CWidget {
public:
  Rectangle(double _X0, double _Y0, double _X1, double _Y1) :
        X0(_X0), Y0(_Y0), X1(_X1), Y1(_Y1) { }
  virtual ~Rectangle();

  int Draw(CWindowCore *Window);    

  const char *getName() const { return "Rectangle"; }

  protected:
    double X0,Y0,X1,Y1; ///< Dimensioni
};

/// Una linea (o segmenti)
template<class T>
class LineStream : public CWidget
{
  
  public:
  LineStream(unsigned int nLines);
  LineStream(const T *vertex, unsigned int nLines);
  LineStream(const std::vector<T> & vertex) : m_vertex(vertex) { }
  LineStream(std::vector<T> & vertex) {std::swap(m_vertex,vertex); }
  
  virtual ~LineStream();
  
  int Draw(CWindowCore *Window);    

  const char *getName() const { return "LineStream"; }

  protected:
    
  std::vector<T> m_vertex;
};

/// Una lista di triangoli
template<class T>
class Triangles : public CWidget
{
  
  public:
  Triangles(const T *vertex, unsigned int nTriangles);
  Triangles(const std::vector<T> & vertex) : m_vertex(vertex) { }
  Triangles(std::vector<T> & vertex) { std::swap(m_vertex,vertex); }
  
  virtual ~Triangles();
  
  int Draw(CWindowCore *Window);    

  const char *getName() const { return "Triangles"; }

  private:
    
    std::vector<T> m_vertex;
};

/// Una lista di bbox
template<class T>
class Boxes : public CWidget
{
  public:
  Boxes(const T *vertex, unsigned int nBoxes);
  Boxes(const std::vector<T> & vertex) : m_vertex(vertex) { }
  Boxes(std::vector<T> & vertex) { std::swap(m_vertex,vertex); }
  virtual ~Boxes();

  int Draw(CWindowCore *Window);    

  const char *getName() const { return "Boxes"; }

  private:
    std::vector<T> m_vertex;
};

/// una crocetta
class Cross : public LineStream<math::Point2f>
{
  public:
  Cross(double _X, double _Y, double _Size);
  virtual ~Cross();

  const char *getName() const { return "Cross"; }

};

/// Ellissi e cerchi, e parti di essi
class Ellipse : public CWidget
{
  public:
    Ellipse(double X0, double Y0, double X1, double Y1, bool _Filled);
    Ellipse(double X0, double Y0, double X1, double Y1, double a0, double a1, bool _Filled);
    virtual ~Ellipse();
    
    int Draw(CWindowCore *Window);    

    const char *getName() const { return "Ellipse"; }

  protected:
    double X0, Y0, X1, Y1;  ///< Dimensioni
    double a0, a1;    ///< Angolo partenza e fine
    bool Filled;      ///< Pieno?
   
};

/// Pixels
template<class T>
class Pixels : public CWidget
{
  public:
    Pixels(const T & p) : m_points(1)	{
  	m_points[0] = p;
	}
    
    Pixels(const T *pPoint, unsigned int count);
    Pixels(const std::vector<T> & pPoint) : m_points(pPoint) { }
    Pixels(std::vector<T> & pPoint) { std::swap(pPoint, m_points); }
    
    virtual ~Pixels();
    
    int Draw(CWindowCore *Window);    

    const char *getName() const { return "Pixels"; }

  protected:
  
    Pixels(unsigned int count);
    
    std::vector<T> m_points;  /// Array di punti
};


/// MetaClasse per disegnare il testo
class Text : public CWidget
{
  public:
    Text(const math::Point3d & p, const std::string & text) : m_p( p ), m_text(text) {}
    Text(double x, double y, const std::string & text) : m_p( math::Point3d(x,y,0.0) ), m_text(text) {}
    virtual ~Text();

    virtual int Draw(CWindowCore *Window);    

    const char *getName() const { return "Text"; }

  protected:
    math::Point3d m_p;
    std::string m_text;
};

class ShadowText : public Text
{
  public:
    ShadowText(const math::Point3d & p, const std::string & text) : Text(p, text) {}
    virtual ~ShadowText();

    int Draw(CWindowCore *Window);    

    const char *getName() const { return "ShadowText"; }
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

/// Setta il nome del font
class SetFontName: public CWidget
{
  public:
    SetFontName(const char *_FontName) : FontName(_FontName) {}
    virtual ~SetFontName();

    virtual int Draw(CWindowCore *Window);    

    const char *getName() const { return "SetFontName"; }

  protected:
    std::string FontName; ///< una nome del font (file.ttf)
};

/// Setta la dimensione del font
class SetFontSize: public CWidget
{
  public:
    SetFontSize(double XSize, double YSize, bool absolute) : 
		m_XSize(XSize), m_YSize(YSize), m_absolute(absolute) {}
    SetFontSize(double Size) : 
		m_XSize(Size), m_YSize(Size), m_absolute(false) {}
    virtual ~SetFontSize();

    int Draw(CWindowCore *Window);    
  protected:
    double m_XSize;   /// Dimensione del font in unita' logiche lungo la direzione X
    double m_YSize;   /// Dimensione del font in unita' logiche lungo la direzione Y
    bool m_absolute;  /// Dimensione logiche o fisiche?
};

/// Setta l'allineamento del testo
class SetTextAlign : public CWidget
{
    TextAlign_t h, v;
    public:
   SetTextAlign(TextAlign_t _h, TextAlign_t _v) : h(_h), v(_v) {}
   virtual ~SetTextAlign();

   int Draw(CWindowCore *Window);    
};

/// Setta il colore di disegno
class SetColor : public CWidget
{
  public:
    /// generic from 4 values
    SetColor(int r,int g, int b, int alpha) : newcolor(r,g,b,alpha) {}
    /// generic from RGB, RGBA, etc ed
    template<class T>
    SetColor(const T & color) : newcolor(color) {}
    virtual ~SetColor();

    int Draw(CWindowCore *Window);    

  protected:
   cimage::RGBA8 newcolor;
};

/// Setta lo scostamento
class Translate : public CWidget
{
  public:
    Translate(double _dx, double _dy, bool _absolute) : dx(_dx), dy(_dy), absolute(_absolute) {}
    virtual ~Translate();

    int Draw(CWindowCore *Window);    

  protected:
   double dx,dy;
   bool absolute;
};

/// Setta lo spessore di una linea
class SetLineWidth : public CWidget
{
  public:
    SetLineWidth(double width) : newwidth(width) {} ;
    virtual ~SetLineWidth();

    int Draw(CWindowCore *Window);    

    const char *getName() const { return "SetLineWidth"; }

  protected:
   double newwidth;
};

/// Setta la dimensione di un punto
class SetPointSize : public CWidget
{
  public:
    SetPointSize(double size) : m_size(size) {} ;
    virtual ~SetPointSize();

    int Draw(CWindowCore *Window);    

    const char *getName() const { return "SetPointSize"; }

  protected:
   double m_size;
};

/// Antialiasing
class SetLineSmooth : public CWidget
{
  public:
    SetLineSmooth(bool _smooth) : smooth(_smooth) {} ;
    virtual ~SetLineSmooth();

    int Draw(CWindowCore *Window);    

  protected:
   bool smooth;
};

/// Setta il Blending
class SetBlend : public CWidget
{
  public:
    SetBlend(BlendType_t _blend) : blend(_blend) {} ;
    virtual ~SetBlend();

    int Draw(CWindowCore *Window);    

  protected:
   BlendType_t blend;
};

/// thema dei bottoni
class SetTheme : public CWidget
{
  public:
    SetTheme(const CWindowTheme & theme) : 
      m_theme(theme) {}
    virtual ~SetTheme();

    int Draw(CWindowCore *Window);    

  protected:
   CWindowTheme m_theme;
};

class DisableZBuffer: public CWidget {
 public:
    virtual ~DisableZBuffer();

    virtual int Draw(CWindowCore *Window);    
};

class EnableZBuffer: public CWidget {
   double m_near, m_far;
 public:
    EnableZBuffer(double near, double far) : m_near(near), m_far(far) { }
    virtual ~EnableZBuffer();

    virtual int Draw(CWindowCore *Window);    
};

// /// Imposta le coordinate logiche della finestra
// class Camera : public CWidget
// {
//   public:
//    Camera(sharedPtrWindowCamera camera) : m_camera(camera) { }
//    virtual ~Camera();
// 
//    virtual int Draw(CWindowCore *window);
// 
//    const char *getName() const { return "Camera"; }
// 
//   private:
//     sharedPtrWindowCamera m_camera;
// };
// 
// /// Viewport source
// class SetViewPortMode : public CWidget
// {
//   public:
//     SetViewPortMode(ViewPortMode mode) : m_mode(mode) {} ;
//     virtual ~SetViewPortMode();
// 
//     virtual int Draw(CWindowCore *Window);    
// 
//   protected:
//    ViewPortMode m_mode;
// };
// 
// class SetViewPort : public CWidget
// {
//   public:
//     SetViewPort(const Rect2d & viewport, ViewPortCoordinate mode) :m_viewport (viewport), m_mode(mode) {} ;
//     virtual ~SetViewPort();
// 
//     virtual int Draw(CWindowCore *Window);    
// 
//   protected:
//    Rect2d m_viewport;
//    ViewPortCoordinate m_mode;
// };

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

class ActiveRegion : public CWidget {
  double x0,y0,x1,y1;
  CWindowEvent_ID m_event;
  boost::function<void (void)> m_action;
  public:
  ActiveRegion(double _x0, double _y0, double _x1, double _y1, CWindowEvent_ID event, boost::function<void (void)> action) :
    x0(_x0), y0(_y0), x1(_x1), y1(_y1), m_event(event), m_action(action) {};
  virtual ~ActiveRegion();

  const char *getName() const;
  
  int Draw(CWindowCore *Window);
  bool Interact(CWindowCoreManager *Window, const CWindowEvent & event);

  bool Export(std::ostream & out) { return false; }
};


////////////////// MACRO COMUNI ////////////////////////

int DrawFrame(CWindowCore *Window, double X0, double Y0, double X1, double Y1, bool Pressed);

}
}


#endif
