/** @file XImgProcs.h
  * @brief Funzioni di elaborazione di immagini
  **/
#ifndef _X_IMAGES_PROCS
#define _X_IMAGES_PROCS

#include <Data/CImage/CImage.h>
#include <Data/CImage/Images/CImageMono8.h>
#include <Data/CImage/Images/CImageRGB8.h>
#include <Data/CImage/Images/CImageRGBA8.h>
#include <UI/CWindows/XImgProc.h>

#include <UI/gold_ui_export.h>

namespace ui
{
  namespace win
  {
    
/// Convert converte una CImageRGB8 in uan CImageRGBA8 aggiungendo un valore di @a alpha costante
void GOLD_UI_EXPORT convert(cimage::CImageRGBA8 & dst,
                 const cimage::CImageRGB8 & src, 
                 const XConversion & params);
/// Convert converte una CImageMono8 in uan CImageRGBA8 aggiungendo un valore di @a alpha costante                 
void GOLD_UI_EXPORT convert(cimage::CImageRGBA8 & dst,
                 const cimage::CImageMono8 & src, 
                 const XConversion & params);

/// Convert converte una CImageRGB8 in uan CImageRGBA8 aggiungendo usando un colorkey per settare alpha
void GOLD_UI_EXPORT colorkey(cimage::CImageRGBA8 & dst,
                 const cimage::CImageRGB8 & src, 
                 const XColorKey & params);
/// Convert converte una CImageMono8 in uan CImageRGBA8 aggiungendo usando un colorkey per settare alpha
void GOLD_UI_EXPORT colorkey(cimage::CImageRGBA8 & dst,
                 const cimage::CImageMono8 & src, 
                 const XColorKey & params);

/// Converte una CImageMono8 in una CImageRGBA8 usando l'immagine in toni di grigio come maschera di opacita'
void GOLD_UI_EXPORT opacity(cimage::CImageRGBA8 & dst,
                const cimage::CImageMono8 & src, 
                const XOpacity & params);

/// Converte una CImageMono8 in una CImageRGB8 moltiplicando ogni byte per il colore chiave
void GOLD_UI_EXPORT filter(cimage::CImageRGB8 & dst,
                const cimage::CImageMono8 & src, 
                const XFilter & params);

/// Converte una CImageRGB8 in una CImageRGB8 moltiplicando ogni byte per il colore chiave                          
void GOLD_UI_EXPORT filter(cimage::CImageRGB8 & dst,
                const cimage::CImageRGB8 & src, 
                const XFilter & params);
                
///////////////////////// TEMPLATE SPECIALIZATIONS ///////////////////////////////////////////
                
template<typename D, typename S>
void XApply(D & dst, const S & src, const XNone & param)
 {
 none(dst, src);
 }

template<typename D, typename S>
void XApply(D & dst, const S & src, const XConversion & param)
 {
 convert(dst, src, param);
 }

template<typename D, typename S>
void XApply(D & dst, const S & src, const XColorKey & param)
 {
 colorkey(dst, src, param);
 }

template<typename D, typename S>
void XApply(D & dst, const S & src, const XOpacity & param)
 {
 opacity(dst, src, param);
 }

template<typename D, typename S>
void XApply(D & dst, const S & src, const XFilter & param)
 {
 filter(dst, src, param);
 }
 
//////////////////////////////////// TARGET SPECIALIZATIONS ///////////////////////////////
 
/// Data una immagine sorgente @a S e un tipo di trasformazione @a X esiste in genere una destinazione @a Type 
///  che meglio rappresenta il dato (una specie di default se una destinazione non e' fornita).
template<typename S, typename X>
struct XTarget;

template<>
struct XTarget<cimage::RGB8, XConversion> {
  typedef cimage::RGBA8 Type;
  };

template<>
struct XTarget<cimage::Mono8, XConversion> {
  typedef cimage::RGBA8 Type;
  };

template<>
struct XTarget<cimage::RGB8, XColorKey> {
  typedef cimage::RGBA8 Type;
  };
  
template<>
struct XTarget<cimage::Mono8, XColorKey> {
  typedef cimage::RGBA8 Type;
  };
  
template<>
struct XTarget<cimage::Mono8, XOpacity> {
  typedef cimage::RGBA8 Type;
  };

template<>
struct XTarget<cimage::RGB8, XFilter> {
  typedef cimage::RGB8 Type;
  };
  
template<>
struct XTarget<cimage::Mono8, XFilter> {
  typedef cimage::RGB8 Type;
  };

  } // namespace win
} // namespace ui
#endif
