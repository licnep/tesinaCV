/**
 * \file CWindowCore_OpenGL.h
 * \brief Implementazione comune dei CWindowCore OpenGL SingleThread e MultiThread
 * \author Paolo Medici (medici@ce.unipr.it)
 **/
#ifndef _CWINDOWCORE_OPENGL_H
#define _CWINDOWCORE_OPENGL_H

#include <vector>
#include <boost/date_time/posix_time/posix_time_types.hpp>

#include <Data/Math/Points.h>
#include <UI/CWindows/CWidget.h>
#include <UI/CWindows/CWindowCore.h>
#include <UI/CWindows/CWindowCoreManager.h>

#ifdef WIN32
# include <Windows.h>
#undef DrawText
#endif

// Expose
#include <GL/gl.h>

#include "CFontManager.h"
#include "GLUtils.h"

using cimage::RGBA8;

namespace ui {
  namespace win {

/// Un singleton (di un dispatcher) che raccoglie tutte le funzioni per il disegno di CImage Particolari sulle OpenGL
BindImageFunctions & OpenGLRenderCollector_Instance();

/// Classe comune alle istanziazioni SingleThread e MultiThread
class CWindowCore_OpenGL:
    public CWindowCoreManager 
{

  protected:
    
    /// last recorded mouse position
    math::Point2i wmouse;
    
    /// Current Drawing Color (usually unused)
    RGBA8 color;

    /// Il colore sotto il mouse corrente
    RGBA8 ColorUnderMouse;
    
    RGBA8 m_bgColor;

    bool sync_mode;		///< use XSync o XFlush
    bool annoing;       		///< print annoing message

    /// Current Font Size
    double FontSizeX, FontSizeY;
    /// Font Mode
    bool FontAbsoluteMode;

    /// m_texture_id is valid?
    bool m_texture_valid;
    /// ID dell'ultima Texture Bindata
    GLuint m_textureid;
    /// Tipo Di texture che questa scheda video supporta
    GLuint m_TextureType;
    /// Subpart of texture used by system
    math::Rect2f m_texture_area;

protected:

    /// Ottiene il contesto OpenGL
    virtual bool GLGetContext(void) = 0;
    /// Rilascia il contesto OpenGL
    virtual bool GLReleaseContext(void) = 0;

    virtual bool GLSwapBuffers(void) = 0;

    /// Return Texture Type
    virtual GLuint TextureType() = 0;
    /// Return Max Texture Size
    virtual unsigned int MaxTextureSize() = 0;
    
    virtual bool SendRedraw() = 0;
    virtual bool RaiseWindow() = 0;
    virtual bool MapWindow() = 0;
    virtual bool WithdrawWindow() = 0;
    virtual bool UnmapWindow() = 0;
    virtual bool QueryPointer(math::Point2i & pt) = 0;
    virtual bool ResizeWindow(int W, int H) = 0;
    virtual bool MoveWindow(int X, int Y) = 0;
    virtual bool SetWindowTitle(const char *str) = 0;

    // se uso Motif possono anche non essere virtuali!

    /// Creazione e inizializzazione del contesto OpenGL per questa window
    virtual bool GLWindowCreate(void)  = 0;
    /// Distruzione del contesto OpenGL associato a questa Window
    virtual bool GLWindowDestroy(void)  = 0;

//     virtual bool SetFullScreenMode(bool FullScreen);

    /// FUnzione per creare finestre trasparenti
//     virtual bool SetWindowShape(const unsigned char *mask, unsigned int width, unsigned int height) = 0;
    
  protected:
    
    static void PrintGLInfo();

    void resetTitle(void);

    void ReleaseObjects();

    bool IsAvailable(void);

   /// Cattura un immagine
    bool GLGetImage(cimage::CImage & img);

   /// Cattura un pixel
    bool GetPixel(RGBA8 *color, int X, int Y);

    /// Prepare Font
    FTFont *SetFont(FontManager *fm, const math::Point3d & p);


    // Funzione chiamata da X qando la finestra viene mossa
    bool GLMove(int newX, int newY);

    // funzione chiamata da X quando la finestra viene ridimensionata
    bool GLResize(unsigned int NewWidth, unsigned int NewHeight);

  public:
    CWindowCore_OpenGL(const WindowCreationParams & param);
    virtual ~CWindowCore_OpenGL();

    /// Metodo per inserire un CWindowCommand dentro alla coda X
    virtual bool PushCommand(const SPWindowCommand & Command) = 0;

    // Tutti i possibili comandi di disegno e di gestione della finestra
    virtual bool SetTitle(const std::string & _Title);
    virtual void EnableKeyboardHandle(bool key);

    //Funzioni di Gestione Finestre
    virtual bool SetVisibility(bool Visibility);
    virtual bool SetDecoration(bool Decoration);
    virtual bool SetPosition(int X, int Y);
    virtual bool SetSize(int W,  int H);

    /// Esegue il refrsh
    virtual bool Refresh(bool force);

    virtual bool BindImage(const cimage::CImage::SharedPtrConstType & img);

    bool GLBeginTextureRender();
    bool GLEndTextureRender();
    
    template<class T, int format, int iformat>
    bool GLBindImage(const T & img)
    {
      bool mipmap = IsFlagSet(CWF_MIPMAP_TEXTURE_FILTER);
      
    //    std::cout << "mipmap: " << mipmap << " linear_texture:" << linear_texture << " TextureType:" << TextureType << std::endl;

    // se voglio la mipmap devo sare una texture2D, override TextureType:
    m_TextureType = 
      (mipmap) ? GL_TEXTURE_2D : (TextureType());

      if(m_texture_valid)
      {
	glDeleteTextures(1, &m_textureid);
	m_texture_valid = false;
	m_textureid = -1;
      }
      // Carico la CImage in una Texture OpenGL
      m_textureid = GLPrepareTexture<T, format, iformat>(m_texture_area, img, mipmap, m_TextureType);
      m_texture_valid = true;
//       log_info << "Reserved Texture " << m_textureid << std::endl;
    return true;
    }

    virtual bool DrawLine(double X0, double Y0, double X1, double Y1);
    virtual bool DrawBox(double X0, double Y0, double X1, double Y1, bool Filled);
    virtual bool DrawEllipse(double X0, double Y0, double X1, double Y1, double a0, double a1, bool Filled);

    virtual bool DrawPixels(const math::Point2f *points, unsigned int PointNo);
    virtual bool DrawPixels(const math::Point3f *points, unsigned int PointNo);
    virtual bool DrawPixels(const C4UB_V3F_t *points, unsigned int PointNo);
    virtual bool DrawPixels(const T2F_V3F_t *vertex, unsigned int PointNo);

    virtual bool DrawPolyLine(const math::Point2f *vertex, unsigned int VertexNo, bool Filled);
    virtual bool DrawPolyLine(const math::Point3f *vertex, unsigned int VertexNo, bool Filled);

    virtual bool DrawLineStream(const math::Point2f *vertex, unsigned int LineCount);
    virtual bool DrawLineStream(const math::Point3f *vertex, unsigned int LineCount);
    virtual bool DrawLineStream(const C4UB_V3F_t *vertex, unsigned int LineCount);

    virtual bool DrawTriangles(const math::Point2f *vertex, unsigned int TriangleCount);
    virtual bool DrawTriangles(const math::Point3f *vertex, unsigned int TriangleCount);
    virtual bool DrawTriangles(const C4UB_V3F_t *vertex, unsigned int TriangleCount);
    virtual bool DrawTriangles(const T2F_V3F_t *vertex, unsigned int TriangleCount);

    virtual bool DrawQuads(const math::Point2f *vertex, unsigned int BoxCount);
    virtual bool DrawQuads(const math::Point3f *vertex, unsigned int BoxCount);
    virtual bool DrawQuads(const C4UB_V3F_t *vertex, unsigned int BoxCount);
    virtual bool DrawQuads(const T2F_V3F_t *vertex, unsigned int BoxCount);
    
    virtual void EnableZBuffer(double, double);
    virtual void DisableZBuffer();

    virtual bool SetFontSizeEx(double XSize, double YSize, bool absolute);

    /// Disegna il testo
    virtual bool DrawText(const math::Point3d & p, const char *Text) = 0;

    template<class T>
     bool DrawText(T x, T y, const char *Text) { return DrawText(math::Point3d(x,y,0.0), Text); }

    template<class T>
     bool DrawText(T x, T y, const std::string & Text) { return DrawText(math::Point3d(x,y,0.0), Text.c_str() ); }

    template<class T>
     bool DrawText(const math::Point3<T> & p, const std::string & Text) { return DrawText( p, Text.c_str() ); }

    /// Ritorna la dimensione del testo
    virtual bool GetTextSize(double &Width, double &Height, const char *Texte) = 0;

    virtual bool SetTranslation(double dx, double dy, bool absolute);

    virtual bool SetColor(RGBA8 pColor);
    virtual bool GetColor(RGBA8 *pColor);
    virtual bool SetBlend(BlendType_t blend);

    virtual bool SetLineSmooth(bool Enabled);
    virtual bool SetLineWidth(float Width);
    virtual bool SetPointSize(float Size);

    bool SetTextureLinearFilter(bool Enable);

    virtual bool GetImage(cimage::CImage & img);

    virtual bool PushState(void);
    virtual bool PopState(void);

    virtual bool SetBackgroundColor(RGBA8 color);

    virtual bool GetHighlightColor(RGBA8 *pColor); // color under mouse i.e.

    virtual void RunExtension(const char *cmd);

    // oggetti che possono essere chiamati direttamente dal thread manager
    bool DrawText(FontManager *fm, const math::Point3d & p, const char *Text);
    bool GetTextSize(FontManager *fm, double &X, double &Y, const char *Texte);


/** chiamata internamente dalla Refresh software e chiamata  direttamente quando una finestra viene corrotta.
  *  Ridisegna completamente la finestra 
  *  @param soft la chiamata di ridisegno e' software o hardware 
    */
    virtual bool GLRefresh(bool soft = true);

   /// imposta un viewport generico (camera)
   void GLSetViewport(const math::TMatrix<double, 3,4> & viewport);
   
   void SetViewPort(ViewPortMode mode = WCVM_INHERIT, CWindowViewPort * viewPort = 0, sharedPtrWindowCamera camera = sharedPtrWindowCamera());
   
};

  }
}

#endif // X

