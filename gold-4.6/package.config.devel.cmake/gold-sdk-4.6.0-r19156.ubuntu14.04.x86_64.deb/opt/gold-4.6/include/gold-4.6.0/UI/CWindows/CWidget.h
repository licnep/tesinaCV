/** \file CWidget.h
 *  \brief Header per la classe CWidget elemento base per il disegno lato server.
 *  \author Paolo Medici (medici@ce.unipr.it)
 **/

#ifndef _CWIDGET_H
#define _CWIDGET_H

#include <UI/CWindows/CWindowTypes.h> // CWindowEvent
#include <UI/CWindows/CWindowFwd.h> // Forward Declaration
#include <UI/gold_ui_export.h>

namespace ui
{
namespace win
{

/** Prototype for CWidget
 *
 *  CWidget is the base classe for object drawed by CWindowCore.
 *   Le liste di CWidget sono raccolte nelle CDrawingQueue
 **/
class GOLD_UI_EXPORT CWidget
{
public:
	// virtual per permettere la distruzione
	virtual ~CWidget();

	/// Ritorna il nome dell'oggetto di disegno (debug purpose)
	virtual const char *getName() const;

	/// Virtual drawing method. Ogni subclasse di CWidget deve reimplementare questa chiamata
	/// @return il numero di oggetti effetivamente disegnati o -1 per errore
	virtual int Draw(CWindowCore* window);

	/// funzioni di gestione eventi
	virtual bool Interact(CWindowCoreManager* window,
						const CWindowEvent& event);
};
} // namespace win
} // namespace ui

#endif // _CWIDGET_H
