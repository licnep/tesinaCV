/** @file CWindowSurface.h
  * @brief strutture di intermediazione tra classi di immagini e superfici di rendering
  * @author Paolo Medici
  **/
#ifndef _CWINDOW_SURFACE_H
#define _CWINDOW_SURFACE_H

#include <map>

#include <Data/CImage/CImage.h>
#include <UI/CWindows/CWindowFwd.h>

#include <UI/gold_ui_export.h>


namespace ui {
  namespace win {

/// Carica una CImage in un WindowCore
/// @param img una immagine da caricare
typedef bool (* CImageLoadFunction) (CWindowCore *win, const cimage::CImage &);

// Non funziona: ci vuole un singleton?

/// mappa tra CImage e funzione di disegno
///  Double Dispatcher
struct GOLD_UI_EXPORT BindImageFunctions :
  public std::map</*const*/ cimage::CImage::Type, CImageLoadFunction> // NOTE PGX: removed const for QNX
{

/// Funzione per registrare una funzione di disegno che viene chiamata al momento del draw di una particolare CImage
/// @note queste funzioni di disegno devono essere NATIVE per la superficie ed accedere direttamente all'hardware
template<class T>
bool Register(const CImageLoadFunction & fn)
 {
 this->insert(std::make_pair( T::type_info(), fn) );
 return true;
 }

/** the operator that effectively execute the binding */
bool operator() (CWindowCore *win, const cimage::CImage::SharedPtrConstType & img);

};

  }
}

#define REGISTER_DRAWIMAGE(T, P, FN)  bool P ## T = P().Register<T>(FN);

// un elenco globale delle funzioni di disegno (uno per ogni Device)
// es:
// extern DrawingImageFunctions g_CImageDrawableFunction_OpenGL;



 
#endif
