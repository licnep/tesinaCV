/**
 * \file CWidget_Registration.h
 * \brief Factory access to CWidget
 * \author Paolo Medici (medici@ce.unipr.it)
 * 
 * Questo file contiene i prototipi per accedere alla registrazione e alla creazione di
 * custom widget da essere usati come gadget per lo schermo.
 */
#ifndef _GADGETS
#define _GADGETS

#include <UI/CWindows/CWidget.h>
#include <Libs/INIFiles/INIFile.h> 

#include <Libs/Patterns/Singleton.h>
#include <Libs/Patterns/Factory.h>
#include <Libs/Patterns/RegisterObject.h>

namespace ui{
  namespace win{

// tipo per la factory a singleton
typedef boost::function<ui::win::CWidget*(INIFile &)> CWidgetAllocatorType;
typedef vl::Factory<std::string, ui::win::CWidget, CWidgetAllocatorType> CWidgetFactoryType;

  }
}


/// Insert in the "PLUGIN" factory a new allocator
#define REGISTER_WIDGET(CLASS,STRNAME)  vl::ObjectRegistrar< ui::win::CWidgetFactoryType, CLASS > drf_##CLASS(STRNAME)

// GADGET Comuni
// Per abilitare o meno i gadgets
//  abilitare o meno la flag corrispondente

// #define GADGET_HELP   "HELP"
#define GADGET_LOGO   "LOGO"

#endif
