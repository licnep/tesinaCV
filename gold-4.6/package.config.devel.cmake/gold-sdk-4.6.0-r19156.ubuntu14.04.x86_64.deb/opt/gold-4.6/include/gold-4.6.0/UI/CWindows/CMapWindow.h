// #ifndef CMAPWINDOW_H
// #define CMAPWINDOW_H
// 
// /** \file CMapWindow.h
//  * \date 14/02/2007
//  * \author Claudio Caraffi
//  * \brief Contiene le definizioni delle TMapWindow, TWorldImageConverter e objectColor_t.
//  */
// 
// 
// #include <UI/CWindows/CWindow.h>
// #include <Data/Math/Points.h>
// 
// #include <vector>
// #include <map>
// #include <iostream> //definizione di std::cout e std::endl
// #include <utility> //definizione di std::pair
// #include <stdint.h>
// // #include "CImage/imgtype.h"
// 
// 
// //TODO RENDERE ATTIVA LA PARTE DELLE ETICHETTE
// //TODO METTERE SETTABILE LA POSIZIONE DELLE ETICHETTE, O FARGLIELA CALCOLARE IN MODO FURBO
// //TODO AGGIUNGERE GRIGLIA
// 
// //TODO NON PRIORITARI
// //METTERE SETTABILE LA DIMENSIONE DEL FONT DELLE ETICHETTE
// //AGGIUNGERE EVENTUALI ALTRE DRAWREAL
// 
// //TODO EVENTUALI
// //USARE RefPlaneLimits_t
// //Vedere se si pu� risolvere la questione dell'anyNews, dato interno di CWorldToImageConverter
// //usato un po' da tutti come una baldracca...
// 
// 
// 
// 
// 
// 
// 
// template <class MemorylessConverter>
// /** \brief Fornisce un'interfaccia ad un convertitore di coordinate
//  *  per poterne cambiare un solo parametro alla volta.
//  * Fornisce inoltre la variabile anyNews che tiene memoria se sono stati effettuati dei
//  * cambiamenti dall'ultimo refresh.
//  * @see CBirdEyeViewMemorylessConverter
//  * @see CLateralViewMemorylessConverter
//  */
// class TWorldImageConverter: protected MemorylessConverter
// {
// private:
//   unsigned int m_width;
//   unsigned int m_height;
//   float m_beginningX;
//   float m_endX;
//   float m_beginningY;
//   float m_endY;
// 
// protected:
// ///Tiene memoria se sono stati effettuati dei cambiamenti nei parametri dall'ultimo refresh.
//   bool anyNews;
// 
// public:
//   TWorldImageConverter(unsigned int width,unsigned int height,float beginningX=0,float endX=50,float beginningY=-25,float endY=25) : m_width(width),m_height(height),m_beginningX(beginningX),m_endX(endX),m_beginningY(beginningY),m_endY(endY)
//     {
//     this->SetParams(m_width,m_height,m_beginningX,m_endX,m_beginningY,m_endY);
//     anyNews=true;
//     }
// 
//   virtual ~TWorldImageConverter(){}
// 
//   void SetBeginningX(const float beginningX)
//     {
//     m_beginningX=beginningX;
//     this->SetParams(m_width,m_height,m_beginningX,m_endX,m_beginningY,m_endY);
//     anyNews=true;
//     }
// 
//   void SetEndX(const float endX)
//     {
//     m_endX=endX;
//     this->SetParams(m_width,m_height,m_beginningX,m_endX,m_beginningY,m_endY);
//     anyNews=true;
//     }
// 
//   float GetBeginningX() const {return m_beginningX;}
// 
//   float GetEndX() const {return m_endX;}
// 
// 
//   void SetXLimits(const float beginningX,const float endX)
//     {
//     m_beginningX=beginningX;
//     m_endX=endX;
//     this->SetParams(m_width,m_height,m_beginningX,m_endX,m_beginningY,m_endY);
//     anyNews=true;
//     }
// 
//   void SetBeginningY(const float beginningY)
//     {
//     m_beginningY=beginningY;
//     this->SetParams(m_width,m_height,m_beginningX,m_endX,m_beginningY,m_endY);
//     anyNews=true;
//     }
// 
//   void SetEndY(const float endY)
//     {
//     m_endY=endY;
//     this->SetParams(m_width,m_height,m_beginningX,m_endX,m_beginningY,m_endY);
//     anyNews=true;
//     }
// 
//   float GetBeginningY() const {return m_beginningY;}
// 
//   float GetEndY() const {return m_endY;}
// 
//   void SetYLimits(const float beginningY,const float endY)
//     {
//     m_beginningY=beginningY;
//     m_endY=endY;
//     this->SetParams(m_width,m_height,m_beginningX,m_endX,m_beginningY,m_endY);
//     anyNews=true;
//     }
// 
//   /**
//   * Setta i limiti del sistema di riferimento
//   * @param beginningX x minima
//   * @param endX x massima
//   * @param beginningY y minima
//   * @param endY y massima
//   */
//   void SetWorldLimits(const float beginningX,const  float endX,const  float beginningY,const  float endY)
//     {
//     m_beginningX=beginningX;
//     m_endX=endX;
//     m_beginningY=beginningY;
//     m_endY=endY;
//     this->SetParams(m_width,m_height,m_beginningX,m_endX,m_beginningY,m_endY);
//     anyNews=true;
//     }
// 
//   void SetImageWidth(const unsigned int width)
//     {
//     m_width= width;
//     this->SetParams(m_width,m_height,m_beginningX,m_endX,m_beginningY,m_endY);
//     anyNews=true;
//     }
// 
//   void SetImageHeight(const unsigned int height)
//     {
//     m_height=height;
//     this->SetParams(m_width,m_height,m_beginningX,m_endX,m_beginningY,m_endY);
//     anyNews=true;
//     }
// 
// };
// 
// 
// 
// 
// 
// 
// 
// 
// /** \brief CBirdEyeViewMemorylessConverter permette di passare da coordinate mondo a coordinate immagine
//  * secondo una vista dall'alto (bird's eye view).
//  *
//  *             /\ x
//  *             ||
//  *             ||
//  *             ||
//  *             ||
//  *             ||
//  *             ||
//  *  y          ||
//  *  <=======================
//  * @see CBirdEyeViewMapWindow
//  * @see CBirdEyeViewConverter
//  */
// class CBirdEyeViewMemorylessConverter {
//   private:
//   float a,b,c,d;
//   public:
//   void SetParams(unsigned int width,unsigned int height,float beginningX,float endX,float beginningY,float endY)
//     {
//     if ((beginningX>=endX) || (beginningY>=endY))
//       {
//       std::cout<<"beginningX="<<beginningX<<" endX="<<endX<<"beginningY="<<beginningY<<" endY="<<endY<<std::endl;
//       throw std::runtime_error("Parametri non validi");
//       }
//   //    U = width - (xy.y-beginningY)/ ( (endY-beginningY)/width);
//   //    V = height - (xy.x-beginningX)/ ( (endX-beginningX)/height );
//     a = (float)width * (1 + beginningY / (endY-beginningY) );
//     b = -(float)width / (endY-beginningY);
//     c = (float)height * (1 + beginningX / (endX-beginningX) );
//     d = -(float)height / (endX-beginningX);
//     }
// 
//   template<class T>
//   /**
//    * Calcola il punto dell'immagine corrispondente ad un certo punto del piano reale
//    * @param in Punto del piano reale
//    * @return Punto dell immagine
//    */
//   Point2f WorldToImage(const T & in) const { return Point2f(a + b * in.y, c + d*in.x); }
// 
//   template<class T>
//   /**
//    * Calcola il punto del piano reale corrispondente ad un certo punto dell'immagine
//    * @param in Punto dell immagine
//    * @return Punto del piano reale
//    */
//   Point2f ImageToWorld(const T & in) const { return Point2f((in.y-a)/b, (in.x-c)/d); }
// };
// 
// 
// 
// /** \brief CBirdEyeViewConverter permette di passare da coordinate mondo a coordinate immagine
//  * secondo una vista dall'alto (bird's eye view).
//  * Permette di modificare uno alla volta i parametri interni come larghezza e altezza dell'immagine e limiti del mondo reale
//  *
//  *             /\ x
//  *             ||
//  *             ||
//  *             ||
//  *             ||
//  *             ||
//  *             ||
//  *  y          ||
//  *  <=======================
//  * @see CBirdEyeViewMapWindow
//  * @see CBirdEyeViewMemoryLessConverter
//  */
// typedef TWorldImageConverter<CBirdEyeViewMemorylessConverter> CBirdEyeViewConverter;
// 
// 
// 
// 
// 
// 
// 
// 
// 
// /** \brief CLateralViewMemorylessConverter permette di passare da coordinate mondo a coordinate immagine
//  * secondo una vista laterale.
//  *
//  *            /\ y
//  *            ||
//  *            ||
//  *            ||
//  *            ||
//  *            ||
//  *            ||
//  *            ||           x
//  *  =======================>
//  * @see CLateralViewMapWindow
//  * @see CLateralViewConverter
//  */
// class CLateralViewMemorylessConverter {
//   private:
//   float a,b,c,d;
//   public:
//   void SetParams(unsigned int width,unsigned int height,float beginningX,float endX,float beginningY,float endY)
//     {
//     if ((beginningX>=endX) || (beginningY>=endY))
//       {
//       std::cout<<"beginningX="<<beginningX<<" endX="<<endX<<"beginningY="<<beginningY<<" endY="<<endY<<std::endl;
//       throw std::runtime_error("Parametri non validi");
//       }
//   //    U = (xy.x-beginningX) / (endX-beginningX) * width);
//   //    V = height - (xy.y-beginningY)/  (endY-beginningY) *height );
//     a = -(float) width * beginningX / (endX-beginningX);
//     b = (float) width / (endX-beginningX);
//     c = (float) height * (1 + beginningY / (endY-beginningY) );
//     d = -(float) height / (endY-beginningY);
//     }
// 
//   template<class T>
//   /**
//    * Calcola il punto dell'immagine corrispondente ad un certo punto del piano reale
//    * @param in Punto del piano reale
//    * @return Punto dell immagine
//    */
//   Point2f WorldToImage(const T & in) const { return Point2f(a + b * in.x, c + d*in.y); }
// 
//   template<class T>
//   /**
//    * Calcola il punto del piano reale corrispondente ad un certo punto dell'immagine
//    * @param in Punto dell immagine
//    * @return Punto del piano reale
//    */
//   Point2f ImageToWorld(const T & in) const { return Point2f((in.x-a)/b, (in.y-c)/d); }
// };
// 
// 
// /** \brief CLateralViewConverter permette di passare da coordinate mondo a coordinate immagine
//  * secondo una vista laterale.
//  * Permette di modificare uno alla volta i parametri interni come larghezza e altezza dell'immagine e limiti del mondo reale
//  *
//  *            /\ y
//  *            ||
//  *            ||
//  *            ||
//  *            ||
//  *            ||
//  *            ||
//  *            ||           x
//  *  =======================>
//  * @see CLateralViewMapWindow
//  * @see CLateralViewMemoryLessConverter
//  */
// typedef TWorldImageConverter<CLateralViewMemorylessConverter> CLateralViewConverter;
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// /** \brief objectColor_t contiene due colori utilizzati per disegnare un poligono,
//  * indicando colore del bordo e colore dell'interno del poligono
//  */
// struct objectColor_t
//   {
//   cimage::RGBA8 border;
//   cimage::RGBA8 inside;
// 
//   /**
//    * @param color Viene assegnato sia come colore del bordo sia come colore dell'interno dell'oggetto, con il canale alfa per l'interno viene preso come met� del canale alfa per il bordo
//    */
//   objectColor_t(cimage::RGBA8 color):border(color),inside(color)
//     {
//     inside.A /= 2;
//     }
// 
//   /**
//    * @param borderColor Colore del bordo dell'oggetto
//    * @param insideAlfa Alfa assegnato al colore interno
//    */
//   objectColor_t(cimage::RGBA8 borderColor,uint8_t insideAlfa):border(borderColor),inside(borderColor)
//     {
//     inside.A = insideAlfa;
//     }
// 
//   /**
//    * @param borderColor Colore del bordo dell'oggetto
//    * @param insideColor Colore dell'interno dell'oggetto
//    */
//   objectColor_t(cimage::RGBA8 borderColor,cimage::RGBA8 insideColor):border(borderColor),inside(insideColor)
//     {
//     }
// 
//   objectColor_t()
//     {
//     }
// 
//   };
// 
// 
// 
// 
// template <class MyConverter>
// /** \brief TMapWindow � una CWindow che permette di disegnare oggetti del mondo reale.
//  *  La conversione viene attuata tramite la classe di conversione ereditata,
//  *  solitamente costruita specializzando TWorldImageConverter.
//  *  Di default � attivato il canale alpha.
//  */
// class TMapWindow: public ui::win::CWindow, public MyConverter
// {
// 
//   protected:
//     typedef std::vector <Point2 <double> > FOV_t;
// 
//     std::map <std::string , FOV_t > m_FOVs;
//     std::map <std::string , objectColor_t> m_FOVcolors;
// 
//     objectColor_t m_FOVcolor;
//     objectColor_t m_objectsColor;
// 
//     cimage::RGBA8 m_BGcolor;
// 
//     unsigned int m_width,m_height;
// 
//     bool  showLabels;
//     bool  firstPointLabels;
//     unsigned int ii; // label Object counter  //incrementato al disegno delle etichette
// 
// 
//   bool RefreshBG()
//     {
//     bool toBeReturned=true;
//     toBeReturned = ( (toBeReturned) && (SetLayer(0)) );
//     toBeReturned = ( (toBeReturned) && (Clear()) );
//     toBeReturned = ( (toBeReturned) && (SetColor(m_BGcolor)) );
//     toBeReturned = ( (toBeReturned) && (DrawBox(0,0,m_width,m_height)) );
//     toBeReturned = ( (toBeReturned) && (SetLayer(2)) );
//     return (toBeReturned);
//     }
// 
// 
//   bool RefreshFOVs()
//     {
//     bool toBeReturned=true;
//     objectColor_t FOVcolor;
// 
//     toBeReturned = ( (toBeReturned) && (SetLayer(1)) ) ;
//     toBeReturned = ( (toBeReturned) && (Clear()) );
// 
//     //Disegna tutti i FOV nell'elenco
//     for ( std::map <std::string , FOV_t>::iterator pp=m_FOVs.begin(); pp!=m_FOVs.end();pp++)
//       {
//       //cerca il colore nella tabella dei colori dei FOV
//       std::map <std::string , objectColor_t>::iterator p_color = m_FOVcolors.find(pp->first);
//       //se non lo trova utilizza il colore globale
//       FOVcolor = (p_color!=m_FOVcolors.end() ) ? p_color->second : m_FOVcolor;
//       toBeReturned = ( (toBeReturned) && (DrawRealObject(pp->second, FOVcolor,true)) );
//       }
// 
//     toBeReturned = ( (toBeReturned) && (SetLayer(2)) );
// 
//     return (toBeReturned);
//     }
// 
// 
// public:
// 
//   /**
//    *
//    * @param Title Il nome della finestra
//    * @param width La larghezza dell'immagine in pixel
//    * @param height L'altezza dell'immagine in pixel
//    * @return La TMapWindow creata
//    */
//   TMapWindow( const char *Title, unsigned int width, unsigned int height):CWindow(Title,width,height),MyConverter(width,height),m_width(width),m_height(height)
//     {
//     CWindow::SetBlend(ui::win::BLEND_ALPHA);
//     SetLayer(2); //Il layer su cui disegneremo gli oggetti
//     SetFOVcolor(objectColor_t( cimage::RGBA8(0,0,0),cimage::RGBA8(0,255,0,125) ) );
//     SetBGcolor(cimage::RGBA8(255,255,255));  //Questo causa l'automatico refresh
//     SetObjectsColor(objectColor_t ( cimage::RGBA8(255,125,0),125 ) );
//     showLabels=true;
//     this->anyNews=false;
//     firstPointLabels=true;
//     ii=0; // label Object counter
//     }
// 
// 
//   ~TMapWindow(){
//    }
// 
// 
//   /**
//    * Setta il colore del background, e lo ridisegna
//    * @param BGcolor colore dello sfondo
//    */
//   bool SetBGcolor(cimage::RGBA8 BGcolor)
//     {
//     m_BGcolor = BGcolor;
//     return RefreshBG();
//     }
// 
// 
//    bool Refresh(bool sync=false)
//     {
//     bool toBeReturned=true;
//     ii=0; //Object counter reset
//     if (this->anyNews)
//       {
//       toBeReturned = ( (toBeReturned) && (RefreshFOVs()) );
//       this->anyNews=false;
//       }
//     return ( (toBeReturned) && (CWindow::Refresh(sync)) );
//     }
// 
// 
//   bool SetBaseSize(unsigned int width,  unsigned int height)
//     {
//     bool toBeReturned;
//     this->anyNews=true;
//     m_width=width;
//     m_height=height;
//     this->SetImageWidth(width);
//     this->SetImageHeight(height);
//     toBeReturned= CWindow::SetSize(width, height);
//     return ( (toBeReturned) && (RefreshBG()) );
//     }
// 
// // template <typename T>
// //   /**
// //    * Inserisce un FOV generico(contraddistinto da una chiave stringa) nel database dei fields of views.
// //    * Se la chiave � gi� presente il FOV viene sostituito.
// //    * Il field of view � passato come vettore di generici struct che abbiano un campo x ed un campo y,
// //    * ma se si passano dei Point2d � meglio perch� viene utilizzata la versione con copia diretta.
// //    * \code
// //    * MyCMapWindow->InsertFOV(std::make_pair ( "trinocular" , vettore) ) ;
// //    * \endcode
// //    * @param FOV La coppia stringachiave-FOV da inserire
// //    */
// //   void InsertFOV (const std::pair <std::string , std::vector <T> > FOV)
// //     {
// //     FOV_t tempFOV;
// //     for (typename std::vector <T>::iterator ii=FOV.second.begin();ii!=FOV.second.end();ii++)
// //       tempFOV.push_back(Point2d(*ii) );
// //     m_FOVs[FOV.first]=tempFOV;
// //     this->anyNews=true;
// //     }
// 
// 
// // template <>
// //   /**
// //    * Inserisce un FOV (contraddistinto da una chiave stringa) nel database dei fields of views.
// //    * Il field of view � passato come vettore di Point2d
// //    * Se la chiave � gi� presente il FOV viene sostituito
// //    * \code
// //    * MyCMapWindow->InsertFOV(std::make_pair ( "trinocular" , vettore) ) ;
// //    * \endcode
// //    * @param FOV La coppia stringachiave-FOV da inserire
// //    */
// //   void TMapWindow<>::InsertFOV (const std::pair <std::string , std::vector <Point2d> > FOV)
// //     {
// //     m_FOVs[FOV.first]=FOV.second;
// //     this->anyNews=true;
// //     }
// 
// 
// template <typename T>
//   /**
//    * Inserisce un FOV generico(contraddistinto da una chiave stringa) nel database dei fields of views.
//    * Se la chiave � gi� presente il FOV viene sostituito.
//    * Sicuramente funziona se il formato dei dati � in Point2d,
//    * in teoria dovrebbe funzionare anche se
//    * il field of view � passato come vettore di generici struct che abbiano un campo x ed un campo y.
//    * \code
//    * MyCMapWindow->InsertFOV(std::make_pair ( "trinocular" , vettore) ) ;
//    * \endcode
//    * @param FOV La coppia stringachiave-FOV da inserire
//    */
//   void InsertFOV (const std::pair <std::string , std::vector <T> > &FOV)
//     {
//     m_FOVs[FOV.first]=FOV.second;
//     this->anyNews=true;
//     }
// 
// 
// 
//   /**
//    * Rimuove dai database dei FOV il FOV che corrisponde alla stringa chiave passata
//    * @param FOVname La stringa chiave per la rimozione
//    */
//   void RemoveFOV (std::string FOVname)
//     {
//     m_FOVs.erase(FOVname);
//     this->anyNews=true;
//     }
// 
//   /**
//    * Setta il colore con cui disegnare uno specifico FOV
//    * \code
//    * MyCMapWindow->SetFOVcolor(std::make_pair ( "trinocular" , objectColor_t( cimage::RGBA8(0,0,0),cimage::RGBA8(0,255,0,125) ) ) );
//    * MyCMapWindow->SetFOVcolor(std::make_pair ( "stereo" , objectColor_t( cimage::RGBA8(0,0,0),cimage::RGBA8(125,255,0,125) ) ) );
//    * \endcode
//    * @param FOVcolor
//    */
//   void SetFOVcolor (std::pair <std::string , objectColor_t> FOVcolor)
//     {
//     m_FOVcolors.erase(FOVcolor.first);
//     m_FOVcolors.insert(FOVcolor);
//     this->anyNews=true;
//     }
// 
// 
//   /**
//    * Setta il colore con cui verranno disegnati tutti i FOV per cui non � stato scelto un colore specifico
//    * \code
//    * MyCMapWindow->SetFOVcolor(objectColor_t( cimage::RGBA8(0,0,0),cimage::RGBA8(0,255,0,125) )  );
//    * \endcode
//    * @param FOVcolor
//    */
//   void SetFOVcolor (objectColor_t FOVcolor)
//     {
//     m_FOVcolor=FOVcolor;
//     this->anyNews=true;
//     }
// 
// 
//   void TurnOnLabels()
//     {
//     showLabels=true;
//     }
// 
//   void TurnOffLabels()
//     {
//     showLabels=false;
//     }
// 
//   void SetFirstPointLabels()
//     {
//     firstPointLabels=true;
//     }
// 
//   void UnsetFirstPointLabels()
//     {
//     firstPointLabels=false;
//     }
// 
// 
// 
// /**
//   * Setta il colore con cui verranno disegnati gli oggetti
//   * \code
//   * MyCMapWindow->SetObjectsColor(objectColor_t( cimage::RGBA8(255,125,0),cimage::RGBA8(255,125,0,125) )  );
//   * \endcode
//   * oppure:
//   * \code
//   * MyCMapWindow->SetObjectsColor(objectColor_t( cimage::RGBA8(255,125,0),125 )  );
//   * \endcode
//   * @param objectsColor
//   */
// void SetObjectsColor(objectColor_t objectsColor)
//   {
//   m_objectsColor = objectsColor;
//   }
// 
// 
// 
// template <class T>
// /**
//  * Disegna un vettore di oggetti
//  * Effetto collaterale: la chiamata interna a DrawRealObject rende
//  * insignifacante una precedente CWindow::SetColor() sul livello corrente
//  * @param objectList vettore di oggetti da disegnare
//  * @param filled true riempito (default), false vuoto
//  * @param mark non mi ricordo
//  * @param halfSize non mi ricordo
//  * @return
//  */
// bool DrawRealObjects(const T &objectList, bool filled=true, bool mark=false, int halfSize=1)
//   {
//   ii=0; // label Object counter
//   bool toBeReturned=true;
//   for( typename T::const_iterator pp=objectList.begin();pp!=objectList.end();pp++)
//     toBeReturned = ( (toBeReturned) && (DrawRealObject(*pp,m_objectsColor,filled,mark,halfSize)) );
//   return (toBeReturned);
//   }
// 
// 
// template <class T>
// /**
//  * Disegna un oggetto reale sul livello corrente (poligono chiuso).
//  * Usata internamente
//  * Effetto collaterale: rende insignifacante una precedente CWindow::SetColor() sul livello corrente
//  * @param object Vettore di punti, contraddistinti ognuno da un campo x ed un campo y
//  * @param objectColor Il colore con cui verr� disegnato
//  * @param filled Se deve disegnarlo riempito
//  * @param mark non mi ricordo
//  * @param halfSize non mi ricordo
//  * @return
//  */
// bool DrawRealObject(const T &object, objectColor_t objectColor, bool filled=false, bool mark=false, int halfSize=1)
//   {
//   std::vector <Point2f > objectImage;
// 
//   bool toBeReturned=true;
// 
//   //Variabili per le etichette
//   float xSum,ySum;
//   xSum=ySum=0;
// 
//   for(typename T::const_iterator pp=object.begin();pp!=object.end();pp++)
//     objectImage.push_back(this->WorldToImage(*pp));
// 
//   if (object.size()>1)
//     {
//     if (filled)
//       {
//       //Disegna l'interno dell'oggetto
//       toBeReturned = ( (toBeReturned) && (CWindow::SetColor(objectColor.inside)) );
//       toBeReturned = ( (toBeReturned) && (CWindow::DrawPolygon(objectImage, true, true)) );
//       }
//     //Disegna il bordo dell'oggetto
//     toBeReturned = ( (toBeReturned) && (CWindow::SetColor(objectColor.border)) );
//     toBeReturned = ( (toBeReturned) && (CWindow::DrawPolygon(objectImage, true, false)) );
//     }
//   else if (object.size()==1)
//     {
//     toBeReturned = ( (toBeReturned) && (CWindow::DrawPixel(objectImage[0])) );
//     }
// 
// 
// /*  if ((showLabels) && (!firstPointLabels))
//     {
//     //non �un gran che fare la media dei vertici, non viene affatto il baricentro
//     object_t::const_iterator pp=object.begin();
//     if (object.size()>2) pp++; //il primo punto lo conterei due volte
//     for(;pp!=object.end();pp++)
//       {
//       xSum+=(pp->x);
//       ySum+=(pp->y);
//       }
//     }
// 
//   if (object.size()>1)
//     {
//     toBeReturned = ( (toBeReturned) && (DrawPolygon(u,v,false,filled);
//     }
// 
//   else if (object.size()==1)
//     {
//     toBeReturned = ( (toBeReturned) && (DrawPixel(u[0],v[0]);
//     }
// 
//   if (showLabels)
//     {
//     char strLabel[100];
//     object_t::const_iterator pp=object.begin();
//     if (firstPointLabels)
//       {
//       sprintf(strLabel, "#%d: (%03.2f, %03.2f)", ii, pp->x, pp->y);
//       }
//     else
//       {
//       sprintf(strLabel, "#%d: (%03.2f, %03.2f)", ii, xSum,ySum);
//       }
//     ii++; // label Object counter
//     SetFontName("arial");
//     SetFontSize(10);
//     DrawText(GetUCoordinate(pp->y),GetVCoordinate(pp->x),strLabel);
//     }
// 
//   if (mark)
//     toBeReturned = ( (toBeReturned) && (DrawBoxes(u,v,halfSize);*/
// 
//   return (toBeReturned);
//   }
// 
// 
// template <class T>
// /**
//  * Disegna una spezzata
//  * @param object Vettore di punti, contraddistinti ognuno da un campo x ed un campo y
//  */
// bool DrawRealPolyLine(const T &object)
//   {
// 
//   std::vector <Point2f > objectImage;
// 
//   //Prepara il vettore di coordinate immagine per il disegno
//   for(typename T::const_iterator pp=object.begin();pp!=object.end();pp++)
//     objectImage.push_back(this->WorldToImage(*pp));
// 
//   return CWindow::DrawPolygon(objectImage, false, false);
//   }
// 
// 
// 
// bool DrawRealLine(float x0, float y0, float x1, float y1)
//   {
//   return CWindow::DrawLine(this->WorldToImage(Point2f(x0,y0) ),this->WorldToImage(Point2f(x1,y1) ) );
//   }
// 
// 
// bool DrawRealPoint(float x, float y)
//   {
//   return CWindow::DrawPixel(this->WorldToImage(Point2f(x,y) ) );
//   }
// 
// /**
//  * Disegna un punto reale
//  * @param realPoint Un qualsiasi tipo di dato che abbia i campi x e y
//  */
// template <class T>
// bool DrawRealPoint(T realPoint)
//   {
//   return CWindow::DrawPixel(this->WorldToImage(realPoint));
//   }
// 
// /**
//  * Disegna un rettangolo reale, di default pieno
//  */
// bool DrawRealBox(float x0, float y0, float x1, float y1,bool filled=true)
//   {
//   return CWindow::DrawBox (Rect2f ( this->WorldToImage(Point2f(x0,y0)), this->WorldToImage(Point2f(x1,y1))),filled );
//   }
// 
// 
// /**
//  * Disegna un rettangolo reale vuoto
//  */
// bool DrawRealRectangle(float x0, float y0, float x1, float y1)
//   {
//   return CWindow::DrawRectangle (Rect2f ( this->WorldToImage(Point2f(x0,y0)), this->WorldToImage(Point2f(x1,y1))) );
//   }
// 
// 
// bool DrawRealEllipse(float x0, float y0, float x1, float y1, bool filled=true)
//   {
//   return CWindow::DrawEllipse(Rect2f (this->WorldToImage(Point2f(x0,y0)),this->WorldToImage(Point2f(x1,y1))),filled );
//   }
// 
// 
// /**
//  * Disegna un cerchio reale, eventualmente deformandolo se la mappa prevede conversioni di dimensioni diverse per x ed y
//  * @param x coordinata mondo x del centro
//  * @param y coordinata mondo y del centro
//  * @param radius raggio in unit� di misura del mondo
//  * @param filled pieno o vuoto
//  */
// bool DrawRealCircle(float x, float y, float radius, bool filled=true)
//   {
//   return DrawRealEllipse(x-radius,y-radius,x+radius,y+radius,filled);
//   }
// 
// 
// 
// 
// 
// /*
// bool DrawPolygon(std::vector <int> &u,std::vector <int> &v, bool closed, bool filled)
//   {
//   return (CWindow::DrawPolygon(&(u[0]),&(v[0]),static_cast<unsigned int> (u.size()),closed,filled));
//   }
// */
// 
// /*
// 
// bool DrawBoxes(const std::vector <int> &u,const std::vector <int> &v, int halfSize=1)
//   {
//   //Si potrebbe fare un assert sul fatto che u e v abbiano la stessa dimensione
//   bool toBeReturned=true;
//   for( std::vector<int>::const_iterator ppU=u.begin(), ppV=v.begin();ppU!=u.end();ppU++,ppV++)
//     toBeReturned = ( (toBeReturned) && (DrawBox(*ppU-halfSize,*ppV-halfSize,*ppU+halfSize,*ppV+halfSize)) );
//   return (toBeReturned);
//   }
// */
// 
// 
// };
// 
// 
// 
// 
// /**
//  * CBirdEyeViewMapWindow � una TMapWindow che permette di disegnare oggetti del mondo reale secondo una vista bird eye view.
//  * @see CWorldToImageConverter
//  * @see CBirdEyeViewConverter
//  * @see CBirdEyeViewMemoryLessConverter
//  * @see TWorldImageConverter
//  */
// typedef TMapWindow<CBirdEyeViewConverter> CBirdEyeViewMapWindow;
// 
// 
// /**
//  * CLateralViewMapWindow � una TMapWindow che permette di disegnare oggetti del mondo reale secondo una vista laterale.
//  * @see CWorldToImageConverter
//  * @see CLateralViewConverter
//  * @see CLateralViewMemoryLessConverter
//  * @see TWorldImageConverter
//  */
// typedef TMapWindow<CLateralViewConverter> CLateralViewMapWindow;
// 
// 
// /**
//  * CMapWindow � una TMapWindow che permette di disegnare oggetti del mondo reale secondo una vista bird eye view
//  * @see CWorldToImageConverter
//  * @see CBirdEyeViewConverter
//  * @see CBirdEyeViewMemoryLessConverter
//  * @see TWorldImageConverter
//  */
// typedef CBirdEyeViewMapWindow CMapWindow;
// 
// 
// #endif
