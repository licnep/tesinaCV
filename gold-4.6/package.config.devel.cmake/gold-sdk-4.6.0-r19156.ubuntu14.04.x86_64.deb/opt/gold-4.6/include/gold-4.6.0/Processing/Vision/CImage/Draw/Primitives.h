#ifndef _DRAW_PRIMITIVES_H
#define _DRAW_PRIMITIVES_H

/** @file Primitives.h
 * @brief Include all the headers file of Draw library */

#include <Processing/Vision/CImage/Draw/Line.h>
#include <Processing/Vision/CImage/Draw/Box.h>
#include <Processing/Vision/CImage/Draw/Triangle.h>
#include <Processing/Vision/CImage/Draw/Polygon.h>
#include <Processing/Vision/CImage/Draw/Fill.h>
#include <Processing/Vision/CImage/Draw/Brushes.h>


#endif
