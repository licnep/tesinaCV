#ifndef _MINIMIZATION_FUNCTION_H
#define _MINIMIZATION_FUNCTION_H

#include <Libs/Compatibility/DeclSpecs.h>



namespace disparity
{
    
    namespace impl
    {
        class Cpp;
        class SIMD;
        class Auto;
    }

    
    namespace opt
    {
        namespace minimization
        {        
                          
            
            template<class Impl, class CorrelType, class DispType>
            DECLSPEC_FORCEINLINE inline int minimize( CorrelType* pixel_corr, DispType *best_disp, CorrelType *best_sad, int d_min, int d_max)
            {
                
                best_sad[0]=std::numeric_limits<CorrelType>::max();
                best_sad[1]=std::numeric_limits<CorrelType>::max();
                best_sad[2]=std::numeric_limits<CorrelType>::max();
                best_sad[3]=std::numeric_limits<CorrelType>::max();
                
                DispType d_max_ = d_max - (d_max - d_min + 1) % 4;
                DispType d = d_max;
                DispType k=0;

                for (; d > d_max_; --d, ++k)
                    if (pixel_corr[d] < best_sad[k % 4]) {

                        best_sad[k % 4] = pixel_corr[d];
                        best_disp[k % 4] = d;
                    }

                for (; d-3 >= d_min; d -= 4) {

                    if (pixel_corr[d] < best_sad[3]) {

                        best_sad[3] = pixel_corr[d];
                        best_disp[3] = d;
                    }

                    if (pixel_corr[d-1] < best_sad[2]) {

                        best_sad[2] = pixel_corr[d-1];
                        best_disp[2] = d - 1;
                    }

                    if (pixel_corr[d-2] < best_sad[1]) {

                        best_sad[1] = pixel_corr[d-2];
                        best_disp[1] = d - 2;
                    }

                    if (pixel_corr[d-3] < best_sad[0]) {

                        best_sad[0] = pixel_corr[d-3];
                        best_disp[0] = d - 3;
                    }
                }

                int minimum = 0;

                if (std::min(best_sad[0], best_sad[1]) == best_sad[1])
                    minimum = 1;

                if (std::min(best_sad[minimum], best_sad[2]) == best_sad[2])
                    minimum = 2;

                if (std::min(best_sad[minimum], best_sad[3]) == best_sad[3])
                    minimum = 3;

                return minimum;
            }

#ifdef __SSE2__

      
            template<>
            DECLSPEC_FORCEINLINE inline int minimize<impl::SIMD, uint32_t, int32_t>(uint32_t* pixel_corr, int32_t* best_disp, uint32_t* best_sad, int d_min, int d_max)
            {
                int32_t d_min_ = (((long)(pixel_corr + d_min) & ~15) - (long)pixel_corr) / 4;

                DECLSPEC_ALIGN(16) int32_t disp0[] = { 0, 1, 2, 3 };

                int32_t a = pixel_corr[d_max + 1];
                int32_t b = pixel_corr[d_max + 2];
                int32_t c = pixel_corr[d_max + 3];
                int32_t d = pixel_corr[d_max + 4];

                __asm__ __volatile__ (

                    "movdqa %2, %%xmm0\n\t"
#ifndef __SSE4_1__
                    "pcmpeqd %%xmm7, %%xmm7\n\t"
#endif
                    "pcmpeqd %%xmm1, %%xmm1\n\t" // 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
                    "psrld $1, %%xmm1\n\t"       // serve perché signed
                    "pcmpeqd %%xmm5, %%xmm5\n\t"
                    "psrld $31, %%xmm5\n\t"
                    "pslld $2, %%xmm5\n\t"       // 0x00000004000000040000000400000004
                    "pxor %%xmm4, %%xmm4\n\t"
                    "por %%xmm0, %%xmm4\n\t"     // xmm4 = xmm0
                    "movdqu  %%xmm1, %0\n\t"
                    "movdqu  %%xmm1, %1\n\t"
                : "=m"(*(pixel_corr + d_max + 1)),
                    "=m"(*(pixel_corr + d_min - 4))
                            : "m"(*disp0)
                            : "%xmm0", "%xmm1", "%xmm4", "%xmm5", "%xmm7");

                for (int i = d_min_; i <= d_max; i += 4) {

                    __asm__ __volatile__ (

                        "movdqa %0, %%xmm2\n\t"
                        "pxor %%xmm3, %%xmm3\n\t"
                        "por %%xmm1, %%xmm3\n\t"
#ifdef __SSE4_1__
                        "pminsd %%xmm2, %%xmm1\n\t"   // aggiorno sad minime
                        "pcmpeqd %%xmm1, %%xmm3\n\t"  // maschera di quelli cambiati (255 quelli uguali)
                        "pand %%xmm3, %%xmm0\n\t"     // azzero disparità minime cambiate
                        "pandn %%xmm4, %%xmm3\n\t"    // azzero disp correnti uguali
                        "por %%xmm3, %%xmm0\n\t"      // aggiorno disp minime
#else
                        "pxor %%xmm6, %%xmm6\n\t"
                        "pcmpgtd %%xmm2, %%xmm3\n\t"  // genero maschera 255 cambiati
                        "por %%xmm3, %%xmm6\n\t"
                        "pandn %%xmm7, %%xmm6\n\t"    // genero maschera 0 cambiati
                        "pand %%xmm3, %%xmm2\n\t"
                        "pand %%xmm6, %%xmm1\n\t"
                        "pand %%xmm6, %%xmm0\n\t"
                        "pand %%xmm4, %%xmm3\n\t"
                        "por %%xmm2, %%xmm1\n\t"
                        "por %%xmm3, %%xmm0\n\t"
#endif
                        "paddd %%xmm5, %%xmm4\n\t"    // aggiorno disp correnti
                :
                : "m"(*(pixel_corr + i))
                                : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5",  "%xmm6", "%xmm7"
                            );
                }

                __asm__ __volatile__ (

                    "movdqa  %%xmm1, %0 \n\t"
                    "movdqa  %%xmm0, %1 \n\t"
                : "=m"(*best_sad),
                    "=m"(*best_disp)
                            :
                            : "%xmm0", "%xmm1"
                        );

                pixel_corr[d_max + 1] = a;
                pixel_corr[d_max + 2] = b;
                pixel_corr[d_max + 3] = c;
                pixel_corr[d_max + 4] = d;


                int minimum = 0;

                if (std::min(best_sad[0], best_sad[1]) == best_sad[1])
                    minimum = 1;

                if (std::min(best_sad[minimum], best_sad[2]) == best_sad[2])
                    minimum = 2;

                if (std::min(best_sad[minimum], best_sad[3]) == best_sad[3])
                    minimum = 3;

                best_disp[minimum] += d_min_;

                return minimum;
            }


    
            template<>
            DECLSPEC_FORCEINLINE  inline int minimize<impl::SIMD, uint16_t, int16_t>(uint16_t* pixel_corr, int16_t* best_disp, uint16_t* best_sad, int d_min, int d_max) 
            {
                int16_t disp0[] = {(int16_t)d_min,(int16_t)( d_min + 1), (int16_t)(d_min + 2),(int16_t)( d_min + 3)};

                __asm__ __volatile__ (

                    "movq %1, %%mm0\n\t"
                    "movq %0, %%mm7\n\t"
                    "pcmpeqw %%mm1, %%mm1\n\t" // 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
                    "pxor %%mm6, %%mm6\n\t"
                    "por %%mm1, %%mm5\n\t"
                    "psrlw $15, %%mm5\n\t"
                    "psllw $2, %%mm5\n\t"      // 0x00000004000000040000000400000004"
                    "pxor %%mm4, %%mm4\n\t"
                    "por %%mm0, %%mm4\n\t"     // xmm4 = xmm0
                    "movq  %%mm1, %0\n\t"

                : "=m"(*(pixel_corr + d_max + 1))
                            : "m"(*disp0)
                            : "%mm0", "%mm1", "%mm4", "%mm5", "%mm6", "%mm7"
                        );

                for (int i = d_min; i <= d_max; i += 4) {

                    __asm__ volatile (

                        "movq %0, %%mm2\n\t"
                        "pxor %%mm3, %%mm3\n\t"
                        "por %%mm1, %%mm3\n\t"
                        "psubusw %%mm2, %%mm3\n\t"  // vecchie - nuove
                        "psubusw %%mm3, %%mm1\n\t"
                        "pcmpeqw %%mm6, %%mm3\n\t"  // (255 quelle diverse)
                        "pand %%mm3, %%mm0\n\t"     // azzero disparità minime cambiate
                        "pandn %%mm4, %%mm3\n\t"    // azzero disp correnti uguali
                        "por %%mm3, %%mm0\n\t"      // aggiorno disp minime
                        "paddw %%mm5, %%mm4\n\t"    // aggiorno disp correnti
                :
                : "m"(*(pixel_corr + i))
                                : "%mm0", "%mm1", "%mm2",  "%mm3", "%mm4", "%mm5", "%mm6");
                }

                __asm__ __volatile__ (

                    "movq  %%mm1, %0\n\t"
                    "movq  %%mm0, %1\n\t"
                    "movq  %%mm7, %2\n\t"
                    "emms\n\t"
                : "=m"(*best_sad),
                    "=m"(*best_disp),
                    "=m"(*(pixel_corr+d_max+1))
                            :
                            : "%mm0", "%mm1", "%mm7"
                        );

                int minimum = 0;

                if (std::min(best_sad[0], best_sad[1]) == best_sad[1])
                    minimum = 1;

                if (std::min(best_sad[minimum], best_sad[2]) == best_sad[2])
                    minimum = 2;

                if (std::min(best_sad[minimum], best_sad[3]) == best_sad[3])
                    minimum = 3;

                return minimum;
            }

#endif

            inline int minimize2(uint16_t* pixel_corr, int16_t* best_disp, uint16_t* best_sad, int d_min, int d_max)
            {
                __asm__ __volatile__ (
                    "movd %1, %%xmm4\n\t"  //contatore disp
                    "movdqu %0, %%xmm6\n\t"
                    "pcmpeqw %%xmm0, %%xmm0\n\t"
                    "pcmpeqw %%xmm5, %%xmm5\n\t"
                    "pslld $16, %%xmm4\n\t"
                    "psrld $31, %%xmm5\n\t"
                    "psrld $16, %%xmm4\n\t"
                    "pslld $3, %%xmm5\n\t" //delta disp
                    "movdqu  %%xmm0, %0\n\t"

                : "=m"(*(pixel_corr+d_max+1)) : "m"(d_min) : "%xmm0", "%xmm4", "%xmm5", "%xmm6");


                for (int i=d_min; i  <= d_max; i+=8)
                {
                    __asm__ volatile (
                        "movdqu %0, %%xmm2\n\t"
                        "phminposuw %%xmm2, %%xmm3\n\t"
                        "pshuflw $1,%%xmm3, %%xmm3\n\t"
                        "paddw %%xmm4, %%xmm3\n\t"
                        "pminud %%xmm3,%%xmm0\n\t"
                        "paddw %%xmm5, %%xmm4\n\t"  //aggiorno disp correnti
                :  : "m"(*(pixel_corr+i)):    "%xmm0",  "%xmm2",  "%xmm3", "%xmm4", "%xmm5");

                }


                __asm__ __volatile__ (
                    "movd  %%xmm0, %0\n\t"
                    "movd  %%xmm0, %1\n\t"
                    "movdqu  %%xmm6, %2\n\t"
                :"=m"(*best_disp), "=m"(*best_sad),  "=m"(*(pixel_corr+d_max+1)) : : "%xmm0", "%xmm6");



                int minimum = 0;

                best_sad[0] = best_sad[1];

                return minimum;

            }
    
    
             inline void pixel_loop0()
            {

                DECLSPEC_ALIGN(16) int8_t disp0[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
                __asm__ __volatile__ (
                    "movdqa %0, %%xmm15\n\t"
                    "pcmpeqd %%xmm5, %%xmm5\n\t"
                    "psrlw $15, %%xmm5\n\t"
                    "psllw $4, %%xmm5\n\t"
                    "packuswb %%xmm5, %%xmm5\n\t" //16
                : : "m"(*disp0) :  "%xmm15", "%xmm5");

            }


            inline void pixel_loop(uint8_t* disparityOutputCube,  int m_max_disparity, int& disp)
            {

                __asm__ __volatile__ (
                    "movdqa %0, %%xmm1\n\t"
                    "pshufd  $228, %%xmm15, %%xmm4\n\t"
                    "pshufd  $228, %%xmm15, %%xmm3\n\t"
                : : "m"(*(disparityOutputCube)) : "%xmm0", "%xmm1", "%xmm4");


                for (int k = 16; k < m_max_disparity; k += 16)
                {
                    __asm__ __volatile__ (
                        "movdqa %0, %%xmm2\n\t"
                        "paddb %%xmm5, %%xmm4\n\t"    // aggiorno disp correnti
                        "pshufd  $228, %%xmm1, %%xmm0\n\t"   //copio sad min
                        "pminub %%xmm2, %%xmm1\n\t"   // aggiorno sad minime
                        "pcmpeqb %%xmm1, %%xmm0\n\t"  // maschera di quelli cambiati (255 quelli uguali)
#ifdef __AVX__                    
                        "vpblendvb %%xmm0, %%xmm3, %%xmm4, %%xmm3\n\t" 
#else                        
                        "pand %%xmm0, %%xmm3\n\t"     // azzero disparità minime cambiate
                        "pandn %%xmm4, %%xmm0\n\t"    // azzero disp correnti uguali
                        "por %%xmm0, %%xmm3\n\t"      // aggiorno disp minime
#endif                        
                : :  "m" (*( disparityOutputCube + k ))  : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5"  );
                }

#ifdef __SSE4_1__
                __asm__ __volatile__ (
#ifdef __AVX__       
                    "vpunpcklbw %%xmm1, %%xmm3, %%xmm2\n\t"
                    "punpckhbw %%xmm1, %%xmm3\n\t"
#else
                    "pshufd  $78, %%xmm3, %%xmm2\n\t"
                    "pshufd  $78, %%xmm1, %%xmm0\n\t"
                    "punpcklbw %%xmm1, %%xmm3\n\t"
                    "punpcklbw %%xmm0, %%xmm2\n\t"
#endif                    
                    "pminuw %%xmm2, %%xmm3\n\t"  //8 da 16
                    "phminposuw %%xmm3, %%xmm3\n\t"       
                    "movd  %%xmm3, %0 \n\t"
                : "=m"(disp)  : : "%xmm0", "%xmm1", "%xmm2",  "%xmm3" );
#else   //funzia fino a 128 disp                          
                __asm__ __volatile__ (
                    "psllw $1, %%xmm3\n\t"
                    "pshufd  $78, %%xmm3, %%xmm2\n\t"
                    "pshufd  $78, %%xmm1, %%xmm0\n\t"
                    "punpcklbw %%xmm1, %%xmm3\n\t"
                    "punpcklbw %%xmm0, %%xmm2\n\t"
                    "psrlw $1, %%xmm3\n\t"
                    "psrlw $1, %%xmm2\n\t"
                    "pminsw %%xmm2, %%xmm3\n\t"  //8 da 16
                    "pshufd  $78,%%xmm3, %%xmm2\n\t"
                    "pminsw %%xmm3, %%xmm2\n\t"  //4 da 16
                    "pshufd $1, %%xmm2, %%xmm3\n\t"
                    "pminsw %%xmm3, %%xmm2\n\t"  //2 da 16
                    "pshuflw $1, %%xmm2, %%xmm3\n\t"
                    "pminsw %%xmm2, %%xmm3\n\t"  //1 da 16
                    "psllw $9, %%xmm3\n\t"
                    "psrlw $9, %%xmm3\n\t"
                    "movd  %%xmm3, %0 \n\t"
                : "=m"(disp)  : : "%xmm0", "%xmm1", "%xmm2",  "%xmm3" );
#endif
               disp &= 255;
            }
        }

    }
    
    
    
     
     template <int maxdisp>
     inline void uniqueness_intenal(uint8_t* disparityOutputCube) {}
     
     template <>
     inline void uniqueness_intenal<16>(uint8_t* disparityOutputCube)
     {
         __asm__ __volatile__ (
              "movdqa %0, %%xmm0\n\t"
       : :   "m" (* disparityOutputCube )   : "%xmm0" );
     }
     
     template <>
     inline void uniqueness_intenal<32>(uint8_t* disparityOutputCube)
     {
         __asm__ __volatile__ (
              "movdqa (%0), %%xmm0\n\t"
              "movdqa 16(%0), %%xmm1\n\t"
              "pminub %%xmm1, %%xmm0\n\t"

       : :  "r" (disparityOutputCube ), "m" (* disparityOutputCube )   : "%xmm0", "%xmm1" );
     }
     
     template <>
     inline void uniqueness_intenal<48>(uint8_t* disparityOutputCube)
     {
         __asm__ __volatile__ (
              "movdqa (%0), %%xmm0\n\t"
              "movdqa 16(%0), %%xmm1\n\t"
              "movdqa 32(%0), %%xmm2\n\t"
              "pminub %%xmm1, %%xmm0\n\t"
              "pminub %%xmm2, %%xmm0\n\t"
       : :  "r" (disparityOutputCube ), "m" (* disparityOutputCube )   : "%xmm0", "%xmm1", "%xmm2" );
     }
     
     template <>
     inline void uniqueness_intenal<64>(uint8_t* disparityOutputCube)
     {
         __asm__ __volatile__ (
              "movdqa (%0), %%xmm0\n\t"
              "movdqa 16(%0), %%xmm1\n\t"
              "movdqa 32(%0), %%xmm2\n\t"
              "movdqa 48(%0), %%xmm3\n\t"
              "pminub %%xmm1, %%xmm0\n\t"
              "pminub %%xmm3, %%xmm2\n\t"
              "pminub %%xmm2, %%xmm0\n\t"
       : :  "r" (disparityOutputCube ), "m" (* disparityOutputCube )   : "%xmm0", "%xmm1", "%xmm2", "%xmm3");
     }
     
     template <>
     inline void uniqueness_intenal<80>(uint8_t* disparityOutputCube)
     {
         __asm__ __volatile__ (
              "movdqa (%0), %%xmm0\n\t"
              "movdqa 16(%0), %%xmm1\n\t"
              "movdqa 32(%0), %%xmm2\n\t"
              "movdqa 48(%0), %%xmm3\n\t"
              "movdqa 64(%0), %%xmm4\n\t"
              "pminub %%xmm1, %%xmm0\n\t"
              "pminub %%xmm3, %%xmm2\n\t"
              "pminub %%xmm2, %%xmm0\n\t"
              "pminub %%xmm4, %%xmm0\n\t"
       : :  "r" (disparityOutputCube ), "m" (* disparityOutputCube )   : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4" );
     }
     
     template <>
     inline void uniqueness_intenal<96>(uint8_t* disparityOutputCube)
     {
         __asm__ __volatile__ (
              "movdqa (%0), %%xmm0\n\t"
              "movdqa 16(%0), %%xmm1\n\t"
              "movdqa 32(%0), %%xmm2\n\t"
              "movdqa 48(%0), %%xmm3\n\t"
              "movdqa 64(%0), %%xmm4\n\t"
              "movdqa 80(%0), %%xmm8\n\t"
              "pminub %%xmm1, %%xmm0\n\t"
              "pminub %%xmm3, %%xmm2\n\t"
              "pminub %%xmm8, %%xmm4\n\t"
              "pminub %%xmm2, %%xmm0\n\t"
              "pminub %%xmm4, %%xmm0\n\t"
       : :  "r" (disparityOutputCube ), "m" (* disparityOutputCube )   : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm8" );
     }
     
     template <>
     inline void uniqueness_intenal<112>(uint8_t* disparityOutputCube)
     {
         __asm__ __volatile__ (
              "movdqa (%0), %%xmm0\n\t"
              "movdqa 16(%0), %%xmm1\n\t"
              "movdqa 32(%0), %%xmm2\n\t"
              "movdqa 48(%0), %%xmm3\n\t"
              "movdqa 64(%0), %%xmm4\n\t"
              "movdqa 80(%0), %%xmm8\n\t"
              "movdqa 96(%0), %%xmm6\n\t"
              "pminub %%xmm1, %%xmm0\n\t"
              "pminub %%xmm3, %%xmm2\n\t"
              "pminub %%xmm8, %%xmm4\n\t"
              "pminub %%xmm2, %%xmm0\n\t"
              "pminub %%xmm6, %%xmm4\n\t"
              "pminub %%xmm4, %%xmm0\n\t"
       : :  "r" (disparityOutputCube ), "m" (* disparityOutputCube )   : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm8", "%xmm6" );
     }
     
     template <>
     inline void uniqueness_intenal<128>(uint8_t* disparityOutputCube)
     {
         __asm__ __volatile__ (
              "movdqa (%0), %%xmm0\n\t"
              "movdqa 16(%0), %%xmm1\n\t"
              "movdqa 32(%0), %%xmm2\n\t"
              "movdqa 48(%0), %%xmm3\n\t"
              "movdqa 64(%0), %%xmm4\n\t"
              "movdqa 80(%0), %%xmm8\n\t"
              "movdqa 96(%0), %%xmm6\n\t"
              "movdqa 112(%0), %%xmm7\n\t"
              "pminub %%xmm1, %%xmm0\n\t"
              "pminub %%xmm3, %%xmm2\n\t"
              "pminub %%xmm8, %%xmm4\n\t"
              "pminub %%xmm7, %%xmm6\n\t"
              "pminub %%xmm2, %%xmm0\n\t"
              "pminub %%xmm6, %%xmm4\n\t"
              "pminub %%xmm4, %%xmm0\n\t"
       : :  "r" (disparityOutputCube ), "m" (* disparityOutputCube )   : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm8", "%xmm6", "xmm7" );
     }
     
     template <int maxdisp>
     inline uint8_t uniqueness(uint8_t* disparityOutputCube, int disp)
     {
       uint8_t m1 = disparityOutputCube[disp-1], m2 = disparityOutputCube[disp], m3 = disparityOutputCube[disp+1];
       uint32_t minumum;
       disparityOutputCube[disp-1] = 255;
       disparityOutputCube[disp  ] = 255;
       disparityOutputCube[disp+1] = 255;
       
       
//        __asm__ __volatile__ ( "movdqa %0, %%xmm0\n\t"  : :  "m" (* disparityOutputCube )  : "%xmm0" );
//        
//        for (int k = 16; k < maxdisp; k += 16)
//        {
//           __asm__ __volatile__ (
//               "movdqa %0, %%xmm2\n\t"
//               "pminub %%xmm2, %%xmm0\n\t"   // aggiorno sad minime
//        : :  "m" (*( disparityOutputCube + k ))  : "%xmm0", "%xmm2" );
//        }
      
       uniqueness_intenal<maxdisp>(disparityOutputCube);
     
       __asm__ __volatile__ (
           "pshufd $78,%%xmm0, %%xmm2\n\t"
           "pminub %%xmm2, %%xmm0\n\t"
      #ifdef __SSE4_1__             
           "punpcklbw %%xmm0, %%xmm0\n\t"
           "phminposuw %%xmm0, %%xmm0\n\t"           
      #else
           "pshufd $1, %%xmm0, %%xmm2\n\t"
           "pminub %%xmm2, %%xmm0\n\t"
           "pshuflw $1, %%xmm0, %%xmm2\n\t"
           "pminub %%xmm2, %%xmm0\n\t"
           "punpcklbw %%xmm0, %%xmm0\n\t"
           "pshuflw $1, %%xmm0, %%xmm2\n\t"
           "pminub %%xmm2, %%xmm0\n\t"               
      #endif
           "movd  %%xmm0, %0 \n\t"
              : "=m"(minumum)  : : "%xmm0", "%xmm2" );
       
       disparityOutputCube[disp-1] = m1;
       disparityOutputCube[disp  ] = m2;
       disparityOutputCube[disp+1] = m3;
       
       return minumum;
     }
     
     
    
}

#endif
