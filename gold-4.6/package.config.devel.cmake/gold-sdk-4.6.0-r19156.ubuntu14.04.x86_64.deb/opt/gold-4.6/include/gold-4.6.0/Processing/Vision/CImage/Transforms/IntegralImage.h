#ifndef _INTEGRAL_IMAGE_H
#define _INTEGRAL_IMAGE_H

/** @file IntegralImage.h
  * @brief method to generate and handle an Integral Image
  * 
  * Since IntegralImage is normally involved in high performance computation, the several methods in this file should be used
  *  according to application requirements.
  **/

#include <boost/tr1/cmath.hpp>
#include <boost/utility.hpp>

#include <Processing/Vision/CImage/gold_proc_cimage_export.h>
#include <Data/CImage/TImage.h>
#include <Data/Math/Rects.h>

#include <algorithm>

// namespace intimg {

/////////////////////////////

/// 
template<class T>
class difference_type;

template<>
class difference_type<uint32_t> {
public:
  typedef int32_t type;
};

template<>
class difference_type<uint64_t> {
public:
  typedef int64_t type;
};

template<>
class difference_type<float> {
public:
  typedef float type;
};

template<>
class difference_type<double> {
public:
  typedef double type;
};

/////////////////////////////

/** Haar Pre-Compute namespace */
namespace haar {

/// Box integral. Weight: 3 sums
struct Box {
  /// offset
 long A,B,C,D;

template<class T>
 inline typename difference_type<T>::type operator()(const T*data) const
	{
	return data[A]+data[D]-data[C]-data[B]; // always positive
	}
};

/// 2Lobe feature Integral. Weight: 5 sums, 2 shifts
struct Feat2 {
 /// offset A(+1), B(-1), C(-2), D(+2), E(+1), F(-1)
 long A,B,C,D,E,F;

template<class T>
 inline typename difference_type<T>::type operator()(const T*data) const
	{
	typedef typename difference_type<T>::type R;
	return (R)data[A]-(R)data[B]-(R)2*data[C]+(R)2*data[D]+(R)data[E]-(R)data[F];
	}
};

}

/////////////////////////////

/** The integral image.
 *  The use of handle is required in order to remove an eventual pointer dereferencing during apply and consequentely improve performance.
 * 
 * TODO add a Crop API and a Build with additional stride parameter
 */
template<class T>
struct IntegralImageHandle {
public:
  /** the origin of integral image */
  T *data;
  /** Integral image geometry */
  unsigned int width, height;
  
public:
  /** DifferenceType used when returns */
  typedef typename difference_type<T>::type DifferenceType;
  
  // precomputed type
  typedef haar::Box BoxType;
  typedef haar::Feat2 DxType;
  typedef haar::Feat2 DyType;
  
public:
  IntegralImageHandle() : data(0), width(0), height(0) { }
  
  /** copy: only handle integral image can receive copy */
  IntegralImageHandle(const IntegralImageHandle<T> & src)
  {
    data = src.data;
    width = src.width;
    height = src.height;
  }
  
  void operator=(const IntegralImageHandle<T> & src)
  {
    data = src.data;
    width = src.width;
    height = src.height;
  }  
  
  /** create an IntegralImage from an image buffer */
  template<class PixelType>
  IntegralImageHandle(const PixelType *ptr, unsigned int width, unsigned int height, bool extend = false) : data(0), width(0), height(0)
  {
    Build(ptr, width, height, extend);
  }
  
  
  ~IntegralImageHandle() { 
  }
  
  void Release()
  {
    delete [] data; 
  }
  
  /// Resize (destructive) of buffer
  void Resize(unsigned int width, unsigned int height)
  {
   delete [] data;
   this->width = width;
   this->height = height;
   data = new T[this->width * this->height]; // reserve new memory
  }
  
  T & operator() (int i, int j) { return data[i + j * width]; } 
  const T & operator() (int i, int j) const { return data[i + j * width]; } 
  
  /**convert the integral image in a buffer. The buffer must be width x height
   * @return pixel(x,y) = I(x,y) + I(x-1,y-1) - I(x,y-1) - I(x-1,y)
   */
  T pixel_at(int x, int y) const
    {
    // TODO: NDEBUG
    if(x<0 || y < 0 || x >=(int)this->width || y>=(int)this->height)
     {
      std::cerr << "pixel_at(" << x << ',' << y << ")" << std::endl;
      throw std::runtime_error("pixel_at called with invalid parameters");
    }
    uint32_t acc = data[x + y * width];
    if(x>0 && y>0) acc += data[(x-1) + (y-1) * width];
    if(x>0) acc -= data[(x-1) + y * width];
    if(y>0) acc -= data[x + (y-1) * width];
    return acc;
  }
  
  /// recover using interpolation integral-image value in x,y
  double interpolated_value_at(double x, double y) const {
   int ix = (int) boost::math::tr1::trunc(x);
   double mx = x - boost::math::tr1::trunc(x);
   int iy = (int) boost::math::tr1::trunc(y);
   double my = y - boost::math::tr1::trunc(y);
   
   // TODO: non vengono controllati i boundaries. 

   double acc = data[(ix+1)+(iy+1)*width] * mx * my;
   if(ix>0 && iy> 0)
     acc += data[ix + iy * width] * (1.0 - mx) * (1.0 - my);
   if(ix>0)
     acc += data[ix + (iy+1) * width] * (1.0 - mx) * my;
   if(iy>0)
     acc += data[(ix+1) + iy * width] * mx * (1.0 - my);
   
   return acc;
     }
      
  /** convert the integral image in a buffer.
   * \code
   * auxIntImage.Export(buf.Buffer(), 1,1, width, height);
   * \endcode
   * @todo use CImage also, add stride eventually
   * */
  template<class D>
  void Export(D * buf, int x0, int y0, int dst_width, int dst_height) const
  {
    for(int j = 0;j<dst_height;++j)
     for(int i = 0;i<dst_width;++i)
     {
       T val = pixel_at(x0 + i, y0 + j); // non molto ottimizzato al momento
       if(val > std::numeric_limits<D>::max() )
         val = std::numeric_limits<D>::max();
       if(val < std::numeric_limits<D>::min() )
         val = std::numeric_limits<D>::min();
       buf[i + j * dst_width] = val;
    }
  }
  
/** Build integral image from buffer
 * @param src a pointer to image buffer
 * @param width image width
 * @param height image height
 * @param extend build an extended integral image. Extended integral image is width+1 x height+1 larger in order to deal with (-1,-1) coordinates */
template<class _S>
void Build(const _S *src, unsigned int width, unsigned int height, bool extend = false)
{
  if(extend)
    Resize(width + 1, height + 1);
  else
    Resize(width, height);
  
  T *i_data = data;
  // first row only
  T rs = T(0);
  
  if(extend) {
    // [first row] and [first element] of second row are zeroes.
    for(unsigned int j=0; j<width+2; j++) 
	*i_data++ = T(0);
  }

  // first row (extended/non extended version)
  for(unsigned int j=0; j<width; j++) 
  {
    rs += *src; 
    *i_data = rs;
    src++;
    i_data++;
  }
  
  long prev_row = - (long) this->width;

  // remaining cells are sum above and to the left
  for(unsigned int i=1; i<height; ++i) 
  {
    rs = T(0);
    
    if(extend) {
      *i_data++ = T(0);
    }
    
    for(unsigned int j=0; j<width; ++j) 
    {
      rs += *src; 
      *i_data = rs + i_data[prev_row];
      i_data++;
      src++;
    }
  }
}

/////////////////////////////////////////////////////////////////////

/// feature haar 2h
/// TODO: verificare che funzioni
inline DifferenceType Dx(int x, int y, int s) const
  {
    int r1 = (y-s)*width;
    int r2 = (y+s)*width;
    int c1 = (x-s);
    int c2 = (x+s);
    
    return 2*(DifferenceType)data[r1 + x] + (DifferenceType)data[r2+c2] + (DifferenceType)data[r1+c2] - (DifferenceType)data[r1+c1] - (DifferenceType)data[r1+c2] 
    - 2*(DifferenceType)data[x+c2];
  }  

/** Precompute a 2h haar feature (size 2s x 2s)
 * a---b---c
 * |   |   |
 * | -1| +1| (f+b-c-e) - (e+a-b-d)
 * |   |   | f+b-c-e -e -a +b +d
 * d---e---f -a+2b-c+d-2e+f
 * */
DxType PrecomputeDx(int s) const
{
  DxType p;
  long r1 = (-s)*(long)width;
  long r2 = (+s+1)*(long)width;
  long c1 = (-s);
  long c2 = (+s+1);
  // offset A(+1), B(-1), C(-2), D(+2), E(+1), F(-1)
  p.A = r2 + c1; // + (d)
  p.B = r1 + c1; // - (a)
  p.C = r2 + 0; // 2- (e)
  p.D = r1 + 0; // 2+ (b)
  p.E = r2 + c2; // + (f)
  p.F = r1 + c2; // - (c)
  return p;
}

/// feature haar 2v
/// TODO: verificare che funzioni
inline DifferenceType Dy(int x, int y, int s) const
  {
    int r1 = (y-s)*width;
    int r2 = (y)*width;
    int r3 = (y+s)*width;
    int c1 = (x-s);
    int c2 = (x+s);
    
    return (DifferenceType)data[r1+c1] - (DifferenceType) data[r1+c2] - 2 * (DifferenceType) data[r2+c1] + 2 * (DifferenceType) data[r2+c2] + (DifferenceType) data[r3+c1] - (DifferenceType) data[r3-c2];
  }  

/** Precompute a 2v haar feature (size 2s x 2s)
 * a-------b
 * |  -1   |
 * c-------d (f+c-d-e) - (d+a-b-c)
 * |  +1   | f+c-d-e -d -a +b +c
 * e-------f -a+b+2c-2d-e+f
  */
DyType PrecomputeDy(int s) const
{
  DyType p;
  long r1 = (-s)*(long)width;
  long r2 = (+s)*(long)width;
  long c1 = (-s);
  long c2 = (+s);
  // offset A(+1), B(-1), C(-2), D(+2), E(+1), F(-1)
  p.A = r1 + c2; // + (b)
  p.B = r1 + c1; // - (a)
  p.C = 0  + c2; // 2-(d)
  p.D = 0  + c1; // 2+(c)
  p.E = r2 + c2; // + (f)
  p.F = r2 + c1; // - (e)
  return p;
}

/** create a PBox for fast Box extraction */
BoxType PrecomputeBox(int x, int y, int dx, int dy) const
{
  BoxType p;
  long r1 = y * (long) width;
  long c1 = x;
  long r2 = (y+dy) *(long) width;
  long c2 = x+dx;
  p.A = r1 + c1;
  p.B = r1 + c2;
  p.C = r2 + c1;
  p.D = r2 + c2;
  return p;
}

/** internal box computing, using memory row (r1,c1)-(r2,c2).
 *  Weight: 7 sum
 */
inline T _Box(int r1, int c1, int r2, int c2) const
  {
    return data[r1 + c1] + data[r2 + c2] - data[r1 + c2] - data[r2 + c1];
  }  

/** compute sum of area inside box (x-1,y-1)-(x-1+dx,y-1+dy) INCLUDED: see note
 *  Weight: 9 Sum, 2 Multiply
 * 
 * @note Un BOX che somma le energie tra (x,y) e (x',y') COMPRESI e' uguale a:
 *  I(x',y') - I(x',y-1) - I(x-1,y') + I(x-1,y-1)
 * percio' Box(x-1,y-1, x'-x+1, y'-y+1);
 */
inline T Box(int x, int y, int dx, int dy) const
  {
    return _Box(y * width, x, (y+dy)*width, x+dx);
  }  

};

/** IntegralImage release memory at the end of scope. 
 * For performance reason (double pointer dereferencing), IntegralImageHandle can be copied and used inside class without involve real copy
 */
template<class T>
struct IntegralImage: public IntegralImageHandle<T>, public boost::noncopyable {
public:
  IntegralImage(){ }
  
  /// create an integral image from  an image
  template<class PixelType>
  IntegralImage(const PixelType *ptr, unsigned int width, unsigned int height, bool extend = false) : IntegralImageHandle<T>(ptr, width, height, extend) { }
  
  ~IntegralImage(){ IntegralImageHandle<T>::Release(); }
};

// }


/** Resample an Integral image using bilinear interpolation. 
 *  An integral image can be downsample and upsamples with the same method */
template<class T>
void Resample(IntegralImageHandle<T> & dst, unsigned int dstWidth, unsigned int dstHeight, const IntegralImageHandle<T> & src, double u0, double v0, double du, double dv)
{
    dst.Resize(dstWidth, dstHeight);
  
  double norm = 1.0 / (du*dv);
  // TODO: il bordo potrebbe non essere valido
  // equazione magica (believe, funziona!) leggere la documentazione dell'immagine integrale
  u0 += du - 1.0;
  v0 += dv - 1.0;

  const double w0 = 0.5; // TODO

  // check nel caso in cui du,dv < 1.0
  int i0 = 0;
  if(u0 < 0.0)
  {
    i0 = (int) ceil(-u0 / du);
    u0 += i0 * du;
  }
  
  int j0 = 0;
  if(v0 < 0.0)
  {
    j0 = (int) ceil(-v0 / dv);
    v0 += i0 * dv;
  }

  double v = v0;
  
  // TODO: ora il bordo e' non inizializzato: usare del codice ad hoc per inizializzarlo

  for(unsigned int j=j0;j<dstHeight;++j)
  {
   int iv = (int) boost::math::tr1::trunc(v);
   double mv = v - boost::math::tr1::trunc(v);
   double u = u0;
   for(unsigned int i=i0;i<dstWidth;++i)
   {
      int iu = (int) boost::math::tr1::trunc(u);
      double mu = u - boost::math::tr1::trunc(u);
     
      const T *ptr = &src.data[ iu + iv * src.width];

      double t = norm * (  (double) ptr[0] * (1.0 - mu) * (1.0 - mv) + (double) ptr[1] * (mu) * (1.0 - mv) +
 			  (double) ptr[src.width] * (1.0 - mu) * (mv) + (double)  ptr[src.width + 1] * (mu) * (mv) );
      
      dst.data[i + dst.width *j] = (uint32_t) (t + w0);
				  
// 	std::cout << dst.data[i + dst.width *j] << ' ';
      u+=du;
   }
    v += dv;
  }
  
}


/** Resample an Integral image using bilinear interpolation. 
 *  An integral image can be downsampled and upsampled with the same method 
 *
 * Per maggiori informationi, richiedere a Paolo Medici <medici@ce.unipr.it>
 */
template<class T>
void Resample(const IntegralImageHandle<T> & src, IntegralImageHandle<T> & dst, const math::Rect2d & srcRect, unsigned int dstWidth, unsigned int dstHeight)
{
  double u0 = srcRect.x0;
  double v0 = srcRect.y0;
  double du = srcRect.width() / (double) dstWidth;
  double dv = srcRect.height() / (double) dstHeight;
  
  Resample<T>(dst, dstWidth, dstHeight, src, u0,v0,du,dv);
}

#endif
