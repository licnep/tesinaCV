/** @file  interpolation.h
  * @brief funzioni interpolanti a tratti
  **/

#ifndef _INTERPOLATION_H
#define _INTERPOLATION_H

#include <vector>
#include <Processing/Math/gold_proc_math_export.h>
#include <Data/Math/Points.h>
#include <Data/Math/Quadratics.h>

namespace math {

/// inner class for spline
///  le funzioni interpolanti sono un vettore di punti (ordinato)
class GOLD_PROC_MATH_EXPORT SplineBase {
public:
    std::vector<Point2d> m_points;

    /// ritorna l'indice del punto con la x piu' vicina alla @a x data
    int find_nearest(double x) const;

    /// ritorna l'indice del punto con la x inferiore alla @a x data
    int find_lower(double x) const;

public:
    SplineBase(const std::vector<Point2d> & points, bool sort=false);
    ~SplineBase();

};

/////////////////////// funzioni interpolanti (continue e a tratti) ////////////////////////////
// Questa classe di funzioni hanno gli stessi metodi e lo stesso costruttore
//  per permettere di usarle nei template.
//

/// funzione continua a tratti di secondo grado
class GOLD_PROC_MATH_EXPORT QuadraticSlice: public SplineBase {
    std::vector<Quadratic1d> m_spline; // spline continue a tratti che passano per il punto scelto
    int find_pivot(double x) const;
public:
    QuadraticSlice(const std::vector<Point2d> &);
    ~QuadraticSlice();
    double operator()(double x) const;
};

/// spline lineare (funzione interpolante a tratti di primo grado)
class GOLD_PROC_MATH_EXPORT LinearSpline: public SplineBase {
public:
    LinearSpline(const std::vector<Point2d> &);
    ~LinearSpline();
    double operator()(double x) const;
};

/// spline quadratica UNIMPLEMENTED YET
class GOLD_PROC_MATH_EXPORT QuadraticSpline {
public:
    QuadraticSpline(const std::vector<Point2d> &);
    ~QuadraticSpline();
    double operator()(double x) const;
};

/// spline cubica UNIMPLEMENTED YET
class GOLD_PROC_MATH_EXPORT CubicSpline {

public:
    CubicSpline(const std::vector<Point2d> &);
    ~CubicSpline();
    double operator()(double x) const;
};


////////////////////////////////////////////// Metodi per l'interpolazione /////////////////////////////////

struct vpoint: public Point2d {
    double value;
};

GOLD_PROC_MATH_EXPORT double generic_bilinear_interpolation(const vpoint & a, const vpoint & b, const vpoint & c,const vpoint & d, double x, double y);

/// ritorna il valore di interpolazione tra le rette a,c e le rette b,d che passa per il punto (x,y)
GOLD_PROC_MATH_EXPORT double sweep_value(const Point2d & a, const Point2d & b, const Point2d & c, const Point2d & d, double x, double y);

/// ritorna il punto sweep di peso @a alpha tra @a a e @a b
template<class T>
inline Point2<T> sweep(const Point2<T> & a, const Point2<T> & b, T alpha)
{
    // return alpha * b + (1 - alpha) * a
    return Point2<T>(alpha * b.x + (T(1) - alpha) * a.x, alpha * b.y + (T(1) - alpha) * a.y);
}

}

#endif
