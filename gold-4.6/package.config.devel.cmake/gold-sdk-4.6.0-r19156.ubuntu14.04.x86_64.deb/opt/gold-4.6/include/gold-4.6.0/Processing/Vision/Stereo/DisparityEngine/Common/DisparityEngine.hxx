#ifndef _DISPARITYENGINE_HXX
#define _DISPARITYENGINE_HXX

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file DisparityEngine.hxx
 * \author Paolo Zani (zani@vislab.it) Mirko Felisa (felisa@vislab.it)
 * \date 2010-10-21
 */

#include <Processing/Vision/Stereo/Images/CDSI.h>
#include <Processing/Vision/Stereo/Images/CScoreImage.h>
#include <Processing/Vision/Stereo/DisparityEngine/Common/SearchRange.h>
#include <Processing/Vision/Stereo/DisparityEngine/Common/DisparityEngineData.h>
#include <Processing/Vision/CImage/BasicOperations/BasicOperations.h>

#include <stdint.h>
#include <stdexcept>
#include <vector>

// #define __DEBUG__

#include <iostream>

#ifdef __DEBUG__
#define __log_debug  std::cout << "[DB] DisparityEngine/Aggregation/Window/Core_Cpp.h "  << __LINE__ << " "
#else
#define __log_debug  while(0) std::cout
#endif

namespace disparity
{
    template<template<typename> class Cost, typename ResultType_Cost,
            template<typename, typename, typename, uint32_t> class Aggregation, typename ResultType_Agg, typename Impl_Agg, uint32_t Threads_Agg,
            template<typename, uint32_t, typename, typename, uint32_t> class Optimization, typename ResultType_Opt, typename Impl_Opt, uint32_t Threads_Opt>
    class TDisparityEngine : public Core<Cost<ResultType_Cost>,
                                         Aggregation<ResultType_Cost, ResultType_Agg, Impl_Agg, Threads_Agg>,
                                         Optimization<ResultType_Agg, Threads_Agg, ResultType_Opt, Impl_Opt, Threads_Opt> >, protected virtual DisparityEngineData
    {
        public:

            typedef Cost<ResultType_Cost> CostType;
            typedef Aggregation<ResultType_Cost, ResultType_Agg, Impl_Agg, Threads_Agg> AggregationType;
            typedef Optimization<ResultType_Agg, Threads_Agg, ResultType_Opt, Impl_Opt, Threads_Opt> OptimizationType;
            
            TDisparityEngine() : m_topOffset(0), m_bottomOffset(0), m_leftOffset(0), m_rightOffset(0), m_alpha(255) {}
            
            /**
            *\brief Returns the Disparity Space Image
            * @return the Disparity Space Image
            */
            inline  const boost::shared_ptr<const CDSI> GetDSI() const { return m_dsi; }

            /**
            *\brief Returns each pixel's matching score (SAD/SAV)
            * @return the pixel matching score
            */
            inline boost::shared_ptr<const CScoreImage> GetScores() const { return m_score; }

            template<typename T>
            inline boost::shared_ptr<const CDSI> Run(const std::pair<cimage::TImage<T>, cimage::TImage<T> >& images, const std::vector<SearchRange>& searchRanges = std::vector<SearchRange>(), const cimage::CImageMono8& mask = cimage::CImageMono8())
            {
                return Run(images.first, images.second, searchRanges, mask);
            }

            template<typename T>
            inline boost::shared_ptr<const CDSI> Run(const cimage::TImage<T>& left, const cimage::TImage<T>& right, const std::vector<SearchRange>& searchRanges = std::vector<SearchRange>(), const cimage::CImageMono8& mask = cimage::CImageMono8())
            {
                uint32_t src_width = left.W();
                uint32_t src_height = left.H();
                
                uint32_t width = src_width;
                uint32_t height = src_height;
                
                CoreType::SetDimensions(width, height);

                if((src_width != right.W()) || (src_height != right.H()) || (mask.W() && src_width != mask.W()) || (mask.H() && src_height != mask.H()))
                    throw(std::invalid_argument("[EE] DisparityEngine::Run<T>() - source images dimensions must agree"));

                if((CoreType::m_winWidth > src_width) || (CoreType::m_winHeight >src_height))
                    throw(std::invalid_argument( "[EE] DisparityEngine::Run<T>() - source image is smaller than correlation window!"));

                m_dsi = boost::shared_ptr<CDSI>(new CDSI(width, height));
                m_score = boost::shared_ptr<CScoreImage>(new CScoreImage(width, height));

                if((m_leftOffset + m_rightOffset >=  src_width) || ((m_topOffset + m_bottomOffset >= src_height)))
                    return m_dsi;

                m_srcXMin = std::max(static_cast<int>(CoreType::m_winWidth / 2), static_cast<int>(m_leftOffset));
                m_srcXMax = std::min(static_cast<int>(src_width - (CoreType::m_winWidth - CoreType::m_winWidth / 2) + 1), static_cast<int>(src_width - m_rightOffset));
                m_srcYMin = std::max(static_cast<int>(CoreType::m_winHeight / 2), static_cast<int>(m_topOffset));
                m_srcYMax = std::min(static_cast<int>(src_height - (CoreType::m_winHeight - CoreType::m_winHeight / 2) + 1), static_cast<int>(src_height - m_bottomOffset));

                m_downsample_ratio = src_width / width;
                
                m_srcXMax =  ((m_srcXMax - m_srcXMin)/ m_downsample_ratio) * m_downsample_ratio + m_srcXMin;
                m_srcYMax =  ((m_srcYMax - m_srcYMin)/ m_downsample_ratio) * m_downsample_ratio + m_srcYMin;

                m_dsiXMin = m_srcXMin / m_downsample_ratio;
                m_dsiXMax = (m_srcXMax - m_srcXMin) / m_downsample_ratio + m_dsiXMin;
                m_dsiYMin = m_srcYMin / m_downsample_ratio;
                m_dsiYMax =  (m_srcYMax - m_srcYMin) / m_downsample_ratio + m_dsiYMin;
                
                
                {
                    Disparity* pDsi = m_dsi->Buffer();
                    Score* pScore = m_score->Buffer();

                    for(unsigned int i = 0; i < width * m_dsiYMin; ++i) {

                        *pDsi++ = DISPARITY_UNKNOWN;
                        *pScore++ = SCORE_UNKNOWN;
                    }

                    for(unsigned int j = m_dsiYMin; j < m_dsiYMax; ++j) {

                        for(unsigned int i = 0; i < m_dsiXMin; ++i ) {

                            *pDsi++ = DISPARITY_UNKNOWN;
                            *pScore++ = SCORE_UNKNOWN;
                        }

                        pDsi += m_dsiXMax - m_dsiXMin;
                        pScore += m_dsiXMax - m_dsiXMin;

                        for(unsigned int i = m_dsiXMax; i < width; ++i) {

                            *pDsi++ = DISPARITY_UNKNOWN;
                            *pScore++ = SCORE_UNKNOWN;
                        }
                    }

                    for(unsigned int i = 0; i < width * (height - m_dsiYMax); ++i) {

                        *pDsi++ = DISPARITY_UNKNOWN;
                        *pScore++ = SCORE_UNKNOWN;
                    }

                    __log_debug << "m_censusWinWidth = " << CoreType::m_winWidth << std::endl;
                    __log_debug << "m_censusWinHeight = " << CoreType::m_winHeight << std::endl;
                    __log_debug << "m_dsi.W() = " << m_dsi->W() << std::endl;
                    __log_debug << "m_dsi.H() = " << m_dsi->H() << std::endl;
                    __log_debug << "m_dsiXMin = " <<  m_dsiXMin << " m_dsiYMin = " << m_dsiYMin << " m_dsiXMax = " << m_dsiXMax << " m_dsiYMax = " << m_dsiYMax << std::endl;
                    __log_debug << "m_srcXMin = " <<  m_srcXMin << " m_srcYMin = " << m_srcYMin << " m_srcXMax = " << m_srcXMax << " m_srcYMax = " << m_srcYMax << std::endl;
                    m_searchRanges = searchRanges;
                    m_searchRanges.resize(src_height, std::make_pair(0, 0.2 * src_width - 1));

                    // left range values must be weakly increasing from top to bottom for the correlation algorithm to work properly

                    for(uint32_t i = 1; i < m_searchRanges.size(); ++i)
                        if(m_searchRanges[i - 1].first > m_searchRanges[i].first)
                            m_searchRanges[i].first = m_searchRanges[i-1].first;

                    int32_t dispMin = m_searchRanges[m_srcYMin].first;
                    int32_t dispMax = m_searchRanges[m_srcYMin].second;

                    for(unsigned int i = m_srcYMin; i < m_srcYMax; ++i)
                        if(m_searchRanges[i].second > dispMax)
                            dispMax = m_searchRanges[i].second;


                    m_dsi->MetaData().put("MIN", (int)(ceil(dispMin/(float)m_downsample_ratio)));  
                    m_dsi->MetaData().put("MAX", (int)(ceil(dispMax/(float)m_downsample_ratio))); 
                    m_dsi->MetaData().put("ALPHA", m_alpha);   
                    m_dispMin = dispMin;
                    m_dispMax = dispMax;
                        
                    CoreType::Run(left, right, mask);
                }

                return  m_dsi;
            }

            uint32_t m_topOffset;
            uint32_t m_bottomOffset;
            uint32_t m_leftOffset;
            uint32_t m_rightOffset;
            int32_t  m_alpha;

        private:

            typedef Core<Cost<ResultType_Cost>, Aggregation<ResultType_Cost, ResultType_Agg, Impl_Agg, Threads_Agg>, Optimization<ResultType_Agg, Threads_Agg, ResultType_Opt, Impl_Opt, Threads_Opt> > CoreType;            
    };
}

#endif
