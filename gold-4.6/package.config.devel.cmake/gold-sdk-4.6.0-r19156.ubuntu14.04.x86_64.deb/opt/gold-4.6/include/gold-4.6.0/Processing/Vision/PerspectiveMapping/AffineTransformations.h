#ifndef _AFFINE_MAP_H
#define _AFFINE_MAP_H

/** @file AffineTransformations.h
  * @brief components to generate Affine Transformation Matrix
  *        La classe at::AffineMatrix aggiunge l'operator * e l'operator () a matrici rettangolari 2x3 che nativamente non potrebbero averlo.
  * @author Paolo Medici
  * @note Guardare le trasformazioni dichiarate in Transformation.h e le mette in un oggetto AffineMatrix in modo
  *       da poterlo utilizzare velocemente per composioni con LUT o utilizzo in generale
  * @todo change the name of header in AffineMatrix.h as HomographicMatrix
  **/

#include <iosfwd>
#include <vector>
#include <utility>

#include <Data/Math/Points.h>
#include <Data/Math/Lines.h>
#include <Data/Math/Rects.h>
#include <Data/Math/TMatrices.h>
#include <Processing/Math/Transformation.h>

#include <Processing/Vision/PerspectiveMapping/gold_proc_pm_export.h>

/// affine transformation namespace
namespace at {

  /// Flag to choose the affine transformation regression
  ///  in order to change the constraints type 
  enum TransformationType { 
    Free,  ///< 4 DOF [a,b,c,d]
    Scale, ///< 1 DOF [a,0,0,a]
    Asymmetric_Scale, ///< 2 DOF [a,0,0,b]
    Scale_and_Rotate  ///< 2 DOF [a,-b,b,a]
  };
  
/** un'estensione alla matrix 2x3 per permettere l'applicazione della matrice a punti Point2d, Point3d e rette
 *
 * Esempio di codice per convertire un elenco di punti:
 * \code
 * at::AffineMatrix<double> M;
 * // ...
 * std::transform(src.begin(), src.end(), dst.begin(), M);
 * \endcode
 * Esempio di creazione di una AffineMatrix:
 * \code
 * at::AffineMatrix<double> R = Compose(m_map.WorldToIpm<double>(), M);
 * \endcode
 *
 * @note la trasformazione affine, come tutte le trasformazioni, trasforma un punto dall'immagine Sorgente all'immagine Destinazione
 *       se usato in una LUT o in una trasformazione densa tra immagini e' chiaro che il suo comportamento sara' opposto
 **/
template<class T>
class GOLD_PROC_PM_EXPORT AffineMatrix : public math::TMatrix<T,2,3> {
    public:
    /** \code
      *  at::AffineMatrix::Matrix M;
      * \endcode
      **/
    typedef math::TMatrix<T,2,3> Matrix;
    public:
    AffineMatrix() { }

    /** Costruttore da una TMatrix<double,2,3> */
    AffineMatrix(const math::TMatrix<T,2,3> & m) : Matrix(m) { }

    /** Compone due trasformazioni affini
    * \f$ X = [Y 1] (A) , Y = [Z 1] (B) \f$
    * diventa:
    * \f$ X = [Z 1] (OUT) \f$
    */
    AffineMatrix(const Matrix & a, const Matrix & b) : Matrix( math::Compose(a,b) ) { }
    
    template<class R>
    explicit AffineMatrix(const R *m) : math::TMatrix<T,2,3>(m) { }

    /** Create an affine matrix using constraints and some structural rule (param1 and translate)
     * build the transformation who transform the first in the second:
     *  second = M * first
     * using an algebraic regression.
     * @todo add a geometric non-linear regression method
     * @note to use this function Eigen must be installed and reported
     * @todo throw an exception in case of rank-deficient matrix
     * */
    AffineMatrix(const std::vector< std::pair< math::Point2<T>, math::Point2<T> > > & constraints, TransformationType param1, bool translate); 
   
    /// return the determinant of trasformation (sovrascrive quello di TMatrix)
    inline T det() const { return this->M[0] * this->M[4] - this->M[3] * this->M[1]; }

    /// return the invert of current trasformation (sovrascrive quello di TMatrix)
    inline AffineMatrix<double> invert() const	{
	return math::Invert(static_cast<const math::TMatrix<T,2,3>&>(*this));
	}

  /**
    *  converte un punto immagine dell'immagine sorgente, in un punto immagine 
    *   dell'immagine destinazione (o viceversa, visto che spesso si usa per LookUp) 
    */
   math::Point2<T> operator() (const math::Point2<T> & in) const
    {
    return math::Point2<T>(
           this->M[0] * in.x + this->M[1] * in.y + this->M[2],
           this->M[3] * in.x + this->M[4] * in.y + this->M[5]
           );
    }

  /**
    *  converte un punto mondo 3d  in un punto mondo, non modificando la coordinata z
    * copre il 99% dei casi in cui la z non viene modificata
    */
   math::Point3<T> operator() (const math::Point3<T> & in) const
    {
    return math::Point3<T>(
           this->M[0] * in.x + this->M[1] * in.y + this->M[2], 
           this->M[3] * in.x + this->M[4] * in.y + this->M[5],
	   in.z
           );
    }

  /** trasforma con la trasformazione INVERSA una retta in una retta 
   * 
   * come per la trasformazione omografica, anche per l'affine e' piu' 
   *  rapido trasformare linee usando la trasformazione inversa (come se 
   *  fosse una LUT insomma).
   **/
   math::Line3<T> operator() (const math::Line3<T> & l) const
   {
    math::Line3<T> o;
    o.a = l.a * this->M[0] + l.b * this->M[3];
    o.b = l.a * this->M[1] + l.b * this->M[4];
    o.c = l.a * this->M[2] + l.b * this->M[5] + l.c;
    return o;
   }

};

/** operator*
 * \code
 * Point2d out = M * Point2d(x,y);
 * \endcode
 */
template<class T>
inline math::Point2<T> operator * (const AffineMatrix<T> & L, const math::Point2<T> R)
{
	return L(R);
}

/** return an identity affine matrix */
inline AffineMatrix<double> identity(void)  {
	AffineMatrix<double> M;
	math::Identity(M);
	return M;
}

/** Crea una matrice di ridimensionamento dell'immagine indicando il centro di riscalatura e il fattore di zoom
 * \code
 * m = at::scale(160,120,1.1,1.1);
 * \endcode
 * @param x,y coordinata immagine del centro di applicazione della trasformazione
 * @param scalex,scaley fattore di scala orizzontale e verticale
 * @see TImageAffineMappingFilter, resample
 **/
template<class T>
AffineMatrix<T> scale(T cx, T cy, T scalex, T scaley)
{
    AffineMatrix<T> m;
    m[0] = 1.0 / scalex;    m[1] = 0.0;    	   m[2] = cx * (1.0 - 1.0 / scalex);
    m[3] = 0.0;		    m[4] = 1.0 / scaley;   m[5] = cy * (1.0 - 1.0 / scaley);
    return m;
}

/** Crea una matrice di traslazione
 * @param tx,ty di quanti pixel spostare l'immagine
 * @note la trasformazione e' relativa a una trasformazione di LUT, percio' inversa
 * @see TImageAffineMappingFilter. Use Translate
 **/
template<class T>
inline AffineMatrix<T> translation(T tx, T ty) {
	return Translate(tx,ty);
}

/** Genera una matrice di rotazione 
 * @param [in] cx,cy coordinata immagine dove applicare il centro della rotazione (alto a sinistra dell'immagine)
 * @param [in] angle angolo (senso orario) di quanto ruotare l'immagine
 * @note Se si usa la matrice per una trasformazione di tipo LUT l'immagine viene ruotata in senso orario, se 
 *       si usa la matrice direttamente per trasferire i pixel dall'immagine sorgente a quella destinazione la
 *       rotazione sara' ovviamente antioraria.
 * @see TImageAffineMappingFilter
 **/
template<class T>
inline AffineMatrix<T> rotation(T cx, T cy, T angle)
{
  return math::Rotation(math::Point2<T>(cx,cy), angle);
}

template<class T>
inline AffineMatrix<T> rotation(const math::Point2<T> center, T angle)
{
  return math::Rotation(center, angle);
}

/** Crea una matrice di ridimensione per passare da una immagine w1 x h1 
 *   a w2 x h2
 **/
template<class T>
inline AffineMatrix<double> resample(T w1, T h1, T w2, T h2)
{
AffineMatrix<double> m;
 m[0] = (double)w1/(double)w2; m[1] =0.0; m[2]=0.0;
 m[3] = 0.0;                   m[4] = (double)h1/(double)h2; m[5]=0.0;
return m;  
}

/** crop the source image in @a rect and resample in dst_width,dst_height
  */
template<class T>
inline AffineMatrix<double> crop_and_resample(unsigned int dst_width, unsigned int dst_height, const math::Rect2<T> & rect)
{
AffineMatrix<double> m;
m[0] = (double) dst_width / (double)(rect.x1 - rect.x0); m[1] = 0.0; m[2] = - m[0] * rect.x0;
m[3] = 0.0; m[4] = (double) dst_height / (double) (rect.y1 - rect.y0); m[5] = - m[4] * rect.y0;
return m;
}

/** Crea una matrice per cambiare alpha e beta di un'immagine.
 *  @param [in] alphas,betas alpha e beta dell'immagine attuale (sorgente)
 *  @param [in] alphad,betad alpha e beta in cui si vuole trasformare l'immagine (destinazione)
 *  @param [in] cx,cy Optical Center of image
 *  @deprecated da rimuovere
 */
template<class T>
inline AffineMatrix<T> alphabeta(T alphas, T betas, 
                       T alphad, T betad,
                       T cx, T cy)
                       {
		      T scale_x = tan(alphas) / tan(alphad);
		      T scale_y = tan(betas) / tan(betad);
		      return scale( cx, cy, scale_x, scale_y);			 
		       }

};

#endif
