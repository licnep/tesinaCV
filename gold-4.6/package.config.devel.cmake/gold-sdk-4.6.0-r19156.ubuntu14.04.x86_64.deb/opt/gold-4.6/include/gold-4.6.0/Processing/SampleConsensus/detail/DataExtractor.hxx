#ifndef _DATAEXTRACTOR_HXX
#define _DATAEXTRACTOR_HXX

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file DataExtractor.hxx
 * @author Paolo Zani (zani@vislab.it)
 * @date 2012-03-16
 */

#include <cstddef>

namespace sample_consensus
{
    namespace detail
    {
        template<typename T>
        class DataExtractor
        {
            public:

                typedef typename T::value_type ValueType;

                DataExtractor(const T& samples) : m_samples(samples) {}

                inline const typename T::value_type& operator[](size_t i) const { return m_samples[i]; }

            private:

                const T& m_samples;
        };

        template<>
        class DataExtractor<void>
        {
            public:

                typedef size_t ValueType;

                inline size_t operator[](size_t i) const { return i; }
        };
    }
}

#endif
