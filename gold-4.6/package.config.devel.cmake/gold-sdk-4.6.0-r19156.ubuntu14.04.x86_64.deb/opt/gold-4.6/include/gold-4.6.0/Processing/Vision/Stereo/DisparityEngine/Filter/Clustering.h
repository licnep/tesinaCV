#ifndef CLUSTERING_H 
#define CLUSTERING_H 

#include <boost/thread/barrier.hpp>

void GapFilter(CDSI& dsi,  boost::barrier& barrier_, uint32_t m_dsiXMin, uint32_t m_dsiXMax,  uint32_t m_dsiYMin, uint32_t m_dsiYMax, uint32_t threadID, uint32_t threadNum )
{
    const float discon_threshold = 3.0;
    int32_t ipol_gap_width =3 ;
    uint32_t width = dsi.W();
    uint32_t height = dsi.H();

    uint32_t k0 = (height * threadID) / threadNum;
    uint32_t k1 = (height * (threadID + 1)) / threadNum;

    float* disp = (float*)  dsi.Buffer() + k0 * width;
    for(uint32_t i = k0; i < k1; i++)
    {
        int count = 0;
        for(int32_t j = 0; j < (int) width; j++, disp++)
        {
            float d = *disp;
            if(d != DISPARITY_UNKNOWN)
            {
                if(count >= 1 && count <= ipol_gap_width && j > count)
                {
                    float d1 = disp[-count - 1];
                    float dmean = (fabs(d1 - d) < discon_threshold) ? (d1 + d) / 2 : std::min(d1, d);
                    int index2 = 0;
                    for(int32_t u_curr = j - count; u_curr < j; u_curr++)
                    {
                        disp[--index2] = dmean;
                    }
                }
                count = 0;
            }
            else
            {
                count++;
            }
        }


    }


    barrier_.wait();

    disp = (float*)  dsi.Buffer();
    k0 = (width * threadID) / threadNum;
    k1 = (width * (threadID + 1)) / threadNum;
    for(uint32_t j = k0; j < k1; j++)
    {
        int count = 0;
        int stride = 0;
        for(int32_t i = 0; i < (int) height; i++, stride += width)
        {
            int index = stride + j;
            float d = disp[index];
            if(d != DISPARITY_UNKNOWN)
            {
                if(count >= 1 && count <= ipol_gap_width && i > count)
                {
                    float d1 = disp[index - (count + 1) * width];
                    float dmean = (fabs(d1 - d) < discon_threshold) ? (d1 + d) / 2 : std::min(d1, d);
                    int index2 = index - width;
                    for(int32_t u_curr = i - count; u_curr < i; u_curr++, index2 -= width)
                    {
                        disp[index2] = dmean;
                    }

                }
                count = 0;
            }
            else
            {
                count++;
            }
        }
    }
    
    barrier_.wait();

}


template<int Threads>
class CDespeckleFilter
{
     
    class Region
    {
        public:
            Region() {}
            Region( uint32_t* begin_, uint32_t*  end_) :  begin(begin_), end(end_), size(end_-begin_+1) {}
            void SetPoints(uint32_t* begin_, uint32_t*  end_)
            {
              begin = begin_;
              end = end_;
              size = end_-begin_+1;
            }

            uint32_t* begin;
            uint32_t*  end;
            uint32_t size;      
    };
    
    Region **lastRowRegions[Threads], **prevRowRegions[Threads];
    
    public:
    
    void operator()(CDSI& dsi,  boost::barrier& barrier_, uint32_t m_dsiXMin, uint32_t m_dsiXMax,  uint32_t m_dsiYMin, uint32_t m_dsiYMax,  float cluster_threshold, unsigned int min_cluster_size,  uint32_t threadID, uint32_t threadNum)
    {
        uint32_t m_width = dsi.W();
        Region *previousRow[m_width], *lastRow[m_width];
        prevRowRegions[threadID] = previousRow;
        lastRowRegions[threadID] = lastRow;
        std::fill(previousRow+m_dsiXMin , previousRow+m_dsiXMax, (Region*)0);
        std::fill(lastRow+m_dsiXMin, lastRow+m_dsiXMax,(Region*)0);
        float* disp = (float*) dsi.Buffer();
        int32_t k0 = ((m_dsiYMax - m_dsiYMin) * threadID) / threadNum + m_dsiYMin;
        int32_t k1 = ((m_dsiYMax - m_dsiYMin) * (threadID + 1)) / threadNum + m_dsiYMin;                        
        std::vector<uint32_t> segment; 
        std::vector<Region>  cluster;  
        segment.reserve(m_width * (k1-k0)); 
        cluster.reserve(m_width * (k1-k0));                            
        std::vector<uint8_t> temp(m_width * (k1-k0+2), 0);
        uint8_t * temp1 = &temp[0] + m_width - k0*m_width;
        std::fill(temp.begin()+m_dsiXMin, temp.begin()+m_dsiXMax, 1);
        temp[m_width-1]= 1;
        std::fill(temp.end()-m_width+m_dsiXMin, temp.end()-m_width+m_dsiXMax, 1);
        *(temp.end()-m_width)=1;

        int32_t index0 =  k0*m_width;
        int32_t index1 =  (k1-1)*m_width;
        for(int32_t i = k0; i < k1; i++)
            for(int32_t j = m_dsiXMin, index = i*m_width+m_dsiXMin; j < (int)m_dsiXMax; j++, index++)
            {                                    
                if(!temp1[index] && disp[index]!=DISPARITY_UNKNOWN)
                {
                    temp1[index] = 1;
                    segment.push_back(index);
                    cluster.push_back(Region());
                    uint32_t& start = segment.back();
                    for( std::vector<uint32_t>::const_iterator k = --segment.end(); k < segment.end(); ++k)
                    {
                        int32_t curr = *k;
                        float curr_disp = disp[curr];
                        
                        if(curr >= index1)
                            lastRow[curr - index1] = &cluster.back();
                        
                        int32_t neigh = curr - m_width;
                        if(neigh < index0 && std::abs(disp[neigh] - curr_disp) <= cluster_threshold)
                            previousRow[neigh - (index0 - m_width)] = &cluster.back();
                        
                        neigh = curr - 1;
                        if( !temp1[neigh] && std::abs(disp[neigh] - curr_disp) <= cluster_threshold)
                        {
                            segment.push_back(neigh);
                            temp1[neigh] = 1;
                        }

                        neigh = curr + 1;
                        if( !temp1[neigh] &&  std::abs(disp[neigh] - curr_disp) <= cluster_threshold)
                        {
                            segment.push_back(neigh);
                            temp1[neigh] = 1;
                        }

                        neigh = curr - m_width;
                        if( !temp1[neigh] &&  std::abs(disp[neigh] - curr_disp) <= cluster_threshold)
                        {
                            segment.push_back(neigh);
                            temp1[neigh] = 1;
                        }

                        neigh = curr + m_width;
                        if( !temp1[neigh] &&  std::abs(disp[neigh] - curr_disp) <= cluster_threshold)
                        {
                            segment.push_back(neigh);
                            temp1[neigh] = 1;
                        }

                    }
                    cluster.back().SetPoints(&start, &segment.back());

                }
            }
              
          barrier_.wait(); 
          
          if(!threadID)
          {
            std::vector<std::pair<Region*, Region* > > connections;
            
            for(uint32_t i=1; i< threadNum; ++i)
            {
              Region** last =  lastRowRegions[i-1];
              Region** prev =  prevRowRegions[i];
              for(uint32_t k=m_dsiXMin; k< m_dsiXMax; ++k)
              {
                  
                  if(last[k] && prev[k])
                  {  
                    uint32_t size = last[k]->size + prev[k]->size;
                    bool lastCond = last[k]->size >= min_cluster_size;
                    bool prevCond = prev[k]->size >= min_cluster_size;
                    bool totCond = size >= min_cluster_size;
                    if (!(lastCond && prevCond) )
                    {  
                      if (totCond)
                        last[k]->size = prev[k]->size = size;   
                      else
                        connections.push_back(std::make_pair(prev[k], last[k]));  
                    }
                  }
              }  
            }


              std::vector<Region*> group;
              int size = connections.size();
              while(size)
              {
                group.clear();
                group.push_back(connections.front().first);
                group.push_back(connections.front().second);
                int total_size = group[0]->size + group[1]->size;
                connections.front() = connections[--size];
            
                int size0 = size;
                do
                {  
                    size0 = size;
                    for(int i=0; i < size; i++)
                    {
                          bool first = find (group.begin(), group.end(), connections[i].first) !=  group.end();
                          bool second = find (group.begin(), group.end(), connections[i].second) !=  group.end();                                            
                          //first==true se  lo ha trovato
                          if(!first && second)
                          {  
                            group.push_back(connections[i].first);
                            total_size += connections[i].first->size;
                            connections[i] = connections[--size];
                          }else
                          if(!second && first)
                          {  
                            group.push_back(connections[i].second);
                            total_size += connections[i].second->size;
                            connections[i] = connections[--size];
                          } else
                          if(second && first)
                            connections[i] = connections[--size];
                          
                    }
                }while(size!=size0);
              
                for(uint32_t i=0; i < group.size(); i++)                             
                    group[i]->size = total_size;

          
            }  
          }     
          
          barrier_.wait();
              
          for(typename std::vector<Region>::const_iterator i = cluster.begin(); i < cluster.end(); ++i)
            if(i->size < min_cluster_size)
            {
                for(uint32_t* k = i->begin; k <= i->end; k++)
                {
                    disp[*k] = DISPARITY_UNKNOWN;
                }

            }
            
         barrier_.wait();    
    }
    
  
};



#endif