#ifndef _LMEDS_HXX
#define _LMEDS_HXX

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file LMedS.hxx
 * @author Paolo Zani (zani@vislab.it)
 * @date 2012-03-19
 */

#include <Processing/SampleConsensus/detail/RandomIndexGenerator.hxx>
#include <Processing/SampleConsensus/Consensus.h>

#include <boost/bind/bind.hpp>
#include <boost/thread/locks.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/thread/thread.hpp>

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <limits>
#include <vector>

namespace sample_consensus
{
    namespace detail
    {
        /**
         * Class implementing the least median of squares algorithm, first described in @cite LMedS84
         *
         **/
        class LMedS
        {
                template<typename Model, typename Estimator, typename Extractor>
                struct IterationParams;

            public:

                template<typename Model, typename Estimator, typename Extractor>
                ConsensusInfo operator()(Model& model, size_t min_sample, size_t max_sample, const Extractor& extractor, const Estimator& estimator, double& max_inliers_error, double a, unsigned int max_iterations, unsigned int threads_number)
                {
                    double best_error = std::numeric_limits<double>::max();
                    size_t best_inliers_num = 0;
                    const double log_1_a = log(1.0 - a);
                    unsigned int current_iteration = 0;
                    unsigned int skipped_iterations = 0;
                    unsigned int k = max_iterations;
                    bool use_sigma_threshold = max_inliers_error == std::numeric_limits<double>::infinity();

                    boost::thread_group thread_group;

                    IterationParams<Model, Estimator, Extractor> iter_params(min_sample, max_sample, max_inliers_error, use_sigma_threshold, estimator, max_iterations, log_1_a,
                                                                                        model, best_error, best_inliers_num, current_iteration, skipped_iterations, k, extractor);

                    for(unsigned int t = 0; t < threads_number; ++t)
                        thread_group.create_thread(boost::bind(&LMedS::Iterate<Model, Estimator, Extractor>, this, iter_params));

                    thread_group.join_all();

                    ConsensusInfo info;

                    info.m_model_cost = best_error;
                    info.m_inliers_number = best_inliers_num;
                    info.m_iterations = current_iteration;
                    info.m_skipped_iterations = skipped_iterations;

                    return info;
                }

            private:

                template<typename Model, typename Estimator, typename Extractor>
                struct IterationParams
                {
                    IterationParams(size_t min,
                                    size_t max,
                                    double& max_inliers_error,
                                    bool use_sigma_threshold,
                                    const Estimator& estimator,
                                    unsigned int max_iterations,
                                    double log_1_a,
                                    Model& best_model,
                                    double& best_error,
                                    size_t& best_inliers_num,
                                    double& best_threshold,
                                    unsigned int& current_iteration,
                                    unsigned int& skipped_iterations,
                                    unsigned int& k,
                                    const Extractor& extractor) :
                        m_min(min),
                        m_max(max),
                        m_max_inliers_error(max_inliers_error),
                        m_use_sigma_threshold(use_sigma_threshold),
                        m_estimator(estimator),
                        m_max_iterations(max_iterations),
                        m_log_1_a(log_1_a),
                        m_best_model(best_model),
                        m_best_error(best_error),
                        m_best_inliers_num(best_inliers_num),
                        m_current_iteration(current_iteration),
                        m_skipped_iterations(skipped_iterations),
                        m_k(k),
                        m_extractor(extractor)
                    {}

                    size_t m_min;
                    size_t m_max;
                    double& m_max_inliers_error;
                    bool m_use_sigma_threshold;
                    const Estimator m_estimator; //NOTE: we make a copy to guarantee thread safety
                    unsigned int m_max_iterations;
                    double m_log_1_a;
                    Model& m_best_model;
                    double& m_best_error;
                    size_t& m_best_inliers_num;
                    unsigned int& m_current_iteration;
                    unsigned int& m_skipped_iterations;
                    unsigned int& m_k;
                    const Extractor& m_extractor;
                };

                template<typename Model, typename Estimator, typename Extractor>
                void Iterate(IterationParams<Model, Estimator, Extractor>& params)
                {
                    size_t min = params.m_min;
                    size_t max = params.m_max;
                    double& max_inliers_error = params.m_max_inliers_error;
                    bool use_sigma_threshold = params.m_use_sigma_threshold;
                    const Estimator& estimator = params.m_estimator;
                    unsigned int max_iterations = params.m_max_iterations;
                    double log_1_a = params.m_log_1_a;
                    Model& best_model = params.m_best_model;
                    double& best_error = params.m_best_error;
                    size_t& best_inliers_num = params.m_best_inliers_num;
                    unsigned int& current_iteration = params.m_current_iteration;
                    unsigned int& skipped_iterations = params.m_skipped_iterations;
                    unsigned int& k = params.m_k;
                    const Extractor& extractor = params.m_extractor;

                    RandomIndexGenerator idx_gen(params.m_min, params.m_max);
                    size_t sample_size = estimator.SampleSize();
                    Model current_model;
                    std::vector<typename Extractor::ValueType> current_sample;
                    size_t current_inliers_num = 0;

                    // we cannot estimate k on the fly when also using auto inliers thresolding since the threshold is proportional to the error (high median error -> high uncertainity -> lots of inliers)
                    // and k is inversely proportional to the # of inliers, so we set the inlier ratio to 0.5 (the worst case still handled correctly by LMedS)
                    if(use_sigma_threshold)
                        k = log_1_a / log(std::min(1.0 - std::numeric_limits<double>::epsilon(),
                                                   std::max(std::numeric_limits<double>::epsilon(),
                                                            1.0 - pow(0.5, static_cast<double>(estimator.SampleSize())))));

                    current_sample.reserve(sample_size);

                    do
                    {
                        idx_gen.reset();
                        current_sample.clear();

                        for(size_t i = 0; i < sample_size; ++i)
                            current_sample.push_back(extractor[idx_gen()]);

                        if(estimator.Generate(current_model, current_sample))
                        {
                            std::vector<double> sorted_errors2;
                            std::vector<double> errors;

                            sorted_errors2.reserve(max - min);
                            errors.reserve(max - min);

                            for(size_t i = min; i <= max; ++i)
                            {
                                const double e = estimator.Evaluate(current_model, extractor[i]);
                                sorted_errors2.push_back(e * e);
                                errors.push_back(e);
                            }

                            std::nth_element(sorted_errors2.begin(), sorted_errors2.begin() + sorted_errors2.size() / 2, sorted_errors2.end()); // median
                            const double current_error2 = sorted_errors2[sorted_errors2.size() / 2];

                            bool compute_inliers = false;

                            {
                                boost::mutex::scoped_lock l(m_iterations_mtx);

                                compute_inliers = current_error2 < best_error;
                            }

                            double sigma, threshold;

                            if(compute_inliers)
                            {
                                current_sample.clear();
                                current_inliers_num = 0;

                                // automatic threshold estimation, see "Robust Regression Methods for Computer Vision: A Review"
                                if(use_sigma_threshold)
                                {
                                    sigma = 1.4826 * (1 + 5 / ((max - min + 1) - estimator.SampleSize())) * sqrt(current_error2);
                                    threshold = 2.5 * sigma;

                                    for(size_t i = 0; i < errors.size(); ++i)
                                        if(errors[i] < threshold)
                                            ++current_inliers_num;
                                }
                                else
                                {
                                    for(size_t i = 0; i < errors.size(); ++i)
                                        if(errors[i] < max_inliers_error)
                                            ++current_inliers_num;
                                }
                            }

                            boost::mutex::scoped_lock l(m_iterations_mtx);

                            if(current_error2 < best_error)
                            {
                                best_error = current_error2;
                                best_inliers_num = current_inliers_num;
                                std::swap(best_model, current_model);

                                if(use_sigma_threshold)
                                    max_inliers_error = threshold;
                                else
                                    k = log_1_a / log(std::min(1.0 - std::numeric_limits<double>::epsilon(),
                                                               std::max(std::numeric_limits<double>::epsilon(),
                                                                        1.0 - pow(static_cast<double>(current_inliers_num) / (max - min + 1), static_cast<double>(estimator.SampleSize())))));
                            }

                            ++current_iteration;

                            if(current_iteration > k || current_iteration > max_iterations)
                                break;
                        }
                        else
                        {
                            boost::mutex::scoped_lock l(m_iterations_mtx);

                            ++skipped_iterations;

                            if(skipped_iterations > max_iterations) // to avoid getting stuck if a valid model cannot be generated
                                break;
                        }
                    } while(1);

                    best_error = sqrt(best_error);
                }

                boost::mutex m_iterations_mtx;
        };
    }
}

#endif
