#ifndef _PRELIMINARYTEST_HXX
#define _PRELIMINARYTEST_HXX

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file PreliminaryTest.hxx
 * @author Paolo Zani (zani@vislab.it)
 * @date 2012-03-23
 */


#include <Processing/SampleConsensus/detail/RandomIndexGenerator.hxx>

#include <cstddef>

namespace sample_consensus
{
    namespace detail
    {
        class TddTest
        {
            public:

                TddTest(size_t d) : m_d(d) {}

                template<typename Model, typename Estimator, typename Extractor>
                inline bool operator()(const Model& model, const Estimator& estimator, RandomIndexGenerator& idx_gen, const Extractor& extractor, double max_inliers_error) const
                {
                    for(size_t i = 0; i < m_d; ++i)
                        if(estimator.Evaluate(model, extractor[idx_gen()]) > max_inliers_error)
                            return false;

                    return true;
                }

            private:

                size_t m_d;
        };

        class NullTest
        {
            public:

                template<typename Model, typename Estimator, typename Extractor>
                inline bool operator()(const Model& model, const Estimator& estimator, RandomIndexGenerator& idx_gen, const Extractor& extractor, double max_inliers_error) const
                {
                    return true;
                }
        };
    }
}

#endif
