#ifndef _PM_PROBE_H
#define _PM_PROBE_H

/** @file PmProbe.h
  * @brief Widget per l'IPM
  * PMProbeWidget per esempio.
  * @author Paolo Medici
  **/

#include <string>

#include <UI/CWindows/CWindowTypes.h>
#include <UI/CWindows/CWidget.h>
#include <Processing/Vision/PerspectiveMapping/ipm.h>
#include <Data/Math/Points.h>
#include <Data/Math/Rects.h>

#include <Processing/Vision/PerspectiveMapping/gold_proc_pm_widget_export.h>

// fwd
class CWindowCore;

namespace ui {
namespace win {


/// Un Widget che scrive su schermo dove e' il mouse la coordinata mondo Z=0 corrispondente.
/// \code
///  win->SetLayer(1);
///  win->SetColor(0,0,255);
///  win->Push(SPDrawingObject(new PMProbeWidget(Rect2f(0,0,ImgWidth,ImgHeight), dev::CameraParams)) );
///  win->SetLayer(0);
/// \endcode
/// @note da testare!
class GOLD_PROC_PM_WIDGET_EXPORT PMProbeWidget : public CWidget
{
    public:
    // alcuni typedef (Traits) per essere indipendenti dal tipo di dati usato internamente
    typedef math::Rect2f Rect;
    private:
    InversePerspectiveMapping ipm;
    /// area del widget
    Rect m_area;
    /// Punto su cui disegnare il testo
    math::Point2f m_pt;
    /// Origine Linea *immagine*
    math::Point2f m_line;
    /// Origine Line *mondo*
    math::Point3f m_line_w;
    /// Testo (X: Y:)
    std::string m_str;
    /// scostamento rispetto al punto del mouse dove compare il testo
    float m_dx,m_dy;
    /// non disegna nulla ma imposta il CustomMessage
    bool m_quiet;
    /// Track
    bool m_track;
    /// Prende il controllo dell'area
    bool m_owner;
    /// sotto l'orizzonte?
    bool m_valid;
    public:
        /// ctor:
        /// @param area rettangolo che contiene l'area da mappare
        /// @param cp i dev::CameraParams dell'immagine
        /// @param dx,dy scostamento dal cursore del testo disegnato
        /// @param quiet se quiet mostra il contenuto nella status bar usanto SetCustomStatusBar
        PMProbeWidget(const Rect & area, const dev::CameraParams & cp, float dx=0.0f, float dy=0.0f, bool quiet=false);
        /// ctor:
        /// @param cp i dev::CameraParams dell'immagine
        /// @param dx,dy scostamento dal cursore del testo disegnato
        /// @param quiet se quiet mostra il contenuto nella status bar usanto SetCustomStatusBar
        PMProbeWidget(const dev::CameraParams & cp, float dx=0.0f, float dy=0.0f, bool quiet=false);
        ~PMProbeWidget();
        const char* getName() const;
        bool Interact(CWindowCoreManager* pWindow, const CWindowEvent& event);
        int Draw(CWindowCore* pWindow);
};

}
}

#endif
