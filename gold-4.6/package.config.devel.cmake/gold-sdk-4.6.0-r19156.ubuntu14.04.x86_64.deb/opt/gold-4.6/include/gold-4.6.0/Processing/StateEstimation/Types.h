#ifndef _KALMAN_TYPES_H
#define _KALMAN_TYPES_H

/** @file
 * @brief Kalman Traits Type
 * */

namespace state_estimation {
  
struct LinearizedImplementation { };
struct UnscentedImplementation { };
  
}

#endif
