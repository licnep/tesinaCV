/** @file LineMath.h
  * @author Paolo Medici
  * @brief funzioni matematiche tra linee e punti
  **/
#ifndef _LINE_MATH_H
#define _LINE_MATH_H

#include <stdexcept>
#include <Data/Math/Points.h>
#include <Data/Math/Lines.h>
#include <Data/Math/Rects.h>
#include <Processing/Math/gold_proc_math_export.h>

namespace math
{


/** Ritorna la distanza punto retta
 *  @param l a line
 *  @param p a point
 *  @return the distance between the line and the point
 **/
template<class T>
inline T point_line_distance(const Line3<T> & l, const Point2<T> & p)
{
    return std::abs( l.a * p.x + l.b * p.y + l.c ) / sqrt( l.a * l.a + l.b * l.b);
}

/** Ritorna la proiezione di un punto su una retta
 *  @return the point on the lane perpendicular to point @a p
 **/
template<class T>
inline Point2<T> point_on_line_near(const Line3<T> & l, const Point2<T> & p)
{
    T d = T(1) / ( l.a * l.a + l.b * l.b);
    return Point2<T> ( (l.b * l.b * p.x - l.a * l.b * p.y - l.c * l.a) * d,
                       (l.a * l.a * p.y - l.a * l.b * p.x - l.c * l.b) * d  );
}

/// clip the line3d @a in inside plane @a plane
/// @param in the input line3d
/// @param out an array of 2 point2d
/// @param plane a rectangular box
/// @return true or false depending on line is contained or not inside box.
template<typename T>
GOLD_PROC_MATH_EXPORT bool clip_line3(const Line3<T> & in, Point2<T> *out, const Rect2<T> & plane);

/** converte una Line3d in due punti tra i quali e' possibile tracciare una linea
  * @param in una struttura Line3d
  * @param out un array di 2 Point2d che verranno impostati
  * @param width,height l'area su cui eseguire il cropping
  * @return TRUE (1) se la retta e' all'interno dell'immagine, altrimenti FALSE (0)
  **/
inline int line3d_to_screen(const Line3d *in, Point2d *out, unsigned int width, unsigned int height)
{
   return clip_line3<double>(*in, out, Rect2d(0.0,0.0,width,height));
}   

/** return the angle between lines
 *  @param x,y two lines
 *  @return angle in radians
  **/
template<class T>
inline T angle_between_lines(const Line3<T> & x, const Line3<T> & y)
{
    return acos( (x.a * y.a + x.b * y.b) /
                 sqrt( (x.a * x.a + x.b * x.b) * (y.a * y.a + y.b * y.b) )
               );
}

/** ritorna il punto di intersezione tra due linee */
template<class T>
inline Point2<T> line_intersection(const Line3<T> &x, const Line3<T> &y)
{
    T det = x.a * y.b - x.b * y.a;
    if (det!=0.0)
    {
        return Point2<T>( (-x.c * y.b + y.c * x.b) / det, (-x.a * y.c + x.c * y.a) / det);
    }
    else
        throw std::runtime_error("No intersection");
}

} // namespace math

#endif
