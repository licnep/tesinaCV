/** \file HomographicTransformation.h
  * \brief home file for class HomographicMatrix
  * \author Paolo Medici \<medici@vislab.it\>
  **/

#ifndef _HOMOGRAPHIC_MATRIX_H
#define _HOMOGRAPHIC_MATRIX_H

#include <vector>
#include <Processing/Vision/PerspectiveMapping/gold_proc_pm_export.h>

#include <Data/Math/TMatrices.h>
#include <Data/Math/Points.h>
#include <Data/Math/Lines.h>


/// Homographic trasformation namespace
namespace ht {

/** La matrice base per le trasformazioni omografiche
  * \code
  * ht::Matrix_t M;
  * \endcode
  * @note usare piuttosto HomographicMatrix che fornisce metodo apposta per le operazioni omografiche
  **/
typedef math::TMatrix<double,3,3>  Matrix_t;

/** La classe HomographicMatrix estende le matrici 3x3 alle trasformazioni omografiche
 *
 * Una trasformazione omografica e' una qualunque trasformazione geometrica esprimibile come:
 *  \f$
 * \begin{array}{l}
 * u' = \frac{m_0 * u + m_1 * v + m_2}{m_6 * u + m_7 * v + m_8} \\
 * v' = \frac{m_3 * u + m_4 * v + m_5}{m_6 * u + m_7 * v + m_8}
 * \end{array}
 * \f$ 
 * dove \f$ (u,v) \f$ sono le coordinate del pixel di un immagine ingresso|destinazione e 
 * \f$ (u',v') \f$ coordinate del pixel in un immagine uscita|sorgente. 
 * E' da notare che le trasformazioni omografiche sono definite a meno di un fattore moltplicativo. E' definito il metodo
 *  HomographicMatrix::Normalize per normalizzare la matrice.
 *
 *   Le prestazioni sono per pixel: 6 moltiplicazioni, 6 somme e 2 divisioni se si usa la chiamata l'operator(), 
 *    e solo 2 divisioni e 3 somme per pixel se si usa l'applicatore a una immagine.
 *
 *  @todo Avere una equazione scritta in forma chiusa permette di calcolare, linea per linea, i limiti del sistema e permette di
 *    rimuovere i confronti per pixel per calcolare se il pixel si trova, o meno, all'interno dell'immagine.
 *
 * \code
 * HomographicMatrix M;
 * \endcode
 * \code
 * double matrix[9] = { ... };
 * HomographicMatrix M( matrix );
 * \endcode
 **/
class GOLD_PROC_PM_EXPORT HomographicMatrix: public Matrix_t {

public:
  HomographicMatrix() {}
  HomographicMatrix(const Matrix_t & m) : Matrix_t(m) { }

  /**  Crea la matrice componendo due trasformazioni.
   * (U V 1) = a (W Z 1) 
   * (W Z 1) = b (X Y 1) 
   * M = a * b;
   * (U V 1) = M (X Y 1)
   **/
  HomographicMatrix(const Matrix_t & a, const Matrix_t & b);
    
  /// inizializza la matrice con un array di 9 elementi (float o double)
  template<class R>
  explicit HomographicMatrix(const R *m) : Matrix_t(m) { }

  // cast per comoodita'
   inline const Matrix_t & Matrix() const { return static_cast<const Matrix_t&>(*this); }
   inline Matrix_t & Matrix() { return static_cast<Matrix_t&>(*this); }

  /** imposta la matrice identita' cancellando la matrice corrente
    * \code
    * M.Identity();
    * \endcode
    */
   void Identity();
   
   /** Riscala i coefficienti per fare in modo che la trasformazione sia normalizzata
    * @param m8 normalizza forzando il termine m[8]=1 invece di |H|=1 (e' una normalizzazione meno stabile)
    *
    * La matrice in effetti e' sovra dimensionata, in quanto bastano, in genere, i soli  
    *  8 parametri (m_0..m_7). tuttavia alcune trasformazioni hanno m[8]=0
    * @return true se m[8]!=0 altrimenti false
    *
    * \code
    * M.Normalize();
    * \endcode
    **/
   bool Normalize(bool m8=false);

////////////////////// Invert /////////////////////////////////////////////

   /** ritorna la matrice omografica che inverte la trasformazione (deprecata)
     * 
     * \code
     * HomographicMatrix inv;
     * M.Invert(inv);
     * \endcode
     **/
   void Invert(Matrix_t &inverted) const;

   /** ritorna la matrice omografica che inverte la trasformazione
     * \code
     * HomographicMatrix inv = M.Invert();
     * \endcode
     **/
   Matrix_t Invert(void) const;

////////////////////////// Processing Points //////////////////////////////

   /** Return the singualarity (input) line where transformation is not defined (for example horizon in PM)
    */
   inline math::Line3d Singularity() const {
	return math::Line3d(M[6], M[7], M[8]);
	}
   
   /** @name funzioni di proiezione
    *  converte un punto immagine dell'immagine sorgente, in un punto immagine 
    *   dell'immagine destinazione (o viceversa, visto che spesso si usa per LookUp dense) 
    * 
    *  @note Bisogna tenere conto che le funzioni sono
    *   progettate per essere usate come LookUpTable dense, e percio' forniscono 
    *   trasformazione opposta a quella indicata dal nome della funzione generatrice
    **/
   /*@{*/

   /** esegue una proiezione inversa di rette: trasforma rette dallo spazio sinistro allo spazio destro
    * 
    * Per costruzione della matrice omografa non e' cosi' banale la trasformazione diretta
    *  di rette in rette, ma invece e' banale la trasformazione inversa.
    **/
   template<class T>
   math::Line3<T> operator() (const math::Line3<T> & l) const
   {
    math::Line3<T> o;
    o.a = l.a * M[0] + l.b * M[3] + l.c * M[6];
    o.b = l.a * M[1] + l.b * M[4] + l.c * M[7];
    o.c = l.a * M[2] + l.b * M[5] + l.c * M[8];
    return o;
   }
   

   /** applica la trasformazione al punto @a in
     * \code
     * Point2d out = hm(in);
     * \endcode
     * @note se la matrice e' generata per una LUT questo metodo fornisce il pixel nell'immagine
     *       sorgente dato un punto dell'immagine destinazione
     * @note meglio che T sia double o float. non usare interi
     **/
   template<class T>
   math::Point2<T> operator() (const math::Point2<T> & in) const
    {
    T x, y, w;
    x = M[0] * in.x + M[1] * in.y + M[2];
    y = M[3] * in.x + M[4] * in.y + M[5];
    w = M[6] * in.x + M[7] * in.y + M[8];
    return math::Point2<T>(x/w, y/w);
    }

   /** applica la trasformazione al punto in coordinate omogenee @a in */
   template<class T>
   math::Point2<T> operator() (const math::Point3<T> & in) const
    {
    T x, y, w;
    x = M[0] * in.x + M[1] * in.y + M[2] * in.z;
    y = M[3] * in.x + M[4] * in.y + M[5] * in.z;
    w = M[6] * in.x + M[7] * in.y + M[8] * in.z;
    return math::Point2<T>(x/w, y/w);
    }
  /*@}*/
   

/////////////////////////// Evaluate ///////////////////////////////////////

/** @name evaluate method used to evalute projection */
/*@{*/
   /** return the remapping error (euclidean distance) 
     * @return the distance | H(first) - second |
     */
   double Evaluate(const std::pair<math::Point2d,math::Point2d> & pt) const;

   /** return the sum of remapping errors on a vector of pair of points */
   double Evaluate(const std::vector< std::pair<math::Point2d,math::Point2d> > & couples) const;
/*@}*/

/////////////////////////////////////////////// advance /////////////////////////////////////
   
   /** Trasforma con una traslazione le coordinate a sinistra
     */
   void MoveInPoint(double dx, double dy);
   
   /** sposta le coordinate a destra
    *
    * \f$ (u_0,v_0) \rightarrow (u_1,v_1) \f$
    */
   void MoveOutPoint(double dx, double dy);
   
   /** scala i pixel in ingresso 
    * 
    * \f$ M_1 = M_0 *
    *    \left[ 
    *    \begin{array}{ccc}
    *    f_x & 0 & 0 \\
    *    0 & f_y & 0 \\ 
    *    0 & 0 & 1 \\
    *    \end{array} 
    *    \right]
    * \f$
    **/
   void ScaleIn(double fx, double fy);
   
   /** scala i pixel in uscita
    *
    * \f$ M_1 = 
    *    \left[ 
    *    \begin{array}{ccc}
    *    f_x & 0 & 0 \\
    *    0 & f_y & 0 \\ 
    *    0 & 0 & 1 \\
    *    \end{array} 
    *    \right]
    *    * M_0
    * \f$
    **/
   void ScaleOut(double fx, double fy);
   
   /** Applica una matrice di condizionamento sull'"uscita"
    *  Moltiplica la matrice omografica a sinistra
    * \f$ M_1 = R * M_0 \f$
    **/
   void LeftMult(const Matrix_t & R);
   
   /** Applica una matrice di condizionamento sull'"ingresso"
    *  Moltiplica la matrice omografica a destra
    * \f$ M_1 = M_0 * R \f$
    **/
   void RightMult(const Matrix_t & R);

};

}

#endif
