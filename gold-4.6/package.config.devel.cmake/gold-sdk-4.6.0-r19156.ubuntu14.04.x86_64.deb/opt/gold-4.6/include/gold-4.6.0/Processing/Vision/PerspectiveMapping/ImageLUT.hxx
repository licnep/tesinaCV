// The template and inlines for the -*- C++ -*- internal ImageLUT helper class.

/** @file ImageLUT.hxx
 *  This is an internal header file, included by other library headers.
 *  You should not attempt to use it directly.
 */

// Written by Paolo Medici <medici@ce.unipr.it>

#ifndef _IMAGELUT_HXX
#define _IMAGELUT_HXX

#include <boost/current_function.hpp>
#include <boost/thread.hpp>
#include "LutPixel.hxx"
#include <Libs/Logger/Log.h>


template<typename T,typename R>
void TImageLUT<T,R>::SetPixel(unsigned int xd, unsigned int yd, double xs, double ys)
    {
    m_lut[xd + yd * R::width].set(xs,ys, R::srcWidth, R::srcHeight);
    R::SetPixel(xd, yd, xs, ys);
    }

// applica la LUT da srcImage a dstImage nella regione x0,y0,x1,y1
// definita la width della immagine sorgente e la width della immagine destinazione
template<typename T, typename R>
template<unsigned int bytePerPixel, typename C>
void  TImageLUT<T,R>::_internal_apply(C * dstImage, const C * srcImage, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1)
{
  T  *lutPos, *lut;
  unsigned int i,j;
  C *dst;
  unsigned long spitch, dpitch;

  dpitch = R::width * bytePerPixel;
  spitch = R::srcWidth * bytePerPixel;
  lutPos = m_lut + y0 * R::width + x0 ; // lutPos punta alla prima lut della riga
  dstImage += (x0 + y0 * R::width) * bytePerPixel;
  
  for(j = y0; j <= y1; j++)
    {
    dst = dstImage;
    for(i= x0, lut = lutPos; i <= x1; i++, lut++) 
        {
         if (lut->IsDefined())
            dst = (*lut).template apply<bytePerPixel>(dst,srcImage,spitch);
         else
            {
            unsigned char c;
            c = bytePerPixel;
            do { 
            *dst++=IPM_UNDEFINED_COLOR_VALUE;
                } while(--c);
            }
        }
    lutPos += R::width;
    dstImage += dpitch;
    }

}

template<typename T, typename R>
template<unsigned int bytePerPixel, typename C>
void TImageLUT<T,R>::_internal_apply_mcore(C* dstImage, const C* srcImage, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1)
{
   if(this->m_nThreads==1)
	TImageLUT<T,R>::template _internal_apply<bytePerPixel,C>(dstImage, srcImage, x0, y0, x1, y1);
   else
   {
   boost::thread_group thread_pool_;
   int active = y1 - y0;
//    std::cout << "spawn " << this->m_nThreads << " threads\n";
   // limito il nThread se l'immagine e' troppo piccola
    for(int32_t k = 0; k < this->m_nThreads; k++)
		{
		uint32_t k0 = y0 + ((active * k) / this->m_nThreads);	    // prima riga da assegnare a questo core
		uint32_t k1 = y0 + ((active * (k+1) ) / this->m_nThreads); // ultima riga (non compresa) da assegnare a questo core

		thread_pool_.create_thread(
			boost::bind(&TImageLUT<T,R>::template _internal_apply<bytePerPixel,C>, this,
					dstImage, srcImage, x0, k0, x1, k1));
		}
   thread_pool_.join_all();
   }
}

template <typename T, typename R>
void TImageLUT<T,R>::ApplyToImage(unsigned char * dstImage, const unsigned char * srcImage, unsigned int bpp, const math::Rect2i *area)
{
  unsigned int x0,y0,x1,y1;

  if ((!dstImage) || (!srcImage))
    throw std::runtime_error(std::string(BOOST_CURRENT_FUNCTION) + ": Source and destination buffers must be allocated");

  if(area)
   {
   x0 = (area->x0<0) ? 0 : area->x0;
   y0 = (area->y0<0) ? 0 : area->y0;
   x1 = (area->x1+1 > (int) R::width)  ? (R::width  - 1) : area->x1;
   y1 = (area->y1+1 > (int)R::height) ? (R::height - 1) : area->y1;
   }
   else
   {
   x0 = y0 = 0;
   x1 = R::width - 1;
   y1 = R::height - 1; // i Bordi sono compresi
   }

   if(bpp == 1)
  	_internal_apply_mcore<1>(dstImage,srcImage,x0,y0,x1,y1);
   else
     if(bpp == 2)
       _internal_apply_mcore<1>((unsigned short *)dstImage,(const unsigned short *)srcImage,x0,y0,x1,y1);
   else
   if(bpp == 3)
  	_internal_apply_mcore<3>(dstImage,srcImage,x0,y0,x1,y1);
  else
	{
        log_error << "bpp: " << bpp << std::endl;
  	throw std::runtime_error("Apply: Unimplemented ColorSpace");
        }
}

#endif
