#ifndef _AVERAGE_FILTER_HXX
#define _AVERAGE_FILTER_HXX

///////////////////////////////// Usati internamente da Average e AverageBin //////////////////////////////////

namespace filter {
  
/** @brief calcola la somma dei pixel su una singola riga 
 *  somma una linea orizzontale
 *  @param ptr un puntatore al pixel dell'immagine da cui comincia la linea
 *  @param width numero di pixel che dovranno essere sommati
 *  @return il valore della somma dei pixel
 **/
template<class T>
unsigned long SumHorLine (const T * ptr, unsigned int width)
{
    unsigned long sum = 0;
    for(unsigned int i =0;i<width;i++)
        sum += ptr[i];
    return sum;
}

/// Calcola la media su una linea orizzontale
template<class T>
float AvgHorLine (const T * ptr, unsigned int width)
{
    return float( SumHorLine(ptr,width) ) / float ( width ) ;
}

/** @brief calcola la somma dei pixel su un blocco
 * Somma l'area all'interno di un rettangolo con vertice superiore in @a ptr 
 * @param ptr puntatore al pixel dell'immagine da cui comincia il blocco
 * @param pitch larghezza dell'immagine (la width)
 * @param blockw,blockh dimensione del blocco
 * @return il valore della somma dei pixel
 **/
template<class T>  
unsigned long SumArea (const T * ptr, long pitch, unsigned int blockw, unsigned int blockh)
{
  unsigned long sum = 0;
  for(unsigned int j=0;j<blockh;j++)
  {
    for(unsigned int i=0;i<blockw;i++)
      sum += ptr[i];
   ptr+=pitch;
  }
  return sum;
}

// funzione usata internamente da ll_grey_lowpass_threshold
template<class T>
unsigned long SumAreaNext(const T * ptr, unsigned int pitch, unsigned int blockw, unsigned int blockh, unsigned long old)
{
  int j = blockh;
  ptr --; // arretro di 1
  
  do  {
   old += ptr[blockw];
   old -= ptr[0];
     ptr+=pitch;
  } while(--j);
  return old;
}

// funzione usata internamente da ll_grey_lowpass_threshold
template<class T>
unsigned long SumAreaVNext(const T * ptr, unsigned int pitch, unsigned int blockw, unsigned int blockh, unsigned long old)
{
  for(unsigned int i = 0; i < blockw; i++)
        old -= ptr[i];

  ptr += blockh * pitch;  

  for(unsigned int i = 0; i < blockw; i++)
        old += ptr[i];

  return old;
}




/// @brief Calcola il valore della varianza di una sottoparte dell'immagine
/// Calcola la varianza all'interno di un area, pixel in alto a sinistra in @a ptr
/// @param ptr puntatore al primo pixel da cui comincia il blocco
/// @param pitch numero di pixel per passare alla linea successiva
/// @param blockw numero di pixel orizzontali
/// @param blockh numero di pixel verticali
template<class T>
float VarArea (const T * ptr, long pitch, unsigned int blockw, unsigned int blockh)
{
  unsigned long sum = 0;
  unsigned long sum2 = 0;
  unsigned long size = blockw * blockh;
  for(unsigned int j=0;j<blockh;j++)
  {
    for(unsigned int i=0;i<blockw;i++)
      sum += ptr[i], sum2 += ptr[i] * ptr[i];
   ptr+=pitch;
  }
  float avg = float(sum) / float(size);
  return (float(sum2) / float(size)) - avg*avg;

}


}

//////////////////////////////////////////// IPP //////////////////////////////////////////////

#ifdef ENABLE_IPP
#include <boost/mpl/vector.hpp>
#include <boost/mpl/contains.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/utility/enable_if.hpp>
#include <ippi.h>
#include <ipps.h>


namespace  ipp
{            
    inline void ippiFilterBox(const uint8_t* s, int source_stride, uint8_t* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterBox_8u_C1R(s, source_stride, d, dest_stride, dstRoiSize, maskSize, anchor);
    }
    
    inline   void ippiFilterBox(const int16_t* s, int source_stride, int16_t* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
       ippiFilterBox_16s_C1R(s, source_stride, d, dest_stride, dstRoiSize, maskSize, anchor);
    }
    
    inline void ippiFilterBox(const uint16_t* s, int source_stride, uint16_t* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterBox_16u_C1R(s, source_stride, d, dest_stride, dstRoiSize, maskSize, anchor);
    }
    
    inline void ippiFilterBox(const RGB8* s, int source_stride, RGB8* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterBox_8u_C3R((uint8_t*)s, source_stride, (uint8_t*)d, dest_stride, dstRoiSize, maskSize, anchor);
    }
    
    inline void ippiFilterBox(const float* s, int source_stride, float* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterBox_32f_C1R(s, source_stride, d, dest_stride, dstRoiSize, maskSize, anchor);
    }

    ///TODO: aggiungere in place functions  
    template <class S, class D>
    struct AverageFilterIppSupportCheck :
            boost::mpl::and_<
            boost::mpl::bool_<boost::is_same<S, D>::value>,
            boost::mpl::contains<  boost::mpl::vector< uint8_t, int16_t, uint16_t, RGB8, float > , S> > {};
           
    template<class T, class S, class D>
    struct implementation<kernel::AverageFilter<T>, S, D,  typename boost::enable_if< AverageFilterIppSupportCheck<S, D> >::type >
    {
        static inline int run(const kernel::AverageFilter<T>& f, const S* input, D* output, uint32_t width, uint32_t height, long source_stride)
        {             
            IppiSize  roi = {width - f.GetWidth() + 1, height - f.GetHeight() + 1}, mask = {f.GetWidth(), f.GetHeight()};
            IppiPoint anchor = { f.GetWidth() / 2, f.GetHeight()/ 2};
            int source_offset = source_stride * (f.GetHeight()/ 2) + f.GetWidth() / 2;
            int output_offset = width * (f.GetHeight()/ 2) + f.GetWidth() / 2;
            ippiFilterBox(input + source_offset, source_stride * sizeof(*input) , output + output_offset, width *  sizeof(*output), roi, mask, anchor);
            FillBorders(output, width, height, f.GetWidth(), f.GetHeight());
            return 1;
                 
        }
    };
  
    
    template<class T>
    struct implementation<kernel::BilateralFilter<T>, uint8_t, uint8_t >
    {
        static inline int run(const kernel::BilateralFilter<T>& f, const uint8_t* input, uint8_t* output, uint32_t width, uint32_t height, long source_stride)
        {             
            IppiSize  roi = {width - f.GetWidth() + 1, height - f.GetHeight() + 1}, mask = {f.GetWidth(), f.GetHeight()};
            IppiPoint anchor = { f.GetWidth() / 2, f.GetHeight()/ 2};
            int source_offset = source_stride * (f.GetHeight()/ 2) + f.GetWidth() / 2;
            int output_offset = width * (f.GetHeight()/ 2) + f.GetWidth() / 2;
            int bufsize;
            ippiFilterBilateralGetBufSize_8u_C1R( ippiFilterBilateralGauss, roi, mask, &bufsize);  ///valutare la memorizzazione
            IppiFilterBilateralSpec* pSpec = (IppiFilterBilateralSpec *)ippsMalloc_8u( bufsize );
            ippiFilterBilateralInit_8u_C1R( ippiFilterBilateralGauss, mask, f.GetSigmaVal(), f.GetSigmaPos(), f.GetKernelStep(), pSpec );
            ippiFilterBilateral_8u_C1R(input + source_offset, source_stride * sizeof(*input) , output + output_offset, width *  sizeof(*output), roi, mask, pSpec);
            ippsFree( pSpec );
            FillBorders(output, width, height, f.GetWidth(), f.GetHeight());
            return 1;
                 
        }
    };
 
}
   

#endif

#endif