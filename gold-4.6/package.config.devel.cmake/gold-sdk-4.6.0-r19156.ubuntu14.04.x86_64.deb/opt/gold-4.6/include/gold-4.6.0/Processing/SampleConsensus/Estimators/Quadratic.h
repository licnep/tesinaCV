#ifndef _SAC_EST_QUADRATIC_H
#define _SAC_EST_QUADRATIC_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * \file Quadratic.h
 * \author Paolo Zani (zani@vislab.it)
 * \date 2012-03-29
 */

#include <Data/Math/Points.h>
#include <Data/Math/Quadratics.h>
#include <Processing/Math/Regression.h>
#include <Processing/SampleConsensus/detail/EstimatorTraits.hxx>

#include <cmath>
#include <cstddef>

namespace sample_consensus
{
    namespace estimators
    {
        /**
         * @brief 2D parabola estimation class
         **/
        class Quadratic
        {
            public:

                /**
                 * @brief Constructor
                 * @note Optimization is performed only by the Local Optimization (LO-*) class of algorithms.
                 * @param optimization_inliers_fraction The fraction of inliers used during the optimization step, in the range [0, 1]. Defaults to 0.5
                 **/
                Quadratic(double optimization_inliers_fraction = 0.5) : m_optimization_inliers_fraction(optimization_inliers_fraction) {}

                /**
                 * @brief The number of 2D points needed to generate a 2D parabola.
                 * @return size_t Sample size.
                 **/
                size_t SampleSize() const { return 3; }

                /**
                 * @brief Generate a 2D parabola from the given 2D points.
                 *
                 * @param [out] model The generated parabola.
                 * @param [in] sample an STL-like container of points.
                 * @return bool true if no error occurred, false otherwise.
                 **/
                template<typename T, template<typename, typename> class Container, class Allocator>
                bool Generate(math::Quadratic<T>& model, const Container<math::Point2<T>, Allocator>& sample) const
                {
                    math::Quadratic<T> q;
                    q.set_quadratic(sample[0].x, sample[0].y, sample[1].x, sample[1].y, sample[2].x, sample[2].y);
                    model = q;

                    return true;
                }

                /**
                 * @brief The size of the sample used during the optimization step.
                 * @note This is required only by the Local Optimization (LO-*) class of algorithms.
                 * @return size_t Sample size.
                 **/
                size_t OptimizationSampleSize(size_t inliers_size) const { return std::max(m_optimization_inliers_fraction * inliers_size, static_cast<double>(SampleSize())); }

                /**
                 * @brief Generate a refined 2D parabola from the given 2D points.
                 * @note A vertical least squares fitting strategy is used.
                 * @note This is required only by the Local Optimization (LO-*) class of algorithms.
                 *
                 * @param [in,out] model The generated parabola.
                 * @param [in] sample an STL-like container of points.
                 * @return bool true if no error occurred, false otherwise;
                 **/
                template<typename T, template<typename, typename> class Container, class Allocator>
                bool Optimize(math::Quadratic<T>& model, const Container<math::Point2<T>, Allocator>& sample) const
                {
                    return math::vertical_least_squares_fitting(&model, &sample[0], sample.size());
                }

                /**
                 * @brief Check whether a 2D point is close to the given 2D parabola.
                 *
                 * @param [in] model A 2D parabola.
                 * @param [in] datum A 2D point.
                 * @return double The vertical distance of the point from the parabola.
                 **/
                template<typename T>
                double Evaluate(const math::Quadratic<T>& model, const math::Point2<T>& datum) const
                {
                    return std::abs(model(datum.x) - datum.y);
                }

            private:

                double m_optimization_inliers_fraction;
        };
    }

    namespace detail
    {
        template<>
        template<typename T>
        struct EstimatorTraits<math::Quadratic<T> >
        {
            typedef estimators::Quadratic EstimatorType;
        };
    }
}

#endif
