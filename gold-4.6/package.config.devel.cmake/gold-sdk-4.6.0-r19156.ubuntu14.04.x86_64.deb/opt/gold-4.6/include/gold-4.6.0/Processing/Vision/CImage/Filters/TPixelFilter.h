#ifndef _TPIXEL_LUT_FILTER_H
#define _TPIXEL_LUT_FILTER_H

/** @file
 * @brief filtri sui pixel
 * */

namespace cimage {

namespace kernel {

/// applica una lut 
/// out = table[in]
template<class OutType = uint8_t, class InType = uint8_t>
class TPixelLUTFilter: public filter::ImplPixelOperator {
protected:
  
  OutType m_lut[256]; // TODO
  
public:
  
  /// to access inner lut element:
   OutType & operator[](int i) { return m_lut[i]; }

   template<typename S>
   struct Return {
        typedef OutType Type;
	};

    template<class D>
    inline OutType zero() const { return OutType(); }
    inline uint32_t GetWidth() const { return 1; }
    inline uint32_t GetHeight() const { return 1; }
    template<class S>
    inline OutType operator() ( const S* inputPixel, long stride ) const
    {
      return m_lut[(InType)(*inputPixel)];
    }  
};

/** precalcola una LUT sull'operatore da applicare a tutti i pixel dell'immagine */
template<class Op>
class TCompPixelFilter: public TPixelLUTFilter<uint8_t, uint8_t> {
  
public:
  
  TCompPixelFilter(Op p = Op() )
  {
    for(int i =0;i<256;++i)
      m_lut[i] = p(i);
  }
  
};

/** applica un operatore a tutti i pixel dell'immagine */
template<class Op>
class TPixelFilter: public Op, public filter::ImplPixelOperator {
  
public:
    public:

   template<typename S>
   struct Return {
        typedef uint8_t Type;
	};

    template<class D>
    inline uint8_t zero() const { return 0; }
    inline uint32_t GetWidth() const { return 1; }
    inline uint32_t GetHeight() const { return 1; }
    template<class S>
    inline uint8_t operator() ( const S* inputPixel, long stride ) const
    {
      return Op::operator() (*inputPixel);
    }
  
};

}

}

#endif
