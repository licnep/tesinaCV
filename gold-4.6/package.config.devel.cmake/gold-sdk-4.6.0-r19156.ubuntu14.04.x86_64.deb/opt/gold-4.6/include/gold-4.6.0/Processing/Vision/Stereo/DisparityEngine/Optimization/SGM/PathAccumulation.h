#ifndef _PATH_ACCUMULATION_H
#define _PATH_ACCUMULATION_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * \file PathAccumulation.h
 * \brief Path Accumulation Functions
 * \author Mirko Felisa <felisa@vislab.it>
 * \date 2010-10-18
 **/

template <class T>
inline T min(T a, T b , T c, T d)
{
   T m = std::min( a ,b);
   m = std::min(m, c);
   m = std::min(m, d);
   return m;

}


template < class ResultType_Opt, class ResultType_Agg>
inline void PathAccumulation0(ResultType_Opt* disparityOutputCube, const ResultType_Agg* disparityInputCube, ResultType_Agg* path, int MAXDISP)
{
    const ResultType_Opt OptTypeMax = std::numeric_limits<ResultType_Opt>::max();
    typedef typename cimage::PixelTraits<ResultType_Agg>::CumulativeType  CumulativeType;

    std::copy(disparityInputCube, disparityInputCube + MAXDISP, path);
    ResultType_Agg minimum = *std::min_element(path, path + MAXDISP);
            
    for(int d = 0; d < MAXDISP; d++)
    {
        path[d] -= minimum;
        CumulativeType sum = (CumulativeType)disparityOutputCube[d] + (CumulativeType)path[d];
        disparityOutputCube[d] = (sum > OptTypeMax) ? OptTypeMax : sum;
    }  
     

}

template < class ResultType_Opt, class ResultType_Agg>
inline void PathAccumulation(ResultType_Opt* disparityOutputCube, const ResultType_Agg* disparityInputCube, ResultType_Agg* path, int MAXDISP, const ResultType_Agg P1, const ResultType_Agg P2)
{
  
    const ResultType_Agg AggTypeMax = std::numeric_limits<ResultType_Agg>::max();
    const ResultType_Opt OptTypeMax = std::numeric_limits<ResultType_Opt>::max();
    typedef typename cimage::PixelTraits<ResultType_Agg>::CumulativeType CumulativeType;
  
    ResultType_Agg minimum = AggTypeMax; 
    ResultType_Agg prev = AggTypeMax, next;
                 
    for(int d = 0; d < MAXDISP; d++)
    {   
        next = (d < MAXDISP - 1) ? path[d + 1] : AggTypeMax;
        ResultType_Agg s = disparityInputCube[d];           
        const ResultType_Agg m = min<ResultType_Agg> (path[d], (next > AggTypeMax - P1)? AggTypeMax : next + P1, (prev > AggTypeMax - P1)? AggTypeMax : prev + P1 , P2);
        s = (m > AggTypeMax - s ) ? AggTypeMax : s + m;
        minimum = std::min(minimum, s); 
        prev = path[d];
        path[d] = s;       
    }

         
    for(int d = 0; d< MAXDISP; d++)
    {
        path[d]-= minimum;
        CumulativeType sum = (CumulativeType)disparityOutputCube[d] + (CumulativeType)path[d];
        disparityOutputCube[d] = (sum > OptTypeMax) ? OptTypeMax : sum;
    }
    

}

#if (defined  __SSSE3__  && defined __x86_64)  

#include <xmmintrin.h>

DECLSPEC_FORCEINLINE inline void PathInit(int P1, int P2)
    {
    __asm__ volatile (
                       "movd   %0, %%xmm7 \n\t"
                       "movd   %1, %%xmm8 \n\t"
                       "punpcklbw %%xmm7, %%xmm7\n\t" 
                       "punpcklbw %%xmm8, %%xmm8\n\t" 
                       "punpcklwd %%xmm7, %%xmm7\n\t"
                       "punpcklwd %%xmm8, %%xmm8\n\t"
                       "pshufd  $0,%%xmm7, %%xmm7\n\t"
                       "pshufd  $0,%%xmm8, %%xmm8\n\t"
                       "pxor %%xmm9, %%xmm9\n\t"
         : :  "m"(P1), "m"(P2) : "%xmm7", "%xmm8", "%xmm9"); 
    }


template <int T>
inline void PathAccumulation0(uint8_t* disparityPathCube, const uint8_t* disparityCube);

template <int T>
inline void PathAccumulation(uint8_t* disparityPathCube, const uint8_t* disparityCube);

template <int T>
inline void PathAccumulation0_0(uint8_t* disparityPathCube, const uint8_t* disparityCube);

template <int T>
inline void PathAccumulation_0(uint8_t* disparityPathCube, const uint8_t* disparityCube);



//16

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation0<16>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{
       __asm__ volatile (
                "movdqa   %1, %%xmm0 \n\t"
                "movdqa  %0, %%xmm4\n\t"
                
                "pshufd  $78,%%xmm0, %%xmm3\n\t"
                "pminub %%xmm0, %%xmm3\n\t"
#ifdef __SSE4_1__                
                "punpcklbw %%xmm3, %%xmm3\n\t"
                "phminposuw %%xmm3, %%xmm3\n\t"
#else
                "pshufd $1, %%xmm3, %%xmm2\n\t"
                "pminub %%xmm2, %%xmm3\n\t"
                "pshuflw $1, %%xmm3, %%xmm2\n\t"
                "pminub %%xmm2, %%xmm3\n\t"
                "punpcklbw %%xmm3, %%xmm3\n\t"
                "pshuflw $1, %%xmm3, %%xmm2\n\t"
                "pminub %%xmm2, %%xmm3\n\t"               
#endif
                "pshufb %%xmm9, %%xmm3\n\t"
                "psubb %%xmm3, %%xmm0\n\t"

                "paddusb  %%xmm0, %%xmm4\n\t"
 
                "movdqa  %%xmm4, %0\n\t"
            : "=m"(*disparityPathCube) :  "m"(*disparityCube) : "%xmm0", "%xmm1", "%xmm2", "%xmm3","%xmm4", "%xmm5"
            );   
}



template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation<16>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{
  
          __asm__ volatile (  /// %%xmm0
                
#ifdef __AVX__
                "vpalignr $15, %%xmm8, %%xmm0, %%xmm2\n\t"   
                "vpalignr $1, %%xmm0, %%xmm8, %%xmm6\n\t"
#else
                "pshufd  $228,%%xmm0, %%xmm2\n\t"
                "pshufd  $228,%%xmm8, %%xmm6\n\t"                                       
                "palignr $15, %%xmm8, %%xmm2\n\t"   
                "palignr $1, %%xmm0, %%xmm6\n\t"
#endif
                "movdqa  %1, %%xmm10\n\t" 
                "movdqa  %0, %%xmm12\n\t"

                "paddusb %%xmm7, %%xmm2\n\t"
                "paddusb %%xmm7, %%xmm6\n\t"
                               
                "pminub %%xmm2, %%xmm0\n\t"
                "pminub %%xmm8, %%xmm6\n\t"          
                "pminub %%xmm6, %%xmm0\n\t"
                
                "paddusb %%xmm10, %%xmm0\n\t"

                "pshufd $78,%%xmm0, %%xmm2\n\t"
                "pminub %%xmm0, %%xmm2\n\t"
#ifdef __SSE4_1__
                "punpcklbw %%xmm2, %%xmm2\n\t"
                "phminposuw %%xmm2, %%xmm2\n\t"
#else
                "pshufd $1, %%xmm2, %%xmm3\n\t"
                "pminub %%xmm3, %%xmm2\n\t"
                "pshuflw $1, %%xmm2, %%xmm3\n\t"
                "pminub %%xmm3, %%xmm2\n\t"
                "punpcklbw %%xmm2, %%xmm2\n\t"
                "pshuflw $1, %%xmm2, %%xmm3\n\t"
                "pminub %%xmm3, %%xmm2\n\t"               
#endif
                "pshufb %%xmm9, %%xmm2\n\t"
                "psubb %%xmm2, %%xmm0\n\t"
                             
                "paddusb  %%xmm0, %%xmm12\n\t"       
                "movdqa  %%xmm12, %0\n\t"
            : "=m"(*disparityPathCube) :  "m"(*disparityCube) : "%xmm0","%xmm1","%xmm2","%xmm3","%xmm4","%xmm5","%xmm7","%xmm8"
            );   
}


template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation0_0<16>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{
       __asm__ volatile (
                "movdqa   %1, %%xmm0 \n\t"   
                "pshufd  $78,%%xmm0, %%xmm3\n\t"
                "pminub %%xmm0, %%xmm3\n\t"
#ifdef __SSE4_1__                
                "punpcklbw %%xmm3, %%xmm3\n\t"
                "phminposuw %%xmm3, %%xmm3\n\t"
#else
                "pshufd $1, %%xmm3, %%xmm2\n\t"
                "pminub %%xmm2, %%xmm3\n\t"
                "pshuflw $1, %%xmm3, %%xmm2\n\t"
                "pminub %%xmm2, %%xmm3\n\t"
                "punpcklbw %%xmm3, %%xmm3\n\t"
                "pshuflw $1, %%xmm3, %%xmm2\n\t"
                "pminub %%xmm2, %%xmm3\n\t"               
#endif
                "pshufb %%xmm9, %%xmm3\n\t"
                "psubb %%xmm3, %%xmm0\n\t"
                "movdqa  %%xmm0, %0\n\t"
            : "=m"(*disparityPathCube) :  "m"(*disparityCube) : "%xmm0", "%xmm1", "%xmm2", "%xmm3","%xmm4", "%xmm5"
            );   
}

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation_0<16>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{
  
          __asm__ volatile (  /// %%xmm0, %%xmm1
                
#ifdef __AVX__
                "vpalignr $15, %%xmm8, %%xmm0, %%xmm2\n\t"   
                "vpalignr $1, %%xmm0, %%xmm8, %%xmm6\n\t"
#else
                "pshufd  $228,%%xmm0, %%xmm2\n\t"
                "pshufd  $228,%%xmm8, %%xmm6\n\t"                                       
                "palignr $15, %%xmm8, %%xmm2\n\t"   
                "palignr $1, %%xmm0, %%xmm6\n\t"
#endif
                "movdqa  %1, %%xmm10\n\t" 

                "paddusb %%xmm7, %%xmm2\n\t"
                "paddusb %%xmm7, %%xmm6\n\t"
                               
                "pminub %%xmm2, %%xmm0\n\t"
                "pminub %%xmm8, %%xmm6\n\t"          
                "pminub %%xmm6, %%xmm0\n\t"
                
                "paddusb %%xmm10, %%xmm0\n\t"

                "pshufd $78,%%xmm0, %%xmm2\n\t"
                "pminub %%xmm0, %%xmm2\n\t" 
#ifdef __SSE4_1__     
                "punpcklbw %%xmm2, %%xmm2\n\t"
                "phminposuw %%xmm2, %%xmm2\n\t"
#else

                "pshufd $1, %%xmm2, %%xmm3\n\t"
                "pminub %%xmm3, %%xmm2\n\t"
                "pshuflw $1, %%xmm2, %%xmm3\n\t"
                "pminub %%xmm3, %%xmm2\n\t"
                "punpcklbw %%xmm2, %%xmm2\n\t"
                "pshuflw $1, %%xmm2, %%xmm3\n\t"
                "pminub %%xmm3, %%xmm2\n\t"               
#endif
                "pshufb %%xmm9, %%xmm2\n\t"
                "psubb %%xmm2, %%xmm0\n\t"
                                
                "movdqa  %%xmm0, %0\n\t"
            : "=m"(*disparityPathCube) :  "m"(*disparityCube) : "%xmm0","%xmm1","%xmm2","%xmm3","%xmm4","%xmm5","%xmm7","%xmm8"
            );   
}



//32


template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation0<32>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{
#ifdef ENABLE_PREFETCH  
       _mm_prefetch(disparityCube,_MM_HINT_NTA);         
       _mm_prefetch(disparityPathCube,_MM_HINT_T0); 
#endif  
       __asm__ volatile (
                "movdqa   %2, %%xmm0 \n\t"
                "movdqa   %3, %%xmm1 \n\t"
                "movdqa  %0, %%xmm4\n\t"
                "movdqa  %1, %%xmm5\n\t"
#ifdef __AVX__
                "vpminub %%xmm1, %%xmm0, %%xmm2\n\t"
#else                
                "pshufd  $228,%%xmm0, %%xmm2\n\t"  ///TODO: prova a fare la minimiz in paral xmm0,1
                "pminub %%xmm1, %%xmm2\n\t"
#endif                
                "pshufd  $78,%%xmm2, %%xmm3\n\t"
                "pminub %%xmm2, %%xmm3\n\t"
#ifdef __SSE4_1__                
                "punpcklbw %%xmm3, %%xmm3\n\t"
                "phminposuw %%xmm3, %%xmm3\n\t"
#else
                "pshufd $1, %%xmm3, %%xmm2\n\t"
                "pminub %%xmm2, %%xmm3\n\t"
                "pshuflw $1, %%xmm3, %%xmm2\n\t"
                "pminub %%xmm2, %%xmm3\n\t"
                "punpcklbw %%xmm3, %%xmm3\n\t"
                "pshuflw $1, %%xmm3, %%xmm2\n\t"
                "pminub %%xmm2, %%xmm3\n\t" 
#endif  
                "pshufb %%xmm9, %%xmm3\n\t"
                "psubb %%xmm3, %%xmm0\n\t"
                "psubb %%xmm3, %%xmm1\n\t"
                "paddusb  %%xmm0, %%xmm4\n\t" ///deve essere init a zero, vedere se conviene fare un caso per 1o path
                "paddusb  %%xmm1, %%xmm5\n\t"       
                "movdqa  %%xmm4, %0\n\t"
                "movdqa  %%xmm5, %1\n\t"
            : "=m"(*disparityPathCube), "=m"(*(disparityPathCube+16)) :  "m"(*disparityCube), "m"(*(disparityCube+16)) : "%xmm0", "%xmm1", "%xmm2", "%xmm3","%xmm4", "%xmm5"
            );   
}



template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation<32>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{
 #ifdef ENABLE_PREFETCH  
          _mm_prefetch(disparityCube,_MM_HINT_NTA);       
          _mm_prefetch(disparityPathCube,_MM_HINT_T0); 
#endif  
          __asm__ volatile (  /// %%xmm0, %%xmm1
                
#ifdef __AVX__
                "vpalignr $15, %%xmm8, %%xmm0, %%xmm2\n\t"   
                "vpalignr $1, %%xmm0, %%xmm1, %%xmm4\n\t"
                "vpalignr $15, %%xmm0, %%xmm1, %%xmm5\n\t"
                "vpalignr $1, %%xmm1, %%xmm8, %%xmm6\n\t"
#else
                "pshufd  $228,%%xmm0, %%xmm2\n\t"
                "pshufd  $228,%%xmm1, %%xmm4\n\t"
                "pshufd  $228,%%xmm1, %%xmm5\n\t"
                "pshufd  $228,%%xmm8, %%xmm6\n\t"                                      
                "palignr $15, %%xmm8, %%xmm2\n\t"   
                "palignr $1, %%xmm0, %%xmm4\n\t"
                "palignr $15, %%xmm0, %%xmm5\n\t"
                "palignr $1, %%xmm1, %%xmm6\n\t"
#endif
                "movdqa  %2, %%xmm10\n\t" 
                "movdqa  %3, %%xmm11\n\t"
                "movdqa  %0, %%xmm12\n\t"
                "movdqa  %1, %%xmm13\n\t" 

                "paddusb %%xmm7, %%xmm2\n\t"
                "paddusb %%xmm7, %%xmm4\n\t"
                "paddusb %%xmm7, %%xmm5\n\t"
                "paddusb %%xmm7, %%xmm6\n\t"
                               
                "pminub %%xmm2, %%xmm0\n\t"
                "pminub %%xmm8, %%xmm4\n\t"       
                "pminub %%xmm5, %%xmm1\n\t"
                "pminub %%xmm8, %%xmm6\n\t"                 
                "pminub %%xmm4, %%xmm0\n\t"
                "pminub %%xmm6, %%xmm1\n\t"
                
                "paddusb %%xmm10, %%xmm0\n\t"
                "paddusb %%xmm11, %%xmm1\n\t"
#ifdef __AVX__
                "vpminub %%xmm1, %%xmm0, %%xmm2\n\t"
#else                
                "pshufd $228,%%xmm0, %%xmm2\n\t"
                "pminub %%xmm1, %%xmm2\n\t"
#endif                
                "pshufd $78,%%xmm2, %%xmm4\n\t"
                "pminub %%xmm4, %%xmm2\n\t"
#ifdef __SSE4_1__               
                "punpcklbw %%xmm2, %%xmm2\n\t"
                "phminposuw %%xmm2, %%xmm2\n\t"
#else
                "pshufd $1, %%xmm2, %%xmm4\n\t"
                "pminub %%xmm4, %%xmm2\n\t"
                "pshuflw $1, %%xmm2, %%xmm4\n\t"
                "pminub %%xmm4, %%xmm2\n\t"
                "punpcklbw %%xmm2, %%xmm2\n\t"
                "pshuflw $1, %%xmm2, %%xmm4\n\t"
                "pminub %%xmm4, %%xmm2\n\t" 
#endif 
                "pshufb %%xmm9, %%xmm2\n\t"

                "psubb %%xmm2, %%xmm0\n\t"
                "psubb %%xmm2, %%xmm1\n\t"
                               
                "paddusb  %%xmm0, %%xmm12\n\t" 
                "paddusb  %%xmm1, %%xmm13\n\t"       
                "movdqa  %%xmm12, %0\n\t"
                "movdqa  %%xmm13, %1\n\t"
            : "=m"(*disparityPathCube), "=m"(*(disparityPathCube+16)) :  "m"(*disparityCube), "m"(*(disparityCube+16)) : "%xmm0","%xmm1","%xmm2","%xmm3","%xmm4","%xmm5","%xmm7","%xmm8"
            );   
}


template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation0_0<32>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{
#ifdef ENABLE_PREFETCH    
       _mm_prefetch(disparityCube,_MM_HINT_NTA); 
       _mm_prefetch(disparityCube+256,_MM_HINT_NTA);
#endif          
 
       __asm__ volatile (
                "movdqa   %2, %%xmm0 \n\t"
                "movdqa   %3, %%xmm1 \n\t"
#ifdef __AVX__
                "vpminub %%xmm1, %%xmm0, %%xmm2\n\t"
#else                
                "pshufd  $228,%%xmm0, %%xmm2\n\t" 
                "pminub %%xmm1, %%xmm2\n\t"
#endif                
                "pshufd  $78,%%xmm2, %%xmm3\n\t"
                "pminub %%xmm2, %%xmm3\n\t"
#ifdef __SSE4_1__                
                "punpcklbw %%xmm3, %%xmm3\n\t"
                "phminposuw %%xmm3, %%xmm3\n\t"
#else
                "pshufd $1, %%xmm3, %%xmm2\n\t"
                "pminub %%xmm2, %%xmm3\n\t"
                "pshuflw $1, %%xmm3, %%xmm2\n\t"
                "pminub %%xmm2, %%xmm3\n\t"
                "punpcklbw %%xmm3, %%xmm3\n\t"
                "pshuflw $1, %%xmm3, %%xmm2\n\t"
                "pminub %%xmm2, %%xmm3\n\t" 
#endif 
                "pshufb %%xmm9, %%xmm3\n\t"
                "psubb %%xmm3, %%xmm0\n\t"
                "psubb %%xmm3, %%xmm1\n\t"     
                "movdqa  %%xmm0, %0\n\t"
                "movdqa  %%xmm1, %1\n\t"
            : "=m"(*disparityPathCube), "=m"(*(disparityPathCube+16)) :  "m"(*disparityCube), "m"(*(disparityCube+16)) : "%xmm0", "%xmm1", "%xmm2", "%xmm3","%xmm4", "%xmm5"
            );   
}

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation_0<32>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{
#ifdef ENABLE_PREFETCH    
           _mm_prefetch(disparityCube-64,_MM_HINT_NTA); 
           _mm_prefetch(disparityCube-64+256,_MM_HINT_NTA); 
#endif            
  
          __asm__ volatile (  /// %%xmm0, %%xmm1 

#ifdef __AVX__
                "vpalignr $15, %%xmm8, %%xmm0, %%xmm2\n\t"   
                "vpalignr $1, %%xmm0, %%xmm1, %%xmm4\n\t"
                "vpalignr $15, %%xmm0, %%xmm1, %%xmm5\n\t"
                "vpalignr $1, %%xmm1, %%xmm8, %%xmm6\n\t"
#else
                "pshufd  $228,%%xmm0, %%xmm2\n\t"
                "pshufd  $228,%%xmm1, %%xmm4\n\t"
                "pshufd  $228,%%xmm1, %%xmm5\n\t"
                "pshufd  $228,%%xmm8, %%xmm6\n\t"                                       
                "palignr $15, %%xmm8, %%xmm2\n\t"   
                "palignr $1, %%xmm0, %%xmm4\n\t"
                "palignr $15, %%xmm0, %%xmm5\n\t"
                "palignr $1, %%xmm1, %%xmm6\n\t"
#endif
                "movdqa  %2, %%xmm10\n\t" 
                "movdqa  %3, %%xmm11\n\t"

                "paddusb %%xmm7, %%xmm2\n\t"
                "paddusb %%xmm7, %%xmm4\n\t"
                "paddusb %%xmm7, %%xmm5\n\t"
                "paddusb %%xmm7, %%xmm6\n\t"
                               
                "pminub %%xmm2, %%xmm0\n\t"
                "pminub %%xmm8, %%xmm4\n\t"       
                "pminub %%xmm5, %%xmm1\n\t"
                "pminub %%xmm8, %%xmm6\n\t"                 
                "pminub %%xmm4, %%xmm0\n\t"
                "pminub %%xmm6, %%xmm1\n\t"
                
                "paddusb %%xmm10, %%xmm0\n\t"
                "paddusb %%xmm11, %%xmm1\n\t"
#ifdef __AVX__
                "vpminub %%xmm1, %%xmm0, %%xmm2\n\t"
#else                
                "pshufd $228,%%xmm0, %%xmm2\n\t"
                "pminub %%xmm1, %%xmm2\n\t"
#endif                
                "pshufd $78,%%xmm2, %%xmm4\n\t"
                "pminub %%xmm4, %%xmm2\n\t"
#ifdef __SSE4_1__                
                "punpcklbw %%xmm2, %%xmm2\n\t"
                "phminposuw %%xmm2, %%xmm2\n\t"
#else
                "pshufd $1, %%xmm2, %%xmm4\n\t"
                "pminub %%xmm4, %%xmm2\n\t"
                "pshuflw $1, %%xmm2, %%xmm4\n\t"
                "pminub %%xmm4, %%xmm2\n\t"
                "punpcklbw %%xmm2, %%xmm2\n\t"
                "pshuflw $1, %%xmm2, %%xmm4\n\t"
                "pminub %%xmm4, %%xmm2\n\t" 
#endif 
                "pshufb %%xmm9, %%xmm2\n\t"

                "psubb %%xmm2, %%xmm0\n\t"
                "psubb %%xmm2, %%xmm1\n\t"
                                     
                "movdqa  %%xmm0, %0\n\t"
                "movdqa  %%xmm1, %1\n\t"
            : "=m"(*disparityPathCube), "=m"(*(disparityPathCube+16)) :  "m"(*disparityCube), "m"(*(disparityCube+16)) : "%xmm0","%xmm1","%xmm2","%xmm3","%xmm4","%xmm5","%xmm7","%xmm8"
            );   
}



//48

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation0<48>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{

    #ifdef ENABLE_PREFETCH  
       _mm_prefetch(disparityCube,_MM_HINT_NTA);         
       _mm_prefetch(disparityPathCube,_MM_HINT_T0); 
    #endif  


        __asm__ volatile (  /// values in xmm0, xmm1, xmm2
            "movdqa   (%1), %%xmm0 \n\t"
            "movdqa 16(%1), %%xmm1 \n\t"
            "movdqa 32(%1), %%xmm2 \n\t"
            "movdqa   (%0), %%xmm5 \n\t"
            "movdqa 16(%0), %%xmm6 \n\t"
            "movdqa 32(%0), %%xmm10 \n\t"
#ifdef __AVX__
            "vpminub %%xmm1, %%xmm0, %%xmm3 \n\t"
#else            
            "pshufd $228, %%xmm0, %%xmm3 \n\t"
            "pminub %%xmm1, %%xmm3 \n\t"
#endif            
            "pminub %%xmm2, %%xmm3 \n\t"
            "pshufd $78, %%xmm3, %%xmm4 \n\t"
            "pminub %%xmm3, %%xmm4 \n\t"
#ifdef __SSE4_1__
            "punpcklbw %%xmm4, %%xmm4 \n\t"
            "phminposuw %%xmm4, %%xmm4 \n\t"
#else
            "pshufd $1, %%xmm4, %%xmm3 \n\t"
            "pminub %%xmm3, %%xmm4 \n\t"
            "pshuflw $1, %%xmm4, %%xmm3 \n\t"
            "pminub %%xmm3, %%xmm4 \n\t"
            "punpcklbw %%xmm4, %%xmm4 \n\t"
            "pshuflw $1, %%xmm4, %%xmm3 \n\t"
            "pminub %%xmm3, %%xmm4 \n\t"
#endif
            "pshufb %%xmm9, %%xmm4 \n\t"
            "psubb %%xmm4, %%xmm0 \n\t"
            "psubb %%xmm4, %%xmm1 \n\t"
            "psubb %%xmm4, %%xmm2 \n\t"
            "paddusb %%xmm0, %%xmm5 \n\t"
            "paddusb %%xmm1, %%xmm6 \n\t"
            "paddusb %%xmm2, %%xmm10 \n\t"
            "movdqa %%xmm5,    (%0) \n\t"
            "movdqa %%xmm6,  16(%0) \n\t"
            "movdqa %%xmm10, 32(%0) \n\t"
            :
            : "r"(disparityPathCube), "r"(disparityCube)
            : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm9", "%xmm10"
        );

}

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation<48>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{

    #ifdef ENABLE_PREFETCH  
       _mm_prefetch(disparityCube,_MM_HINT_NTA);         
       _mm_prefetch(disparityPathCube,_MM_HINT_T0); 
   #endif

        __asm__ volatile (  /// values in xmm0, xmm1, xmm2
            "movdqa   (%1), %%xmm12 \n\t"
            "movdqa 16(%1), %%xmm13 \n\t"
            "movdqa 32(%1), %%xmm14 \n\t"
#ifdef __AVX__
            "vpalignr $15, %%xmm8, %%xmm0, %%xmm3 \n\t"
            "vpalignr  $1, %%xmm0, %%xmm1, %%xmm4 \n\t"
            "vpalignr $15, %%xmm0, %%xmm1, %%xmm5 \n\t"
            "vpalignr  $1, %%xmm1, %%xmm2, %%xmm6 \n\t"
            "vpalignr $15, %%xmm1, %%xmm2, %%xmm10 \n\t"
            "vpalignr  $1, %%xmm2, %%xmm8, %%xmm11 \n\t"
#else            
            "pshufd $228, %%xmm0, %%xmm3 \n\t"
            "pshufd $228, %%xmm1, %%xmm4 \n\t"
            "pshufd $228, %%xmm1, %%xmm5 \n\t"
            "pshufd $228, %%xmm2, %%xmm6 \n\t"
            "pshufd $228, %%xmm2, %%xmm10 \n\t"
            "pshufd $228, %%xmm8, %%xmm11 \n\t"
            "palignr $15, %%xmm8, %%xmm3 \n\t"
            "palignr  $1, %%xmm0, %%xmm4 \n\t"
            "palignr $15, %%xmm0, %%xmm5 \n\t"
            "palignr  $1, %%xmm1, %%xmm6 \n\t"
            "palignr $15, %%xmm1, %%xmm10 \n\t"
            "palignr  $1, %%xmm2, %%xmm11 \n\t"
#endif           
            "paddusb %%xmm7, %%xmm3 \n\t"
            "paddusb %%xmm7, %%xmm4 \n\t"
            "paddusb %%xmm7, %%xmm5 \n\t"
            "paddusb %%xmm7, %%xmm6 \n\t"
            "paddusb %%xmm7, %%xmm10 \n\t"
            "paddusb %%xmm7, %%xmm11 \n\t"
            "pminub %%xmm3, %%xmm0 \n\t"
            "pminub %%xmm5, %%xmm1 \n\t"
            "pminub %%xmm10, %%xmm2 \n\t"
            "movdqa   (%0), %%xmm3 \n\t" 
            "movdqa 16(%0), %%xmm5 \n\t" 
            "movdqa 32(%0), %%xmm10 \n\t"
            "pminub %%xmm8, %%xmm4 \n\t"
            "pminub %%xmm8, %%xmm6 \n\t"
            "pminub %%xmm8, %%xmm11 \n\t"
            "pminub %%xmm4, %%xmm0 \n\t"
            "pminub %%xmm6, %%xmm1 \n\t"
            "pminub %%xmm11, %%xmm2 \n\t"
            "paddusb %%xmm12, %%xmm0 \n\t"
            "paddusb %%xmm13, %%xmm1 \n\t"
            "paddusb %%xmm14, %%xmm2 \n\t"
#ifdef __AVX__
            "vpminub %%xmm1, %%xmm0, %%xmm13 \n\t"
#else            
            "pshufd $228, %%xmm0, %%xmm13 \n\t"
            "pminub %%xmm1, %%xmm13 \n\t"
#endif            
            "pminub %%xmm2, %%xmm13 \n\t"
            "pshufd $78, %%xmm13, %%xmm4 \n\t"
            "pminub %%xmm13, %%xmm4 \n\t"
#ifdef __SSE4_1__
            "punpcklbw %%xmm4, %%xmm4 \n\t"
            "phminposuw %%xmm4, %%xmm4 \n\t"
#else
            "pshufd $1, %%xmm4, %%xmm13 \n\t"
            "pminub %%xmm13, %%xmm4 \n\t"
            "pshuflw $1, %%xmm4, %%xmm13 \n\t"
            "pminub %%xmm13, %%xmm4 \n\t"
            "punpcklbw %%xmm4, %%xmm4 \n\t"
            "pshuflw $1, %%xmm4, %%xmm13 \n\t"
            "pminub %%xmm13, %%xmm4 \n\t"
#endif
            "pshufb %%xmm9, %%xmm4 \n\t"
            "psubb %%xmm4, %%xmm0 \n\t"
            "psubb %%xmm4, %%xmm1 \n\t"
            "psubb %%xmm4, %%xmm2 \n\t"
            "paddusb %%xmm0, %%xmm3 \n\t"
            "paddusb %%xmm1, %%xmm5 \n\t"
            "paddusb %%xmm2, %%xmm10 \n\t"
            "movdqa %%xmm3,    (%0) \n\t"
            "movdqa %%xmm5,  16(%0) \n\t"
            "movdqa %%xmm10, 32(%0) \n\t"   
            :
            : "r"(disparityPathCube), "r"(disparityCube)
            : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7", "%xmm8", "%xmm9", "%xmm10", "%xmm11", "%xmm12", "%xmm13", "%xmm14"
      );

}

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation0_0<48>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{

    #ifdef ENABLE_PREFETCH    
       _mm_prefetch(disparityCube,_MM_HINT_NTA); 
       _mm_prefetch(disparityCube+256,_MM_HINT_NTA);
   #endif 

        __asm__ volatile (  /// values in xmm0, xmm1, xmm2
            "movdqa   (%1), %%xmm0 \n\t"
            "movdqa 16(%1), %%xmm1 \n\t"
            "movdqa 32(%1), %%xmm2 \n\t"
#ifdef __AVX__
            "vpminub %%xmm1, %%xmm0, %%xmm3 \n\t"
#else            
            "pshufd $228, %%xmm0, %%xmm3 \n\t"
            "pminub %%xmm1, %%xmm3 \n\t"
#endif            
            "pminub %%xmm2, %%xmm3 \n\t"
            "pshufd $78, %%xmm3, %%xmm4 \n\t"
            "pminub %%xmm3, %%xmm4 \n\t"
#ifdef __SSE4_1__
            "punpcklbw %%xmm4, %%xmm4 \n\t"
            "phminposuw %%xmm4, %%xmm4 \n\t"
#else
            "pshufd $1, %%xmm4, %%xmm3 \n\t"
            "pminub %%xmm3, %%xmm4 \n\t"
            "pshuflw $1, %%xmm4, %%xmm3 \n\t"
            "pminub %%xmm3, %%xmm4 \n\t"
            "punpcklbw %%xmm4, %%xmm4 \n\t"
            "pshuflw $1, %%xmm4, %%xmm3 \n\t"
            "pminub %%xmm3, %%xmm4 \n\t"
#endif
            "pshufb %%xmm9, %%xmm4 \n\t"
            "psubb %%xmm4, %%xmm0 \n\t"
            "psubb %%xmm4, %%xmm1 \n\t"
            "psubb %%xmm4, %%xmm2 \n\t"
            "movdqa %%xmm0,   (%0) \n\t"
            "movdqa %%xmm1, 16(%0) \n\t"
            "movdqa %%xmm2, 32(%0) \n\t"   
            : 
            : "r"(disparityPathCube), "r"(disparityCube)
            : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm9"
       );

}

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation_0<48>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{

   #ifdef ENABLE_PREFETCH    
           _mm_prefetch(disparityCube-64,_MM_HINT_NTA); 
           _mm_prefetch(disparityCube-64+256,_MM_HINT_NTA); 
   #endif  

        __asm__ volatile (  /// values in xmm0, xmm1, xmm2
            "movdqa   (%1), %%xmm12 \n\t"
            "movdqa 16(%1), %%xmm13 \n\t"
            "movdqa 32(%1), %%xmm14 \n\t"
#ifdef __AVX__ 
            "vpalignr $15, %%xmm8, %%xmm0, %%xmm3 \n\t"
            "vpalignr  $1, %%xmm0, %%xmm1, %%xmm4 \n\t"
            "vpalignr $15, %%xmm0, %%xmm1, %%xmm5 \n\t"
            "vpalignr  $1, %%xmm1, %%xmm2, %%xmm6 \n\t"
            "vpalignr $15, %%xmm1, %%xmm2, %%xmm10 \n\t"
            "vpalignr  $1, %%xmm2, %%xmm8, %%xmm11 \n\t"
#else            
            "pshufd $228, %%xmm0, %%xmm3 \n\t"
            "pshufd $228, %%xmm1, %%xmm4 \n\t"
            "pshufd $228, %%xmm1, %%xmm5 \n\t"
            "pshufd $228, %%xmm2, %%xmm6 \n\t"
            "pshufd $228, %%xmm2, %%xmm10 \n\t"
            "pshufd $228, %%xmm8, %%xmm11 \n\t"
            "palignr $15, %%xmm8, %%xmm3 \n\t"
            "palignr  $1, %%xmm0, %%xmm4 \n\t"
            "palignr $15, %%xmm0, %%xmm5 \n\t"
            "palignr  $1, %%xmm1, %%xmm6 \n\t"
            "palignr $15, %%xmm1, %%xmm10 \n\t"
            "palignr  $1, %%xmm2, %%xmm11 \n\t"
#endif            
            "paddusb %%xmm7, %%xmm3 \n\t"
            "paddusb %%xmm7, %%xmm4 \n\t"
            "paddusb %%xmm7, %%xmm5 \n\t"
            "paddusb %%xmm7, %%xmm6 \n\t"
            "paddusb %%xmm7, %%xmm10 \n\t"
            "paddusb %%xmm7, %%xmm11 \n\t"
            "pminub %%xmm3, %%xmm0 \n\t"
            "pminub %%xmm5, %%xmm1 \n\t"
            "pminub %%xmm10, %%xmm2 \n\t"
            "pminub %%xmm8, %%xmm4 \n\t"
            "pminub %%xmm8, %%xmm6 \n\t"
            "pminub %%xmm8, %%xmm11 \n\t"
            "pminub %%xmm4, %%xmm0 \n\t"
            "pminub %%xmm6, %%xmm1 \n\t"
            "pminub %%xmm11, %%xmm2 \n\t"
            "paddusb %%xmm12, %%xmm0 \n\t"
            "paddusb %%xmm13, %%xmm1 \n\t"
            "paddusb %%xmm14, %%xmm2 \n\t"
#ifdef __AVX__
            "vpminub %%xmm1, %%xmm0, %%xmm3 \n\t"
#else            
            "pshufd $228, %%xmm0, %%xmm3 \n\t"
            "pminub %%xmm1, %%xmm3 \n\t"
#endif            
            "pminub %%xmm2, %%xmm3 \n\t"
            "pshufd $78, %%xmm3, %%xmm4 \n\t"
            "pminub %%xmm3, %%xmm4 \n\t"
#ifdef __SSE4_1__
            "punpcklbw %%xmm4, %%xmm4 \n\t"
            "phminposuw %%xmm4, %%xmm4 \n\t"
#else
            "pshufd $1, %%xmm4, %%xmm3 \n\t"
            "pminub %%xmm3, %%xmm4 \n\t"
            "pshuflw $1, %%xmm4, %%xmm3 \n\t"
            "pminub %%xmm3, %%xmm4 \n\t"
            "punpcklbw %%xmm4, %%xmm4 \n\t"
            "pshuflw $1, %%xmm4, %%xmm3 \n\t"
            "pminub %%xmm3, %%xmm4 \n\t"
#endif
            "pshufb %%xmm9, %%xmm4 \n\t"
            "psubb %%xmm4, %%xmm0 \n\t"
            "psubb %%xmm4, %%xmm1 \n\t"
            "psubb %%xmm4, %%xmm2 \n\t"
            "movdqa %%xmm0,   (%0) \n\t"
            "movdqa %%xmm1, 16(%0) \n\t"
            "movdqa %%xmm2, 32(%0) \n\t"   
            :
            : "r"(disparityPathCube), "r"(disparityCube)
            : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7", "%xmm8", "%xmm9", "%xmm10", "%xmm11", "%xmm12", "%xmm13", "%xmm14"
        );
}




//64


template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation0<64>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{
#ifdef ENABLE_PREFETCH  
       _mm_prefetch(disparityCube,_MM_HINT_NTA); 
       _mm_prefetch(disparityCube+256,_MM_HINT_NTA); 
          
       _mm_prefetch(disparityPathCube,_MM_HINT_T0); 
       _mm_prefetch(disparityPathCube+256,_MM_HINT_T0);
#endif  
       __asm__ volatile (
                "movdqa   %4, %%xmm0 \n\t"
                "movdqa   %5, %%xmm1 \n\t"
                "movdqa   %6, %%xmm2 \n\t"
                "movdqa   %7, %%xmm3 \n\t"
                
                "movdqa  %0, %%xmm10\n\t"
                "movdqa  %1, %%xmm11\n\t"
                "movdqa  %2, %%xmm12\n\t"
                "movdqa  %3, %%xmm13\n\t"
#ifdef __AVX__
                "vpminub %%xmm1, %%xmm0, %%xmm5\n\t"
                "vpminub %%xmm3, %%xmm2, %%xmm6\n\t"
#else                
                "pshufd  $228,%%xmm0, %%xmm5\n\t"
                "pshufd  $228,%%xmm2, %%xmm6\n\t"               
                "pminub %%xmm1, %%xmm5\n\t"
                "pminub %%xmm3, %%xmm6\n\t"
#endif                
                "pminub %%xmm5, %%xmm6\n\t"
                
                "pshufd  $78,%%xmm6, %%xmm5\n\t"
                "pminub %%xmm5, %%xmm6\n\t"
#ifdef __SSE4_1__                
                "punpcklbw %%xmm6, %%xmm6\n\t"
                "phminposuw %%xmm6, %%xmm6\n\t"
#else
                "pshufd $1, %%xmm6, %%xmm5\n\t"
                "pminub %%xmm5, %%xmm6\n\t"
                "pshuflw $1, %%xmm6, %%xmm5\n\t"
                "pminub %%xmm5, %%xmm6\n\t"
                "punpcklbw %%xmm6, %%xmm6\n\t"
                "pshuflw $1, %%xmm6, %%xmm5\n\t"
                "pminub %%xmm5, %%xmm6\n\t" 
#endif 
                
                "pshufb %%xmm9, %%xmm6\n\t"
                "psubb %%xmm6, %%xmm0\n\t"
                "psubb %%xmm6, %%xmm1\n\t"
                "psubb %%xmm6, %%xmm2\n\t"
                "psubb %%xmm6, %%xmm3\n\t"
                "paddusb  %%xmm0, %%xmm10\n\t" 
                "paddusb  %%xmm1, %%xmm11\n\t"
                "paddusb  %%xmm2, %%xmm12\n\t" 
                "paddusb  %%xmm3, %%xmm13\n\t"  
                "movdqa  %%xmm10, %0\n\t"
                "movdqa  %%xmm11, %1\n\t"
                "movdqa  %%xmm12, %2\n\t"
                "movdqa  %%xmm13, %3\n\t"
            : "=m"(*disparityPathCube), "=m"(*(disparityPathCube+16)), "=m"(*(disparityPathCube+32)), "=m"(*(disparityPathCube+48)):  "m"(*disparityCube), "m"(*(disparityCube+16)),  "m"(*(disparityCube+32)), "m"(*(disparityCube+48)) : "%xmm0", "%xmm1", "%xmm2", "%xmm3","%xmm4", "%xmm5"
            );  
            

}




template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation<64>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{
#ifdef ENABLE_PREFETCH  
          _mm_prefetch(disparityCube,_MM_HINT_NTA); 
          _mm_prefetch(disparityCube+256,_MM_HINT_NTA);
          
          _mm_prefetch(disparityPathCube,_MM_HINT_T0); 
          _mm_prefetch(disparityPathCube+256,_MM_HINT_T0);
#endif         
          
          __asm__ volatile (  /// %%xmm0, %%xmm1 %%xmm2 %%xmm3
                
#ifdef __AVX__
                "vpalignr $15, %%xmm8, %%xmm0, %%xmm4\n\t"   
                "vpalignr $1,  %%xmm0, %%xmm1, %%xmm5\n\t"
                "vpalignr $15, %%xmm0, %%xmm1, %%xmm6\n\t"              
                "vpalignr $1,  %%xmm1, %%xmm2, %%xmm10\n\t"               
                "vpalignr $15, %%xmm1, %%xmm2, %%xmm11\n\t"              
                "vpalignr $1,  %%xmm2, %%xmm3, %%xmm12\n\t"             
                "vpalignr $15, %%xmm2, %%xmm3, %%xmm13\n\t"               
                "vpalignr $1,  %%xmm3, %%xmm8, %%xmm14\n\t"
#else
                "pshufd  $228,%%xmm0, %%xmm4\n\t"       
                "pshufd  $228,%%xmm1, %%xmm5\n\t"
                "pshufd  $228,%%xmm1, %%xmm6\n\t"                
                "pshufd  $228,%%xmm2, %%xmm10\n\t"                
                "pshufd  $228,%%xmm2, %%xmm11\n\t"              
                "pshufd  $228,%%xmm3, %%xmm12\n\t"              
                "pshufd  $228,%%xmm3, %%xmm13\n\t"                
                "pshufd  $228,%%xmm8, %%xmm14\n\t"                   
                "palignr $15, %%xmm8, %%xmm4\n\t"   
                "palignr $1, %%xmm0, %%xmm5\n\t"
                "palignr $15, %%xmm0, %%xmm6\n\t"              
                "palignr $1, %%xmm1, %%xmm10\n\t"               
                "palignr $15, %%xmm1, %%xmm11\n\t"              
                "palignr $1, %%xmm2, %%xmm12\n\t"             
                "palignr $15, %%xmm2, %%xmm13\n\t"               
                "palignr $1, %%xmm3, %%xmm14\n\t"
#endif
                "movdqa  %4, %%xmm15\n\t" 
                "movdqa  %5, %%xmm9\n\t" 


                "paddusb %%xmm7, %%xmm4\n\t"
                "paddusb %%xmm7, %%xmm5\n\t"
                "paddusb %%xmm7, %%xmm6\n\t"
                "paddusb %%xmm7, %%xmm10\n\t"
                "paddusb %%xmm7, %%xmm11\n\t"
                "paddusb %%xmm7, %%xmm12\n\t"
                "paddusb %%xmm7, %%xmm13\n\t"
                "paddusb %%xmm7, %%xmm14\n\t"
                
                
                "pminub %%xmm4, %%xmm0\n\t"
                "pminub %%xmm6, %%xmm1\n\t"                
                "movdqa  %6, %%xmm4\n\t"
                "movdqa  %7, %%xmm6\n\t"              
                "pminub %%xmm11, %%xmm2\n\t"
                "pminub %%xmm13, %%xmm3\n\t"           
                "movdqa  %0, %%xmm11\n\t" 
                "movdqa  %1, %%xmm13\n\t"                
                "pminub %%xmm8, %%xmm5\n\t"
                "pminub %%xmm8, %%xmm10\n\t"
                "pminub %%xmm8, %%xmm12\n\t"
                "pminub %%xmm8, %%xmm14\n\t"
                "pminub %%xmm5, %%xmm0\n\t"
                "pminub %%xmm10, %%xmm1\n\t"               
                "pminub %%xmm12, %%xmm2\n\t"
                "pminub %%xmm14, %%xmm3\n\t"
              
                "movdqa  %2, %%xmm10\n\t"                
                "movdqa  %3, %%xmm12\n\t"
                        
                "paddusb %%xmm15, %%xmm0\n\t"
                "paddusb %%xmm9, %%xmm1\n\t"
                "paddusb %%xmm4, %%xmm2\n\t"
                "paddusb %%xmm6, %%xmm3\n\t"
                
                "pxor %%xmm9, %%xmm9\n\t"
#ifdef __AVX__
                "vpminub %%xmm2, %%xmm0, %%xmm4\n\t"
                "vpminub %%xmm3, %%xmm1, %%xmm5\n\t"
#else                
                "pshufd $228,%%xmm0, %%xmm4\n\t"
                "pshufd $228,%%xmm1, %%xmm5\n\t"
                "pminub %%xmm2, %%xmm4\n\t"
                "pminub %%xmm3, %%xmm5\n\t"
#endif                
                "pminub %%xmm4, %%xmm5\n\t"
                
                
                "pshufd $78,%%xmm5, %%xmm4\n\t"
                "pminub %%xmm4, %%xmm5\n\t"  
#ifdef __SSE4_1__                
                "punpcklbw %%xmm5, %%xmm5\n\t"
                "phminposuw %%xmm5, %%xmm5\n\t"
#else
                "pshufd $1, %%xmm5, %%xmm4\n\t"
                "pminub %%xmm4, %%xmm5\n\t"
                "pshuflw $1, %%xmm5, %%xmm4\n\t"
                "pminub %%xmm4, %%xmm5\n\t"
                "punpcklbw %%xmm5, %%xmm5\n\t"
                "pshuflw $1, %%xmm5, %%xmm4\n\t"
                "pminub %%xmm4, %%xmm5\n\t" 
#endif   
                "pshufb %%xmm9, %%xmm5\n\t"

                "psubb %%xmm5, %%xmm0\n\t"
                "psubb %%xmm5, %%xmm1\n\t"
                "psubb %%xmm5, %%xmm2\n\t"
                "psubb %%xmm5, %%xmm3\n\t"
                               
                "paddusb  %%xmm0, %%xmm11\n\t" 
                "paddusb  %%xmm1, %%xmm13\n\t"
                "paddusb  %%xmm2, %%xmm10\n\t" 
                "paddusb  %%xmm3, %%xmm12\n\t"  
                "movdqa  %%xmm11, %0\n\t"
                "movdqa  %%xmm13, %1\n\t"
                "movdqa  %%xmm10, %2\n\t"
                "movdqa  %%xmm12, %3\n\t"
            : "=m"(*disparityPathCube), "=m"(*(disparityPathCube+16)), "=m"(*(disparityPathCube+32)), "=m"(*(disparityPathCube+48)):  "m"(*disparityCube), "m"(*(disparityCube+16)),  "m"(*(disparityCube+32)), "m"(*(disparityCube+48)) : "%xmm0", "%xmm1", "%xmm2", "%xmm3","%xmm4", "%xmm5"
            ); 
            

   

            
}


template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation0_0<64>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{
  
#ifdef ENABLE_PREFETCH    
      _mm_prefetch(disparityCube,_MM_HINT_NTA); 
      _mm_prefetch(disparityCube+256,_MM_HINT_NTA); 
          
      _mm_prefetch(disparityPathCube,_MM_HINT_T0); 
      _mm_prefetch(disparityPathCube+256,_MM_HINT_T0);
#endif
      
      __asm__ volatile (
                "movdqa   %4, %%xmm0 \n\t"
                "movdqa   %5, %%xmm1 \n\t"
                "movdqa   %6, %%xmm2 \n\t"
                "movdqa   %7, %%xmm3 \n\t"
#ifdef __AVX__
                "vpminub %%xmm1, %%xmm0, %%xmm5\n\t"
                "vpminub %%xmm3, %%xmm2, %%xmm6\n\t"
#else                
                "pshufd  $228,%%xmm0, %%xmm5\n\t"
                "pshufd  $228,%%xmm2, %%xmm6\n\t"               
                "pminub %%xmm1, %%xmm5\n\t"
                "pminub %%xmm3, %%xmm6\n\t"
#endif                
                "pminub %%xmm5, %%xmm6\n\t"
                
                "pshufd  $78,%%xmm6, %%xmm5\n\t"
                "pminub %%xmm5, %%xmm6\n\t"
#ifdef __SSE4_1__
                "punpcklbw %%xmm6, %%xmm6\n\t"
                "phminposuw %%xmm6, %%xmm6\n\t"
#else
                "pshufd $1, %%xmm6, %%xmm5\n\t"
                "pminub %%xmm5, %%xmm6\n\t"
                "pshuflw $1, %%xmm6, %%xmm5\n\t"
                "pminub %%xmm5, %%xmm6\n\t"
                "punpcklbw %%xmm6, %%xmm6\n\t"
                "pshuflw $1, %%xmm6, %%xmm5\n\t"
                "pminub %%xmm5, %%xmm6\n\t" 
#endif 
                "pshufb %%xmm9, %%xmm6\n\t"
                "psubb %%xmm6, %%xmm0\n\t"
                "psubb %%xmm6, %%xmm1\n\t"
                "psubb %%xmm6, %%xmm2\n\t"
                "psubb %%xmm6, %%xmm3\n\t"
                "movdqa  %%xmm0, %0\n\t"
                "movdqa  %%xmm1, %1\n\t"
                "movdqa  %%xmm2, %2\n\t"
                "movdqa  %%xmm3, %3\n\t"
            : "=m"(*disparityPathCube), "=m"(*(disparityPathCube+16)), "=m"(*(disparityPathCube+32)), "=m"(*(disparityPathCube+48)):  "m"(*disparityCube), "m"(*(disparityCube+16)),  "m"(*(disparityCube+32)), "m"(*(disparityCube+48)) : "%xmm0", "%xmm1", "%xmm2", "%xmm3","%xmm4", "%xmm5"
            );  
            

}

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation_0<64>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{
#ifdef ENABLE_PREFETCH    
           _mm_prefetch(disparityCube-64,_MM_HINT_NTA); 
           _mm_prefetch(disparityCube-64+256,_MM_HINT_NTA); 
            
           _mm_prefetch(disparityPathCube,_MM_HINT_T0); 
           _mm_prefetch(disparityPathCube+256,_MM_HINT_T0);
#endif
           __asm__ volatile (  /// %%xmm0, %%xmm1 %%xmm2 %%xmm3
                
#ifdef __AVX__
                "vpalignr $15, %%xmm8, %%xmm0, %%xmm4\n\t"   
                "vpalignr $1,  %%xmm0, %%xmm1, %%xmm5\n\t"
                "vpalignr $15, %%xmm0, %%xmm1, %%xmm6\n\t"              
                "vpalignr $1,  %%xmm1, %%xmm2, %%xmm10\n\t"               
                "vpalignr $15, %%xmm1, %%xmm2, %%xmm11\n\t"              
                "vpalignr $1,  %%xmm2, %%xmm3, %%xmm12\n\t"             
                "vpalignr $15, %%xmm2, %%xmm3, %%xmm13\n\t"               
                "vpalignr $1,  %%xmm3, %%xmm8, %%xmm14\n\t"
#else
                "pshufd  $228,%%xmm0, %%xmm4\n\t"       
                "pshufd  $228,%%xmm1, %%xmm5\n\t"
                "pshufd  $228,%%xmm1, %%xmm6\n\t"                
                "pshufd  $228,%%xmm2, %%xmm10\n\t"                
                "pshufd  $228,%%xmm2, %%xmm11\n\t"              
                "pshufd  $228,%%xmm3, %%xmm12\n\t"              
                "pshufd  $228,%%xmm3, %%xmm13\n\t"                
                "pshufd  $228,%%xmm8, %%xmm14\n\t"                  
                "palignr $15, %%xmm8, %%xmm4\n\t"   
                "palignr $1, %%xmm0, %%xmm5\n\t"
                "palignr $15, %%xmm0, %%xmm6\n\t"              
                "palignr $1, %%xmm1, %%xmm10\n\t"               
                "palignr $15, %%xmm1, %%xmm11\n\t"              
                "palignr $1, %%xmm2, %%xmm12\n\t"             
                "palignr $15, %%xmm2, %%xmm13\n\t"               
                "palignr $1, %%xmm3, %%xmm14\n\t"
#endif
                "movdqa  %4, %%xmm9\n\t" 
                "movdqa  %5, %%xmm15\n\t"


                "paddusb %%xmm7, %%xmm4\n\t"
                "paddusb %%xmm7, %%xmm5\n\t"
                "paddusb %%xmm7, %%xmm6\n\t"
                "paddusb %%xmm7, %%xmm10\n\t"
                "paddusb %%xmm7, %%xmm11\n\t"
                "paddusb %%xmm7, %%xmm12\n\t"
                "paddusb %%xmm7, %%xmm13\n\t"
                "paddusb %%xmm7, %%xmm14\n\t"
                
                
                "pminub %%xmm4, %%xmm0\n\t"
                "pminub %%xmm6, %%xmm1\n\t"
                
                "movdqa  %6, %%xmm4\n\t"
                "movdqa  %7, %%xmm6\n\t"
                
                "pminub %%xmm11, %%xmm2\n\t"
                "pminub %%xmm13, %%xmm3\n\t"
                "pminub %%xmm8, %%xmm5\n\t"
                "pminub %%xmm8, %%xmm10\n\t"
                "pminub %%xmm8, %%xmm12\n\t"
                "pminub %%xmm8, %%xmm14\n\t"
                "pminub %%xmm5, %%xmm0\n\t"
                "pminub %%xmm10, %%xmm1\n\t"
                "pminub %%xmm12, %%xmm2\n\t"
                "pminub %%xmm14, %%xmm3\n\t"
              
           
                
                "paddusb %%xmm9, %%xmm0\n\t"
                "paddusb %%xmm15, %%xmm1\n\t"
                "paddusb %%xmm4, %%xmm2\n\t"
                "paddusb %%xmm6, %%xmm3\n\t"

                "pxor %%xmm9, %%xmm9\n\t"
#ifdef __AVX__
                "vpminub %%xmm2, %%xmm0, %%xmm4\n\t"
                "vpminub %%xmm3, %%xmm1, %%xmm5\n\t"
#else                
                "pshufd $228,%%xmm0, %%xmm4\n\t"
                "pshufd $228,%%xmm1, %%xmm5\n\t"
                "pminub %%xmm2, %%xmm4\n\t"
                "pminub %%xmm3, %%xmm5\n\t"
#endif                
                "pminub %%xmm4, %%xmm5\n\t"
                
                
                "pshufd $78,%%xmm5, %%xmm4\n\t"
                "pminub %%xmm4, %%xmm5\n\t"
#ifdef __SSE4_1__                 
                "punpcklbw %%xmm5, %%xmm5\n\t"
                "phminposuw %%xmm5, %%xmm5\n\t"
#else
                "pshufd $1, %%xmm5, %%xmm4\n\t"
                "pminub %%xmm4, %%xmm5\n\t"
                "pshuflw $1, %%xmm5, %%xmm4\n\t"
                "pminub %%xmm4, %%xmm5\n\t"
                "punpcklbw %%xmm5, %%xmm5\n\t"
                "pshuflw $1, %%xmm5, %%xmm4\n\t"
                "pminub %%xmm4, %%xmm5\n\t" 
#endif                
                "pshufb %%xmm9, %%xmm5\n\t"

                "psubb %%xmm5, %%xmm0\n\t"
                "psubb %%xmm5, %%xmm1\n\t"
                "psubb %%xmm5, %%xmm2\n\t"
                "psubb %%xmm5, %%xmm3\n\t"
                               
                "movdqa  %%xmm0, %0\n\t"
                "movdqa  %%xmm1, %1\n\t"
                "movdqa  %%xmm2, %2\n\t"
                "movdqa  %%xmm3, %3\n\t"
            : "=m"(*disparityPathCube), "=m"(*(disparityPathCube+16)), "=m"(*(disparityPathCube+32)), "=m"(*(disparityPathCube+48)):  "m"(*disparityCube), "m"(*(disparityCube+16)),  "m"(*(disparityCube+32)), "m"(*(disparityCube+48)) : "%xmm0", "%xmm1", "%xmm2", "%xmm3","%xmm4", "%xmm5"
            );
        
           
}


// 80


 template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation0<80>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{

  #ifdef ENABLE_PREFETCH  
       _mm_prefetch(disparityCube,_MM_HINT_NTA); 
       _mm_prefetch(disparityCube+256,_MM_HINT_NTA); 
          
       _mm_prefetch(disparityPathCube,_MM_HINT_T0); 
       _mm_prefetch(disparityPathCube+256,_MM_HINT_T0);
 #endif 

            __asm__ volatile (  /// values in xmm0, xmm1, xmm2, xmm3, xmm4

                "movdqa   (%1), %%xmm0 \n\t"
                "movdqa 16(%1), %%xmm1 \n\t"
                "movdqa 32(%1), %%xmm2 \n\t"
                "movdqa 48(%1), %%xmm3 \n\t"
                "movdqa 64(%1), %%xmm4 \n\t"
                "movdqa   (%0), %%xmm10 \n\t"
                "movdqa 16(%0), %%xmm11 \n\t"
                "movdqa 32(%0), %%xmm12 \n\t"
                "movdqa 48(%0), %%xmm13 \n\t"
                "movdqa 64(%0), %%xmm14 \n\t"
#ifdef __AVX__
                "vpminub %%xmm1, %%xmm0, %%xmm5 \n\t"
                "vpminub %%xmm3, %%xmm2, %%xmm6 \n\t"
#else                
                "pshufd $228, %%xmm0, %%xmm5 \n\t"
                "pshufd $228, %%xmm2, %%xmm6 \n\t"
                "pminub %%xmm1, %%xmm5 \n\t"
                "pminub %%xmm3, %%xmm6 \n\t"
#endif                
                "pminub %%xmm4, %%xmm5 \n\t"
                "pminub %%xmm6, %%xmm5 \n\t"
                "pshufd $78, %%xmm5, %%xmm6 \n\t"
                "pminub %%xmm5, %%xmm6 \n\t"
#ifdef __SSE4_1__
                "punpcklbw %%xmm6, %%xmm6 \n\t"
                "phminposuw %%xmm6, %%xmm6 \n\t"
#else
                "pshufd $1, %%xmm6, %%xmm5 \n\t"
                "pminub %%xmm5, %%xmm6 \n\t"
                "pshuflw $1, %%xmm6, %%xmm5 \n\t"
                "pminub %%xmm5, %%xmm6 \n\t"
                "punpcklbw %%xmm6, %%xmm6 \n\t"
                "pshuflw $1, %%xmm6, %%xmm5 \n\t"
                "pminub %%xmm5, %%xmm6 \n\t"
#endif
                "pshufb %%xmm9, %%xmm6 \n\t"
                "psubb %%xmm6, %%xmm0 \n\t"
                "psubb %%xmm6, %%xmm1 \n\t"
                "psubb %%xmm6, %%xmm2 \n\t"
                "psubb %%xmm6, %%xmm3 \n\t"
                "psubb %%xmm6, %%xmm4 \n\t"
                "paddusb %%xmm0, %%xmm10 \n\t"
                "paddusb %%xmm1, %%xmm11 \n\t"
                "paddusb %%xmm2, %%xmm12 \n\t"
                "paddusb %%xmm3, %%xmm13 \n\t"
                "paddusb %%xmm4, %%xmm14 \n\t"
                "movdqa %%xmm10,   (%0) \n\t"
                "movdqa %%xmm11, 16(%0) \n\t"
                "movdqa %%xmm12, 32(%0) \n\t"
                "movdqa %%xmm13, 48(%0) \n\t"
                "movdqa %%xmm14, 64(%0) \n\t"
        :
        : "r"(disparityPathCube), "r"(disparityCube)
        : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm9", "%xmm10", "%xmm11", "%xmm12", "%xmm13", "%xmm14"
        );

}

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation<80>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{
    
#ifdef ENABLE_PREFETCH  
       _mm_prefetch(disparityCube,_MM_HINT_NTA); 
       _mm_prefetch(disparityCube+256,_MM_HINT_NTA);          
#endif 
        __asm__ volatile (  /// values in xmm0, xmm1, xmm2, xmm3, xmm4
            "movdqa   (%1), %%xmm14 \n\t"
            "movdqa 16(%1), %%xmm15 \n\t"
#ifdef __AVX__
            "vpalignr $15, %%xmm8, %%xmm0, %%xmm5 \n\t"
            "vpalignr  $1, %%xmm0, %%xmm1, %%xmm6 \n\t"
            "vpalignr $15, %%xmm0, %%xmm1, %%xmm10 \n\t"
            "vpalignr  $1, %%xmm1, %%xmm2, %%xmm11 \n\t"
            "vpalignr $15, %%xmm1, %%xmm2, %%xmm12 \n\t"
            "vpalignr  $1, %%xmm2, %%xmm3, %%xmm13 \n\t"
#else            
            "pshufd $228, %%xmm0, %%xmm5 \n\t"
            "pshufd $228, %%xmm1, %%xmm6 \n\t"
            "pshufd $228, %%xmm1, %%xmm10 \n\t"
            "pshufd $228, %%xmm2, %%xmm11 \n\t"
            "pshufd $228, %%xmm2, %%xmm12 \n\t"
            "pshufd $228, %%xmm3, %%xmm13 \n\t"
            "palignr $15, %%xmm8, %%xmm5 \n\t"
            "palignr  $1, %%xmm0, %%xmm6 \n\t"
            "palignr $15, %%xmm0, %%xmm10 \n\t"
            "palignr  $1, %%xmm1, %%xmm11 \n\t"
            "palignr $15, %%xmm1, %%xmm12 \n\t"
            "palignr  $1, %%xmm2, %%xmm13 \n\t"
#endif            
            "paddusb %%xmm7, %%xmm5 \n\t"
            "paddusb %%xmm7, %%xmm6 \n\t"
            "paddusb %%xmm7, %%xmm10 \n\t"
            "paddusb %%xmm7, %%xmm11 \n\t"
            "paddusb %%xmm7, %%xmm12 \n\t"
            "paddusb %%xmm7, %%xmm13 \n\t"
            "pminub %%xmm5,  %%xmm0 \n\t"
            "pminub %%xmm8,  %%xmm6 \n\t"
            "pminub %%xmm6,  %%xmm0 \n\t"
            "pminub %%xmm10, %%xmm1 \n\t"
            "pminub %%xmm8,  %%xmm11 \n\t"
            "pminub %%xmm11, %%xmm1 \n\t"
            "paddusb %%xmm14, %%xmm0 \n\t"
            "paddusb %%xmm15, %%xmm1 \n\t"
            "movdqa 32(%1), %%xmm14 \n\t"
            "movdqa 48(%1), %%xmm15 \n\t"
#ifdef __AVX__
            "vpalignr $15, %%xmm2, %%xmm3, %%xmm5 \n\t"
            "vpalignr  $1, %%xmm3, %%xmm4, %%xmm6 \n\t"
            "vpalignr $15, %%xmm3, %%xmm4, %%xmm10 \n\t"
            "vpalignr  $1, %%xmm4, %%xmm8, %%xmm11 \n\t"
#else            
            "pshufd $228, %%xmm3, %%xmm5 \n\t"
            "pshufd $228, %%xmm4, %%xmm6 \n\t"
            "pshufd $228, %%xmm4, %%xmm10 \n\t"
            "pshufd $228, %%xmm8, %%xmm11 \n\t"
            "palignr $15, %%xmm2, %%xmm5 \n\t"
            "palignr  $1, %%xmm3, %%xmm6 \n\t"
            "palignr $15, %%xmm3, %%xmm10 \n\t"
            "palignr  $1, %%xmm4, %%xmm11 \n\t"
#endif            
            "paddusb %%xmm7, %%xmm5 \n\t"
            "paddusb %%xmm7, %%xmm6 \n\t"
            "paddusb %%xmm7, %%xmm10 \n\t"
            "paddusb %%xmm7, %%xmm11 \n\t"
            "pminub %%xmm12, %%xmm2 \n\t"
            "movdqa 64(%1), %%xmm12 \n\t"
            "pminub %%xmm8,  %%xmm13 \n\t"
            "pminub %%xmm13, %%xmm2 \n\t"
            "pminub %%xmm5,  %%xmm3 \n\t"
            "pminub %%xmm8,  %%xmm6 \n\t"
            "pminub %%xmm6,  %%xmm3 \n\t"
            "pminub %%xmm10, %%xmm4 \n\t"
            "pminub %%xmm8,  %%xmm11 \n\t"
            "pminub %%xmm11, %%xmm4 \n\t"
            "paddusb %%xmm14, %%xmm2 \n\t"
            "paddusb %%xmm15, %%xmm3 \n\t"
            "paddusb %%xmm12, %%xmm4 \n\t"
            "movdqa   (%0), %%xmm10\n\t" 
            "movdqa 16(%0), %%xmm11\n\t" 
            "movdqa 32(%0), %%xmm12\n\t" 
            "movdqa 48(%0), %%xmm13\n\t" 
            "movdqa 64(%0), %%xmm14\n\t"
#ifdef __AVX__
            "vpminub %%xmm1, %%xmm0, %%xmm5 \n\t"
            "vpminub %%xmm3, %%xmm2, %%xmm6 \n\t"
#else            
            "pshufd $228, %%xmm0, %%xmm5 \n\t"
            "pshufd $228, %%xmm2, %%xmm6 \n\t"
            "pminub %%xmm1, %%xmm5 \n\t"
            "pminub %%xmm3, %%xmm6 \n\t"
#endif            
            "pminub %%xmm4, %%xmm5 \n\t"
            "pminub %%xmm6, %%xmm5 \n\t"
            "pshufd $78, %%xmm5, %%xmm6 \n\t"
            "pminub %%xmm5, %%xmm6 \n\t"
#ifdef __SSE4_1__
            "punpcklbw %%xmm6, %%xmm6 \n\t"
            "phminposuw %%xmm6, %%xmm6 \n\t"
#else
            "pshufd $1, %%xmm6, %%xmm5 \n\t"
            "pminub %%xmm5, %%xmm6 \n\t"
            "pshuflw $1, %%xmm6, %%xmm5 \n\t"
            "pminub %%xmm5, %%xmm6 \n\t"
            "punpcklbw %%xmm6, %%xmm6 \n\t"
            "pshuflw $1, %%xmm6, %%xmm5 \n\t"
            "pminub %%xmm5, %%xmm6 \n\t"
#endif
            "pshufb %%xmm9, %%xmm6 \n\t"
            "psubb %%xmm6, %%xmm0 \n\t"
            "psubb %%xmm6, %%xmm1 \n\t"
            "psubb %%xmm6, %%xmm2 \n\t"
            "psubb %%xmm6, %%xmm3 \n\t"
            "psubb %%xmm6, %%xmm4 \n\t"
            "paddusb %%xmm0, %%xmm10 \n\t"
            "paddusb %%xmm1, %%xmm11 \n\t"
            "paddusb %%xmm2, %%xmm12 \n\t"
            "paddusb %%xmm3, %%xmm13 \n\t"
            "paddusb %%xmm4, %%xmm14 \n\t"
            "movdqa %%xmm10,   (%0) \n\t"
            "movdqa %%xmm11, 16(%0) \n\t"
            "movdqa %%xmm12, 32(%0) \n\t"
            "movdqa %%xmm13, 48(%0) \n\t"
            "movdqa %%xmm14, 64(%0) \n\t"   
    :
    : "r"(disparityPathCube), "r"(disparityCube)
    : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7", "%xmm8", "%xmm9", "%xmm10", "%xmm11", "%xmm12", "%xmm13", "%xmm14", "%xmm15"
    );

}

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation0_0<80>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{

    #ifdef ENABLE_PREFETCH    
      _mm_prefetch(disparityCube,_MM_HINT_NTA); 
      _mm_prefetch(disparityCube+256,_MM_HINT_NTA); 
    #endif

    __asm__ volatile (  /// values in xmm0, xmm1, xmm2, xmm3, xmm4

        "movdqa   (%1), %%xmm0 \n\t"
        "movdqa 16(%1), %%xmm1 \n\t"
        "movdqa 32(%1), %%xmm2 \n\t"
        "movdqa 48(%1), %%xmm3 \n\t"
        "movdqa 64(%1), %%xmm4 \n\t"
#ifdef __AVX__
        "vpminub %%xmm1, %%xmm0, %%xmm5 \n\t"
        "vpminub %%xmm3, %%xmm2, %%xmm6 \n\t"
#else        
        "pshufd $228, %%xmm0, %%xmm5 \n\t"
        "pshufd $228, %%xmm2, %%xmm6 \n\t"
        "pminub %%xmm1, %%xmm5 \n\t"
        "pminub %%xmm3, %%xmm6 \n\t"
#endif        
        "pminub %%xmm4, %%xmm5 \n\t"
        "pminub %%xmm6, %%xmm5 \n\t"
        "pshufd $78, %%xmm5, %%xmm6 \n\t"
        "pminub %%xmm5, %%xmm6 \n\t"
#ifdef __SSE4_1__
        "punpcklbw %%xmm6, %%xmm6 \n\t"
        "phminposuw %%xmm6, %%xmm6 \n\t"
#else
        "pshufd $1, %%xmm6, %%xmm5 \n\t"
        "pminub %%xmm5, %%xmm6 \n\t"
        "pshuflw $1, %%xmm6, %%xmm5 \n\t"
        "pminub %%xmm5, %%xmm6 \n\t"
        "punpcklbw %%xmm6, %%xmm6 \n\t"
        "pshuflw $1, %%xmm6, %%xmm5 \n\t"
        "pminub %%xmm5, %%xmm6 \n\t"
#endif
        "pshufb %%xmm9, %%xmm6 \n\t"
        "psubb %%xmm6, %%xmm0 \n\t"
        "psubb %%xmm6, %%xmm1 \n\t"
        "psubb %%xmm6, %%xmm2 \n\t"
        "psubb %%xmm6, %%xmm3 \n\t"
        "psubb %%xmm6, %%xmm4 \n\t"
        "movdqa %%xmm0,   (%0) \n\t"
        "movdqa %%xmm1, 16(%0) \n\t"
        "movdqa %%xmm2, 32(%0) \n\t"
        "movdqa %%xmm3, 48(%0) \n\t"
        "movdqa %%xmm4, 64(%0) \n\t"  
   :
   : "r"(disparityPathCube), "r"(disparityCube)
   : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm9"
    );

}

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation_0<80>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{

#ifdef ENABLE_PREFETCH    
           _mm_prefetch(disparityCube-64,_MM_HINT_NTA); 
           _mm_prefetch(disparityCube-64+256,_MM_HINT_NTA);             
#endif

    __asm__ volatile (  /// values in xmm0, xmm1, xmm2, xmm3, xmm4
        "movdqa   (%1), %%xmm14 \n\t"
        "movdqa 16(%1), %%xmm15 \n\t"
#ifdef __AVX__ 
        "vpalignr $15, %%xmm8, %%xmm0, %%xmm5 \n\t"
        "vpalignr  $1, %%xmm0, %%xmm1, %%xmm6 \n\t"
        "vpalignr $15, %%xmm0, %%xmm1, %%xmm10 \n\t"
        "vpalignr  $1, %%xmm1, %%xmm2, %%xmm11 \n\t"
        "vpalignr $15, %%xmm1, %%xmm2, %%xmm12 \n\t"
        "vpalignr  $1, %%xmm2, %%xmm3,%%xmm13 \n\t"
#else        
        "pshufd $228, %%xmm0, %%xmm5 \n\t"
        "pshufd $228, %%xmm1, %%xmm6 \n\t"
        "pshufd $228, %%xmm1, %%xmm10 \n\t"
        "pshufd $228, %%xmm2, %%xmm11 \n\t"
        "pshufd $228, %%xmm2, %%xmm12 \n\t"
        "pshufd $228, %%xmm3, %%xmm13 \n\t"
        "palignr $15, %%xmm8, %%xmm5 \n\t"
        "palignr  $1, %%xmm0, %%xmm6 \n\t"
        "palignr $15, %%xmm0, %%xmm10 \n\t"
        "palignr  $1, %%xmm1, %%xmm11 \n\t"
        "palignr $15, %%xmm1, %%xmm12 \n\t"
        "palignr  $1, %%xmm2, %%xmm13 \n\t"
#endif        
        "paddusb %%xmm7, %%xmm5 \n\t"
        "paddusb %%xmm7, %%xmm6 \n\t"
        "paddusb %%xmm7, %%xmm10 \n\t"
        "paddusb %%xmm7, %%xmm11 \n\t"
        "paddusb %%xmm7, %%xmm12 \n\t"
        "paddusb %%xmm7, %%xmm13 \n\t"
        "pminub %%xmm5,  %%xmm0 \n\t"
        "pminub %%xmm8,  %%xmm6 \n\t"
        "pminub %%xmm6,  %%xmm0 \n\t"
        "pminub %%xmm10, %%xmm1 \n\t"
        "pminub %%xmm8,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm1 \n\t"
        "paddusb %%xmm14, %%xmm0 \n\t"
        "paddusb %%xmm15, %%xmm1 \n\t"
        "movdqa 32(%1), %%xmm14 \n\t"
        "movdqa 48(%1), %%xmm15 \n\t"
#ifdef __AVX__
        "vpalignr $15, %%xmm2, %%xmm3, %%xmm5 \n\t"
        "vpalignr  $1, %%xmm3, %%xmm4, %%xmm6 \n\t"
        "vpalignr $15, %%xmm3, %%xmm4, %%xmm10 \n\t"
        "vpalignr  $1, %%xmm4, %%xmm8, %%xmm11 \n\t"
#else        
        "pshufd $228, %%xmm3, %%xmm5 \n\t"
        "pshufd $228, %%xmm4, %%xmm6 \n\t"
        "pshufd $228, %%xmm4, %%xmm10 \n\t"
        "pshufd $228, %%xmm8, %%xmm11 \n\t"
        "palignr $15, %%xmm2, %%xmm5 \n\t"
        "palignr  $1, %%xmm3, %%xmm6 \n\t"
        "palignr $15, %%xmm3, %%xmm10 \n\t"
        "palignr  $1, %%xmm4, %%xmm11 \n\t"
#endif        
        "paddusb %%xmm7, %%xmm5 \n\t"
        "paddusb %%xmm7, %%xmm6 \n\t"
        "paddusb %%xmm7, %%xmm10 \n\t"
        "paddusb %%xmm7, %%xmm11 \n\t"
        "pminub %%xmm12, %%xmm2 \n\t"
        "movdqa 64(%1), %%xmm12 \n\t"
        "pminub %%xmm8,  %%xmm13 \n\t"
        "pminub %%xmm13, %%xmm2 \n\t"
        "pminub %%xmm5,  %%xmm3 \n\t"
        "pminub %%xmm8,  %%xmm6 \n\t"
        "pminub %%xmm6,  %%xmm3 \n\t"
        "pminub %%xmm10, %%xmm4 \n\t"
        "pminub %%xmm8,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm4 \n\t"
        "paddusb %%xmm14, %%xmm2 \n\t"
        "paddusb %%xmm15, %%xmm3 \n\t"
        "paddusb %%xmm12, %%xmm4 \n\t"
#ifdef __AVX__ 
        "vpminub %%xmm1, %%xmm0, %%xmm5 \n\t"
        "vpminub %%xmm3, %%xmm2, %%xmm6 \n\t"
#else        
        "pshufd $228, %%xmm0, %%xmm5 \n\t"
        "pshufd $228, %%xmm2, %%xmm6 \n\t"
        "pminub %%xmm1, %%xmm5 \n\t"
        "pminub %%xmm3, %%xmm6 \n\t"
#endif       
        "pminub %%xmm4, %%xmm5 \n\t"
        "pminub %%xmm6, %%xmm5 \n\t"
        "pshufd $78, %%xmm5, %%xmm6 \n\t"
        "pminub %%xmm5, %%xmm6 \n\t"
#ifdef __SSE4_1__
        "punpcklbw %%xmm6, %%xmm6 \n\t"
        "phminposuw %%xmm6, %%xmm6 \n\t"
#else
        "pshufd $1, %%xmm6, %%xmm5 \n\t"
        "pminub %%xmm5, %%xmm6 \n\t"
        "pshuflw $1, %%xmm6, %%xmm5 \n\t"
        "pminub %%xmm5, %%xmm6 \n\t"
        "punpcklbw %%xmm6, %%xmm6 \n\t"
        "pshuflw $1, %%xmm6, %%xmm5 \n\t"
        "pminub %%xmm5, %%xmm6 \n\t"
#endif
        "pshufb %%xmm9, %%xmm6 \n\t"
        "psubb %%xmm6, %%xmm0 \n\t"
        "psubb %%xmm6, %%xmm1 \n\t"
        "psubb %%xmm6, %%xmm2 \n\t"
        "psubb %%xmm6, %%xmm3 \n\t"
        "psubb %%xmm6, %%xmm4 \n\t"
        "movdqa %%xmm0,   (%0) \n\t"
        "movdqa %%xmm1, 16(%0) \n\t"
        "movdqa %%xmm2, 32(%0) \n\t"
        "movdqa %%xmm3, 48(%0) \n\t"
        "movdqa %%xmm4, 64(%0) \n\t"   
   :
   : "r"(disparityPathCube), "r"(disparityCube)
   : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7", "%xmm8", "%xmm9", "%xmm10", "%xmm11", "%xmm12", "%xmm13", "%xmm14", "%xmm15"
    );

}




//96

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation0<96>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{

    __asm__ volatile (  /// values in xmm0, xmm1, xmm2, xmm3, xmm4, xmm5
        "movdqa   (%1), %%xmm0 \n\t"
        "movdqa 16(%1), %%xmm1 \n\t"
        "movdqa 32(%1), %%xmm2 \n\t"
        "movdqa 48(%1), %%xmm3 \n\t"
        "movdqa 64(%1), %%xmm4 \n\t"
        "movdqa 80(%1), %%xmm5 \n\t"
        "movdqa   (%0), %%xmm12 \n\t"
        "movdqa 16(%0), %%xmm13 \n\t"
        "movdqa 32(%0), %%xmm14 \n\t"
        "movdqa 48(%0), %%xmm15 \n\t"
#ifdef __AVX__	
        "vpminub %%xmm1, %%xmm0, %%xmm10 \n\t"
        "vpminub %%xmm4, %%xmm3, %%xmm11 \n\t"
#else	
        "pshufd $228, %%xmm0, %%xmm10 \n\t"
        "pshufd $228, %%xmm3, %%xmm11 \n\t"
        "pminub %%xmm1,  %%xmm10 \n\t"
        "pminub %%xmm4,  %%xmm11 \n\t"
#endif	
        "pminub %%xmm2,  %%xmm10 \n\t"
        "pminub %%xmm5,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm10 \n\t"
        "pshufd $78, %%xmm10, %%xmm11 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
#ifdef __SSE4_1__
        "punpcklbw %%xmm11, %%xmm11 \n\t"
        "phminposuw %%xmm11, %%xmm11 \n\t"
#else
        "pshufd $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
        "pshuflw $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
        "punpcklbw %%xmm11, %%xmm11 \n\t"
        "pshuflw $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
#endif
        "pshufb %%xmm9, %%xmm11 \n\t"
        "psubb %%xmm11, %%xmm0 \n\t"
        "psubb %%xmm11, %%xmm1 \n\t"
        "psubb %%xmm11, %%xmm2 \n\t"
        "psubb %%xmm11, %%xmm3 \n\t"
        "psubb %%xmm11, %%xmm4 \n\t"
        "psubb %%xmm11, %%xmm5 \n\t"
        "movdqa 64(%0), %%xmm10 \n\t"
        "movdqa 80(%0), %%xmm11 \n\t"
        "paddusb %%xmm0, %%xmm12\n\t"
        "movdqa %%xmm12,   (%0) \n\t"
        "paddusb %%xmm1, %%xmm13\n\t"
        "movdqa %%xmm13, 16(%0) \n\t"
        "paddusb %%xmm2, %%xmm14\n\t"
        "movdqa %%xmm14, 32(%0) \n\t"
        "paddusb %%xmm3, %%xmm15\n\t"
        "movdqa %%xmm15, 48(%0) \n\t"
        "paddusb %%xmm4, %%xmm10\n\t"
        "movdqa %%xmm10, 64(%0) \n\t"
        "paddusb %%xmm5, %%xmm11\n\t"
        "movdqa %%xmm11, 80(%0) \n\t" 
   :
   : "r"(disparityPathCube), "r"(disparityCube)
   : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm9", "%xmm10", "%xmm11"
    );

}

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation<96>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{

    __asm__ volatile (  /// values in xmm0, xmm1, xmm2, xmm3, xmm4, xmm5
        "movdqa   (%1), %%xmm14 \n\t"
        "movdqa 16(%1), %%xmm15 \n\t"
#ifdef __AVX__
	"vpalignr $15, %%xmm8, %%xmm0, %%xmm10 \n\t"
        "vpalignr  $1, %%xmm0, %%xmm1, %%xmm11 \n\t"
        "vpalignr $15, %%xmm0, %%xmm1, %%xmm12 \n\t"
        "vpalignr  $1, %%xmm1, %%xmm2, %%xmm13 \n\t"
#else	
        "pshufd $228, %%xmm0, %%xmm10 \n\t"
        "pshufd $228, %%xmm1, %%xmm11 \n\t"
        "pshufd $228, %%xmm1, %%xmm12 \n\t"
        "pshufd $228, %%xmm2, %%xmm13 \n\t"
        "palignr $15, %%xmm8, %%xmm10 \n\t"
        "palignr  $1, %%xmm0, %%xmm11 \n\t"
        "palignr $15, %%xmm0, %%xmm12 \n\t"
        "palignr  $1, %%xmm1, %%xmm13 \n\t"
#endif	
        "paddusb %%xmm7, %%xmm10 \n\t"
        "paddusb %%xmm7, %%xmm11 \n\t"
        "paddusb %%xmm7, %%xmm12 \n\t"
        "paddusb %%xmm7, %%xmm13 \n\t"
        "pminub %%xmm10, %%xmm0 \n\t"
        "pminub %%xmm8,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm0 \n\t"
        "paddusb %%xmm14, %%xmm0 \n\t"
        "movdqa 32(%1), %%xmm14 \n\t"
#ifdef __AVX__
	"vpalignr $15, %%xmm1, %%xmm2, %%xmm10 \n\t"
        "vpalignr  $1, %%xmm2, %%xmm3, %%xmm11 \n\t"
#else	
        "pshufd $228, %%xmm2, %%xmm10 \n\t"
        "pshufd $228, %%xmm3, %%xmm11 \n\t"
        "palignr $15, %%xmm1, %%xmm10 \n\t"
        "palignr  $1, %%xmm2, %%xmm11 \n\t"
#endif	
        "paddusb %%xmm7, %%xmm10 \n\t"
        "paddusb %%xmm7, %%xmm11 \n\t"
        "pminub %%xmm12, %%xmm1 \n\t"
        "pminub %%xmm8,  %%xmm13 \n\t"
        "pminub %%xmm13, %%xmm1 \n\t"
        "paddusb %%xmm15, %%xmm1 \n\t"
        "movdqa 48(%1), %%xmm15 \n\t"
#ifdef __AVX__
        "vpalignr $15, %%xmm2, %%xmm3, %%xmm12 \n\t"
        "vpalignr  $1, %%xmm3, %%xmm4, %%xmm13 \n\t"
#else	
        "pshufd $228, %%xmm3, %%xmm12 \n\t"
        "pshufd $228, %%xmm4, %%xmm13 \n\t"
        "palignr $15, %%xmm2, %%xmm12 \n\t"
        "palignr  $1, %%xmm3, %%xmm13 \n\t"
#endif
	"paddusb %%xmm7, %%xmm12 \n\t"
        "paddusb %%xmm7, %%xmm13 \n\t"
        "pminub %%xmm10, %%xmm2 \n\t"
        "pminub %%xmm8,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm2 \n\t"
        "paddusb %%xmm14, %%xmm2 \n\t"
        "movdqa 64(%1), %%xmm14 \n\t"
#ifdef __AVX__
        "vpalignr $15, %%xmm3, %%xmm4, %%xmm10 \n\t"
        "vpalignr  $1, %%xmm4, %%xmm5, %%xmm11 \n\t"
#else        
        "pshufd $228, %%xmm4, %%xmm10 \n\t"
        "pshufd $228, %%xmm5, %%xmm11 \n\t"
        "palignr $15, %%xmm3, %%xmm10 \n\t"
        "palignr  $1, %%xmm4, %%xmm11 \n\t"
#endif        
        "paddusb %%xmm7, %%xmm10 \n\t"
        "paddusb %%xmm7, %%xmm11 \n\t"
        "pminub %%xmm12, %%xmm3 \n\t"
        "pminub %%xmm8,  %%xmm13 \n\t"
        "pminub %%xmm13, %%xmm3 \n\t"
        "paddusb %%xmm15, %%xmm3 \n\t"
        "movdqa 80(%1), %%xmm15 \n\t"
#ifdef __AVX__
        "vpalignr $15, %%xmm4, %%xmm5, %%xmm12 \n\t"
        "vpalignr  $1, %%xmm5, %%xmm8, %%xmm13 \n\t"
#else        
        "pshufd $228, %%xmm5, %%xmm12 \n\t"
        "pshufd $228, %%xmm8, %%xmm13 \n\t"
        "palignr $15, %%xmm4, %%xmm12 \n\t"
        "palignr  $1, %%xmm5, %%xmm13 \n\t"
#endif        
        "paddusb %%xmm7, %%xmm12 \n\t"
        "paddusb %%xmm7, %%xmm13 \n\t"
        "pminub %%xmm10, %%xmm4 \n\t"
        "pminub %%xmm8,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm4 \n\t"
        "pminub %%xmm12, %%xmm5 \n\t"
        "pminub %%xmm8,  %%xmm13 \n\t"
        "pminub %%xmm13, %%xmm5 \n\t"
        "paddusb %%xmm14, %%xmm4 \n\t"
        "paddusb %%xmm15, %%xmm5 \n\t"
#ifdef __AVX__
        "vpminub %%xmm1, %%xmm0, %%xmm10 \n\t"
        "vpminub %%xmm4, %%xmm3, %%xmm11 \n\t"
#else        
        "pshufd $228, %%xmm0, %%xmm10 \n\t"
        "pshufd $228, %%xmm3, %%xmm11 \n\t"
        "pminub %%xmm1,  %%xmm10 \n\t"
        "pminub %%xmm4,  %%xmm11 \n\t"
#endif        
        "pminub %%xmm2,  %%xmm10 \n\t"
        "pminub %%xmm5,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm10 \n\t"
        "pshufd $78, %%xmm10, %%xmm11 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
#ifdef __SSE4_1__
        "punpcklbw %%xmm11, %%xmm11 \n\t"
        "phminposuw %%xmm11, %%xmm11 \n\t"
#else
        "pshufd $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
        "pshuflw $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
        "punpcklbw %%xmm11, %%xmm11 \n\t"
        "pshuflw $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
#endif
        "pshufb %%xmm9, %%xmm11 \n\t"
        "movdqa   (%0), %%xmm10 \n\t" 
        "movdqa 16(%0), %%xmm9 \n\t" 
        "movdqa 32(%0), %%xmm12 \n\t" 
        "movdqa 48(%0), %%xmm13 \n\t" 
        "movdqa 64(%0), %%xmm14 \n\t"
        "movdqa 80(%0), %%xmm15 \n\t"
        "psubb %%xmm11, %%xmm0 \n\t"
        "psubb %%xmm11, %%xmm1 \n\t"
        "psubb %%xmm11, %%xmm2 \n\t"
        "psubb %%xmm11, %%xmm3 \n\t"
        "psubb %%xmm11, %%xmm4 \n\t"
        "psubb %%xmm11, %%xmm5 \n\t"
        "paddusb %%xmm0, %%xmm10 \n\t"
        "movdqa %%xmm10,   (%0) \n\t" 
        "paddusb %%xmm1, %%xmm9 \n\t"
        "movdqa %%xmm9,  16(%0) \n\t"
        "pxor %%xmm9, %%xmm9 \n\t"
        "paddusb %%xmm2, %%xmm12 \n\t" 
        "movdqa %%xmm12, 32(%0) \n\t"
        "paddusb %%xmm3, %%xmm13 \n\t"  
        "movdqa %%xmm13, 48(%0) \n\t"
        "paddusb %%xmm4, %%xmm14 \n\t" 
        "movdqa %%xmm14, 64(%0) \n\t"
        "paddusb %%xmm5, %%xmm15 \n\t"
        "movdqa %%xmm15, 80(%0) \n\t"   
   :
   : "r"(disparityPathCube), "r"(disparityCube)
   : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7", "%xmm8", "%xmm9", "%xmm10", "%xmm11", "%xmm12", "%xmm13", "%xmm14", "%xmm15"
    );

}

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation0_0<96>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{

    __asm__ volatile (  /// values in xmm0, xmm1, xmm2, xmm3, xmm4, xmm5
        "movdqa   (%1), %%xmm0 \n\t"
        "movdqa 16(%1), %%xmm1 \n\t"
        "movdqa 32(%1), %%xmm2 \n\t"
        "movdqa 48(%1), %%xmm3 \n\t"
        "movdqa 64(%1), %%xmm4 \n\t"
        "movdqa 80(%1), %%xmm5 \n\t"
#ifdef __AVX__
        "vpminub %%xmm1, %%xmm0, %%xmm10 \n\t"
        "vpminub %%xmm4, %%xmm3, %%xmm11 \n\t"
#else	
        "pshufd $228, %%xmm0, %%xmm10 \n\t"
        "pshufd $228, %%xmm3, %%xmm11 \n\t"
        "pminub %%xmm1,  %%xmm10 \n\t"
        "pminub %%xmm4,  %%xmm11 \n\t"
#endif	
        "pminub %%xmm2,  %%xmm10 \n\t"
        "pminub %%xmm5,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm10 \n\t"
        "pshufd $78, %%xmm10, %%xmm11 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
#ifdef __SSE4_1__
        "punpcklbw %%xmm11, %%xmm11 \n\t"
        "phminposuw %%xmm11, %%xmm11 \n\t"
#else
        "pshufd $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
        "pshuflw $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
        "punpcklbw %%xmm11, %%xmm11 \n\t"
        "pshuflw $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
#endif
        "pshufb %%xmm9, %%xmm11 \n\t"
        "psubb %%xmm11, %%xmm0 \n\t"
        "psubb %%xmm11, %%xmm1 \n\t"
        "psubb %%xmm11, %%xmm2 \n\t"
        "psubb %%xmm11, %%xmm3 \n\t"
        "psubb %%xmm11, %%xmm4 \n\t"
        "psubb %%xmm11, %%xmm5 \n\t"
        "movdqa %%xmm0,   (%0) \n\t"
        "movdqa %%xmm1, 16(%0) \n\t"
        "movdqa %%xmm2, 32(%0) \n\t"
        "movdqa %%xmm3, 48(%0) \n\t"
        "movdqa %%xmm4, 64(%0) \n\t"
        "movdqa %%xmm5, 80(%0) \n\t"
   :
   : "r"(disparityPathCube), "r"(disparityCube)
   : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm9", "%xmm10", "%xmm11"
    );

}

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation_0<96>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{

    __asm__ volatile (  /// values in xmm0, xmm1, xmm2, xmm3, xmm4, xmm5
        "movdqa   (%1), %%xmm14 \n\t"
        "movdqa 16(%1), %%xmm15 \n\t"
#ifdef __AVX__
	"vpalignr $15, %%xmm8, %%xmm0, %%xmm10 \n\t"
        "vpalignr  $1, %%xmm0, %%xmm1, %%xmm11 \n\t"
        "vpalignr $15, %%xmm0, %%xmm1, %%xmm12 \n\t"
        "vpalignr  $1, %%xmm1, %%xmm2, %%xmm13 \n\t"
#else
        "pshufd $228, %%xmm0, %%xmm10 \n\t"
        "pshufd $228, %%xmm1, %%xmm11 \n\t"
        "pshufd $228, %%xmm1, %%xmm12 \n\t"
        "pshufd $228, %%xmm2, %%xmm13 \n\t"
        "palignr $15, %%xmm8, %%xmm10 \n\t"
        "palignr  $1, %%xmm0, %%xmm11 \n\t"
        "palignr $15, %%xmm0, %%xmm12 \n\t"
        "palignr  $1, %%xmm1, %%xmm13 \n\t"
#endif	
        "paddusb %%xmm7, %%xmm10 \n\t"
        "paddusb %%xmm7, %%xmm11 \n\t"
        "paddusb %%xmm7, %%xmm12 \n\t"
        "paddusb %%xmm7, %%xmm13 \n\t"
        "pminub %%xmm10, %%xmm0 \n\t"
        "pminub %%xmm8,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm0 \n\t"
        "paddusb %%xmm14, %%xmm0 \n\t"
        "movdqa 32(%1), %%xmm14 \n\t"
#ifdef __AVX__
	"vpalignr $15, %%xmm1, %%xmm2, %%xmm10 \n\t"
        "vpalignr  $1, %%xmm2, %%xmm3, %%xmm11 \n\t"
#else	
        "pshufd $228, %%xmm2, %%xmm10 \n\t"
        "pshufd $228, %%xmm3, %%xmm11 \n\t"
        "palignr $15, %%xmm1, %%xmm10 \n\t"
        "palignr  $1, %%xmm2, %%xmm11 \n\t"
#endif	
        "paddusb %%xmm7, %%xmm10 \n\t"
        "paddusb %%xmm7, %%xmm11 \n\t"
        "pminub %%xmm12, %%xmm1 \n\t"
        "pminub %%xmm8,  %%xmm13 \n\t"
        "pminub %%xmm13, %%xmm1 \n\t"
        "paddusb %%xmm15, %%xmm1 \n\t"
        "movdqa 48(%1), %%xmm15 \n\t"
#ifdef __AVX__
	"vpalignr $15, %%xmm2, %%xmm3, %%xmm12 \n\t"
        "vpalignr  $1, %%xmm3, %%xmm4, %%xmm13 \n\t"
#else	
        "pshufd $228, %%xmm3, %%xmm12 \n\t"
        "pshufd $228, %%xmm4, %%xmm13 \n\t"
        "palignr $15, %%xmm2, %%xmm12 \n\t"
        "palignr  $1, %%xmm3, %%xmm13 \n\t"
#endif	
        "paddusb %%xmm7, %%xmm12 \n\t"
        "paddusb %%xmm7, %%xmm13 \n\t"
        "pminub %%xmm10, %%xmm2 \n\t"
        "pminub %%xmm8,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm2 \n\t"
        "paddusb %%xmm14, %%xmm2 \n\t"
        "movdqa 64(%1), %%xmm14 \n\t"
#ifdef __AVX__
	"vpalignr $15, %%xmm3, %%xmm4, %%xmm10 \n\t"
        "vpalignr  $1, %%xmm4, %%xmm5, %%xmm11 \n\t"
#else	
        "pshufd $228, %%xmm4, %%xmm10 \n\t"
        "pshufd $228, %%xmm5, %%xmm11 \n\t"
        "palignr $15, %%xmm3, %%xmm10 \n\t"
        "palignr  $1, %%xmm4, %%xmm11 \n\t"
#endif	
        "paddusb %%xmm7, %%xmm10 \n\t"
        "paddusb %%xmm7, %%xmm11 \n\t"
        "pminub %%xmm12, %%xmm3 \n\t"
        "pminub %%xmm8,  %%xmm13 \n\t"
        "pminub %%xmm13, %%xmm3 \n\t"
        "paddusb %%xmm15, %%xmm3 \n\t"
        "movdqa 80(%1), %%xmm15 \n\t"
#ifdef __AVX__	
	"vpalignr $15, %%xmm4,  %%xmm5, %%xmm12 \n\t"
        "vpalignr  $1, %%xmm5,  %%xmm8, %%xmm13 \n\t"
#else	
        "pshufd $228, %%xmm5, %%xmm12 \n\t"
        "pshufd $228, %%xmm8, %%xmm13 \n\t"
        "palignr $15, %%xmm4, %%xmm12 \n\t"
        "palignr  $1, %%xmm5, %%xmm13 \n\t"
#endif	
        "paddusb %%xmm7, %%xmm12 \n\t"
        "paddusb %%xmm7, %%xmm13 \n\t"
        "pminub %%xmm10, %%xmm4 \n\t"
        "pminub %%xmm8,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm4 \n\t"
        "pminub %%xmm12, %%xmm5 \n\t"
        "pminub %%xmm8,  %%xmm13 \n\t"
        "pminub %%xmm13, %%xmm5 \n\t"
        "paddusb %%xmm14, %%xmm4 \n\t"
        "paddusb %%xmm15, %%xmm5 \n\t"
#ifdef __AVX__
        "vpminub %%xmm1, %%xmm0, %%xmm10 \n\t"
	"vpminub %%xmm4, %%xmm3, %%xmm11 \n\t"
#else	
        "pshufd $228, %%xmm0, %%xmm10 \n\t"
        "pshufd $228, %%xmm3, %%xmm11 \n\t"
        "pminub %%xmm1,  %%xmm10 \n\t"
	"pminub %%xmm4,  %%xmm11 \n\t"
#endif	
        "pminub %%xmm2,  %%xmm10 \n\t"
        "pminub %%xmm5,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm10 \n\t"
        "pshufd $78, %%xmm10, %%xmm11 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
#ifdef __SSE4_1__
        "punpcklbw %%xmm11, %%xmm11 \n\t"
        "phminposuw %%xmm11, %%xmm11 \n\t"
#else
        "pshufd $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
        "pshuflw $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
        "punpcklbw %%xmm11, %%xmm11 \n\t"
        "pshuflw $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
#endif
        "pshufb %%xmm9, %%xmm11 \n\t"
        "psubb %%xmm11, %%xmm0 \n\t"
        "psubb %%xmm11, %%xmm1 \n\t"
        "psubb %%xmm11, %%xmm2 \n\t"
        "psubb %%xmm11, %%xmm3 \n\t"
        "psubb %%xmm11, %%xmm4 \n\t"
        "psubb %%xmm11, %%xmm5 \n\t"
        "movdqa %%xmm0,   (%0) \n\t"
        "movdqa %%xmm1, 16(%0) \n\t"
        "movdqa %%xmm2, 32(%0) \n\t"
        "movdqa %%xmm3, 48(%0) \n\t"
        "movdqa %%xmm4, 64(%0) \n\t"
        "movdqa %%xmm5, 80(%0) \n\t"
   :
   : "r"(disparityPathCube), "r"(disparityCube)
   : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7", "%xmm8", "%xmm9", "%xmm10", "%xmm11", "%xmm12", "%xmm13", "%xmm14", "%xmm15"
    );

}

//112

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation0<112>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{

      #ifdef ENABLE_PREFETCH  
       _mm_prefetch(disparityCube,_MM_HINT_NTA); 
       _mm_prefetch(disparityCube+256,_MM_HINT_NTA);         
     #endif 

    __asm__ volatile (  /// values in xmm0, xmm1, xmm2, xmm3, xmm4, xmm5, xmm6
        "movdqa   (%1), %%xmm0 \n\t"
        "movdqa 16(%1), %%xmm1 \n\t"
        "movdqa 32(%1), %%xmm2 \n\t"
        "movdqa 48(%1), %%xmm3 \n\t"
        "movdqa 64(%1), %%xmm4 \n\t"
        "movdqa 80(%1), %%xmm5 \n\t"
        "movdqa 96(%1), %%xmm6 \n\t"
        "movdqa   (%0), %%xmm12 \n\t"
        "movdqa 16(%0), %%xmm13 \n\t"
        "movdqa 32(%0), %%xmm14 \n\t"
        "movdqa 48(%0), %%xmm15 \n\t"
#ifdef __AVX__
        "vpminub %%xmm1, %%xmm0, %%xmm10 \n\t"
        "vpminub %%xmm4, %%xmm3, %%xmm11 \n\t"
#else        
        "pshufd $228, %%xmm0, %%xmm10 \n\t"
        "pshufd $228, %%xmm3, %%xmm11 \n\t"
        "pminub %%xmm1,  %%xmm10 \n\t"
        "pminub %%xmm4,  %%xmm11 \n\t"        
#endif        
        "pminub %%xmm2,  %%xmm10 \n\t"
        "pminub %%xmm5,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm6,  %%xmm10 \n\t"
        "pshufd $78, %%xmm10, %%xmm11 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
#ifdef __SSE4_1__
        "punpcklbw %%xmm11, %%xmm11 \n\t"
        "phminposuw %%xmm11, %%xmm11 \n\t"
#else
        "pshufd $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
        "pshuflw $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
        "punpcklbw %%xmm11, %%xmm11 \n\t"
        "pshuflw $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
#endif
        "pshufb %%xmm9, %%xmm11 \n\t"
        "psubb %%xmm11, %%xmm0 \n\t"
        "psubb %%xmm11, %%xmm1 \n\t"
        "psubb %%xmm11, %%xmm2 \n\t"
        "psubb %%xmm11, %%xmm3 \n\t"
        "psubb %%xmm11, %%xmm4 \n\t"
        "psubb %%xmm11, %%xmm5 \n\t"
        "psubb %%xmm11, %%xmm6 \n\t"
        "movdqa 64(%0), %%xmm9 \n\t"
        "movdqa 80(%0), %%xmm10 \n\t"
        "movdqa 96(%0), %%xmm11 \n\t"
        "paddusb %%xmm0, %%xmm12 \n\t"
        "movdqa %%xmm12,   (%0) \n\t"
        "paddusb %%xmm1, %%xmm13 \n\t"
        "movdqa %%xmm13, 16(%0) \n\t"
        "paddusb %%xmm2, %%xmm14 \n\t"
        "movdqa %%xmm14, 32(%0) \n\t"
        "paddusb %%xmm3, %%xmm15 \n\t"
        "movdqa %%xmm15, 48(%0) \n\t"
        "paddusb %%xmm4, %%xmm9 \n\t"
        "movdqa %%xmm9, 64(%0) \n\t"
        "pxor %%xmm9, %%xmm9 \n\t"
        "paddusb %%xmm5, %%xmm10 \n\t"
        "movdqa %%xmm10, 80(%0) \n\t"
        "paddusb %%xmm6, %%xmm11 \n\t"
        "movdqa %%xmm11, 96(%0) \n\t" 
   :
   : "r"(disparityPathCube), "r"(disparityCube)
   : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm9", "%xmm10", "%xmm11", "%xmm12", "%xmm13", "%xmm14", "%xmm15"
    );

}

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation<112>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{

      #ifdef ENABLE_PREFETCH  
       _mm_prefetch(disparityCube,_MM_HINT_NTA); 
       _mm_prefetch(disparityCube+256,_MM_HINT_NTA); 
      #endif 

    __asm__ volatile (  /// values in xmm0, xmm1, xmm2, xmm3, xmm4, xmm5, xmm6
        "movdqa   (%1), %%xmm14 \n\t"
        "movdqa 16(%1), %%xmm15 \n\t"
#ifdef __AVX__ 
        "vpalignr $15, %%xmm8, %%xmm0, %%xmm10 \n\t"
        "vpalignr  $1, %%xmm0, %%xmm1, %%xmm11 \n\t"
        "vpalignr $15, %%xmm0, %%xmm1, %%xmm12 \n\t"
        "vpalignr  $1, %%xmm1, %%xmm2, %%xmm13 \n\t"
#else        
        "pshufd $228, %%xmm0, %%xmm10 \n\t"
        "pshufd $228, %%xmm1, %%xmm11 \n\t"
        "pshufd $228, %%xmm1, %%xmm12 \n\t"
        "pshufd $228, %%xmm2, %%xmm13 \n\t"
        "palignr $15, %%xmm8, %%xmm10 \n\t"
        "palignr  $1, %%xmm0, %%xmm11 \n\t"
        "palignr $15, %%xmm0, %%xmm12 \n\t"
        "palignr  $1, %%xmm1, %%xmm13 \n\t"
#endif        
        "paddusb %%xmm7, %%xmm10 \n\t"
        "paddusb %%xmm7, %%xmm11 \n\t"
        "paddusb %%xmm7, %%xmm12 \n\t"
        "paddusb %%xmm7, %%xmm13 \n\t"
        "pminub %%xmm10, %%xmm0 \n\t"
        "pminub %%xmm8,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm0 \n\t"
        "paddusb %%xmm14, %%xmm0 \n\t"
        "movdqa 32(%1), %%xmm14 \n\t"
#ifdef __AVX__ 
        "vpalignr $15, %%xmm1, %%xmm2, %%xmm10 \n\t"
        "vpalignr  $1, %%xmm2, %%xmm3, %%xmm11 \n\t"
#else        
        "pshufd $228, %%xmm2, %%xmm10 \n\t"
        "pshufd $228, %%xmm3, %%xmm11 \n\t"
        "palignr $15, %%xmm1, %%xmm10 \n\t"
        "palignr  $1, %%xmm2, %%xmm11 \n\t"
#endif        
        "paddusb %%xmm7, %%xmm10 \n\t"
        "paddusb %%xmm7, %%xmm11 \n\t"
        "pminub %%xmm12, %%xmm1 \n\t"
        "pminub %%xmm8,  %%xmm13 \n\t"
        "pminub %%xmm13, %%xmm1 \n\t"
        "paddusb %%xmm15, %%xmm1 \n\t"
        "movdqa 48(%1), %%xmm15 \n\t"
#ifdef __AVX__ 
        "vpalignr $15, %%xmm2, %%xmm3, %%xmm12 \n\t"
        "vpalignr  $1, %%xmm3, %%xmm4, %%xmm13 \n\t"
#else        
        "pshufd $228, %%xmm3, %%xmm12 \n\t"
        "pshufd $228, %%xmm4, %%xmm13 \n\t"
        "palignr $15, %%xmm2, %%xmm12 \n\t"
        "palignr  $1, %%xmm3, %%xmm13 \n\t"
#endif        
        "paddusb %%xmm7, %%xmm12 \n\t"
        "paddusb %%xmm7, %%xmm13 \n\t"
        "pminub %%xmm10, %%xmm2 \n\t"
        "pminub %%xmm8,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm2 \n\t"
        "paddusb %%xmm14, %%xmm2 \n\t"
        "movdqa 64(%1), %%xmm14 \n\t"
#ifdef __AVX__ 
        "vpalignr $15, %%xmm3, %%xmm4, %%xmm10 \n\t"
        "vpalignr  $1, %%xmm4, %%xmm5, %%xmm11 \n\t"
#else        
        "pshufd $228, %%xmm4, %%xmm10 \n\t"
        "pshufd $228, %%xmm5, %%xmm11 \n\t"
        "palignr $15, %%xmm3, %%xmm10 \n\t"
        "palignr  $1, %%xmm4, %%xmm11 \n\t"
#endif        
        "paddusb %%xmm7, %%xmm10 \n\t"
        "paddusb %%xmm7, %%xmm11 \n\t"
        "pminub %%xmm12, %%xmm3 \n\t"
        "pminub %%xmm8,  %%xmm13 \n\t"
        "pminub %%xmm13, %%xmm3 \n\t"
        "paddusb %%xmm15, %%xmm3 \n\t"
        "movdqa 80(%1), %%xmm15 \n\t"
#ifdef __AVX__ 
        "vpalignr $15, %%xmm4, %%xmm5, %%xmm12 \n\t"
        "vpalignr  $1, %%xmm5, %%xmm6, %%xmm13 \n\t"
#else        
        "pshufd $228, %%xmm5, %%xmm12 \n\t"
        "pshufd $228, %%xmm6, %%xmm13 \n\t"
        "palignr $15, %%xmm4, %%xmm12 \n\t"
        "palignr  $1, %%xmm5, %%xmm13 \n\t"
#endif        
        "paddusb %%xmm7, %%xmm12 \n\t"
        "paddusb %%xmm7, %%xmm13 \n\t"
        "pminub %%xmm10, %%xmm4 \n\t"
        "pminub %%xmm8,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm4 \n\t"
        "paddusb %%xmm14, %%xmm4 \n\t"
        "movdqa 96(%1), %%xmm14 \n\t"
#ifdef __AVX__  
        "vpalignr $15, %%xmm5, %%xmm6, %%xmm10 \n\t"
        "vpalignr  $1, %%xmm6, %%xmm8, %%xmm11 \n\t"
#else        
        "pshufd $228, %%xmm6, %%xmm10 \n\t"
        "pshufd $228, %%xmm8, %%xmm11 \n\t"
        "palignr $15, %%xmm5, %%xmm10 \n\t"
        "palignr  $1, %%xmm6, %%xmm11 \n\t"
#endif        
        "paddusb %%xmm7, %%xmm10 \n\t"
        "paddusb %%xmm7, %%xmm11 \n\t"
        "pminub %%xmm12, %%xmm5 \n\t"
        "pminub %%xmm8,  %%xmm13 \n\t"
        "pminub %%xmm13, %%xmm5 \n\t"
        "pminub %%xmm10, %%xmm6 \n\t"
        "pminub %%xmm8,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm6 \n\t"
        "paddusb %%xmm15, %%xmm5 \n\t"
        "paddusb %%xmm14, %%xmm6 \n\t"
#ifdef __AVX__ 
        "vpminub %%xmm1, %%xmm0, %%xmm10 \n\t"
        "vpminub %%xmm4, %%xmm3, %%xmm11 \n\t"
#else        
        "pshufd $228, %%xmm0, %%xmm10 \n\t"
        "pshufd $228, %%xmm3, %%xmm11 \n\t"
        "pminub %%xmm1,  %%xmm10 \n\t"
        "pminub %%xmm4,  %%xmm11 \n\t"
#endif       
        "pminub %%xmm2,  %%xmm10 \n\t"
        "pminub %%xmm5,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm6,  %%xmm10 \n\t"
        "pshufd $78, %%xmm10, %%xmm11 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
#ifdef __SSE4_1__
        "punpcklbw %%xmm11, %%xmm11 \n\t"
        "phminposuw %%xmm11, %%xmm11 \n\t"
#else
        "pshufd $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
        "pshuflw $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
        "punpcklbw %%xmm11, %%xmm11 \n\t"
        "pshuflw $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
#endif
        "pshufb %%xmm9, %%xmm11 \n\t"
        "movdqa   (%0), %%xmm10 \n\t" 
        "movdqa 16(%0), %%xmm9 \n\t" 
        "movdqa 32(%0), %%xmm12 \n\t" 
        "movdqa 48(%0), %%xmm13 \n\t" 
        "movdqa 64(%0), %%xmm14 \n\t"
        "movdqa 80(%0), %%xmm15 \n\t"
        "psubb %%xmm11, %%xmm0 \n\t"
        "psubb %%xmm11, %%xmm1 \n\t"
        "psubb %%xmm11, %%xmm2 \n\t"
        "psubb %%xmm11, %%xmm3 \n\t"
        "psubb %%xmm11, %%xmm4 \n\t"
        "psubb %%xmm11, %%xmm5 \n\t"
        "psubb %%xmm11, %%xmm6 \n\t"
        "movdqa 96(%0), %%xmm11 \n\t" 
        "paddusb %%xmm0, %%xmm10 \n\t"
        "movdqa %%xmm10,   (%0) \n\t" 
        "paddusb %%xmm1, %%xmm9 \n\t"
        "movdqa %%xmm9,  16(%0) \n\t"
        "pxor %%xmm9, %%xmm9 \n\t"
        "paddusb %%xmm2, %%xmm12 \n\t" 
        "movdqa %%xmm12, 32(%0) \n\t"
        "paddusb %%xmm3, %%xmm13 \n\t"  
        "movdqa %%xmm13, 48(%0) \n\t"
        "paddusb %%xmm4, %%xmm14 \n\t" 
        "movdqa %%xmm14, 64(%0) \n\t"
        "paddusb %%xmm5, %%xmm15 \n\t"
        "movdqa %%xmm15, 80(%0) \n\t"
        "paddusb %%xmm6, %%xmm11 \n\t"
        "movdqa %%xmm11, 96(%0) \n\t"  
   :
   : "r"(disparityPathCube), "r"(disparityCube)
   : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7", "%xmm8", "%xmm9", "%xmm10", "%xmm11", "%xmm12", "%xmm13", "%xmm14", "%xmm15"
    );

}

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation0_0<112>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{


    __asm__ volatile (  /// values in xmm0, xmm1, xmm2, xmm3, xmm4, xmm5, xmm6
        "movdqa   (%1), %%xmm0 \n\t"
        "movdqa 16(%1), %%xmm1 \n\t"
        "movdqa 32(%1), %%xmm2 \n\t"
        "movdqa 48(%1), %%xmm3 \n\t"
        "movdqa 64(%1), %%xmm4 \n\t"
        "movdqa 80(%1), %%xmm5 \n\t"
        "movdqa 96(%1), %%xmm6 \n\t"
#ifdef __AVX__
        "vpminub %%xmm1, %%xmm0, %%xmm10 \n\t"     
        "vpminub %%xmm4, %%xmm3, %%xmm11 \n\t"
#else        
        "pshufd $228, %%xmm0, %%xmm10 \n\t"
        "pshufd $228, %%xmm3, %%xmm11 \n\t"
        "pminub %%xmm1,  %%xmm10 \n\t"     
        "pminub %%xmm4,  %%xmm11 \n\t"
#endif        
        "pminub %%xmm2,  %%xmm10 \n\t"
        "pminub %%xmm5,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm6,  %%xmm10 \n\t"
        "pshufd $78, %%xmm10, %%xmm11 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
#ifdef __SSE4_1__
        "punpcklbw %%xmm11, %%xmm11 \n\t"
        "phminposuw %%xmm11, %%xmm11 \n\t"
#else
        "pshufd $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
        "pshuflw $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
        "punpcklbw %%xmm11, %%xmm11 \n\t"
        "pshuflw $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
#endif
        "pshufb %%xmm9, %%xmm11 \n\t"
        "psubb %%xmm11, %%xmm0 \n\t"
        "psubb %%xmm11, %%xmm1 \n\t"
        "psubb %%xmm11, %%xmm2 \n\t"
        "psubb %%xmm11, %%xmm3 \n\t"
        "psubb %%xmm11, %%xmm4 \n\t"
        "psubb %%xmm11, %%xmm5 \n\t"
        "psubb %%xmm11, %%xmm6 \n\t"
        "movdqa %%xmm0,   (%0) \n\t"
        "movdqa %%xmm1, 16(%0) \n\t"
        "movdqa %%xmm2, 32(%0) \n\t"
        "movdqa %%xmm3, 48(%0) \n\t"
        "movdqa %%xmm4, 64(%0) \n\t"
        "movdqa %%xmm5, 80(%0) \n\t"
        "movdqa %%xmm6, 96(%0) \n\t" 
   :
   : "r"(disparityPathCube), "r"(disparityCube)
   : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm9", "%xmm10", "%xmm11"
    );

}

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation_0<112>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{

     #ifdef ENABLE_PREFETCH  
       _mm_prefetch(disparityCube-64,_MM_HINT_NTA); 
       _mm_prefetch(disparityCube-64+256,_MM_HINT_NTA); 
    #endif 

    __asm__ volatile (  /// values in xmm0, xmm1, xmm2, xmm3, xmm4, xmm5, xmm6
        "movdqa   (%1), %%xmm14 \n\t"
        "movdqa 16(%1), %%xmm15 \n\t"
#ifdef __AVX__	
	"vpalignr $15, %%xmm8, %%xmm0, %%xmm10 \n\t"
        "vpalignr  $1, %%xmm0, %%xmm1, %%xmm11 \n\t"
        "vpalignr $15, %%xmm0, %%xmm1, %%xmm12 \n\t"
        "vpalignr  $1, %%xmm1, %%xmm2, %%xmm13 \n\t"
#else	
        "pshufd $228, %%xmm0, %%xmm10 \n\t"
        "pshufd $228, %%xmm1, %%xmm11 \n\t"
        "pshufd $228, %%xmm1, %%xmm12 \n\t"
        "pshufd $228, %%xmm2, %%xmm13 \n\t"
	
        "palignr $15, %%xmm8, %%xmm10 \n\t"
        "palignr  $1, %%xmm0, %%xmm11 \n\t"
        "palignr $15, %%xmm0, %%xmm12 \n\t"
        "palignr  $1, %%xmm1, %%xmm13 \n\t"
#endif	
        "paddusb %%xmm7, %%xmm10 \n\t"
        "paddusb %%xmm7, %%xmm11 \n\t"
        "paddusb %%xmm7, %%xmm12 \n\t"
        "paddusb %%xmm7, %%xmm13 \n\t"
        "pminub %%xmm10, %%xmm0 \n\t"
        "pminub %%xmm8,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm0 \n\t"
        "paddusb %%xmm14, %%xmm0 \n\t"
        "movdqa 32(%1), %%xmm14 \n\t"
#ifdef __AVX__
	"vpalignr $15, %%xmm1, %%xmm2, %%xmm10 \n\t"
        "vpalignr  $1, %%xmm2, %%xmm3, %%xmm11 \n\t"
#else	
        "pshufd $228, %%xmm2, %%xmm10 \n\t"
        "pshufd $228, %%xmm3, %%xmm11 \n\t"
        "palignr $15, %%xmm1, %%xmm10 \n\t"
        "palignr  $1, %%xmm2, %%xmm11 \n\t"
#endif	
        "paddusb %%xmm7, %%xmm10 \n\t"
        "paddusb %%xmm7, %%xmm11 \n\t"
        "pminub %%xmm12, %%xmm1 \n\t"
        "pminub %%xmm8,  %%xmm13 \n\t"
        "pminub %%xmm13, %%xmm1 \n\t"
        "paddusb %%xmm15, %%xmm1 \n\t"
        "movdqa 48(%1), %%xmm15 \n\t"
#ifdef __AVX__
	"vpalignr $15, %%xmm2, %%xmm3, %%xmm12 \n\t"
        "vpalignr  $1, %%xmm3, %%xmm4, %%xmm13 \n\t"
#else	
        "pshufd $228, %%xmm3, %%xmm12 \n\t"
        "pshufd $228, %%xmm4, %%xmm13 \n\t"
        "palignr $15, %%xmm2, %%xmm12 \n\t"
        "palignr  $1, %%xmm3, %%xmm13 \n\t"
#endif	
        "paddusb %%xmm7, %%xmm12 \n\t"
        "paddusb %%xmm7, %%xmm13 \n\t"
        "pminub %%xmm10, %%xmm2 \n\t"
        "pminub %%xmm8,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm2 \n\t"
        "paddusb %%xmm14, %%xmm2 \n\t"
        "movdqa 64(%1), %%xmm14 \n\t"
#ifdef __AVX__
	"vpalignr $15, %%xmm3, %%xmm4, %%xmm10 \n\t"
        "vpalignr  $1, %%xmm4, %%xmm5, %%xmm11 \n\t"
#else	
        "pshufd $228, %%xmm4, %%xmm10 \n\t"
        "pshufd $228, %%xmm5, %%xmm11 \n\t"
        "palignr $15, %%xmm3, %%xmm10 \n\t"
        "palignr  $1, %%xmm4, %%xmm11 \n\t"
#endif	
        "paddusb %%xmm7, %%xmm10 \n\t"
        "paddusb %%xmm7, %%xmm11 \n\t"
        "pminub %%xmm12, %%xmm3 \n\t"
        "pminub %%xmm8,  %%xmm13 \n\t"
        "pminub %%xmm13, %%xmm3 \n\t"
        "paddusb %%xmm15, %%xmm3 \n\t"
        "movdqa 80(%1), %%xmm15 \n\t"
#ifdef __AVX__
	"vpalignr $15, %%xmm4, %%xmm5, %%xmm12 \n\t"
        "vpalignr  $1, %%xmm5, %%xmm6, %%xmm13 \n\t"
#else	
        "pshufd $228, %%xmm5, %%xmm12 \n\t"
        "pshufd $228, %%xmm6, %%xmm13 \n\t"
        "palignr $15, %%xmm4, %%xmm12 \n\t"
        "palignr  $1, %%xmm5, %%xmm13 \n\t"
#endif	
        "paddusb %%xmm7, %%xmm12 \n\t"
        "paddusb %%xmm7, %%xmm13 \n\t"
        "pminub %%xmm10, %%xmm4 \n\t"
        "pminub %%xmm8,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm4 \n\t"
        "paddusb %%xmm14, %%xmm4 \n\t"
        "movdqa 96(%1), %%xmm14 \n\t"
#ifdef __AVX__
	"vpalignr $15, %%xmm5, %%xmm6, %%xmm10 \n\t"
        "vpalignr  $1, %%xmm6, %%xmm8, %%xmm11 \n\t"
#else	
        "pshufd $228, %%xmm6, %%xmm10 \n\t"
        "pshufd $228, %%xmm8, %%xmm11 \n\t"
        "palignr $15, %%xmm5, %%xmm10 \n\t"
        "palignr  $1, %%xmm6, %%xmm11 \n\t"
#endif
        "paddusb %%xmm7, %%xmm10 \n\t"
        "paddusb %%xmm7, %%xmm11 \n\t"
        "pminub %%xmm12, %%xmm5 \n\t"
        "pminub %%xmm8,  %%xmm13 \n\t"
        "pminub %%xmm13, %%xmm5 \n\t"
        "pminub %%xmm10, %%xmm6 \n\t"
        "pminub %%xmm8,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm6 \n\t"
        "paddusb %%xmm15, %%xmm5 \n\t"
        "paddusb %%xmm14, %%xmm6 \n\t"
#ifdef __AVX__	
        "vpminub %%xmm1, %%xmm0, %%xmm10 \n\t"
        "vpminub %%xmm4, %%xmm3, %%xmm11 \n\t"
#else	
        "pshufd $228, %%xmm0, %%xmm10 \n\t"
        "pshufd $228, %%xmm3, %%xmm11 \n\t"
        "pminub %%xmm1,  %%xmm10 \n\t"        
        "pminub %%xmm4,  %%xmm11 \n\t"
#endif	
	"pminub %%xmm2,  %%xmm10 \n\t"
        "pminub %%xmm5,  %%xmm11 \n\t"
        "pminub %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm6,  %%xmm10 \n\t"
        "pshufd $78, %%xmm10, %%xmm11 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
#ifdef __SSE4_1__
        "punpcklbw %%xmm11, %%xmm11 \n\t"
        "phminposuw %%xmm11, %%xmm11 \n\t"
#else
        "pshufd $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
        "pshuflw $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
        "punpcklbw %%xmm11, %%xmm11 \n\t"
        "pshuflw $1, %%xmm11, %%xmm10 \n\t"
        "pminub %%xmm10, %%xmm11 \n\t"
#endif
        "pshufb %%xmm9, %%xmm11 \n\t"
        "psubb %%xmm11, %%xmm0 \n\t"
        "psubb %%xmm11, %%xmm1 \n\t"
        "psubb %%xmm11, %%xmm2 \n\t"
        "psubb %%xmm11, %%xmm3 \n\t"
        "psubb %%xmm11, %%xmm4 \n\t"
        "psubb %%xmm11, %%xmm5 \n\t"
        "psubb %%xmm11, %%xmm6 \n\t"
        "movdqa %%xmm0,   (%0) \n\t"
        "movdqa %%xmm1, 16(%0) \n\t"
        "movdqa %%xmm2, 32(%0) \n\t"
        "movdqa %%xmm3, 48(%0) \n\t"
        "movdqa %%xmm4, 64(%0) \n\t"
        "movdqa %%xmm5, 80(%0) \n\t"
        "movdqa %%xmm6, 96(%0) \n\t"   
   :
   : "r"(disparityPathCube), "r"(disparityCube)
   : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7", "%xmm8", "%xmm9", "%xmm10", "%xmm11", "%xmm12", "%xmm13", "%xmm14", "%xmm15"
    );

}


//128


template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation0<128>(uint8_t* disparityPathCube, const uint8_t* disparityCube)   /// %%xmm0, %%xmm1, %%xmm2, %%xmm3, %%xmm4, %%xmm5, %%xmm6, %%xmm10
{
  
      
         __asm__ volatile (
#ifdef ENABLE_PREFETCH               
                "prefetchnta (%1)\n"
                "prefetchnta 256(%1)\n"
                "prefetcht0 (%0)\n"
                "prefetcht0 256(%0)\n"
#endif             
                "movdqa   (%1), %%xmm0 \n\t"
                "movdqa   16(%1), %%xmm1 \n\t"
                "movdqa   32(%1), %%xmm2 \n\t"
                "movdqa   48(%1), %%xmm3 \n\t"
                "movdqa   64(%1), %%xmm4 \n\t"
                "movdqa   80(%1), %%xmm5 \n\t"
                "movdqa   96(%1), %%xmm6 \n\t"
                "movdqa   112(%1), %%xmm10 \n\t"

#ifdef __AVX__
                "vpminub %%xmm1, %%xmm0, %%xmm11\n\t"
                "vpminub %%xmm3, %%xmm2, %%xmm12\n\t"
                "vpminub %%xmm5, %%xmm4, %%xmm13\n\t"
                "vpminub %%xmm10,%%xmm6, %%xmm14\n\t" 
#else
                "pshufd  $228,%%xmm0, %%xmm11\n\t"
                "pshufd  $228,%%xmm2, %%xmm12\n\t"
                "pshufd  $228,%%xmm4, %%xmm13\n\t"
                "pshufd  $228,%%xmm6, %%xmm14\n\t"
                
                "pminub %%xmm1, %%xmm11\n\t"
                "pminub %%xmm3, %%xmm12\n\t"
                "pminub %%xmm5, %%xmm13\n\t"
                "pminub %%xmm10, %%xmm14\n\t"              
#endif     
                "pminub %%xmm11, %%xmm12\n\t"
                "pminub %%xmm13, %%xmm14\n\t"
                "pminub %%xmm12, %%xmm14\n\t"
                "pxor %%xmm9, %%xmm9\n\t"
                
                "movdqa  (%0), %%xmm12\n\t"
                "movdqa  16(%0), %%xmm13\n\t"  
                
                "pshufd  $78,%%xmm14, %%xmm11\n\t"
                "pminub %%xmm11, %%xmm14\n\t"               
#ifdef __SSE4_1__ 
                "movdqa  32(%0), %%xmm11\n\t" 
                "punpcklbw %%xmm14, %%xmm14\n\t"
                "phminposuw %%xmm14, %%xmm14\n\t"
#else
                "pshufd $1, %%xmm14, %%xmm11\n\t"
                "pminub %%xmm11, %%xmm14\n\t"
                "pshuflw $1, %%xmm14, %%xmm11\n\t"
                "pminub %%xmm11, %%xmm14\n\t"
                "punpcklbw %%xmm14, %%xmm14\n\t"
                "pshuflw $1, %%xmm14, %%xmm11\n\t"
                "pminub %%xmm11, %%xmm14\n\t" 
                "movdqa  32(%0), %%xmm11\n\t" 
#endif  
                "pshufb %%xmm9, %%xmm14\n\t"
                
                "movdqa  48(%0), %%xmm9\n\t" 
                
                "psubb %%xmm14, %%xmm0\n\t"
                "psubb %%xmm14, %%xmm1\n\t"
                "psubb %%xmm14, %%xmm2\n\t"
                "psubb %%xmm14, %%xmm3\n\t"
                "psubb %%xmm14, %%xmm4\n\t"
                "psubb %%xmm14, %%xmm5\n\t"
                "psubb %%xmm14, %%xmm6\n\t"
                "psubb %%xmm14, %%xmm10\n\t"
                
                "movdqa  64(%0), %%xmm14\n\t" 
                
                "paddusb  %%xmm0, %%xmm12\n\t" 
                "paddusb  %%xmm1, %%xmm13\n\t"
                "paddusb  %%xmm2, %%xmm11\n\t" 
                "paddusb  %%xmm3, %%xmm9\n\t"                                
                "movdqa  %%xmm12, (%0)\n\t"
                "movdqa  %%xmm13, 16(%0)\n\t"
                "movdqa  %%xmm11, 32(%0)\n\t"
                "movdqa  %%xmm9, 48(%0)\n\t"
                                
                "movdqa  80(%0), %%xmm13\n\t" 
                "movdqa  96(%0), %%xmm11\n\t" 
                "movdqa  112(%0), %%xmm12\n\t"
                "paddusb  %%xmm4, %%xmm14\n\t" 
                "paddusb  %%xmm5, %%xmm13\n\t"
                "paddusb  %%xmm6, %%xmm11\n\t" 
                "paddusb  %%xmm10, %%xmm12\n\t"            
                "movdqa  %%xmm14, 64(%0)\n\t"
                "movdqa  %%xmm13, 80(%0)\n\t"
                "movdqa  %%xmm11, 96(%0)\n\t"
                "movdqa  %%xmm12, 112(%0)\n\t"
              :  : 
              "r"(disparityPathCube),"r"(disparityCube) 
              : "%xmm0", "%xmm1", "%xmm2", "%xmm3","%xmm4", "%xmm5"
            ); 

}

template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation0_0<128>(uint8_t* disparityPathCube, const uint8_t* disparityCube)   /// %%xmm0, %%xmm1, %%xmm2, %%xmm3, %%xmm4, %%xmm5, %%xmm6, %%xmm10
{
  
  
//       _mm_prefetch(disparityCube,_MM_HINT_NTA); 
//       _mm_prefetch(disparityCube+256,_MM_HINT_NTA); 
          
//       _mm_prefetch(disparityPathCube,_MM_HINT_T0); 
//       _mm_prefetch(disparityPathCube+256,_MM_HINT_T0);
 
      
        __asm__ volatile (
                "movdqa   (%1), %%xmm0 \n\t"
                "movdqa   16(%1), %%xmm1 \n\t"
                "movdqa   32(%1), %%xmm2 \n\t"
                "movdqa   48(%1), %%xmm3 \n\t"
                "movdqa   64(%1), %%xmm4 \n\t"
                "movdqa   80(%1), %%xmm5 \n\t"
                "movdqa   96(%1), %%xmm6 \n\t"
                "movdqa   112(%1), %%xmm10 \n\t"
                "pxor %%xmm9, %%xmm9\n\t"
#ifdef __AVX__
                "vpminub %%xmm1, %%xmm0, %%xmm11\n\t"
                "vpminub %%xmm3, %%xmm2, %%xmm12\n\t"
                "vpminub %%xmm5, %%xmm4, %%xmm13\n\t"
                "vpminub %%xmm10, %%xmm6, %%xmm14\n\t"  
#else
                "pshufd  $228,%%xmm0, %%xmm11\n\t"
                "pshufd  $228,%%xmm2, %%xmm12\n\t"
                "pshufd  $228,%%xmm4, %%xmm13\n\t"
                "pshufd  $228,%%xmm6, %%xmm14\n\t"                

                
                "pminub %%xmm1, %%xmm11\n\t"
                "pminub %%xmm3, %%xmm12\n\t"
                "pminub %%xmm5, %%xmm13\n\t"
                "pminub %%xmm10, %%xmm14\n\t"              
#endif
                "pminub %%xmm11, %%xmm12\n\t"
                "pminub %%xmm13, %%xmm14\n\t"
                "pminub %%xmm12, %%xmm14\n\t"
                
                "pshufd  $78,%%xmm14, %%xmm11\n\t"
                "pminub %%xmm11, %%xmm14\n\t"
#ifdef __SSE4_1__                
                "punpcklbw %%xmm14, %%xmm14\n\t"
                "phminposuw %%xmm14, %%xmm14\n\t"                
#else
                "pshufd $1, %%xmm14, %%xmm11\n\t"
                "pminub %%xmm11, %%xmm14\n\t"
                "pshuflw $1, %%xmm14, %%xmm11\n\t"
                "pminub %%xmm11, %%xmm14\n\t"
                "punpcklbw %%xmm14, %%xmm14\n\t"
                "pshuflw $1, %%xmm14, %%xmm11\n\t"
                "pminub %%xmm11, %%xmm14\n\t"               
#endif            
                "pshufb %%xmm9, %%xmm14\n\t"
                
                "psubb %%xmm14, %%xmm0\n\t"
                "psubb %%xmm14, %%xmm1\n\t"
                "psubb %%xmm14, %%xmm2\n\t"
                "psubb %%xmm14, %%xmm3\n\t"
                "psubb %%xmm14, %%xmm4\n\t"
                "psubb %%xmm14, %%xmm5\n\t"
                "psubb %%xmm14, %%xmm6\n\t"
                "psubb %%xmm14, %%xmm10\n\t"
                               
                "movdqa  %%xmm0, (%0)\n\t"
                "movdqa  %%xmm1, 16(%0)\n\t"
                "movdqa  %%xmm2, 32(%0)\n\t"
                "movdqa  %%xmm3, 48(%0)\n\t"
                "movdqa  %%xmm4, 64(%0)\n\t"
                "movdqa  %%xmm5, 80(%0)\n\t"
                "movdqa  %%xmm6, 96(%0)\n\t"
                "movdqa  %%xmm10, 112(%0)\n\t"
              :  : 
              "r"(disparityPathCube),"r"(disparityCube) 
              : "%xmm0", "%xmm1", "%xmm2", "%xmm3","%xmm4", "%xmm5"
            );  
            

}


template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation_0<128>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{
  

                __asm__ volatile (  /// %%xmm0, %%xmm1 %%xmm2 %%xmm3
#ifdef ENABLE_PREFETCH                  
                "prefetchnta -64(%1)\n"
                "prefetchnta 256-64(%1)\n"
#endif 
#ifdef __AVX__
                "vpalignr $15, %%xmm8, %%xmm0, %%xmm9\n\t"   
                "vpalignr $1, %%xmm0, %%xmm1, %%xmm11\n\t"
                "vpalignr $15, %%xmm0, %%xmm1, %%xmm12\n\t"              
                "vpalignr $1, %%xmm1, %%xmm2, %%xmm13\n\t"               
                "vpalignr $15, %%xmm1, %%xmm2, %%xmm14\n\t"                         
                "vpalignr $1, %%xmm2, %%xmm3, %%xmm15\n\t"   
#else                
                "pshufd  $228,%%xmm0, %%xmm9\n\t"       
                "pshufd  $228,%%xmm1, %%xmm11\n\t"
                "pshufd  $228,%%xmm1, %%xmm12\n\t"                
                "pshufd  $228,%%xmm2, %%xmm13\n\t"                
                "pshufd  $228,%%xmm2, %%xmm14\n\t"               
                "pshufd  $228,%%xmm3, %%xmm15\n\t"  
                
                "palignr $15, %%xmm8, %%xmm9\n\t"   
                "palignr $1, %%xmm0, %%xmm11\n\t"
                "palignr $15, %%xmm0, %%xmm12\n\t"              
                "palignr $1, %%xmm1, %%xmm13\n\t"               
                "palignr $15, %%xmm1, %%xmm14\n\t"                         
                "palignr $1, %%xmm2, %%xmm15\n\t"               
#endif
                "paddusb %%xmm7, %%xmm9\n\t"
                "paddusb %%xmm7, %%xmm11\n\t"
                "paddusb %%xmm7, %%xmm12\n\t"
                "paddusb %%xmm7, %%xmm13\n\t"
                "paddusb %%xmm7, %%xmm14\n\t"
                "paddusb %%xmm7, %%xmm15\n\t"

                    
                "pminub %%xmm9, %%xmm0\n\t"
                "movdqa  (%1), %%xmm9\n\t" 
                "pminub %%xmm12, %%xmm1\n\t"                
                "movdqa  16(%1), %%xmm12\n\t"
                
                
                "pminub %%xmm8, %%xmm11\n\t"
                "pminub %%xmm8, %%xmm13\n\t"
                "pminub %%xmm11, %%xmm0\n\t"
                "pminub %%xmm8, %%xmm15\n\t"               
                "pshufd  $228,%%xmm2, %%xmm11\n\t"
                "pminub %%xmm14, %%xmm2\n\t"
                "movdqa  32(%1), %%xmm14\n\t"
                "pminub %%xmm13, %%xmm1\n\t"               
                "pminub %%xmm15, %%xmm2\n\t"

                  
                        
                "paddusb %%xmm9, %%xmm0\n\t"
                "paddusb %%xmm12, %%xmm1\n\t"
                "paddusb %%xmm14, %%xmm2\n\t"
#ifdef __AVX__
                "vpalignr $15, %%xmm11, %%xmm3,  %%xmm9\n\t" 
                "vpalignr $1, %%xmm3, %%xmm4, %%xmm11\n\t"
                "vpalignr $15, %%xmm3, %%xmm4, %%xmm12\n\t"              
                "vpalignr $1, %%xmm4, %%xmm5, %%xmm13\n\t"               
                "vpalignr $15, %%xmm4, %%xmm5, %%xmm14\n\t"                         
                "vpalignr $1, %%xmm5, %%xmm6, %%xmm15\n\t"
#else                
                "pshufd  $228,%%xmm3, %%xmm9\n\t"  
                "pshufd  $228,%%xmm4, %%xmm12\n\t"
                "palignr $15, %%xmm11, %%xmm9\n\t" 
                "pshufd  $228,%%xmm5, %%xmm13\n\t"  
                "pshufd  $228,%%xmm5, %%xmm14\n\t"
                "pshufd  $228,%%xmm4, %%xmm11\n\t"
                "pshufd  $228,%%xmm6, %%xmm15\n\t"  
                  
                "palignr $1, %%xmm3, %%xmm11\n\t"
                "palignr $15, %%xmm3, %%xmm12\n\t"              
                "palignr $1, %%xmm4, %%xmm13\n\t"               
                "palignr $15, %%xmm4, %%xmm14\n\t"                         
                "palignr $1, %%xmm5, %%xmm15\n\t"
#endif                
                
                "paddusb %%xmm7, %%xmm9\n\t"
                "paddusb %%xmm7, %%xmm11\n\t"
                "paddusb %%xmm7, %%xmm12\n\t"
                "paddusb %%xmm7, %%xmm13\n\t"
                "paddusb %%xmm7, %%xmm14\n\t"
                "paddusb %%xmm7, %%xmm15\n\t"
                
                "pminub %%xmm9, %%xmm3\n\t"
                "movdqa  48(%1), %%xmm9\n\t" 
                "pminub %%xmm12, %%xmm4\n\t"                
                "movdqa  64(%1), %%xmm12\n\t"
                              
                
                "pminub %%xmm8, %%xmm11\n\t"
                "pminub %%xmm8, %%xmm13\n\t"
                "pminub %%xmm11, %%xmm3\n\t"
                "pminub %%xmm8, %%xmm15\n\t"               
                "pshufd  $228,%%xmm5, %%xmm11\n\t"
                "pminub %%xmm14, %%xmm5\n\t"
                "movdqa  80(%1), %%xmm14\n\t"
                "pminub %%xmm13, %%xmm4\n\t"
                "pminub %%xmm15, %%xmm5\n\t"
                
                               
                "paddusb %%xmm9, %%xmm3\n\t"
                "paddusb %%xmm12, %%xmm4\n\t"
                "paddusb %%xmm14, %%xmm5\n\t"
                
#ifdef __AVX__
                "vpalignr $15, %%xmm11, %%xmm6, %%xmm9\n\t"   
                "vpalignr $1, %%xmm6, %%xmm10, %%xmm12\n\t"
                "vpalignr $15, %%xmm6, %%xmm10, %%xmm13\n\t"              
                "vpalignr $1, %%xmm10, %%xmm8, %%xmm14\n\t"   
#else                
                "pshufd  $228,%%xmm6, %%xmm9\n\t"  
                "pshufd  $228,%%xmm10, %%xmm12\n\t"               
                "pshufd  $228,%%xmm10, %%xmm13\n\t"  
                "pshufd  $228,%%xmm8, %%xmm14\n\t"

                "palignr $15, %%xmm11, %%xmm9\n\t"   
                "palignr $1, %%xmm6, %%xmm12\n\t"
                "palignr $15, %%xmm6, %%xmm13\n\t"              
                "palignr $1, %%xmm10, %%xmm14\n\t"               
#endif             
                "movdqa  96(%1), %%xmm15\n\t"
                "movdqa  112(%1), %%xmm11\n\t"
                
                "paddusb %%xmm7, %%xmm9\n\t"
                "paddusb %%xmm7, %%xmm12\n\t"
                "paddusb %%xmm7, %%xmm13\n\t"
                "paddusb %%xmm7, %%xmm14\n\t"
                
                
                "pminub %%xmm9, %%xmm6\n\t"
                "pminub %%xmm13, %%xmm10\n\t"                               
                "pminub %%xmm8, %%xmm12\n\t"
                "pminub %%xmm8, %%xmm14\n\t"
                "pminub %%xmm12, %%xmm6\n\t"
                "pminub %%xmm14, %%xmm10\n\t"

                "paddusb %%xmm15, %%xmm6\n\t"
                "paddusb %%xmm11, %%xmm10\n\t"
                

                "pxor %%xmm9, %%xmm9\n\t"
#ifdef __AVX__
                "vpminub %%xmm4, %%xmm0, %%xmm11\n\t"
                "vpminub %%xmm5, %%xmm1, %%xmm12\n\t"
                "vpminub %%xmm6, %%xmm2, %%xmm13\n\t"
                "vpminub %%xmm10,%%xmm3, %%xmm14\n\t"		
#else		
                "pshufd $228,%%xmm0, %%xmm11\n\t"
                "pshufd $228,%%xmm1, %%xmm12\n\t"
                "pshufd $228,%%xmm2, %%xmm13\n\t"
                "pshufd $228,%%xmm3, %%xmm14\n\t"
                
                
                "pminub %%xmm4, %%xmm11\n\t"
                "pminub %%xmm5, %%xmm12\n\t"
                "pminub %%xmm6, %%xmm13\n\t"
                "pminub %%xmm10, %%xmm14\n\t"
#endif		
                "pminub %%xmm12, %%xmm11\n\t"
                "pminub %%xmm14, %%xmm13\n\t"               
                "pminub %%xmm11, %%xmm13\n\t"
                
                
                "pshufd $78,%%xmm13, %%xmm14\n\t"
                "pminub %%xmm14, %%xmm13\n\t"
#ifdef __SSE4_1__                
                "punpcklbw %%xmm13, %%xmm13\n\t"
                "phminposuw %%xmm13, %%xmm13\n\t"                
#else
                "pshufd $1, %%xmm13, %%xmm14\n\t"
                "pminub %%xmm14, %%xmm13\n\t"
                "pshuflw $1, %%xmm13, %%xmm14\n\t"
                "pminub %%xmm14, %%xmm13\n\t"
                "punpcklbw %%xmm13, %%xmm13\n\t"
                "pshuflw $1, %%xmm13, %%xmm14\n\t"
                "pminub %%xmm14, %%xmm13\n\t"               
#endif                  
                "pshufb %%xmm9, %%xmm13\n\t"

                "psubb %%xmm13, %%xmm0\n\t"
                "psubb %%xmm13, %%xmm1\n\t"
                "psubb %%xmm13, %%xmm2\n\t"
                "psubb %%xmm13, %%xmm3\n\t"
                "psubb %%xmm13, %%xmm4\n\t"
                "psubb %%xmm13, %%xmm5\n\t"
                "psubb %%xmm13, %%xmm6\n\t"
                "psubb %%xmm13, %%xmm10\n\t"
                               
                "movdqa  %%xmm0, (%0)\n\t"
                "movdqa  %%xmm1, 16(%0)\n\t"
                "movdqa  %%xmm2, 32(%0)\n\t"
                "movdqa  %%xmm3, 48(%0)\n\t"
                "movdqa  %%xmm4, 64(%0)\n\t"
                "movdqa  %%xmm5, 80(%0)\n\t"
                "movdqa  %%xmm6, 96(%0)\n\t"
                "movdqa  %%xmm10, 112(%0)\n\t"
              :  : 
              "r"(disparityPathCube),"r"(disparityCube) 
              : "%xmm0", "%xmm1", "%xmm2", "%xmm3","%xmm4", "%xmm5"
            ); 
}


template <>
DECLSPEC_FORCEINLINE inline void PathAccumulation<128>(uint8_t* disparityPathCube, const uint8_t* disparityCube)
{
                 
            
                __asm__ volatile (  /// %%xmm0, %%xmm1 %%xmm2 %%xmm3
#ifdef ENABLE_PREFETCH  
                "prefetchnta (%1)\n"
                "prefetchnta 256(%1)\n"
#endif
                
#ifdef __AVX__
                "vpalignr $15, %%xmm8, %%xmm0, %%xmm9\n\t"   
                "vpalignr $1, %%xmm0, %%xmm1, %%xmm11\n\t"
                "vpalignr $15, %%xmm0, %%xmm1, %%xmm12\n\t"              
                "vpalignr $1, %%xmm1, %%xmm2, %%xmm13\n\t"               
                "vpalignr $15, %%xmm1, %%xmm2, %%xmm14\n\t"                         
                "vpalignr $1, %%xmm2, %%xmm3, %%xmm15\n\t"  
#else
                "pshufd  $228,%%xmm0, %%xmm9\n\t"       
                "pshufd  $228,%%xmm1, %%xmm11\n\t"
                "pshufd  $228,%%xmm1, %%xmm12\n\t"                
                "pshufd  $228,%%xmm2, %%xmm13\n\t"                
                "pshufd  $228,%%xmm2, %%xmm14\n\t"               
                "pshufd  $228,%%xmm3, %%xmm15\n\t" 
                
                
                "palignr $15, %%xmm8, %%xmm9\n\t"   
                "palignr $1, %%xmm0, %%xmm11\n\t"
                "palignr $15, %%xmm0, %%xmm12\n\t"              
                "palignr $1, %%xmm1, %%xmm13\n\t"               
                "palignr $15, %%xmm1, %%xmm14\n\t"                         
                "palignr $1, %%xmm2, %%xmm15\n\t"               
#endif
                "paddusb %%xmm7, %%xmm9\n\t"
                "paddusb %%xmm7, %%xmm11\n\t"
                "paddusb %%xmm7, %%xmm12\n\t"
                "paddusb %%xmm7, %%xmm13\n\t"
                "paddusb %%xmm7, %%xmm14\n\t"
                "paddusb %%xmm7, %%xmm15\n\t"

                    
                "pminub %%xmm9, %%xmm0\n\t"
                "movdqa  (%1), %%xmm9\n\t" 
                "pminub %%xmm12, %%xmm1\n\t"                
                "movdqa  16(%1), %%xmm12\n\t"
                
                
                "pminub %%xmm8, %%xmm11\n\t"
                "pminub %%xmm8, %%xmm13\n\t"                          
                "pminub %%xmm11, %%xmm0\n\t" 
                "pminub %%xmm8, %%xmm15\n\t"  
                "pshufd $228, %%xmm2, %%xmm11\n\t"               
                "pminub %%xmm14, %%xmm2\n\t"                
                "movdqa  32(%1), %%xmm14\n\t"             
                "pminub %%xmm13, %%xmm1\n\t"               
                "pminub %%xmm15, %%xmm2\n\t"

                  
                        
                "paddusb %%xmm9, %%xmm0\n\t"
                "paddusb %%xmm12, %%xmm1\n\t"
                "paddusb %%xmm14, %%xmm2\n\t"
  
                
#ifdef __AVX__
                "vpalignr $15, %%xmm11, %%xmm3, %%xmm9\n\t" 
                "vpalignr $1, %%xmm3, %%xmm4, %%xmm11\n\t"
                "vpalignr $15, %%xmm3, %%xmm4, %%xmm12\n\t"              
                "vpalignr $1, %%xmm4, %%xmm5, %%xmm13\n\t"               
                "vpalignr $15, %%xmm4, %%xmm5, %%xmm14\n\t"                         
                "vpalignr $1, %%xmm5, %%xmm6, %%xmm15\n\t"
                
#else
                "pshufd  $228,%%xmm3, %%xmm9\n\t"  
                "pshufd  $228,%%xmm4, %%xmm12\n\t"
                "palignr $15, %%xmm11, %%xmm9\n\t" 
                "pshufd  $228,%%xmm5, %%xmm13\n\t"  
                "pshufd  $228,%%xmm5, %%xmm14\n\t"
                "pshufd  $228,%%xmm4, %%xmm11\n\t"
                "pshufd  $228,%%xmm6, %%xmm15\n\t"  
                  
                "palignr $1, %%xmm3, %%xmm11\n\t"
                "palignr $15, %%xmm3, %%xmm12\n\t"              
                "palignr $1, %%xmm4, %%xmm13\n\t"               
                "palignr $15, %%xmm4, %%xmm14\n\t"                         
                "palignr $1, %%xmm5, %%xmm15\n\t"
#endif                
                
                "paddusb %%xmm7, %%xmm9\n\t"
                "paddusb %%xmm7, %%xmm11\n\t"
                "paddusb %%xmm7, %%xmm12\n\t"
                "paddusb %%xmm7, %%xmm13\n\t"
                "paddusb %%xmm7, %%xmm14\n\t"
                "paddusb %%xmm7, %%xmm15\n\t"
                
                "pminub %%xmm9, %%xmm3\n\t"
                "movdqa  48(%1), %%xmm9\n\t" 
                "pminub %%xmm12, %%xmm4\n\t"                
                "movdqa  64(%1), %%xmm12\n\t"
                
                
                "pminub %%xmm8, %%xmm11\n\t"
                "pminub %%xmm8, %%xmm13\n\t"
                "pminub %%xmm11, %%xmm3\n\t"
                "pminub %%xmm8, %%xmm15\n\t"
                "pshufd  $228,%%xmm5, %%xmm11\n\t"
                
                "pminub %%xmm14, %%xmm5\n\t"
                "movdqa  80(%1), %%xmm14\n\t"
                "pminub %%xmm13, %%xmm4\n\t"
                "pminub %%xmm15, %%xmm5\n\t"
                
                               
                "paddusb %%xmm9, %%xmm3\n\t"
                "paddusb %%xmm12, %%xmm4\n\t"
                "paddusb %%xmm14, %%xmm5\n\t"
 
#ifdef __AVX__
                "vpalignr $15, %%xmm11, %%xmm6, %%xmm9\n\t"   
                "vpalignr $1, %%xmm6, %%xmm10, %%xmm12\n\t"
                "vpalignr $15, %%xmm6,%%xmm10, %%xmm13\n\t"              
                "vpalignr $1, %%xmm10, %%xmm8, %%xmm14\n\t"  
#else
                
                "pshufd  $228,%%xmm6, %%xmm9\n\t"  
                "pshufd  $228,%%xmm10, %%xmm12\n\t"               
                "pshufd  $228,%%xmm10, %%xmm13\n\t"  
                "pshufd  $228,%%xmm8, %%xmm14\n\t"

                "palignr $15, %%xmm11, %%xmm9\n\t"   
                "palignr $1, %%xmm6, %%xmm12\n\t"
                "palignr $15, %%xmm6, %%xmm13\n\t"              
                "palignr $1, %%xmm10, %%xmm14\n\t"               
#endif             
                "movdqa  96(%1), %%xmm15\n\t"
                "movdqa  112(%1), %%xmm11\n\t"
                
                "paddusb %%xmm7, %%xmm9\n\t"
                "paddusb %%xmm7, %%xmm12\n\t"
                "paddusb %%xmm7, %%xmm13\n\t"
                "paddusb %%xmm7, %%xmm14\n\t"
                
                
                "pminub %%xmm9, %%xmm6\n\t"
                "pminub %%xmm13, %%xmm10\n\t"                               
                "pminub %%xmm8, %%xmm12\n\t"
                "pminub %%xmm8, %%xmm14\n\t"
                "pminub %%xmm12, %%xmm6\n\t"
                "pminub %%xmm14, %%xmm10\n\t"

                "paddusb %%xmm15, %%xmm6\n\t"
                "paddusb %%xmm11, %%xmm10\n\t"
                
                "pxor %%xmm9, %%xmm9\n\t"
#ifdef __AVX__ 
                "vpminub %%xmm4, %%xmm0, %%xmm11\n\t"
                "vpminub %%xmm5, %%xmm1, %%xmm12\n\t"
                "vpminub %%xmm6, %%xmm2, %%xmm13\n\t"
                "vpminub %%xmm10,%%xmm3, %%xmm14\n\t" 
#else
                "pshufd $228,%%xmm0, %%xmm11\n\t"
                "pshufd $228,%%xmm1, %%xmm12\n\t"
                "pshufd $228,%%xmm2, %%xmm13\n\t"
                "pshufd $228,%%xmm3, %%xmm14\n\t"
                
                
                "pminub %%xmm4, %%xmm11\n\t"
                "pminub %%xmm5, %%xmm12\n\t"
                "pminub %%xmm6, %%xmm13\n\t"
                "pminub %%xmm10, %%xmm14\n\t"                
#endif               
                
                "pminub %%xmm12, %%xmm11\n\t"
                "pminub %%xmm14, %%xmm13\n\t"               
                "pminub %%xmm11, %%xmm13\n\t"

                
                "pshufd $78,%%xmm13, %%xmm14\n\t"
                "pminub %%xmm14, %%xmm13\n\t"
#ifdef __SSE4_1__             
                "punpcklbw %%xmm13, %%xmm13\n\t"
                "phminposuw %%xmm13, %%xmm13\n\t"           
#else
                "pshufd $1, %%xmm13, %%xmm14\n\t"
                "pminub %%xmm14, %%xmm13\n\t"
                "pshuflw $1, %%xmm13, %%xmm14\n\t"
                "pminub %%xmm14, %%xmm13\n\t"
                "punpcklbw %%xmm13, %%xmm13\n\t"
                "pshuflw $1, %%xmm13, %%xmm14\n\t"
                "pminub %%xmm14, %%xmm13\n\t"               
#endif                               
                "pshufb %%xmm9, %%xmm13\n\t"
                
                "movdqa  (%0), %%xmm9\n\t" 
                "movdqa  16(%0), %%xmm11\n\t" 
                "movdqa  32(%0), %%xmm12\n\t" 
                "movdqa  48(%0), %%xmm14\n\t" 
                "movdqa  64(%0), %%xmm15\n\t"

                "psubb %%xmm13, %%xmm0\n\t"
                "psubb %%xmm13, %%xmm1\n\t"
                "psubb %%xmm13, %%xmm2\n\t"
                "psubb %%xmm13, %%xmm3\n\t"
                "psubb %%xmm13, %%xmm4\n\t"
                "psubb %%xmm13, %%xmm5\n\t"
                "psubb %%xmm13, %%xmm6\n\t"
                "psubb %%xmm13, %%xmm10\n\t"
                
                "movdqa  80(%0), %%xmm13\n\t"
                
                "paddusb  %%xmm0, %%xmm9\n\t" 
                "paddusb  %%xmm1, %%xmm11\n\t"
                "paddusb  %%xmm2, %%xmm12\n\t" 
                "paddusb  %%xmm3, %%xmm14\n\t"  
                "paddusb  %%xmm4, %%xmm15\n\t" 
                "paddusb  %%xmm5, %%xmm13\n\t"
                
                "movdqa  %%xmm9, (%0)\n\t"
                "movdqa  %%xmm11, 16(%0)\n\t"
                "movdqa  %%xmm12, 32(%0)\n\t"
                "movdqa  %%xmm14, 48(%0)\n\t"
                "movdqa  %%xmm15, 64(%0)\n\t"
                "movdqa  %%xmm13, 80(%0)\n\t"
                
                "movdqa  96(%0), %%xmm9\n\t" 
                "movdqa  112(%0), %%xmm11\n\t" 
                
                "paddusb  %%xmm6, %%xmm9\n\t" 
                "paddusb  %%xmm10, %%xmm11\n\t"
                
                "movdqa  %%xmm9, 96(%0)\n\t"
                "movdqa  %%xmm11, 112(%0)\n\t"
            
              :  : 
              "r"(disparityPathCube),"r"(disparityCube) 
              : "%xmm0", "%xmm1", "%xmm2", "%xmm3","%xmm4", "%xmm5"
            );  
        
            
            
            
}
#endif

#endif
