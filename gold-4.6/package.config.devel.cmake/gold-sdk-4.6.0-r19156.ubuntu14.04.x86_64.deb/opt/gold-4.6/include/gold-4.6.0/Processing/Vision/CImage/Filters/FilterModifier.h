#ifndef _FILTER_MODIFIER_H
#define _FILTER_MODIFIER_H

#include "detail/FilterModifier.hxx"

/** @file FilterModifier.h
  * @brief questo file contiene tutti i modificatori per i filtri.
  * I modificatori presenti in questo file sono:
  * - filter::Source     usa l'immagine sorgente senza alcun processing (serve come inizio per altri filtri)
  * - filter::Sign       trasforma il dato del filtro in -1 0 1 a seconda del segno
  * - filter::Ternarize  trasforma il dato in 0 127 254 a seconda del segno
  * - filter::Abs        ritorna il valore assoluto del filtro
  * - filter::Clamp8s    limita il filtro tra -128 e 127
  * - filter::Clamp8u    limita il filtro tra 0 e 255
  * - filter::Div	 Divide l'output del filtro per un numero intero (normalmente per normalizzare l'output)
  * - filter::Bin        Binarizza l'output del filtro tra 0 e 255 a seconda della soglia th 
  * e altri
  * Contiene anche le policy per i filtri
  * - policy::All          Policy che usa tutti i punti della finestra
  * - policy::NotZero      Policy che usa solo i punti diversi da 0
  * - policy::Not          Policy che inverte il comportamento di una policy
  * - policy::FixedSize	   Filtro a dimensione fissa
  * - policy::VariableSize Filtro a dimensione variabile
  **/


namespace cimage {
    
//////////////////////////////// policy per i filtri //////////////////////
namespace policy {

  /** return true for all the element.
   * Mask Policy.
   * */
  class All {
    protected:  
    template<class T>
    inline bool operator()(const T & src) const { return true; } 
  };

  /** return true if is NotZero.
   * Mask Policy.
   * */
  class NotZero {
    protected:   
    template<class T>
    inline bool operator()(const T & src) const { return src != T(0); }
  };

  /** Invert behavior of a filter policy.
   * Mask Policy.
   * */
  template<class F>
  class Not: public F {
    protected:   
    template<class T>
    inline bool operator()(const T & src) const { return !F::template operator()(src); }
  };

  /** Fixed Size filter.
   * \code
   * MyFilter< filter::FixedSize<3,3> >
   * \endcode
   * */
  template<uint32_t width, uint32_t height>
  class FixedSize {
    public:
        static uint32_t GetWidth() { return width; }
        static uint32_t GetHeight() { return height; }
  };

  /** Dynamic Size filter.
   * \code
   * MyFilter< VariableSize >
   * ....
   * myFilter.SetGeometry(5,5);
   * \endcode
   * */
  class VariableSize {
      uint32_t m_width;
      uint32_t m_height;
    public:
        VariableSize() : m_width(3), m_height(3){}
        
        inline void SetWidth(uint32_t width)    { if(m_width > 0 ) m_width = width;}
        inline void  SetHeight(uint32_t height)  { if(m_height > 0 ) m_height = height;}
        inline void SetGeometry(int _w, int _h) {  SetWidth(_w); SetHeight(_h);	}
        inline void SetGeometry(int _s) {  SetWidth(_s); SetHeight(_s);	}
        uint32_t GetWidth() const { return m_width; }
        uint32_t GetHeight() const { return m_height; }  
 };
 
 
} // policy

//////////////////////////////// modificatori per i filtri //////////////////////
namespace filter {
  
/**
 * \brief Implementa il calcolo di una maschera 3x3 orizzontale di Sobel (NON effettua il valore assoluto)
*/
class Source
{
  public:

   template<typename S>
   struct Return {
        typedef S Type;
	};

    template<class D>
    inline D zero() const { return 0; }
    inline uint32_t GetWidth() const { return 1; }
    inline uint32_t GetHeight() const { return 1; }
    template<class S>
    inline S operator() ( const S* inputPixel, long stride ) const {
      return inputPixel[0];
    }
};



/** \brief Filtro modificatore, trasforma il filtro tra valori a -1 (se < -th), 0 (se compreso) o +1 (se > th)
*/
template<typename F, int th =0>
class Sign : public F
{
  public:

    template<class D>
    inline D zero() {
	return D(0);
	}

   template<typename S>
   struct Return {
        typedef int Type;
	};

    template<class S>
    inline int operator() ( const S* inputPixel, long stride ) const
    {
      return detail::sign<th>(F::operator()(inputPixel, stride));
    }
};

/** \brief Filtro modificatore, trasforma il filtro tra valori 0 (se < th), 127 (se 0) o 254 (se > th)
 */
template<typename F, int th>
class Ternarize : public F
{
  public:
    template<class D>
    inline D zero() {
	return D(127);
	}

   template<typename S>
   struct Return {
        typedef unsigned char Type;
	};

    template<class S>
    inline unsigned char operator() ( const S* inputPixel, long stride ) const
    {
      return detail::tern<th>(F::operator()(inputPixel, stride));
    }
};

/** \brief restituisce il valore assoluto dell'output del filtro */
template<typename F>
class Abs : public F
{
  public:
    template<class D>
    inline D zero() {
	return D(0);
	}

   template<typename S>
   struct Return {
        typedef typename F::template Return<S>::Type Type;
	};

    template<class S>
    inline typename Return<S>::Type operator() ( const S* inputPixel, long stride ) const
    {
      return std::abs(F::operator()(inputPixel, stride));
    }
};

/** \brief limita l'output del filtro a valori compresi tra 0 e 255 */
template<typename F>
class Clamp8u : public F
{
  public:

    template<class D>
    inline D zero() {
	return D(0);
	}

   template<typename S>
   struct Return {
        typedef unsigned char Type;
	};

    template<class S>
    inline unsigned char operator() ( const S* inputPixel, long stride ) const
    {
      return detail::clamp8u(F::operator()(inputPixel, stride));
    }
};

/** \brief limita l'output del filtro a valori compresi tra -128 e 127 */
template<typename F>
class Clamp8s : public F
{
  public:

    template<class D>
    inline D zero() {
	return D(0);
	}

   template<typename S>
   struct Return {
        typedef signed char Type;
	};

    template<class S>
    inline signed char operator() ( const S* inputPixel, long stride ) const
    {
      return detail::clamp8s(F::operator()(inputPixel, stride));
    }
};

/// Gamma correction filter modifier (without LookUpTable)
class Gamma {
  float m_gamma;  
//   float m_igamma;
  
public:
  
  Gamma(float gamma=1.0f) { SetGamma(gamma); }
  
  inline void SetGamma(float gamma) { m_gamma = gamma; }
  inline float GetGamma() const { return m_gamma; }  

   template<typename S>
   struct Return {
        typedef uint8_t Type;
	};
	
  template<class S>
  uint8_t operator()(const S * src, long ii) const
  {
    return (uint8_t)(255*std::pow(src[ii]/(float)255, m_gamma));
  }
};


/** \brief Aggiunge una costante all'output del filtro
 **/
template<typename F, int _bias>
class Bias : public F
{
public:
  /// modified bias
     static const unsigned int bias = F::bias + _bias;
     
public:

    template<class D>
    inline D zero() {
	return D(F::template zero<D>()+_bias);
	}

   template<typename S>
   struct Return {
        typedef typename F::template Return<S>::Type Type;
	};

    template<class S>
    inline typename Return<S>::Type operator() ( const S* inputPixel, long stride ) const
    {
      return F::operator()(inputPixel, stride) + _bias;
    }
};


/** \brief Modify a filter applying a uint8_t binarization (x > th ? 255 : 0).
 * Binarizza l'output di un filtro (e' un modificatore).
 * I valori inferiori alla soglia vengono messi a 0, quelli sopra a 255
 * 
 * \code
 * filter::Bin< MyFilter > bin;
 * ...
 * bin.SetThreshold( 100 );
 * \endcode
 * 
 * @todo develop a version with dynamic response for low and high
*/
template<typename F, typename T=int, uint8_t _bin_low = 0, uint8_t _bin_hi = 255>
class Bin: public F
{
  /// the inner threshold
    T m_threshold;
    
public:

  // workaround for static const problem  
    enum {
       bin_low = _bin_low,  ///< response below threshold
       bin_high = _bin_hi   ///< response over threshold
    };

public:

    template<class D>
    inline D zero() {
	return D(0);
	}

   template<typename S>
   struct Return {
        typedef unsigned char Type;
	};

public:

    /**
     * Funzione utile per gli slider del pannello
     * @return Il valore della soglia
     */
    T GetThreshold() const { return m_threshold; }
    /**
     * Funzione per settare il valore della soglia.
     * @param threshold Il valore che si vuole settare per la soglia
     */
    void SetThreshold ( const T threshold ) { m_threshold = threshold; }

    template<class S>
    inline unsigned char operator() ( const S* inputPixel, long stride ) const
    {
      return (F::operator()(inputPixel, stride) > m_threshold) ? bin_high : bin_low;
    }
};

/** \brief Binarizza il risultato in valore assoluto del filtro 
 * I valori compresi tra -th e +th vengono messi a 0, altrimenti 255
*/
template<typename F, typename T=int>
class AbsBin: public F
{
    T m_threshold;

  public:

    template<class D>
    inline D zero() {
	return D(0);
	}

   template<typename S>
   struct Return {
        typedef uint8_t Type;
	};
    /**
     * Funzione utile per gli slider del pannello
     * @return Il valore della soglia
     */
    T GetThreshold() const { return m_threshold; }
    /**
     * Funzione per settare il valore della soglia.
     * @param threshold Il valore che si vuole settare per la soglia
     */
    void SetThreshold ( const T threshold ) { m_threshold = threshold; }

    template<class S>
    inline uint8_t operator() ( const S* inputPixel, long stride ) const
    {
      return detail::absbin(T(F::operator()(inputPixel, stride)), m_threshold);
    }
};

/** \brief divide il risultato del filtro per il numero proposto nel template
**/
template<typename F, int V >
class Div: public F
{
  public:
    
   /// Output Filter Magnitude
   static const unsigned int magnitude = F::magnitude / V;

   template<typename S>
   struct Return {
        typedef typename F::template Return<S>::Type Type;
	};

    template<class D>
    inline int zero() {
	return F::template zero<D>()/V;
	}

    template<class S>
    inline typename Return<S>::Type operator() ( const S* inputPixel, long stride ) const
    {
      return F::operator()(inputPixel, stride) / V;
    }
};

/// shifts right and adds either 0s, if value is an unsigned type, or extends the top bit (to preserve the sign) if its a signed type. 
template<typename F, int l >
class Shr: public F
{
  public:
    
   /// Output Filter Magnitude
   static const unsigned int magnitude = F::magnitude >> l;

   template<typename S>
   struct Return {
        typedef typename F::template Return<S>::Type Type;
	};

    template<class D>
    inline D zero() {
	return F::template zero<D>() >> l;
	}

    template<class S>
    inline typename Return<S>::Type operator() ( const S* inputPixel, long stride ) const
    {
      return F::operator()(inputPixel, stride) >> l;
    }
};

/// shifts left and adds zeros at the right end.
template<typename F, int l >
class Shl: public F
{
  public:
    
   /// Output Filter Magnitude
   static const unsigned int magnitude = F::magnitude << l;

   template<typename S>
   struct Return {
        typedef typename F::template Return<S>::Type Type;
	};

    template<class D>
    inline D zero() {
	return F::template zero<D>() << l;
	}

    template<class S>
    inline typename Return<S>::Type operator() ( const S* inputPixel, long stride ) const
    {
      return F::operator()(inputPixel, stride) << l;
    }
};

/** \brief Quantizza il valore dell'output del filtro */
template<int n, typename F>
class Quantize : public F
{
  public:
    template<class D>
    inline D zero() {
	return D(0);
	}

   template<typename S>
   struct Return {
        typedef typename F::template Return<S>::Type Type;
	};

    template<class S>
    inline typename Return<S>::Type operator() ( const S* inputPixel, long stride ) const
    {
      return detail::qtz<n>(F::operator()(inputPixel, stride));
    }
};

/// riserva il colore chiave per operazioni di pixel non definito.
template<uint8_t src, uint8_t dst, typename F>
class TReplace : public F
{
  public:
    template<class D>
    inline D zero() {
	return D(0);
	}

   template<typename S>
   struct Return {
        typedef uint8_t Type;
	};

    template<class S>
    inline uint8_t operator() ( const S* inputPixel, long stride ) const
    {
      uint8_t v = F::operator()(inputPixel, stride);
      return (v == src) ? dst : v;
    }
};

/// riserva il colore chiave per operazioni di pixel non definito.
///  (Tunable version)
template<typename Format, typename F>
class Replace : public F
{
  Format m_src, m_dst;
  
  public:
    
    Replace() { }
    Replace(Format src, Format dst) : m_src(src), m_dst(dst) { }
    
    /// Set the source Color
    inline void SetSource(Format src)      { m_src = src; }
    /// Set the Destination color
    inline void SetDestination(Format dst) { m_dst = dst; }
    /// return the source color
    inline Format GetSource() const        { return m_src; }
    /// return the destination color
    inline Format GetDestination() const   { return m_dst; }
    
    template<class D>
    inline D zero() {
	return D(0);
	}

   template<typename S>
   struct Return {
        typedef Format Type;
	};

    template<class S>
    inline Format operator() ( const S* inputPixel, long stride ) const
    {
      Format v = F::operator()(inputPixel, stride);
      return (v == m_src) ? m_dst : v;
    }
};

/** \brief Filtro compositivo: ritorna il valore massimo dei due filtri che lo compongono
  **/
template<typename A, typename B >
class Max2
{
  public:
  
  static const unsigned int magnitude = static_max(A::magnitude, B::magnitude);
  
  public:

    A a;
    B b;

  public:

   uint32_t GetWidth() { return std::max(a.GetWidth(), b.GetWidth() ); }
   uint32_t GetHeight() { return std::max(a.GetHeight(), b.GetHeight() ); }

   template<typename S>
   struct Return {
        typedef typename A::template Return<S>::Type Type;
	};

    template<class D>
    inline int zero() {
	return std::max(a.template zero<D>(), b.template zero<D>() );
	}

    template<class S>
    inline typename Return<S>::Type operator() ( const S* inputPixel, long stride ) const
    {
      return std::max(a(inputPixel, stride), b(inputPixel, stride));
    }
};

/** \brief Filtro Compositivo: ritorna il valore minimo dei due filtri che lo compongono
**/
template<typename A, typename B >
class Min2
{
  public:
  
  static const unsigned int magnitude = static_min(A::magnitude, B::magnitude);
  
  public:

    A a;
    B b;

   uint32_t GetWidth() { return std::max(a.GetWidth(), b.GetWidth() ); }
   uint32_t GetHeight() { return std::max(a.GetHeight(), b.GetHeight() ); }

   template<typename S>
   struct Return {
        typedef typename A::template Return<S>::Type Type;
	};

    template<class D>
    inline int zero() {
	return std::min(a.template zero<D>(), b.template zero<D>());
	}
    template<class S>
    inline int operator() ( const S* inputPixel, long stride ) const
    {
      return std::min(a(inputPixel, stride), b(inputPixel, stride));
    }
};

/** \brief Filtro Compositivo: ritorna il valore ritornato dal filtro A e quello del filtro B
**/
template<typename A, typename B >
class Sum2
{
  public:
  
  static const unsigned int magnitude = A::magnitude + B::magnitude;
  static const int bias = A::bias + B::bias;
  
  public:

    A a;
    B b;

   uint32_t GetWidth() { return std::max(a.GetWidth(), b.GetWidth() ); }
   uint32_t GetHeight() { return std::max(a.GetHeight(), b.GetHeight() ); }

   template<typename S>
   struct Return {
        typedef typename A::template Return<S>::Type Type;
	};

    template<class D>
    inline int zero() {
	return a.template zero<D>() + b.template zero<D>();
	}
    template<class S>
    inline int operator() ( const S* inputPixel, long stride ) const
    {
      return a(inputPixel, stride) + b(inputPixel, stride);
    }
};


/** \brief Filtro Compositivo: ritorna il valore ritornato dal filtro A meno quello del filtro B
**/
template<typename A, typename B >
class Diff2
{
  public:

    A a;
    B b;

   uint32_t GetWidth() { return std::max(a.GetWidth(), b.GetWidth() ); }
   uint32_t GetHeight() { return std::max(a.GetHeight(), b.GetHeight() ); }

   template<typename S>
   struct Return {
        typedef typename A::template Return<S>::Type Type;
	};

    template<class D>
    inline int zero() {
	return a.template zero<D> - b.template zero<D>;
	}
    template<class S>
    inline int operator() ( const S* inputPixel, long stride ) const
    {
      return a(inputPixel, stride) - b(inputPixel, stride);
    }
};

/** Calcola un hash per unire due filtri insieme **/
template<typename A, typename B >
class Hash
{
  
  public:

    int m_threshold;
    
    A a;
    B b;
    
  public:

   /**
    * Funzione utile per gli slider del pannello
    * @return Il valore della soglia
    */
   int GetThreshold() const { return m_threshold; }
   
   /**
    * Funzione per settare il valore della soglia.
    * @param threshold Il valore che si vuole settare per la soglia
    */
   void SetThreshold ( const int threshold ) { m_threshold = threshold; }    
    
   uint32_t GetWidth() { return std::max(a.GetWidth(), b.GetWidth() ); }

   uint32_t GetHeight() { return std::max(a.GetHeight(), b.GetHeight() ); }

   template<typename S>
   struct Return {
	typedef uint8_t Type;
	};

    template<class D>
    inline uint8_t zero() {
	return 0;
	}
    template<class S>
    inline uint8_t operator() ( const S* inputPixel, long stride ) const
    {
      return detail::hash( a(inputPixel, stride), b(inputPixel, stride), m_threshold );
    }
};

/** Binarizza sul Modulo 
  * Questo filtro prende due filtri e confronta il loro risultato in modulo se e' maggiore o inferiore a una determinata soglia
 **/
template<typename A, typename B, typename T = int >
class ModuleBin
{

    T m_threshold;
    T m_threshold2;
    
    A a;
    B b;


  public:

    template<class D>
    inline D zero() {
	return D(0);
	}

   template<typename S>
   struct Return {
        typedef uint8_t Type;
	};
    /**
     * Funzione utile per gli slider del pannello
     * @return Il valore della soglia
     */
    T GetThreshold() const { return m_threshold; }
    /**
     * Funzione per settare il valore della soglia.
     * @param threshold Il valore che si vuole settare per la soglia
     */
    void SetThreshold ( const T threshold ) { m_threshold = threshold; m_threshold2 = threshold*threshold; }

    uint32_t GetWidth() { return std::max(a.GetWidth(), b.GetWidth() ); }
    uint32_t GetHeight() { return std::max(a.GetHeight(), b.GetHeight() ); }

    template<class S>
    inline uint8_t operator() ( const S* inputPixel, long stride ) const
    {
      T va = a(inputPixel, stride);
      T vb = b(inputPixel, stride);
      return ((va*va + vb*vb) > m_threshold2) ? 255 : 0;
    }
};
        

/** Modulo **/
template<typename A, typename B >
class Module
{

  public:

    A a;
    B b;

   uint32_t GetWidth() { return std::max(a.GetWidth(), b.GetWidth() ); }
   uint32_t GetHeight() { return std::max(a.GetHeight(), b.GetHeight() ); }

   template<typename S>
   struct Return {
        // typedef typename A::template Return<S>::Type Type;
	typedef float Type;
	};

    template<class D>
    inline D zero() {
	return __module(a.template zero<D>(), b.template zero<D>() );
	}
    template<class S>
    inline float operator() ( const S* inputPixel, long stride ) const
    {
      return detail::module( a(inputPixel, stride), b(inputPixel, stride) );
    }
};

/** return the module and phase packed in a pair */
template<typename A, typename B >
class MakePair_Module_Phase
{

  public:

    A a;
    B b;

   uint32_t GetWidth() { return std::max(a.GetWidth(), b.GetWidth() ); }
   uint32_t GetHeight() { return std::max(a.GetHeight(), b.GetHeight() ); }

   template<typename S>
   struct Return {
        // typedef typename A::template Return<S>::Type Type;
	typedef std::pair<int,float> Type;
	};

    template<class D>
    inline D zero() {
	return D(0, 0.0);
	}
    template<class S>
    inline std::pair<int,float> operator() ( const S* inputPixel, long stride ) const
    {
      return detail::module_phase( a(inputPixel, stride), b(inputPixel, stride) );
    }
};


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/** Impacchetta due filtri con ouput uint8_t in un filtro uint16_t */
template<typename X, typename Y >
class Pack8u16u
{
  
public:

    X x;
    Y y;

public:
  
   uint32_t GetWidth() { return std::max(x.GetWidth(), y.GetWidth() ); }
   uint32_t GetHeight() { return std::max(x.GetHeight(), y.GetHeight() ); }

   template<typename S>
   struct Return {
	typedef uint16_t Type;
	};

    template<class D>
    inline D zero() {
	return detail::pack8u16u( x.template zero<D>(), y.template zero<D>() );
	}
    template<class S>
    inline uint16_t operator() ( const S* inputPixel, long stride ) const
    {
      return detail::pack8u16u( x(inputPixel, stride), y(inputPixel, stride) );
    }
};

} // namespace filter

} // namespace cimage

#endif
