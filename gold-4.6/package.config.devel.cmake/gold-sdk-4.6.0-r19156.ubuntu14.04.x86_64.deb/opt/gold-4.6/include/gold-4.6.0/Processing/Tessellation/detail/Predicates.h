#ifndef _PREDICATES_HXX
#define _PREDICATES_HXX

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file Predicates.hxx
 * @author Mirko Felisa (felisa@vislab.it)
 * @date 2012-04-16
 */

#include<limits>

namespace tessellation
{

    namespace detail
    {

        inline int Counterclockwise(double ax, double ay, double bx, double by, double cx, double cy)
        {
            double area = (ax - cx) * (by - cy) - (ay - cy) * (bx - cx);
            const double epsilon = 10 * std::numeric_limits<double>::epsilon();
            return (area > epsilon) - (area < epsilon);
        }


        inline int Counterclockwise(int ax, int ay, int bx, int by, int cx, int cy)
        {
            int area = (ax - cx) * (by - cy) - (ay - cy) * (bx - cx);

            return (area > 0) - (area < 0);
        }

        inline bool Incircle(double ax, double ay, double bx, double by, double cx, double cy, double dx, double dy)
        {

            double adx = ax - dx;
            double bdx = bx - dx;
            double cdx = cx - dx;
            double ady = ay - dy;
            double bdy = by - dy;
            double cdy = cy - dy;

            double bdxcdy = bdx * cdy;
            double cdxbdy = cdx * bdy;
            double alift = adx * adx + ady * ady;

            double cdxady = cdx * ady;
            double adxcdy = adx * cdy;
            double blift = bdx * bdx + bdy * bdy;

            double adxbdy = adx * bdy;
            double bdxady = bdx * ady;
            double clift = cdx * cdx + cdy * cdy;

            const double epsilon = 10 * std::numeric_limits<double>::epsilon();
            return (alift * (bdxcdy - cdxbdy) + blift * (cdxady - adxcdy) + clift * (adxbdy - bdxady) > epsilon);

        }

        inline bool Incircle(int ax, int ay, int bx, int by, int cx, int cy, int dx, int dy)
        {

            int adx = ax - dx;
            int bdx = bx - dx;
            int cdx = cx - dx;
            int ady = ay - dy;
            int bdy = by - dy;
            int cdy = cy - dy;

            long bdxcdy = bdx * cdy;
            long cdxbdy = cdx * bdy;
            long alift = adx * adx + ady * ady;

            long cdxady = cdx * ady;
            long adxcdy = adx * cdy;
            long blift = bdx * bdx + bdy * bdy;

            long adxbdy = adx * bdy;
            long bdxady = bdx * ady;
            long clift = cdx * cdx + cdy * cdy;

            return (alift * (bdxcdy - cdxbdy) + blift * (cdxady - adxcdy) + clift * (adxbdy - bdxady) > 0);

        }

        template<typename T>
        inline int Counterclockwise(T a, T b, T c)
        {
            return Counterclockwise(a->x, a->y, b->x, b->y, c->x, c->y);
        }

        template<typename T>
        inline bool Incircle(T a, T b, T c, T d)
        {
            return Incircle(a->x, a->y, b->x, b->y, c->x, c->y, d->x, d->y);
        }

    }

}

#endif
