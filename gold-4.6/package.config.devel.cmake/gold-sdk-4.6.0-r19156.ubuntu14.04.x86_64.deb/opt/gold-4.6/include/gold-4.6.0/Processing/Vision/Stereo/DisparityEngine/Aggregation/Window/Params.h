#ifndef _WINDOW_PARAMS_H
#define _WINDOW_PARAMS_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file Params.h
 * \author Paolo Zani (zani@vislab.it) Mirko Felisa (felisa@vislab.it)
 * \date 2010-09-24
 */


#include <Libs/Compatibility/DeclSpecs.h>

#include <stdint.h>

namespace disparity
{
    class DECLSPEC_EXPORT WindowParams
    {
        public:

            static const int32_t VARIANCE = 0;
            static const int32_t SUM = 1;
            
            const double DEFAULT_MIN_VARIANCE;
            const double DEFAULT_MIN_SUM;
            static const int32_t DEFAULT_TEXTURE_ALGO = SUM;
            static const uint32_t DEFAULT_WINDOW_WIDTH = 5;
            static const uint32_t DEFAULT_WINDOW_HEIGHT = 9;

            WindowParams() :
                    DEFAULT_MIN_VARIANCE(10.0),
                    DEFAULT_MIN_SUM(0.0),
                    m_minVariance(DEFAULT_MIN_VARIANCE),
                    m_minSum(DEFAULT_MIN_SUM),
                    m_textureAlgo(DEFAULT_TEXTURE_ALGO),
                    m_winWidth(DEFAULT_WINDOW_WIDTH),
                    m_winHeight(DEFAULT_WINDOW_HEIGHT) {}

            double m_minVariance;
            double m_minSum;
            int32_t m_textureAlgo;

            uint32_t m_winWidth;
            uint32_t m_winHeight;
    };
}

#endif 
