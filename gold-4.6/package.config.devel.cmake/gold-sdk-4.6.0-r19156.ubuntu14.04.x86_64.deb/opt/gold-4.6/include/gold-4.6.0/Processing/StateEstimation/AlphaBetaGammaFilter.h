#ifndef _ALPHA_BETA_GAMMA_FILTER_H
#define _ALPHA_BETA_GAMMA_FILTER_H

#include <Eigen/Core>

namespace state_estimation {

  /** A simple alpha-beta-gamma filter 
   * 
   * Alpha-Beta filter observer position of an object and return a state with
   * (0) position, (1) speed, (2) acceleration
   */
  template<class _Scalar>
  class AlphaBetaGammaFilter {
  public:
    typedef Eigen::Matrix<_Scalar,3,1> StateType;
    
  private:
    /// the state
    StateType m_state;
    /// the smoothing parameters
    _Scalar m_alpha, m_beta, m_gamma;
    
  public:
    
    AlphaBetaGammaFilter() : m_alpha(1), m_beta(1), m_gamma(1) { }
    AlphaBetaGammaFilter(_Scalar alpha, _Scalar beta, _Scalar gamma) : m_alpha(alpha), m_beta(beta), m_gamma(gamma) { }
    
    
    StateType & State() { return m_state; }
    const StateType & State() const { return m_state; }
    
    /// Modify the Alpha parameters (position smoothing)
    _Scalar & Alpha() { return m_alpha; }
    /// Modify the Beta parameters (speed smoothing)
    _Scalar & Beta() { return m_beta; }
    /// Modify the Gamma parameters (acceleration smoothing)
    _Scalar & Gamma() { return m_gamma; }
    
    /** Execute a Step of AlphaBeta filter */
    void Step(_Scalar x, _Scalar dt)
    {
      _Scalar dx = x - m_state(0);
      m_state(0) += m_alpha * dx;
      m_state(1) += m_beta * (dx / dt);
      m_state(2) += m_gamma * (dx / (_Scalar(2)*dt*dt));
    }
  };
  
}

#endif
