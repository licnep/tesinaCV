/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2007                  *
 *                                                                    *
 *       http://vislab.it                                             *
 *                                                                    *
 *  Author: Medici Paolo                                              *
 **********************************************************************/
 
#ifndef _X_IMAGE_LUT_H
#define _X_IMAGE_LUT_H

/** @file XImageLUT.h
  * @brief Trasformazioni omografe con LUT
  **/

#include <Data/Math/TMatrices.h>
#include "HomographicMatrix.h"
#include "ImageLUT.h"

/** TXImageLUT permette di applicare trasformazioni omografiche su immagine basate sulla matrice omografa 3x3 calcolando prima una LUT.
 *
 * E' simile in tutto e per tutto a una ImageLUT ma prende come input una TMatrix omografa. Per una introduzione
 *  sulle trasformazioni omografe vedere ht::HomographicTransformation.
 *
 * In teoria la Compute e' piu veloce di quella di una PMImageLUT o IPMImageLUT ma offre meno servizi. 
 *  Da test eseguiti Compute impiega il 30\% in meno rispetto allo stesso Compute di IPMImageLUT. Allo stesso modo calcolare la LUT e' leggermente piu' veloce che 
 *  applicare la trasformazione omografica direttamente (ovvero conviene se si
 *  applica su piu' immagini la stessa LUT).
 *
 * Le classi da instazionare sono, a seconda del tipo di interpolazione, XDirectImageLUT, XBilinearImageLUT o XFPBilinearImageLUT. 
 * \code
 *  xrIpmLUT = new XFPBilinearImageLUT(m_ipmWidth,m_ipmHeight,m_width,m_height);
 *  // ...
 *  xrIpmLUT->SetMatrix(ht::IPM(camera_params,plane,m_ipmWidth,m_ipmHeight).Matrix());
 * \endcode 
 *
 * @note le classi XDirectImageLUT, XBilinearImageLUT o XFPBilinearImageLUT sono
 *       compilate all'interno della libreria. Per sviluppare delle proprie LUT
 *       basate su funzioni interpolanti proprietarie includere XImageLUT.tcc.
 **/
template<class T, class D = double>
class TXImageLUT : public T
{
 public:
 typedef math::TMatrix<D,3,3> Matrix_t;
 private:
 Matrix_t m;
 bool computed;  ///< la lUT e' calcolata o devo eseguire la Compute?
 public:
    /// Class Constructor
    /// @param imgLUTWidth,imgLUTHeight dimensione immagine destinazione
    /// @param srcImgWidth,srcImgHeight dimensione immagine sorgente
    TXImageLUT(unsigned int imgLUTWidth, unsigned int imgLUTHeight, unsigned int srcImgWidth, unsigned int srcImgHeight) 
      : T(imgLUTWidth, imgLUTHeight, srcImgWidth, srcImgHeight), computed(false) {}
    
    TXImageLUT(const Matrix_t & _m, unsigned int imgLUTWidth, unsigned int imgLUTHeight, unsigned int srcImgWidth, unsigned int srcImgHeight) 
      : T(imgLUTWidth, imgLUTHeight, srcImgWidth, srcImgHeight), m(_m), computed(false) {}
    
    // Class Destructor
    ~TXImageLUT() {};

    /// Calcola la XImageLUT
    void Compute(void);

#ifdef I_AM_MASOCHISTIC
    /// Calcola la XImageLUT in maniera fine!
    void FineCompute(void);
#endif

    /// Cambia la matrice di sistema    
    inline void SetMatrix(const Matrix_t & _m)
    {
        m = _m;
        computed = false;
    }
    
    void ApplyToImage(unsigned char* dstImage, const unsigned char* srcImage, unsigned int bpp, const math::Rect2i* area=NULL)
    {
        if(!computed)
            Compute();
        T::ApplyToImage(dstImage, srcImage, bpp, area);
    }
    
};

/// Una perspective mapping LUT che usa un filtro nearest
typedef TXImageLUT<DirectImageLUT> XDirectImageLUT;
/// Una perspective mapping LUT che usa un filtro bilineare
typedef TXImageLUT<BilinearImageLUT> XBilinearImageLUT;
/// Una perspective mapping LUT che usa un filtro bilineare fixed point
typedef TXImageLUT<FPBilinearImageLUT> XFPBilinearImageLUT;

#endif
