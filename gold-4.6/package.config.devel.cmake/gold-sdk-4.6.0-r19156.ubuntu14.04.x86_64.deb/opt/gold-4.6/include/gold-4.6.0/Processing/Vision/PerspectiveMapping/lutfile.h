#ifndef _LUT_FILE_H
#define _LUT_FILE_H

/** @file lutffile.h 
  * @brief Dichiarazioni comuni per i file LUT 
  */


#define LUT_HEADER_ID		"LUTX"
#define LUT_HEADER_VERSION	0

#define LUT_TYPE_SIMPLE		0
#define LUT_TYPE_GENERIC	1

#define LUT_DATA_INT		0
#define LUT_DATA_FLOAT		1
#define LUT_DATA_DOUBLE		2

/** Questo e' l'header del file di LUT binario */
struct LUTFileHeader {
	char id[4];	///< LUT_HEADER_ID

	unsigned char version;		///< version (LUT_HEADER_VERSION)
	unsigned char size;			///< size of this header (to revision check) 
	unsigned char type;			///< simple, gaussian, etc etc
	unsigned char data_type;	///< int,float,double
     
	unsigned int lut_width, lut_height;
	unsigned int src_width, src_height;
};

// seguono nel file un array lut_width x lut_height di Point2<T> con T:{int,float,double} come indicato in data_type

#endif
