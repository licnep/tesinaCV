#ifndef _STEREOVISIONTOOLS_H
#define _STEREOVISIONTOOLS_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file StereoVisionTools.h
 * \author Paolo Zani (zani@ce.unipr.it)
 * \date 2006-09-08
 */

#include <Processing/Vision/Stereo/Images/CDSI.h>
#include <Processing/Vision/PerspectiveMapping/ipm.h>
#include <Data/Math/Points.h>
#include <Processing/Vision/PerspectiveMapping/StereoInversePerspectiveMapping.h>
#include <Libs/Threads/Parallelize.h>
#include <Libs/Logger/Log.h>
#include <boost/thread/thread.hpp>
#include <limits>
#include <utility>

namespace detail
{
  
  /**
 * \brief Maps each known point of a Disparity Space Image into the corresponding world coords
 * @param [in] dsi CDSI the Disparity Space Image
 * @param [in] CStereoInversePerspectiveMapping the stereo IPM associated with cameras calibration parameters 
 * @param [out] world std::vector<Point3<T> > the computed world coords
 * @note pixels with a disparity value lower than cameras vergence are mapped to (inf, 0, 0), with inf being the maximum representable value for the given precision
 */
template<typename T>
inline void DSIToWorldCoords(const CDSI& dsi, const CStereoInversePerspectiveMapping<T>& stereoIpm, std::vector<math::Point3<T> >& world, unsigned int algo, uint32_t threadID, uint32_t threadNum)
{
    const unsigned int width = dsi.W();
    const unsigned int height = dsi.H();
    const Disparity* pDisparityBuffer = dsi.Buffer();
    const Disparity vergence = Disparity(stereoIpm.GetVergence());

    uint32_t k0 = (height * threadID) / threadNum;
    uint32_t k1 = (height * (threadID + 1)) / threadNum;
    if (algo == CStereoInversePerspectiveMapping<T>::ALGO_SIMPLE)
    {
      for(unsigned int j = k0, stride= k0 * width; j < k1; ++j, stride+=width)
          for(unsigned int i = 0; i < width; ++i)
          {
              unsigned int index = stride + i;
              T d = pDisparityBuffer[index];

              if(d > vergence)
                  world[index] = stereoIpm.WorldFromPixels_StrictlyAlignedCameras(std::make_pair(math::Point2<T>(i + d, j), math::Point2<T>(i, j)));
              else
                  world[index] = math::Point3<T>(std::numeric_limits<T>::max(), 0.0, 0.0);
          }
     }else
     {
        for(unsigned int j = k0, stride= k0 * width; j < k1; ++j, stride+=width)
          for(unsigned int i = 0; i < width; ++i)
          {
              unsigned int index = stride + i;
              T d = pDisparityBuffer[index];

              if(d > vergence)
                  world[index] = stereoIpm. WorldFromPixels_AlignedCameras(std::make_pair(math::Point2<T>(i + d, j), math::Point2<T>(i, j)));
              else
                  world[index] = math::Point3<T>(std::numeric_limits<T>::max(), 0.0, 0.0);
          }
       
     }
  
}

}

/**
 * \brief Maps each known point of a Disparity Space Image into the corresponding world coords
 * @param [in] dsi CDSI the Disparity Space Image
 * @param [in] cameraParams std::pair<CameraParams, CameraParams> cameras calibration parameters
 * @param [out] world std::vector<Point3<T> > the computed world coords
 * @note pixels with a disparity value of DISPARITY_UNKNOWN are mapped to (inf, 0, 0), with inf being the maximum representable value for the given precision
 * @note if you expect to call this function repeatedly with the same camera params, consider generating the corresponting StereoIPM once
 * and using DSIToWorldCoords(CDSI, CStereoInversePerspectiveMapping, std::vector<Point3<T> >) instead
 */
template<typename T>
inline void DSIToWorldCoords(const CDSI& dsi,  std::pair<CameraParams, CameraParams> cameraParams, std::vector<math::Point3<T> >& world, int threadNum = boost::thread::hardware_concurrency())
{
    cameraParams.first.SetGeometry(dsi.W(), dsi.H());
    cameraParams.second.SetGeometry(dsi.W(), dsi.H());
    world.resize(dsi.Area());
    CStereoInversePerspectiveMapping<T> stereoIpm(cameraParams);
    unsigned int algo = stereoIpm.GetCamerasConfiguration();
    if (algo ==CStereoInversePerspectiveMapping<T>::ALGO_RAYTRACING)
    {
       log_error << "Cameras are not rectified. Check camera parameters."<< std::endl;
       throw;
    }
    else
    {  
       Parallelize(boost::bind(::detail::DSIToWorldCoords<T>, boost::cref(dsi), boost::cref(stereoIpm), boost::ref(world), algo, _1,_2), threadNum);
    }
}




/**
 * \brief Computes cameras field of view
 * @return std::vector<Point2d> the computed FOV (bottom-left, bottom-right, top-right, top-left)
 */
inline std::vector<math::Point2d> ComputeFOV(const std::pair<CameraParams, CameraParams>& cameraParams)
{
    InversePerspectiveMapping leftIpm(cameraParams.first);
    InversePerspectiveMapping rightIpm(cameraParams.second);

    std::vector<math::Point2d> fov;
    math::Point3d w(0.0, 0.0, 0.0);

    w = rightIpm.WorldFromPixelZ(0, (cameraParams.second.height - 1));
    fov.push_back(math::Point2d(w.x, w.y));

    w = leftIpm.WorldFromPixelZ(cameraParams.second.width, (cameraParams.first.height - 1));
    fov.push_back(math::Point2d(w.x, w.y));

    w = leftIpm.WorldFromPixelZ(static_cast<double>(cameraParams.second.width), std::min(leftIpm.GetHorizonY()+1.0, static_cast<double>(cameraParams.first.height)));
    fov.push_back(math::Point2d(w.x, w.y));

    w = rightIpm.WorldFromPixelZ(0.0, std::min(rightIpm.GetHorizonY()+1.0, static_cast<double>(cameraParams.second.height)));
    fov.push_back(math::Point2d(w.x, w.y));

    return fov;
}

#endif
