#ifndef _UI_CENSUS_H
#define _UI_CENSUS_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2011                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/


/**
 * \file UI_Census.h
 * \author Paolo Zani (zani@vislab.it)
 * \date 2011-02-08
 */

#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/Census/Params.h>

#include <UI/Panel/Panel.h>

namespace disparity
{
    // forward declarations

    namespace agg
    {
        template<typename ResultType_Cost, typename _ResultType_Agg, typename Impl_Agg, uint32_t _Threads_Agg>
        class Census;
    }

    template<typename Aggregation, typename Engine>
    class UI_Aggregation;

    template<typename ResultType_Cost, typename ResultType_Agg, typename Impl_Agg, uint32_t Threads_Agg, typename Engine>
    class UI_Aggregation<agg::Census<ResultType_Cost, ResultType_Agg, Impl_Agg, Threads_Agg>, Engine>
    {
        public:

            UI_Aggregation(Engine* _this) : m_this(_this) {}

            void Init(INIFile* pIni)
            {
                ui::var::Range<uint32_t> winWidth(&m_this->m_winWidth, DE_AGG_CENSUS_MIN_ARITY, DE_AGG_CENSUS_MAX_ARITY, 1);
                ui::var::Range<uint32_t> winHeight(&m_this->m_winHeight, DE_AGG_CENSUS_MIN_ARITY, DE_AGG_CENSUS_MAX_ARITY, 1);
                ui::var::Map<uint32_t> downsampleratio(&m_this->m_downsampleratio, std::make_pair("1", 1U), std::make_pair("2", 2U), std::make_pair("4", 4U) );
                
                ui::conf::Configuration conf(pIni);
                conf.Bind(winWidth, "WINDOW WIDTH", 5U);
                conf.Bind(winHeight, "WINDOW HEIGHT", 5U);
                conf.Bind(downsampleratio, "DOWNSAMPLE RATIO", std::string("1"));

                m_panel
                (
                    ui::wgt::GridSizer().Border(3).VExpand(0)
                    (
                        ui::wgt::SzCell(0, 0)( ui::wgt::Text("Downsample ratio").Border(3) ), ui::wgt::SzCell(0, 1).HExpand(0)(ui::wgt::ComboBox(downsampleratio).Border(3).HExpand(0).Geometry(50,-1))
                    ),
                    ui::wgt::VBoxSizer("Window").Border(3)
                    (
                    
                        ui::wgt::GridSizer().Border(3)
                        (
                            ui::wgt::SzCell(0, 0)( ui::wgt::Text("Width") ), ui::wgt::SzCell(0, 1).HExpand()( ui::wgt::Slider(winWidth) ),
                            ui::wgt::SzCell(1, 0)( ui::wgt::Text("Height") ), ui::wgt::SzCell(1, 1).HExpand()( ui::wgt::Slider(winHeight) )
                        )
                    )
                );
            }

            inline std::string Name() { return "Census"; }

            inline ui::wgt::Widget Panel() { return m_panel; }
            
        private:

            Engine* m_this;
            ui::wgt::VSizer m_panel;
    };
}

#endif
