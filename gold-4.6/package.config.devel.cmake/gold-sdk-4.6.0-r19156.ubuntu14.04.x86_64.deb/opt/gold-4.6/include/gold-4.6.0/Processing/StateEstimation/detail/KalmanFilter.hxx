#ifndef _KALMAN_FILTER_HXX
#define _KALMAN_FILTER_HXX

// the unimplemented state_estimation

namespace state_estimation {
  
namespace detail {

/// Internal Kalman Implementation
template<class PredictorImpl, class ObserverImpl, class _Scalar, class Predictor, class Observer, class ErrorPolicy>
class KalmanImpl;
  
}

}

#endif
