#ifndef _DISPARITYENGINE_CENSUS_LOOPS_H
#define _DISPARITYENGINE_CENSUS_LOOPS_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/

/**
 * \file Loops.h
 * \author Mirko Felisa (felisa@vislab.it)
 * \date 20010-10-28
 */

#include <Data/CImage/Pixels/Mono8.h>
#include <Data/CImage/Pixels/Mono8s.h>
#include <Data/CImage/Pixels/TRGB.h>
#include <Libs/Compatibility/DeclSpecs.h>

namespace disparity
{
    namespace impl
    {
        class Auto;
        class Cpp;
        class SIMD;
    }

    namespace census
    {
        
         //wrapper necessario per evitate lo static assert introdotto dalle boost-1.50 per dati con size > 64
         template <int a, bool c=(a<=64)>  struct safe_uint_t {  typedef typename boost::uint_t<a>::least type;};
         template <int a> struct safe_uint_t<a,0> { typedef void type;};
        
         template<uint32_t w, uint32_t h, class S>
         inline  typename boost::uint_t<w*h>::least Census(const S* inputPixel, long stride)
         {
                S p = inputPixel[0];
                typename boost::uint_t<w*h>::least census = 0;

                int stride2 = -(int)h/2 * stride - (int)w/2;

                for(uint32_t i = 0; i < h; ++i) {

                    int stride3 = stride2;

                    for(uint32_t j = 0; j < w; ++j) {

                        census = census << 1;

                        if(p <= inputPixel[stride3++])
                            census |= 1;
                    }

                    stride2 += stride;
                }

                return census;
         }
            
         template<uint32_t w, uint32_t h, class S>
         inline  typename safe_uint_t<3*w*h>::type Census(const cimage::TRGB<S>* inputPixel, long stride)
         {
                //   const cimage::RGB8& p = inputPixel[0];
                typename boost::uint_t<3*w*h>::least census = 0;

                int stride2 = -(int)h/2 * stride - (int)w/2;

                for(uint32_t i = 0; i < h; ++i) {

                    int stride3 = stride2;

                    for(uint32_t j = 0; j < w; ++j) {

                        census = census << 1;

                        if(inputPixel[0].R <= inputPixel[stride3].R)
                            census |= 1;
                        census = census << 1;

                        if(inputPixel[0].G <= inputPixel[stride3].G)
                            census |= 1;
                        census = census << 1;

                        if(inputPixel[0].B <= inputPixel[stride3].B)
                            census |= 1;    
                        stride3++;
                    }

                    stride2 += stride;
                }

                return census;
        }
        
        
        
 
        template<uint32_t w, uint32_t h, class Impl_Agg>
        struct pixel_loop;
        
        template<uint32_t w, uint32_t h>
        struct pixel_loop<w, h, impl::Cpp>
        {        
          public :
              
            template<class S>
            static inline  typename boost::uint_t<w*h>::least run(const S* inputPixel, long stride)
            {
                    return  Census<w, h, S>(inputPixel, stride);
            }
            
            template<class S>
            static inline  typename safe_uint_t<3*w*h>::type run(const cimage::TRGB<S>* inputPixel, long stride)
            {
                    return  Census<w, h, S>(inputPixel, stride);
            }
        };
        
        template<uint32_t w, uint32_t h>
        struct pixel_loop<w, h, impl::Auto> : public pixel_loop<w, h, impl::Cpp> {};

        
#ifdef __SSE3__
        template<>
        struct pixel_loop<5, 5, impl::SIMD>
        {
          public:

            DECLSPEC_FORCEINLINE static inline uint32_t run(const cimage::Mono8* inputPixel, long stride)
            {
                cimage::Mono8 c0 = inputPixel[0];
                uint8_t ref[] = {c0, c0, c0, c0, c0, c0, c0, c0};
                uint8_t remains[] = {inputPixel[2 - 2 * stride], inputPixel[2 - stride], inputPixel[2], inputPixel[2 + stride], inputPixel[2 + 2 * stride], 0, 0, 0};
                uint32_t res;

                __asm__ volatile (
                    "movd %0, %%xmm0\n\t"
                    "movd %1, %%xmm1\n\t"
                    "movd %2, %%xmm2\n\t"
                    "movd %3, %%xmm3\n\t"
                    "movq %4, %%xmm4\n\t"
                    "movd %5, %%xmm5\n\t"
                    "movddup %6, %%xmm6\n\t"
                    : 
                    :  "m"(*(inputPixel - 2 - 2*stride)), "m"(*(inputPixel - 2 - stride)), "m"(*(inputPixel - 2)), "m"(*(inputPixel - 2 + stride)), "m"(*(remains)), "m"(*(inputPixel - 2 + 2 * stride)), "m"(*ref)
                    :  "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4","%xmm5","%xmm6"
                );
                __asm__ volatile (
                    "punpckldq %%xmm1, %%xmm0\n\t"
                    "punpckldq %%xmm3, %%xmm2\n\t"
                    "punpckldq %%xmm5, %%xmm4\n\t"
                    "pshufd $228,%%xmm6, %%xmm1\n\t"
                    "punpcklqdq %%xmm2, %%xmm0\n\t"
                    "pmaxub %%xmm0, %%xmm6\n\t"
                    "pmaxub %%xmm4, %%xmm1\n\t"
                    "pcmpeqb %%xmm0, %%xmm6\n\t"
                    "pcmpeqb %%xmm4, %%xmm1\n\t"
                    "pmovmskb %%xmm6, %%eax\n\t"
                    "pmovmskb %%xmm1, %%ecx\n\t"
                    "sal $23, %%ecx\n\t"
                    "xor %%ecx, %%eax\n\t"
                    "mov %%eax, %0\n\t"
                    : "=m"(res)
                    : 
                    : "%ecx", "%eax", "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6"
                );

                
                return res;
            }

            DECLSPEC_FORCEINLINE static inline uint32_t run(const cimage::Mono8s* inputPixel, long stride)
            {
                cimage::Mono8s c0 = inputPixel[0];
                int8_t ref[] = { c0, c0, c0, c0, c0, c0, c0, c0 };
                int8_t remains[] = { inputPixel[2 - 2 * stride], inputPixel[2 - stride], inputPixel[2], inputPixel[2 + stride], inputPixel[2 + 2 * stride], 0, 0, 0 };
                uint32_t res;

                __asm__ volatile (

                    "movd %0, %%xmm0 \n\t"
                    "movd %1, %%xmm1 \n\t"
                    "movd %2, %%xmm2 \n\t"
                    "movd %3, %%xmm3 \n\t"
                    "movq %4, %%xmm4 \n\t"
                    "movd %5, %%xmm5 \n\t"
                    "movddup %6, %%xmm6 \n\t"
                    : 
                    : "m"(*(inputPixel - 2 - 2 * stride)), "m"(*(inputPixel - 2 - stride)), "m"(*(inputPixel - 2)), "m"(*(inputPixel - 2 + stride)), "m"(*(remains)), "m"(*(inputPixel - 2 + 2 * stride)), "m"(*ref)
                    :  "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4","%xmm5","%xmm6"
                );

                __asm__ volatile (
                    "punpckldq %%xmm1, %%xmm0\n\t"
                    "punpckldq %%xmm3, %%xmm2\n\t"
                    "punpckldq %%xmm5, %%xmm4\n\t"
                    "pshufd $228,%%xmm6, %%xmm1\n\t"
                    "punpcklqdq %%xmm2, %%xmm0\n\t"
                    "pcmpgtb %%xmm0, %%xmm6\n\t"
                    "pcmpgtb %%xmm4, %%xmm1\n\t"
                    "pmovmskb %%xmm6, %%eax\n\t"
                    "pmovmskb %%xmm1, %%ecx\n\t"
                    "sal $23, %%ecx\n\t"
                    "xor %%ecx, %%eax\n\t"
                    "mov %%eax, %0\n\t"
                    : "=m"(res)
                    : 
                    : "%ecx", "%eax", "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6"
                );

                return res;
            }
            
            DECLSPEC_FORCEINLINE static inline uint32_t run(const cimage::Mono16s* inputPixel, long stride)
            {
                cimage::Mono16s c0 = inputPixel[0];
                int16_t ref[] = { c0, c0, c0, c0 };
                DECLSPEC_ALIGN(16) int16_t remains[] = { inputPixel[2 - 2 * stride], inputPixel[2 - stride], inputPixel[2], inputPixel[2 + stride], inputPixel[2 + 2 * stride], 0, 0, 0 };
                uint32_t res;

                __asm__ volatile (

                    "movq %0, %%xmm0 \n\t"
                    "movq %1, %%xmm1 \n\t"
                    "movq %2, %%xmm2 \n\t"
                    "movq %3, %%xmm3 \n\t"
                    "movdqa %4, %%xmm4 \n\t"
                    "movq %5, %%xmm5 \n\t"
                    "movddup %6, %%xmm6 \n\t"
                    : 
                    : "m"(*(inputPixel - 2 - 2 * stride)), "m"(*(inputPixel - 2 - stride)), "m"(*(inputPixel - 2)), "m"(*(inputPixel - 2 + stride)), "m"(*(remains)), "m"(*(inputPixel - 2 + 2 * stride)), "m"(*ref)
                    :  "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4","%xmm5","%xmm6"
                );
                __asm__ volatile (
                    "punpcklqdq %%xmm1, %%xmm0\n\t"
                    "pshuflw $180, %%xmm2, %%xmm2\n\t"
                    "pslldq $10,%%xmm2\n\t"
                    "punpcklqdq %%xmm3, %%xmm5\n\t"
                    "por %%xmm4, %%xmm2\n\t"
                    "pshufd $228,%%xmm6, %%xmm1\n\t"
                    "pshufd $228,%%xmm6, %%xmm3\n\t"
                    "pcmpgtw %%xmm0, %%xmm6\n\t"
                    "pcmpgtw %%xmm5, %%xmm1\n\t"
                    "pcmpgtw %%xmm2, %%xmm3\n\t"
                    "packsswb %%xmm6, %%xmm1\n\t"
                    "packsswb %%xmm3, %%xmm3\n\t"
                    "pmovmskb %%xmm1, %%eax\n\t"
                    "pmovmskb %%xmm3, %%ecx\n\t"
                    "sal $24, %%ecx\n\t"
                    "or %%ecx, %%eax\n\t"
                    "mov %%eax, %0\n\t"
                    : "=m"(res)
                    : 
                    : "%ecx", "%eax", "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6"
                );
                
                return res;
            }
            
            DECLSPEC_FORCEINLINE static inline uint32_t run(const cimage::Mono16* inputPixel, long stride)
            {
                cimage::Mono16 c0 = inputPixel[0];
                uint16_t ref[] = { c0, c0, c0, c0 };
                DECLSPEC_ALIGN(16) uint16_t remains[] = { inputPixel[2 - 2 * stride], inputPixel[2 - stride], inputPixel[2], inputPixel[2 + stride], inputPixel[2 + 2 * stride], 0, 0, 0 };
                uint32_t res;

                __asm__ volatile (
                    "pcmpeqw %%xmm7, %%xmm7\n\t"
                    "psllw $15, %%xmm7\n\t"
                    "movq %0, %%xmm0\n\t"
                    "movq %1, %%xmm1\n\t"
                    "movq %2, %%xmm2\n\t"
                    "movq %3, %%xmm3\n\t"
                    "movdqa %4, %%xmm4\n\t"
                    "movq %5, %%xmm5\n\t"
                    "movddup %6, %%xmm6\n\t"
                    : 
                    : "m"(*(inputPixel - 2 - 2 * stride)), "m"(*(inputPixel - 2 - stride)), "m"(*(inputPixel - 2)), "m"(*(inputPixel - 2 + stride)), "m"(*(remains)), "m"(*(inputPixel - 2 + 2 * stride)), "m"(*ref)
                    :  "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4","%xmm5","%xmm6"
                );
                __asm__ volatile (
                    "punpcklqdq %%xmm1, %%xmm0\n\t"
                    "pshuflw $180, %%xmm2, %%xmm2\n\t"
                    "pslldq $10,%%xmm2\n\t"
                    "punpcklqdq %%xmm3, %%xmm5\n\t"
                    "por %%xmm4, %%xmm2\n\t"
                    "paddb %%xmm7, %%xmm6 \n\t"
                    "paddb %%xmm7, %%xmm0 \n\t"
                    "paddb %%xmm7, %%xmm5 \n\t"
                    "paddb %%xmm7, %%xmm2 \n\t"
                    "pshufd $228,%%xmm6, %%xmm1\n\t"
                    "pshufd $228,%%xmm6, %%xmm3\n\t"
                    "pcmpgtw %%xmm0, %%xmm6\n\t"
                    "pcmpgtw %%xmm5, %%xmm1\n\t"
                    "pcmpgtw %%xmm2, %%xmm3\n\t"
                    "packsswb %%xmm6, %%xmm1\n\t"
                    "packsswb %%xmm3, %%xmm3\n\t"
                    "pmovmskb %%xmm1, %%eax\n\t"
                    "pmovmskb %%xmm3, %%ecx\n\t"
                    "sal $24, %%ecx\n\t"
                    "or %%ecx, %%eax\n\t"
                    "mov %%eax, %0\n\t"
                    : "=m"(res)
                    : 
                    : "%ecx", "%eax", "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6"
                );
                
                return res;
            }
        
        };

        template<>
        struct pixel_loop<5, 5, impl::Auto> : public pixel_loop<5, 5, impl::SIMD> {};
        
        
        template<>
        struct pixel_loop<7, 7, impl::SIMD>
        {
          public:

            DECLSPEC_FORCEINLINE static inline uint64_t run(const cimage::Mono8* inputPixel, long stride)
            {
                cimage::Mono8 c0 = inputPixel[0];
                uint8_t ref[] = {c0, c0, c0, c0, c0, c0, c0, c0};                      
                 uint64_t res;
                
                __asm__ volatile (
                    "movq %0, %%xmm0\n\t"
                    "movq %1, %%xmm1\n\t"
                    "movq %2, %%xmm2\n\t"
                    "movq %3, %%xmm3\n\t"
                    "movq %4, %%xmm4\n\t"
                    "movq %5, %%xmm5\n\t"
                    "movq %6, %%xmm6\n\t"
                    "movddup %7, %%xmm7\n\t"
                    : 
                    :  "m"(*(inputPixel - 3 - 3*stride)), "m"(*(inputPixel - 3 - 2*stride)), "m"(*(inputPixel - 3 - stride)), "m"(*(inputPixel - 3)),
                       "m"(*(inputPixel - 3 + stride)),   "m"(*(inputPixel - 3 + 2*stride)), "m"(*(inputPixel - 3 + 3 * stride)), "m"(*ref)
                    :  "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4","%xmm5","%xmm6","%xmm7"
                );

                
                __asm__ volatile (
                    "punpcklbw %%xmm1, %%xmm0\n\t" 
                    "punpcklbw %%xmm3, %%xmm2\n\t"
                    "punpcklbw %%xmm5, %%xmm4\n\t"
                  
#ifdef __AVX__                     
                    "vpmaxub %%xmm2, %%xmm7, %%xmm8\n\t"
                    "vpmaxub %%xmm4, %%xmm7, %%xmm9\n\t"
                    "vpmaxub %%xmm6, %%xmm7, %%xmm10\n\t" 
                    "pmaxub %%xmm0, %%xmm7\n\t"
#else                   
                    "pshufd $228,%%xmm7, %%xmm8\n\t"
                    "pshufd $228,%%xmm7, %%xmm9\n\t"
                    "pshufd $228,%%xmm7, %%xmm10\n\t"
                    
                    "pmaxub %%xmm0, %%xmm7\n\t"
                    "pmaxub %%xmm2, %%xmm8\n\t"
                    "pmaxub %%xmm4, %%xmm9\n\t"
                    "pmaxub %%xmm6, %%xmm10\n\t"
#endif                    
                    "pcmpeqb %%xmm7, %%xmm0\n\t"
                    "pcmpeqb %%xmm8, %%xmm2\n\t"
                    "pcmpeqb %%xmm9, %%xmm4\n\t"
                    "pcmpeqb %%xmm10, %%xmm6\n\t"
                    
                    
                    "pmovmskb %%xmm0, %%eax\n\t"
                    "pmovmskb %%xmm2, %%ebx\n\t"
                    "pmovmskb %%xmm4, %%ecx\n\t"
                    "pmovmskb %%xmm6, %%edx\n\t"
                    "sal $16, %%ebx\n\t"
                    "sal $16, %%edx\n\t"
                    "or %%ebx, %%eax\n\t"
                    "or %%edx, %%ecx\n\t"
                    
                    "and $1073692671, %%eax\n\t"   
                    "and $48339455, %%ecx\n\t"   

                    "sal $32, %%rcx\n\t"
                    "or %%rcx, %%rax\n\t"
                    "mov %%rax, %0\n\t"
                    :  "=m"(res)
                    : 
                    : "%rax", "%rbx", "%rcx", "%rdx","%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6"
                );

                return res;

            }

            DECLSPEC_FORCEINLINE static inline uint64_t run(const cimage::Mono8s* inputPixel, long stride)
            {
                
                cimage::Mono8s c0 = inputPixel[0];
                int8_t ref[] = {c0, c0, c0, c0, c0, c0, c0, c0};                      
                uint64_t res;
                
                __asm__ volatile (
                    "movq %0, %%xmm0\n\t"
                    "movq %1, %%xmm1\n\t"
                    "movq %2, %%xmm2\n\t"
                    "movq %3, %%xmm3\n\t"
                    "movq %4, %%xmm4\n\t"
                    "movq %5, %%xmm5\n\t"
                    "movq %6, %%xmm6\n\t"
                    "movddup %7, %%xmm7\n\t"
                    : 
                    :  "m"(*(inputPixel - 3 - 3*stride)), "m"(*(inputPixel - 3 - 2*stride)), "m"(*(inputPixel - 3 - stride)), "m"(*(inputPixel - 3)),
                       "m"(*(inputPixel - 3 + stride)),   "m"(*(inputPixel - 3 + 2*stride)), "m"(*(inputPixel - 3 + 3 * stride)), "m"(*ref)
                    :  "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4","%xmm5","%xmm6","%xmm7"
                );

                
                __asm__ volatile (
                    "punpcklbw %%xmm1, %%xmm0\n\t" 
                    "punpcklbw %%xmm3, %%xmm2\n\t"
                    "punpcklbw %%xmm5, %%xmm4\n\t"
                  
#ifdef __AVX__                     
                    "vpcmpgtb %%xmm2, %%xmm7, %%xmm8\n\t"
                    "vpcmpgtb %%xmm4, %%xmm7, %%xmm9\n\t"
                    "vpcmpgtb %%xmm6, %%xmm7, %%xmm10\n\t"
                    "pcmpgtb %%xmm0, %%xmm7\n\t"
#else                   
                    "pshufd $228,%%xmm7, %%xmm8\n\t"
                    "pshufd $228,%%xmm7, %%xmm9\n\t"
                    "pshufd $228,%%xmm7, %%xmm10\n\t"
                    
                    "pcmpgtb %%xmm0, %%xmm7\n\t"
                    "pcmpgtb %%xmm2, %%xmm8\n\t"
                    "pcmpgtb %%xmm4, %%xmm9\n\t"
                    "pcmpgtb %%xmm6, %%xmm10\n\t"
#endif                    
                  
                    
                    "pmovmskb %%xmm7, %%eax\n\t"
                    "pmovmskb %%xmm8, %%ebx\n\t"
                    "pmovmskb %%xmm9, %%ecx\n\t"
                    "pmovmskb %%xmm10, %%edx\n\t"
                    "sal $16, %%ebx\n\t"
                    "sal $16, %%edx\n\t"
                    "or %%ebx, %%eax\n\t"
                    "or %%edx, %%ecx\n\t"
                    
                    "and $1073692671, %%eax\n\t"   
                    "and $48339455, %%ecx\n\t"   

                    "sal $32, %%rcx\n\t"
                    "or %%rcx, %%rax\n\t"
                    "mov %%rax, %0\n\t"
                    :  "=m"(res)
                    : 
                    : "%rax", "%rbx", "%rcx", "%rdx","%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6"
                );
                

                return res;
            }
            
            DECLSPEC_FORCEINLINE static inline uint64_t run(const cimage::Mono16s* inputPixel, long stride)
            {
                return  Census<7, 7, cimage::Mono16s>(inputPixel, stride);
            }
            
            DECLSPEC_FORCEINLINE static inline uint64_t run(const cimage::Mono16* inputPixel, long stride)
            {
                return  Census<7, 7, cimage::Mono16>(inputPixel, stride);
            }
        
        };

        template<>
        struct pixel_loop<7, 7, impl::Auto> : public pixel_loop<7, 7, impl::SIMD> {};
        
        
        
        
        
        
        template<>
        struct pixel_loop<4, 4, impl::SIMD>
        {
          public:
              
            DECLSPEC_FORCEINLINE static inline uint16_t run(const cimage::Mono8* inputPixel, long stride)
            {
                cimage::Mono8 c0 = inputPixel[0];
                uint8_t ref[] = { c0, c0, c0, c0, c0, c0, c0, c0 };
                uint16_t res;
        
                __asm__ volatile (
                    "movd    %1, %%xmm0 \n\t"
                    "movd    %2, %%xmm1 \n\t"
                    "movd    %3, %%xmm2 \n\t"
                    "movd    %4, %%xmm3 \n\t"
                    "movddup %5, %%xmm4 \n\t"
                    "punpckldq  %%xmm1, %%xmm0 \n\t"
                    "punpckldq  %%xmm3, %%xmm2 \n\t"
                    "punpcklqdq %%xmm2, %%xmm0 \n\t"
                    "pmaxub %%xmm0, %%xmm4 \n\t"
                    "pcmpeqb %%xmm0, %%xmm4\n\t"
                    "pmovmskb %%xmm4, %%ecx \n\t"
                    "mov %%cx, %0 \n\t"
                    : "=m"(res)
                    : "m"(*(inputPixel - 2 - 2 * stride)), "m"(*(inputPixel - 2 - stride)), "m"(*(inputPixel - 2)), "m"(*(inputPixel - 2 + stride)), "m"(*ref)
                    : "%rcx", "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4"
                );  
                           
                
                return res;
            }

            DECLSPEC_FORCEINLINE static inline uint16_t run(const cimage::Mono8s* inputPixel, long stride)
            {
                cimage::Mono8s c0 = inputPixel[0];
                int8_t ref[] = { c0, c0, c0, c0, c0, c0, c0, c0 };
                uint16_t res;

                
                __asm__ volatile (
                    "movd    %1, %%xmm0 \n\t"
                    "movd    %2, %%xmm1 \n\t"
                    "movd    %3, %%xmm2 \n\t"
                    "movd    %4, %%xmm3 \n\t"
                    "movddup %5, %%xmm4 \n\t"
                    "punpckldq  %%xmm1, %%xmm0 \n\t"
                    "punpckldq  %%xmm3, %%xmm2 \n\t"
                    "punpcklqdq %%xmm2, %%xmm0 \n\t"
                    "pcmpgtb %%xmm0, %%xmm4 \n\t"
                    "pmovmskb %%xmm4, %%ecx \n\t"
                    "mov %%cx, %0 \n\t"
                    : "=m"(res)
                    : "m"(*(inputPixel - 2 - 2 * stride)), "m"(*(inputPixel - 2 - stride)), "m"(*(inputPixel - 2)), "m"(*(inputPixel - 2 + stride)), "m"(*ref)
                    : "%rcx", "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4"
                );
                
                return res;
            }
            
            
           DECLSPEC_FORCEINLINE static inline uint16_t run(const cimage::Mono16* inputPixel, long stride)
            {
                cimage::Mono16 c0 = inputPixel[0];
                uint16_t ref[] = { c0, c0, c0, c0 };
                uint16_t res;

                __asm__ volatile (
                    "pcmpeqw %%xmm6, %%xmm6 \n\t"
                    "psllw $15, %%xmm6 \n\t"
                    "movq    %1, %%xmm0 \n\t"
                    "movq    %2, %%xmm1 \n\t"
                    "movq    %3, %%xmm2 \n\t"
                    "movq    %4, %%xmm3 \n\t"
                    "movddup %5, %%xmm4 \n\t"                   
                    "punpcklqdq %%xmm1, %%xmm0 \n\t"
                    "punpcklqdq %%xmm3, %%xmm2 \n\t"
                    "paddb %%xmm6, %%xmm4 \n\t"
                    "paddb %%xmm6, %%xmm0 \n\t"
                    "paddb %%xmm6, %%xmm2 \n\t"
                    "pshufd $228, %%xmm4, %%xmm5 \n\t"
                    "pcmpgtw %%xmm0, %%xmm4 \n\t"
                    "pcmpgtw %%xmm2, %%xmm5 \n\t"
                    "packsswb %%xmm5, %%xmm4 \n\t"
                    "pmovmskb %%xmm4, %%ecx \n\t"
                    "mov %%cx, %0\n\t"
                    : "=m"(res)
                    : "m"(*(inputPixel - 2 - 2 * stride)), "m"(*(inputPixel - 2 - stride)), "m"(*(inputPixel - 2)), "m"(*(inputPixel - 2 + stride)), "m"(*ref)
                    : "%rcx", "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5"
            );
            
                return res;
            }

            DECLSPEC_FORCEINLINE static inline uint16_t run(const cimage::Mono16s* inputPixel, long stride)
            {
                cimage::Mono16s c0 = inputPixel[0];
                int16_t ref[] = { c0, c0, c0, c0 };
                uint16_t res;

                
                __asm__ volatile (
                    "movq    %1, %%xmm0 \n\t"
                    "movq    %2, %%xmm1 \n\t"
                    "movq    %3, %%xmm2 \n\t"
                    "movq    %4, %%xmm3 \n\t"
                    "movddup %5, %%xmm4 \n\t"
                    "punpcklqdq %%xmm1, %%xmm0 \n\t"
                    "punpcklqdq %%xmm3, %%xmm2 \n\t"
                    "pshufd $228, %%xmm4, %%xmm5 \n\t"
                    "pcmpgtw %%xmm0, %%xmm4 \n\t"
                    "pcmpgtw %%xmm2, %%xmm5 \n\t"
                    "packsswb %%xmm5, %%xmm4 \n\t"
                    "pmovmskb %%xmm4, %%ecx \n\t"
                    "mov %%cx, %0 \n\t"
                    : "=m"(res)
                    : "m"(*(inputPixel - 2 - 2 * stride)), "m"(*(inputPixel - 2 - stride)), "m"(*(inputPixel - 2)), "m"(*(inputPixel - 2 + stride)), "m"(*ref)
                    : "%rcx", "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4"
                );
                
                return res;
            }
            
            DECLSPEC_FORCEINLINE static inline uint64_t run(const cimage::TRGB<uint8_t>* inputPixel, long stride)
            {
                cimage::TRGB<uint8_t> c0 = inputPixel[0];
                DECLSPEC_ALIGN(16)  cimage::TRGB<uint8_t> ref[] = { c0, c0, c0, c0, c0, c0 };
                uint64_t res;

                
                __asm__ volatile (
                    "movdqu  %1, %%xmm0 \n\t"
                    "movdqu  %2, %%xmm1 \n\t"
                    "movdqu  %3, %%xmm2 \n\t"
                    "movdqu  %4, %%xmm3 \n\t"
                    "movdqa  %5, %%xmm4 \n\t"
                    "pshufd $228, %%xmm4, %%xmm5\n\t"
                    "pshufd $228, %%xmm4, %%xmm6\n\t"
                    "pshufd $228, %%xmm4, %%xmm7\n\t"
                    "pmaxub %%xmm0, %%xmm4 \n\t"
                    "pmaxub %%xmm1, %%xmm5 \n\t"
                    "pmaxub %%xmm2, %%xmm6 \n\t"
                    "pmaxub %%xmm3, %%xmm7 \n\t"
                    "pcmpeqb %%xmm0, %%xmm4\n\t"
                    "pcmpeqb %%xmm1, %%xmm5\n\t"
                    "pcmpeqb %%xmm2, %%xmm6\n\t"
                    "pcmpeqb %%xmm3, %%xmm7\n\t"
                    "pmovmskb %%xmm4, %%eax \n\t"
                    "pmovmskb %%xmm5, %%ebx \n\t"
                    "pmovmskb %%xmm6, %%ecx \n\t"
                    "pmovmskb %%xmm7, %%edx \n\t"
                    "shl $52, %%rax\n\t"
                    "shl $52, %%rcx\n\t"
                    "shrd $12, %%rbx, %%rax\n\t"
                    "shld $12, %%rcx, %%rdx\n\t"
                    "shrd $24, %%rdx ,%%rax\n\t"                 
                    "mov %%rax, %0 \n\t"
                    : "=m"(res)
                    : "m"(*(inputPixel - 2 - 2 * stride)), "m"(*(inputPixel - 2 - stride)), "m"(*(inputPixel - 2)), "m"(*(inputPixel - 2 + stride)), "m"(*ref)
                    : "%rax", "%rbx", "%rcx", "%rdx", "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7"
                );
                
                return res;
            
            }
            
            
            DECLSPEC_FORCEINLINE static inline uint64_t run(const cimage::TRGB<int8_t>* inputPixel, long stride)
            {
                cimage::TRGB<int8_t> c0 = inputPixel[0];
                DECLSPEC_ALIGN(16)  cimage::TRGB<int8_t> ref[] = { c0, c0, c0, c0, c0, c0 };
                uint64_t res;

              
                __asm__ volatile (
                    "movdqu  %1, %%xmm0 \n\t"
                    "movdqu  %2, %%xmm1 \n\t"
                    "movdqu  %3, %%xmm2 \n\t"
                    "movdqu  %4, %%xmm3 \n\t"
                    "movdqa  %5, %%xmm4 \n\t"
                    "pshufd $228, %%xmm4, %%xmm5\n\t"
                    "pshufd $228, %%xmm4, %%xmm6\n\t"
                    "pshufd $228, %%xmm4, %%xmm7\n\t"
                    "pcmpgtb %%xmm0, %%xmm4 \n\t"
                    "pcmpgtb %%xmm1, %%xmm5 \n\t"
                    "pcmpgtb %%xmm2, %%xmm6 \n\t"
                    "pcmpgtb %%xmm3, %%xmm7 \n\t"
                    "pmovmskb %%xmm4, %%eax \n\t"
                    "pmovmskb %%xmm5, %%ebx \n\t"
                    "pmovmskb %%xmm6, %%ecx \n\t"
                    "pmovmskb %%xmm7, %%edx \n\t"
                    "shl $52, %%rax\n\t"
                    "shl $52, %%rcx\n\t"
                    "shrd $12, %%rbx, %%rax\n\t"
                    "shld $12, %%rcx, %%rdx\n\t"
                    "shrd $24, %%rdx ,%%rax\n\t"                 
                    "mov %%rax, %0 \n\t"
                    : "=m"(res)
                    : "m"(*(inputPixel - 2 - 2 * stride)), "m"(*(inputPixel - 2 - stride)), "m"(*(inputPixel - 2)), "m"(*(inputPixel - 2 + stride)), "m"(*ref)
                    : "%rax", "%rbx", "%rcx", "%rdx", "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7"
                );
   
                
                return res;
            }
            
            
        };

        template<>
        struct pixel_loop<4, 4, impl::Auto> : public pixel_loop<4, 4, impl::SIMD> {};
#endif

    }
    
    namespace hamming
    {
        
        template<class T>
        inline T PopCount(uint16_t b)
        {
            b = (b & 0x5555) + (b >> 1 & 0x5555);
            b = (b & 0x3333) + (b >> 2 & 0x3333);
            b = (b + (b >> 4)) & 0x0F0F;
            b = b + (b >> 8);
            return (T)b;
        }
        
        
        template<class T>
        inline T PopCount(uint32_t b)
        {
            b = (b & 0x55555555) + (b >> 1 & 0x55555555);
            b = (b & 0x33333333) + (b >> 2 & 0x33333333);
            b = (b + (b >> 4)) & 0x0F0F0F0F;
            b = b + (b >> 8);
            b = (b + (b >> 16)) & 0x0000003F;

            return (T)b;
        }
        
        template<class T>
        inline T PopCount(uint64_t b)
        {
            b =  b       - ((b >> 1)  & 0x5555555555555555LLU);
            b = (b & 0x3333333333333333LLU) + ((b >> 2)  & 0x3333333333333333LLU);
            b = (b       +  (b >> 4)) & 0x0f0f0f0f0f0f0f0fLLU; 
            b = (b * 0x0101010101010101LLU) >> 56;
            return (T) b;
        }

        template<class ResultType_Agg, class Impl_Agg>
        struct pixel_loop;

        template<class ResultType_Agg>
        struct pixel_loop<ResultType_Agg, impl::Cpp>
        {
            template<class T>
            static inline void run(ResultType_Agg * pCorr, int d_min, int d_max, T * pLeft,  T r)
            {
                for(int d = d_min; d <= d_max; ++d)
                    pCorr[d] = PopCount<ResultType_Agg>((T)(pLeft[d] ^ r));
            }
        };

        
                    
        
#if (defined __SSSE3__) && (defined __x86_64__)
        template<>
        struct pixel_loop<uint8_t, impl::SIMD>
        {
            DECLSPEC_FORCEINLINE static inline void run(uint8_t * pCorr, int d_min, int d_max, uint16_t * pLeft, uint16_t r)
            {


                static uint32_t mask = 0x0F0F0F0F;
                DECLSPEC_ALIGN(16) static unsigned LUT[] = {0x02010100, 0x03020201, 0x03020201, 0x04030302};
                DECLSPEC_ALIGN(16) static uint8_t m7[] = { 1, 255, 3, 255, 5, 255, 7, 255, 9, 255, 11, 255, 13, 255, 15, 255};
                DECLSPEC_ALIGN(16) static uint8_t m8[] = { 0, 2, 4, 6, 8, 10, 12, 14};
                uint16_t rv[] = { r, r };
                __asm__ volatile 
                (
                    "movd %0, %%xmm1\n\t"
                    "movdqa %1, %%xmm3\n\t"
                    "movdqa %2, %%xmm6\n\t"
                    "movq %3, %%xmm7\n\t"
                    "movd %4, %%xmm8\n\t"                  
                    "pshufd  $0, %%xmm1, %%xmm1 \n\t"
                    "pshufd  $0, %%xmm8, %%xmm8 \n\t"
                  : : "m"(mask), "m"(*LUT),"m"(*m7), "m"(*m8), "m" (*rv)   : "%xmm1", "%xmm3", "%xmm6",  "%xmm7", "%xmm8"               
                );
                

                
                int d;
                for( d = d_min;  d <=  d_max ; d += 16)
                {
                   __asm__ volatile (
                        "movdqu  %2, %%xmm0\n\t"
                        "movdqu  %3, %%xmm9\n\t"
                        "pxor  %%xmm8, %%xmm0\n\t"
                        "pxor  %%xmm8, %%xmm9\n\t"
#ifdef __AVX__ 
                        "vpand %%xmm1, %%xmm0, %%xmm2\n\t"
                        "vpand %%xmm1, %%xmm9, %%xmm10\n\t"
                        "psrlw $4, %%xmm0\n\t"
                        "psrlw $4, %%xmm9\n\t"
                        "pand %%xmm1, %%xmm0\n\t"
                        "pand %%xmm1, %%xmm9\n\t"
                        "vpshufb %%xmm0,%%xmm3, %%xmm4\n\t"
                        "vpshufb %%xmm9,%%xmm3, %%xmm11\n\t"
                        "vpshufb %%xmm2,%%xmm3, %%xmm5\n\t"
                        "vpshufb %%xmm10,%%xmm3, %%xmm12\n\t"
#else
                        "pshufd $228,%%xmm0, %%xmm2\n\t"
                        "pshufd $228,%%xmm9, %%xmm10\n\t"
                        "pand %%xmm1, %%xmm0\n\t"
                        "pand %%xmm1, %%xmm9\n\t"
                        "psrlw $4, %%xmm2\n\t"
                        "psrlw $4, %%xmm10\n\t"
                        "pand %%xmm1, %%xmm2\n\t"
                        "pand %%xmm1, %%xmm10\n\t"
                        "pshufd $228,%%xmm3, %%xmm4\n\t"
                        "pshufd $228,%%xmm3, %%xmm11\n\t"
                        "pshufd $228,%%xmm3, %%xmm5\n\t"
                        "pshufd $228,%%xmm3, %%xmm12\n\t"
                        "pshufb %%xmm0, %%xmm4\n\t"
                        "pshufb %%xmm9, %%xmm11\n\t"
                        "pshufb %%xmm2, %%xmm5\n\t"
                        "pshufb %%xmm10, %%xmm12\n\t"
#endif                        
                        "paddb %%xmm5, %%xmm4\n\t"
                        "paddb %%xmm11, %%xmm12\n\t"
#ifdef __AVX__  
                        "vpshufb %%xmm6, %%xmm4, %%xmm5\n\t" 
                        "vpshufb %%xmm6, %%xmm12, %%xmm10\n\t"
#else                        
                        "pshufd $228,%%xmm4, %%xmm5\n\t"
                        "pshufd $228,%%xmm12, %%xmm10\n\t"
                        "pshufb %%xmm6, %%xmm4\n\t" 
                        "pshufb %%xmm6, %%xmm12\n\t"
#endif                      
                        "paddb %%xmm5, %%xmm4\n\t"
                        "paddb %%xmm10, %%xmm12\n\t"                       
                        "pshufb %%xmm7, %%xmm4\n\t" 
                        "pshufb %%xmm7, %%xmm12\n\t"  
                        "movq %%xmm4, %0 \n\t"
                        "movq %%xmm12, %1 \n\t"
                        : "=m"(*(pCorr + d)), "=m"(*(pCorr + d + 8))
                        : "m"(*(pLeft + d)), "m"(*(pLeft + d + 8))
                        : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7", "%xmm9", "%xmm10",  "%xmm11",  "%xmm12"
                    );
                }
                
                for(int k = d_max+1; k< d; k++)
                   pCorr[k]=255;
            }



            DECLSPEC_FORCEINLINE static inline void run(uint8_t * pCorr, int d_min, int d_max, uint32_t * pLeft, uint32_t r)
            {

                static uint32_t mask = 0x0F0F0F0F;
                DECLSPEC_ALIGN(16) static unsigned LUT[] = {0x02010100, 0x03020201, 0x03020201, 0x04030302};
                DECLSPEC_ALIGN(16) static uint8_t m7[] = { 1, 255, 3, 255, 5, 255, 7, 255, 9, 255, 11, 255, 13, 255, 15, 255};
                DECLSPEC_ALIGN(16) static uint8_t m8[] = { 0, 2, 4, 6, 8, 10, 12, 14};
                __asm__ volatile 
                (
                    "movd %0, %%xmm1\n\t"
                    "movdqa %1, %%xmm3\n\t"
                    "movdqa %2, %%xmm6\n\t"
                    "movq %3, %%xmm7\n\t"
                    "movd %4, %%xmm8\n\t"                  
                    "pshufd  $0, %%xmm1, %%xmm1 \n\t"
                    "pshufd  $0, %%xmm8, %%xmm8 \n\t"
                  : : "m"(mask), "m"(*LUT),"m"(*m7), "m"(*m8), "m" (r)   : "%xmm1", "%xmm3", "%xmm6",  "%xmm7", "%xmm8"               
                );
                
                   
                int d;
                for(d = d_min;  d <=  d_max ; d += 8)
                {
                   __asm__ volatile (
                        "movdqu  %1, %%xmm0\n\t"
                        "movdqu  %2, %%xmm9\n\t"
                        "pxor  %%xmm8, %%xmm0\n\t"
                        "pxor  %%xmm8, %%xmm9\n\t"
#ifdef __AVX__ 
                        "vpand %%xmm1, %%xmm0, %%xmm2\n\t"
                        "vpand %%xmm1, %%xmm9, %%xmm10\n\t"
                        "psrlw $4, %%xmm0\n\t"
                        "psrlw $4, %%xmm9\n\t"
                        "pand %%xmm1, %%xmm0\n\t"
                        "pand %%xmm1, %%xmm9\n\t"
                        "vpshufb %%xmm0,%%xmm3, %%xmm4\n\t"
                        "vpshufb %%xmm9,%%xmm3, %%xmm11\n\t"
                        "vpshufb %%xmm2,%%xmm3, %%xmm5\n\t"
                        "vpshufb %%xmm10,%%xmm3, %%xmm12\n\t"
#else                        
                        "pshufd $228,%%xmm0, %%xmm2\n\t"
                        "pshufd $228,%%xmm9, %%xmm10\n\t"
                        "pand %%xmm1, %%xmm0\n\t"
                        "pand %%xmm1, %%xmm9\n\t"                      
                        "psrlw $4, %%xmm2\n\t"
                        "psrlw $4, %%xmm10\n\t"
                        "pand %%xmm1, %%xmm2\n\t"
                        "pand %%xmm1, %%xmm10\n\t"
                        "pshufd $228,%%xmm3, %%xmm4\n\t"
                        "pshufd $228,%%xmm3, %%xmm11\n\t"
                        "pshufd $228,%%xmm3, %%xmm5\n\t"
                        "pshufd $228,%%xmm3, %%xmm12\n\t"
                        "pshufb %%xmm0, %%xmm4\n\t"
                        "pshufb %%xmm9, %%xmm11\n\t"
                        "pshufb %%xmm2, %%xmm5\n\t"
                        "pshufb %%xmm10, %%xmm12\n\t"
#endif                       
                        "paddb %%xmm5, %%xmm4\n\t"
                        "paddb %%xmm11, %%xmm12\n\t"
                        "phaddw %%xmm12, %%xmm4\n\t"
#ifdef __AVX__ 
                        "vpshufb %%xmm6, %%xmm4,%%xmm5\n\t"
#else
                        "pshufd $228,%%xmm4, %%xmm5\n\t"
                        "pshufb %%xmm6, %%xmm4\n\t"
#endif                        
                        "paddb %%xmm5, %%xmm4\n\t"
                        "pshufb %%xmm7, %%xmm4\n\t"      
                        "movq %%xmm4, %0 \n\t"
                        : "=m"(*(pCorr + d))
                        : "m"(*(pLeft + d)), "m"(*(pLeft + d + 4))
                        : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7", "%xmm9", "%xmm10",  "%xmm11",  "%xmm12"
                    );
                }
                
                for(int k = d_max+1; k< d; k++)
                   pCorr[k]=255;
            }

            
            DECLSPEC_FORCEINLINE static inline void run(uint8_t * pCorr, int d_min, int d_max, uint64_t * pLeft, uint64_t r)
            {

                DECLSPEC_ALIGN(16) static unsigned LUT[] = {0x02010100, 0x03020201, 0x03020201, 0x04030302};            
                DECLSPEC_ALIGN(16) static uint8_t m8[] = { 0, 4, 8, 12, 0x0F, 0x0F, 0x0F, 0x0F};
                __asm__ volatile 
                (
                    "movdqa %0, %%xmm3\n\t"
                    "movdqa %1, %%xmm7\n\t" 
                    "movq %2, %%xmm8\n\t"       
                    "pshufd  $85, %%xmm7, %%xmm1 \n\t"
                    "pshufd  $68, %%xmm8, %%xmm8 \n\t"
                  : : "m"(*LUT), "m"(*m8), "m" (r)   : "%xmm1", "%xmm3", "%xmm6",  "%xmm7", "%xmm8"               
                ); 
                
                int d;
                for(d = d_min;  d <=  d_max ; d += 4)
                {
                   __asm__ volatile (
                        "movdqu  %1, %%xmm0\n\t"
                        "movdqu  %2, %%xmm9\n\t"
                        "pxor  %%xmm8, %%xmm0\n\t"
                        "pxor  %%xmm8, %%xmm9\n\t"
#ifdef __AVX__
                        "vpand %%xmm1, %%xmm0, %%xmm2\n\t"
                        "vpand %%xmm1, %%xmm9, %%xmm10\n\t"
                        "psrlw $4, %%xmm0\n\t"
                        "psrlw $4, %%xmm9\n\t"
                        "pand %%xmm1, %%xmm0\n\t"
                        "pand %%xmm1, %%xmm9\n\t"
                        "vpshufb %%xmm0,%%xmm3, %%xmm4\n\t"
                        "vpshufb %%xmm9,%%xmm3, %%xmm11\n\t"
                        "vpshufb %%xmm2,%%xmm3, %%xmm5\n\t"
                        "vpshufb %%xmm10,%%xmm3, %%xmm12\n\t"
#else                        
                        "pshufd $228,%%xmm0, %%xmm2\n\t"
                        "pshufd $228,%%xmm9, %%xmm10\n\t"
                        "pand %%xmm1, %%xmm0\n\t"
                        "pand %%xmm1, %%xmm9\n\t"
                        "psrlw $4, %%xmm2\n\t"
                        "psrlw $4, %%xmm10\n\t"
                        "pand %%xmm1, %%xmm2\n\t"
                        "pand %%xmm1, %%xmm10\n\t"
                        "pshufd $228,%%xmm3, %%xmm4\n\t"
                        "pshufd $228,%%xmm3, %%xmm11\n\t"
                        "pshufd $228,%%xmm3, %%xmm5\n\t"
                        "pshufd $228,%%xmm3, %%xmm12\n\t"
                        "pshufb %%xmm0, %%xmm4\n\t"
                        "pshufb %%xmm9, %%xmm11\n\t"
                        "pshufb %%xmm2, %%xmm5\n\t"
                        "pshufb %%xmm10, %%xmm12\n\t"
#endif                        
                        "paddb %%xmm5, %%xmm4\n\t"
                        "paddb %%xmm11, %%xmm12\n\t"
                        "pxor  %%xmm0, %%xmm0\n\t"
                        "psadbw  %%xmm0, %%xmm4\n\t"
                        "psadbw  %%xmm0, %%xmm12\n\t"
                        "packssdw %%xmm12, %%xmm4\n\t"
                        "pshufb %%xmm7, %%xmm4\n\t"      
                        "movd %%xmm4, %0 \n\t"
                        : "=m"(*(pCorr + d))
                        : "m"(*(pLeft + d)), "m"(*(pLeft + d + 2))
                        : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7", "%xmm9", "%xmm10",  "%xmm11",  "%xmm12"
                    );
                }
                
                for(int k = d_max+1; k< d; k++)
                   pCorr[k]=255;
            }            
            
        };

        template<>
        struct pixel_loop<uint8_t, impl::Auto> : public pixel_loop<uint8_t, impl::SIMD> {};
#endif
        template<class ResultType_Agg>
        struct pixel_loop<ResultType_Agg, impl::Auto> : public pixel_loop<ResultType_Agg, impl::Cpp> {};        

    }
}

#endif
