#ifndef _SEMIINCREMENTALLOOPS_H
#define _SEMIINCREMENTALLOOPS_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2007                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file Loops.h
 * \author Mirko Felisa (felisa@ce.unipr.it), Paolo Zani (zani@ce.unipr.it)
 * \date 2007-04-08
 */

#include <Data/CImage/Pixels/Mono8.h>
#include <Data/CImage/Pixels/Mono8s.h>
#include <Data/CImage/Pixels/Mono16.h>
#include <Data/CImage/Pixels/Mono16s.h>
#include <Data/CImage/Pixels/RGB8.h>
#include <Libs/Compatibility/DeclSpecs.h>

#include <stdint.h>

namespace disparity
{
    namespace impl
    {
        class Cpp;
        class SIMD;
        class Auto;
    }

    namespace cost
    {
        template<typename ResultType_Cost> class None;
        template<typename ResultType_Cost> class AbsDiff;
    }

    namespace sincr
    {
        template<int32_t K, typename T, typename ResultType_Agg, typename Impl, typename Cost>
        struct pixel0_loop;

        template<int32_t K, typename T, typename ResultType_Agg, typename Impl, typename Cost>
        struct pixel_loop;

        template<int32_t K, typename T, typename ResultType_Agg, typename Cost>
        struct pixel0_loop<K, T, ResultType_Agg, impl::Cpp, Cost>
        {
            static inline void run(const T* pLeft, const T* pRight, ResultType_Agg* cur_prev_row_corr, ResultType_Agg* cur_corr_row_sum, int d_min, int d_max)
            {
                for(int d = d_min; d <= d_max; ++d) {

                    ResultType_Agg corr_delta = 0;

                    for(int w = 0; w < K; ++w)
                        corr_delta += Cost::eval(pLeft[d + w], pRight[w]);

                    cur_prev_row_corr[d] = corr_delta;
                    cur_corr_row_sum[d] += corr_delta;
                }
            }
        };

        template<int32_t K, typename T, typename ResultType_Agg, typename Cost>
        struct pixel_loop<K, T, ResultType_Agg, impl::Cpp, Cost>
        {
            static inline void run(const T* pLeft, const T* pRight, ResultType_Agg* cur_prev_row_corr, ResultType_Agg* cur_corr_row_sum, int d_min, int d_max)
            {
                for(int d = d_min;  d <= d_max; ++d) {

                    ResultType_Agg corr_delta = 0;

                    for(int w = 0; w < K; ++w)
                        corr_delta += Cost::eval(pLeft[d + w], pRight[w]);

                    cur_corr_row_sum[d] += corr_delta - cur_prev_row_corr[d];
                    cur_prev_row_corr[d] = corr_delta;
                }
            }
        };

        template<int32_t K, typename T, typename ResultType_Agg, typename Cost>
        struct pixel0_loop<K, T, ResultType_Agg, impl::Auto, Cost> : public pixel0_loop<K, T, ResultType_Agg, impl::Cpp, Cost> {};

        template<int32_t K, typename T, typename ResultType_Agg, typename Cost>
        struct pixel_loop<K, T, ResultType_Agg, impl::Auto, Cost> : public pixel_loop<K, T, ResultType_Agg, impl::Cpp, Cost> {};

#ifdef __SSE2__

#define cpsubw(X,S,D)  psubw##X(S,D)
#define psubw1(S,D)    "psubw "#S","#D"\n\t"
#define psubw0(S,D)  

#define cpsllq(X,S,D)  psllq##X(S,D)
#define psllq1(S,D)    "psllq $"#S","#D"\n\t"
#define psllq0(S,D) 

#define cmovq(X,S,D)  cmovq##X(S,D)
#define cmovq1(S,D)   "movq "#S","#D"\n\t"
#define cmovq0(S,D)

#define cmovd(X,S,D)  cmovd##X(S,D)
#define cmovd1(S,D)   "movd "#S","#D"\n\t"
#define cmovd0(S,D)

#define cmovdqa(X,S,D)  cmovdqa##X(S,D)
#define cmovdqa1(S,D)   "movdqa "#S","#D"\n\t"
#define cmovdqa0(S,D)


#define X86_PRELOAD_3 \
    __asm__ __volatile__ ("movd %0, %%xmm0"::"m" (*pRight) : "%xmm0"); \
    __asm__ __volatile__ ("pshufd  $68, %%xmm0, %%xmm0\n\t"::: "%xmm0"); \
    __asm__ __volatile__ ("psllq $40, %%xmm0\n\t"::: "%xmm0");        
       
#define X86_PRELOAD_4 \
    __asm__ __volatile__ ("movd %0, %%xmm0"::"m" (*pRight) : "%xmm0"); \
    __asm__ __volatile__ ("pshufd  $17, %%xmm0, %%xmm0\n\t"::: "%xmm0");

#define X86_PRELOAD_5_8(X,N) \
    __asm__ __volatile__ ( \
        "movq %0, %%xmm0\n\t"\
        "pshufd  $68, %%xmm0, %%xmm0\n\t" \
        cpsllq(X,N, %%xmm0\n\t) \
    ::"m" (*pRight) : "%xmm0");

#define X86_PRELOAD_9_15(N) \
    __asm__ __volatile__ ("movdqu %0, %%xmm0"::"m" (*pRight) : "%xmm0"); \
    __asm__ __volatile__ ("pslldq $"#N", %%xmm0\n\t":: : "%xmm0");

#define X86_PRELOAD_16 \
    __asm__ __volatile__ ("movdqu %0, %%xmm0\n\t"::"m" (*pRight) : "%xmm0");
    
#define X86_LOAD8 \
        "movdqu %2, %%xmm1\n\t"  \
        "movdqa  %1, %%xmm3 \n\t"

#define X86_LOAD4(X) \
        "movdqu %2, %%xmm1\n\t"  \
        cmovq(X, %0, %%xmm2) \
        "movq  %1, %%xmm3 \n\t"
        
#define X86_LOAD2_0(X) \
        "movdqu %2, %%xmm1\n\t" \
        cmovd(X, %0, %%xmm2) \
        "movd  %1, %%xmm3\n\t" \
        "movdqa  %%xmm1, %%xmm5\n\t"

#define X86_LOAD2_1(X) \
        "movdqu %2, %%xmm1\n\t" \
        "movdqu %3, %%xmm5\n\t" \
        cmovd(X, %0, %%xmm2) \
        "movd  %1, %%xmm3\n\t"
        
#define X86_SHIFT\
        "movdqa  %%xmm1, %%xmm4 \n\t" \
        "psrldq $1, %%xmm1\n\t" \
        "movdqa  %%xmm1, %%xmm5\n\t" \
        "psrldq $1, %%xmm1\n\t" \
        "movdqa  %%xmm1, %%xmm6\n\t" \
        "psrldq $1, %%xmm1\n\t"

#define X86_SHUF \
        "pshufd  $148, %%xmm4, %%xmm4\n\t" \
        "pshufd  $148, %%xmm5, %%xmm5\n\t" \
        "pshufd  $148, %%xmm6, %%xmm6\n\t" \
        "pshufd  $148, %%xmm1, %%xmm1\n\t"

#define X86_SLLQ(X,N) X86_SLLQ##X(N)
#define X86_SLLQ0(N)
#define X86_SLLQ1(N) \
        "psllq $"#N", %%xmm4\n\t" \
        "psllq $"#N", %%xmm5\n\t" \
        "psllq $"#N", %%xmm6\n\t" \
        "psllq $"#N", %%xmm1\n\t"

#define X86_SLLDQ_0(N) \
        "pslldq $"#N", %%xmm4\n\t" \
        "pslldq $"#N", %%xmm5\n\t" \
        "pslldq $"#N", %%xmm6\n\t" \
        "pslldq $"#N", %%xmm1\n\t"

#define X86_SLLDQ_1(N) \
        "pslldq $"#N", %%xmm1\n\t" \
        "psrldq $1, %%xmm5\n\t" \
        "pslldq $"#N", %%xmm5\n\t"
	
#define X86_SAD \
        "psadbw %%xmm0, %%xmm4\n\t" \
        "psadbw %%xmm0, %%xmm5\n\t" \
        "psadbw %%xmm0, %%xmm6\n\t" \
        "psadbw %%xmm0, %%xmm1\n\t" \
        "pslldq $2, %%xmm5\n\t" \
        "pslldq $4, %%xmm6\n\t" \
        "pslldq $6, %%xmm1\n\t" \
        "por %%xmm5, %%xmm4\n\t" \
        "por %%xmm6, %%xmm1\n\t" \
        "por %%xmm4, %%xmm1\n\t"

#define X86_SAD2 \
        "psadbw %%xmm0, %%xmm1\n\t" \
        "psadbw %%xmm0, %%xmm5\n\t" \
        "pslldq $2, %%xmm5\n\t" \
        "por %%xmm5, %%xmm1\n\t"


#define X86_SAVE8(X) \
       cpsubw(X, %0,%%xmm3\n\t) \
       "movdqa  %%xmm1, %0\n\t" \
       "paddw  %%xmm3, %%xmm1 \n\t" \
       "movdqa  %%xmm1, %1\n\t"

#define X86_SAVE4(X) \
       "pshufd $14, %%xmm1, %%xmm4\n\t" \
       "paddw  %%xmm4, %%xmm1\n\t" \
       cpsubw(X, %%xmm2, %%xmm3\n\t) \
       "movq  %%xmm1, %0\n\t" \
       "paddw  %%xmm3, %%xmm1\n\t" \
       "movq  %%xmm1, %1\n\t"

#define X86_SAVE2(X) \
       "pshufd $14, %%xmm1, %%xmm6\n\t" \
       "paddw  %%xmm6, %%xmm1\n\t" \
       cpsubw(X, %%xmm2, %%xmm3\n\t) \
       "movd  %%xmm1, %0\n\t" \
       "paddw  %%xmm3, %%xmm1 \n\t" \
       "movd  %%xmm1, %1\n\t"


#define X86_PIXEL_3_8(X, Y, N) \
       for (int d = d_min_; d <= d_max; d += 8) \
       { \
          __asm__ __volatile__ ( \
            X86_LOAD8 \
            X86_SHIFT \
            X86_SHUF \
            X86_SLLQ(Y,N) \
            X86_SAD \
            X86_SAVE8(X) \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft + d) ) : "%xmm0", "%xmm1","%xmm2","%xmm3", "%xmm4", "%xmm5","%xmm6"); \
    }

#define X86_PIXEL_9_12(X, N) \
       for (int d = d_min_; d <= d_max; d += 4) \
       { \
          __asm__ __volatile__ ( \
            X86_LOAD4(X) \
            X86_SHIFT \
            X86_SLLDQ_0(N) \
            X86_SAD \
            X86_SAVE4(X) \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft + d) ) : "%xmm0", "%xmm1","%xmm2","%xmm3", "%xmm4", "%xmm5","%xmm6"); \
    }


#define X86_PIXEL_13_15(X, N) \
       for (int d = d_min_; d <= d_max; d += 2) \
       { \
          __asm__ __volatile__ ( \
            X86_LOAD2_0(X) \
            X86_SLLDQ_1(N) \
            X86_SAD2 \
            X86_SAVE2(X) \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft + d) ) : "%xmm0", "%xmm1","%xmm2","%xmm3", "%xmm4", "%xmm5","%xmm6"); \
    }
    
#define X86_PIXEL_16_(X, N) \
       for (int d = d_min_; d <= d_max; d += 2) \
       { \
          __asm__ __volatile__ ( \
            X86_LOAD2_1(X) \
            X86_SAD2 \
            X86_SAVE2(X) \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft+d)), "m"(*(pLeft+d +1)) : "%xmm0","%xmm1","%xmm2","%xmm3","%xmm5","%xmm6"); \
    }


#define X86_PIXEL_3(X)  X86_PRELOAD_3          X86_PIXEL_3_8(X, 1, 40)
#define X86_PIXEL_4(X)  X86_PRELOAD_4          X86_PIXEL_3_8(X, 1, 32)
#define X86_PIXEL_5(X)  X86_PRELOAD_5_8(1, 24) X86_PIXEL_3_8(X, 1, 24)
#define X86_PIXEL_6(X)  X86_PRELOAD_5_8(1, 16) X86_PIXEL_3_8(X, 1, 16)
#define X86_PIXEL_7(X)  X86_PRELOAD_5_8(1, 8)  X86_PIXEL_3_8(X, 1, 8)
#define X86_PIXEL_8(X)  X86_PRELOAD_5_8(0, 0)  X86_PIXEL_3_8(X, 0, 0)
#define X86_PIXEL_9(X)  X86_PRELOAD_9_15(7)    X86_PIXEL_9_12(X, 7)
#define X86_PIXEL_10(X) X86_PRELOAD_9_15(6)    X86_PIXEL_9_12(X, 6)
#define X86_PIXEL_11(X) X86_PRELOAD_9_15(5)    X86_PIXEL_9_12(X, 5)
#define X86_PIXEL_12(X) X86_PRELOAD_9_15(4)    X86_PIXEL_9_12(X, 4)
#define X86_PIXEL_13(X) X86_PRELOAD_9_15(3)    X86_PIXEL_13_15(X, 3)
#define X86_PIXEL_14(X) X86_PRELOAD_9_15(2)    X86_PIXEL_13_15(X, 2)
#define X86_PIXEL_15(X) X86_PRELOAD_9_15(1)    X86_PIXEL_13_15(X, 1)
#define X86_PIXEL_16(X) X86_PRELOAD_16         X86_PIXEL_16_(X, 0)

#define SSE4_PRELOAD_3  \
    __asm__ __volatile__ ("movd %0, %%xmm0"::"m" (*pRight) : "%xmm0"); \
    __asm__ __volatile__ ("movdqa %0, %%xmm5"::"m" (*pr) : "%xmm5");
    
#define  SSE4_PRELOAD_4  \
    __asm__ __volatile__ ("movd %0, %%xmm0"::"m" (*pRight) : "%xmm0");

#define SSE4_PRELOAD_6 \
    __asm__ __volatile__ ("movd %0, %%xmm0"::"m" (*pRight) : "%xmm0"); \
    __asm__ __volatile__ ( \
        "movdqa %0, %%xmm5\n\t" \
        "movdqa %1, %%xmm7\n\t" \
        ::"m" (*pr),"m" (*pr2)  : "%xmm5", "%xmm7");

#define SSE4_PRELOAD_7 \
    __asm__ __volatile__ ("movq %0, %%xmm0"::"m" (*pRight) : "%xmm0"); \
    __asm__ __volatile__ ("movdqa %0, %%xmm5"::"m" (*pr) : "%xmm5");
    
#define SSE4_PRELOAD_8 \
    __asm__ __volatile__ ("movq %0, %%xmm0"::"m" (*pRight) : "%xmm0");

#define SSE4_PRELOAD_12 \
    __asm__ __volatile__ ( \
        "movdqu %0, %%xmm0\n\t" \
        "movdqu %1, %%xmm1\n\t" \
        ::"m" (*pRight), "m"(*(pLeft + d_min_)) : "%xmm0", "%xmm1");
        
#define SSE4_PRELOAD_10 \
    SSE4_PRELOAD_12 \
    __asm__ __volatile__ ( \
        "movdqa %0, %%xmm5\n\t" \
        "movdqa %1, %%xmm9\n\t" \
        ::"m" (*pr),"m" (*pr2)  : "%xmm5", "%xmm9");
        
#define SSE4_PRELOAD_11 \
    SSE4_PRELOAD_12 \
    __asm__ __volatile__ ("movdqa %0, %%xmm8"::"m" (*pr) : "%xmm8");

               
#define  SSE4_PIXEL_3_(X) \
    for (int d = d_min_; d <= d_max; d += 8) \
    { \
        __asm__ __volatile__ ( \
            "movdqu %2, %%xmm1\n\t" \
            cmovdqa(X, %0, %%xmm2) \
            "movdqa  %1, %%xmm3 \n\t" \
            "pxor %%xmm4, %%xmm4\n\t" \
            "por %%xmm1, %%xmm4\n\t" \
            "mpsadbw $0, %%xmm0, %%xmm1\n\t" \
            "psrldq $3, %%xmm4\n\t" \
            "pmovzxbw %%xmm4, %%xmm4\n\t" \
            cpsubw(X, %%xmm2, %%xmm3\n\t) \
            "psubw  %%xmm5, %%xmm4 \n\t" \
            "pabsw  %%xmm4, %%xmm4 \n\t" \
            "psubw  %%xmm4, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %0\n\t" \
            "paddw  %%xmm3, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %1\n\t" \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft + d) ) : "%xmm0", "%xmm1","%xmm2","%xmm3","%xmm4","%xmm5"); \
    }
    
#define  SSE4_PIXEL_4_(X) \
    for (int d = d_min_; d <= d_max; d += 8) \
    { \
        __asm__ __volatile__ ( \
            "movdqu %2, %%xmm1\n\t" \
            cmovdqa(X, %0, %%xmm2) \
            "movdqa  %1, %%xmm3 \n\t" \
            "mpsadbw $0, %%xmm0, %%xmm1\n\t" \
            cpsubw(X, %%xmm2, %%xmm3\n\t) \
            "movdqa  %%xmm1, %0\n\t" \
            "paddw  %%xmm3, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %1\n\t" \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft + d) ) : "%xmm0", "%xmm1","%xmm2","%xmm3"); \
    }

#define  SSE4_PIXEL_5_(X) \
    for (int d = d_min_; d <= d_max; d += 8) \
    { \
        __asm__ __volatile__ ( \
            "movdqu %2, %%xmm1\n\t"  \
            cmovdqa(X, %0, %%xmm2) \
            "movdqa  %1, %%xmm3 \n\t" \
            "pxor %%xmm4, %%xmm4\n\t" \
            "por %%xmm1, %%xmm4\n\t" \
            "mpsadbw $0, %%xmm0, %%xmm1\n\t" \
            "psrldq $4, %%xmm4\n\t" \
            "pmovzxbw %%xmm4, %%xmm4\n\t" \
            cpsubw(X, %%xmm2, %%xmm3\n\t) \
            "psubw  %%xmm5, %%xmm4 \n\t" \
            "pabsw  %%xmm4, %%xmm4 \n\t" \
            "paddw  %%xmm4, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %0\n\t" \
            "paddw  %%xmm3, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %1\n\t" \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft + d) ) : "%xmm0", "%xmm1","%xmm2","%xmm3","%xmm4","%xmm5"); \
    }

#define  SSE4_PIXEL_6_(X) \
    for (int d = d_min_; d <= d_max; d += 8) \
    { \
        __asm__ __volatile__ ( \
            "movdqu %2, %%xmm1\n\t" \
            cmovdqa(X, %0, %%xmm2) \
            "movdqa  %1, %%xmm3 \n\t" \
            "pxor %%xmm4, %%xmm4\n\t" \
            "pxor %%xmm6, %%xmm6\n\t" \
            "por %%xmm1, %%xmm4\n\t" \
            "por %%xmm1, %%xmm6\n\t" \
            "mpsadbw $0, %%xmm0, %%xmm1\n\t" \
            "psrldq $4, %%xmm4\n\t" \
            "psrldq $5, %%xmm6\n\t" \
            "pmovzxbw %%xmm4, %%xmm4\n\t" \
            "pmovzxbw %%xmm6, %%xmm6\n\t" \
            cpsubw(X, %%xmm2, %%xmm3\n\t) \
            "psubw  %%xmm5, %%xmm4 \n\t" \
            "psubw  %%xmm7, %%xmm6 \n\t" \
            "pabsw  %%xmm4, %%xmm4 \n\t" \
            "pabsw  %%xmm6, %%xmm6 \n\t" \
            "paddw  %%xmm4, %%xmm1 \n\t" \
            "paddw  %%xmm6, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %0\n\t" \
            "paddw  %%xmm3, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %1\n\t" \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft + d) ) : "%xmm0", "%xmm1","%xmm2","%xmm3","%xmm4","%xmm5", "%xmm6","%xmm7"); \
    }


#define  SSE4_PIXEL_7_(X) \
    for (int d = d_min_; d <= d_max; d += 8) \
    { \
        __asm__ __volatile__ ( \
            "movdqu  %2, %%xmm1\n\t" \
            cmovdqa(X, %0, %%xmm2) \
            "movdqa  %1, %%xmm3 \n\t"\
            "pxor %%xmm4, %%xmm4\n\t" \
            "pxor %%xmm6, %%xmm6\n\t" \
            "por  %%xmm1, %%xmm4\n\t" \
            "por  %%xmm1, %%xmm6\n\t"  \
            "mpsadbw $0, %%xmm0, %%xmm1\n\t" \
            "mpsadbw $5, %%xmm0, %%xmm4\n\t" \
            "psrldq $7, %%xmm6\n\t" \
            "pmovzxbw %%xmm6, %%xmm6\n\t" \
            cpsubw(X, %%xmm2, %%xmm3\n\t) \
            "paddw  %%xmm4, %%xmm1\n\t" \
            "psubw  %%xmm5, %%xmm6 \n\t" \
            "pabsw  %%xmm6, %%xmm6 \n\t" \
            "psubw  %%xmm6, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %0\n\t" \
            "paddw  %%xmm3, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %1\n\t" \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft + d) ) : "%xmm0", "%xmm1","%xmm2","%xmm3", "%xmm4", "%xmm5", "%xmm6"); \
    }

#define  SSE4_PIXEL_8_(X) \
    for (int d = d_min_; d <= d_max; d += 8) \
    { \
        __asm__ __volatile__ ( \
            "movdqu %2, %%xmm1\n\t" \
            cmovdqa(X, %0, %%xmm2) \
            "movdqa  %1, %%xmm3 \n\t" \
            "pxor %%xmm4, %%xmm4\n\t" \
            "por  %%xmm1,%%xmm4\n\t" \
            "mpsadbw $0, %%xmm0, %%xmm1\n\t" \
            "mpsadbw $5, %%xmm0, %%xmm4\n\t" \
            cpsubw(X, %%xmm2, %%xmm3\n\t) \
            "paddw  %%xmm4, %%xmm1\n\t" \
            "movdqa  %%xmm1, %0\n\t" \
            "paddw  %%xmm3, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %1\n\t" \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft + d) ) : "%xmm0", "%xmm1","%xmm2","%xmm3", "%xmm4"); \
    }

#define  SSE4_PIXEL_9_(X) \
    for (int d = d_min_; d <= d_max; d += 8) \
    { \
        __asm__ __volatile__ ( \
            "movdqu  %2, %%xmm1\n\t" \
            cmovdqa(X, %0, %%xmm2) \
            "movdqa  %1, %%xmm3 \n\t" \
            "pxor %%xmm4, %%xmm4\n\t" \
            "pxor %%xmm6, %%xmm6\n\t" \
            "por  %%xmm1, %%xmm4\n\t" \
            "por  %%xmm1, %%xmm6\n\t" \
            "mpsadbw $0, %%xmm0, %%xmm1\n\t" \
            "mpsadbw $5, %%xmm0, %%xmm4\n\t" \
            "psrldq $8, %%xmm6\n\t" \
            "pmovzxbw %%xmm6, %%xmm6\n\t" \
            cpsubw(X, %%xmm2, %%xmm3\n\t) \
            "paddw  %%xmm4, %%xmm1\n\t" \
            "psubw  %%xmm5, %%xmm6 \n\t" \
            "pabsw  %%xmm6, %%xmm6 \n\t" \
            "paddw  %%xmm6, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %0\n\t" \
            "paddw  %%xmm3, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %1\n\t" \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft + d) ) : "%xmm0", "%xmm1","%xmm2","%xmm3", "%xmm4", "%xmm5", "%xmm6"); \
    }

#define  SSE4_PIXEL_10_(X) \
    for (int d = d_min_; d <= d_max; d += 8) \
    { \
        __asm__ __volatile__ ( \
            "movdqu  %2, %%xmm7\n\t" \
            cmovdqa(X, %0, %%xmm2) \
            "movdqa  %1, %%xmm3 \n\t" \
            "pxor %%xmm4, %%xmm4\n\t" \
            "pxor %%xmm6, %%xmm6\n\t" \
            "pxor %%xmm8, %%xmm8\n\t" \
            "por  %%xmm1, %%xmm4\n\t" \
            "por  %%xmm1, %%xmm6\n\t" \
            "por  %%xmm7, %%xmm8\n\t" \
            "mpsadbw $0, %%xmm0, %%xmm1\n\t" \
            "mpsadbw $5, %%xmm0, %%xmm4\n\t" \
            "psrldq $8, %%xmm6\n\t" \
            "psrldq $1, %%xmm8\n\t" \
            "pmovzxbw %%xmm6, %%xmm6\n\t" \
            "pmovzxbw %%xmm8, %%xmm8\n\t" \
            cpsubw(X, %%xmm2, %%xmm3\n\t) \
            "paddw  %%xmm4, %%xmm1\n\t" \
            "psubw  %%xmm5, %%xmm6 \n\t" \
            "psubw  %%xmm9, %%xmm8 \n\t" \
            "pabsw  %%xmm6, %%xmm6 \n\t" \
            "pabsw  %%xmm8, %%xmm8 \n\t" \
            "paddw  %%xmm6, %%xmm1 \n\t" \
            "paddw  %%xmm8, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %0\n\t" \
            "paddw  %%xmm3, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %1\n\t" \
            "pxor %%xmm1, %%xmm1\n\t" \
            "por  %%xmm7,%%xmm1\n\t" \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft + d + 8) ) : "%xmm0", "%xmm1","%xmm2","%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7","%xmm8","%xmm9"); \
    }

#define  SSE4_PIXEL_11_(X) \
    for (int d = d_min_; d <= d_max; d += 8) \
    { \
        __asm__ __volatile__ ( \
            "movdqu %2, %%xmm5\n\t" \
            cmovdqa(X, %0, %%xmm2) \
            "movdqa  %1, %%xmm3 \n\t" \
            "pxor %%xmm4, %%xmm4\n\t" \
            "pxor %%xmm6, %%xmm6\n\t" \
            "pxor %%xmm7, %%xmm7\n\t" \
            "por  %%xmm1,%%xmm4\n\t" \
            "por  %%xmm5,%%xmm6\n\t" \
            "por  %%xmm5,%%xmm7\n\t" \
            "mpsadbw $0, %%xmm0, %%xmm1\n\t" \
            "mpsadbw $5, %%xmm0, %%xmm4\n\t" \
            "mpsadbw $2, %%xmm0, %%xmm5\n\t" \
            "psrldq $3, %%xmm7\n\t" \
            "pmovzxbw %%xmm7, %%xmm7\n\t" \
            cpsubw(X, %%xmm2, %%xmm3\n\t) \
            "paddw  %%xmm4, %%xmm1\n\t" \
            "paddw  %%xmm5, %%xmm1\n\t" \
            "psubw  %%xmm8, %%xmm7 \n\t" \
            "pabsw  %%xmm7, %%xmm7 \n\t" \
            "psubw  %%xmm7, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %0\n\t" \
            "paddw  %%xmm3, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %1\n\t" \
            "pxor %%xmm1, %%xmm1\n\t" \
            "por  %%xmm6,%%xmm1\n\t" \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft + d +8) ) : "%xmm0", "%xmm1","%xmm2","%xmm3", "%xmm4", "%xmm5","%xmm6","%xmm7"); \
    }

#define  SSE4_PIXEL_12_(X) \
    for (int d = d_min_; d <= d_max; d += 8) \
    { \
        __asm__ __volatile__ ( \
            "movdqu %2, %%xmm5\n\t" \
            cmovdqa(X, %0, %%xmm2) \
            "movdqa  %1, %%xmm3 \n\t" \
            "pxor %%xmm4, %%xmm4\n\t" \
            "pxor %%xmm6, %%xmm6\n\t" \
            "por  %%xmm1,%%xmm4\n\t" \
            "por  %%xmm5,%%xmm6\n\t" \
            "mpsadbw $0, %%xmm0, %%xmm1\n\t" \
            "mpsadbw $5, %%xmm0, %%xmm4\n\t" \
            "mpsadbw $2, %%xmm0, %%xmm5\n\t" \
            cpsubw(X, %%xmm2, %%xmm3\n\t) \
            "paddw  %%xmm4, %%xmm1\n\t" \
            "paddw  %%xmm5, %%xmm1\n\t" \
            "movdqa  %%xmm1, %0\n\t" \
            "paddw  %%xmm3, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %1\n\t" \
            "pxor %%xmm1, %%xmm1\n\t" \
            "por  %%xmm6,%%xmm1\n\t" \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft + d +8) ) : "%xmm0", "%xmm1","%xmm2","%xmm3", "%xmm4", "%xmm5","%xmm6"); \
    }

#define  SSE4_PIXEL_13_(X) \
    for (int d = d_min_; d <= d_max; d += 8) \
    { \
        __asm__ __volatile__ ( \
            "movdqu %2, %%xmm5\n\t" \
            cmovdqa(X, %0, %%xmm2) \
            "movdqa  %1, %%xmm3 \n\t" \
            "pxor %%xmm4, %%xmm4\n\t" \
            "pxor %%xmm6, %%xmm6\n\t" \
            "pxor %%xmm7, %%xmm7\n\t" \
            "por  %%xmm1,%%xmm4\n\t" \
            "por  %%xmm5,%%xmm6\n\t" \
            "por  %%xmm5,%%xmm7\n\t" \
            "mpsadbw $0, %%xmm0, %%xmm1\n\t" \
            "mpsadbw $5, %%xmm0, %%xmm4\n\t" \
            "mpsadbw $2, %%xmm0, %%xmm5\n\t" \
            "psrldq $4, %%xmm7\n\t" \
            "pmovzxbw %%xmm7, %%xmm7\n\t" \
            cpsubw(X, %%xmm2, %%xmm3\n\t) \
            "paddw  %%xmm4, %%xmm1\n\t" \
            "paddw  %%xmm5, %%xmm1\n\t" \
            "psubw  %%xmm8, %%xmm7 \n\t" \
            "pabsw  %%xmm7, %%xmm7 \n\t" \
            "paddw  %%xmm7, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %0\n\t" \
            "paddw  %%xmm3, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %1\n\t" \
            "pxor %%xmm1, %%xmm1\n\t" \
            "por  %%xmm6,%%xmm1\n\t" \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft + d +8) ) : "%xmm0", "%xmm1","%xmm2","%xmm3", "%xmm4", "%xmm5","%xmm6","%xmm7"); \
    }


#define  SSE4_PIXEL_14_(X) \
    for (int d = d_min_; d <= d_max; d += 8) \
    { \
        __asm__ __volatile__ ( \
            "movdqu %2, %%xmm8\n\t" \
            cmovdqa(X, %0, %%xmm2) \
            "movdqa  %1, %%xmm3 \n\t" \
            "pxor %%xmm4, %%xmm4\n\t" \
            "pxor %%xmm6, %%xmm6\n\t" \
            "pxor %%xmm7, %%xmm7\n\t" \
            "pxor %%xmm10, %%xmm10\n\t" \
            "por  %%xmm1,%%xmm4\n\t" \
            "por  %%xmm8,%%xmm6\n\t" \
            "por  %%xmm8,%%xmm7\n\t" \
            "por  %%xmm8,%%xmm10\n\t" \
            "mpsadbw $0, %%xmm0, %%xmm1\n\t" \
            "mpsadbw $5, %%xmm0, %%xmm4\n\t" \
            "mpsadbw $2, %%xmm0, %%xmm8\n\t" \
            "psrldq $4, %%xmm7\n\t" \
            "psrldq $5, %%xmm10\n\t" \
            "pmovzxbw %%xmm7, %%xmm7\n\t" \
            "pmovzxbw %%xmm10, %%xmm10\n\t" \
            cpsubw(X, %%xmm2, %%xmm3\n\t) \
            "paddw  %%xmm4, %%xmm1\n\t" \
            "paddw  %%xmm8, %%xmm1\n\t" \
            "psubw  %%xmm5, %%xmm7 \n\t" \
            "psubw  %%xmm9, %%xmm10 \n\t" \
            "pabsw  %%xmm7, %%xmm7 \n\t" \
            "pabsw  %%xmm10, %%xmm10 \n\t" \
            "paddw  %%xmm7, %%xmm1 \n\t" \
            "paddw  %%xmm10, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %0\n\t" \
            "paddw  %%xmm3, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %1\n\t" \
            "pxor %%xmm1, %%xmm1\n\t" \
            "por  %%xmm6,%%xmm1\n\t" \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft + d +8) ) : "%xmm0", "%xmm1","%xmm2","%xmm3", "%xmm4", "%xmm5","%xmm6","%xmm7", "%xmm8","%xmm9","%xmm10"); \
    }

    
#define  SSE4_PIXEL_15_(X) \
    for (int d = d_min_; d <= d_max; d += 8) \
    { \
        __asm__ __volatile__ ( \
            "movdqu %2, %%xmm5\n\t" \
            cmovdqa(X, %0, %%xmm2) \
            "movdqa  %1, %%xmm3 \n\t" \
            "pxor %%xmm4, %%xmm4\n\t" \
            "pxor %%xmm6, %%xmm6\n\t" \
            "pxor %%xmm7, %%xmm7\n\t" \
            "pxor %%xmm9, %%xmm9\n\t" \
            "por  %%xmm1,%%xmm4\n\t" \
            "por  %%xmm5,%%xmm7\n\t" \
            "por  %%xmm5,%%xmm6\n\t" \
            "por  %%xmm5,%%xmm9\n\t" \
            "mpsadbw $0, %%xmm0, %%xmm1\n\t" \
            "mpsadbw $5, %%xmm0, %%xmm4\n\t" \
            "mpsadbw $2, %%xmm0, %%xmm5\n\t" \
            "mpsadbw $7, %%xmm0, %%xmm7\n\t" \
            "psrldq $7, %%xmm9\n\t" \
            "pmovzxbw %%xmm9, %%xmm9\n\t" \
            cpsubw(X, %%xmm2, %%xmm3\n\t) \
            "paddw  %%xmm4, %%xmm5\n\t" \
            "paddw  %%xmm7, %%xmm1\n\t" \
            "paddw  %%xmm5, %%xmm1\n\t" \
            "psubw  %%xmm8, %%xmm9 \n\t" \
            "pabsw  %%xmm9, %%xmm9 \n\t" \
            "psubw  %%xmm9, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %0\n\t" \
            "paddw  %%xmm3, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %1\n\t" \
            "pxor %%xmm1, %%xmm1\n\t" \
            "por  %%xmm6,%%xmm1\n\t" \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft + d +8) ) : "%xmm0", "%xmm1","%xmm2","%xmm3", "%xmm4", "%xmm5","%xmm6","%xmm7","%xmm8","%xmm9");\
    }

 #define  SSE4_PIXEL_16_(X) \
    for (int d = d_min_; d <= d_max; d += 8) \
    { \
        __asm__ __volatile__ ( \
            "movdqu %2, %%xmm5\n\t" \
            cmovdqa(X, %0, %%xmm2) \
            "movdqa  %1, %%xmm3 \n\t" \
            "pxor %%xmm4, %%xmm4\n\t" \
            "pxor %%xmm6, %%xmm6\n\t" \
            "pxor %%xmm7, %%xmm7\n\t" \
            "por  %%xmm1,%%xmm4\n\t" \
            "por  %%xmm5,%%xmm7\n\t" \
            "por  %%xmm5,%%xmm6\n\t" \
            "mpsadbw $0, %%xmm0, %%xmm1\n\t" \
            "mpsadbw $5, %%xmm0, %%xmm4\n\t" \
            "mpsadbw $2, %%xmm0, %%xmm5\n\t" \
            "mpsadbw $7, %%xmm0, %%xmm7\n\t" \
            cpsubw(X, %%xmm2, %%xmm3\n\t) \
            "paddw  %%xmm4, %%xmm5\n\t" \
            "paddw  %%xmm7, %%xmm1\n\t" \
            "paddw  %%xmm5, %%xmm1\n\t" \
            "movdqa  %%xmm1, %0\n\t" \
            "paddw  %%xmm3, %%xmm1 \n\t" \
            "movdqa  %%xmm1, %1\n\t" \
            "pxor %%xmm1, %%xmm1\n\t" \
            "por  %%xmm6,%%xmm1\n\t" \
    : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLeft + d +8) ) : "%xmm0", "%xmm1","%xmm2","%xmm3", "%xmm4", "%xmm5","%xmm6","%xmm7"); \
    }


#define SSE4_PIXEL_3(X)  SSE4_PRELOAD_3  SSE4_PIXEL_3_(X)
#define SSE4_PIXEL_4(X)  SSE4_PRELOAD_4  SSE4_PIXEL_4_(X)
#define SSE4_PIXEL_5(X)  SSE4_PRELOAD_3  SSE4_PIXEL_5_(X) 
#define SSE4_PIXEL_6(X)  SSE4_PRELOAD_6  SSE4_PIXEL_6_(X)
#define SSE4_PIXEL_7(X)  SSE4_PRELOAD_7  SSE4_PIXEL_7_(X)
#define SSE4_PIXEL_8(X)  SSE4_PRELOAD_8  SSE4_PIXEL_8_(X)
#define SSE4_PIXEL_9(X)  SSE4_PRELOAD_7  SSE4_PIXEL_9_(X)
#define SSE4_PIXEL_10(X) SSE4_PRELOAD_10 SSE4_PIXEL_10_(X) 
#define SSE4_PIXEL_11(X) SSE4_PRELOAD_11 SSE4_PIXEL_11_(X)
#define SSE4_PIXEL_12(X) SSE4_PRELOAD_12 SSE4_PIXEL_12_(X)
#define SSE4_PIXEL_13(X) SSE4_PRELOAD_11 SSE4_PIXEL_13_(X)
#define SSE4_PIXEL_14(X) SSE4_PRELOAD_10 SSE4_PIXEL_14_(X)
#define SSE4_PIXEL_15(X) SSE4_PRELOAD_11 SSE4_PIXEL_15_(X)
#define SSE4_PIXEL_16(X) SSE4_PRELOAD_12 SSE4_PIXEL_16_(X)

        template<>
        struct pixel0_loop<3, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[3];
                DECLSPEC_ALIGN(16) cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};

                SSE4_PIXEL_3(0)
#else
                X86_PIXEL_3(0)
#endif
            }
        };
        

        template<>
        struct pixel_loop<3, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[3];
                DECLSPEC_ALIGN(16) cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                SSE4_PIXEL_3(1)
#else
                X86_PIXEL_3(1)
#endif
            }
        };


        template<>
        struct pixel0_loop<4, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                SSE4_PIXEL_4(0)
#else
                X86_PIXEL_4(0)
#endif
            }
        };

        template<>
        struct pixel_loop<4, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                SSE4_PIXEL_4(1)
#else
                X86_PIXEL_4(1)
#endif
            }
        };


        template<>
        struct pixel0_loop<5, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[4];
                DECLSPEC_ALIGN(16)  cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                SSE4_PIXEL_5(0)
#else
                X86_PIXEL_5(0)
#endif
            }
        };

       template<>
        struct pixel_loop<5, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[4];
                DECLSPEC_ALIGN(16) cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                SSE4_PIXEL_5(1)
#else
                X86_PIXEL_5(1)
#endif
            }
        };


        template<>
        struct pixel0_loop<6, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[4];
                cimage::Mono16 b = pRight[5];
                DECLSPEC_ALIGN(16) cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                DECLSPEC_ALIGN(16) cimage::Mono16 pr2[8] = {b, b, b, b, b, b, b, b};
                SSE4_PIXEL_6(0)
#else
                X86_PIXEL_6(0)
#endif
            }
        };

        template<>
        struct pixel_loop<6, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[4];
                cimage::Mono16 b = pRight[5];
                DECLSPEC_ALIGN(16) cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                DECLSPEC_ALIGN(16) cimage::Mono16 pr2[8] = {b, b, b, b, b, b, b, b};
                SSE4_PIXEL_6(1)
#else
                X86_PIXEL_6(1)
#endif
            }
        };


        template<>
        struct pixel0_loop<7, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[7];
                DECLSPEC_ALIGN(16) cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                SSE4_PIXEL_7(0)
#else
                X86_PIXEL_7(0)
#endif
            }
        };

        template<>
        struct pixel_loop<7, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[7];
                DECLSPEC_ALIGN(16) cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                SSE4_PIXEL_7(1)
#else
                X86_PIXEL_7(1)
#endif
            }
        };


        template<>
        struct pixel0_loop<8, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                SSE4_PIXEL_8(0)
#else
                X86_PIXEL_8(0)
#endif
            }
        };

        template<>
        struct pixel_loop<8, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                SSE4_PIXEL_8(1)
#else
                X86_PIXEL_8(1)
#endif
            }
        };


        template<>
        struct pixel0_loop<9, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[8];
                DECLSPEC_ALIGN(16)  cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                SSE4_PIXEL_9(0)
#else
                X86_PIXEL_9(0)
#endif
            }
        };

        template<>
        struct pixel_loop<9, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[8];
                DECLSPEC_ALIGN(16) cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                SSE4_PIXEL_9(1)
#else
                X86_PIXEL_9(1)
#endif
            }
        };


        template<>
        struct pixel0_loop<10, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[8];
                cimage::Mono16 b = pRight[9];
                DECLSPEC_ALIGN(16)  cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                DECLSPEC_ALIGN(16)  cimage::Mono16 pr2[8] = {b, b, b, b, b, b, b, b};
                SSE4_PIXEL_10(0)
#else
                X86_PIXEL_10(0)
#endif
            }
        };

        template<>
        struct pixel_loop<10, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[8];
                cimage::Mono16 b = pRight[9];
                DECLSPEC_ALIGN(16) cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                DECLSPEC_ALIGN(16) cimage::Mono16 pr2[8] = {b, b, b, b, b, b, b, b};
                SSE4_PIXEL_10(1)
#else
                X86_PIXEL_10(1)
#endif
            }
        };

        template<>
        struct pixel0_loop<11, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[11];
                DECLSPEC_ALIGN(16)  cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                SSE4_PIXEL_11(0)
#else
                X86_PIXEL_11(0)
#endif
            }
        };

        template<>
        struct pixel_loop<11, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[11];
                DECLSPEC_ALIGN(16)  cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                SSE4_PIXEL_11(1)
#else
                X86_PIXEL_11(1)
#endif
            }
        };


        template<>
        struct pixel0_loop<12, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                SSE4_PIXEL_12(0)
#else
                X86_PIXEL_12(0)
#endif
            }
        };

        template<>
        struct pixel_loop<12, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                SSE4_PIXEL_12(1)
#else
                X86_PIXEL_12(1)
#endif
            }
        };


        template<>
        struct pixel0_loop<13, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[12];
                DECLSPEC_ALIGN(16)  cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                SSE4_PIXEL_13(0)
#else
                X86_PIXEL_13(0)
#endif
            }
        };

        template<>
        struct pixel_loop<13, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[12];
                DECLSPEC_ALIGN(16) cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                SSE4_PIXEL_13(1)
#else
                X86_PIXEL_13(1)
#endif
            }
        };


        template<>
        struct pixel0_loop<14, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[12];
                cimage::Mono16 b = pRight[13];
                DECLSPEC_ALIGN(16)  cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                DECLSPEC_ALIGN(16)  cimage::Mono16 pr2[8] = {b, b, b, b, b, b, b, b};
                SSE4_PIXEL_14(0)
#else
                X86_PIXEL_14(0)
#endif
            }
        };

        template<>
        struct pixel_loop<14, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[12];
                cimage::Mono16 b = pRight[13];
                DECLSPEC_ALIGN(16) cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                DECLSPEC_ALIGN(16) cimage::Mono16 pr2[8] = {b, b, b, b, b, b, b, b};
                SSE4_PIXEL_14(1)
#else
                X86_PIXEL_14(1)
#endif
            }
        };


        template<>
        struct pixel0_loop<15, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[15];
                DECLSPEC_ALIGN(16)  cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                SSE4_PIXEL_15(0)
#else
                X86_PIXEL_15(0)
#endif
            }
        };

        template<>
        struct pixel_loop<15, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                cimage::Mono16 a = pRight[15];
                DECLSPEC_ALIGN(16) cimage::Mono16 pr[8] = {a, a, a, a, a, a, a, a};
                SSE4_PIXEL_15(1)
#else
                X86_PIXEL_15(1)
#endif
            }
        };


        template<>
        struct pixel0_loop<16, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                SSE4_PIXEL_16(0)
#else
                X86_PIXEL_16(0)
#endif
            }
        };

        template<>
        struct pixel_loop<16, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >
        {
            static inline void run(const cimage::Mono8* pLeft, const cimage::Mono8* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)
            {
                long d_min_ = (((long)(cur_corr_row_sum +d_min)& ~15 ) -(long)cur_corr_row_sum) /2;

#ifdef __SSE4_1__
                SSE4_PIXEL_16(1)
#else
                X86_PIXEL_16(1)
#endif
            }
        };

        
        
        #define PIXEL_LOOP_MONO8O127(N) \
        template<>\
        struct pixel0_loop<N, cimage::Mono8o127, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >\
        {\
            static inline void run(const cimage::Mono8o127* pLeft, const cimage::Mono8o127* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)\
            {\
                pixel0_loop<N, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >::run((cimage::Mono8*)pLeft, (cimage::Mono8*)pRight, cur_prev_row_corr, cur_corr_row_sum, d_min, d_max);\
            }\
        };\
        template<>\
        struct pixel_loop<N, cimage::Mono8o127, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >\
        {\
            static inline void run(const cimage::Mono8o127* pLeft, cimage::Mono8o127* pRight, uint16_t* cur_prev_row_corr, uint16_t* cur_corr_row_sum, int d_min, int d_max)\
            {\
                pixel_loop<N, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> >::run((cimage::Mono8*)pLeft, (cimage::Mono8*)pRight, cur_prev_row_corr, cur_corr_row_sum, d_min, d_max);\
            }\
        };
        
        PIXEL_LOOP_MONO8O127(3)
        PIXEL_LOOP_MONO8O127(4)
        PIXEL_LOOP_MONO8O127(5)
        PIXEL_LOOP_MONO8O127(6)
        PIXEL_LOOP_MONO8O127(7)
        PIXEL_LOOP_MONO8O127(8)
        PIXEL_LOOP_MONO8O127(9)
        PIXEL_LOOP_MONO8O127(10)
        PIXEL_LOOP_MONO8O127(11)
        PIXEL_LOOP_MONO8O127(12)
        PIXEL_LOOP_MONO8O127(13)
        PIXEL_LOOP_MONO8O127(14)
        PIXEL_LOOP_MONO8O127(15)
        PIXEL_LOOP_MONO8O127(16)
        
        #define PIXEL_LOOP_AUTO(N) \
        template<>\
        struct pixel0_loop<N, cimage::Mono8o127, uint16_t, impl::Auto, cost::AbsDiff<uint16_t> >\
        : public pixel0_loop<N, cimage::Mono8o127, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> > {};\
        template<>\
        struct pixel0_loop<N, cimage::Mono8, uint16_t, impl::Auto, cost::AbsDiff<uint16_t> >\
        : public pixel0_loop<N, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> > {};\
        template<>\
        struct pixel_loop<N, cimage::Mono8o127, uint16_t, impl::Auto, cost::AbsDiff<uint16_t> >\
        : public pixel_loop<N, cimage::Mono8o127, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> > {};\
        template<>\
        struct pixel_loop<N, cimage::Mono8, uint16_t, impl::Auto, cost::AbsDiff<uint16_t> >\
        : public pixel_loop<N, cimage::Mono8, uint16_t, impl::SIMD, cost::AbsDiff<uint16_t> > {};
        
        PIXEL_LOOP_AUTO(3)
        PIXEL_LOOP_AUTO(4)
        PIXEL_LOOP_AUTO(5)
        PIXEL_LOOP_AUTO(6)
        PIXEL_LOOP_AUTO(7)
        PIXEL_LOOP_AUTO(8)
        PIXEL_LOOP_AUTO(9)
        PIXEL_LOOP_AUTO(10)
        PIXEL_LOOP_AUTO(11)
        PIXEL_LOOP_AUTO(12)
        PIXEL_LOOP_AUTO(13)
        PIXEL_LOOP_AUTO(14)
        PIXEL_LOOP_AUTO(15)
        PIXEL_LOOP_AUTO(16)

#endif
    }
}

#endif
