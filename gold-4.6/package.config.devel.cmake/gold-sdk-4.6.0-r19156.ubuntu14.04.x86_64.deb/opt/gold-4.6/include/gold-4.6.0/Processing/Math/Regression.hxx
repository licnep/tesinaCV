#ifndef _REGRESSION_MATH_HXX
#define _REGRESSION_MATH_HXX

#include <cmath>
#include "Regression.h"

namespace math {

template<class R, class T>
R orthogonal_least_squares_fitting(Line3<R> & out, const T * in, unsigned int size)
{
    R sx, sy, sx2, sy2, sxy;

    sx = sy = sxy = sx2 = sy2 = R(0);

    // calcolo la matrice
    for (unsigned int i=0;i<size;i++)
    {
        sx += (R) in[i].x;
        sy += (R) in[i].y;

        sxy += (R) in[i].x * in[i].y;

        sx2 += (R) in[i].x * in[i].x;
        sy2 += (R) in[i].y * in[i].y;
    }

    R A,B,D;
    R e1,e2,e;
    // NOTA: si possono evitare in parte le seguenti divisioni
    sx/=size;
    sy/=size;
    sxy/=size;
    sx2/=size;
    sy2/=size;
    R Sx,Sy,Sxy;
    // Sx a^2 + 2 Sxy a b + Sy b^2
    Sx = sx2 - sx*sx;
    Sy = sy2 - sy*sy;
    Sxy = sxy - sx*sy;
    // sistema del tipo a^2 A - 2 * B * a * b - A * b^2 = 0
    A = Sxy; // Sxy
    B = (Sx - Sy)/2.0; // versione con il meno
    D = std::sqrt( B*B + A*A );

    // le soluzioni sono:
    // a = B+D, b = A
    // a = B-D, b = A
    out.b = A;
    // non si puo' ottimizzare???
    e1 = ( (B + D)*(B + D) * Sx + 2.0 * (B + D) * A * Sxy +  A * A * Sy) / ((B + D)*(B + D) + A * A);
    e2 = ( (B - D)*(B - D) * Sx + 2.0 * (B - D) * A * Sxy +  A * A * Sy) / ((B - D)*(B - D) + A * A);

    if (e1 < e2)
    {
        out.a = B + D;
        e = e1;
    }
    else
    {
        out.a = B - D;
        e = e2;
    }
    // c deve essere tale che la retta passi per il centroide
    out.c = - out.a * sx - out.b * sy;

    return e;
}


template<class R, class InputIterator>
R orthogonal_least_squares_fitting(Line3<R> & out,  InputIterator __first, InputIterator __last)
{
    R sx, sy, sx2, sy2, sxy;
    int size = 0;
    sx = sy = sxy = sx2 = sy2 = R(0);

    // calcolo la matrice
    for (; __first != __last; ++__first)
    {
        sx += (R) __first->x;
        sy += (R) __first->y;

        sxy += (R) __first->x * __first->y;

        sx2 += (R) __first->x * __first->x;
        sy2 += (R) __first->y * __first->y;
        size++;
    }

    R A,B,D;
    R e1,e2,e;
    // NOTA: si possono evitare in parte le seguenti divisioni
    sx/=size;
    sy/=size;
    sxy/=size;
    sx2/=size;
    sy2/=size;
    R Sx,Sy,Sxy;
    // Sx a^2 + 2 Sxy a b + Sy b^2
    Sx = sx2 - sx*sx;
    Sy = sy2 - sy*sy;
    Sxy = sxy - sx*sy;
    // sistema del tipo a^2 A - 2 * B * a * b - A * b^2 = 0
    A = Sxy; // Sxy
    B = (Sx - Sy)/2.0; // versione con il meno
    D = std::sqrt( B*B + A*A );

    // le soluzioni sono:
    // a = B+D, b = A
    // a = B-D, b = A
    out.b = A;
    // non si puo' ottimizzare???
    e1 = ( (B + D)*(B + D) * Sx + 2.0 * (B + D) * A * Sxy +  A * A * Sy) / ((B + D)*(B + D) + A * A);
    e2 = ( (B - D)*(B - D) * Sx + 2.0 * (B - D) * A * Sxy +  A * A * Sy) / ((B - D)*(B - D) + A * A);

    if (e1 < e2)
    {
        out.a = B + D;
        e = e1;
    }
    else
    {
        out.a = B - D;
        e = e2;
    }
    // c deve essere tale che la retta passi per il centroide
    out.c = - out.a * sx - out.b * sy;

    return e;
}

}

#endif
