#ifndef _LO_SAC_HXX
#define _LO_SAC_HXX

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file LO_SAC.hxx
 * @author Stefano Cattani (cattani@vislab.it), Paolo Medici (medici@vislab.it),  Paolo Zani (zani@vislab.it)
 * @date 2012-03-17
 */


#include <Processing/SampleConsensus/detail/RandomIndexGenerator.hxx>
#include <Processing/SampleConsensus/Consensus.h>

#include <boost/array.hpp>
#include <boost/bind/bind.hpp>
#include <boost/thread/locks.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/thread/thread.hpp>

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <limits>
#include <utility>
#include <vector>

namespace sample_consensus
{
    namespace detail
    {
        /**
         * Sample and consensus with local optimization (LO-SAC), implementing variants 4 and 5 of the algorithm described in @cite LO-RANSAC03 and its variants.
         *
         **/
        template<typename Loss>
        class LO_SAC
        {
                template<typename Model, typename Estimator, typename Extractor, typename Test>
                struct IterationParams;

            public:

                template<typename Model, typename Estimator, typename Extractor, typename Test>
                ConsensusInfo operator()(Model& model, size_t min_sample, size_t max_sample, const Extractor& extractor, const Estimator& estimator, const Test& test, double max_inliers_error, unsigned int max_opt_iterations, double a, unsigned int max_iterations, unsigned int threads_number)
                {
                    double best_cost = std::numeric_limits<double>::max();
                    size_t best_inliers_num = 0;
                    const double log_1_a = log(1.0 - a);
                    unsigned int current_iteration = 0;
                    unsigned int skipped_iterations = 0;
                    unsigned int k = max_iterations;

                    boost::thread_group thread_group;

                    IterationParams<Model, Estimator, Extractor, Test> iter_params(min_sample, max_sample, max_inliers_error, estimator, test, max_iterations, max_opt_iterations, log_1_a,
                                                                                   model, best_cost, best_inliers_num, current_iteration, skipped_iterations, k, extractor);

                    for(unsigned int t = 0; t < threads_number; ++t)
                        thread_group.create_thread(boost::bind(&LO_SAC::Iterate<Model, Estimator, Extractor, Test>, this, iter_params));

                    thread_group.join_all();

                    ConsensusInfo info;

                    info.m_model_cost = best_cost;
                    info.m_inliers_number = best_inliers_num;
                    info.m_iterations = current_iteration;
                    info.m_skipped_iterations = skipped_iterations;

                    return info;
                }

            private:

                template<typename Model, typename Estimator, typename Extractor, typename Test>
                struct IterationParams
                {
                    IterationParams(size_t min,
                                    size_t max,
                                    double max_inliers_error,
                                    const Estimator& estimator,
                                    const Test& test,
                                    unsigned int max_iterations,
                                    unsigned int max_opt_iterations,
                                    double log_1_a,
                                    Model& best_model,
                                    double& best_cost,
                                    size_t& best_inliers_num,
                                    unsigned int& current_iteration,
                                    unsigned int& skipped_iterations,
                                    unsigned int& k,
                                    const Extractor& extractor) :
                        m_min(min),
                        m_max(max),
                        m_max_inliers_error(max_inliers_error),
                        m_estimator(estimator),
                        m_test(test),
                        m_max_iterations(max_iterations),
                        m_max_opt_iterations(max_opt_iterations),
                        m_log_1_a(log_1_a),
                        m_best_model(best_model),
                        m_best_cost(best_cost),
                        m_best_inliers_num(best_inliers_num),
                        m_current_iteration(current_iteration),
                        m_skipped_iterations(skipped_iterations),
                        m_k(k),
                        m_extractor(extractor)
                    {}

                    size_t m_min;
                    size_t m_max;
                    double m_max_inliers_error;
                    const Estimator m_estimator; //NOTE: we make a copy to guarantee thread safety
                    const Test& m_test;
                    unsigned int m_max_iterations;
                    unsigned int m_max_opt_iterations;
                    double m_log_1_a;
                    Model& m_best_model;
                    double& m_best_cost;
                    size_t& m_best_inliers_num;
                    unsigned int& m_current_iteration;
                    unsigned int& m_skipped_iterations;
                    unsigned int& m_k;
                    const Extractor& m_extractor;
                };

                template<typename Model, typename Estimator, typename Extractor, typename Test>
                void Iterate(IterationParams<Model, Estimator, Extractor, Test>& params)
                {
                    size_t min = params.m_min;
                    size_t max = params.m_max;
                    double max_inliers_error = params.m_max_inliers_error;
                    const Estimator& estimator = params.m_estimator;
                    const Test& test = params.m_test;
                    unsigned int max_iterations = params.m_max_iterations;
                    unsigned int max_opt_iterations = params.m_max_opt_iterations;
                    double log_1_a = params.m_log_1_a;
                    Model& best_model = params.m_best_model;
                    double& best_cost = params.m_best_cost;
                    size_t& best_inliers_num = params.m_best_inliers_num;
                    unsigned int& current_iteration = params.m_current_iteration;
                    unsigned int& skipped_iterations = params.m_skipped_iterations;
                    unsigned int& k = params.m_k;
                    const Extractor& extractor = params.m_extractor;

                    Loss loss(max_inliers_error);
                    RandomIndexGenerator idx_gen(params.m_min, params.m_max);
                    size_t sample_size = estimator.SampleSize();
                    Model current_model;
                    std::vector<typename Extractor::ValueType> current_sample;
                    size_t current_inliers_num = 0;

                    current_sample.reserve(sample_size);

                    do
                    {
                        idx_gen.reset();
                        current_sample.clear();

                        for(size_t i = 0; i < sample_size; ++i)
                            current_sample.push_back(extractor[idx_gen()]);

                        if(estimator.Generate(current_model, current_sample))
                        {
                            current_sample.clear();
                            current_sample.reserve(max - min + 1);
                            current_inliers_num = 0;
                            double current_cost = 0.0;

                            // preliminary test on a subset of the sample
                            idx_gen.reset();

                            if(!test(current_model, estimator, idx_gen, extractor, max_inliers_error))
                            {
                                boost::mutex::scoped_lock l(m_iterations_mtx);

                                ++current_iteration;

                                if(current_iteration > k || current_iteration > max_iterations)
                                    break;
                                else
                                    continue;
                            }

                            for(size_t i = min; i <= max; ++i)
                            {
                                const double current_error = estimator.Evaluate(current_model, extractor[i]);
                                const bool inlier = current_error < max_inliers_error;

                                current_cost += loss(inlier, current_error);

                                if(inlier)
                                    ++current_inliers_num;
                            }

                            bool new_minimum = false;

                            {
                                boost::mutex::scoped_lock l(m_iterations_mtx);

                                new_minimum = current_cost < best_cost;
                            }

                            if(new_minimum && current_inliers_num)
                            {
                                // first we need to recheck the values to fill the current sample with inliers data
                                for(size_t i = min; i <= max; ++i)
                                    if(estimator.Evaluate(current_model, extractor[i]) < max_inliers_error)
                                        current_sample.push_back(extractor[i]);

                                if(current_sample.size() >= estimator.OptimizationSampleSize(current_sample.size())) // local optimization step
                                {
                                    unsigned int lo_current_iteration = 0;
                                    Extractor lo_extractor(current_sample);
                                    RandomIndexGenerator lo_idx_gen(0, current_sample.size() - 1);
                                    size_t lo_sample_size = estimator.OptimizationSampleSize(current_sample.size());
                                    Model lo_current_model = current_model;
                                    std::vector<typename Extractor::ValueType> lo_current_sample;
                                    size_t lo_current_inliers_num = 0;

                                    double lo_best_cost = std::numeric_limits<double>::max();
                                    Model lo_best_model;

                                    lo_current_sample.reserve(lo_sample_size);

                                    do
                                    {
                                        lo_idx_gen.reset();
                                        lo_current_sample.clear();

                                        // we select values among inliers only...
                                        for(size_t i = 0; i < lo_sample_size; ++i)
                                            lo_current_sample.push_back(lo_extractor[lo_idx_gen()]);

                                        if(estimator.Optimize(lo_current_model, lo_current_sample))
                                        {
                                            lo_current_inliers_num = 0;
                                            double lo_current_cost = 0.0;

                                            // ...but we evaluate the error on *ALL* the original data
                                            for(size_t i = min; i <= max; ++i)
                                            {
                                                double current_error = estimator.Evaluate(lo_current_model, extractor[i]);
                                                bool inlier = current_error < max_inliers_error;

                                                lo_current_cost += loss(inlier, current_error);

                                                if(inlier)
                                                    ++lo_current_inliers_num;
                                            }

                                            if((lo_current_cost < lo_best_cost) && lo_current_inliers_num)
                                            {
                                                lo_best_cost = lo_current_cost;
                                                std::swap(lo_best_model, lo_current_model); // current best optimized model replaces the outer model
                                            }
                                        }

                                        ++lo_current_iteration;

                                        if(lo_current_iteration > max_opt_iterations)
                                            break;
                                    } while(1);


                                    if(lo_best_cost < current_cost)
                                    {
                                        current_cost = lo_best_cost;
                                        current_inliers_num = lo_current_inliers_num;
                                        std::swap(current_model, lo_best_model);
                                    }
                                }

                                boost::mutex::scoped_lock l(m_iterations_mtx);

                                if(current_cost < best_cost) // things might have changed due to multithreading, we need to recheck
                                {
                                    best_cost = current_cost;
                                    best_inliers_num = current_inliers_num;

                                    std::swap(best_model, current_model);

                                    // update k
                                    k = log_1_a / log(std::min(1.0 - std::numeric_limits<double>::epsilon(),
                                                            std::max(std::numeric_limits<double>::epsilon(),
                                                                    1.0 - pow(static_cast<double>(current_inliers_num) / (max - min + 1), static_cast<double>(estimator.SampleSize())))));
                                }
                            }

                            boost::mutex::scoped_lock l(m_iterations_mtx);
                            ++current_iteration;

                            if(current_iteration > k || current_iteration > max_iterations)
                                break;
                        }
                        else
                        {
                            boost::mutex::scoped_lock l(m_iterations_mtx);

                            ++skipped_iterations;

                            if(skipped_iterations > max_iterations) // to avoid getting stuck if a valid model cannot be generated
                                break;
                        }
                    } while(1);
                }

                boost::mutex m_iterations_mtx;
        };
    }
}

#endif
