// #ifndef _PIXEL_OPERATIONS_H
// #define _PIXEL_OPERATIONS_H
// 
// #include "TPixelFilter.h"
// 
// namespace cimage {
// 
//    namespace kernel {
// 
// class GammaCorrection 
//     {
//       float m_gamma;
//     public:
//       
//       GammaCorrection(float g = 1.0f) : m_gamma(g) { }
//       
//       void SetGamma(float g) { m_gamma = g; }
//       float GetGamma() const { return m_gamma; }
//       
//       template<class S>
//         inline uint8_t operator()(S inputPixel) const
//         {
// 	  // TODO: inputPixel limits
// 	    int ret = 255.0f * pow(inputPixel/255.0f,1.0f/m_gamma);
//             return (ret > 255 ) ? 255 : ret;
//         }
//   };
//     
// 
// class Invert
//     {
//     public:
//       
//       template<class S>
//         inline S operator()(S inputPixel) const
//         {
//             return ~inputPixel;
//         }
//   };
//       
//   }
//   
//   namespace filter {
//     /// Applica una gamma correction all'immagine
//     typedef TPixelLUTFilter< kernel::GammaCorrection > GammaCorrection;
// 
//     /// Inverte tutti i pixel dell'immagine
//     typedef TPixelFilter< kernel::Invert > Invert;
// 
//   }
// }
// 
// 
// #endif
