#ifndef _LMEDS_H
#define _LMEDS_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file LMedS.h
 * @author Paolo Zani (zani@vislab.it)
 * @date 2012-03-20
 */

#include <Processing/SampleConsensus/detail/EstimatorTraits.hxx>
#include <Processing/SampleConsensus/detail/DataExtractor.hxx>
#include <Processing/SampleConsensus/detail/LMedS.hxx>
#include <Processing/SampleConsensus/Consensus.h>

#include <boost/thread/thread.hpp>

#include <cstddef>
#include <limits>

namespace sample_consensus
{
    /**
    * @ingroup SAC
    * @defgroup LMedS LMedS
    * @brief Least median of squares algorithm
    *
    * It is described in @cite LMedS84.
    * @{
    **/


    /**
     * @brief Computes the model parameters that minimize the median of squared errors over the samples using the supplied estimator.
     *
     * @param [out] model The model with lowest cost.
     * @param [in] samples Input data, containing both inliers and outliers.
     * @param [in] max_inliers_error Max fitting error of inlier samples.
     * @param [in] a Success rate, in the range [0, 1]. Defaults to 0.99.
     * @param [in] max_iterations Max algorithm iterations. Defaults to std::numeric_limits<unsigned int>::max().
     * @param [in] estimator Data analysis class. Defaults to the built-in estimator for the given model.
     * @param [in] threads_number Numer of threads to run in parallel. Defaults to boost::thread::hardware_concurrency().
     * @return Some details about both the model and the selection process.
     **/
    template<typename Model, typename Estimator, template<typename, typename> class Container, typename T, typename Allocator>
    inline ConsensusInfo LMedS(Model& model, const Container<T, Allocator>& samples, double max_inliers_error, double a, unsigned int max_iterations, const Estimator& estimator, unsigned int threads_number = boost::thread::hardware_concurrency())
    {
        detail::LMedS lmeds;
        return lmeds(model, 0, samples.size() - 1, detail::DataExtractor<Container<T, Allocator> >(samples), estimator, max_inliers_error, a, max_iterations, threads_number);
    }

    template<typename Model, typename Estimator, template<typename, typename> class Container, typename T, typename Allocator>
    inline ConsensusInfo LMedS(Model& model, const Container<T, Allocator>& samples, double max_inliers_error, double a = 0.99, unsigned int max_iterations = std::numeric_limits<unsigned int>::max())
    { typename detail::EstimatorTraits<Model>::EstimatorType estimator; return LMedS(model, samples, max_inliers_error, a, max_iterations, estimator); }

    /**
     * @brief Computes the model parameters that minimize the median of squared errors over the samples using the supplied estimator.
     * @note This method automatically determines the inliers threshold, assuming Gaussian noise.
     *
     * @param [out] model The model with lowest cost.
     * @param [out] inliers_error The automatically determined inliers threshold.
     * @param [in] samples Input data, containing both inliers and outliers.
     * @param [in] a Success rate, in the range [0, 1]. Defaults to 0.99.
     * @param [in] max_iterations Max algorithm iterations. Defaults to std::numeric_limits<unsigned int>::max().
     * @param [in] estimator Data analysis class. Defaults to the built-in estimator for the given model.
     * @param [in] threads_number Numer of threads to run in parallel. Defaults to boost::thread::hardware_concurrency().
     * @return Some details about both the model and the selection process.
     **/
    template<typename Model, typename Estimator, template<typename, typename> class Container, typename T, typename Allocator>
    inline ConsensusInfo LMedS(Model& model, double& inliers_error, const Container<T, Allocator>& samples, double a, unsigned int max_iterations, const Estimator& estimator, unsigned int threads_number = boost::thread::hardware_concurrency())
    {
        detail::LMedS lmeds;
        inliers_error = std::numeric_limits<double>::infinity();
        return lmeds(model, 0, samples.size() - 1, detail::DataExtractor<Container<T, Allocator> >(samples), estimator, inliers_error, a, max_iterations, threads_number);
    }

    /** @cond **/
    template<typename Model, typename Estimator, template<typename, typename> class Container, typename T, typename Allocator>
    inline ConsensusInfo LMedS(Model& model, double& inliers_error, const Container<T, Allocator>& samples, double a = 0.99, unsigned int max_iterations = std::numeric_limits<unsigned int>::max())
    { typename detail::EstimatorTraits<Model>::EstimatorType estimator; return LMedS(model, inliers_error, samples, a, max_iterations, estimator); }
    /** @endcond **/


    /**
     * @brief Computes the model parameters that minimize the median of squared errors over the samples using the supplied estimator.
     * @note This method is useful when you want to use indexes rather than the sample values.
     *
     * @param [out] model The model with lowest cost.
     * @param [in] min_sample Minimum input index.
     * @param [in] max_sample Maximum input index.
     * @param [in] max_inliers_error Max fitting error of inlier samples.
     * @param [in] a Success rate, in the range [0, 1].
     * @param [in] max_iterations Max algorithm iterations.
     * @param [in] estimator Data analysis class.
     * @param [in] threads_number Numer of threads to run in parallel. Defaults to boost::thread::hardware_concurrency().
     * @return Some details about both the model and the selection process.
     **/
    template<typename Model, typename Estimator>
    inline ConsensusInfo LMedS(Model& model, size_t min_sample, size_t max_sample, double max_inliers_error, double a, unsigned int max_iterations, const Estimator& estimator, unsigned int threads_number = boost::thread::hardware_concurrency())
    {
        detail::LMedS lmeds;
        return lmeds(model, min_sample, max_sample, detail::DataExtractor<void>(), estimator, max_inliers_error, a, max_iterations, threads_number);
    }

    /**
     * @brief Computes the model parameters that minimize the median of squared errors over the samples using the supplied estimator.
     * @note This method is useful when you want to use indexes rather than the sample values.
     * @note This method automatically determines the inliers threshold, assuming Gaussian noise.
     *
     * @param [out] model The model with lowest cost.
     * @param [out] inliers_error The automatically determined inliers threshold.
     * @param [in] min_sample Minimum input index.
     * @param [in] max_sample Maximum input index.
     * @param [in] a Success rate, in the range [0, 1].
     * @param [in] max_iterations Max algorithm iterations.
     * @param [in] estimator Data analysis class.
     * @param [in] threads_number Numer of threads to run in parallel. Defaults to boost::thread::hardware_concurrency().
     * @return Some details about both the model and the selection process.
     **/
    template<typename Model, typename Estimator>
    inline ConsensusInfo LMedS(Model& model, double& inliers_error, size_t min_sample, size_t max_sample, double a, unsigned int max_iterations, const Estimator& estimator, unsigned int threads_number = boost::thread::hardware_concurrency())
    {
        detail::LMedS lmeds;
        inliers_error = std::numeric_limits<double>::infinity();
        return lmeds(model, min_sample, max_sample, detail::DataExtractor<void>(), estimator, inliers_error, a, max_iterations, threads_number);
    }

    /**@}*/
}

#endif
