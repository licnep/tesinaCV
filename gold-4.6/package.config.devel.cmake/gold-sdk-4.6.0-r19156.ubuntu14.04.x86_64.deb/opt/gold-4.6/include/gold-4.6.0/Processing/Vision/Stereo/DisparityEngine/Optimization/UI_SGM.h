#ifndef _UI_SGM_H
#define _UI_SGM_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2011                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/


/**
 * \file UI_SGM.h
 * \author Paolo Zani (zani@vislab.it)
 * \date 2011-02-16
 */

#include <Processing/Vision/Stereo/DisparityEngine/Optimization/SGM.h>

#include <UI/Panel/Panel.h>

#include <cmath>

namespace disparity
{
    // forward declarations

    namespace opt
    {
        template<typename ResultType_Agg, uint32_t Threads_Agg, typename ResultType_Opt, typename Impl_Opt, uint32_t Threads_Opt> class SGM;
    }

    template<typename Aggregation, typename Engine>
    class UI_Optimization;

    template<typename ResultType_Agg, uint32_t Threads_Agg, typename ResultType_Opt, typename Impl_Opt, uint32_t Threads_Opt, typename Engine>
    class UI_Optimization<opt::SGM<ResultType_Agg, Threads_Agg, ResultType_Opt, Impl_Opt, Threads_Opt>, Engine>
    {
        public:
        
            UI_Optimization(Engine* _this) : m_this(_this) {}
            
            void Init(INIFile* pIni)
            {
                ui::var::Range<ResultType_Agg> p1(&m_this->P1, 0, 255, 1);
                ui::var::Range<ResultType_Agg> p2(&m_this->P2, 0, 255, 1);
                ui::var::Value<bool> crosswisePath(&m_this->m_enableCrosswisePath);
                ui::var::Value<bool> despeckle(&m_this->m_enableDespeckleFilter);
                ui::var::Value<bool> gap(&m_this->m_enableGapFilter);
                ui::var::Value<bool> adapmean(&m_this->m_enableAdaptiveMeanFilter);
                ui::var::Value<bool> median(&m_this->m_enableMedianFilter);
                
                ui::var::Range<float> speckle_sim_threshold(&m_this->m_cluster_threshold, 0, 10, 0.1);
                ui::var::Range<float> uniqueness_threshold(&m_this->m_uniqueness_threshold, 0.5f, 1.0f, 0.01f);
                ui::var::Range<unsigned int> min_speckle_segment_size(&m_this->m_min_cluster_size, 0, 500, 1);
                ui::var::Range<unsigned int> min_element(&m_this->m_min_element, 0, 50, 1);
                 

                ui::conf::Configuration conf(pIni);

                conf.Bind(p1, "P1", (ResultType_Agg) (1 * pow(10, sizeof(ResultType_Agg))));
                conf.Bind(p2, "P2", (ResultType_Agg) (5 * pow(10, sizeof(ResultType_Agg))));
                conf.Bind(crosswisePath, "CROSSWISE PATH", true);
                conf.Bind(despeckle, "DESPECKLE", true);
                conf.Bind(speckle_sim_threshold, "SPECKLE SIM THRESHOLD", 1.0f);
                conf.Bind(uniqueness_threshold, "UNIQUENESS THRESHOLD", 0.9f);
                conf.Bind(min_element, "MIN ELEMENT", 16U);
                conf.Bind(min_speckle_segment_size, "MIN SPECKLE SEGMENT SIZE", 100U);               
                conf.Bind(gap, "GAP", true);
                conf.Bind(adapmean, "ADAPTIVE MEAN", true);
                conf.Bind(median, "MEDIAN", false);
                m_panel
                (
                    ui::wgt::VSizer()
                    (
                        ui::wgt::CheckBox(crosswisePath, "Enable Crosswise Path").Border(3),                       
                        ui::wgt::CheckBox(adapmean, "Enable Adaptive Mean").Border(3),
                        ui::wgt::CheckBox(median, "Enable Median").Border(3),
                        ui::wgt::CheckBox(despeckle, "Despeckle").Border(3),
                        ui::wgt::CheckBox(gap, "Enable Gap").Border(3),
//                         ui::wgt::Slider(uniqueness_threshold, "Uniqueness Threshold").Border(3),
//                         ui::wgt::Slider(min_speckle_segment_size, "Min Cluster Area").Border(3),
//                         ui::wgt::Slider(speckle_sim_threshold, "Cluster Similarity Threshold").Border(3),
                        ui::wgt::GridSizer().Border(3)
                        (
                            ui::wgt::SzCell(0, 0)( ui::wgt::Text("P1") ), ui::wgt::SzCell(0, 1).HExpand()( ui::wgt::Slider(p1) ),
                            ui::wgt::SzCell(1, 0)( ui::wgt::Text("P2") ), ui::wgt::SzCell(1, 1).HExpand()( ui::wgt::Slider(p2) ),
                            ui::wgt::SzCell(2, 0)( ui::wgt::Text("Uniqueness Threshold") ), ui::wgt::SzCell(2, 1).HExpand()( ui::wgt::Slider(uniqueness_threshold) ),
                            ui::wgt::SzCell(3, 0)( ui::wgt::Text("Min Element") ), ui::wgt::SzCell(3, 1).HExpand()( ui::wgt::Slider(min_element) ),
                            ui::wgt::SzCell(4, 0)( ui::wgt::Text("Min Cluster Area") ), ui::wgt::SzCell(4, 1).HExpand()( ui::wgt::Slider(min_speckle_segment_size) ),
                            ui::wgt::SzCell(5, 0)( ui::wgt::Text("Cluster Similarity Threshold") ), ui::wgt::SzCell(5, 1).HExpand()( ui::wgt::Slider(speckle_sim_threshold) )
                        )
                   )    
                );
            }

            inline std::string Name() { return "SGM"; }

            inline ui::wgt::Widget Panel() { return m_panel; }
            
        private:
            
            Engine* m_this;
            ui::wgt::VSizer m_panel;
    };
}

#endif
