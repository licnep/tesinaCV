#ifndef _SGM_IMPL_CPP_H
#define _SGM_IMPL_CPP_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/


/**
 * \file Impl_Cpp.h
 * \brief Semi-global matching optimization
 * \author Mirko Felisa <felisa@vislab.it>
 * \date 2010-10-18
 **/

#include <Libs/Threads/Parallelize.h>
#include <Processing/Vision/Stereo/DisparityEngine/Common/DisparityEngineData.h>
#include <Processing/Vision/Stereo/DisparityEngine/Filter/Smoothing.h>
#include <Processing/Vision/Stereo/DisparityEngine/Filter/Clustering.h>
#include <Processing/Vision/Stereo/DisparityEngine/Optimization/SGM/PathAccumulation.h>
#include <Processing/Vision/Stereo/DisparityEngine/Optimization/SGM/LRConsistencyCheckLoop.h>
#include <Processing/Vision/CImage/BasicOperations/BasicOperations.h>

#include <boost/thread/barrier.hpp>
#include <stdint.h>
#include <limits>
#include <cmath>
#include <cstdlib>

namespace disparity
{
    namespace impl
    {
        class Cpp;
        class SIMD;
        class Auto;
    }

    namespace opt
    {
        template<typename ResultType_Agg, uint32_t Threads_Agg, typename ResultType_Opt, typename Impl_Opt, uint32_t Threads_Opt> class SGM;

        template<typename ResultType_Agg, uint32_t Threads_Agg, typename ResultType_Opt, uint32_t _Threads_Opt>

        class SGM<ResultType_Agg, Threads_Agg, ResultType_Opt, impl::Cpp, _Threads_Opt> : private virtual DisparityEngineData
        {
            public:
            
                ResultType_Agg P1;
                ResultType_Agg P2;
                float m_cluster_threshold;
                unsigned int m_min_cluster_size;
                float m_uniqueness_threshold;
                unsigned int m_min_element;

            protected:
              

                typedef SGM<ResultType_Agg, Threads_Agg, ResultType_Opt, impl::Cpp, _Threads_Opt> SGMType;

                static const uint32_t Threads_Opt = _Threads_Opt;

                SGM<ResultType_Agg, Threads_Agg, ResultType_Opt, impl::Cpp, _Threads_Opt>() :  m_disparityCubeSize(0), m_disparityInputCube(0), m_disparityOutputCube(0), 
                                                                                               m_barrier(_Threads_Opt), m_enableCrosswisePath(true), m_enableDespeckleFilter(true),
                                                                                               m_enableGapFilter(true), m_enableAdaptiveMeanFilter(true), m_enableMedianFilter(false)
                {
                     P1 = 1 * pow(10, sizeof(ResultType_Agg));
                     P2 = 5 * pow(10, sizeof(ResultType_Agg));
                     m_cluster_threshold = 1; 
                     m_min_cluster_size = 50;
                     m_uniqueness_threshold = 0.9;
                     m_min_element = 16;
                }     

                ~SGM<ResultType_Agg, Threads_Agg, ResultType_Opt, impl::Cpp, _Threads_Opt>()
                {
                    free(m_disparityInputCube);
                    free(m_disparityOutputCube);
                }

                void Init(int correlScaleFactor)
                {
                    m_pDsi = m_dsi->Buffer();
                    m_pScore = m_score->Buffer();
                    m_width = m_dsi->W();
                    m_height = m_dsi->H();

                    Resize(m_rawDsi, m_width, m_height);

                    m_max_disparity = m_dispMax - m_dispMin + 1;

                    int width = m_dsiXMax - m_dsiXMin;
                    int height = m_dsiYMax - m_dsiYMin;

                    int size = width * height * m_max_disparity;

                    if(size > m_disparityCubeSize) {

                        m_disparityCubeSize = size;
                        m_disparityInputCube  = (ResultType_Agg*)realloc(m_disparityInputCube, size * sizeof(ResultType_Agg));
                        m_disparityOutputCube = (ResultType_Opt*)realloc(m_disparityOutputCube, size * sizeof(ResultType_Opt));
                    }
                    
                    int sum = 0;

                    for(int j = 0; j < width; j++)
                        sum += std::min(height, width - j);

                    sum /= _Threads_Opt;  

                    int acc = 0, i = 1, th = sum;

                    m_threadRangeHor[0] = 0;

                    for(int j = 0; j < width; j++) {
                        
                        acc += std::min (height, width - j);

                        if(acc > th) {

                           m_threadRangeHor[i++] = j; 
                           th = sum * i;
                        }   
                    }

                    m_threadRangeHor[_Threads_Opt] =  width;

                    sum = 0;

                    for(int i = 1; i < height; i++)
                        sum += std::min(height - 1 - i, width - 1);

                    sum /= _Threads_Opt;

                    int j = 1;

                    acc = 0; 
                    th = sum;
                    m_threadRangeVer[0] = 0;

                    for(int i = 1; i < height; i++) {

                        acc += std::min(height - 1 - i, width - 1);

                        if(acc > th) {

                           m_threadRangeVer[j++] = i;
                           th = j * sum;
                        }   
                    }
                    
                    m_threadRangeVer[_Threads_Opt] =  height - 1;
                }

                void Finalize() { Parallelize(boost::bind(&SGMType::ComputeSGM, this, _1, _2), _Threads_Opt); }

                inline void Store(Disparity d, Score s, uint32_t x, uint32_t y, uint32_t stripe)
                {
                    int index = ((y - m_dsiYMin) * (m_dsiXMax - m_dsiXMin) + x - m_dsiXMin) * m_max_disparity;
                    std::fill(m_disparityInputCube + index, m_disparityInputCube + index + m_max_disparity, std::numeric_limits<ResultType_Agg>::max());
                }

                inline void Store(const ResultType_Agg* pCorr, uint32_t x, uint32_t y, int d_min, int d_max, uint32_t stripe)
                {
                    int index = ((y - m_dsiYMin) * (m_dsiXMax - m_dsiXMin) + x - m_dsiXMin) * m_max_disparity;

                    ResultType_Agg* disparityInputCube = m_disparityInputCube - m_dispMin;

                    std::copy(pCorr + d_min,  pCorr + d_max + 1, disparityInputCube + index + d_min);

                    for(int i = m_dispMin; i < d_min; ++i)
                        m_disparityInputCube[index + i] = std::numeric_limits<ResultType_Agg>::max();

                    for(int i = d_max + 1; i <  m_max_disparity + m_dispMin; ++i)
                        m_disparityInputCube[index + i] = std::numeric_limits<ResultType_Agg>::max();
                }

                inline void ComputeSGM(uint32_t threadID, uint32_t threadNum)
                {
                    ResultType_Agg path[m_max_disparity];
                    
                    const int width = m_dsiXMax - m_dsiXMin;
                    const int height = m_dsiYMax - m_dsiYMin;

                    int size =  width * height * m_max_disparity;
                    int32_t k0 = (threadID * size) / threadNum;
                    int32_t k1 = ((threadID + 1) * size) / threadNum;
                    std::fill(m_disparityOutputCube + k0,  m_disparityOutputCube +  k1, 0);

                    m_barrier.wait(); // needed for the parallel fill


                    int32_t k4 = (threadID * width) / threadNum;
                    int32_t k5 = ((threadID + 1) * width) / threadNum;

                    const int stride = m_max_disparity * width;

                    for(int j = k4; j < k5; j++) {

                        int index =  j * m_max_disparity;
                        PathAccumulation0(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity);

                        index += stride;
                        for(int32_t i = 1; i < height; i++, index += stride)
                            PathAccumulation(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity, P1, P2);

                        index -= stride;
                        PathAccumulation0(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity);

                        index -= stride;
                        for(int32_t i = 1; i < height; i++, index -= stride)
                            PathAccumulation(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity, P1, P2);
                    }

                    m_barrier.wait();

                    if (m_enableCrosswisePath)
                    { 
                    const int stride2 = m_max_disparity * width + m_max_disparity;
                    const int32_t k12 = m_threadRangeHor[threadID];
                    const int32_t k13 = m_threadRangeHor[threadID + 1];

                    for(int j = k12; j < k13; j++) {

                        int index =  j * m_max_disparity;
                        PathAccumulation0(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity);

                        index += stride2;
                        int size = std::min(height - 1, width - 1 - j);

                        for(int i = 0; i < size; i++, index += stride2)
                            PathAccumulation(m_disparityOutputCube + index, m_disparityInputCube + index,  path, m_max_disparity, P1, P2);

                        index -= stride2;
                        PathAccumulation0(m_disparityOutputCube + index, m_disparityInputCube + index,  path, m_max_disparity);

                        index -= stride2;
                        for(int i = 0; i < size; i++, index -= stride2)
                            PathAccumulation(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity, P1, P2);
                    }

                    const int32_t k6 = m_threadRangeVer[threadID] + 1;
                    const int32_t k7 = m_threadRangeVer[threadID + 1] + 1;

                    for(int i = k6; i < k7; i++) {

                        int index = i * width * m_max_disparity;
                        PathAccumulation0(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity);

                        index += stride2;
                        int size = std::min(height - 1 - i, width - 1);

                        for(int j = 0; j < size; j++, index += stride2)
                            PathAccumulation(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity, P1, P2);

                        index -= stride2;
                        PathAccumulation0(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity);

                        index -= stride2;
                        for(int j = 0; j < size; j++, index -= stride2)
                            PathAccumulation(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity, P1, P2);
                    }

                    m_barrier.wait();

                    const int stride3 = -m_max_disparity * width + m_max_disparity;

                    for(int j = k12; j < k13; j++) {

                        int index = ((height - 1) * width + j) * m_max_disparity;
                        PathAccumulation0(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity);

                        index += stride3;
                        int size = std::min(height - 1, width - 1 - j);

                        for(int i = 0; i < size; i++, index += stride3)
                            PathAccumulation(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity, P1, P2);

                        index -= stride3;
                        PathAccumulation0(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity);

                        index -= stride3;
                        for(int i = 0; i < size; i++, index -= stride3)
                            PathAccumulation(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity, P1, P2);
                    }

                    const int32_t k8 = height - 1 - m_threadRangeVer[threadID + 1];
                    const int32_t k9 = height - 1 - m_threadRangeVer[threadID];

                    for(int i = k8; i < k9; i++) {

                        int index = i * width * m_max_disparity;
                        PathAccumulation0(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity);

                        index += stride3;
                        int size = std::min(i , width - 1);

                        for(int j = 0; j <  size; j++, index += stride3)
                            PathAccumulation(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity, P1, P2);

                        index -= stride3;
                        PathAccumulation0(m_disparityOutputCube + index, m_disparityInputCube + index,  path, m_max_disparity);

                        index -= stride3;
                        for(int j = 0; j < size; j++, index -= stride3)
                            PathAccumulation(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity, P1, P2);
                    }

                    m_barrier.wait();
                    }
                    
                    
                    int32_t k2 = (threadID * height) / threadNum;
                    int32_t k3 = ((threadID + 1) * height) / threadNum;

                    for(int i = k2; i < k3; i++) {

                        int index = i * width * m_max_disparity;
                        PathAccumulation0 (m_disparityOutputCube + index, m_disparityInputCube + index,  path, m_max_disparity);

                        index += m_max_disparity;
                        for(int32_t j = 1; j <  width; j++, index += m_max_disparity)
                            PathAccumulation(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity, P1, P2);

                        index -= m_max_disparity;
                        PathAccumulation0(m_disparityOutputCube + index, m_disparityInputCube + index,  path, m_max_disparity);

                        index -= m_max_disparity;
                        for(int32_t j = 1; j < width; j++, index -= m_max_disparity)
                            PathAccumulation(m_disparityOutputCube + index, m_disparityInputCube + index, path, m_max_disparity, P1, P2);
                    }

                   // m_barrier.wait();
                    
                    
                    float* pDisp = (float*)m_pDsi;
                    DECLSPEC_ALIGN(16) ResultType_Opt diag[m_max_disparity + m_downsample_ratio*width];
                    invratio = 1.0f / m_downsample_ratio; ///FIXME: dichiarare la variabile   locale  porta a risultati errati x d=63
                    
                    for(int i = k2; i < k3; i++)
                    {

                      ResultType_Opt * disparityOutputCube = m_disparityOutputCube + i * width * m_max_disparity;
                        
                      std::fill(diag, diag + m_max_disparity + m_downsample_ratio*width, std::numeric_limits<ResultType_Opt>::max() );             
                      for(int j = 0, stride = 0; j < m_downsample_ratio*width; j+=m_downsample_ratio, stride += m_max_disparity)
                         for(int k = 0; k < m_max_disparity ; k++)
                             diag[j+k] = std::min(diag[j+k], *(disparityOutputCube + stride +k));

                        int stride1 = (i + m_dsiYMin ) * m_width + m_dsiXMin;
                        for(int j = 0; j < width - (int)m_min_element; j++, disparityOutputCube += m_max_disparity) 
                        {
                            int index2 = stride1 + j;
                            int k = 0;
                            ResultType_Opt min = std::numeric_limits<ResultType_Opt>::max();
                            for(int d = 0;  d < m_max_disparity; d++)                                
                                if(disparityOutputCube[d] < min) {
                                    min = disparityOutputCube[d];
                                    k = d;
                                }
                               
//                             
                            ResultType_Opt second_min = std::numeric_limits<ResultType_Opt>::max();
                            for(int d = 0;  d < m_max_disparity; d++)                                
                                if(disparityOutputCube[d] < second_min && std::abs(k-d)>1) 
                                  second_min = disparityOutputCube[d];

                            
                            float disparity = DISPARITY_UNKNOWN;
                            if( second_min * m_uniqueness_threshold >= disparityOutputCube[k] )
                            {  
                                disparity = k;

                                if((k > 0) && (k < m_max_disparity - 1))
                                {

                                  int y0 = disparityOutputCube[k - 1];
                                  int y2 = disparityOutputCube[k + 1];
#ifdef USE_EQUIANGULAR_SUBPIXEL                                
                                  float y1 = (Disparity)(2 * (std::max(y0, y2) - (int) disparityOutputCube[k]));
#else                                
                                  float y1 = (Disparity)(2 * (y0 + y2 - 2 * (int)disparityOutputCube[k]));
#endif                                
                                    
                                  if(y1)
                                      disparity += ((y0 - y2) / y1);
                                }
                                
                                int disp = lrintf(disparity);
                                            
                                ResultType_Opt cost = disparityOutputCube[disp];                           
                                
                                ResultType_Opt min_cost = diag[m_downsample_ratio*j + disp];
                                                            
                                if((cost == min_cost) || (j && min_cost == disparityOutputCube[disp - (m_max_disparity - m_downsample_ratio)]) || 
                                            (j != width - 1 && min_cost == disparityOutputCube[disp + (m_max_disparity - m_downsample_ratio)]))
                                  disparity = (disparity + m_dispMin) * invratio;                    
                                else
                                  disparity = DISPARITY_UNKNOWN;
                            } 
                            
                            pDisp[index2] = disparity;
                        }
                        std::fill(pDisp+stride1 + width - m_min_element, pDisp+stride1 + width, DISPARITY_UNKNOWN);
                    }
                    
                    
                   m_barrier.wait();
                    

                  if(m_enableMedianFilter)
                    MedianFilter(*m_dsi,  m_rawDsi, m_barrier, m_dsiXMin, m_dsiXMax, m_dsiYMin, m_dsiYMax, threadID, threadNum );
                  
                  if(m_enableAdaptiveMeanFilter)
                    AdaptiveMeanFilter(*m_dsi,  m_rawDsi, m_barrier, m_dsiXMin, m_dsiXMax, m_dsiYMin, m_dsiYMax, threadID, threadNum );

                  if(m_enableDespeckleFilter)
                    DespeckleFilter(*m_dsi, m_barrier, m_dsiXMin, m_dsiXMax, m_dsiYMin, m_dsiYMax, m_cluster_threshold,  m_min_cluster_size, threadID, threadNum );
                                     
                  if(m_enableGapFilter)
                    GapFilter(*m_dsi, m_barrier, m_dsiXMin, m_dsiXMax, m_dsiYMin, m_dsiYMax, threadID, threadNum );

                }

                uint32_t m_width;
                uint32_t m_height;
                Disparity* m_pDsi;
                Score* m_pScore;
                int m_disparityCubeSize;
                ResultType_Agg * m_disparityInputCube;
                ResultType_Opt * m_disparityOutputCube;
                int m_max_disparity;
                boost::barrier m_barrier;
                float invratio;
                CDespeckleFilter<_Threads_Opt> DespeckleFilter;
                CDSI m_rawDsi;
                int m_threadRangeHor[_Threads_Opt + 1];
                int m_threadRangeVer[_Threads_Opt + 1];
        public:       
                bool m_enableCrosswisePath; 
                bool m_enableDespeckleFilter;
                bool m_enableGapFilter;
                bool m_enableAdaptiveMeanFilter;
                bool m_enableMedianFilter;
        };
    }
}

#endif
