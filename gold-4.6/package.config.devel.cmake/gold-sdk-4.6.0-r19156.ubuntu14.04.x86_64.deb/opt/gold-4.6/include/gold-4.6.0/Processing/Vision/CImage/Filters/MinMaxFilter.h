#ifndef _MINMAX_FILTER_H
#define _MINMAX_FILTER_H

/** @file MinMaxFilter.h
  * @brief this header containes Minimum (Erode), Maximum (Dilate) and Non-Maxima Suppresion filter. */

#include <stdint.h>

#include <Processing/Vision/CImage/Filters/TLocalFilter.h>
#include <Processing/Vision/CImage/Filters/BaseFilter.h>
#include <Processing/Vision/CImage/Filters/FilterModifier.h>


namespace cimage {

namespace kernel {  
  
/** \brief filtro che ritorna il minimo (Erode) della funzione in un intorno WxH
* Filtro Erosione
* \code
* TLocalFilter< kernel::TMinFilter<3,3> > filter;
* filter(m_inputImageMono, m_outputImageMono);
* \endcode
*/
template<typename SizePolicy>
class MinFilter: public SizePolicy, public filter::ImplPixelOperator
    {
    public:
    // unbiased filter
    static const int bias = 0; 
    // do not change sign
    static const bool positive = true;
    // do not alter energy
    static const unsigned int magnitude = 1;    
      
    public:

	template<class D>
        inline D zero() const { return 0; }
	template<class S>
        inline S operator()(const S* inputPixel, long stride) const
        {
            S comp = inputPixel[0];
            const int32_t win_w = SizePolicy::GetWidth();
            const int32_t win_h =  SizePolicy::GetHeight();
            for (int32_t j = - win_h / 2; j <= (win_h - 1) / 2; j++)
            {  
               const S* pixel_row = inputPixel + stride * j;
               for (int32_t i= - win_w / 2; i <= (win_w - 1) / 2; i++)
                  if(pixel_row[i] < comp)
                      comp = pixel_row[i];
            }
            return comp;
        }
  };

/** \brief filtro che ritorna il massimo (Dilate) dell'immagine in un intorno WxH
 *  Filtro Espansione
 * \code
 * TLocalFilter< kernel::MaxFilter< policy::FixedSize<3,3> > > filter;
 * filter(m_inputImageMono, m_outputImageMono);
 * \endcode
 */
template<typename SizePolicy>
class MaxFilter: public SizePolicy, public filter::ImplPixelOperator
    {
    public:
    // unbiased filter
    static const int bias = 0; 
    // do not change sign
    static const bool positive = true;
    // do not alter energy
    static const unsigned int magnitude = 1;    
      
    public:

	template<class D>
        inline D zero() const { return 0; }
	template<class S>
        inline S operator()(const S* inputPixel, long stride) const
        {
            S comp = inputPixel[0];
            const int32_t win_w = SizePolicy::GetWidth();
            const int32_t win_h =  SizePolicy::GetHeight();
            for (int32_t j = - win_h / 2; j <= (win_h - 1) / 2; j++)
            {  
               const S* pixel_row = inputPixel + stride * j;
               for (int32_t i= - win_w / 2; i <= (win_w - 1) / 2; i++)
                  if(pixel_row[i] > comp)
                      comp = pixel_row[i];
            }
            return comp;
        }
  };
  
  
/** \brief filtro che applica la Non-Maximum Suppression su un interno WxH
 *  Filtro Espansione
 * \code
 * TLocalFilter< kernel::NonMaximumSuppression<policy::FixedSize<3,3> > > filter;
 * filter(m_inputImageMono, m_outputImageMono);
 * \endcode
 */
template<class SizePolicy>
class NonMaximumSuppression : public SizePolicy, public filter::ImplPixelOperator
    {
    public:

	template<class D>
        inline D zero() const { return 0; }
	template<class S>
        inline S operator()(const S* inputPixel, long stride) const
        {
            S comp = inputPixel[0];
            const int32_t win_w = SizePolicy::GetWidth();
            const int32_t win_h =  SizePolicy::GetHeight();
            for (int32_t j = - win_h / 2; j <= (win_h - 1) / 2; j++)
            {  
               const S* pixel_row = inputPixel + stride * j;
               for (int32_t i= - win_w / 2; i <= (win_w - 1) / 2; i++)
                   if(pixel_row[i] > inputPixel[0] && i!=0 && j!=0) // maggiore stretto
                        return  S(0);
            }
            

            return inputPixel[0];
        }
  };
  
  
  typedef kernel::MinFilter< policy::FixedSize<3,3> > MinFilter3x3;
  typedef kernel::MinFilter< policy::FixedSize<5,5> > MinFilter5x5;

  typedef kernel::MaxFilter< policy::FixedSize<3,3> > MaxFilter3x3;
  typedef kernel::MaxFilter< policy::FixedSize<5,5> > MaxFilter5x5;

  typedef kernel::NonMaximumSuppression< policy::FixedSize<3,3> > NonMaximumSuppression3x3;
  typedef kernel::NonMaximumSuppression< policy::FixedSize<5,5> > NonMaximumSuppression5x5;
  
} // kernel Namespace


#include <Processing/Vision/CImage/Filters/MinMaxFilter.hxx>

// filtro
namespace filter {

  typedef TLocalFilter< kernel::MinFilter3x3 > MinFilter3x3;
  typedef TLocalFilter< kernel::MinFilter5x5 > MinFilter5x5;

  typedef TLocalFilter< kernel::MaxFilter3x3 > MaxFilter3x3;
  typedef TLocalFilter< kernel::MaxFilter5x5 > MaxFilter5x5;

  typedef TLocalFilter< kernel::NonMaximumSuppression3x3 > NonMaximumSuppression3x3;
  typedef TLocalFilter< kernel::NonMaximumSuppression5x5 > NonMaximumSuppression5x5;
  
}

} // namespace cimage

#endif
