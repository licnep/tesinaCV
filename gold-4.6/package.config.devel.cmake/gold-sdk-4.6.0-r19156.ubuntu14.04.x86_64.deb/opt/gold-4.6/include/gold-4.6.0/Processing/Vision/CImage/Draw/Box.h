#ifndef _DRAW_BOX_H
#define _DRAW_BOX_H

/** @file Box.h
 *  @brief API to draw rects and boxes on images
 * */

#include <Data/Math/Rects.h>
#include <Data/Math/Points.h>

namespace draw {

/** \ingroup Draw 
  *  Draw a filled box
  * \code
  * draw::Box( draw::Opaque<unsigned char>(buffer, 128,128, 0), 10,10, 40, 40);
  * \endcode
  * @todo aggiungere una politica per il clipping
  * @see draw::Opaque
  * @see draw::Fill
  */
template <class _Brush>
void Box(_Brush f, int x0, int y0, int x1, int y1)
  {
    if(x0<0)      x0=0;
    if(y0<0)      y0=0;
    if(x1> f.W())      x1 = f.W();
    if(y1 > f.H())      y1 = f.H();
  for (int j = y0; j <= y1; j++)
      f.FillLine(x0, x1, j);
  }

/** \ingroup Draw 
  * Draw a filled rectangle on the image
  * 
  * @param patch A bounding box
  * \code
  * draw::Box( draw::Opaque<unsigned char>(buffer, 128,128, 0), rect);
  * \endcode
  */
template <class _Brush, class _Rect>
void Box(_Brush f, const _Rect & patch)
  {
    Box<_Brush>(f, patch.top(), patch.left(), patch.right(), patch.bottom());
  }


/** \ingroup Draw 
  * Applies a frame rectangular patch to the image
  * @param patch A bounding box
  */
template <class _Brush, class _Rect>
void Rectangle(_Brush f, const _Rect & patch)
  {
  f.FillLine((int) patch.left(), (int) patch.right(), patch.top());
  
  for (int j = (int) patch.top(); j < (int) patch.bottom()-1; j++)
  {
      f.FillPixel((int) patch.left(), j);
      f.FillPixel((int) patch.right()-1, j);
  }
  f.FillLine((int) patch.left(), (int) patch.right(), patch.bottom()-1);
  }

}

#endif
