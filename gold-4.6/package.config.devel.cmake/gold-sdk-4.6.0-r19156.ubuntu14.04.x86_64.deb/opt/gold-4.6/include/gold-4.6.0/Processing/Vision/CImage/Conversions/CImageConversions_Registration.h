#ifndef _CIMAGECONVERTERREGISTER_H
#define _CIMAGECONVERTERREGISTER_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/

/**
 * \file CImageConversion_Registration.h
 * \author Paolo Grisleri (grisleri@ce.unipr.it), Paolo Zani (zani@ce.unipr.it)
 * \date 2006-05-10
 */

#include <Processing/Vision/CImage/Functions_Registration.h>

/**
 * @note
 * to add global support for a conversion operator acting on a CImage whose actual type
 * is, say, CImageDummy, you would do the following:
 * \code
 *
 * CImageDummy : public TImage <...> { ... }
 *
 * CImageDummy& operator >> (const CImageDummy& src, CImageRGB8& dst) { ... };
 * namespace cimage
 * {
 *   CIMAGE__REGISTER_CONVERSION(CImageDummy, CImageRGB8);
 *  }
 *
 * \endcode
 */
namespace cimage
{
  class ConversionRegister :
    public OperatorRegister< ConversionRegister > {};
}

#define CIMAGE__REGISTER_CONVERSION( M, N ) \
    static bool _gtgt_##M##N = \
      ConversionRegister::Instance().Register<const M, N > ( operator >> )

#endif
