#ifndef _DISPARITYENGINE_SIMPLE_IMPL_H
#define _DISPARITYENGINE_SIMPLE_IMPL_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file Core_Cpp.h
 * \author Paolo Zani (zani@vislab.it) Mirko Felisa (felisa@vislab.it)
 * \date 2008-12-04
 */

#include <Processing/Vision/Stereo/Images/CDSI.h>
#include <Processing/Vision/Stereo/Images/CScoreImage.h>
#include <Processing/Vision/Stereo/DisparityEngine/Common/SearchRange.h>
#include <Processing/Vision/Stereo/DisparityEngine/Common/DisparityEngineData.h>
#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/Window/Params.h>
#include <Processing/Vision/Stereo/DisparityEngine/Common/PixelFunctions.h>

#include <Data/CImage/PixelTraits/PixelTraits.h>
#include <Libs/Threads/Parallelize.h>

#include <stdint.h>
#include <cstdlib>

// #define __DEBUG__

#include <iostream>

#ifdef __DEBUG__
#define __log_debug  std::cout << "[DB] DisparityEngine/Aggregation/Window/Core_Cpp.h "  << __LINE__ << " "
#else
#define __log_debug  while(0) std::cout
#endif

namespace disparity
{
    // forward declarations
    
    namespace agg
    {
        template<typename ResultType_Cost, typename _ResultType_Agg, typename Impl_Agg, uint32_t _Threads_Agg>
        class Window_Simple;
    }

    namespace impl
    {
        class Auto;
        class Cpp;
    }

    template<typename Cost, typename Aggregation, typename Optimization>
    class Core;

    // actual specialization
    
    template<typename Cost, typename Optimization, typename ResultType_Cost, typename ResultType_Agg, uint32_t Threads_Agg>
    class Core<Cost, agg::Window_Simple<ResultType_Cost, ResultType_Agg, impl::Auto, Threads_Agg>, Optimization> : public Core<Cost, agg::Window_Simple<ResultType_Cost, ResultType_Agg, impl::Cpp, Threads_Agg>, Optimization> {};
    
    template<typename Cost, typename Optimization, typename ResultType_Cost, typename _ResultType_Agg, uint32_t _Threads_Agg>
    class Core<Cost, agg::Window_Simple<ResultType_Cost, _ResultType_Agg, impl::Cpp, _Threads_Agg>, Optimization> : public Optimization, public WindowParams, private virtual DisparityEngineData
    {
        public:

            typedef Cost CostType;
            typedef _ResultType_Agg ResultType_Agg;
            typedef agg::Window_Simple<ResultType_Cost, ResultType_Agg, impl::Cpp, _Threads_Agg> AggregationType;
            typedef Optimization OptimizationType;
            typedef Core<Cost, AggregationType, Optimization> CoreType;

            static const uint32_t Threads_Agg = _Threads_Agg;
            
        protected:

            Core() : m_maxDisparityRangeSize(0), m_textureSize(0), m_pTextureImage(NULL)
            {
                for(uint32_t i = 0; i < Threads_Agg; ++i)
                    m_pCorrel__Buffer[i] = NULL;
            }

            ~Core()
            {
                free(m_pTextureImage);

                for(uint32_t i = 0; i < Threads_Agg; ++i)
                    free(m_pCorrel__Buffer[i]);
            }
            
            inline void SetDimensions(uint32_t& width, uint32_t& height){}

            template<typename T>
            inline void Run(const cimage::TImage<T>& left, const cimage::TImage<T>& right, const cimage::CImageMono8& mask)
            {
                Optimization::Init(m_winWidth * m_winHeight);

                uint32_t width = m_dsi->W();
                uint32_t height = m_dsi->H();
                m_pMask = mask.Area() ? mask.Buffer() : NULL;

                int sum = 0;
                for ( unsigned int i = m_dsiYMin; i < m_dsiYMax; ++i )
                    sum += std::max ( m_searchRanges[i].second - m_searchRanges[i].first + 1, 1 );
                sum/=Threads_Agg;
                      
                m_threadRange[0] = m_dsiYMin;
                int acc = 0, th = sum, j = 1;
                 for ( unsigned int i = m_dsiYMin; i < m_dsiYMax; ++i )
                {    
                    acc += std::max ( m_searchRanges[i].second - m_searchRanges[i].first + 1, 1 );
                    if (acc > th)
                    {    
                       m_threadRange[j++] = i;
                       th = j * sum;
                    }   
                }
                m_threadRange[Threads_Agg] = m_dsiYMax;

                int maxDisparityRangeSize = m_dispMax - m_dispMin + 1;

                if(maxDisparityRangeSize > m_maxDisparityRangeSize) {

                    m_maxDisparityRangeSize = maxDisparityRangeSize;

                    __log_debug << "Reallocating correlation buffers (m_maxDisparityRangeSize = " << m_maxDisparityRangeSize <<")" << std::endl;

                    for(uint32_t i = 0; i < Threads_Agg; ++i) {

                        m_pCorrel__Buffer[i] = reinterpret_cast<ResultType_Agg*>(realloc(m_pCorrel__Buffer[i], m_maxDisparityRangeSize * sizeof(ResultType_Agg)));
                        m_pCorrel[i] = m_pCorrel__Buffer[i] - m_dispMin;
                    }
                }

                if(m_textureSize < width * height) {

                    m_textureSize = width * height;
                    m_pTextureImage = reinterpret_cast<uint8_t*>(realloc(m_pTextureImage, m_textureSize));
                }

                Parallelize(boost::bind(&CoreType::template ComputeDisparity<T>, this, _1, _2, _3, _4), left.Buffer(), right.Buffer(), Threads_Agg);

                Optimization::Finalize();
            }

            template<typename T>
            inline void ComputeDisparity(const T* pLeft, const T* pRight, uint32_t threadId, uint32_t threadNum)
            {   
                const uint32_t width = m_dsi->W();
                uint32_t dsi_x_min = m_dsiXMin;
                uint32_t dsi_x_max = m_dsiXMax;

                uint32_t y_min = m_threadRange[threadId];
                uint32_t y_max = m_threadRange[threadId + 1];

                const std::vector<SearchRange>& search_ranges = m_searchRanges;
                ResultType_Agg* pCorrel = m_pCorrel[threadId];

                const uint32_t win_w = m_winWidth;
                const uint32_t win_h = m_winHeight;

                uint32_t l_half_win_w = win_w/2;
                uint32_t r_half_win_w = (win_w % 2) ? win_w/2 : win_w/2 -1;
                uint32_t t_half_win_h = win_h/2;
                uint32_t b_half_win_h = (win_h % 2) ? win_h/2 : win_h/2 -1;

                const int win_area = win_w * win_h;

                typedef typename cimage::PixelTraits<T>::ChannelCumulativeType TextureType;
                
                if(m_textureAlgo == VARIANCE) {

                    TextureType minVariance = m_minVariance * win_area * win_area;

                    for(int i = (int)y_min; i< (int)y_max;i++)
                        for(int j = (int)dsi_x_min; j< (int)dsi_x_max; j++) {
                            
                            typename cimage::PixelTraits<T>::CumulativeType sum = 0, sum2 = 0;

                            for(int h = -(int)t_half_win_h; h<= (int)b_half_win_h; h++)
                                for(int k = -(int)l_half_win_w; k <= (int)r_half_win_w; k++) {

                                    int index = (i + h) * width + j + k;
                                    sum += cimage::Abs(pRight[index]);
                                    sum2 += cimage::Sqr(pRight[index]);
                                }

                            m_pTextureImage[i * width + j] = (cimage::ChannelSum(win_area * sum2 - sum * sum) >= minVariance);
                        }
                } else {

                    const TextureType minSum = m_minSum * win_area;

                    for (int i = (int)y_min; i< (int)y_max;i++)
                        for (int j = (int)dsi_x_min; j< (int)dsi_x_max; j++) {

                            TextureType sum = 0;

                            for(int h = -(int)t_half_win_h; h<= (int)b_half_win_h; h++)
                                for(int k = -(int)l_half_win_w; k <= (int)r_half_win_w; k++)
                                    sum += cimage::Norm1(pRight[(i + h) * width + j + k]);

                            m_pTextureImage[i * width + j] = (sum >= minSum);
                        }
                }

                for(int i = (int)y_min; i< (int)y_max; i++)
                    for(int j = (int)dsi_x_min; j < (int)dsi_x_max; j++) {

                        int index = i * width + j;

                        if(m_pTextureImage[index]) {

                            int start = std::max(search_ranges[i].first, (int)l_half_win_w - j);
                            int stop = std::min(search_ranges[i].second,(int)width - 1 - j - (int)r_half_win_w);

                            for(int d = start; d <= stop; d++) {

                                ResultType_Agg correl = 0;

                                for(int h = -(int)t_half_win_h; h <= (int)b_half_win_h; h++)
                                    for(int k = -(int)l_half_win_w; k<= (int)r_half_win_w; k++)
                                        correl += Cost::eval(pLeft[(i + h) * width + j + k + d], pRight[(i + h) * width + j + k]);

                                pCorrel[d] = correl;
                            }

                            Optimization::Store(pCorrel, j, i, start, stop, threadId);
                        } else
                            Optimization::Store(DISPARITY_UNKNOWN, SCORE_UNKNOWN, j, i, threadId);
                    }
            }

        private:

            const uint8_t* m_pMask;
            int32_t m_maxDisparityRangeSize;
            int m_threadRange[Threads_Agg + 1];
            uint32_t m_textureSize;
            ResultType_Agg* m_pCorrel[Threads_Agg];
            ResultType_Agg* m_pCorrel__Buffer[Threads_Agg];
            uint8_t* m_pTextureImage;
    };

    
}

#undef __log_debug

#endif
