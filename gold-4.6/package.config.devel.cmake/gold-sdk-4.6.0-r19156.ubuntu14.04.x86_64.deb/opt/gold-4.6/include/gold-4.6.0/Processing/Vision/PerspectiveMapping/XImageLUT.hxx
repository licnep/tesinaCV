#ifndef _XIMAGELUT_TCC
#define _XIMAGELUT_TCC

#include "XImageLUT.h"

#ifdef I_AM_MASOCHISTIC
 #include "interpolation.h"
#endif

#include <boost/math/tr1.hpp> 

template<class T, class D>
void TXImageLUT<T,D>::Compute(void)
{
D x0,y0,w0;

/*    std::cout << "%";*/
x0 = m[2];y0 = m[5];w0 = m[8];

for (unsigned int v=0; v<T::height; v++)
    {
    D x = x0, y = y0, w = w0;
    for (unsigned int u=0; u<T::width; u++)
        {
        T::SetPixel(u, v, x/w, y/w);
        x += m[0]; y += m[3]; w += m[6];
        }
    x0 += m[1]; y0+=m[4]; w0+=m[7];
    }
computed = true;
}

#ifdef I_AM_MASOCHISTIC
template<class T, class D>
void TXImageLUT<T,D>::FineCompute(void)
    {
    ht::HomographicTransformation I;

    ht::HomographicTransformation(m).Invert(I);

    D x0,y0,w0;
    x0 = m[2];y0 = m[5];w0 = m[8];
    
    for (unsigned int v=0; v<T::height; v++)
        {
        D x = x0, y = y0, w = w0;
        for (unsigned int u=0; u<T::width; u++)
            {
            double uk = x/w, vk = y/w;
            double uf, vf;
            double ur, vr;
            math::Point2d a,b,c,d;
            double alpha, beta;

            ur = boost::math::tr1::trunc(uk);
            vr = boost::math::tr1::trunc(vk);

            a = I(Point2d(ur,vr));
            b = I(Point2d(ur,vr+1.0));
            c = I(Point2d(ur+1.0,vr));
            d = I(Point2d(ur+1.0,vr+1.0));

//              std::cout << u <<","<< v << " -> " << a << " " << b << " " << c << " " << d << std::endl;

            alpha = sweep_value(a,b,c,d,(double)u,(double)v);
            beta =  sweep_value(a,c,b,d,(double)u,(double)v);
            
            uf = ur + beta;
            vf = vr + alpha;
            
//             std::cout << "result: " << uk <<"," << vk << " -> " << uf << "," << vf << std::endl;

            T::SetPixel(u, v, uf, vf);
            x += m[0]; y += m[3]; w += m[6];
            }
        x0 += m[1]; y0+=m[4]; w0+=m[7];
        }
    computed = true;
    }
#endif


#endif
