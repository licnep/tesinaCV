#ifndef _CIMAGE_STATISTICS_HXX
#define _CIMAGE_STATISTICS_HXX

#include <Data/CImage/TImage.h>
#include <Data/CImage/PixelTraits/PixelTraits.h>
#include <Processing/Vision/CImage/Algorithms.hxx>
#include <Processing/Vision/CImage/PixelFunctors.h>
#include <Processing/Vision/CImage/Statistics/Statistics.h>

namespace cimage
{
  template <class ImageType, class MaskType>
  class Accumulator
  {
      typedef typename ImageType::PixelTraits::ChannelCumulativeType ChannelCumulativeType;

      std::vector<ChannelCumulativeType> CumulativeValues;
      cimage::AreaType N;
      double MaskSum;   // sum of the mask values
      const ImageType& m_Image;
      const unsigned int W;

      typename ImageType::PixelType m_Buffer; // buffer per le operazioni di mascheratura

    public:
      Accumulator ( const ImageType& Image ) :
          CumulativeValues ( ImageType::PixelTraits::Channels() ) ,
          N ( 0L ),
          MaskSum ( 0.0 ),
          m_Image ( Image ),
          W ( m_Image.W() )
      {}

      void operator() ( const typename ImageType::PixelType &pixel, const typename MaskType::PixelType mask )
      {
        // maschera il pixel
        functors::Apply_Mask ( m_Buffer, pixel, mask );

        // aggiorna il valore cumulativo per ogni canale
        for ( unsigned int i=0; i<ImageType::PixelTraits::Channels(); ++i )
        {
          // accumula il valore di ciascun canale
          CumulativeValues[i]+=static_cast<ChannelCumulativeType> ( *ImageType::PixelTraits::GetChannel ( &m_Buffer, W, i ) );

          // accumula il valore della maschera
          MaskSum+=static_cast<double> ( mask );
        }
      }

      // ritorna un vettore di double con le medie per ciascun canale
      cimage::StatisticType Mean()
      {
        cimage::StatisticType RetVal ( ImageType::PixelTraits::Channels() );

        // se MaskSum vale 0 si torna il valore di default
        if(MaskSum!=0)
        {
          // compila l'array delle statistiche per ogni canale
          for ( unsigned int i=0; i<ImageType::PixelTraits::Channels(); ++i )
            RetVal[i]=CumulativeValues[i]/static_cast<unsigned int> ( MaskSum/MaskType::PixelTraits::Channel_Max() );
        }

        return RetVal;
      }
  };


  // calcola la media di una immagine. Ritorna un vettore di double in cui ciascun elemento è la media per il canale i-esimo
  template<class T>
  // GOLD_PROC_CIMAGE_EXPORT cimage::StatisticType Mean ( const TImage<T>& Image, unsigned int Start, unsigned int Stride, unsigned int _Size, unsigned int PCh, unsigned int ICh )
  cimage::StatisticType Mean ( const TImage<T>& Image, unsigned int Start, unsigned int Stride, unsigned int _Size, unsigned int PCh, unsigned int ICh )
  {
    typedef PixelTraits<T> PixelTraits;

    cimage::StatisticType RetVal ( PixelTraits::Channels() );
    std::vector<typename PixelTraits::ChannelCumulativeType> CumulativeValues 
      ( static_cast<typename std::vector<typename PixelTraits::ChannelCumulativeType>::size_type>(PixelTraits::Channels()), 0 );

    AreaType N=0;

    const typename PixelTraits::PixelType *Buffer = Image.Buffer()+Start+PCh;
    const typename PixelTraits::PixelType *End    = Buffer+Image.Area();

    // per ogni pixel
    for ( ; Buffer<End; Buffer+=Stride, ++N )
      // per ogni canale
      for ( unsigned int i=0; i<PixelTraits::Channels(); ++i )
      {
        // if(*PixelTraits::GetChannel ( Buffer, Image.W(), i )==0)
        //  std::cout << "!" << std::flush;
        CumulativeValues[i] += *PixelTraits::GetChannel ( Buffer, Image.W(), i );
      }

    // std::cout << "CV="<<CumulativeValues[0] << " "
    //           << CumulativeValues[1] << " "
    //           << CumulativeValues[2] << " N="<<N<< std::endl;

    // per ogni canale
    for ( unsigned int i=0; i<PixelTraits::Channels(); ++i )
      RetVal[i]=CumulativeValues[i]/N;


    // std::cout << "RV="<< RetVal[0] << " "
    //         << RetVal[1] << " "
    //         << RetVal[2] << std::endl;




    return RetVal;
  }

  template<class ImageType, class MaskType>
  // GOLD_PROC_CIMAGE_EXPORT cimage::StatisticType Mean ( const ImageType& Image, const MaskType& Mask )
  cimage::StatisticType Mean ( const ImageType& Image, const MaskType& Mask ) // PG patch dllimportexport
  {
    return algorithms::for_each_masked_sub_on_mask ( Image, Mask, Accumulator<ImageType, MaskType> ( Image ) ).Mean();
  }
}


#endif