/** @file TImageMatrixTransformation.h
  * @brief funzioni per trasformazioni lineari (affini) e omografiche su CImage
  * @author Paolo Medici
  **/
#ifndef _IMAGEMATRIXTRANSFORMATION_H
#define _IMAGEMATRIXTRANSFORMATION_H

#warning deprecated: use <Processing/Vision/CImage/Transformations/Homography.h> instead

#include <Data/CImage/CImage.h>
#include <Processing/Vision/CImage/Transformations/Interpolate.h>
#include <Data/Math/TMatrices.h>

/** Applica una trasformazione affine basata su matrice al buffer
 * @note usare i float. i double avrebbero un decadimento sensibile delle prestazioni senza
 *       alcun aumento di precisione. usare altrimenti i fixed_point
 *
 * \code
 * AffineMappingFilter<unsigned char, float, BilinearInterpolate>(dest, source, width, height, matrix);
 * \endcode
 **/
template<typename T, typename R, class X>
class AffineMappingFilter: public math::TMatrix<R,2,3>, public X
{
    public:
    typedef math::TMatrix<R,2,3> matrix_t;
    public:
    AffineMappingFilter()  {}
    AffineMappingFilter(const matrix_t & m) : matrix_t(m) { }
    template<class S>
    explicit AffineMappingFilter(const S * s) : matrix_t(s) { }

void operator()(T *dest,
                const T *source,
                unsigned int out_width,
                unsigned int out_height,
                unsigned int in_width,
                unsigned int in_height) const
{
    const R *matrix = this->get();

    R x0,y0;
    /* codice originale (non ottimizzato)
    x = matrix[0] * i + matrix[1] * j + matrix[2];
    y = matrix[3] * i + matrix[4] * j + matrix[5];
    */    
    x0 = matrix[2];
    y0 = matrix[5];
    for(unsigned int j=0;j<out_height;j++)
    {
        R x,y;
        x = x0;
        y = y0;
        for(unsigned int i=0;i<out_width;i++)
        {
            *dest = X::operator()(source, in_width, in_height, x, y);
            dest++;
            x+= matrix[0];
            y+= matrix[3];
        }
        x0+=matrix[1];
        y0+=matrix[4];
    }
}
};


/** Applica una trasformazione affine basata su matrice alle CImage
 * La trasformazione affine 
 * @note la matrice deve essere una matrice Affine. L'uso di matrici omografiche come input, anchse se permesso
 *       potrebbe dare risultati inattesi, normalmente non corretti se m[6]!=0.0 & m[7]!=0.0 (piccole variazioni prospettiche)
 * @note usare i float. i double avrebbero un decadimento sensibile delle prestazioni senza
 *       alcun aumento di precisione. usare altrimenti i fixed_point.
 *
 * \code
 * TImageAffineMappingFilter<CImageMono,float> filter(M);
 * filter(source, dest);
 * \endcode
 *
 * \code
 * TImageAffineMappingFilter<CImageRGB8,float> filter(M);
 * filter(source, dest);
 * \endcode
 *
 * \code
 *  TImageAffineMappingFilter<CImageMono,float,NearestInterpolate> filter;
 * \endcode
 *
 * @note 
 *  Su immagini 640x300 BW su Pentium4HT 3.2Ghz
 *   BilinearInterpolate impiega circa 17msec,
 *   NearestInterpolate impiega circa 6msec.
 *  Su immagini 640x480 RGB su Pentium4HT 3.2Ghz
 *   BilinearInterpolate impiega circa 35msec,
 *   NearestInterpolate impiega circa 13msec.
 **/
template<typename T, typename R, class X = BilinearInterpolate>
class TImageAffineMappingFilter: public AffineMappingFilter<typename T::PixelType,R,X>
{
    typedef typename T::PixelType pixel_t;
    typedef AffineMappingFilter<pixel_t,R,X> parent_t;
    typedef math::TMatrix<R,2,3> matrix_t;
    public:
        TImageAffineMappingFilter()  {}
        
        /// @param m a 3x2 Affine Transformation matrix
        TImageAffineMappingFilter(const matrix_t & m) : parent_t(m) { }
        
        /// @param s a 3x2 Affine Transformation matrix
        template<class S>
        explicit TImageAffineMappingFilter(const S * s) : parent_t(s) { }

        /**
        * @brief Applica la trasformazione lineare tra le due immagini
        * @param input  Immagine di input
        * @param output Immagine di output
        */
        void operator() (const T& input, T& output) const
            {
            parent_t::operator() (output.Buffer(), input.Buffer(),
                        output.W(),output.H(),
                        input.W(),input.H() );
            }
};

/** Applica una trasformazione omografica basata su matrice al buffer
 * @note usare i float. i double avrebbero un decadimento sensibile delle prestazioni senza
 *       alcun aumento di precisione. usare altrimenti i fixed_point
 *
 * \code
 * HomographicMappingFilter<unsigned char, float, BilinearInterpolate> htr(matrix);
 * // ...
 * htr(dest, source, dest_width, dest_height, source_width, source_width);
 * \endcode
 **/
template<typename T, typename R, class X>
class HomographicMappingFilter: public math::TMatrix<R,3,3>, public X
{
    public:
    typedef math::TMatrix<R,3,3> matrix_t;
    public:
    HomographicMappingFilter()  {}
    HomographicMappingFilter(const matrix_t & m) : matrix_t(m) { }
    template<class S>
    explicit HomographicMappingFilter(const S * s) : matrix_t(s) { }

void operator()(T *dest,
                const T *source,
                unsigned int out_width,
                unsigned int out_height,
                unsigned int in_width,
                unsigned int in_height) const
{
    const R *matrix = this->get();

    R x0,y0,w0;
    /* codice originale (non ottimizzato)
        jx = m[0] * u0 + m[1] * v0 + m[2];
        jy = m[3] * u0 + m[4] * v0 + m[5];
        jw = m[6] * u0 + m[7] * v0 + m[8];    
    */
    x0 = matrix[2];
    y0 = matrix[5];
    w0 = matrix[8];
    for(unsigned int j=0;j<out_height;j++)
    {
        R x,y,w;
        x = x0;
        y = y0;
        w = w0;
        for(unsigned int i=0;i<out_width;i++)
        {
            *dest = X::operator()(source, in_width, in_height, x/w, y/w);
            dest++;
            x+= matrix[0];
            y+= matrix[3];
            w+= matrix[6];
        }
        x0+=matrix[1];
        y0+=matrix[4];
        w0+=matrix[7];
    }
}
};

/** Applica una trasformazione omografica basata su matrice alle CImage
 * @note usare i float. i double avrebbero un decadimento sensibile delle prestazioni senza
 *       alcun aumento di precisione. usare altrimenti i fixed_point.
 *
 * \code
 *  TImageHomographicMappingFilter<CImageMono,float,NearestInterpolate> filter;
 * \endcode
 * \code
 *  TImageHomographicMappingFilter<CImageMono,float> filter(ht::CameraWarp(src,dst).get());
 * \endcode
 *
 * @note 
 *  Su immagini 640x300 BW su Pentium4HT 3.2Ghz 
 *   BilinearInterpolate impiega circa 19 msec,
 *   NearestInterpolate impiega circa 10 msec.
 *  Su immagini 640x480 RGB su Pentium4HT 3.2Ghz 
 *   BilinearInterpolate impiega circa 39 msec,
 *   NearestInterpolate impiega circa 23 msec.
 **/
template<typename T, typename R, class X = BilinearInterpolate>
class TImageHomographicMappingFilter: public HomographicMappingFilter<typename T::PixelType,R,X>
{
    typedef typename T::PixelType pixel_t;
    typedef HomographicMappingFilter<pixel_t,R,X> parent_t;
    typedef math::TMatrix<R,3,3> matrix_t;
    public:
        TImageHomographicMappingFilter()  {}
        TImageHomographicMappingFilter(const matrix_t & m) : parent_t(m) { }
        template<class S>
        explicit TImageHomographicMappingFilter(const S * s) : parent_t(s) { }

        /**
        * @brief Applica la trasformazione lineare tra le due immagini
        * @param input  Immagine di input
        * @param output Immagine di output
        */
        void operator() (const T& input, T& output) const
            {
            parent_t::operator() (output.Buffer(), input.Buffer(),
                        output.W(),output.H(),
                        input.W(),input.H() );
            }
};

#endif
