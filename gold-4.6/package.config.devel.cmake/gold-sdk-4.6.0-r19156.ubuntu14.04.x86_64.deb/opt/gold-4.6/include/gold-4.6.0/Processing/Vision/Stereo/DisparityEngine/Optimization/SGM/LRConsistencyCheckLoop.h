#ifndef LR_CONSISTENCY_CHECK_H
#define LR_CONSISTENCY_CHECK_H

namespace disparity
{

    namespace opt
    {

        namespace lrcheck
        {
            template <int max_disparity>
            inline void pixel_loop1(uint8_t* diag,  uint8_t* cube, int width);
            
            template <int max_disparity>
            inline void pixel_loop2(uint8_t* diag,  uint8_t* cube, int width){}
            
            template <int max_disparity>
            inline void pixel_loop4(uint8_t* diag,  uint8_t* cube, int width){}
       
#ifdef __AVX__            
#define  LRLOOP16(x) \
            "vpalignr $"#x", %%xmm5, %%xmm0, %%xmm5 \n\t"\
            "vpalignr $"#x", %%xmm0, %%xmm4, %%xmm0 \n\t"
#else
#define  LRLOOP16(x) \
            "palignr $"#x", %%xmm0, %%xmm4\n\t"\
            "palignr $"#x", %%xmm5, %%xmm0\n\t"\
            "pshufd  $228, %%xmm0, %%xmm5\n\t"\
            "pshufd  $228, %%xmm4, %%xmm0\n\t"
#endif             
            
            
#define PIXEL_LOOP_16(x)\
            template <>\
            DECLSPEC_FORCEINLINE inline void pixel_loop##x<16>(uint8_t* diag,  uint8_t* cube, int width)\
            {\
                const int max_disparity = 16;\
                int ii = 0;\
                __asm__ __volatile__ (\
                    "movdqa %0, %%xmm0\n\t"\
                    "pcmpeqd %%xmm4, %%xmm4\n\t"\
                    LRLOOP16(x)\
                : :  "m" (*( cube )) : "%xmm0", "%xmm4", "%xmm5"  );\
                \
                cube += max_disparity;\
                for ( int j = 1; j < width; j++, cube += max_disparity)\
                {\
                    __asm__ __volatile__ (\
                        "movdqa %0, %%xmm6\n\t"\
                        "pminub %%xmm6, %%xmm0\n\t"\
                        "pcmpeqd %%xmm4, %%xmm4\n\t"\
                        LRLOOP16(x)\
                   : :  "m" (*( cube )) : "%xmm0", "%xmm4", "%xmm5",  "%xmm6");\
                    if (!((j+1) % (16/x)))\
                    {\
                        __asm__ __volatile__ (    "movdqa %%xmm5, %0\n\t":  "=m"(*(diag+ii)): : "%xmm0");\
                        ii += 16;\
                    }\
                }\
                \
                if (width % (16/x))\
                {\
                    for ( int j = 0; j <(16/x) - (width % (16/x)); j++)\
                    {\
                        __asm__ __volatile__ (\
                        LRLOOP16(x)\
                        : :   : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5" );\
                    }\
                    __asm__ __volatile__ (    "movdqa %%xmm5, %0\n\t":  "=m"(*(diag+ii)): : "%xmm0");\
                    ii += 16;\
                }\
                \
                __asm__ __volatile__ (\
                    "movdqa %%xmm0, %0\n\t"\
                :  "=m"(*(diag+ii)): : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5",  "%xmm6", "%xmm7", "%xmm8");\
            }
            
#ifdef __AVX__            
#define  LRLOOP32(x) \
            "vpalignr $"#x", %%xmm5, %%xmm0, %%xmm5 \n\t"\
            "vpalignr $"#x", %%xmm0, %%xmm1, %%xmm0 \n\t"\
            "vpalignr $"#x", %%xmm1, %%xmm4, %%xmm1 \n\t"   
#else
#define  LRLOOP32(x) \
            "palignr $"#x", %%xmm1, %%xmm4\n\t"\
            "palignr $"#x", %%xmm0, %%xmm1\n\t"\
            "palignr $"#x", %%xmm5, %%xmm0\n\t"\
            "pshufd  $228, %%xmm0, %%xmm5\n\t"\
            "pshufd  $228, %%xmm1, %%xmm0\n\t"\
            "pshufd  $228, %%xmm4, %%xmm1\n\t"
#endif 

#define PIXEL_LOOP_32(x)\
            template <>\
            DECLSPEC_FORCEINLINE inline void pixel_loop##x<32>(uint8_t* diag,  uint8_t* cube, int width)\
            {\
                const int max_disparity = 32;\
                int ii = 0;\
                __asm__ __volatile__ (\
                    "movdqa %0, %%xmm0\n\t"\
                    "movdqa %1, %%xmm1\n\t"\
                    "pcmpeqd %%xmm4, %%xmm4\n\t"\
                    LRLOOP32(x)\
                : :  "m" (*( cube )), "m" (*( cube+16 )) : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5"  );\
                \
                cube += max_disparity;\
                for ( int j = 1; j < width; j++, cube += max_disparity)\
                {\
                    __asm__ __volatile__ (\
                        "movdqa %0, %%xmm6\n\t"\
                        "movdqa %1, %%xmm7\n\t"\
                        "pminub %%xmm6, %%xmm0\n\t"\
                        "pminub %%xmm7, %%xmm1\n\t"\
                        "pcmpeqd %%xmm4, %%xmm4\n\t"\
                         LRLOOP32(x)\
                : :  "m" (*( cube )), "m" (*( cube+16 ))  : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5",  "%xmm6", "%xmm7");\
                    if (!((j+1) % (16/x)))\
                    {\
                        __asm__ __volatile__ (    "movdqa %%xmm5, %0\n\t":  "=m"(*(diag+ii)): : "%xmm0");\
                        ii += 16;\
                    }\
                }\
                if (width % (16/x))\
                {\
                    for ( int j = 0; j <(16/x) - (width % (16/x)); j++)\
                    {\
                        __asm__ __volatile__ (\
                        LRLOOP32(x)\
                        : :   : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5" );\
                    }\
                    __asm__ __volatile__ (    "movdqa %%xmm5, %0\n\t":  "=m"(*(diag+ii)): : "%xmm0");\
                    ii += 16;\
                }\
                __asm__ __volatile__ (\
                    "movdqa %%xmm0, %0\n\t"\
                    "movdqa %%xmm1, %1\n\t"\
                :  "=m"(*(diag+ii)), "=m"(*(diag+ii+16)): : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5",  "%xmm6", "%xmm7", "%xmm8");\
            }
            
#ifdef __AVX__            
#define  LRLOOP48(x) \
            "vpalignr $"#x", %%xmm8, %%xmm0, %%xmm8 \n\t"\
            "vpalignr $"#x", %%xmm0, %%xmm1, %%xmm0 \n\t"\
            "vpalignr $"#x", %%xmm1, %%xmm2, %%xmm1 \n\t"\
            "vpalignr $"#x", %%xmm2, %%xmm9, %%xmm2 \n\t"      
#else
#define  LRLOOP48(x) \
            "palignr $"#x", %%xmm2, %%xmm9 \n\t"\
            "palignr $"#x", %%xmm1, %%xmm2 \n\t"\
            "palignr $"#x", %%xmm0, %%xmm1 \n\t"\
            "palignr $"#x", %%xmm8, %%xmm0 \n\t"\
            "pshufd  $228, %%xmm0, %%xmm8 \n\t"\
            "pshufd  $228, %%xmm1, %%xmm0 \n\t"\
            "pshufd  $228, %%xmm2, %%xmm1 \n\t"\
            "pshufd  $228, %%xmm9, %%xmm2 \n\t"
#endif            
            
#define PIXEL_LOOP_48(x)\
            template <>\
            DECLSPEC_FORCEINLINE inline void pixel_loop##x<48>(uint8_t* diag,  uint8_t* cube, int width)\
            {\
                const int max_disparity = 48;\
                int ii=0;\
                __asm__ __volatile__ (\
                    "movdqa %0, %%xmm0 \n\t"\
                    "movdqa %1, %%xmm1 \n\t"\
                    "movdqa %2, %%xmm2 \n\t"\
                    "pcmpeqd %%xmm9, %%xmm9 \n\t"\
                    LRLOOP48(x)\
                : :  "m" (*( cube )), "m" (*( cube+16 )), "m" (*( cube+32 ))  : "%xmm0", "%xmm1", "%xmm2", "%xmm8", "%xmm9"  );\
                \
                cube += max_disparity;\
                for ( int j = 1; j < width; j++, cube += max_disparity)\
                {\
                    __asm__ __volatile__ (\
                        "movdqa %0, %%xmm10 \n\t"\
                        "movdqa %1, %%xmm11 \n\t"\
                        "movdqa %2, %%xmm12 \n\t"\
                        "pminub %%xmm10, %%xmm0 \n\t"\
                        "pminub %%xmm11, %%xmm1 \n\t"\
                        "pminub %%xmm12, %%xmm2 \n\t"\
                        "pcmpeqd %%xmm9, %%xmm9 \n\t"\
                        LRLOOP48(x)\
                : :  "m" (*( cube )), "m" (*( cube+16 )), "m" (*( cube+32 ))  : "%xmm0", "%xmm1", "%xmm2", "%xmm8", "%xmm9", "%xmm10", "%xmm11", "%xmm12" );\
                    if (!((j+1) % (16/x)))\
                    {\
                        __asm__ __volatile__ (    "movdqa %%xmm8, %0\n\t":  "=m"(*(diag+ii)): : "%xmm8");\
                        ii += 16;\
                    }\
                }\
                \
                if (width % (16/x))\
                {\
                    for ( int j = 0; j <(16/x) - (width % (16/x)); j++)\
                    {\
                        __asm__ __volatile__ (\
                        LRLOOP48(x)\
                        : :   : "%xmm0", "%xmm1", "%xmm2", "%xmm8", "%xmm9" );\
                    }\
                    __asm__ __volatile__ (    "movdqa %%xmm8, %0\n\t":  "=m"(*(diag+ii)): : "%xmm8");\
                    ii += 16;\
                }\
                \
                __asm__ __volatile__ (\
                    "movdqa %%xmm0, %0\n\t"\
                    "movdqa %%xmm1, %1\n\t"\
                    "movdqa %%xmm2, %2\n\t"\
                :  "=m"(*(diag+ii)), "=m"(*(diag+ii+16)), "=m"(*(diag+ii+32))  : : "%xmm0", "%xmm1", "%xmm2" );\
            }
            
#ifdef __AVX__            
#define  LRLOOP64(x) \
            "vpalignr $"#x", %%xmm5, %%xmm0, %%xmm5 \n\t"\
            "vpalignr $"#x", %%xmm0, %%xmm1, %%xmm0 \n\t"\
            "vpalignr $"#x", %%xmm1, %%xmm2, %%xmm1 \n\t"\
            "vpalignr $"#x", %%xmm2, %%xmm3, %%xmm2 \n\t"\
            "vpalignr $"#x", %%xmm3, %%xmm4, %%xmm3 \n\t"        
#else
#define  LRLOOP64(x) \
            "palignr $"#x", %%xmm3, %%xmm4\n\t"\
            "palignr $"#x", %%xmm2, %%xmm3\n\t"\
            "palignr $"#x", %%xmm1, %%xmm2\n\t"\
            "palignr $"#x", %%xmm0, %%xmm1\n\t"\
            "palignr $"#x", %%xmm5, %%xmm0\n\t"\
            "pshufd  $228, %%xmm0, %%xmm5\n\t"\
            "pshufd  $228, %%xmm1, %%xmm0\n\t"\
            "pshufd  $228, %%xmm2, %%xmm1\n\t"\
            "pshufd  $228, %%xmm3, %%xmm2\n\t"\
            "pshufd  $228, %%xmm4, %%xmm3\n\t"
#endif
 
#define PIXEL_LOOP_64(x)\
            template <>\
            DECLSPEC_FORCEINLINE inline void pixel_loop##x<64>(uint8_t* diag,  uint8_t* cube, int width)\
            {\
                const int max_disparity = 64;\
                int ii = 0;\
                __asm__ __volatile__ (\
                    "movdqa %0, %%xmm0\n\t"\
                    "movdqa %1, %%xmm1\n\t"\
                    "movdqa %2, %%xmm2\n\t"\
                    "movdqa %3, %%xmm3\n\t"\
                    "pcmpeqd %%xmm4, %%xmm4\n\t"\
                     LRLOOP64(x)\
                : :  "m" (*( cube )), "m" (*( cube+16 )), "m" (*( cube+32 )), "m" (*( cube+48 )) : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5"  );\
                \
                cube += max_disparity;\
                for ( int j = 1; j < width; j++, cube += max_disparity)\
                {\
                    __asm__ __volatile__ (\
                        "movdqa %0, %%xmm6\n\t"\
                        "movdqa %1, %%xmm7\n\t"\
                        "movdqa %2, %%xmm8\n\t"\
                        "movdqa %3, %%xmm9\n\t"\
                        "pminub %%xmm6, %%xmm0\n\t"\
                        "pminub %%xmm7, %%xmm1\n\t"\
                        "pminub %%xmm8, %%xmm2\n\t"\
                        "pminub %%xmm9, %%xmm3\n\t"\
                        "pcmpeqd %%xmm4, %%xmm4\n\t"\
                        LRLOOP64(x)\
                : :  "m" (*( cube )), "m" (*( cube+16 )), "m" (*( cube+32 )), "m" (*( cube+48 ))  : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5",  "%xmm6", "%xmm7", "%xmm8",  "%xmm9");\
                    if (!((j+1) % (16/x)))\
                    {\
                        __asm__ __volatile__ (    "movdqa %%xmm5, %0\n\t":  "=m"(*(diag+ii)): : "%xmm5");\
                        ii += 16;\
                    }\
                }\
                \
                if (width % (16/x))\
                {\
                    for ( int j = 0; j <(16/x) - (width % (16/x)); j++)\
                    {\
                        __asm__ __volatile__ (\
                        LRLOOP64(x)\
                        : :   : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5" );\
                    }\
                    __asm__ __volatile__ (    "movdqa %%xmm5, %0\n\t":  "=m"(*(diag+ii)): : "%xmm5");\
                    ii += 16;\
                }\
                \
                __asm__ __volatile__ (\
                    "movdqa %%xmm0, %0\n\t"\
                    "movdqa %%xmm1, %1\n\t"\
                    "movdqa %%xmm2, %2\n\t"\
                    "movdqa %%xmm3, %3\n\t"\
                :  "=m"(*(diag+ii)), "=m"(*(diag+ii+16)), "=m"(*(diag+ii+32)), "=m"(*(diag+ii+48)): : "%xmm0", "%xmm1", "%xmm2",  "%xmm3");\
            }

#ifdef __AVX__            
#define  LRLOOP80(x) \
            "vpalignr $"#x", %%xmm8, %%xmm0, %%xmm8 \n\t"\
            "vpalignr $"#x", %%xmm0, %%xmm1, %%xmm0 \n\t"\
            "vpalignr $"#x", %%xmm1, %%xmm2, %%xmm1 \n\t"\
            "vpalignr $"#x", %%xmm2, %%xmm3, %%xmm2 \n\t"\
            "vpalignr $"#x", %%xmm3, %%xmm4, %%xmm3 \n\t"\
            "vpalignr $"#x", %%xmm4, %%xmm9, %%xmm4 \n\t"             
#else
#define  LRLOOP80(x) \
            "palignr $"#x", %%xmm4, %%xmm9 \n\t"\
            "palignr $"#x", %%xmm3, %%xmm4 \n\t"\
            "palignr $"#x", %%xmm2, %%xmm3 \n\t"\
            "palignr $"#x", %%xmm1, %%xmm2 \n\t"\
            "palignr $"#x", %%xmm0, %%xmm1 \n\t"\
            "palignr $"#x", %%xmm8, %%xmm0 \n\t"\
            "pshufd  $228, %%xmm0, %%xmm8 \n\t"\
            "pshufd  $228, %%xmm1, %%xmm0 \n\t"\
            "pshufd  $228, %%xmm2, %%xmm1 \n\t"\
            "pshufd  $228, %%xmm3, %%xmm2 \n\t"\
            "pshufd  $228, %%xmm4, %%xmm3 \n\t"\
            "pshufd  $228, %%xmm9, %%xmm4 \n\t"
#endif

#define PIXEL_LOOP_80(x)\
            template <>\
            DECLSPEC_FORCEINLINE inline void pixel_loop##x<80>(uint8_t* diag,  uint8_t* cube, int width)\
            {\
                const int max_disparity = 80;\
                int ii=0;\
                __asm__ __volatile__ (\
                    "movdqa %0, %%xmm0 \n\t"\
                    "movdqa %1, %%xmm1 \n\t"\
                    "movdqa %2, %%xmm2 \n\t"\
                    "movdqa %3, %%xmm3 \n\t"\
                    "movdqa %4, %%xmm4 \n\t"\
                    "pcmpeqd %%xmm9, %%xmm9 \n\t"\
                    LRLOOP80(x)\
                : :  "m" (*( cube )), "m" (*( cube+16 )), "m" (*( cube+32 )), "m" (*( cube+48 )), "m" (*( cube+64 ))  : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm8", "%xmm9"  );\
                \
                cube += max_disparity;\
                for ( int j = 1; j < width; j++, cube += max_disparity)\
                {\
                    __asm__ __volatile__ (\
                        "movdqa %0, %%xmm10 \n\t"\
                        "movdqa %1, %%xmm11 \n\t"\
                        "movdqa %2, %%xmm12 \n\t"\
                        "movdqa %3, %%xmm13 \n\t"\
                        "movdqa %4, %%xmm14 \n\t"\
                        "pminub %%xmm10, %%xmm0 \n\t"\
                        "pminub %%xmm11, %%xmm1 \n\t"\
                        "pminub %%xmm12, %%xmm2 \n\t"\
                        "pminub %%xmm13, %%xmm3 \n\t"\
                        "pminub %%xmm14, %%xmm4 \n\t"\
                        "pcmpeqd %%xmm9, %%xmm9 \n\t"\
                        LRLOOP80(x)\
                : :  "m" (*( cube )), "m" (*( cube+16 )), "m" (*( cube+32 )), "m" (*( cube+48 )), "m" (*( cube+64 ))  : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm8", "%xmm9", "%xmm10", "%xmm11", "%xmm12", "%xmm13", "%xmm14" );\
                    if (!((j+1) % (16/x)))\
                    {\
                        __asm__ __volatile__ (    "movdqa %%xmm8, %0\n\t":  "=m"(*(diag+ii)): : "%xmm8");\
                        ii += 16;\
                    }\
                }\
                \
                if (width % (16/x))\
                {\
                    for ( int j = 0; j <(16/x) - (width % (16/x)); j++)\
                    {\
                        __asm__ __volatile__ (\
                        LRLOOP80(x)\
                        : :   : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm8", "%xmm9" );\
                    }\
                    __asm__ __volatile__ (    "movdqa %%xmm8, %0\n\t":  "=m"(*(diag+ii)): : "%xmm8");\
                    ii += 16;\
                }\
                \
                __asm__ __volatile__ (\
                    "movdqa %%xmm0, %0\n\t"\
                    "movdqa %%xmm1, %1\n\t"\
                    "movdqa %%xmm2, %2\n\t"\
                    "movdqa %%xmm3, %3\n\t"\
                    "movdqa %%xmm4, %4\n\t"\
                :  "=m"(*(diag+ii)), "=m"(*(diag+ii+16)), "=m"(*(diag+ii+32)), "=m"(*(diag+ii+48)), "=m"(*(diag+ii+64))  : : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4" );\
            }


#ifdef __AVX__            
#define  LRLOOP96(x) \
            "vpalignr $"#x", %%xmm8, %%xmm0, %%xmm8 \n\t"\
            "vpalignr $"#x", %%xmm0, %%xmm1, %%xmm0 \n\t"\
            "vpalignr $"#x", %%xmm1, %%xmm2, %%xmm1 \n\t"\
            "vpalignr $"#x", %%xmm2, %%xmm3, %%xmm2 \n\t"\
            "vpalignr $"#x", %%xmm3, %%xmm4, %%xmm3 \n\t"\
            "vpalignr $"#x", %%xmm4, %%xmm5, %%xmm4 \n\t"\
            "vpalignr $"#x", %%xmm5, %%xmm9, %%xmm5 \n\t"                
#else
#define  LRLOOP96(x)\
            "palignr $"#x", %%xmm5, %%xmm9 \n\t"\
            "palignr $"#x", %%xmm4, %%xmm5 \n\t"\
            "palignr $"#x", %%xmm3, %%xmm4 \n\t"\
            "palignr $"#x", %%xmm2, %%xmm3 \n\t"\
            "palignr $"#x", %%xmm1, %%xmm2 \n\t"\
            "palignr $"#x", %%xmm0, %%xmm1 \n\t"\
            "palignr $"#x", %%xmm8, %%xmm0 \n\t"\
            "pshufd  $228, %%xmm0, %%xmm8 \n\t"\
            "pshufd  $228, %%xmm1, %%xmm0 \n\t"\
            "pshufd  $228, %%xmm2, %%xmm1 \n\t"\
            "pshufd  $228, %%xmm3, %%xmm2 \n\t"\
            "pshufd  $228, %%xmm4, %%xmm3 \n\t"\
            "pshufd  $228, %%xmm5, %%xmm4 \n\t"\
            "pshufd  $228, %%xmm9, %%xmm5 \n\t"
#endif
            
            
#define PIXEL_LOOP_96(x)\
            template <>\
            DECLSPEC_FORCEINLINE inline void pixel_loop##x<96>(uint8_t* diag,  uint8_t* cube, int width)\
            {\
                const int max_disparity = 96;\
                int ii=0;\
                __asm__ __volatile__ (\
                    "movdqa %0, %%xmm0 \n\t"\
                    "movdqa %1, %%xmm1 \n\t"\
                    "movdqa %2, %%xmm2 \n\t"\
                    "movdqa %3, %%xmm3 \n\t"\
                    "movdqa %4, %%xmm4 \n\t"\
                    "movdqa %5, %%xmm5 \n\t"\
                    "pcmpeqd %%xmm9, %%xmm9 \n\t"\
                    LRLOOP96(x)\
                : :  "m" (*( cube )), "m" (*( cube+16 )), "m" (*( cube+32 )), "m" (*( cube+48 )), "m" (*( cube+64 )), "m" (*( cube+80 ))  : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5", "%xmm8", "%xmm9"  );\
                \
                cube += max_disparity;\
                for ( int j = 1; j < width; j++, cube += max_disparity)\
                {\
                    __asm__ __volatile__ (\
                        "movdqa %0, %%xmm10 \n\t"\
                        "movdqa %1, %%xmm11 \n\t"\
                        "movdqa %2, %%xmm12 \n\t"\
                        "movdqa %3, %%xmm13 \n\t"\
                        "movdqa %4, %%xmm14 \n\t"\
                        "movdqa %5, %%xmm15 \n\t"\
                        "pminub %%xmm10, %%xmm0 \n\t"\
                        "pminub %%xmm11, %%xmm1 \n\t"\
                        "pminub %%xmm12, %%xmm2 \n\t"\
                        "pminub %%xmm13, %%xmm3 \n\t"\
                        "pminub %%xmm14, %%xmm4 \n\t"\
                        "pminub %%xmm15, %%xmm5 \n\t"\
                        "pcmpeqd %%xmm9, %%xmm9 \n\t"\
                        LRLOOP96(x)\
                : :  "m" (*( cube )), "m" (*( cube+16 )), "m" (*( cube+32 )), "m" (*( cube+48 )), "m" (*( cube+64 )), "m" (*( cube+80 ))  : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5", "%xmm8", "%xmm9", "%xmm10", "%xmm11", "%xmm12", "%xmm13", "%xmm14", "%xmm15");\
                    if (!((j+1) % (16/x)))\
                    {\
                        __asm__ __volatile__ (    "movdqa %%xmm8, %0\n\t":  "=m"(*(diag+ii)): : "%xmm8");\
                        ii += 16;\
                    }\
                }\
                \
                if (width % (16/x))\
                {\
                    for ( int j = 0; j <(16/x) - (width % (16/x)); j++)\
                    {\
                        __asm__ __volatile__ (\
                        LRLOOP96(x)\
                        : :   : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm8", "%xmm9" );\
                    }\
                    __asm__ __volatile__ (    "movdqa %%xmm8, %0\n\t":  "=m"(*(diag+ii)): : "%xmm8");\
                    ii += 16;\
                }\
               \
                __asm__ __volatile__ (\
                    "movdqa %%xmm0, %0\n\t"\
                    "movdqa %%xmm1, %1\n\t"\
                    "movdqa %%xmm2, %2\n\t"\
                    "movdqa %%xmm3, %3\n\t"\
                    "movdqa %%xmm4, %4\n\t"\
                    "movdqa %%xmm5, %5\n\t"\
                :  "=m"(*(diag+ii)), "=m"(*(diag+ii+16)), "=m"(*(diag+ii+32)), "=m"(*(diag+ii+48)), "=m"(*(diag+ii+64)), "=m"(*(diag+ii+80)) : : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5" );\
            }



#ifdef __AVX__            
#define  LRLOOP112(x) \
            "vpalignr $"#x", %%xmm8, %%xmm0, %%xmm8 \n\t"\
            "vpalignr $"#x", %%xmm0, %%xmm1, %%xmm0 \n\t"\
            "vpalignr $"#x", %%xmm1, %%xmm2, %%xmm1 \n\t"\
            "vpalignr $"#x", %%xmm2, %%xmm3, %%xmm2 \n\t"\
            "vpalignr $"#x", %%xmm3, %%xmm4, %%xmm3 \n\t"\
            "vpalignr $"#x", %%xmm4, %%xmm5, %%xmm4 \n\t"\
            "vpalignr $"#x", %%xmm5, %%xmm6, %%xmm5 \n\t"\
            "vpalignr $"#x", %%xmm6, %%xmm9, %%xmm6 \n\t"
                 
#else
#define  LRLOOP112(x) \
            "palignr $"#x", %%xmm6, %%xmm9 \n\t" \
            "palignr $"#x", %%xmm5, %%xmm6 \n\t"\
            "palignr $"#x", %%xmm4, %%xmm5 \n\t"\
            "palignr $"#x", %%xmm3, %%xmm4 \n\t"\
            "palignr $"#x", %%xmm2, %%xmm3 \n\t"\
            "palignr $"#x", %%xmm1, %%xmm2 \n\t"\
            "palignr $"#x", %%xmm0, %%xmm1 \n\t"\
            "palignr $"#x", %%xmm8, %%xmm0 \n\t"\
            "pshufd  $228, %%xmm0, %%xmm8 \n\t"\
            "pshufd  $228, %%xmm1, %%xmm0 \n\t"\
            "pshufd  $228, %%xmm2, %%xmm1 \n\t"\
            "pshufd  $228, %%xmm3, %%xmm2 \n\t"\
            "pshufd  $228, %%xmm4, %%xmm3 \n\t"\
            "pshufd  $228, %%xmm5, %%xmm4 \n\t"\
            "pshufd  $228, %%xmm6, %%xmm5 \n\t"\
            "pshufd  $228, %%xmm9, %%xmm6 \n\t"
#endif

#define PIXEL_LOOP_112(x)\
            template <>\
            DECLSPEC_FORCEINLINE inline void pixel_loop##x<112>(uint8_t* diag,  uint8_t* cube, int width)\
            {\
                const int max_disparity = 112;\
                int ii=0;\
                __asm__ __volatile__ (\
                    "movdqa %0, %%xmm0 \n\t"\
                    "movdqa %1, %%xmm1 \n\t"\
                    "movdqa %2, %%xmm2 \n\t"\
                    "movdqa %3, %%xmm3 \n\t"\
                    "movdqa %4, %%xmm4 \n\t"\
                    "movdqa %5, %%xmm5 \n\t"\
                    "movdqa %6, %%xmm6 \n\t"\
                    "pcmpeqd %%xmm9, %%xmm9 \n\t"\
                    LRLOOP112(x)\
                : :  "m" (*( cube )), "m" (*( cube+16 )), "m" (*( cube+32 )), "m" (*( cube+48 )), "m" (*( cube+64 )), "m" (*( cube+80 )), "m" (*( cube+96 ))  : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm8", "%xmm9"  );\
                \
                cube += max_disparity;\
                for ( int j = 1; j < width; j++, cube += max_disparity)\
                {\
                    __asm__ __volatile__ (\
                        "movdqa %0, %%xmm10 \n\t"\
                        "movdqa %1, %%xmm11 \n\t"\
                        "movdqa %2, %%xmm12 \n\t"\
                        "movdqa %3, %%xmm13 \n\t"\
                        "movdqa %4, %%xmm14 \n\t"\
                        "movdqa %5, %%xmm15 \n\t"\
                        "movdqa %6, %%xmm7  \n\t"\
                        "pminub %%xmm10, %%xmm0 \n\t"\
                        "pminub %%xmm11, %%xmm1 \n\t"\
                        "pminub %%xmm12, %%xmm2 \n\t"\
                        "pminub %%xmm13, %%xmm3 \n\t"\
                        "pminub %%xmm14, %%xmm4 \n\t"\
                        "pminub %%xmm15, %%xmm5 \n\t"\
                        "pminub %%xmm7,  %%xmm6 \n\t"\
                        "pcmpeqd %%xmm9, %%xmm9 \n\t"\
                         LRLOOP112(x)\
                : :  "m" (*( cube )), "m" (*( cube+16 )), "m" (*( cube+32 )), "m" (*( cube+48 )), "m" (*( cube+64 )), "m" (*( cube+80 )), "m" (*( cube+96 ))  : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7", "%xmm8", "%xmm9", "%xmm10", "%xmm11", "%xmm12", "%xmm13", "%xmm14", "%xmm15");\
                    if (!((j+1) % (16/x)))\
                    {\
                        __asm__ __volatile__ (    "movdqa %%xmm8, %0\n\t":  "=m"(*(diag+ii)): : "%xmm8");\
                        ii += 16;\
                    }\
                }\
                \
                if (width % (16/x))\
                {\
                    for ( int j = 0; j <(16/x) - (width % (16/x)); j++)\
                    {\
                        __asm__ __volatile__ (\
                        LRLOOP112(x)\
                        : :   : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm8", "%xmm9" );\
                    }\
                    __asm__ __volatile__ (    "movdqa %%xmm8, %0\n\t":  "=m"(*(diag+ii)): : "%xmm8");\
                    ii += 16;\
                }\
                \
                __asm__ __volatile__ (\
                    "movdqa %%xmm0, %0\n\t"\
                    "movdqa %%xmm1, %1\n\t"\
                    "movdqa %%xmm2, %2\n\t"\
                    "movdqa %%xmm3, %3\n\t"\
                    "movdqa %%xmm4, %4\n\t"\
                    "movdqa %%xmm5, %5\n\t"\
                    "movdqa %%xmm6, %6\n\t"\
                :  "=m"(*(diag+ii)), "=m"(*(diag+ii+16)), "=m"(*(diag+ii+32)), "=m"(*(diag+ii+48)), "=m"(*(diag+ii+64)), "=m"(*(diag+ii+80)), "=m"(*(diag+ii+96)) : : "%xmm0", "%xmm1", "%xmm2", "%xmm3", "%xmm4", "%xmm5", "%xmm6" );\
            }  
            
            
#ifdef __AVX__            
#define  LRLOOP128(x)\
            "vpalignr $"#x", %%xmm8, %%xmm0, %%xmm8\n\t"\
            "vpalignr $"#x", %%xmm0, %%xmm1, %%xmm0\n\t"\
            "vpalignr $"#x", %%xmm1, %%xmm2, %%xmm1\n\t"\
            "vpalignr $"#x", %%xmm2, %%xmm3, %%xmm2 \n\t"\
            "vpalignr $"#x", %%xmm3, %%xmm4, %%xmm3\n\t"\
            "vpalignr $"#x", %%xmm4, %%xmm5, %%xmm4\n\t"\
            "vpalignr $"#x", %%xmm5, %%xmm6, %%xmm5\n\t"\
            "vpalignr $"#x", %%xmm6, %%xmm7, %%xmm6\n\t"\
            "vpalignr $"#x", %%xmm7, %%xmm9, %%xmm7\n\t"  
#else
#define  LRLOOP128(x)\
            "palignr $"#x", %%xmm7, %%xmm9\n\t" \
            "palignr $"#x", %%xmm6, %%xmm7\n\t"\
            "palignr $"#x", %%xmm5, %%xmm6\n\t"\
            "palignr $"#x", %%xmm4, %%xmm5\n\t"\
            "palignr $"#x", %%xmm3, %%xmm4\n\t"\
            "palignr $"#x", %%xmm2, %%xmm3\n\t"\
            "palignr $"#x", %%xmm1, %%xmm2\n\t"\
            "palignr $"#x", %%xmm0, %%xmm1\n\t"\
            "palignr $"#x", %%xmm8, %%xmm0\n\t"\
            "pshufd  $228, %%xmm0, %%xmm8\n\t"\
            "pshufd  $228, %%xmm1, %%xmm0\n\t"\
            "pshufd  $228, %%xmm2, %%xmm1\n\t"\
            "pshufd  $228, %%xmm3, %%xmm2\n\t"\
            "pshufd  $228, %%xmm4, %%xmm3\n\t"\
            "pshufd  $228, %%xmm5, %%xmm4\n\t"\
            "pshufd  $228, %%xmm6, %%xmm5\n\t"\
            "pshufd  $228, %%xmm7, %%xmm6\n\t"\
            "pshufd  $228, %%xmm9, %%xmm7\n\t"
#endif
          
#define PIXEL_LOOP_128(x)\
            template <>\
            DECLSPEC_FORCEINLINE inline void pixel_loop##x<128>(uint8_t* diag,  uint8_t* cube, int width)\
            {\
                const int max_disparity = 128;\
                int ii=0;\
                __asm__ __volatile__ (\
                    "movdqa %0, %%xmm0\n\t"\
                    "movdqa %1, %%xmm1\n\t"\
                    "movdqa %2, %%xmm2\n\t"\
                    "movdqa %3, %%xmm3\n\t"\
                    "movdqa %4, %%xmm4\n\t"\
                    "movdqa %5, %%xmm5\n\t"\
                    "movdqa %6, %%xmm6\n\t"\
                    "movdqa %7, %%xmm7\n\t"\
                    "pcmpeqd %%xmm9, %%xmm9\n\t"\
                    LRLOOP128(x)\
                : :  "m" (*( cube )), "m" (*( cube+16 )), "m" (*( cube+32 )), "m" (*( cube+48 )), "m" (*( cube+64 )), "m" (*( cube+80 )), "m" (*( cube+96 )),  "m" (*( cube+112 ))  : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7"  );\
                \
                cube += max_disparity;\
                for ( int j = 1; j < width; j++, cube += max_disparity)\
                {\
                    __asm__ __volatile__ (\
                        "movdqa %0, %%xmm9\n\t"\
                        "movdqa %1, %%xmm10\n\t"\
                        "movdqa %2, %%xmm11\n\t"\
                        "movdqa %3, %%xmm12\n\t"\
                        "movdqa %4, %%xmm13\n\t"\
                        "movdqa %5, %%xmm14\n\t"\
                        "movdqa %6, %%xmm15\n\t"\
                        "pminub %%xmm9, %%xmm0\n\t"\
                        "movdqa %7, %%xmm9\n\t"\
                        "pminub %%xmm10, %%xmm1\n\t"\
                        "pminub %%xmm11, %%xmm2\n\t"\
                        "pminub %%xmm12, %%xmm3\n\t"\
                        "pminub %%xmm13, %%xmm4\n\t"\
                        "pminub %%xmm14, %%xmm5\n\t"\
                        "pminub %%xmm15, %%xmm6\n\t"\
                        "pminub %%xmm9, %%xmm7\n\t"\
                        "pcmpeqd %%xmm9, %%xmm9\n\t"\
                        LRLOOP128(x)\
                : :  "m" (*( cube )), "m" (*( cube+16 )), "m" (*( cube+32 )), "m" (*( cube+48 )), "m" (*( cube+64 )), "m" (*( cube+80 )), "m" (*( cube+96 )),  "m" (*( cube+112 ))   : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5",  "%xmm6", "%xmm7", "%xmm8",  "%xmm9", "%xmm10", "%xmm11", "%xmm12", "%xmm13", "%xmm14",  "%xmm15");\
                    if (!((j+1) % (16/x)))\
                    {\
                        __asm__ __volatile__ (    "movdqa %%xmm8, %0\n\t":  "=m"(*(diag+ii)): : "%xmm0");\
                        ii += 16;\
                    }\
                }\
                \
                if (width % (16/x))\
                {\
                    for ( int j = 0; j <16/x - (width % (16/x)); j++)\
                    {\
                        __asm__ __volatile__ (\
                        LRLOOP128(x)\
                        : :   : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5", "%xmm6", "%xmm7","%xmm8", "%xmm9"  );\
                    }\
                    __asm__ __volatile__ (    "movdqa %%xmm8, %0\n\t":  "=m"(*(diag+ii)): : "%xmm0");\
                    ii += 16;\
                }\
                \
                __asm__ __volatile__ (\
                    "movdqa %%xmm0, %0\n\t"\
                    "movdqa %%xmm1, %1\n\t"\
                    "movdqa %%xmm2, %2\n\t"\
                    "movdqa %%xmm3, %3\n\t"\
                    "movdqa %%xmm4, %4\n\t"\
                    "movdqa %%xmm5, %5\n\t"\
                    "movdqa %%xmm6, %6\n\t"\
                    "movdqa %%xmm7, %7\n\t"\
                :  "=m"(*(diag+ii)), "=m"(*(diag+ii+16)), "=m"(*(diag+ii+32)), "=m"(*(diag+ii+48)), "=m"(*(diag+ii+64)), "=m"(*(diag+ii+80)), "=m"(*(diag+ii+96)), "=m"(*(diag+ii+112)): : "%xmm0", "%xmm1", "%xmm2",  "%xmm3", "%xmm4", "%xmm5",  "%xmm6", "%xmm7", "%xmm8");\
            }
            
            PIXEL_LOOP_16(1)
            PIXEL_LOOP_16(2)
            PIXEL_LOOP_16(4)
            PIXEL_LOOP_32(1)
            PIXEL_LOOP_32(2)
            PIXEL_LOOP_32(4)
            PIXEL_LOOP_48(1)
            PIXEL_LOOP_48(2)
            PIXEL_LOOP_48(4)
            PIXEL_LOOP_64(1)
            PIXEL_LOOP_64(2)
            PIXEL_LOOP_64(4)
            PIXEL_LOOP_80(1)
            PIXEL_LOOP_80(2)
            PIXEL_LOOP_80(4)
            PIXEL_LOOP_96(1)
            PIXEL_LOOP_96(2)
            PIXEL_LOOP_96(4)
            PIXEL_LOOP_112(1)
            PIXEL_LOOP_112(2)
            PIXEL_LOOP_112(4)
            PIXEL_LOOP_128(1)
            PIXEL_LOOP_128(2)
            PIXEL_LOOP_128(4)
            
            template <int max_disparity>
            DECLSPEC_FORCEINLINE inline void ConsistencyCheck(uint8_t* m_disparityOutputCube, float* dstBuffer, uint8_t* diag, int width, int m_disp_min, int downsample_ratio)
            {
            //  float invratio=1.0f;// 1.0f/downsample_ratio  porta a risultati errati x d=63
              
              if(downsample_ratio ==1)  
                 lrcheck::pixel_loop1<max_disparity>(diag, m_disparityOutputCube, width); 
              else
              if(downsample_ratio ==2)
              {    
                 lrcheck::pixel_loop2<max_disparity>(diag, m_disparityOutputCube, width);
            //     invratio=0.5f;
              }  
              else
              if(downsample_ratio ==4)  
              {    
                 lrcheck::pixel_loop4<max_disparity>(diag, m_disparityOutputCube, width);
               //  invratio=0.25f;
              }  
              
             
              for ( int j = 0; j < width; j++, m_disparityOutputCube += max_disparity, dstBuffer++)
              {                                                 
                   // int disp = *dstBuffer + 0.5f;
                  //  int disp = roundf( *dstBuffer);
//                    int disp;
//                    __asm__ __volatile__ (
//                   "cvtss2si  %1, %%eax\n\t"
//                   "mov   %%eax, %0\n\t"
//                   :  "=m"(disp): "m" (*dstBuffer) : "%eax");
//                     int disp = lrintf(*dstBuffer);
//                     
//                     uint8_t cost = m_disparityOutputCube[disp];                           
//                     
//                     uint8_t min_cost = diag[j + disp];
//                       
//                     if( (cost == min_cost) || ( j && min_cost == m_disparityOutputCube[disp - ( max_disparity - 1 )] ) || (j!=width-1 && min_cost == m_disparityOutputCube[disp + ( max_disparity - 1 )]))                            
//                       *dstBuffer += m_disp_min;
//                     else
//                       *dstBuffer = DISPARITY_UNKNOWN;
                    if(*dstBuffer== DISPARITY_UNKNOWN) 
                      continue;
                                
                    int disp = lrintf(*dstBuffer);
                                            
                    uint8_t cost = m_disparityOutputCube[disp];                           
                    
                    uint8_t min_cost = diag[downsample_ratio*j + disp];
                                                
                    if((cost == min_cost) || (j && min_cost == m_disparityOutputCube[disp - (max_disparity - downsample_ratio)]) || (j != width - 1 && min_cost == m_disparityOutputCube[disp + (max_disparity - downsample_ratio)]))
                      *dstBuffer = (*dstBuffer + m_disp_min)/downsample_ratio;//* invratio;                    
                    else
                      *dstBuffer = DISPARITY_UNKNOWN;
                    
                   
//                      if (cost == min_cost)
//                          *dstBuffer += m_disp_min;
//                      else
//                         if( (!j || min_cost != m_disparityOutputCube[ disp - ( max_disparity - 1 )]) && 
//                             (j == width - 1  ||    min_cost != m_disparityOutputCube[ disp + ( max_disparity - 1 )])
//                           )
//                             *dstBuffer = DISPARITY_UNKNOWN;
//                      else
//                      {
//                             int stride2 =  disp - 2 * (max_disparity - 1);
//                             int stop = std::min(j - 1, max_disparity - disp - 2);
//                             for ( int k =  0; k < stop; k++, stride2 -= max_disparity - 1 )
//                                 if ( m_disparityOutputCube[stride2] < cost )
//                                     goto INVALID;                                      
//                                 
//                             stride2 =  disp + 2 * (max_disparity - 1);  
//                             stop = std::min (width - (j + 2), disp - 2 + 1);
//                             for ( int k = 0; k < stop; k++, stride2 += max_disparity - 1 )
//                                 if ( m_disparityOutputCube[stride2] < cost )
//                                    goto INVALID;
//                                 
//                             *dstBuffer += m_disp_min;
//                             continue;
// 
//                         INVALID:
// 
//                             *dstBuffer = DISPARITY_UNKNOWN;
// 
//                      }
              }
        }

        }
    }    
}
#endif
