#ifndef _EXTENDED_KALMAN_FILTER_H
#define _EXTENDED_KALMAN_FILTER_H

/** @file
 * @brief include headers for using of EKF
 * */

#include "Types.h"
#include "detail/ExtendedKalmanFilter.hxx"
#include "KalmanFilter.h"

#endif
