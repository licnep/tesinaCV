/** @file Hough.h
  * @brief Hough and Experimental Hough template
  * @author Paolo Medici
  **/
#ifndef _HOUGH_H
#define _HOUGH_H

#include <stdexcept>

#include <boost/math/tr1.hpp>
#include <boost/concept_check.hpp>

#include <Processing/Vision/CImage/gold_proc_cimage_export.h>
#include <Data/Math/Rects.h>
#include <Data/Math/Lines.h>

namespace hough {

/** Select any value over a threshold */  
template<class T>
struct Threshold {
  T m_th;
  public:
    Threshold() : m_th(1) { }
    
    void SetThreashold(T th) { m_th = th; }
    
    T operator()(T t) const
    {
      return (t > m_th) ? 1 : 0;
    }
};

/** Select any value different from Zero */
template<class T>
struct NotZero {
  public:
    
    int operator()(T t) const
    {
      return (t != T(0) ) ? 1 : 0;
    }
};

/** Cumulative Hough: use value as accumulation buffer */
template<class T>
struct Cumulative {
  public:
    
    T operator()(T t) const
    {
      return t;
    }
};

/**
 A typical 2-dimension Hough usefull to detect Line with equation
  
  x * cos(theta) + y * sin(theta) = rho
  
 (polar form)
 
 @param T type of input image (in order to spawn the threshold policy)
 @param _Policy type of policy used to threshold the image
 @param _AccumType type of accumulator (default is the CumulativeType of T)
 \code
 hough::HoughLine2<unsigned char, hough::NotZero> hbg;
 hough::HoughLine2<unsigned char, hough::Threshold> hbg;
 hough::HoughLine2<unsigned char, hough::Cumulative> hbg;
 hough::HoughLine2<float, hough::Cumulative> hbg;
 hough::HoughLine2<unsigned char, hough::NotZero, uint32_t> hbg;
 \endcode
**/
template<class T, template<typename> class _Policy, class _AccumType = typename cimage::PixelTraits<T>::CumulativeType >
class HoughLine2: public _Policy<T> {
  public:
  typedef _AccumType AccumType;

  private:
  /// hough buffer geometry
  unsigned int m_width, m_height;
  AccumType * m_buffer;
  double m_angleMin, m_angleMax, m_angleStep;
  double m_rhoFactor;
  public:
    
    HoughLine2() : m_buffer(0) { }
    
    /// create Hough Accumulator Object
    HoughLine2(double angleMin, double angleMax, unsigned int HoughWidth, unsigned int HoughHeight, double rhoFactor = 1.0) : m_buffer(0) {
      Init(angleMin, angleMax, HoughWidth, HoughHeight, rhoFactor);
    }
    
    ~HoughLine2()
    {
      delete [] m_buffer;
    }
    
    /** Initialize Hough transform 
     * @param angleMin Minimum angle
     * @param angleMax Maximum angle
     * @param HoughWidth Hough Table width (rho quantization). Set to sqrt(maxW*maxW + maxH*maxH)
     * @param HoughHeight Hough Table height (angle quantization)
     * @param rhoFactor rho compression factor
     * 
     * \code
     * hough.Init(0, M_PI, 100, 180);
     * \endcode
     */
    void Init(double angleMin, double angleMax, unsigned int HoughWidth, unsigned int HoughHeight, double rhoFactor = 1.0)
    {
    if(HoughHeight == 0 || HoughWidth == 0)
      throw(std::runtime_error("Init called with invalid parameters"));
    delete [] m_buffer;
    m_angleMin = angleMin;
    m_angleMax = angleMax;
    m_angleStep = (angleMax - angleMin) / HoughHeight;
    m_width = HoughWidth;
    m_height = HoughHeight;
    m_rhoFactor = rhoFactor;
    m_buffer = new AccumType[m_width * m_height];
    Clear();
    }

    /** Clear the Hough Table */
    void Clear()
    {
      if(m_buffer==0)
        throw std::runtime_error("Hough not initialized.");
      for(int i =0;i<m_width*m_height;++i)
	  m_buffer[i] = AccumType();
    }
    
    /** Execute Hough on a image buffer.
     *  Internal function: user should use the operator() version of this method
     * 
     * @param srcImage top-left pointer of image area to be processed
     * @param width the image stride (can be different from area width)
     * @param area the coordinate where process hough
     * 
     * @note used internally, it is pubblic, but normally is not called directly. 
     * 
     * \code
     *  // search on all buffer
     *  obj.Process(my_buffer, width, Rect2i(0,0, width, height));
     * 
     *  // search on buffer subpart. In this case the meaning of polar line is refered to (0,0)
     *  obj.Process(my_buffer, width, Rect2i(left,top,right,bottom));
     * 
     *  // search on buffer subpart moving the origin of reference frame. Polar line is refered to (left,top)
     *  obj.Process(my_buffer+left + top*width, width, Rect2i(0,0,right-left,bottom-top));
     * \endcode
     * 
     * @note Process do not clear the Hough Table. It is possible to call multiple times Process in order to Accumulate different hough data
     */
    void Process(const T *srcImage, long width, const math::Rect2i & area)
    {
      if(m_buffer==0)
        throw std::runtime_error("Hough not initialized.");

    const T * src;
    double _c0, _s0;
    double sa, ca;
    double fy = area.y0 * m_rhoFactor;
    
    // precompute sa,ca_c0,_s0
    sa = sin(m_angleStep);
    ca = cos(m_angleStep);

    _c0 = cos(m_angleMin);
    _s0 = sin(m_angleMax);

    /* Hough Incremental:
       \forall (x,y)
       rho = x * cos(theta) + y * sin(theta)
       theta = [m_angleMin, m_angleMax]     
       theta_{k+1} = theta_{k} + m_angleStep;
       rho_{k+1} = x * cos(theta_{k}) * sin(m_angleStep) + y * sin(theta_{k}) * cos(m_angleStep)
      */
    
    // mi sposto all'angolo alto sinistro dell'area da esaminare
    srcImage += area.y0 * width + area.x0;
    // Fill the destination buffer
    for (int y=area.y0; y<area.y1; y++)
    {
      double fx = area.x0 * m_rhoFactor;
      src = srcImage;
      srcImage += width;
      for (int x=area.x0; x<area.x1; x++)
      {
	AccumType t = _Policy<T>::operator()(*src++);
	if (t) 
	{
	  int j = m_height;
	  double c0 = _c0;
	  double s0 = _s0;
	  double c1, s1;
	  double theta = m_angleMin;
	  AccumType *acc = m_buffer;
	  do {
	    int ro = (int) boost::math::tr1::round(fx*c0 + fy*s0);// boost::math::tr1::round(fx*c0 + fy*s0);
	    // tips: si puo' fare una interpolazione con i float
	    if ((ro>=0) && (ro<(int)m_width))
	      acc[ro]+=t; // si potrebbe anche usare il valore di input per fare un hough-x
	  c1 = c0 * ca - s0 * sa;
	  s1 = s0 * ca + c0 * sa;
	  c0 = c1;
	  s0 = s1;
	  acc += m_width;
	  } while(--j);
	}
	fx += m_rhoFactor;
      }
      fy += m_rhoFactor;
      
    }
    
    }

    /** Process a whole image buffer
      * @param obj pointer of top-left pixel of buffer
      * @param width buffer width
      * @param height buffer height
      * 
      * \code
      *  hbg(m_BinBuffer, m_bufferWidth, m_bufferHeight);
      * \endcode
      * @note Hough permette di processare in maniera incrementale il buffer.
      *       Per questo motivo l'operator() non pulisce il buffer accumulatore: chiamare esplicitamente la Clear
      * */
    void operator() (const T *obj, unsigned int width, unsigned int height)
    {
      Process(obj, width, math::Rect2i(0,0,width,height));
    }
    
    /** Process a subpart of image buffer
      * @param obj pointer of top-left pixel of buffer
      * @param width buffer stride: the delta pointer between two rows in the buffer
      * @param rect a rect that is the subpart where process the image
      * 
      * @note user should verify that rect is totally contained inside the image memory
      * \code
      * hbg(m_BinBuffer, m_bufferWidth, math::Rect2i(left,top,right,bottom) );
      * \endcode
      * @note Hough permette di processare in maniera incrementale il buffer.
      *       Per questo motivo l'operator() non pulisce il buffer accumulatore: chiamare esplicitamente la Clear
      * */
    void operator() (const T *obj, long stride, const math::Rect2i & rect)
    {
      Process(obj, stride, rect);
    }
    
    /// Process a whole CImage
    /// \code
    /// hbg(m_BinImage);
    /// \endcode
    /// @note Hough permette di processare in maniera incrementale il buffer.
    ///       Per questo motivo la l'operator() non pulisce il buffer accumulatore: chiamare esplicitamente la Clear
    void operator() (const cimage::TImage<T> & obj)
    {
      Process(obj.Buffer(), obj.W(), math::Rect2i(0,0,obj.W(),obj.H()));
    }

    /** Process a CImage SubPart
      * @note user should verify that @a area is totally contained inside the image memory
      * \code
      * hbg(m_BinImage, math::Rect2i(10,10, 40,40) );
      * \endcode
      * @note this method do not clear the Hough Table. It is possible to call multiple times Process in order to Accumulate different hough data, or manually call Clear method.
      * */
    void operator() (const cimage::TImage<T> & obj, const math::Rect2i & area)
    {
      Process(obj.Buffer(), obj.W(), area);
    }
    
    /** Process a cimage subpart using an additional origin to set (0,0) of Hough Transform
      *  @note origin changes the meaning of polar line returned by this application
      *  @note user should verify that @a area is totally contained inside the image memory
      * \code
      * // place the origin at the center of ROI
      * obj(Image, math::Rect2i(100, 50, 120, 70), math::Point2i(110, 60));
      * 
      * // place the origin on the bottom-left of the RO
      * obj(Image, math::Rect2i(100, 50, 120, 70), math::Point2i(100, 50));
      * \endcode
      *
      * @note this method do not clear the Hough Table. It is possible to call multiple times Process in order to Accumulate different hough data, or manually call Clear method.
      * */
    void operator() (const cimage::TImage<T> & obj, const math::Rect2i & area, const math::Point2i & origin)
    {
      math::Rect2i area2;
      area2.x0 = area.x0 - origin.x;
      area2.y0 = area.y0 - origin.y;
      area2.x1 = area.x1 - origin.x;
      area2.y1 = area.y1 - origin.y;
      
      Process(obj.Buffer() + origin.x + origin.y * obj.W(), obj.W(), area2);
    }
    
    /** Convert row index to angle */
    inline double RowToAngle(int row) const { return m_angleMin + ((row * (m_angleMax - m_angleMin))/m_height); }

    /** convert an angle to index inside Hough Table */
    inline double AngleToRow(double angle) const { return (angle - m_angleMin) * m_height / (m_angleMax - m_angleMin); }

    /** Convert column index to the corresponding rho factor */
    inline double ColumnToRho(int col) const { return col / m_rhoFactor; }
    
    /** convert a point in hough to a line equation 
     * @note according to the origin of reference frame the polar line can have different response
     */
    inline math::PolarLine<double> PointToLine(int i, int j) {
      return math::PolarLine<double>( ColumnToRho(i), RowToAngle(j) );
    }

    /// return the inner accumulator buffer
    inline const AccumType *GetBuffer() const {return m_buffer; }
    /// return the inner accumulator buffer
    inline AccumType *GetBuffer() {return m_buffer; }
    
    /// return the min angle in the hough search range
    inline double AngleMin() const { return m_angleMin; }
    /// return the max angle in the hough search range
    inline double AngleMax() const { return m_angleMax; }
    /// return the angle step, the value represented by a row in the hough accumulator
    inline double AngleStep() const { return m_angleStep; }
    
    /// return the buffer geometry
    inline int W() const { return m_width; }
    /// return the buffer geometry
    inline int H() const { return m_height; }
   
};

}
#endif
