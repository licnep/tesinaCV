#ifndef _STATE_OBSERVER_H
#define _STATE_OBSERVER_H

/** @file
 * @brief implements base State Observer for Kalman Filters
 * */


#include "Types.h"
#include <Eigen/Core>

namespace state_estimation {

/** A general purpose linear (o linearized) observe model
 * z_k = H_k * x_k + noise(R_k)
 * 
 * @param _ObservationSize output size
 * @param _StateSize	  state size
 * 
 * Extended Kalman Filter User have to implement Update and h methods:
\code
class MyEKFObserver: public state_estimation::LinearObserver<double> {
  
public:
  MyEKFObserver() : state_estimation::LinearObserver<double>(2,1) { }
   
  template<class ObserverType, class StateType>
  void h(ObserverType &z, const StateType &x) 
  { 
    // set z from x
  }

  template<class StateType>
  void Update(const StateType &x) 
  { 
    // update ObservationMatrix from x
  }
  
};

\endcode
 * */
template<class _Scalar, int _ObservationSize = Eigen::Dynamic, int _StateSize = Eigen::Dynamic>
class LinearObserver {
public:
  typedef LinearizedImplementation Implementation;

  typedef Eigen::Matrix<_Scalar, _ObservationSize, 1> 		ObservedType;
  typedef Eigen::Matrix<_Scalar, _ObservationSize, _StateSize> MatrixHType;
  typedef Eigen::Matrix<_Scalar, _ObservationSize, _ObservationSize> MatrixRType;
  
  typedef _Scalar ScalarType;

  enum { StateSizePolicy = _StateSize,
	 ObservationSizePolicy = _ObservationSize
  };
  
private:
  
  int m_state_size; // to cache size
  int m_output_size; // to cache size

protected:

  /// observation matrix
  MatrixHType H; 
  /// noise matrix
  MatrixRType R;
  
public:
  LinearObserver() : m_state_size( (_StateSize!=Eigen::Dynamic) ? _StateSize : 1  ), m_output_size( (_ObservationSize!=Eigen::Dynamic) ? _ObservationSize : 1 ) { }
  /** @param observation_size dimensione osservazione
   *  @param state_size dimensione stato */
  LinearObserver(int observation_size, int state_size) : H(observation_size,state_size), R(observation_size,observation_size), m_state_size(state_size), m_output_size(observation_size) { }
  
  MatrixHType & ObservationMatrix() { return H; }
  const MatrixHType & ObservationMatrix() const { return H; }

  MatrixRType & ObservationNoiseMatrix() { return R; }
  const MatrixRType & ObservationNoiseMatrix() const { return R; }
  
  int ObservationSize() const { return m_output_size; }
  
  /** change the state size */
  void StateSize(int n) { m_state_size = n; H.resize(m_output_size, n);  }
  /** change the input size */
  void ObservationSize(int n) { m_output_size = n; H.resize(n, m_state_size); R.resize(m_output_size, m_output_size); }
  
  template<class ObserverType, class StateType>
  void h(ObserverType & z, const StateType & x)
  {
    z = H * x;
  }

  /** does nothing */
  template<class StateType>
  inline void Update(const StateType & s) { }
};

/** An unscented/sigma point kalman filter observer
 * 
 * User have to implemenet h method:
\code
class MySPKFObserver: public state_estimation::FunctionalObserver<double> {
public:
  MySPKFObserver() : state_estimation::FunctionalObserver<double>(2) { }
  
  template<class StateType>
  void Update(const StateType &x) { }
  
  template<class ObservationType, class StateType>
  void h(ObservationType &z, const StateType &x) { 
    // set h from x
  } 
};
\endcode
* */
template<class _Scalar, int _ObservationSize = Eigen::Dynamic>
class FunctionalObserver {
public:
  typedef UnscentedImplementation Implementation;

  typedef Eigen::Matrix<_Scalar, _ObservationSize, 1> ObservedType;
  typedef Eigen::Matrix<_Scalar, _ObservationSize, _ObservationSize> MatrixRType;
  
  typedef _Scalar ScalarType;
  
  // 
  enum { StateSizePolicy = Eigen::Dynamic,
	 ObservationSizePolicy = _ObservationSize
  };
  
private:
  
  /// noise matrix
  MatrixRType R;
  
public:
  FunctionalObserver() : R( (_ObservationSize!=Eigen::Dynamic) ? _ObservationSize : 1, (_ObservationSize!=Eigen::Dynamic) ? _ObservationSize : 1 ) { }
  /** Initialize the observer with the observation size */
  FunctionalObserver(int observation_size) : R(observation_size, observation_size) { }

  MatrixRType & ObservationNoiseMatrix() { return R; }
  const MatrixRType & ObservationNoiseMatrix() const { return R; }
  
  void StateSize(int n) { }
  
  /// return the Observed Size
  int ObservationSize() const { return R.cols(); }
  
  /** change the observed size */
  void ObservationSize(int n) { R.resize(n, n); }
  
  /// User have to implement it
  template<class ObserverType, class StateType>
  inline void h(ObserverType & z, const StateType & x);

  /** does nothing */
  template<class StateType>
  inline void Update(const StateType & s) { }
};

}

#endif
