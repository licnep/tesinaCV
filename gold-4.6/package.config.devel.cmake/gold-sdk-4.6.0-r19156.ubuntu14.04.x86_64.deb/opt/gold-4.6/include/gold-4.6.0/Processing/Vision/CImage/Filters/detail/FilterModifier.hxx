#ifndef _FILTER_MODIFIER_HXX
#define _FILTER_MODIFIER_HXX

/** @file
 * @brief implementation detail for FilterModifier.h
 * */

#include <cmath>

/////// ADDITIONAL MACRO USED IN FILTER  ////////////
// si potranno rimuovere con il c++0x
#define static_abs(x)   (((x)>0)   ? (x) : -(x))
#define static_max(a,b) (((a)>(b)) ? (a) : (b))
#define static_min(a,b) (((a)<(b)) ? (a) : (b))
#define static_sgn(x)	(((x)>0) ? (1) : ((x)<0) ? (-1) : 0)

namespace cimage {

 namespace filter {
  
  namespace detail {
    
/// metodo stub per trasformare @a val in -1,0,1 a seconda della soglia in th
template<int th, typename S>
inline int sign ( const S val )
{
  return  (val >= S(th)) ? (1) : (val <= S(-th)) ? -1 : 0 ;
}
              
/// filtro "ternarizzatore" uint8_t
template<int th, typename S>
inline uint8_t tern ( const S val )
{
  return  (val > S(th)) ? (254) : (val < S(-th)) ? 0 : 127 ;
}

/// filtro clamp a uint8_t
template<typename S>
inline uint8_t clamp8u ( const S val )
{
  return  (val > S(255)) ? (255) : (val < S(0)) ? 0 : (uint8_t)(val);
}

/// filtro clamp a int8_t
template<typename S>
inline int8_t clamp8s ( const S val )
{
  return  (val > S(127)) ? (127) : (val < S(-128)) ? -128 : (int8_t)(val);
}

/// absolute binarize 
template<typename S>
inline uint8_t absbin ( S val, S th )
{
  return  (val < -th || val > th) ? 255 : 0;
}

/// filtro quantizzatore  
template<int n>
inline int qtz(int v)
{
  return v - (v % n);
}

/// modulo 
template<class X, class Y>
inline float module(X x, Y y) { return std::sqrt((float)x*x+(float)y*y); }

/// fase
template<class X, class Y>
inline float phase(X x, Y y) { return std::atan2(y,x); }

/// packed
template<class X, class Y>
inline std::pair<int,float> module2_phase(X x, Y y) {
	return std::pair<int,float>( x*x+y*y, std::atan2(y,x) );
        }

/// packed
template<class X, class Y>
inline std::pair<int,float> module_phase(X x, Y y) {
	return std::pair<int,float>( std::sqrt(x*x+y*y), std::atan2(y,x) );
        }

/// calcola l'"hash" per immagini di gradienti
template<class X, class Y>
inline uint8_t hash(X x, Y y, int th) 
{
  uint8_t value = 0;
  if(x<-th)
      value |= 1;
  else
  if(x>th)
      value |= 2;
  if(y<-th)
      value |= 4;
  else
  if(y>th)
      value |= 8;
  return value;
}
  
/// pack 2 uin8_t in a single uint16_t
inline uint16_t pack8u16u(uint8_t x, uint8_t y)
  {
    return (x<<8)|y;
  }
  
  
  }
}

}

#endif
