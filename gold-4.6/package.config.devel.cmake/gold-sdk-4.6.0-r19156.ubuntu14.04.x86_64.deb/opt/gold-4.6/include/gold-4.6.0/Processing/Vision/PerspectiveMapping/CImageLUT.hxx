#ifndef _CIMAGE_LUT_HXX
#define _CIMAGE_LUT_HXX

#include "ImageLUT.h"
#include <Data/CImage/PixelTraits/PixelTraits.h>
#include <Libs/Logger/Log.h>

template<class T>
void ImageLUT::Apply(T *dst,const T *src, const math::Rect2i* area)
{
ApplyToImage(reinterpret_cast<unsigned char *>(dst), reinterpret_cast<const unsigned char *>(src), cimage::PixelTraits<T>::BytePerPixel(), area);
}

template<class T>
void ImageLUT::Apply(cimage::TImage<T> &dst,const cimage::TImage<T> &src, const math::Rect2i* area)
{
Resize(dst, width,height);
 if(src.W() != srcWidth || src.H() != srcHeight)
   log_warn << " the source image (" << src.W() << 'x' << src.H() << ") have geometry different from LUT (" << srcWidth << 'x' << srcHeight <<"). Normally this is an error." << std::endl;
 
 {
 Apply(dst.Buffer(), src.Buffer(), area);
 }
 
}


#endif
