#ifndef MEDIAN_FILTER_HXX
#define MEDIAN_FILTER_HXX

#ifdef __SSE2__
  #include <xmmintrin.h>
#endif

#ifdef __SSE4_1__
  #include <smmintrin.h>
#endif

#ifdef ENABLE_IPP
  #include <boost/mpl/vector.hpp>
  #include <boost/mpl/contains.hpp>
  #include <boost/type_traits/is_same.hpp>
  #include <boost/utility/enable_if.hpp>
  #include <ippi.h>
#endif

namespace cimage
{

namespace detail
{
    
    template<class T> 
    struct MinMax
    {
        typedef T value_type;
        typedef T arg_type;
        enum { SIZE = 1 };
        arg_type load(const value_type* ptr) { return *ptr; }
        void store(value_type* ptr, arg_type val) { *ptr = val; }
        void operator()(arg_type& a, arg_type& b) const
        {         
            arg_type t = a;
            a = std::min(a, b);
            b = std::max(b, t);
        }
    };
 
    
    template<class T> 
    struct MinMaxVect;
        
#ifdef __SSE2__ 
        
    template<>
    struct MinMaxVect<uint8_t>
    {
        typedef uint8_t value_type;
        typedef __m128i arg_type;
        enum { SIZE = 16 };
        arg_type load(const value_type* ptr) { return _mm_loadu_si128((const __m128i*)ptr); }
        void store(value_type* ptr, arg_type val) { _mm_storeu_si128((__m128i*)ptr, val); }
        void operator()(arg_type& a, arg_type& b) const
        {
            arg_type t = a;
            a = _mm_min_epu8(a, b);
            b = _mm_max_epu8(b, t);            
        }
    };
    
#ifdef __SSE4_1__ 
    template<>
    struct MinMaxVect<int8_t>
    {
        typedef int8_t value_type;
        typedef __m128i arg_type;
        enum { SIZE = 16 };
        arg_type load(const value_type* ptr) { return _mm_loadu_si128((const __m128i*)ptr); }
        void store(value_type* ptr, arg_type val) { _mm_storeu_si128((__m128i*)ptr, val); }
        void operator()(arg_type& a, arg_type& b) const
        {
            arg_type t = a;
            a = _mm_min_epi8(a, b);
            b = _mm_max_epi8(b, t);
            
        }
    };
#else
    template<>
    struct MinMaxVect<int8_t> : public MinMax<int8_t>{}; 
#endif

    template<>
    struct MinMaxVect<uint16_t>
    {
        typedef uint16_t value_type;
        typedef __m128i arg_type;
        enum { SIZE = 8 };
        arg_type load(const value_type* ptr) { return _mm_loadu_si128((const __m128i*)ptr); }
        void store(value_type* ptr, arg_type val) { _mm_storeu_si128((__m128i*)ptr, val); }
        void operator()(arg_type& a, arg_type& b) const
        {
            arg_type t = _mm_subs_epu16(a, b);
            a = _mm_subs_epu16(a, t);
            b = _mm_adds_epu16(b, t);
        }
    };

        
    template<>
    struct MinMaxVect<int16_t>
    {
        typedef int16_t value_type;
        typedef __m128i arg_type;
        enum { SIZE = 8 };
        arg_type load(const value_type* ptr) { return _mm_loadu_si128((const __m128i*)ptr); }
        void store(value_type* ptr, arg_type val) { _mm_storeu_si128((__m128i*)ptr, val); }
        void operator()(arg_type& a, arg_type& b) const
        {
            arg_type t = a;
            a = _mm_min_epi16(a, b);
            b = _mm_max_epi16(b, t);
        }
    };    

    template<>
    struct MinMaxVect<float>
    {
        typedef float value_type;
        typedef __m128 arg_type;
        enum { SIZE = 4 };
        arg_type load(const value_type* ptr) { return _mm_loadu_ps(ptr); }
        void store(value_type* ptr, arg_type val) { _mm_storeu_ps(ptr, val); }
        void operator()(arg_type& a, arg_type& b) const
        {
            arg_type t = a;
            a = _mm_min_ps(a, b);
            b = _mm_max_ps(b, t);
        }
    };

#else    
    template<>
    struct MinMaxVect<uint8_t> : public MinMax<uint8_t>{};
    template<>
    struct MinMaxVect<int8_t> : public MinMax<int8_t>{};
    template<>
    struct MinMaxVect<uint16_t> : public MinMax<uint16_t>{};
    template<>
    struct MinMaxVect<int16_t> : public MinMax<int16_t>{};
    template<>
    struct MinMaxVect<float> : public MinMax<float>{};
#endif
    
    
    template<class S>
    void Median3x3(const S* input, S* output, uint32_t width, uint32_t height, long source_stride)
    {
       
        //larghezza bordo a sx e dx dell'immagine che non devo elaborare ma semplicemente azzerrare
        const uint32_t left = 1;
        const uint32_t right = 1;
        detail::MinMaxVect<S> MinMaxSIMD;
        detail::MinMax<S> MinMax; 

        const S *currRow = input, *prevRow = input - source_stride, *nextRow = input + source_stride;
         
        for(uint32_t k = 0; k < height; k++)
        {
            for(uint32_t h = 0; h < left; h++)
                *output++= 0;

               uint32_t j;
               for (j = left ; j < (width-right) - detail::MinMaxVect<S>::SIZE - 1; j += detail::MinMaxVect<S>::SIZE )
               {
                    typename detail::MinMaxVect<S>::arg_type p0 = MinMaxSIMD.load ( prevRow + j - 1 ), p1 =  MinMaxSIMD.load ( prevRow + j ), p2 =  MinMaxSIMD.load ( prevRow + j + 1 );
                    typename detail::MinMaxVect<S>::arg_type p3 = MinMaxSIMD.load ( currRow + j - 1 ), p4 =  MinMaxSIMD.load ( currRow + j ), p5 =  MinMaxSIMD.load ( currRow + j + 1 );
                    typename detail::MinMaxVect<S>::arg_type p6 = MinMaxSIMD.load ( nextRow + j - 1 ), p7 =  MinMaxSIMD.load ( nextRow + j ), p8 =  MinMaxSIMD.load ( nextRow + j + 1 );

                    MinMaxSIMD ( p1, p2 );
                    MinMaxSIMD ( p4, p5 );
                    MinMaxSIMD ( p7, p8 );
                    MinMaxSIMD ( p0, p1 );
                    MinMaxSIMD ( p3, p4 );
                    MinMaxSIMD ( p6, p7 );
                    MinMaxSIMD ( p1, p2 );
                    MinMaxSIMD ( p4, p5 );
                    MinMaxSIMD ( p7, p8 );
                    MinMaxSIMD ( p0, p3 );
                    MinMaxSIMD ( p5, p8 );
                    MinMaxSIMD ( p4, p7 );
                    MinMaxSIMD ( p3, p6 );
                    MinMaxSIMD ( p1, p4 );
                    MinMaxSIMD ( p2, p5 );
                    MinMaxSIMD ( p4, p7 );
                    MinMaxSIMD ( p4, p2 );
                    MinMaxSIMD ( p6, p4 );
                    MinMaxSIMD ( p4, p2 );
                    MinMaxSIMD.store ( output, p4 );
                    output+=detail::MinMaxVect<S>::SIZE;

               }
               
               for (; j < (width-right); j ++)
               {
                    typename detail::MinMax<S>::arg_type p0 = MinMax.load ( prevRow + j - 1 ), p1 =  MinMax.load ( prevRow + j ), p2 =  MinMax.load ( prevRow + j + 1 );
                    typename detail::MinMax<S>::arg_type p3 = MinMax.load ( currRow + j - 1 ), p4 =  MinMax.load ( currRow + j ), p5 =  MinMax.load ( currRow + j + 1 );
                    typename detail::MinMax<S>::arg_type p6 = MinMax.load ( nextRow + j - 1 ), p7 =  MinMax.load ( nextRow + j ), p8 =  MinMax.load ( nextRow + j + 1 );

                    MinMax ( p1, p2 );
                    MinMax ( p4, p5 );
                    MinMax ( p7, p8 );
                    MinMax ( p0, p1 );
                    MinMax ( p3, p4 );
                    MinMax ( p6, p7 );
                    MinMax ( p1, p2 );
                    MinMax ( p4, p5 );
                    MinMax ( p7, p8 );
                    MinMax ( p0, p3 );
                    MinMax ( p5, p8 );
                    MinMax ( p4, p7 );
                    MinMax ( p3, p6 );
                    MinMax ( p1, p4 );
                    MinMax ( p2, p5 );
                    MinMax ( p4, p7 );
                    MinMax ( p4, p2 );
                    MinMax ( p6, p4 );
                    MinMax ( p4, p2 );
                    MinMax.store ( output++, p4 );

               }

            for(uint32_t h = 0; h < right; h++)
                *output++= 0;

            currRow += source_stride;
            prevRow += source_stride;
            nextRow += source_stride;
        }    
    }
       
    
}


///Queste versioni sono piu' lente delle corrispettive IPP

template<>
template<>
void TLocalFilter< kernel::MedianFilter< policy::FixedSize<3,3>, policy::All > >::render<int8_t, int8_t>(const int8_t* input, int8_t* output, uint32_t width, uint32_t height, long source_stride)
{
    detail::Median3x3(input, output, width, height, source_stride);
}

template<>
template<>
void TLocalFilter< kernel::MedianFilter< policy::FixedSize<3,3>, policy::All > >::render<uint8_t, uint8_t>(const uint8_t* input, uint8_t* output, uint32_t width, uint32_t height, long source_stride)
{
    detail::Median3x3(input, output, width, height, source_stride);
}

template<>
template<>
void TLocalFilter< kernel::MedianFilter< policy::FixedSize<3,3>, policy::All > >::render<int16_t, int16_t>(const int16_t* input, int16_t* output, uint32_t width, uint32_t height, long source_stride)
{
    detail::Median3x3(input, output, width, height, source_stride);
}

template<>
template<>
void TLocalFilter< kernel::MedianFilter< policy::FixedSize<3,3>, policy::All > >::render<uint16_t, uint16_t>(const uint16_t* input, uint16_t* output, uint32_t width, uint32_t height, long source_stride)
{
    detail::Median3x3(input, output, width, height, source_stride);
} 

template<>
template<>
void TLocalFilter< kernel::MedianFilter< policy::FixedSize<3,3>, policy::All > >::render<float, float>(const float* input, float* output, uint32_t width, uint32_t height, long source_stride)
{
    detail::Median3x3(input, output, width, height, source_stride);
} 



#ifdef ENABLE_IPP

/// Il filtro mediano Ipp funziona solo con maschera dispari

namespace  ipp
{            
    inline void ippiFilterMedian(const uint8_t* s, int source_stride, uint8_t* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterMedian_8u_C1R(s, source_stride, d, dest_stride, dstRoiSize, maskSize, anchor);
    }
    
    inline   void ippiFilterMedian(const int16_t* s, int source_stride, int16_t* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterMedian_16s_C1R(s, source_stride, d, dest_stride, dstRoiSize, maskSize, anchor);
    }
    
    inline void ippiFilterMedian(const uint16_t* s, int source_stride, uint16_t* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterMedian_16u_C1R(s, source_stride, d, dest_stride, dstRoiSize, maskSize, anchor);
    }
    
    inline void ippiFilterMedian(const RGB8* s, int source_stride, RGB8* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterMedian_8u_C3R((uint8_t*)s, source_stride, (uint8_t*)d, dest_stride, dstRoiSize, maskSize, anchor);
    }
    
    inline void ippiFilterMedian(const float* s, int source_stride, float* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterMedian_32f_C1R(s, source_stride, d, dest_stride, dstRoiSize, maskSize, anchor);
    }


 
    ///TODO: possibilita' di specializzare per TRGB<uint16_t>, TRGB<int16_t>, RGBA       
    template <class S, class D>
    struct MedianFilterIppSupportCheck :
            boost::mpl::and_<
            boost::mpl::bool_<boost::is_same<S, D>::value>,
            boost::mpl::contains<  boost::mpl::vector< uint8_t, int16_t, uint16_t, RGB8, float > , S> > {};
           
    template<class T, class S, class D>
    struct implementation<kernel::MedianFilter<T>, S, D,  typename boost::enable_if< MedianFilterIppSupportCheck<S, D> >::type >
    {
        static inline int run(const kernel::MedianFilter<T>& f, const S* input, D* output, uint32_t width, uint32_t height, long source_stride)
        { 
            if(!(f.GetWidth()%2 && f.GetHeight()%2))
              return 0;
            
            IppiSize  roi = {width - f.GetWidth() + 1, height - f.GetHeight() + 1}, mask = {f.GetWidth(), f.GetHeight()};
            IppiPoint anchor = { f.GetWidth() / 2, f.GetHeight()/ 2};
            int source_offset = source_stride * (f.GetHeight()/ 2) + f.GetWidth() / 2;
            int output_offset = width * (f.GetHeight()/ 2) + f.GetWidth() / 2;
            ippiFilterMedian(input + source_offset, source_stride * sizeof(*input) , output + output_offset, width *  sizeof(*output), roi, mask, anchor);
            FillBorders(output, width, height, f.GetWidth(), f.GetHeight());
            return 1;
                 
        }
    };
 
}
    


template<>
template<>
void TLocalFilter<  kernel::MedianWeightedCenterFilter< policy::FixedSize<3,3> > >::apply<uint8_t, uint8_t>(const uint8_t* input, uint8_t* output, uint32_t width, uint32_t height, long source_stride)
{
    IppiSize  roi = {width - 2, height - 2};
    ippiFilterMedianWeightedCenter3x3_8u_C1R(input + source_stride + 1, source_stride, output + width + 1, width, roi, GetWeight());
    FillBorders(output, width, height, 3, 3);  

}


template<>
template<>
void TLocalFilter<  kernel::MedianColorFilter< policy::FixedSize<3,3> > >::apply<uint8_t, uint8_t>(const uint8_t* input, uint8_t* output, uint32_t width, uint32_t height, long source_stride)
{
    IppiSize  roi = {width - 2, height - 2};
    ippiFilterMedianColor_8u_C3R(input + source_stride + 1, source_stride, output + width + 1, width, roi, ippMskSize3x3);
    FillBorders(output, width, height, 3, 3);  

}

template<>
template<>
void TLocalFilter<  kernel::MedianColorFilter< policy::FixedSize<5,5> > >::apply<uint8_t, uint8_t>(const uint8_t* input, uint8_t* output, uint32_t width, uint32_t height, long source_stride)
{
    IppiSize  roi = {width - 4, height - 4};
    ippiFilterMedianColor_8u_C3R(input + 2*source_stride + 1, source_stride, output + 2*width + 1, width, roi, ippMskSize5x5);
    FillBorders(output, width, height, 5, 5);  

}


#endif

}

#endif