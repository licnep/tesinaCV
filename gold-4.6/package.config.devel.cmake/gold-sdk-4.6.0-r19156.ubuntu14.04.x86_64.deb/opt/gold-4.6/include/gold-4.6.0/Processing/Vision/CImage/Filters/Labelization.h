#ifndef _LABELIZATION_H
#define _LABELIZATION_H

/** @file Labelize.h
  *
  * @author Paolo Medici (medici@ce.unipr.it)
  **/


#include <Data/Math/Points.h>
#include <Data/Math/Rects.h>

#include <Processing/Vision/CImage/gold_proc_cimage_export.h>
#include <Data/CImage/TImage.h>

#include <vector>
#include <limits>
#include <stdexcept>


namespace cimage {

/** Un labeler basato su std::vector (richiede pertanto una MMU)
 *
 * Questo labeler e' basato su un oggetto std::vector pertanto puo' crescere fino alla
 *  dimensione massima dell'Heap. Il neo sono le performance (a causa dell'allocazione
 *  dinamica della memoria) e la richiesta di std::vector (per esempio su architetture
 *  DSP tale struttura non e' possibile, cmq sostituibile pero' con un array statico).
 *
 * Benchmark fatti mostrano che impiega circa il 30% in meno di tempo per labellizzare rispetto
 *  a quello StackBased.
 *
 * @param src un immagine di ingresso binaria
 * @param dest un immagine di destinazione in toni di grigio (8,16,32bit) riempita con un tono differente per ogni label.
 * @return the number of label found
 *
 * \code
 * Labelize(input_image, dest_image, xsize, ysize);
 * \endcode
 *
 * @note nel caso vengano trovate piu' label di quelli che servono... viene lanciata una eccezione
 **/
template<class S, class D>
int Labelize(const S *src, D *dest, unsigned int width, unsigned int height);

/** Un labeler che riempie fornisce anche l'elenco dei punti appartenenti al label, per permettere
* la successiva eliminazione (in questo esempio basata su soglia per esempio).
*
* Anche senza rimozione del label impiega tanto tempo come la versione StackBased perche' sfrutta peggio la cache rispetto
*  a Labelize. Tuttavia ha la feature di rimozione che e' importante e implementarla fuori impiegherebbe sicuramente piu' tempo
* @param src un immagine di ingresso binaria
* @param dest un immagine di destinazione in toni di grigio (8,16,32bit) riempita con un tono differente per ogni label.
* @param threshold the minimum size (in pixels) of label. Only label with size larger or equal to threshold are keeped
* @return the number of label found
* \code
*  int n_label2 = cimage::Labelize(bin_image, label_image, width, height, 20);
* \endcode
*/
template<class S, class D>
int Labelize(const S *src, D *dest, unsigned int width, unsigned int height, unsigned int threshold);

/// Un labeler che invece di riempire un immagine di output genera solo i bounding box che contengono i label
template<class S>
int Labelize(const S *src, std::vector<math::Rect2i> &list, unsigned int width, unsigned int height);

/// Un Generico Labeler che chiama l'oggetto funzione per ogni elemento del label
template<class S, class F>
int Labelize(const S *src, F funobj, unsigned int width, unsigned int height);

/** extract a subset of label from the label image
 * @param rest an output list of rects. The entry 0 contains the first_label and so on...
 * @param label_image a label image
 * @param width,height the image geometry
 * @param first_label first label to be processed from the list (normally 1)
 * @param nMaxLabel number of labels to be processed
 * \code
 * std::vector<iRect> output;
 * FindBoundingRects(output, m_ImmagineLabel.data, width, height,  1, nlabel);
 * \endcode
 */
template<class D>
void FindBoundingRects(std::vector<math::Rect2i> & rect, const D *label_image, unsigned int width, unsigned int height, D first_Label, unsigned int nMaxLabel);

/// Extract a vector of bounding boxes from a labelized image
template<class D>
void FindBoundingRects(std::vector<math::Rect2i> & rect, const cimage::TImage<D> & img, D first_Label, unsigned int nMaxLabel) {
    FindBoundingRects<D>(rect, img.Buffer(), img.W(), img.H(), first_Label, nMaxLabel);
}

/** FindBoundingRect riempie un vettore di rettangoli con le etichette di una immagine
  *
  * Classe che genera un vettore di bounding rectangle data un immagine labellizata
  * @param rest an output list of rects. The entry 0 contains the first_label and so on...
  * @param label_image a label image
  * @param width,height the image geometry
  * \code
  * image::FindBoundingRects(out, label_image, width, height);
  * \endcode
  **/
 template<class D>
 void FindBoundingRects(std::vector<math::Rect2i> & rect, const D *label_image, unsigned int width, unsigned int height, D first_Label, unsigned int nMaxLabel);

template<class D>
void FindBoundingRects(std::vector<math::Rect2i> & rect, const D *label_image, unsigned int width, unsigned int height);

/// Classe che genera un vettore di bounding rectangle data un immagine labellizata
template<class T>
void FindBoundingRects(std::vector<math::Rect2i> & rect, const T & img) {
    FindBoundingRects(rect, img.Buffer(), img.W(), img.H());
}

/** FindBoundingRect ritorna il rettangolo che contiene i punti dell'immagine che hanno etichetta @a id
  *
  * Classe che genera il bounding rectanble di un determinato label
  * @param rect un rettangolo riempito in output
  * @param label_image una immagine generica
  * @param width,height dimensione dell'immagine
  * @param id una etichetta
  * @return true se l'etichetta e' stata trovata
  * @note per come e' implementata D puo' essere una immagine a 8 bit, 16 bit, RGB, RGBA
  **/
template<class D>
bool FindBoundingRect(math::Rect2i & rect, const D *label_image, unsigned int width, unsigned int height, D id);

/// Classe che genera il bounding rectanble di un determinato label
template<class D>
bool FindBoundingRect(math::Rect2i & rect, const cimage::TImage<D> &img, D id)
{
    FindBoundingRect(rect, img.Buffer(), img.W(), img.H(), id);
    return false;
}

////////////////////////////////////////// implementazione /////////////////////////////////////////////////

// detail
namespace detail {

/// Common variables and methods for Labeler classes
template<class S, class D>
class labeler {
    const S *m_src;     	    ///< immagine sorgente
    D *m_dest;                      ///< immagine destinazione
    unsigned int m_width, m_height; ///< dimensioni immagine
    D m_label;                      ///< label corrente
    std::vector<math::Point2i> m_points;	///< buffer temporaneo

private:
#if 0
    /// Imposta il `colore' del label
    inline bool TestAndSet(int x, int y) const
    {
        if(x<0 || (unsigned int)x>=m_width || y<0 || (unsigned int)y>=m_height)
            // if((unsigned int)x>=m_width || (unsigned int)y>=m_height)
            return false;
        else
        {
            unsigned int k = x + y * m_width;
            if ((!m_src[k]) || (m_dest[k]))
                return false;
            else
            {
                m_dest[k]=m_label;
                return true;
            }
        }
    }
#endif

    /// valuta se il punto (x,y) dell'immagine e' occupato e non e' stato ancora labellizato
    ///  se cio' accade setta l'immagine di output e inserisce nel vector il punto
    inline bool TestAndSet(int x, int y)
    {
        if(x<0 || (unsigned int)x>=m_width || y<0 || (unsigned int)y>=m_height)
            return false;
        else
        {
            unsigned int k = x + y * m_width;
            if ((!m_src[k]) || (m_dest[k]))
                return false;
            else
            {
                m_dest[k]=m_label;
                m_points.push_back(math::Point2i(x,y));
                return true;
            }
        }
    }

public:
    labeler() : m_label(0)
    {
    }

    /// labelizza nel modo piu' semplice
    int label(const S *src, D *dest, unsigned int width, unsigned int height)
    {
        m_src = src;
        m_dest = dest;
        m_width = width;
        m_height = height;
        m_label = 0;
        // clean up dest buffer
        for(unsigned int i = 0; i <width * height; i++)
            m_dest[i] = D(0);

        for(unsigned int j=0; j<height; j++)
            for(unsigned int i=0; i<width; i++)
            {
                int k = i+j*width;
                if((m_src[k]!=0)&&(m_dest[k]==0))
                {
                    if(m_label==std::numeric_limits <D>::max() )
                        throw std::runtime_error("Labelize: too many label");

                    m_label++;

                    m_dest[k] = m_label;

                    m_points.clear();

                    m_points.push_back(math::Point2i(i,j));

                    while(!m_points.empty())
                    {
                        math::Point2i cur = m_points.back();
                        m_points.pop_back();

                        TestAndSet(cur.x + 1, cur.y    );
                        TestAndSet(cur.x    , cur.y + 1);
                        TestAndSet(cur.x - 1, cur.y    );
                        TestAndSet(cur.x    , cur.y - 1);

                        TestAndSet(cur.x + 1, cur.y + 1);
                        TestAndSet(cur.x - 1, cur.y + 1);
                        TestAndSet(cur.x - 1, cur.y - 1);
                        TestAndSet(cur.x + 1, cur.y - 1);
                    }
                }
            }
        return m_label;
    }

    /// labelizza ma mantiene comunque una storia dei punti attraversati in modo da cancellare il label se e' troppo piccolo
    int label_with_threshold(const S *src, D *dest, unsigned int width, unsigned int height, unsigned int threshold)
    {
        m_src = src;
        m_dest = dest;
        m_width = width;
        m_height = height;
        m_label = 0;
        // clean up dest buffer
        for(unsigned int i = 0; i <width * height; i++)
            m_dest[i] = D(0);

        for(unsigned int j=0; j<height; j++)
            for(unsigned int i=0; i<width; i++)
            {
                int k = i+j*width;
                if((m_src[k]!=0)&&(m_dest[k]==0))
                {
                    if(m_label==std::numeric_limits <D>::max()-1 )
                        throw std::runtime_error("Labelize: too many label");

                    m_label++;

                    m_dest[k] = m_label;

                    m_points.clear();

                    m_points.push_back(math::Point2i(i,j));

                    // ultimo elemento processato
                    int index = 0;

                    while(index < m_points.size())
                    {
                        math::Point2i cur = m_points[index];
                        index++;

                        TestAndSet(cur.x + 1, cur.y    );
                        TestAndSet(cur.x    , cur.y + 1);
                        TestAndSet(cur.x - 1, cur.y    );
                        TestAndSet(cur.x    , cur.y - 1);

                        TestAndSet(cur.x + 1, cur.y + 1);
                        TestAndSet(cur.x - 1, cur.y + 1);
                        TestAndSet(cur.x - 1, cur.y - 1);
                        TestAndSet(cur.x + 1, cur.y - 1);
                    }

                    if(m_points.size() < threshold)
                    {
                        // marca i punti scartati come numeric_limits <D>::max()-1
                        //  altrimenti cicli successivi li potrebbero riprocessare
                        for(unsigned int i = 0; i < m_points.size(); i++)
                            dest[m_points[i].x + m_points[i].y * width] = std::numeric_limits <D>::max()-1;
                        m_label--;
                    }

                }
            }
        return m_label;
    }

    /// label che permette un numero qualunque di label, ma non genera una immagine destinazione valida
    int export_label(const S *src, D *dest, std::vector<math::Rect2i> &list, unsigned int width, unsigned int height)
    {
        m_src = src;
        m_dest = dest;
        m_width = width;
        m_height = height;
        m_label = std::numeric_limits <D>::max()-1;
        math::Rect2i r;
        m_label = 1;
        // clean up dest buffer
        for(unsigned int i = 0; i <width * height; i++)
            m_dest[i] = D(0);

        for(unsigned int j=0; j<height; j++)
            for(unsigned int i=0; i<width; i++)
            {
                int k = i+j*width;
                if((m_src[k]!=0)&&(m_dest[k]==0))
                {
                    m_dest[k] = m_label;

                    m_points.clear();

                    m_points.push_back(math::Point2i(i,j));

                    r.x0 = r.x1 = i;
                    r.y0 = r.y1 = j;

                    while(!m_points.empty())
                    {
                        math::Point2i cur = m_points.back();
                        m_points.pop_back();
                        r.include(cur);

                        TestAndSet(cur.x + 1, cur.y    );
                        TestAndSet(cur.x    , cur.y + 1);
                        TestAndSet(cur.x - 1, cur.y    );
                        TestAndSet(cur.x    , cur.y - 1);

                        TestAndSet(cur.x + 1, cur.y + 1);
                        TestAndSet(cur.x - 1, cur.y + 1);
                        TestAndSet(cur.x - 1, cur.y - 1);
                        TestAndSet(cur.x + 1, cur.y - 1);
                    }

                    list.push_back(r);
                }
            }
        return m_label;

    }

};

} // detail

template<class S, class D>
int Labelize(const S *src, D *dest, unsigned int width, unsigned int height)
{
    detail::labeler<S,D> filter;

    return filter.label(src, dest, width, height);
}

template<class S, class D>
int Labelize(const S *src, D *dest, unsigned int width, unsigned int height, unsigned int threshold)
{
    detail::labeler<S,D> filter;

    return filter.label_with_threshold(src, dest, width, height, threshold);
}

template<class S>
int Labelize(const S *src, std::vector<math::Rect2i> &list, unsigned int width, unsigned int height)
{
    detail::labeler<S, uint8_t> filter;
    unsigned char *tmp = new unsigned char [width * height];
    int label = filter.export_label(src, tmp, list, width, height);
    delete [] tmp;
    return label;
}

template<class D>
bool FindBoundingRect(math::Rect2i & rect, const D *label_image, unsigned int width, unsigned int height, D id)
{
    bool found = false;
    for(unsigned int j=0; j<height; j++)
        for(unsigned int i=0; i<width; i++)
            if ( *label_image++ == id )
            {
                if( !found ) {
                    rect.x0 = rect.x1 = i;
                    rect.y0 = rect.y1 = j;
                    found = true;
                }
                else	rect.include(i,j);
            }
    return found;
}

template<class D>
void FindBoundingRects(std::vector<math::Rect2i> & rect, const D *label_image, unsigned int width, unsigned int height)
{
    rect.resize( std::numeric_limits<D>::max() ); // for example 255
    for(int i=0; i<rect.size(); ++i)
    {
        rect[i].x0 = width-1;
        rect[i].y0 = height-1;
        rect[i].x1 = rect[i].y1 = -1;
    }

    for(unsigned int j=0; j<height; j++)
        for(unsigned int i=0; i<width; i++)
        {
            if (*label_image != D(0) )
            {
                rect[*label_image - 1].include(i,j);
            }
            label_image++;
        }
}

template<class D>
void FindBoundingRects(std::vector<math::Rect2i> & rect, const D *label_image, unsigned int width, unsigned int height,  D first_Label, unsigned int nMaxLabel)
{
    D last_label = first_Label + nMaxLabel - 1;
    rect.resize(nMaxLabel);
    for(int i=0; i<nMaxLabel; ++i)
        rect[i].x0 = rect[i].y0 = rect[i].x1 = rect[i].y1 = -1;

    for(unsigned int j=0; j<height; j++)
        for(unsigned int i=0; i<width; i++)
        {
            if ((*label_image >= first_Label) && (*label_image <= last_label))
            {
                math::Rect2i & r = rect[*label_image - first_Label];	// etichetta vera e propria
                if(r.x0 == -1)
                {
                    r.x0 = r.x1 = i;
                    r.y0 = r.y1 = j;
                }
                else
                    r.include(i,j);
            }
            label_image++;
        }
}

} // namespace cimage

#endif
