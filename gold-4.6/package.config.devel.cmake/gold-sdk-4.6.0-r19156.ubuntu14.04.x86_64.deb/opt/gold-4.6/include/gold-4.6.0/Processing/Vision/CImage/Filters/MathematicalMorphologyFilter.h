#ifndef _MATHEMATICAL_MORPHOLOGY_FILTER_H
#define _MATHEMATICAL_MORPHOLOGY_FILTER_H

/** @file
 * @brief filtri morfologici 
 * @note ADDITIONAL WORK IS REQUIRED
 */

namespace cimage
{

namespace policy
{

/// Fixed Size Structure element
template<uint32_t width, uint32_t height>
class FullStructuringElement
{
public:
	static uint32_t GetWidth()
	{
		return width;
	}
	static uint32_t GetHeight()
	{
		return height;
	}

	bool operator()(int i)
	{
		return true;
	}
};

/// Dynamic Size Filter
class VariableStructuringElement
{
	uint32_t m_width;
	uint32_t m_height;
	bool *m_element;
public:
	VariableStructuringElement() :
			m_width(0), m_height(0), m_element(0)
	{
	}
	~VariableStructuringElement()
	{
		delete[] m_element;
	}
	/// Insert the Structuring Element
	void SetElement(uint32_t w, uint32_t h, const bool *mask)
	{
		if (m_width != w || m_height != h)
		{
			delete[] m_element;
			m_width = w;
			m_height = h;
			m_element = new bool[m_width * m_height];
		}
		std::copy(&mask[0], &mask[w * h], m_element);
	}

	bool operator()(int i)
	{
		return m_element[i];
	}

	uint32_t GetWidth() const
	{
		return m_width;
	}
	uint32_t GetHeight() const
	{
		return m_height;
	}
};

} // namespace policy

namespace kernel
{

/// Dilate a Binary Image
template<class StructureElement>
class Dilate: public StructureElement
{
public:

	template<class D>
	inline D zero() const
	{
		return 0;
	}
	template<class S>
	inline S operator()(const S* inputPixel, long stride) const
	{
		int k = 0;
		for (int32_t j = -((int32_t) StructureElement::GetHeight() / 2);
				j <= (((int32_t) StructureElement::GetHeight() - 1) / 2); j++)
			for (int32_t i = -((int32_t) StructureElement::GetWidth() / 2);
					i <= (((int32_t) StructureElement::GetWidth() - 1) / 2); i++)
			{
				if (StructureElement::operator()(k)
						&& inputPixel[stride * j + i] > 0)
					return 255;
				k++;
			}
		return 0;
	}
};

/// Erode a Binary Image
template<class StructureElement>
class Erode: public StructureElement
{
public:

	template<class D>
	inline D zero() const
	{
		return 0;
	}
	template<class S>
	inline S operator()(const S* inputPixel, long stride) const
	{
		int k = 0;
		for (int32_t j = -((int32_t) StructureElement::GetHeight() / 2);
				j <= (((int32_t) StructureElement::GetHeight() - 1) / 2); j++)
			for (int32_t i = -((int32_t) StructureElement::GetWidth() / 2);
					i <= (((int32_t) StructureElement::GetWidth() - 1) / 2); i++)
			{
				if (StructureElement::operator()(k)
						&& inputPixel[stride * j + i] == 0)
					return 0;
				k++;
			}
		return 255;
	}
};

} // namespace kernel

// PGX 20131023: this line has been commented since it was preventing the correct compiling
// }// Filter

} // namespace cimage

#if 0

/** Operation Type per ll_grey_morfologia_matematica_bw **/
#define OP_TYPE_APERTURA 7
#define OP_TYPE_CHIUSURA 8
#define OP_TYPE_ESPANSIONE 9
#define OP_TYPE_EROSIONE 10

/** strutturante ::= [0] numero elementi onset
 *                   [1] righe strutturante
 *                   [2] colonne strutturante
 *                   di seguito: x0, y0, x1, y1, x2, y1, .. x_{n-1}, y_{n-1}
 *  avente origine (x0,y0), x positive a destra ed y positive verso il basso
 *  avendo ipotizzato che (x0,y0) appartenga all'onset                      
 *
 * effettua l'apertura black/white di 8bit - gray tone images sotto
 * l'ipotesi che  [ g(i,j)==White ] <=> [ (g(i,j) & bitmask) != 0 ]
 * In analogia effettua altresi' chiusura, espansione ed erosione
 */
GOLD_PROC_CIMAGE_EXPORT void ll_grey_morfologia_matematica_bw(unsigned char * dest, unsigned char * src, int x, int y, int * structuring, char bitmask, int op_type);

/** horizontal binary expansion */
GOLD_PROC_CIMAGE_EXPORT void ll_grey_hexp(unsigned char *dest, unsigned char *src, const int x, const int y);

/** questa funzione espande controlla un intorno sizexsize e accende il pixel se piu' di num pixel sono accesi 
 * @return TRUe se i parametri di ingresso sono corretti.
 **/
GOLD_PROC_CIMAGE_EXPORT int ll_grey_espandi(const unsigned char *src, unsigned char *dest, const int x, const int y, int size, const int num);

/** questa funzione espande controlla un intorno sizexsize e accende il pixel se piu' di num pixel sono accesi size_x puo' essere != da size_y*/
GOLD_PROC_CIMAGE_EXPORT void ll_grey_vert_espandi(const unsigned char *src, unsigned char *dest, const int x, const int y, int size_x,int size_y, const int num);

/**
 * @return TRUE se i parametri di ingresso sono corretti, altrimenti FALSE
 **/
GOLD_PROC_CIMAGE_EXPORT int ll_grey_espandimaschera(const unsigned char *orig, unsigned char *destinazione, const int x, const int y, const int *mask, const int masksize, const int n);

/** @brief elimina i punti isolati secondo la maschera di dimensioni masksize*masksize 
 * \param orig Buffer immagine sorgente
 * \param dest Buffer immagine destinazione. Se @orig==@dest viene creato automaticamente un buffer intermedio
 * \param x dimensione orizzontale del buffer
 * \param y dimensione verticale del buffer
 * \param mask maschera
 * \param masksize dimensione della maschera
 * \param n soglia
 * @return TRUE se i parametri sono corretti, altrimenti FALSE
 **/
GOLD_PROC_CIMAGE_EXPORT int ll_grey_eliminamaschera(const unsigned char *orig, unsigned char *dest, const int x, const int y, const int *mask, const int masksize, const int n);

/** elimina gli spuntoni, ovverossia controlla il vicinato ed elimina i punti che hanno due o piu' vicini
 * gia' connessi tra di loro e che non sono ponte tra vicini */
GOLD_PROC_CIMAGE_EXPORT void ll_grey_eliminaspuntoni(unsigned char *orig, unsigned char *dest, int x, int y);

GOLD_PROC_CIMAGE_EXPORT void ll_grey_eliminaspuntoni_di_due(unsigned char *orig, unsigned char *dest, int x, int y);

/** @brief elimina i pixel che nel vicinato 3x3 hanno meno di n pixel accesi 
 * @param orig immagine sorgente
 * @param destinaz immagine destinazione
 * @param x,y dimensione delle immagini
 * @param n numero di pixel accesi nell'intorno 3x3
 **/
GOLD_PROC_CIMAGE_EXPORT void ll_grey_elimina_quasi_isolati(const unsigned char * orig, unsigned char * destinaz, unsigned int x, unsigned int y, unsigned int n);

GOLD_PROC_CIMAGE_EXPORT void ll_grey_thinning(const unsigned char *orig, unsigned char *dest, unsigned int x, unsigned int y);

GOLD_PROC_CIMAGE_EXPORT void ll_grey_fake_thinning(const unsigned char *orig, unsigned char *dest, unsigned int x, unsigned int y);

#endif

#endif
