#ifndef _EXTENDED_KALMAN_FILTER_HXX
#define _EXTENDED_KALMAN_FILTER_HXX

#include <boost/static_assert.hpp>
#include "KalmanFilter.hxx"

#include <Eigen/Core>

#include <iostream> // only for debug

#define debug_ekf   false

namespace state_estimation {
namespace detail {

// l'effettiva implementazione di Kalman quando Predictor e Observer sono lineari o linearizzabili
template<class _Scalar, class Predictor, class Observer, class ErrorPolicy>
class KalmanImpl<LinearizedImplementation, LinearizedImplementation, _Scalar, Predictor, Observer, ErrorPolicy> : public Predictor, public Observer {

    /// Assert when fail [ Observer STATE SIZE == Predictor STATE SIZE ]
    BOOST_STATIC_ASSERT(  ((int) Predictor::StateSizePolicy == (int) Eigen::Dynamic) ||
                          ((int) Observer::StateSizePolicy == (int) Eigen::Dynamic) ||
                          ((int) Predictor::StateSizePolicy == (int) Observer::StateSizePolicy) );
public:

    enum {
        StateSizePolicy = ((int) Predictor::StateSizePolicy != (int) Eigen::Dynamic) ? (int) Predictor::StateSizePolicy : (int) Observer::StateSizePolicy,
        ObservationSizePolicy = (int) Observer::ObservationSizePolicy
    };

    typedef typename Observer::ObservedType 					ObservedType;
    typedef Eigen::Matrix<_Scalar, StateSizePolicy, 1>          		StateType;
    typedef Eigen::Matrix<_Scalar, StateSizePolicy, StateSizePolicy>		CovarianceMatrixType;
    typedef Eigen::Matrix<_Scalar, StateSizePolicy, ObservationSizePolicy> 	MatrixKType;

private:
    /// hidden status
    StateType x;
/// covariance matrix
    CovarianceMatrixType P;
/// Kalman gain
    MatrixKType K;
public:

/// initialize the filter (size are inherited by policy)
    KalmanImpl()
    {
        x.resize(Predictor::StateSize() );
        P.resize(Predictor::StateSize(), Predictor::StateSize() );
        K.resize(Predictor::StateSize(), Observer::ObservationSize() );
    }

    KalmanImpl(int state_size)
    {
        this->StateSize(state_size);
    }
    KalmanImpl(int state_size, int observation_size) {
        this->StateSize(state_size);
        this->ObservationSize(observation_size);
    }
    KalmanImpl(int state_size, int input_size, int observation_size) {
        this->StateSize(state_size);
        this->InputSize(input_size);
        this->ObservationSize(observation_size);
    }

/// initialize the filter with a state @a size
    void StateSize(int size)
    {
        x.resize(size);
        P.resize(size, size);

        Predictor::StateSize(size);
        Observer::StateSize(size);
    }

/// return the state size
    unsigned int StateSize() const {
        return x.rows();
    }

//  /// initialize the hidden status @a _x and covariance matrix @a _P
//  template<class StateType, class CovarianceMatrixType>
//  void State(const StateType & _x, const CovarianceMatrixType & _P)
//  {
//    x = _x;
//    P = _P;
//  }

/// predict without input (predict must have predict.A matrix
///  and predict.update(x) method)
/// x' = Ax
/// @see use linearized_predict
    void Predict()
    {
        StateType x1(x.rows());
        // update
        Predictor::Update(x);

        const typename Predictor::MatrixAType & A = Predictor::TransitionMatrix();

        if(debug_ekf)
            std::cout << "[EKF] A:\n" << A << std::endl;
        if(debug_ekf)
            std::cout << "[EKF] Q:\n" <<  Predictor::ProcessNoiseMatrix() << std::endl;

        // stima a priori di x
        Predictor::f(x1, x);

        if(debug_ekf)
            std::cout << "[EKF] state = " << x.transpose() << " | predict = " << x1.transpose() <<  std::endl;

        x = x1;


        // aggiornamento della covarianza a priori
        P = ( A * P * A.transpose() ) + Predictor::ProcessNoiseMatrix();
        if(debug_ekf)
            std::cout << "[EKF] P-:\n" << P << std::endl;
    }

/// predict with input (predict must have predict.A e predict.B
///  and predict.update(x, u) method
/// x' = Ax + Bu
    template<class InputType>
    void Predict(const InputType & u)
    {
        StateType x1(x.rows());
        // update
        Predictor::Update(x);

        const typename Predictor::MatrixAType & A = Predictor::TransitionMatrix();
        // stima a priori di x
        Predictor::f(x1, x, u);
        if(debug_ekf)
            std::cout << "[EKF] state = " << x.transpose() << " | predict = " << x1.transpose() <<  std::endl;
        x = x1;

        // aggiornamento della covarianza a priori
        P = A * P * A.transpose() + Predictor::ProcessNoiseMatrix();
    }

/// simulate the future state of the system (without change it)
/// @param x1 return the future state
    template<class StateType>
    void Simulate(StateType & x1)
    {
        Predictor::f(x1, x);
    }

/// simulate the future state of the system (without change it)
/// @param x1 return the future state
/// @param u the input param
    template<class StateType, class InputType>
    void Simulate(const InputType & u, StateType & x1)
    {
        Predictor::f(x1, x, u);
    }

/// Observe. Observe must have observe.H matrix and observe.update(x) method.
/// @param comp the observation comparting funcation. It is needed because error computing could be not linear (es circular distance). Use linear_compare as default
/// @see use linearized_observe
    void Observe(const ObservedType & z)
    {
        ErrorPolicy e;
        // TODO: check matrix size

        // call update for EKF
        Observer::Update(x);

        const typename Observer::MatrixHType & H = Observer::ObservationMatrix();
        const typename Observer::MatrixRType & R = Observer::ObservationNoiseMatrix();

        if(debug_ekf)
            std::cout << "[EKF] H:\n" << H << std::endl;
        if(debug_ekf)
            std::cout << "[EKF] R:\n" << R << std::endl;

        ObservedType z1(Observer::ObservationSize() );

        K.resize(x.rows(), z.rows() );

        // K = P * H^{T} * ( HPH^{T} + R )^{-1}

        // calcolo del kalman gain:
        K = P * H.transpose() * ( (H * P * H.transpose()) + R ).inverse();

        if(debug_ekf)
            std::cout << "[EKF] kalman gain\n" << K << std::endl;

        Observer::h(z1, x); // H*x

        if(debug_ekf)
            std::cout << "[EKF] observation error = " << e(z, z1).transpose() << std::endl;

        // stima a posteriori dello stato
        // x = x + K * (z - H * x) per Kalman
        // x = x + K * (z - h(x) ) per EKF
        x += K * e(z, z1);

        // Stima a posteriori dell'errore di covarianza
        // P = (I - K * H) * P;
        P -= K * H * P;
    }

/// return the inner state
    inline const StateType & State() const {
        return x;
    }
    inline StateType & State() {
        return x;
    }
/// return the state covariance matrix
    inline const CovarianceMatrixType & CovarianceMatrix() const {
        return P;
    }
    inline CovarianceMatrixType & CovarianceMatrix() {
        return P;
    }
};

}
}

#endif