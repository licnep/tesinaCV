#ifndef _DRAW_LINE_H
#define _DRAW_LINE_H

/** @file Line.h
 *  @brief API to draw lines on images
 * */

#include <cmath>
#include <Data/Math/Points.h>

namespace draw {
 
/** \ingroup Draw
 * Disegna una linea 
 * @note il clipping viene eseguito per ogni punto
 * @todo aggiungere una politica per il clipping
 * 
 * Example of an opaque black(0) brush on a unsigned char array 128x128:
 * \code
 * draw::Line( draw::Opaque<unsigned char>(buffer, 128,128, 0), 10,10, 50,50);
 * \endcode
 * 
 * Example of an additive (+1) brush on a unsigned char array 128x128:
 * \code
 * draw::Line( draw::Additive<unsigned char>(buffer, 128,128, 1), 10,10, 50,50);
 * \endcode
 * @see draw::Opaque
 */
template<class _Brush>  
void Line(_Brush f, int x1, int y1, int x2, int y2)
{
	int dx2,	//scaled deltas
            dy2,
            ix,		//increase rate on the x axis
            iy,		//increase rate on the y axis
            err,	//the error term
            i;		//looping variable

	// difference between starting and ending points
	int dx = x2 - x1;
	int dy = y2 - y1;

	// calculate direction of the vector and store in ix and iy
	if (dx >= 0)
		ix = 1;

	if (dx < 0)
	{
		ix = -1;
		dx = std::abs(dx);
	}

	if (dy >= 0)
		iy = 1;

	if (dy < 0)
	{
		iy = -1;
		dy = std::abs(dy);
	}

	// scale deltas and store in dx2 and dy2
	dx2 = dx * 2;
	dy2 = dy * 2;
        
	if (dx > dy)	// dx is the major axis
	{
		// initialize the error term
		err = dy2 - dx;

		for (i = 0; i <= dx; i++)
		{
			f(x1,y1);
			if (err >= 0)
			{
				err -= dx2;
				y1 += iy;
			}
			err += dy2;
			x1 += ix;
		}
	}
	
	else 		// dy is the major axis
	{
		// initialize the error term
		err = dx2 - dy;

		for (i = 0; i <= dy; i++)
		{
			f(x1,y1);
			if (err >= 0)
			{
				err -= dy2;
				x1 += ix;
			}
			err += dx2;
			y1 += iy;
		}
	}
} // end of Line(...

/** \ingroup Draw 
 * Draw a line using a brush
 * Example of a opaque black (0) brush on a 128x128 unsigned char buffer array
\code
draw::Line( draw::Opaque<unsigned char>(buffer, 128,128, 0), a, b);
\endcode
*/
template<class _Brush>  
void Line(_Brush f, const math::Point2<int> & a, const math::Point2<int> & b)
{
  Line<_Brush>(f, a.x, a.y, b.x, b.y);
}

}

#endif
