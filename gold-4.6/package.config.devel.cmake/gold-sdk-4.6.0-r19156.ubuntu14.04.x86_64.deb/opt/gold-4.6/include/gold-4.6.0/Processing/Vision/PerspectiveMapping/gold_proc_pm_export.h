
#ifndef GOLD_PROC_PM_EXPORT_H
#define GOLD_PROC_PM_EXPORT_H

#ifdef GOLD_PROC_PM_STATIC_DEFINE
#  define GOLD_PROC_PM_EXPORT
#  define GOLD_PROC_PM_NO_EXPORT
#else
#  ifndef GOLD_PROC_PM_EXPORT
#    ifdef gold_proc_pm_EXPORTS
        /* We are building this library */
#      define GOLD_PROC_PM_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define GOLD_PROC_PM_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef GOLD_PROC_PM_NO_EXPORT
#    define GOLD_PROC_PM_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef GOLD_PROC_PM_DEPRECATED
#  define GOLD_PROC_PM_DEPRECATED __attribute__ ((__deprecated__))
#  define GOLD_PROC_PM_DEPRECATED_EXPORT GOLD_PROC_PM_EXPORT __attribute__ ((__deprecated__))
#  define GOLD_PROC_PM_DEPRECATED_NO_EXPORT GOLD_PROC_PM_NO_EXPORT __attribute__ ((__deprecated__))
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define GOLD_PROC_PM_NO_DEPRECATED
#endif

#endif
