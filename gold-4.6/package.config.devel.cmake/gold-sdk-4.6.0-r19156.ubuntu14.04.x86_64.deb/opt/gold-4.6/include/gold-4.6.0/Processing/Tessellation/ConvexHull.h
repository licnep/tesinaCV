#ifndef _CONVEXHULL_H
#define _CONVEXHULL_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file ConvexHull.h
 * @author Mirko Felisa (felisa@vislab.it)
 * @date 2012-04-16
 */

#include<Processing/Tessellation/Data.h>
#include <Processing/Tessellation/gold_proc_tessellation_export.h>



/**
 * \brief Namespace for Tessellation Processing Library
*/  
namespace tessellation
{
  
    /**
    * \brief Namespace for Convex Hull Algorithm
    */
    namespace convex_hull
    {

        /**
        * @ingroup Tess
        * @defgroup CH Convex Hull
        * @brief Convex Hull algorithms
        * 
        * The convex hull or convex envelope of a set A of points in the plane  is the smallest convex set that contains A.
        * @{
        **/
      
        /**
        * @brief Computes convex hull of Delaunay triangulation.
        * @param [in] hull Delaunay triangulation of the input data.
        * @param [out] v   convex hull output  vector.
        * @param [in] keep_collinear if it is true then collinear points in the convex hull are removed.
        * @note Delaunay triangulation is usually slower than GiftWrapping algorithm. Use this algorithm only if you need Delaunay triangulation for other processing. 
        * @note complexity \f$ O(h)\f$  where  \f$ h\f$ is the number of  output vertices
        * @note keep_collinear = true is slower.
        **/
        template<typename T>
        GOLD_PROC_TESSELLATION_EXPORT void DelaunayWrapping(TriangleHull<T>& hull, typename std::vector<T>& v, bool keep_collinear = false);

        
        /**
        * @brief Computes convex hull of point vector, exploiting Delaunay triangulation.
        * @param [in] point input data.
        * @param [out] v   convex hull output  vector.
        * @param [in] keep_collinear if it is true then collinear points in the convex hull are removed.
        * @note DelaunayWrapping is usually slower than GiftWrapping algorithm.   
        * @note complexity \f$ O(nlog(n))\f$  where  \f$ n\f$ is the number of  input vertices 
        **/
        template<typename T>
        GOLD_PROC_TESSELLATION_EXPORT void DelaunayWrapping(const typename std::vector<T>& point, typename std::vector<T>& v, bool keep_collinear = false);

        /**
        * @brief Computes convex hull of point vector, exploiting GiftWrapping algorithm.
        * @param [in] point input data.
        * @param [out] v   convex hull output  vector.
        * @param [in] keep_collinear if it is true then collinear points in the convex hull are removed. 
        * @note complexity \f$ O(nh)\f$  where \f$ n\f$  and \f$ h\f$ are the number of input and output vertices
        **/
        template<typename T>
        GOLD_PROC_TESSELLATION_EXPORT void GiftWrapping(const typename std::vector<T>& point, typename std::vector<T>& hull, bool keep_collinear = false);

        /**@}*/
        
    }
    

}



#endif
