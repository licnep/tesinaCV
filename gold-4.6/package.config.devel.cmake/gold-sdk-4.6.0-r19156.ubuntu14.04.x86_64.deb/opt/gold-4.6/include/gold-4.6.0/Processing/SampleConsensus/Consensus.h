#ifndef _CONSENSUS_H
#define _CONSENSUS_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file Consensus.h
 * @author Paolo Zani (zani@vislab.it)
 * @date 2012-11-14
 */

#include <Processing/SampleConsensus/detail/EstimatorTraits.hxx>

#include <cstddef>

namespace sample_consensus
{
    /**
     * @brief Structure holding some statistics about the model-fitting process
     **/
    struct ConsensusInfo
    {
        double m_model_cost; /**< the fitting cost of the selected model. */
        size_t m_inliers_number; /**< the number of inliers associated with the selected model. */
        unsigned int m_iterations; /**< the number of iterations performed. */
        unsigned int m_skipped_iterations; /**< the number of iterations for which the selected sample did not lead to a successful model generation */
        
        /// test if sac has found a solution
        operator bool() { return m_inliers_number!=0; }
    };

     /**
     * @ingroup SAC
     * @defgroup Consensus Consensus
     * @brief Helper functions to determine the consensus set.
     *
     * @{
     **/

    /**
     * @brief Computes consensus set (i.e. the inliers) using the supplied model and estimator.
     * @note This is an helper function that is intended to be used once the best-fitting model has already been determined using one of the sample and consensus algorithms provided by the library.
     * @see RANSAC
     *
     * @param [out] consensus The set of inliers.
     * @param [in] model The model to use.
     * @param [in] samples Input data, containing both inliers and outliers.
     * @param [in] max_inliers_error Max fitting error of inlier samples.
     * @param [in] estimator Data analysis class.
     **/
    template<template<typename, typename> class Container, typename T, typename Allocator, typename Model, typename Estimator>
    void Consensus(Container<T, Allocator>& consensus, const Model& model, const Container<T, Allocator>& samples, double max_inliers_error, const Estimator& estimator)
    {
        for(typename Container<T, Allocator>::const_iterator ii = samples.begin(); ii != samples.end(); ++ii)
            if(estimator.Evaluate(model, *ii) < max_inliers_error)
                consensus.push_back(*ii);
    }

    /** @cond **/
    template<template<typename, typename> class Container, typename T, typename Allocator, typename Model>
    void Consensus(Container<T, Allocator>& consensus, const Model& model, const Container<T, Allocator>& samples, double max_inliers_error)
    {
        typename detail::EstimatorTraits<Model>::EstimatorType estimator;
        Consensus(consensus, model, samples, max_inliers_error, estimator);
    }
    /** @endcond **/

    /**@}*/
}

#endif // _CONSENSUS_H
