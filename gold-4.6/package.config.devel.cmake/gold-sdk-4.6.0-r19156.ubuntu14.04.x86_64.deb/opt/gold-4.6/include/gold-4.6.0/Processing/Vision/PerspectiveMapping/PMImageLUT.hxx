// The template and inlines for the -*- C++ -*- internal PMImageLUT helper class.

/** @file PMImageLUT.tcc
 *  This is an internal header file, included by other library headers.
 *  You should not attempt to use it directly.
 */

// Written by Paolo Medici <medici@ce.unipr.it>

#ifndef _PMIMAGELUT_TCC
#define _PMIMAGELUT_TCC

#include "PMImageLUT.h"
#include "LutPixel.hxx"

template<class T>
void TIPMImageLUT<T>::Compute(void)  
{
double xw, yw;
double dx,dy;
unsigned int xx, yy;

dx = 1.0 / RefPlaneMapping::dx; // X-altezza... da XMAX a XMIN
dy = 1.0 / RefPlaneMapping::dy;  // Y-larghezza... da YMAX a YMIN

// Computation of the LUT (scanning each pixel of the resulting image)
for (yy=0, xw=RefPlaneMapping::x0; yy<T::height; yy++, xw-=dx)
    for (xx=0, yw=RefPlaneMapping::y0; xx<T::width; xx++, yw-=dy)
    {
    if(GetCameraZCoord(math::Point3d(xw,yw,0.0))>0.0)
    {
    math::Point2d p = PixelFromWorld(xw, yw, 0.0); // (xw,yw,0) -> (xu,yu) @todo usare il reflpan limits
    
    // NOTA: non controllo che xu,yu siano all'interno dell'immagine
    //       sorgente. Bisognerebbe controllare e impostare a -1 
    //       il punto
    T::SetPixel(xx, yy, p.x, p.y); // chiamata di <T>
   }
else
  {
  T::SetPixel(xx,yy, -1.0, -1.0);
  }
    }

m_computed = true;    
}

template<class T>
void TIPMImageLUT<T>::GetValidMask(unsigned char *buffer, unsigned int width, unsigned int height, unsigned char valid, unsigned char invalid)
{
unsigned int i,j;
if(!m_computed)
    Compute();
    
for(j=0;j<T::height;j++)
    for(i=0;i<T::width;i++)
    *buffer++ = T::IsDefined(i,j) ? valid : invalid;
}

template<class T>
void TPMImageLUT<T>::Compute(void)
{
unsigned int xu, yu;
double mz = 0.0; // todo: usare il refplan limits
// TODO: Usare l'omografia!

for (yu=0; yu<T::height; yu++)
  for (xu=0; xu<T::width; xu++)
  {
  math::Point2d p;
  math::Point3d w;
  // TODO: test return:
  w = WorldFromPixelZ(xu, yu, mz); // (xu,yu) -> (w)
  p = WorldToIpm(w.x,w.y);    // (w) -> (x,y)
  T::SetPixel(xu, yu, p.x, p.y);
  }
m_computed = true;
}



#endif

