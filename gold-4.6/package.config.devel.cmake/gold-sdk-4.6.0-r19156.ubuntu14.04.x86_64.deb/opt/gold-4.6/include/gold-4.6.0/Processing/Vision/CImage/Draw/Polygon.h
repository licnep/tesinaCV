/**
 * \file CImage/Draw/Polygon.h
 * \brief API to draw polygons on images
 */

#ifndef _DRAW_POLYGON_H
#define _DRAW_POLYGON_H

#include "Triangle.h"

namespace draw {
  
/** \ingroup Draw
  * Applies a (convess) polygonal patch to the image using the Fan Algorithm
  * @param patch A polygon
  * @todo aggiungere una politica per il clipping
  * 
  * Draw a polygon (4 points) on a 128x128 unsigned char buffer, color black(0)
  * \code
  std::vector <Point2i> poly;
  poly.push_back(Point2i(1,1) );
  poly.push_back(Point2i(200,200) );
  poly.push_back(Point2i(700,300) );
  poly.push_back(Point2i(500,100) );
  draw::PolygonFan( draw::Opaque<unsigned char>(buffer, 128,128, 0), poly);
  * \endcode
  */
template <typename F,class S>
bool PolygonFan(F f, const S& patch)
{
if (patch.size() <= 2)
  return false;
else
  {
  typename S::const_iterator first  = patch.begin();
  typename S::const_iterator second = patch.begin();
  second++;
  typename S::const_iterator third  = patch.begin();
  third++;
  third++;

  for (;third != patch.end();++second,++third)
    Triangle(f, Point2f(*first), Point2f(*second), Point2f(*third) );
  return true;
  }
}

}

#endif
