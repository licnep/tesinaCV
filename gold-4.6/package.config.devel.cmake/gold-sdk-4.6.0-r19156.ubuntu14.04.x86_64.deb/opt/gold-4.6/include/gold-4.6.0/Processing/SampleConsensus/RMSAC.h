#ifndef _RMSAC_H
#define _RMSAC_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file RMSAC.h
 * @author Paolo Zani (zani@vislab.it)
 * @date 2012-03-29
 */

#include <Processing/SampleConsensus/detail/EstimatorTraits.hxx>
#include <Processing/SampleConsensus/detail/DataExtractor.hxx>
#include <Processing/SampleConsensus/detail/LossFunctions.hxx>
#include <Processing/SampleConsensus/detail/PreliminaryTest.hxx>
#include <Processing/SampleConsensus/detail/SAC.hxx>
#include <Processing/SampleConsensus/Consensus.h>

#include <boost/thread/thread.hpp>

#include <cstddef>
#include <limits>

namespace sample_consensus
{
    /**
     * @ingroup SAC
     * @defgroup RMSAC RMSAC
     * @brief Randomized M-estimator SAC algorithm
     *
     * It is an hybrid of @cite RRANSAC02 and @cite MLESAC00.
     * @{
     **/


    /**
     * @brief Computes the model parameters that minimize a given cost function over the samples using the supplied estimator.
     *
     * @param [out] model The model with lowest cost.
     * @param [in] samples Input data, containing both inliers and outliers.
     * @param [in] max_inliers_error Max fitting error of inlier samples.
     * @param [in] d Size of the sample used in the preliminary test.
     * @param [in] a Success rate, in the range [0, 1]. Defaults to 0.99.
     * @param [in] max_iterations Max algorithm iterations. Defaults to std::numeric_limits<unsigned int>::max().
     * @param [in] estimator Data analysis class. Defaults to the built-in estimator for the given model.
     * @param [in] threads_number Numer of threads to run in parallel. Defaults to boost::thread::hardware_concurrency().
     * @return Some details about both the model and the selection process.
     **/
    template<typename Model, typename Estimator, template<typename, typename> class Container, typename T, typename Allocator>
    inline ConsensusInfo RMSAC(Model& model, const Container<T, Allocator>& samples, double max_inliers_error, size_t d, double a, unsigned int max_iterations, Estimator& estimator, unsigned int threads_number = boost::thread::hardware_concurrency())
    {
        detail::SAC<sample_consensus::detail::BoundedSquareLoss> sac;
        return sac(model, 0, samples.size() - 1, detail::DataExtractor<Container<T, Allocator> >(samples), estimator, detail::TddTest(d), max_inliers_error, a, max_iterations, threads_number);
    }

    /** @cond **/
    template<typename Model, template<typename, typename> class Container, typename T, typename Allocator>
    inline ConsensusInfo RMSAC(Model& model, const Container<T, Allocator>& samples, double max_inliers_error, size_t d, double a = 0.99, unsigned int max_iterations = std::numeric_limits<unsigned int>::max())
    { typename detail::EstimatorTraits<Model>::EstimatorType estimator; return RMSAC(model, samples, max_inliers_error, d, a, max_iterations, estimator); }
    /** @endcond **/


    /**
     * @brief Computes the model parameters that minimize a given cost function over the samples using the supplied estimator.
     * @note This method is useful when you want to use indexes rather than the sample values.
     *
     * @param [out] model The model with lowest cost.
     * @param [in] min_sample Minimum input index.
     * @param [in] max_sample Maximum input index.
     * @param [in] estimator User-supplied data analysis class.
     * @param [in] max_inliers_error Max fitting error of inlier samples.
     * @param [in] d Size of the sample used in the preliminary test.
     * @param [in] a Success rate, in the range [0, 1].
     * @param [in] max_iterations Max algorithm iterations.
     * @param [in] estimator Data analysis class.
     * @param [in] threads_number Numer of threads to run in parallel. Defaults to boost::thread::hardware_concurrency().
     * @return Some details about both the model and the selection process.
     **/
    template<typename Model, typename Estimator>
    inline ConsensusInfo RMSAC(Model& model, size_t min_sample, size_t max_sample, double max_inliers_error, size_t d, double a, unsigned int max_iterations, Estimator& estimator, unsigned int threads_number = boost::thread::hardware_concurrency())
    {
        detail::SAC<sample_consensus::detail::BoundedSquareLoss> sac;
        return sac(model, min_sample, max_sample, detail::DataExtractor<void>(), estimator, detail::TddTest(d), max_inliers_error, a, max_iterations, threads_number);
    }

    /**@}*/
}

#endif
