#ifndef _TESSDATA_H
#define _TESSDATA_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file Data.h
 * @author Mirko Felisa (felisa@vislab.it)
 * @date 2012-04-16
 */

#include<boost/thread/thread.hpp>
#include<boost/utility.hpp>
#include<Eigen/StdVector>


namespace tessellation
{

    /**
    * @brief This class describes a triangle composed by 3 vertices and 3 edges pointing to other triangles. A vertex can be null (ghost triangle).
    * The Triangle class describes 3 triangles: abc, bca, cab. The correct triangle is identified by the orientation value.
    * In the neighbour pointer is stored the address of adiacent triangle, but also the orientation (in the last 2 bit of the point), for efficiency reason.
    * This required that the all triangles are aligned to the boundary of 4.
    **/
    template <class T>
    struct Triangle
    {
        /**
        * @brief Returns true if it is not a ghost triangle, false  otherwise. 
        * @return true if it is not a ghost triangle, false  otherwise. 
        **/
        bool Valid() const {return vertex[0] && vertex[1] && vertex[2];}
        
        /**
        * @brief pointer to triangle neighbours. The last 2 bit of the pointer store  the orientation of the pointed triangle.
        **/
        Triangle* neighbour[3];
        /**
        * @brief pointer to the vertices of the triangle.
        **/
        T*  vertex[3];
    };


    /**
    * @brief This class describes an oriented triangle.  It allows to iterate on a TriangleHull data structure. The operations on the TriangleHullCursor, described below, 
    * are detailed using the following convention.  Triangles  are denoted by their vertices. The triangle abc has origin (org) a, destination (dest) b, and apex (apex) c.
    * These vertices occur in counterclockwise order about the triangle.  * The handle abc may simultaneously denote vertex a, edge ab, and triangle  abc. 
    * An asterisk (*) denotes a vertex whose identity is unknown.       
    **/
    template<class T>
    class TriangleHullCursor
    {
    public :

         /**
        * @brief Default class constructor
        */
        TriangleHullCursor();

        /**
        * @brief Class constructor. It builds a cursor from a triangle pointer and orientation.
        * @param [in] t triangle pointer 
        * @param [in] o orientation
        */
        inline TriangleHullCursor(Triangle<T>* t, int o);


        /**
        * @brief Returns the origin vertex.
        * @return The origin vertex.
        **/
        inline T* Origin() const;

        /**
        * @brief Returns the destination vertex.
        * @return The destination vertex.
        **/
        inline T* Destination() const;

        /**
        * @brief Returns the apex vertex.
        * @return The apex vertex.
        **/
        inline T* Apex() const;

        /**
        * @brief Set the origin vertex.
        * @param [in] v vertex pointer
        **/
        inline void Origin(T* v);

        /**
        * @brief Set the destination vertex.
        * @param [in] v  vertex pointer
        **/
        inline void Destination(T* v);

        /**
        * @brief Set the apex vertex.
        * @param [in] v  vertex pointer
        **/
        inline void Apex(T* v);

        /**
        * @brief Returns the abutting triangle; same edge.   Back(abc) -> ba*    
        * @return the abutting triangle; same edge.   Back(abc) -> ba*    
        **/
        inline void Back();

        /**
        * @brief Returns the next edge counterclockwise with the same origin. Left(abc) -> ac*   
        * @return  the next edge counterclockwise with the same origin. Left(abc) -> ac*   
        **/
        inline void Left();

        /**
        * @brief  Returns the next edge clockwise with the same destination.   Right(abc) -> cb*    
        * @return   the next edge clockwise with the same destination.   Right(abc) -> cb*    
        **/
        inline void Right();

        /**
        * @brief Returns the next edge counterclockwise with the same destination.
        * @return the next edge (counterclockwise) of a triangle.  Rotate(abc) -> bca 
        **/
        inline void Rotate();

        /**
        * @brief Returns the previous edge (clockwise) of a triangle.  InverseRotate(abc) -> cab
        * @return the previous edge (clockwise) of a triangle.  InverseRotate(abc) -> cab
        **/
        inline void InverseRotate();

        /**
        * @brief Returns true if the two cursors point to the same triangle, false  otherwise.
        * @param [in] a TriangleHullCursor
        * @return  True if the two cursors point to the same triangle, false  otherwise. 
        **/
        inline bool operator== (const TriangleHullCursor& a) const;

        /**
        * @brief Returns true if the two cursors don't point to the same triangle, false  otherwise.
        * @param [in] a TriangleHullCursor
        * @return  True if the two cursors point to the same triangle, false  otherwise. 
        **/
        inline bool operator!= (const TriangleHullCursor& a) const;


    private:

        inline Triangle<T>* Encode() const;


        inline void Decode(Triangle<T>* t);

        Triangle<T>* triangle;
        int orientation;

        template<class U>
        friend  void Join(U& tri1, U& tri2);
        template<class U>
        friend void Back(const U& tri1, U& tri2);
        template<class U>
        friend void Left(const U& tri1, U& tri2);
        template<class U>
        friend void Right(const U& tri1, U& tri2);
        template<class U>
        friend void Rotate(const U& tri1, U& tri2);
        template<class U>
        friend void InverseRotate(const U& tri1, U& tri2);
    };

    /**
    * @brief Merge together two cursor
    * @param [in] tri1 first TriangleHullCursor
    * @param [in] tri2 second TriangleHullCursor
    **/
    template<class T>
    inline void Join(T& tri1, T& tri2);



    /**
    * @brief A data structure that describes the Delaunay Triangulation. Delaunay Triangulation class doesn't use the quad-edge data structure presented in@cite Guibas85 for efficiency
    * reason, but a Triangle-based structure. TriangleHull is a collection of Triangle joined together by the neighbour member pointer.
    * 
    * To preserve the elegance of Guibas and Stolfi's the divide-and-conquer algorithm, each triangulation is surrounded with a layer of ghost triangles, 
    * one triangle per convex hull edge. The ghost triangles are connected to each other in a ring about a ``vertex at infinity'' (really just a null pointer). 
    * A single edge is represented by two ghost triangles. Ghost triangles are useful for efficiently traversing the convex hull edges.
    *
    * @note The data structure is not noncopyable because the copy invalidates the structure.
    * @note You can use the cursor class to iterate on it.
    **/
    template< class T>
    class TriangleHull :  boost::noncopyable
    {
    public:

        typedef  TriangleHullCursor<T> CursorType;


        typedef std::vector<Triangle<T>, Eigen::aligned_allocator<Triangle<T> > > ContainerType;

        /**
        * @brief Returns the Cursor of Delaunay Triangulation
        * @return the Cursor of Delaunay Triangulation
        * @note The Cursor points to the ghost triangle (it's invalid) of Delaunay Triangulation and the origin vertex is Null;
        **/
        inline CursorType Cursor() const;


        /**
        * @brief Set the Cursor of Delaunay Triangulation
        **/
        inline void Cursor(CursorType c);


        /**
        * @brief Swap two TriangleHull
        * @param [in,out] h  input TriangleHull
        **/
        inline void Swap(TriangleHull& h);


        /**
        * @brief Returns the internal structure of Delaunay Triangulation
        * @return the internal structure of Delaunay Triangulation
        * @note If you modify it, you can invalidate the TriangleHull instance.
        * @note don't copy the internal structure
        **/
        inline ContainerType& Data();


        /**
        * @brief Returns the internal structure of Delaunay Triangulation.
        * @return the internal structure of Delaunay Triangulation.
        * @note It's useful for iterate on all triangle of Delaunay Triangulation.
        * @note don't copy the internal structure
        **/
        inline const ContainerType& Data() const;


    private:

        CursorType m_start;
        ContainerType m_data;

    };




}

#include"Processing/Tessellation/detail/Data.hxx"

#endif
