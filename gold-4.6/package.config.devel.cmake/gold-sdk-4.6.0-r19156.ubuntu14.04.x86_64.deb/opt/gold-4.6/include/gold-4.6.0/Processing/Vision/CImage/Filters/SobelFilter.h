#ifndef _SOBEL_FILTER_H
#define _SOBEL_FILTER_H

#include <stdint.h>
#include <Data/CImage/PixelTraits/PixelTraits.h>
#include "FilterModifier.h"
#include "ConvolutionKernel.h"
#include "TLocalFilter.h"

/**
 * \file SobelFilter.h
 * \brief This file contains the Sobel kernel functions
 */

namespace cimage {

/// Core classes
namespace kernel {

/**
 * \brief Implementa il calcolo di una maschera w x h verticale di Sobel (Sx)
*/
template<uint32_t w, uint32_t h>
class SobelVertical;

/**
 * \brief Implementa il calcolo di una maschera 3x3 verticale di Sobel
 * @note attenzione: questo filtro non e' normalizzato. Usare SobelVerticalAbs3x3 o SobelVerticalBias3x3 invece
 */
template<>
struct SobelVertical<3, 3>: public TConvolutionKernel3x3<-1,0,1,-2,0,2,-1,0,1>
{
};

/**
 * \brief Implementa il calcolo di una maschera 5x5 verticale di Sobel Sx
 * @note attenzione: questo filtro non e' normalizzato. Usare SobelVerticalAbs5x5 o SobelVerticalBias5x5 invece
 */
template<>
class SobelVertical<5, 5>: public TConvolutionKernel5x5<-1,-2,0,2,1, -4,-8,0,8,4, -6,-12,0,12,6, -4,-8,0,8,4, -1,-2,0,2,1>
{
  
};

/**
 * \brief Implementa il calcolo di una maschera w x h orizzontale di Sobel Sy
*/
template<uint32_t w, uint32_t h>
class SobelHorizontal;

/**
 * \brief Implementa il calcolo di una maschera 3x3 orizzontale di Sobel
 * @note attenzione: questo filtro non e' normalizzato. Usare SobelHorizontalAbs3x3 o SobelHorizontalBias3x3 invece
*/
template<>
struct SobelHorizontal<3, 3>: public TConvolutionKernel3x3<-1,-2,-1,0,0,0,+1,+2,+1>
{
};

/**
 * \brief Implementa il calcolo di una maschera 5x5 orizzontale di Sobel (Sx)
 * @note attenzione: questo filtro non e' normalizzato. Usare SobelHorizontalAbs5x5 o SobelHorizontalBias5x5 invece
 */
template<>
class SobelHorizontal<5, 5>: public TConvolutionKernel5x5<-1,-4,-6,-4,-1, -2,-8,-12,-8,-2, 0,0,0,0,0, 2,8,12,8,2, 1,4,6,4,1>
{
};

/******************************** Core Filtri Comuni ***************************************/

/** sobel verticale (normalizzato) con segno -128 e 127 (se l'input e' Mono8)
 * @note la output image deve avere il segno
 * \code
 * TLocalFilter< kernel::SobelVertical3x3 > filter;
 * filter(m_inputImageMono, m_outputImageMonoS);
 * \endcode
 **/
typedef filter::Div<SobelVertical<3,3>, 8> SobelVertical3x3;

/** Sobel verticale (normalizzato) in valore assoluto
* \code
* TLocalFilter< kernel::SobelVerticalAbs3x3 > filter;
* filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef filter::Shr< filter::Abs< SobelVertical<3,3> > , 2 > SobelVerticalAbs3x3;
/** Absolute verticla gradient with sobel kernel 5x5 
 * @see SobelVerticalAbs3x3 */
typedef filter::Shr< filter::Abs< SobelVertical<5,5> > , 5 > SobelVerticalAbs5x5;

/** sobel verticale senza segno
* \code
*	TLocalFilter< kernel::SobelVerticalBias3x3 > filter;
*	filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef filter::Bias<SobelVertical3x3, 127> SobelVerticalBias3x3;

/** sobel verticale binarizzato
 * @note non viene fatta la divisione per motivi di performance per cui la soglia deve essere moltiplicata per 8
 * \code
 * TLocalFilter< kernel::SobelVerticalBin3x3 > filter;
 * filter.SetThreshold( th * 8);
 * filter(m_inputImageMono, m_outputImageMono);
 * \endcode
 **/
typedef filter::AbsBin< SobelVertical<3,3> > SobelVerticalBin3x3;
/// @see SobelVerticalBin3x3 
typedef filter::AbsBin< SobelVertical<5,5> > SobelVerticalBin5x5;

/** sobel orizzontale (normalizzato) con segno -128 e 127
 * @note la output image deve avere il segno
 **/
typedef filter::Shr<SobelHorizontal<3,3>, 3> SobelHorizontal3x3;

/** Sobel orizzontale (normalizzato) in valore assoluto
* \code
* TLocalFilter< kernel::SobelHorizontalAbs3x3 > filter;
* filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef filter::Shr< filter::Abs< SobelHorizontal<3,3> > , 2 > SobelHorizontalAbs3x3;
/** Absolute horizontal gradient with sobel kernel 5x5 
 * @see SobelHorizontalAbs3x3 */
typedef filter::Shr< filter::Abs< SobelHorizontal<5,5> > , 5 > SobelHorizontalAbs5x5;


/** sobel orizzontale (normalizzato) senza segno
* \code
* TLocalFilter< kernel::SobelHorizontalBias3x3 > filter;
* filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef filter::Bias<SobelHorizontal3x3, 127> SobelHorizontalBias3x3;

/** sobel orizzontale binarizzato
 * @note non viene fatta la divisione per motivi di performance per cui la soglia deve essere moltiplicata per 8
 * \code
 * TLocalFilter< kernel::SobelHorizontalBin3x3 > filter;
 * filter.SetThreshold( th * 8);
 * filter(m_inputImageMono, m_outputImageMono);
 * \endcode
 **/
typedef filter::AbsBin< SobelHorizontal<3,3> > SobelHorizontalBin3x3;
/// @see SobelHorizontalBin3x3
typedef filter::AbsBin< SobelHorizontal<5,5> > SobelHorizontalBin5x5;

/** sobel verticale5x5 (normalizzato) con segno -128 e 127 **/
typedef filter::Div<SobelVertical<5,5>, 96> SobelVertical5x5;
/** sobel orizzontale (normalizzato) senza segno **/
typedef filter::Bias<SobelVertical5x5, 127> SobelVerticalBias5x5;

/** sobel verticale5x5 (normalizzato) con segno -128 e 127 **/
typedef filter::Div<SobelHorizontal<5,5>, 96> SobelHorizontal5x5;
/** sobel orizzontale (normalizzato) senza segno **/
typedef filter::Bias<SobelHorizontal5x5, 127> SobelHorizontalBias5x5;

/** filtro 'trova edge' usando Sobel. Output normalizzato.
  *  ritorna il massimo tra sobel orizzontale e verticale in valore assoluto
  * \code
  * TLocalFilter< kernel::SobelEdges3x3 > filter;
  * filter(m_inputImageMono, m_outputImageMono);
  * \endcode
  **/
typedef filter::Shr< filter::Max2< filter::Abs< SobelHorizontal<3,3> > , filter::Abs< SobelVertical<3,3> > >, 2> SobelEdges3x3;

/// edge of sobel, normalized using 64 (instead of 48)
typedef filter::Shr< filter::Max2< filter::Abs< SobelHorizontal<5,5> > , filter::Abs< SobelVertical<5,5> > >, 5> SobelEdges5x5;

///////// DISPARITA ///////
/** Immagine ternarizzata di sobel verticale
* \code
* TLocalFilter< kernel::SobelVerticalTern3x3 > filter;
* filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef filter::Ternarize<SobelVertical3x3, 3> SobelVerticalTern3x3;

/** Immagine ternarizzata di sobel orizzontale
* \code
* TLocalFilter< kernel::SobelHorizontalTern3x3 > filter;
* filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef filter::Ternarize<SobelHorizontal3x3, 3> SobelHorizontalTern3x3;

/// Genera una immagine di sobel con il modulo calcolato come (|gx|+|gy|)/16
typedef filter::Shr< filter::Sum2< filter::Abs< SobelVertical<3,3> >, filter::Abs< SobelHorizontal<3,3> > >, 4 > SobelModule3x3;

/** Modulo (Norma Euclidea) di Sobel con soglia */
typedef filter::ModuleBin< SobelVertical<3,3>, SobelHorizontal<3,3> > SobelModuleBin3x3;

/** Create a Pair Image of Module + Phase */
typedef filter::MakePair_Module_Phase< SobelVertical<3,3>, SobelHorizontal<3,3> > SobelModulePhase3x3;

} // kernel typedef and classes

/******************* Filtri ********************************************/

namespace filter {

/** sobel verticale (normalizzato) con segno -128 e 127 (se l'input e' Mono8)
 * @note la output image deve avere il segno
 * \code
 * filter::SobelVertical3x3 filter;
 * filter(m_inputImageMono, m_outputImageMonoS);
 * \endcode
 **/
typedef TLocalFilter<kernel::SobelVertical3x3> SobelVertical3x3;

/** Sobel verticale (normalizzato) in valore assoluto
* \code
* filter::SobelVerticalAbs3x3 filter;
* filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef TLocalFilter<kernel::SobelVerticalAbs3x3> SobelVerticalAbs3x3;
/// normalized absolute vertical sobel using a 5x5 kernel
/// @see SobelVerticalAbs3x3
typedef TLocalFilter<kernel::SobelVerticalAbs5x5> SobelVerticalAbs5x5;

/** sobel verticale senza segno
* \code
*	filter::SobelVerticalBias3x3 filter;
*	filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef TLocalFilter<kernel::SobelVerticalBias3x3 > SobelVerticalBias3x3;

/** sobel orizzontale (normalizzato) con segno -128 e 127
 * @note la output image deve avere il segno
 **/
typedef TLocalFilter<kernel::SobelHorizontal3x3> SobelHorizontal3x3;

/** Sobel orizzontale (normalizzato) in valore assoluto
* \code
* filter::SobelHorizontalAbs3x3 filter;
* filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef TLocalFilter<kernel::SobelHorizontalAbs3x3> SobelHorizontalAbs3x3;
/// normalized absolute horizontal sobel using a 5x5 kernel
/// @see SobelHorizontalAbs3x3
typedef TLocalFilter<kernel::SobelHorizontalAbs5x5> SobelHorizontalAbs5x5;

/** sobel orizzontale (normalizzato) senza segno
* \code
* filter::SobelHorizontalBias3x3 filter;
* filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef TLocalFilter<kernel::SobelHorizontalBias3x3> SobelHorizontalBias3x3;

/** Sobel verticale con soglia per ottenere un'immagine binaria 
 * @note the sobel filter is unormalized then the threshold must deal with a scale factor
 */
typedef TLocalFilter<kernel::SobelVerticalBin3x3 > SobelVerticalBin3x3;
/** Binarized vertical sobel with a 5x5 kernel
 * @note the sobel filter is unormalized then the threshold must deal with a scale factor
 */
typedef TLocalFilter<kernel::SobelVerticalBin5x5 > SobelVerticalBin5x5;

/** Sobel orizzontale con soglia per ottenere un'immagine binaria 
 * @note the sobel filter is unormalized then the threshold must deal with a scale factor
 */
typedef TLocalFilter<kernel::SobelHorizontalBin3x3 > SobelHorizontalBin3x3;
/** Binarized horizontal sobel with a 5x5 kernel
 * @note the sobel filter is unormalized then the threshold must deal with a scale factor
 * @see SobelHorizontalBin3x3 */
typedef TLocalFilter<kernel::SobelHorizontalBin5x5 > SobelHorizontalBin5x5;

/** sobel verticale5x5 (normalizzato) con segno -128 e 127 **/
typedef TLocalFilter<kernel::SobelVertical5x5> SobelVertical5x5;
/** sobel orizzontale (normalizzato) senza segno **/
typedef TLocalFilter<kernel::SobelVerticalBias5x5> SobelVerticalBias5x5;

/** sobel verticale5x5 (normalizzato) con segno -128 e 127 **/
typedef TLocalFilter<kernel::SobelHorizontal5x5> SobelHorizontal5x5;
/** sobel orizzontale (normalizzato) senza segno **/
typedef TLocalFilter<kernel::SobelHorizontalBias5x5> SobelHorizontalBias5x5;

/** filtro 'trova edge' usando Sobel. Output normalizzato.
  *  ritorna il massimo tra sobel orizzontale e verticale in valore assoluto
  * \code
  * filter::SobelEdges3x3 filter;
  * filter(m_inputImageMono, m_outputImageMono);
  * \endcode
  **/
typedef TLocalFilter<kernel::SobelEdges3x3> SobelEdges3x3;

///////// DISPARITA ///////
/** Immagine ternarizzata di sobel verticale
* \code
* filter::SobelVerticalTern3x3 filter;
* filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef TLocalFilter<kernel::SobelVerticalTern3x3> SobelVerticalTern3x3;

/** Immagine ternarizzata di sobel orizzontale
* \code
* filter::SobelHorizontalTern3x3 filter;
* filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef TLocalFilter<kernel::SobelHorizontalTern3x3> SobelHorizontalTern3x3;

/** Modulo di sobel binarizzato */
typedef TLocalFilter<kernel::SobelModuleBin3x3> SobelModuleBin3x3;

/** Generate a Module + Phase image.
  * @note it require 2 output image to be comuted */
typedef TLocalFilter<kernel::SobelModulePhase3x3 > SobelModulePhase3x3;


/** edge find filter using Sobel 5x5 kernel. The output is correctly normalized in order to deal with data range.
  * The filter set using the maximum between Absolute Sobel horizontal and Sobel vertical.
  * \code
  * filter::SobelEdges5x5 filter;
  * filter(m_inputImageMono, m_outputImageMono);
  * \endcode
  **/
typedef TLocalFilter<kernel::SobelEdges5x5> SobelEdges5x5;


} // filter

} // cimage

#endif
