// The template and inlines for the -*- C++ -*- internal LutPixel helper class.

/** @file LutPixel.hxx
 *  This is an internal header file, included by other library headers.
 *  You should not attempt to use it directly.
 */

// Written by Paolo Medici <medici@ce.unipr.it>

#ifndef _LUT_PIXEL_HXX
#define _LUT_PIXEL_HXX

#include <boost/math/tr1.hpp> 

#include "LutPixel.h"

inline void PixelPos::set(double xs, double ys, unsigned int width, unsigned int height)
    {
    int x,y;
    x = (int) boost::math::tr1::round(xs);
    y = (int) boost::math::tr1::round(ys);

    if((x>=0)&&(y>=0)&&(x<(int)width)&&(y<(int)height))
        {
        col = x;
        row = y; 
        }
    else
        {
        col = row = IMGLUT_UNDEFINED;
        }
    }

template<unsigned int byte_per_pixel, typename C>
inline C * PixelPos::apply(C * dst, const C * src, long stride) const
    {
    unsigned int k = byte_per_pixel;
    src +=  col * byte_per_pixel + row * stride;
    do {
        *dst++ = *src++;
        } while(--k);
    return dst;
    }

//////////

inline void BilinearPixel::set(double xs, double ys, unsigned int width, unsigned int height)
    {
    int ixs, iys;
    double dx, dy;
    
    ixs = (int) floor(xs);
    iys = (int) floor(ys);
    
    if((ixs>=0)&&(iys>=0)&&(ixs<(int)width)&&(iys<(int)height))
        {
        dx = xs - floor(xs);
        dy = ys - floor(ys);
        
        if(ixs+1==(int)width)
                {
                ixs = width - 2;
                dx = 1.0;
                }
        
        if(iys+1==(int)height)
                {
                iys =  height - 2;
                dy = 1.0;
                }
                
        span = ixs + iys * width;
    
        k[0] = (1.0 - dy) * (1.0 - dx);  // a
        k[1] = dx* (1.0 - dy);   // b
        k[2] = (1.0 - dx) * dy;  // c
        k[3] = dx * dy;  // d
        }
    else
        {
        span = -1;
        }
    }

template<unsigned int byte_per_pixel, typename C>
inline C * BilinearPixel::apply(C * dst, const C * src, long stride) const
    {
    const float *weight = k;
    unsigned int c = byte_per_pixel;
    src += span * byte_per_pixel;
    do {
        *dst = (C) ( (src[0] * weight[0]) +
            (src[byte_per_pixel] * weight[1]) + 
            (src[stride] * weight[2]) + 
            (src[stride + byte_per_pixel] * weight[3]) );
        dst++;
        src++;
        } while(--c);
    return dst;
    }

//////////

template<unsigned int byte_per_pixel, typename C>
inline C * FPBilinearPixel::apply(C * dst, const C * src, long stride) const
    {
    const unsigned char *weight = k;
    unsigned int c = byte_per_pixel;
    src += span * byte_per_pixel;
    do {
        *dst= (C) (( ( (unsigned int) src[0] * weight[0]) +
        ((unsigned int) src[byte_per_pixel] * weight[1]) + 
        ((unsigned int) src[stride] * weight[2]) + 
        ((unsigned int) src[stride + byte_per_pixel] * weight[3]) )>>8);
        dst++;
        src++;
        } while(--c);
    return dst;
    }
    
inline unsigned char fp_cast(double p)
{
int x = (int) boost::math::tr1::round(p * 256.0);  // sorry :(
return (x<0) ? 0 : ((x>255) ? 255 : (x));
}

inline void FPBilinearPixel::set(double xs, double ys, unsigned int width, unsigned int height)
    {
    int ixs,iys;
    ixs = (int) floor(xs);
    iys = (int) floor(ys);
    
    if((ixs>=0)&&(iys>=0)&&(ixs<(int)width)&&(iys<(int)height))
        {
        double dx,dy;
        dx = xs - floor(xs);    // TODO: e' il modo migliore????
        dy = ys - floor(ys);
        
        if(ixs+1==(int)width)
                {
                ixs = width - 2;
                dx = 1.0;
                }
        
        if(iys+1==(int)height)
                {
                iys =  height - 2;
                dy = 1.0;
                }
                
        span = ixs + iys * width;
    
        k[0] = fp_cast((1.0 - dy) * (1.0 - dx)); // a
        k[1] = fp_cast(dx* (1.0 - dy));  // b
        k[2] = fp_cast((1.0 - dx) * dy); // c
        k[3] = fp_cast(dx * dy);  // d
        }
    else
        {
        span = IMGLUT_UNDEFINED;
        }
    }

#endif
