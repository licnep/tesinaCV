#ifndef _UI_DISPARITYENGINE_H
#define _UI_DISPARITYENGINE_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2011                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/


/**
 * \file UI_DisparityEngine.h
 * \author Paolo Zani (zani@vislab.it) Mirko Felisa (felisa@vislab.it)
 * \date 2011-02-04
 */


#include <Processing/Vision/Stereo/DisparityEngine/DisparityEngine.h>
#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/UI_Window.h>
#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/UI_Census.h>
#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/UI_ELAS.h>
#include <Processing/Vision/Stereo/DisparityEngine/Optimization/UI_SGM.h>
#include <Processing/Vision/Stereo/DisparityEngine/Optimization/UI_FilteredWTA.h>
#include <Processing/Vision/Stereo/DisparityEngine/Optimization/UI_None.h>
#include <Processing/Vision/PerspectiveMapping/StereoTriangulation.h>
#include <Data/CImage/TImage.h>
#include <Data/CImage/Images/CImageMono8.h>
#include <UI/CWindows/CWindow.h>
#include <UI/CWindows/CWindowCamera3D.h>
#include <UI/CWindows/CWindowTypes.h>
#include <UI/CWindows/CWindowCore.h>
#include <UI/CWindows/CWindowCoreManager.h>
#include <UI/CWindows/CWidget.h>
#include <UI/CWindows/Navigation.h>
#include <Data/Base/CCameraParams.h>
#include <UI/Panel/Panel.h>

#include <boost/shared_ptr.hpp>
#include <boost/algorithm/string.hpp>
#include <string>

namespace disparity
{

    template<template<typename> class Cost, typename ResultType_Cost,
            template<typename, typename, typename, uint32_t> class Aggregation, typename ResultType_Agg, typename Impl_Agg, uint32_t Threads_Agg,
            template<typename, uint32_t, typename, typename, uint32_t> class Optimization, typename ResultType_Opt, typename Impl_Opt, uint32_t Threads_Opt>
    class UI_TDisparityEngine : public TDisparityEngine<Cost, ResultType_Cost,
                                                        Aggregation, ResultType_Agg, Impl_Agg, Threads_Agg,
                                                        Optimization, ResultType_Opt, Impl_Opt, Threads_Opt>
    {
        public:

            typedef TDisparityEngine<Cost, ResultType_Cost,
                                              Aggregation, ResultType_Agg, Impl_Agg, Threads_Agg,
                                              Optimization, ResultType_Opt, Impl_Opt, Threads_Opt> DisparityEngineType;

            typedef UI_Aggregation<typename DisparityEngineType::AggregationType, DisparityEngineType> UI_AggregationType;

            typedef UI_Optimization<typename DisparityEngineType::OptimizationType, DisparityEngineType> UI_OptimizationType;

            UI_TDisparityEngine() :
                m_aggregation(this),
                m_optimization(this),
                m_pDSIWindow(NULL),
                m_p3DWindow(NULL),
                m_showDSIWindow(false),
                m_showDSIValues(false),
                m_invertColor(false),
                m_show3DWindow(false)
            {}

            void Init(INIFile* pIni)
            {
                ui::var::Range<uint32_t> topOffset(&this->m_topOffset, 0, 100, 1);
                ui::var::Range<uint32_t> bottomOffset(&this->m_bottomOffset, 0, 100, 1);
                ui::var::Range<uint32_t> leftOffset(&this->m_leftOffset, 0, 100, 1);
                ui::var::Range<uint32_t> rightOffset(&this->m_rightOffset, 0, 100, 1);
                ui::var::Range<int32_t> alpha(&this->m_alpha, 0, 255, 1);
                ui::var::Value<bool> showDSIWindow(&m_showDSIWindow);
                ui::var::Value<bool> show3DWindow(&m_show3DWindow);
                ui::var::Value<bool> showDSIValues(&m_showDSIValues);
                ui::var::Value<bool> invertColor(&m_invertColor);

                ui::conf::Configuration conf(pIni);

                conf.Bind(topOffset, "TOP OFFSET", 0U);
                conf.Bind(bottomOffset, "BOTTOM OFFSET", 0U);
                conf.Bind(leftOffset, "LEFT OFFSET", 0U);
                conf.Bind(rightOffset, "RIGHT OFFSET", 0U);
                conf.Bind(showDSIWindow, "SHOW DSI WINDOW", false);
                conf.Bind(show3DWindow, "SHOW 3D WINDOW", false);
                m_aggregation.Init(pIni? pIni->Node(boost::to_upper_copy(m_aggregation.Name())) : NULL);
                m_optimization.Init(pIni? pIni->Node(boost::to_upper_copy(m_optimization.Name())) : NULL);

                m_panel
                (
                    ui::wgt::VSizer()
                    (
                        ui::wgt::VSizer().Border(3)
                        (
                            ui::wgt::NoteBook()
                            (
                                ui::wgt::Page("Display")
                                (
                                    ui::wgt::VSizer()
                                    (
                                        ui::wgt::CheckBox(showDSIWindow, "Show DSI window"),
                                        ui::wgt::CheckBox(showDSIValues, "Show DSI values"),
                                        ui::wgt::CheckBox(invertColor, "Invert background color"),
                                        ui::wgt::CheckBox(show3DWindow, "Show 3D view"),
                                        ui::wgt::HSizer()
                                        (
                                            ui::wgt::Text("Alpha").HExpand(false).Border(3),
                                            ui::wgt::Slider(alpha)
                                        )
                                    )
                                ),
                                ui::wgt::Page("Preprocessing")
                                (
                                    ui::wgt::VSizer()
                                    (
                                        ui::wgt::VBoxSizer("Crop").Border(3)
                                        (
                                            ui::wgt::GridSizer().Border(3)
                                            (
                                                ui::wgt::SzCell(0, 0)( ui::wgt::Text("Top") ), ui::wgt::SzCell(0, 1).HExpand()( ui::wgt::Slider(topOffset) ),
                                                ui::wgt::SzCell(1, 0)( ui::wgt::Text("Bottom") ), ui::wgt::SzCell(1, 1).HExpand()( ui::wgt::Slider(bottomOffset) ),
                                                ui::wgt::SzCell(2, 0)( ui::wgt::Text("Left") ), ui::wgt::SzCell(2, 1).HExpand()( ui::wgt::Slider(leftOffset) ),
                                                ui::wgt::SzCell(3, 0)( ui::wgt::Text("Right") ), ui::wgt::SzCell(3, 1).HExpand()( ui::wgt::Slider(rightOffset) )
                                            )
                                        )
                                    )
                                ),
                                ui::wgt::Page(m_aggregation.Name())
                                (
                                    m_aggregation.Panel()
                                ),
                                ui::wgt::Page(m_optimization.Name())
                                (
                                    m_optimization.Panel()
                                )
                            )
                        )
                    )
                );
            }

            ~UI_TDisparityEngine()
            {
                delete m_pDSIWindow;
                delete m_p3DWindow;
            }

            ui::wgt::Panel Panel() const { return m_panel; }

            template<typename T>
            void Output(const cimage::TImage<T>& background = cimage::CImageMono8(), const std::pair<CameraParams, CameraParams>& p = std::make_pair(CameraParams(),CameraParams()))
            {
                Draw(background, background.Buffer(), p);
            }

            template<typename T>
            void Output(boost::shared_ptr<T> background, const std::pair<CameraParams, CameraParams>& p =std::make_pair(CameraParams(),CameraParams()))
            {
                Draw(background, background->Buffer(), p);
            }

            template<typename T>
            void Output(const cimage::TImage<T>& background, const CameraParams& pl , const CameraParams& pr)
            {
                Draw(background, background.Buffer(), std::make_pair(pl, pr));
            }

            template<typename T>
            void Output(typename boost::shared_ptr<T> background, const CameraParams& pl, const CameraParams& pr)
            {
                Draw(background, background->Buffer(), std::make_pair(pl, pr));
            }


        private:


            cimage::RGB8 GetColor(cimage::Mono8 p) {return cimage::RGB8(p,p,p);}
            cimage::RGB8 GetColor(const cimage::RGB8 & p) {return p;}

            template <typename T, typename U>
            void Draw(T& background, const U* buffer,  std::pair<CameraParams, CameraParams> params)
            {
                if(!this->m_dsi || !(this->m_dsi->W() * this->m_dsi->H()))
                    return;

                if(m_showDSIWindow)
                {
                    if(!m_pDSIWindow)
                        m_pDSIWindow = new ui::win::CWindow("DSI", this->m_dsi->W(), this->m_dsi->H());

                    static uint32_t winSize = 0;
                    if (winSize != this->m_dsi->W() )
                    {
                        m_pDSIWindow->SetSize (this->m_dsi->W(), this->m_dsi->H());
                        winSize =this->m_dsi->W();  
                    }    
                    
                    if(!m_pDSIWindow->IsVisible())
                        m_pDSIWindow->Show();

                    m_pDSIWindow->Clear();
                    m_pDSIWindow->DrawImage(background);
                    m_pDSIWindow->EnableBlend();
                    if (m_invertColor)
                       m_pDSIWindow->SetBlend(ui::win::BLEND_SUBTRACT);
                    else
                       m_pDSIWindow->SetBlend(ui::win::BLEND_ALPHA);
                    m_pDSIWindow->DrawImage(this->m_dsi);
                    if (m_showDSIValues)
                    {
                       m_pDSIWindow->Push(boost::shared_ptr<ui::win::CWidget>(new CDSIDebugWidget(DisparityEngineType::GetDSI(), DisparityEngineType::GetScores())));
                    }
                    m_pDSIWindow->Refresh();
                } else
                    if(m_pDSIWindow)
                        m_pDSIWindow->Hide();


           if (m_show3DWindow)
            {
                if (!params.first.ku || !params.first.kv || !params.second.ku || !params.second.kv)
                {
                    return;
                }

                if (!m_p3DWindow)
                {
                    m_p3DWindow = new ui::win::CWindow ("3D View", this->m_dsi->W(), this->m_dsi->H());
                    
                    const CameraParams& p = params.second;
                    
                    ///////////////////////////////////////////////////////////////////////////
                    //// sample code for navigation plugin
                    ///////////////////////////////////////////////////////////////////////////
                    boost::shared_ptr<ui::win::Navigation> viewer( new  ui::win::Navigation() );

                    // inserisce il primo segmento
                    ui::win::Navigation::Segment segment;
                    
                    // CCamera3D(double hfov, double vfov, double u0, double v0, double yaw, double pitch, double roll, double x0, double y0, double z0);
                    // CWindowCamera3D (atan (p.u0 / p.ku), atan (p.v0 / p.kv),        // hfov, vfov
                    // p.u0 / this->m_dsi->W() - 0.5, p.v0 / this->m_dsi->H() - 0.5,   // u0, vo
                    // p.yaw, p.pitch, p.roll,                                         // yaw, pitch, roll
                    // p.x, p.y, p.z)));                                               // x, y, z

                    segment.begin.ku=p.u0/p.ku;
                    segment.begin.ratio=(p.v0/p.ku)/(p.v0/p.kv);

                    segment.begin.u0=p.u0 / this->m_dsi->W() - 0.5;
                    segment.begin.v0=p.v0 / this->m_dsi->H() - 0.5;

                    segment.begin.x0=p.x; 
                    segment.begin.y0=p.y;
                    segment.begin.z0=p.z;

                    segment.begin.yaw=p.yaw;
                    segment.begin.pitch=p.pitch;
                    segment.begin.roll=p.roll;

                    segment.end=segment.begin;
                    
                    segment.look_at_begin = math::Point3d(0.0, 0.0, 0.0);
                    segment.look_at_end = math::Point3d(0.0, 0.0, 0.0);
                    
                    viewer->AddSegment(segment);
                    
                    // assegna il nome del file da usare
                    viewer->m_fs_path = "3dview-camera_path.txt";
                    // viewer->Load(); // carica il path da file
                  
                    // inserisce il plugin nella finestra
                    m_p3DWindow->InsertPlugin( viewer );    

                    // assegna all finestra la camera del viewer
                    m_p3DWindow->SetCamera ( viewer->Camera() );
                    ///////////////////////////////////////////////////////////////////////////                    
                    
                    // old code
                    // m_p3DWindow->SetCamera (ui::win::sharedPtrWindowCamera (new ui::win::CWindowCamera3D (atan (p.u0 / p.ku), atan (p.v0 / p.kv), p.u0 / this->m_dsi->W() - 0.5, p.v0 / this->m_dsi->H() - 0.5, p.yaw, p.pitch, p.roll, p.x, p.y, p.z)));
                }

                std::vector<math::Point3f> worldPoint;
                DSIToWorldCoords (*this->m_dsi, params, worldPoint);
                std::vector<ui::win::C4UB_V3F_t> colored_points;
                uint32_t area = this->m_dsi->W() * this->m_dsi->H();
                for (uint32_t i = 0; i < area; i++)
                {
                    ui::win::C4UB_V3F_t colored_pix;
                    math::Point3f&  w = worldPoint[i];
                    cimage::RGB8 c = GetColor (buffer[i]);
                    colored_pix.x = w.x;
                    colored_pix.y = w.y;
                    colored_pix.z = w.z;
                    colored_pix.r = c.R;
                    colored_pix.g = c.G;
                    colored_pix.b = c.B;
                    colored_points.push_back (colored_pix);
                }
                m_p3DWindow->Show();
                m_p3DWindow->Clear();
                m_p3DWindow->EnableZBuffer (0.5, 200.0);
                m_p3DWindow->SetBackgroundColor (cimage::RGBA8 (0, 0, 0, 0));
                m_p3DWindow->SetPointSize (2);
                m_p3DWindow->DrawColorPixels3 (colored_points);
                m_p3DWindow->DisableZBuffer();
                m_p3DWindow->Refresh();
            }
            else
                if (m_p3DWindow)
                {
                    m_p3DWindow->Hide();
                }
            }



            class CDSIDebugWidget : public ui::win::CWidget
            {
                public:

                    inline CDSIDebugWidget(boost::shared_ptr<const CDSI> dsi, boost::shared_ptr<const CScoreImage> score) : m_dsi(dsi), m_score(score) {}

                    inline const char* getName() const
                    {
                        return "DSI Debug";
                    }

                    inline bool Interact(ui::win::CWindowCoreManager* pWindow, const ui::win::CWindowEvent& event)
                    {
                        switch (event.event)
                        {

                        case(ui::win::WEF_MOUSE_MOTION):
                        {
                            int x = static_cast<int>(event.pos.x);
                            int y = static_cast<int>(event.pos.y);

                            if (x > 0 && x < static_cast<int>(m_dsi->W()) && y > 0 && y < static_cast<int>(m_dsi->H()))
                            {
                                // TODO: serve il lock?
                                Disparity d = m_dsi->Buffer()[y * m_dsi->W() + x];

                                Score s = m_score->Buffer()[y * m_score->W() + x];

                                std::ostringstream oss;

                                oss << "(" << x << ", "<< y << "): Disparity = ";

                                if (d == DISPARITY_UNKNOWN)
                                    oss << "DISPARITY_UNKNOWN";
                                else
                                    oss << static_cast<double>(d);

                                oss << " Score = ";

                                if (s == SCORE_UNKNOWN)
                                    oss << "SCORE_UNKNOWN";
                                else
                                    oss << static_cast<double>(s);

                                pWindow->SetCustomStatusBar(oss.str());
                            }
                            else
                                pWindow->SetCustomStatusBar("");

                            pWindow->Refresh();
                        }

                        default:
                            ;
                        }

                        return true;
                    }

            private:

                boost::shared_ptr<const CDSI> m_dsi;
                boost::shared_ptr<const CScoreImage> m_score;
            };

            UI_AggregationType m_aggregation;
            UI_OptimizationType m_optimization;

            ui::wgt::Panel m_panel;

            ui::win::CWindow* m_pDSIWindow;
            ui::win::CWindow* m_p3DWindow;
    public :
            bool m_showDSIWindow;
            bool m_showDSIValues;
            bool m_invertColor;
            bool m_show3DWindow;
    };
}

typedef disparity::UI_TDisparityEngine<disparity::cost::None, void,
                                    disparity::agg::Census, uint8_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                    disparity::opt::FilteredWTA, uint8_t, disparity::impl::Auto, PLATFORM_CPU_CORES> UI_DisparityEngine_Census_FilteredWTA;

typedef disparity::UI_TDisparityEngine<disparity::cost::None, void,
                                    disparity::agg::Census, uint8_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                    disparity::opt::SGM, uint8_t, disparity::impl::Auto, PLATFORM_CPU_CORES> UI_DisparityEngine_Census_SGM;

typedef disparity::UI_TDisparityEngine<disparity::cost::AbsDiff, uint16_t,
                                    disparity::agg::Window_Simple, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                    disparity::opt::FilteredWTA, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES> UI_DisparityEngine_Simple_FilteredWTA;

typedef disparity::UI_TDisparityEngine<disparity::cost::AbsDiff, uint16_t,
                                    disparity::agg::Window_Simple, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                    disparity::opt::SGM, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES> UI_DisparityEngine_Simple_SGM;

typedef disparity::UI_TDisparityEngine<disparity::cost::AbsDiff, uint16_t,
                                    disparity::agg::Window_SemiIncremental, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                    disparity::opt::FilteredWTA, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES> UI_DisparityEngine_SemiIncremental_FilteredWTA;

typedef disparity::UI_TDisparityEngine<disparity::cost::AbsDiff, uint16_t,
                                    disparity::agg::Window_SemiIncremental, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                    disparity::opt::SGM, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES> UI_DisparityEngine_SemiIncremental_SGM;

typedef disparity::UI_TDisparityEngine<disparity::cost::AbsDiff, uint16_t,
                                    disparity::agg::Window_Incremental, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                    disparity::opt::FilteredWTA, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES> UI_DisparityEngine_Incremental_FilteredWTA;

typedef disparity::UI_TDisparityEngine<disparity::cost::AbsDiff, uint16_t,
                                    disparity::agg::Window_Incremental, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                    disparity::opt::SGM, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES> UI_DisparityEngine_Incremental_SGM;

typedef disparity::UI_TDisparityEngine < disparity::cost::None, void,
                                    disparity::agg::ELAS, uint8_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                    disparity::opt::None, uint8_t, disparity::impl::Auto, PLATFORM_CPU_CORES > UI_DisparityEngine_ELAS;
                                    
                                    
typedef UI_DisparityEngine_Census_SGM UI_DisparityEngine;
#endif


