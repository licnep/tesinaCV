#ifndef _CIMAGE_ALGORITHMS_H
#define _CIMAGE_ALGORITHMS_H

#include <Data/CImage/TImage.h>

#include "PixelFunctors.h"

namespace cimage
{
namespace algorithms
{
  // TODO: versioni che operano su RegularRegions, Maschere e contenitori di PixelCoordinates
  /**
   * Esecuzione una operazione su ciacun pixel dell'immagine
   * Riceve una copia del functor e la ritorna
   * Il functor deve avere un operator ()(const ImageType::PixelType&) che viene invocato per ciascun pixel
   * Se TImage<type> A(10, 10); for_each(A, Operation) invoca Operation(A) per ogni pixel di A
   * @param Image Immagine su cui operare
   * @param Functor Oggetto funzione da chiamare
   * @return l'oggetto funzione modificato
   */

  template <class ImageType, class OpType>
  OpType for_each ( const ImageType &Image, OpType Operation )
  {
    typename ImageType::PixelType *pPos = Image.Buffer();
    const typename ImageType::PixelType *pEnd = pPos+Image.Area();

    for ( ; pPos<pEnd; ++pPos )
      Operation ( *pPos );

    return Operation;
  }

  /**
   * Esecuzione una trasformazione unaria: a ciascun pixel dell'immagine destinazione viene 
   * assegnato il risultato del functor calcolato usando come parametro il pixel corrispondente
   * dell'immagine sorgente
   * con sorgente e destinazione separate ( AVENTI STESSE DIMENSIONI)
   * TImage<type> A(10, 10), B(10, 10);
   * A = Operation(B)
   * @param DstImage Immagine destinazione
   * @param SrcImage  Immagine sorgente
   * @param Functor Oggetto funzione da chiamare
   * @return l'oggetto funzione modificato
   */
  template <class DstType ,class SrcType, class OpType>
  OpType transform ( const SrcType& SrcImage, DstType& DstImage, OpType Operation )
  {
    // Controllo dei prerequisiti
    // Le immagini devono avere le stesse dimensioni
    if ( ( ( DstImage.W() ) !=SrcImage.W() ) || ( ( DstImage.H() ) !=SrcImage.H() ) )
      throw std::runtime_error ( "Cannot apply a pixel by pixel operator to images with different sizes" );

    typename DstType::PixelType *pDst = DstImage.Buffer();

    const typename DstType::PixelType  *pEnd  =  pDst+DstImage.Area();
    const typename SrcType::PixelType *pSrc = SrcImage.Buffer();

    for (; pDst != pEnd; ++pSrc, ++pDst)
      *pDst=Operation( *pSrc );

    // FIXME: per analogia dovrebbe tornare DstImage
    return Operation;
  }

  /**
   * Esecuzione di operazioni pixel per pixel
   * con due immagini sorgente e una destinazione ( AVENTI STESSE DIMENSIONI)
   * A=op(B,C)
   * @param SrcImage  Immagine sorgente 1
   * @param SrcImage  Immagine sorgente 2
   * @param DstImage Immagine modificata
   * @param Functor Oggetto funzione da chiamare
   * @return l'oggetto funzione modificato
   */
  template <class DstType ,class SrcAType, class SrcBType, class OpType>
  OpType transform ( const SrcAType& SrcImageA,const SrcBType& SrcImageB, DstType& DstImage, OpType Operation )
  {
    // Controllo dei prerequisiti

    // Le immagini devono avere le stesse dimensioni
    if ( ( ( DstImage.W() ) !=SrcImageA.W() ) || ( ( DstImage.H() ) !=SrcImageA.H() )
            || ( ( DstImage.W() ) !=SrcImageB.W() ) || ( ( DstImage.H() ) !=SrcImageB.H() ) )
      throw std::runtime_error ( "Cannot apply a pixel by pixel operator to images with different sizes" );

    //TODO: se la maschera non ha dimensioni sottomultiple o uguali a quelle della sorgente throw...
    typename DstType::PixelType *pDst = DstImage.Buffer();

    const typename DstType::PixelType  *pEnd  =  pDst+DstImage.Area();
    const typename SrcAType::PixelType *pSrcA = SrcImageA.Buffer();
    const typename SrcBType::PixelType *pSrcB = SrcImageB.Buffer();

    for (; pDst != pEnd; ++pDst, ++pSrcA, ++pSrcB )
      *pDst = Operation ( *pSrcA, *pSrcB );

    // FIXME: per analogia dovrebbe tornare DstImage
    return Operation;
  }

  /**
   * Esecuzione di operazioni pixel per pixel
   * con sorgente e destinazione separate ( AVENTI STESSE DIMENSIONI)
   * TImage<type> A(10, 10), B(10, 10);
   * A op= B
   * @param DstImage Immagine destinazione
   * @param SrcImage  Immagine sorgente
   * @param Functor Oggetto funzione da chiamare
   * @return l'oggetto funzione modificato
   */
  template <class DstType ,class SrcType, class OpType>
  OpType transform_self ( const SrcType& SrcImage, DstType& DstImage, OpType Operation )
  {
    // Controllo dei prerequisiti
    // Le immagini devono avere le stesse dimensioni
    if ( ( ( DstImage.W() ) !=SrcImage.W() ) || ( ( DstImage.H() ) !=SrcImage.H() ) )
      throw std::runtime_error ( "Cannot apply a pixel by pixel operator to images with different sizes" );

    typename DstType::PixelType *pDst = DstImage.Buffer();

    const typename DstType::PixelType  *pEnd  =  pDst+DstImage.Area();
    const typename SrcType::PixelType *pSrc = SrcImage.Buffer();

    for (; pDst != pEnd; ++pSrc, ++pDst)
      Operation( *pDst, *pSrc );

    // FIXME: per analogia dovrebbe tornare DstImage
    return Operation;
  }

  /**
   * Esecuzione di operazioni pixel per pixel
   * con due immagini sorgente e una destinazione ( AVENTI STESSE DIMENSIONI)
   * A op=(B,C)
   * @param SrcImage  Immagine sorgente 1
   * @param SrcImage  Immagine sorgente 2
   * @param DstImage Immagine modificata
   * @param Functor Oggetto funzione da chiamare
   * @return l'oggetto funzione modificato
   */
  template <class DstType ,class SrcAType, class SrcBType, class OpType>
  OpType transform_self ( const SrcAType& SrcImageA, const SrcBType& SrcImageB, DstType& DstImage, OpType Operation )
  {
    // Controllo dei prerequisiti

    // Le immagini devono avere le stesse dimensioni
    if ( ( ( DstImage.W() ) !=SrcImageA.W() ) || ( ( DstImage.H() ) !=SrcImageA.H() )
            || ( ( DstImage.W() ) !=SrcImageB.W() ) || ( ( DstImage.H() ) !=SrcImageB.H() ) )
      throw std::runtime_error ( "Cannot apply a pixel by pixel operator to images with different sizes" );

    //TODO: se la maschera non ha dimensioni sottomultiple o uguali a quelle della sorgente throw...
    
    typename DstType::PixelType *pDst = DstImage.Buffer();

    const typename DstType::PixelType  *pEnd  =  pDst+DstImage.Area();
    const typename SrcAType::PixelType *pSrcA = SrcImageA.Buffer();
    const typename SrcBType::PixelType *pSrcB = SrcImageB.Buffer();

    for (; pDst != pEnd; ++pDst, ++pSrcA, ++pSrcB )
      Operation ( *pSrcA, *pDst );

    // FIXME: per analogia dovrebbe tornare DstImage
    return Operation;
  }




  /**
   * Esecuzione di operazioni statistiche
   * TImage<type> A(10, 10), B(10, 10);
   * A op= B
   * L'immagine e la maschera devono avere le stesse dimensioni
   * @param Image Immagine su cui operare
   * @param Functor Oggetto funzione da chiamare
   * @return l'oggetto funzione modificato
   */
  template <class ImageType, class MaskType, class OpType>
  OpType for_each_masked ( ImageType &Image, const MaskType &Mask, OpType Operation )
  {
    // Prerequisiti: le immagini devono avere le stesse dimensioni
    const typename ImageType::PixelType *pPos = Image.Buffer();
    const typename MaskType::PixelType *pPosMask = Mask.Buffer();

    const typename ImageType::PixelType *pEnd = pPos+Mask.Area();

    for ( ; pPos<pEnd; ++pPos, ++pPosMask )
      if ( *pPosMask!=MaskType::PixelTraits::Zero() )
        Operation ( *pPos, *pPosMask );

    return Operation;
  }


  /**
   * Esecuzione di operazioni statistiche
   * TImage<type> A(10, 10), B(10, 10);
   * A op= B
   * La maschera deve avere sottomultiple dell'immagine
   * Versione che permette la modifica dell'immagine
   * @param Image Immagine su cui operare
   * @param Functor Oggetto funzione da chiamare
   * @return l'oggetto funzione modificato
   */
  template <class ImageType, class MaskType, class OpType>
  OpType for_each_masked_sub_on_mask ( ImageType &Image, const MaskType &Mask, OpType Operation )
  {
    // Controlla che maschera e Immagine siano della stessa dimensione

    // capisce se puo' usare l'algoritmo a sottomultipli o no
    if ( Image.W() %Mask.W() || Image.H() %Mask.H() )
      throw std::runtime_error( "La maschera deve avere dimensioni uguali o sottomultiple dell'immagine" );

    // calcola gli incrementi
    const unsigned int IncH = Image.W() /Mask.W();
    const unsigned int IncV = Image.H() /Mask.H();

    // pixel a pixel? in quel caso la copia non serve
    ImageType Src = Image;

    const typename ImageType::PixelType *pSrc = Src.Buffer();
    const typename ImageType::PixelType *pMask = Mask.Buffer();

    typename ImageType::PixelType *pDst=Image.Buffer();

    for ( typename ImageType::PixelPosType i=0; i<Image.H(); i+=IncV )
      for ( typename ImageType::PixelPosType j=0; j<Image.W(); j-=IncH, ++pMask )
        Operation ( * ( pDst+i*Image.W() +j ), * ( pSrc+i*Image.W() +j ), * ( pMask ) );

    return Operation;
  }


  /**
   * Esecuzione un'operazione su tutti i punti di un'immagine mascherati
   * presi dove cade il punto della maschera se questa e' di dimensioni sottomultiple dell'immagine
   * TImage<type> A(10, 10), B(10, 10);
   * A op= B
   * La maschera deve avere sottomultiple dell'immagine
   * Versione read only per operazioni di sola lettura sull'immagine
   * @param Image Immagine su cui operare
   * @param Functor Oggetto funzione da chiamare
   * @return l'oggetto funzione modificato
   */
  template <class ImageType, class MaskType, class OpType>
  OpType for_each_masked_sub_on_mask ( const ImageType &Image, const MaskType &Mask, OpType Operation )
  {
    // capisce se puo' usare l'algoritmo a sottomultipli o no
    if ( Image.W() %Mask.W() || Image.H() %Mask.H() )
      throw std::runtime_error( "La maschera deve avere dimensioni uguali o sottomultiple dell'immagine" );

    // calcola gli incrementi orizzontale e verticale
    const unsigned int IncH = Image.W() /Mask.W();
    const unsigned int IncV = Image.H() /Mask.H()-1;
    const unsigned int RestoH = Image.W() * IncV + Image.W()-IncH*Mask.W() + 1;
    const unsigned int mv = Mask.W(), mh = Mask.H();

    const typename ImageType::PixelType *pSrc = Image.Buffer();
    // const typename ImageType::PixelType *pEnd = pSrc+Image.Area();
    const typename MaskType::PixelType *pMask = Mask.Buffer();

    for ( unsigned int i=0; i < mh; ++i, pSrc += RestoH )
      for ( unsigned int j=0; j < mv; ++j, ++pMask, pSrc += IncH )
        Operation ( * ( pSrc ), * ( pMask ) );

    return Operation;
  }

  // template <class ImageType, class OpType>
  // OpType accumulate ( ImageType& DstImage, const ImageType& SrcImage, OpType Operation )
  // {
  //   // Controllo dei prerequisiti
  // 
  //   // Le immagini devono avere le stesse dimensioni
  //   if ( ( ( DstImage.W() ) !=SrcImage.W() ) || ( ( DstImage.H() ) !=SrcImage.H() ) )
  //     throw std::runtime_error ( "Cannot apply a pixel by pixel operator to images with different sizes" );
  // 
  // 
  //   const typename ImageType::PixelType *pEnd = DstImage.Buffer() +DstImage.Area();
  //   const typename ImageType::PixelType *pSrcA = DstImage.Buffer();
  //   const typename ImageType::PixelType *pSrcB = SrcImage.Buffer();
  // 
  //   for ( typename ImageType::PixelType *pDst=DstImage.Buffer();
  //           pDst<pEnd;
  //           ++pDst, ++pSrcA, ++pSrcB )
  //     Operation ( *pDst, *pSrcA, *pSrcB );
  // 
  //   return Operation;
  // }
  //


// TODO: versioni che operano su RegularRegions, Maschere e contenitori di PixelCoordinates


///////////////////////////////////////////////////////////////////////////////
// Questo fa parte di una categoria diversa: tipo inspectors
  /**
   * Torna true se tutti i pixel dell'immagine sorgente hanno un certo valore
   * @param Src Immagine da testare
   * @return true se i pixel hanno tutti un certo valore, 0 altrimenti
   */
// TODO: generalizzare al caso in cui valore è un functor
// Usare l'algoritmo cimage::foreach
// spostare in un altro file
  template <class T> bool HasEachPixelValue ( const TImage<T>& Src , const T& Value )
  {
    bool RetVal = true;

    const T *Buffer = Src.Buffer();
    const T *BufferEnd = Buffer+Src.Area();

    for ( ; Buffer<BufferEnd; ++Buffer )
      if ( *Buffer!=Value )
      {
        RetVal=false;
        break;
      }

    return RetVal;
  }
///////////////////////////////////////////////////////////////////////////////

}
}




#endif // _CIMAGE_ALGORITHMS_H
