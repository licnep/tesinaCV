#ifndef _SIMPLE_FILTERS_H
#define _SIMPLE_FILTERS_H

/** @file SimpleFilters
  * @brief Alcuni semplici filtri
  **/

#include "TLocalFilter.h"
#include "FilterModifier.h"

namespace cimage {

namespace kernel {
  /// Filtro che binarizza l'immagine con una soglia
  typedef filter::Bin< filter::Source> Binarize;
  /// Filtro che sostituisce gli elementi 255 dell'immagine con 254
  typedef filter::TReplace<255, 254, filter::Source> Reserve255;
};
  
namespace filter {
  
/** Un filtro che genera una immagine binaria sogliando l'immagine in ingresso
* \code
* filter::Binarize filter;
* filter.SetThreshold(127);
* filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef TLocalFilter< kernel::Binarize > Binarize;

/** Un filtro che sostituisce il tono di grigio 255 con 254 per lasciare il 255 come valore Non Definito.
* \code
* filter::Reserve255(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef TLocalFilter< kernel::Reserve255 > Reserve255;

} // namespace filter

} // namespace cimage



#endif
