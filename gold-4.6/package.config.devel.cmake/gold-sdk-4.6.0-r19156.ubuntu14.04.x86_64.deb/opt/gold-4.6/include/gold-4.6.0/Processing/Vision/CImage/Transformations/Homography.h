/** @file Homography.c
  * @brief funzioni per trasformazioni omografiche su CImage
  * @author Paolo Medici
  **/
#ifndef _HOMOGRAPHIC_TRANSFORMATION_APPLIER_H
#define _HOMOGRAPHIC_TRANSFORMATION_APPLIER_H

#include <Data/CImage/CImage.h>
#include <Data/Math/TMatrices.h>
#include <Processing/Vision/CImage/Transformations/Interpolate.h>


namespace transformation {

/** Applica una trasformazione omografica basata su matrice al buffer
 * @note usare i float. i double avrebbero un decadimento sensibile delle prestazioni senza
 *       alcun aumento di precisione. usare altrimenti i fixed_point
 *
 * \code
 * transformation::Homography<float, BilinearInterpolate> htr(matrix);
 * // ...
 * htr(dest, source, dest_width, dest_height, source_width, source_width);
 * \endcode
 *
 * Applica una trasformazione omografica basata su matrice alle CImage
 * @note usare i float. i double avrebbero un decadimento sensibile delle prestazioni senza
 *       alcun aumento di precisione. usare altrimenti i fixed_point.
 *
 * \code
 *  transformation::Homography<float,NearestInterpolate> filter;
 * \endcode
 * \code
 *  transformation::Homography<float> filter(ht::CameraWarp(src,dst).get());
 * \endcode
 *
 * @note 
 *  Su immagini 640x300 BW su Pentium4HT 3.2Ghz 
 *   BilinearInterpolate impiega circa 19 msec,
 *   NearestInterpolate impiega circa 10 msec.
 *  Su immagini 640x480 RGB su Pentium4HT 3.2Ghz 
 *   BilinearInterpolate impiega circa 39 msec,
 *   NearestInterpolate impiega circa 23 msec.
 **/

template<typename R, class X>
class Homography: public math::TMatrix<R,3,3>, public X
{
    public:
    typedef math::TMatrix<R,3,3> matrix_t;
    public:
    Homography()  {}
    Homography(const matrix_t & m) : matrix_t(m) { }
    template<class S>
    explicit Homography(const S * s) : matrix_t(s) { }

template<class T>
void operator()(T *dest,
                const T *source,
                unsigned int out_width,
                unsigned int out_height,
                unsigned int in_width,
                unsigned int in_height) const
{
    const R *matrix = this->get();

    R x0,y0,w0;
    /* codice originale (non ottimizzato)
        jx = m[0] * u0 + m[1] * v0 + m[2];
        jy = m[3] * u0 + m[4] * v0 + m[5];
        jw = m[6] * u0 + m[7] * v0 + m[8];    
    */
    x0 = matrix[2];
    y0 = matrix[5];
    w0 = matrix[8];
    for(unsigned int j=0;j<out_height;j++)
    {
        R x,y,w;
        x = x0;
        y = y0;
        w = w0;
        for(unsigned int i=0;i<out_width;i++)
        {
            *dest = X::operator()(source, in_width, in_height, x/w, y/w);
            dest++;
            x+= matrix[0];
            y+= matrix[3];
            w+= matrix[6];
        }
        x0+=matrix[1];
        y0+=matrix[4];
        w0+=matrix[7];
    }
}

/**
* @brief Applica la trasformazione lineare tra le due immagini
* @param input  Immagine di input
* @param output Immagine di output
*/
template<class T>
void operator() (const cimage::TImage<T>& input, cimage::TImage<T>& output) const
    {
    this->operator() (output.Buffer(), input.Buffer(),
		output.W(),output.H(),
		input.W(),input.H() );
    }

};

} // namespace transformation


#endif
