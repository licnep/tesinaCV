/** @file TImageInterpolate.h
  * @brief Funzioni di interpolazione basate su PixelTraits
  * @author Paolo Medici
  **/
#ifndef _TIMAGE_INTERPOLATE_H
#define _TIMAGE_INTERPOLATE_H

#include <boost/math/tr1.hpp>

#include <Data/CImage/PixelTraits/PixelTraits.h>


/** Classe per interpolazione bilineare 
 **/
struct BilinearInterpolate {
/** Data un immagine @a src grande @a width e @a height 
 *  ritorna il punto interpolato @a x,y
 **/
template<class T, class R>
T operator()(const T *src, unsigned int width, unsigned int height, R x, R y) const
{
  R dx,dy;
  int i,j;
  
  i = (int) floor(x);
  j = (int) floor(y);
  dx = x - floor(x);
  dy = y - floor(y);
  
  if((i>=0)&&(j>=0)&&(i<(int)width)&&(j<(int)height))
    {
    // avoid overflow
    if(i+1==(int)width)
      {
      i--;
      dx=R(1);
      }
    // avoid overflow
    if(j+1==(int)height)
      {
      j--;
      dy=R(1);
      }
    src += i + j * width;

    return cimage::PixelTraits<T>::BilinearInterpolate(src, width, dx,dy);
    }
    else
     return T(255);
}
};

/** Classe che ritorna il punto piu vicino
 **/
struct NearestInterpolate {
/** Data un immagine @a src grande @a width e @a height 
 *  ritorna il punto piu vicino a @a x,y
 **/
template<class T, class R>
T operator()(const T *src, unsigned int width, unsigned int height, R x, R y) const
  {
  int i,j;
  
  i = (int) boost::math::tr1::round(x);// boost::math::tr1::round(x);
  j = (int) boost::math::tr1::round(y);// boost::math::tr1::round(y);

  return   
  ((i>=0)&&(j>=0)&&(i<(int)width)&&(j<(int)height))
    ? src[i + j * width] : T(255);
 }
};

#endif
