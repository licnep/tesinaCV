#ifndef _BASE_FILTER_H
#define _BASE_FILTER_H

/** @file 
 * @brief base classes for declare a filter */

namespace cimage{
  namespace filter {
    
    /// category of filer
    enum FilterType {
      PixelFilter,	///< a local filter, @see ImplPixelOperator
      LineFilter,	///< a line filter, @see ImplLineOperator
      AreaFilter	///< an area filter, @see ImplAreaOperator
    };
    
    /** a filter that implement a pixel operator:
     * \code
     * output operator()(const input *src, long src_stride) const;
     * \endcode
     * */
    struct ImplPixelOperator {
      
      static const FilterType type = PixelFilter;
      
    };

    /** a filter that implement a line operator:
     * \code
     * void operator()(output *dst, const input *src, unsigned int w, long src_stride) const;
     * \endcode
     * */
    struct ImplLineOperator {
      
      static const FilterType type = LineFilter;
      
    };

    /** a filter that implement an area operator:
     * \code
     * void operator()(output *dst, const input *src, unsigned int w, unsigned int h, long src_stride, long dst_stride) const;
     * \endcode
     * */
    struct ImplAreaOperator {
      
      static const FilterType type = AreaFilter;
      
    };
    
  }
}

#endif