#ifndef _CIMAGE_BASIC_OPERATIONS_REGISTRATION_H
#define _CIMAGE_BASIC_OPERATIONS_REGISTRATION_H

#include <map>

#include <Libs/Patterns/Singleton.h>

#include <Processing/Vision/CImage/gold_proc_cimage_export.h>

#include <Data/CImage/CImage.h>
// Procedura per aggiungere una operazione
// BasicOperations_Registration.h:
// 1. Aggiungere la mappa con il prototipo opportuno in cimage::impl::FunctionMatrix
// 2. Aggiungere la registrazione delle funzione sulle CImage in FunctionMatrix::Register
// 3. Aggiungere la macro di dichiarazione delle funzioni sulle TImage
// BasicOperations.h:
// 5. Aggiungere il prototipo dell'operazione sulle TImage e CImage
// BasicOperations.hxx:
// 6. Aggiungere il codice dell'operazione su TImage
// BasicOperations_MySpecializedImage.h:
// 6. Aggiungere il codice dell'operazione specializzato per una TImage specifica
// BasicOperations.cpp:
// 7. Aggiungere il codice dell'operazione su CImage (lookup nella mapppa e chiamata)


namespace cimage
{
  namespace impl
  {
    class GOLD_PROC_CIMAGE_EXPORT BasicOps_FnMtx
    {
        template<typename PB,typename PC>
        GOLD_PROC_CIMAGE_EXPORT void __reg ( std::map<CImage::Type, PB >& map, CImage::Type img_type, PC f )
        {
          // std::cout << "registering" << "???"
          // << img_type.name() << "@" << ( void* ) f
          //<< " " << typeid ( f ).name() <<  __FILE__<< __LINE__ << std::endl;
          map.insert ( std::make_pair ( img_type, reinterpret_cast<PB> ( f ) ) );
        }

      public:
        std::map<CImage::Type, void ( * ) ( CImage&, int ) >  map_Fill;
        std::map<CImage::Type, void ( * ) ( const CImage& src, CImage& dst) > map_Copy;
        std::map<CImage::Type, void ( * ) ( const void *, CImage& ) > map_Copy_from;
        std::map<CImage::Type, void ( * ) ( const CImage& src, void * ) > map_Copy_to;
        std::map<CImage::Type, void ( * ) ( CImage&, SizeType, SizeType ) > map_Resize;
        std::map<CImage::Type, void ( * ) ( const CImage&, CImage&, const CImageFlag& ) > map_Resample;
        std::map<CImage::Type, void ( * ) ( const CImage&, double, CImage& ) > map_LinComb;
        std::map<CImage::Type, void ( * ) ( const CImage& src, CImage& dst, PosType Left, PosType Top, PosType Right, PosType Bottom, bool KeepSize ) > map_Crop;
        std::map<CImage::Type, void ( * ) ( const CImage& , CImage&, double, ANGLE_UNIT ) > map_Rotate;
        std::map<CImage::Type, void ( * ) ( const CImage& , CImage&, double, double, double, ANGLE_UNIT ) > map_RotateC;
        std::map<CImage::Type, void ( * ) ( const CImage& src, CImage& dst) > map_DeInterlace_OddField;
        std::map<CImage::Type, bool ( * ) ( const CImage& src ) >  map_IsEmpty;
        // Add other maps here
        
        template<typename T>
        bool Register ()
        {
          __reg ( map_Fill,  T::type_info(), Fill<typename T::PixelType> );

          void ( *pCopy ) ( const T&, T& );
          pCopy = Copy<typename T::PixelType>;
          __reg ( map_Copy,  T::type_info(), pCopy );

          void ( *pCopy_from ) ( const void *, T& );
          pCopy_from = Copy<typename T::PixelType>;
          __reg ( map_Copy_from, T::type_info(), pCopy_from );

          void ( *pCopy_to ) ( const T&, void * );
          pCopy_to = Copy<typename T::PixelType>;
          __reg ( map_Copy_to,  T::type_info(), pCopy_to );

          __reg ( map_Resize,   T::type_info(), Resize<typename T::PixelType>  );
          __reg ( map_Resample, T::type_info(), Resample<typename T::PixelType>  );
          __reg ( map_LinComb,  T::type_info(), LinComb<typename T::PixelType> );
          __reg ( map_Crop,     T::type_info(), Crop<typename T::PixelType> );
          
          __reg ( map_Rotate,   T::type_info(), Rotate<typename T::PixelType> );
          __reg ( map_RotateC,  T::type_info(), RotateC<typename T::PixelType> );
          
          __reg ( map_DeInterlace_OddField, T::type_info(), DeInterlace_OddField<typename T::PixelType> );
          __reg ( map_IsEmpty,  T::type_info(), IsEmpty<typename T::PixelType> );
          // Add other functions here
          
          return true;
        }        
    };
    
    // Declaration macro. Aggiunge le dichiarazioni delle operazioni su una TImage
#define CIMAGE__DECLARE_BASIC_OPERATIONS(I)\
         template GOLD_PROC_CIMAGE_EXPORT void Copy<I::PixelType> ( const I&, I& );\
         template GOLD_PROC_CIMAGE_EXPORT void Copy<I::PixelType > ( const void*, I& ); \
         template GOLD_PROC_CIMAGE_EXPORT void Copy<I::PixelType > ( const I&, void* ); \
         template GOLD_PROC_CIMAGE_EXPORT void Fill<I::PixelType > ( I&, I::PixelType ); \
         template GOLD_PROC_CIMAGE_EXPORT void Resize<I::PixelType > ( I&, cimage::SizeType, cimage::SizeType ); \
         template GOLD_PROC_CIMAGE_EXPORT void Resample<I::PixelType > ( const I&, I&, const CImageFlag& ); \
         template GOLD_PROC_CIMAGE_EXPORT void Rotate<I::PixelType > ( const I&, I&, double, ANGLE_UNIT ); \
         template GOLD_PROC_CIMAGE_EXPORT void RotateC<I::PixelType > ( const I&, I&, double, double, double, ANGLE_UNIT ); \
         template GOLD_PROC_CIMAGE_EXPORT void LinComb<I::PixelType > ( const I&, double, I& ); \
         template GOLD_PROC_CIMAGE_EXPORT void Crop<I::PixelType > ( const I&, I&, cimage::PosType, cimage::PosType, cimage::PosType, cimage::PosType, bool ); \
         template GOLD_PROC_CIMAGE_EXPORT bool IsEmpty<I::PixelType > ( const I& );

    // Registration macro registra le operazioni specifiche nella matrice delle operazioni su CImage
#define CIMAGE__REGISTER_BASIC_OPERATIONS(I)\
      static bool __fun_reg_##I=vl::Singleton<BasicOps_FnMtx>::Instance().Register<I>();
      
  }
}

#endif
