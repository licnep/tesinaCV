#ifndef _LINEAR_TRANSFORMATION_H
#define _LINEAR_TRANSFORMATION_H

/** @file Transformation.h
  * @brief this file handle linear and affine space transformation
  * @note homographic transformation (between homogeneous coordinates) can be found in homographic.h
  **/

#include <cmath>

#include <Processing/Math/gold_proc_math_export.h>
#include <Data/Math/Lines.h>
#include <Data/Math/Points.h>
#include <Data/Math/Rects.h>
#include <Data/Math/TMatrices.h>


// TODO: usare un namespace?
namespace  math
{

/* Isometries are transformations that preserve distances */

/*** some typedes **/

/** Bidimensional Affine Transformation (linear transformation plus a translation)
  *  (x' y') = M (x y 1)
  **/
typedef math::TMatrix<double,2,3>  AffineTransformation2d;

/** Tridimensional Affine Transformation (linear transformation plus a translation)
  *  (x' y' z') = M (x y z 1)
  **/
typedef math::TMatrix<double,3,4>  AffineTransformation3d;

/** Linear Transformation
  * (x' y') = M (x y)
  **/
typedef math::TMatrix<double,2,2>  LinearTransformation2d;

/** Linear Transformation
  *  (x' y' z') = M (x y z)
  **/
typedef math::TMatrix<double,3,3>  LinearTransformation3d;

/*** transformations **/

/************* Funzioni per applicare trasformazioni affini a punti *********************/
/*** NOTA: mancano delle funzioni opearatore per semplificare l'applicazione delle trasformazioni ad array/vettori di punti **/

/** Applica una Trasformazione Affine a un punto nello spazio 2D
  *   (x' y') = M (x y 1)
  * \code
  * TMatrix<double,2,3> M;
  * Point2d out = Apply(M, Point2d( x , y) );
  * \endcode
  * @note la trasformazione lineare e' gestita nativamente dalla moltiplicazione tra matrice 2x2 e Point2
  **/
template<class T>
inline math::Point2<T> Apply(const math::TMatrix<T,2,3> & M, const math::Point2<T> & in)
{
    return math::Point2<T>(
               M[0] * in.x + M[1] * in.y + M[2],
               M[3] * in.x + M[4] * in.y + M[5]
           );
}

/** Applica una Trasformazione Affine a un punto nello spazio 3D
  *  (x' y' z') = M (x y z 1)
  * \code
  * TMatrix<double,3,4> M;
  * Point3d out = Apply(M, Point3d(x , y) );
  * \endcode
  * @note la trasformazione lineare e' gestita nativamente dalla moltiplicazione tra matrice 3x3 e Point3
  **/
template<class T>
inline math::Point3<T> Apply(const math::TMatrix<T,3,4> & M, const math::Point3<T> & in)
{
    return math::Point3<T>(
               M[0] * in.x + M[1] * in.y + M[2]  * in.z + M[3],
               M[4] * in.x + M[5] * in.y + M[6]  * in.z + M[7],
               M[8] * in.x + M[9] * in.y + M[10] * in.z + M[11]
           );
}

/** Applica una Trasformazione Affine INVERSA a una retta
  *   @note E' una trasformazione inversa rispetto ai punti perche' per motivi di sintassi le rette vengono trasformate facilmente dalla trasformazione inversa dei punti
  **/
template<class T>
inline math::Line3<T> Apply(const math::TMatrix<T,2,3> & M, const math::Line3<T> & l)
{
    math::Line3<T> o;
    o.a = l.a * M[0] + l.b * M[3];
    o.b = l.a * M[1] + l.b * M[4];
    o.c = l.a * M[2] + l.b * M[5] + l.c;
    return o;
}

/************* Funzioni per comporre trasformazioni lineari e affini *********************/

/** Compone due trasformazioni affini
  *
  *  (x" y") = A   (x' y' 1); <br>
  *  (x' y') = B   (x  y  1); <br>
  *  (x" y") = A*B (x  y  1);
  **/
template<class T>
math::TMatrix<T,2,3> Compose(const math::TMatrix<T,2,3> & A, const math::TMatrix<T,2,3> &B)
{
    math::TMatrix<T,2,3> C;
    C[0] = A[0]*B[0]+A[1]*B[3];
    C[1] = A[0]*B[1]+A[1]*B[4];
    C[2] = A[0]*B[2]+A[1]*B[5]+A[2];
    C[3] = A[3]*B[0]+A[4]*B[3];
    C[4] = A[3]*B[1]+A[4]*B[4];
    C[5] = A[3]*B[2]+A[4]*B[5]+A[5];
    return C;
}

/** Compone due trasformazioni affini
  *
  *  (x" y" z") = A   (x' y' z' 1); <br>
  *  (x' y' z') = B   (x  y  z  1); <br>
  *  (x" y" z") = A*B (x  y  z  1);
  **/
template<class T>
GOLD_PROC_MATH_EXPORT math::TMatrix<T,3,4> Compose(const math::TMatrix<T,3,4> & A, const math::TMatrix<T,3,4> &B);

/// Compone una trasformazioni affine con una lineare
template<class T>
math::TMatrix<T,2,3> Compose(const math::TMatrix<T,2,3> & A, const math::TMatrix<T,2,2> &B)
{
    math::TMatrix<T,2,3> C;
    C[0] = A[0]*B[0]+A[1]*B[2];
    C[1] = A[0]*B[1]+A[1]*B[3];
    C[2] = A[2];
    C[3] = A[3]*B[0]+A[4]*B[2];
    C[4] = A[3]*B[1]+A[4]*B[3];
    C[5] = A[5];
    return C;
}

/// Compone una trasformazione lineare con una affine
template<class T>
math::TMatrix<T,2,3> Compose(const math::TMatrix<T,2,2> & A, const math::TMatrix<T,2,3> &B)
{
    math::TMatrix<T,2,3> C;
    C[0] = A[0]*B[0]+A[1]*B[3];
    C[1] = A[0]*B[1]+A[1]*B[4];
    C[2] = A[0]*B[2]+A[1]*B[5];
    C[3] = A[2]*B[0]+A[3]*B[3];
    C[4] = A[2]*B[1]+A[3]*B[4];
    C[5] = A[2]*B[2]+A[3]*B[5];
    return C;
}

/// Compone due trasformazioni affini
/// @return the transformation a*b
template<class T>
GOLD_PROC_MATH_EXPORT math::TMatrix<T,3,4> Compose(const math::TMatrix<T,3,4> & a, const math::TMatrix<T,3,3> &b);

/// Compone una trasformazione lineare con una affine
/// @return the transformation a*b
template<class T>
GOLD_PROC_MATH_EXPORT math::TMatrix<T,3,4> Compose(const math::TMatrix<T,3,3> & a, const math::TMatrix<T,3,4> &b);

/************* Funzioni per generare trasformazioni lineari e affini notevoli *********************/

/** Imposta una trasformazione Affine all'identita'
  *  (x y) = A (x y 1);
  **/
template<class T>
inline void Identity(math::TMatrix<T,2,3> & M)
{
    M[0]=T(1);
    M[1]=T(0);
    M[2]=T(0);
    M[3]=T(0);
    M[4]=T(1);
    M[5]=T(0);
}

/** Imposta una trasformazione Affine all'identita'
  *  (x y z) = A (x y z 1);
  **/
template<class T>
inline void Identity(math::TMatrix<T,3,4> & M)
{
    M[0]=T(1);
    M[1]=T(0);
    M[2] =T(0);
    M[3] =T(0);
    M[4]=T(0);
    M[5]=T(1);
    M[6] =T(0);
    M[7] =T(0);
    M[8]=T(0);
    M[9]=T(0);
    M[10]=T(1);
    M[11]=T(0);
}

/** Invert an Affine Transformation 2D
  *  (x' y') = A    (x  y  1); <br>
  *  (x  y ) = A^-1 (x' y' 1);
  **/
template<class T>
GOLD_PROC_MATH_EXPORT math::TMatrix<T,2,3> Invert(const math::TMatrix<T,2,3> & M);

/** Invert an Affine Transformation 3D
  *  (x' y' z') = A    (x  y  z  1); <br>
  *  (x  y  z ) = A^-1 (x' y' z' 1);
  **/
template<class T>
GOLD_PROC_MATH_EXPORT math::TMatrix<T,3,4> Invert(const math::TMatrix<T,3,4> & M);

/** crea una matrice di rotazione 2D
  * Rotates vectors in the plane by an angle of @a angle. The x axis is rotated towards the y axis.
  *  The rotation is counterclockwise
  * @note remember that inverse of rotation matrix is its transpose
  **/
template<class T >
math::TMatrix<T,2,2> Rotation(T angle)
{
    math::TMatrix<T,2,2> M;
    M[0]= std::cos(angle);
    M[1]=-std::sin(angle);
    M[2]= std::sin(angle);
    M[3]= std::cos(angle);
    return M;
}

/** crea una matrice di trasformazione affine intorno al punto @a p.
  * The @a p point is the only point not rotated
  * Rotates vectors in the plane by an angle of @a angle . The x axis is rotated towards the y axis.
  *  The rotation is counterclockwise
  **/
template<class T >
math::TMatrix<T,3,2> Rotation(const math::Point2<T> & p, T angle)
{
    math::TMatrix<T,3,2> m;
    T s = std::sin(angle);
    T c = std::cos(angle);
    m[0] =   c;
    m[1] =-s;
    m[2] = p.x - p.x * c + p.y * s;
    m[3] =   s;
    m[4] = c;
    m[5] = p.y - p.x * s - p.y * c;
    return m;
}

/** crea una matrice di rotazione intorno all'asse X (Goldstein 1980)
  * The direction of the rotation is as follows: Rx rotates the y-axis towards the z-axis
  * this is the matrix able to rotate a vector, or convert a sensor coordinate in world coordinate
  * @note remember that inverse of rotation matrix is its transpose
  **/
template<class T >
math::TMatrix<T,3,3> RotationX(T roll)
{
    math::TMatrix<T,3,3> M;
    M[0]=T(1);
    M[1]=T(0);
    M[2]=T(0);
    M[3]=T(0);
    M[4]= std::cos(roll);
    M[5]=-std::sin(roll);
    M[6]=T(0);
    M[7]= std::sin(roll);
    M[8]= std::cos(roll);
}

/** crea una matrice di rotazione intorno all'asse Y (Goldstein 1980)
  *  Ry rotates the z-axis towards the x-axis,
  * this is the matrix able to rotate a vector, or convert a sensor coordinate in world coordinate
  * @note remember that inverse of rotation matrix is its transpose
  **/
template<class T >
math::TMatrix<T,3,3> RotationY(T pitch)
{
    math::TMatrix<T,3,3> M;
    M[0]= std::cos(pitch);
    M[1]=T(0);
    M[2]= std::sin(pitch);
    M[3]= T(0);
    M[4]=T(1);
    M[5]= T(0);
    M[6]=-std::sin(pitch);
    M[7]=T(0);
    M[8]= std::cos(pitch);
    return M;
}

/** crea una matrice di rotazione intorno all'asse Z (Goldstein 1980)
  *   Rz rotates the x-axis towards the y-axis.
  * this is the matrix able to rotate a vector, or convert a sensor coordinate in world coordinate
  * @note remember that inverse of rotation matrix is its transpose
  **/
template<class T >
math::TMatrix<T,3,3> RotationZ(T yaw)
{
    math::TMatrix<T,3,3> M;
    M[0]= std::cos(yaw);
    M[1]=-std::sin(yaw);
    M[2]=T(0);
    M[3]= std::sin(yaw);
    M[4]= std::cos(yaw);
    M[5]=T(0);
    M[6]= T(0);
    M[7]= T(0);
    M[8]=T(1);
    return M;
}

/** crea una matrice di rotazione 3D (Z*Y*X)
  * this is the matrix able to rotate a vector, or convert a sensor coordinate in world coordinate
  * @note remember that inverse of rotation matrix is its transpose
  **/
template<class T>
math::TMatrix<T,3,3> Rotation(T yaw, T pitch, T roll)
{
    math::TMatrix<T,3,3> M;

// usare la forma esplicita per aumentare la precisione e ridurre il peso computazionale:
// return RotationZ(roll) * RotationY(pitch) * RotationX(yaw);
    M[0]= std::cos(pitch)*std::cos(yaw);
    M[1]= std::sin(roll)*std::sin(pitch)*std::cos(yaw)-std::cos(roll)*std::sin(yaw);
    M[2]= std::cos(roll)*std::sin(pitch)*std::cos(yaw)+std::sin(roll)*std::sin(yaw);

    M[3]= std::cos(pitch)*std::sin(yaw);
    M[4]= std::sin(roll)*std::sin(pitch)*std::sin(yaw)+std::cos(roll)*std::cos(yaw);
    M[5]= std::cos(roll)*std::sin(pitch)*std::sin(yaw)-std::sin(roll)*std::cos(yaw);

    M[6]=-std::sin(pitch);
    M[7]= std::sin(roll)*std::cos(pitch);
    M[8]= std::cos(roll)*std::cos(pitch);
    return M;
}

/** crea una matrice di rotazione inversa 3D (trasformazione che rimuove la rotazione applicata)
  * X^{-1} * Y^{-1} * Z^{-1}
  * this is the matrix able to rotate the reference frame, or convert a world coordinate in sensor coordinate
  * @note remember that inverse of rotation matrix is its transpose
  **/
template<class T>
math::TMatrix<T,3,3> InverseRotation(T yaw, T pitch, T roll)
{
    math::TMatrix<T,3,3> M;

    M[0]= std::cos(pitch)*std::cos(yaw);
    M[1]= std::cos(pitch)*std::sin(yaw);
    M[2]=-std::sin(pitch);

    M[3]= std::sin(roll)*std::sin(pitch)*std::cos(yaw)-std::cos(roll)*std::sin(yaw);
    M[4]= std::sin(roll)*std::sin(pitch)*std::sin(yaw)+std::cos(roll)*std::cos(yaw);
    M[5]= std::sin(roll)*std::cos(pitch);

    M[6]= std::cos(roll)*std::sin(pitch)*std::cos(yaw)+std::sin(roll)*std::sin(yaw);
    M[7]= std::cos(roll)*std::sin(pitch)*std::sin(yaw)-std::sin(roll)*std::cos(yaw);
    M[8]= std::cos(roll)*std::cos(pitch);

    return M;
}

/** Rotazione intorno a un asse dato
  * @param u is a unit vector
  * @return the matrix for a rotation by an angle of @a angle about an axis the direction of @a u
  * @note remember that inverse of rotation matrix is its transpose
  **/
template<class T>
GOLD_PROC_MATH_EXPORT math::TMatrix<T,3,3> AxisRotation(const math::Point3<T> & u, T angle);

/** crea una matrice di Scala 2D
  * x' = sx * x; y' = sy * y;
  * @note ovviamente prima di usare una trasformazione affine per eseguire una scala pensarci bene se
  *       e' strettamente necessario (generalizzazioni, composizioni).  La classe Point ha anche l'operatore * scalare
  **/
template<class T>
math::TMatrix<T,2,2> Scale(T sx, T sy)
{
    math::TMatrix<T,2,2> M;
    M[0]=sx;
    M[1]=T(0);
    M[2]=T(0);
    M[3]=sy;
    return M;
}

/** crea una matrice di Scala 3D
  * x' = sx * x; y' = sy * y; z' = sz * z;
  * @note ovviamente prima di usare una trasformazione affine per eseguire una scala pensarci bene se
  *       e' strettamente necessario (generalizzazioni, composizioni). La classe Point ha anche l'operatore * scalare
  **/
template<class T>
math::TMatrix<T,3,3> Scale(T sx, T sy, T sz)
{
    math::TMatrix<T,3,3> M;
    M[0]=sx;
    M[1]=T(0);
    M[2]=T(0);
    M[3]=T(0);
    M[4]=sy;
    M[5]=T(0);
    M[6]=T(0);
    M[7]=T(0);
    M[8]=sz;
    return M;
}

/** crea una trasformazione affine di traslazione 2D
  * x' = x + dx; y' = y + dy;
  * @note ovviamente prima di usare una trasformazione affine per eseguire una traslazione pensarci bene se
  *       e' strettamente necessario (generalizzazioni, composizioni). La classe Point ha anche l'operatore +
  **/
template<class T>
inline math::TMatrix<T,2,3> Translate(T dx, T dy)
{
    math::TMatrix<T,2,3> M;
    M[0]=T(1);
    M[1]=T(0);
    M[2]=dx;
    M[3]=T(0);
    M[4]=T(1);
    M[5]=dy;
    return M;
}

/** crea una trasformazione affine di traslazione 2D
 * x' = x + p.x; y' = y + p.y;
 * @note ovviamente prima di usare una trasformazione affine per eseguire una traslazione pensarci bene se
 *       e' strettamente necessario (generalizzazioni, composizioni). La classe Point ha anche l'operatore +
 **/
template<class T>
inline math::TMatrix<T,2,3> Translate(const math::Point2<T> & p)
{
    math::TMatrix<T,2,3> M;
    M[0]=T(1);
    M[1]=T(0);
    M[2]=p.x;
    M[3]=T(0);
    M[4]=T(1);
    M[5]=p.y;
    return M;
}

/** @brief Compone una trasformazione affine con una traslazione in ingresso
  * Compose an affine transformation with an input traslation
  *
  *  (x" y") = A   (x' y' 1); <br>
  *  (x' y') = p + (x  y  1); <br>
  *  (x" y") = A*(p +  (x  y  1) ) = A*p + A * (x y 1);
  **/
template<class T>
math::TMatrix<T,2,3> Translate(const math::TMatrix<T,2,3> & A, const math::Point2<T> & p)
{
    math::TMatrix<T,2,3> C;
    C[0] = A[0];
    C[1] = A[1];
    C[2] = A[2] + A[0]*p.x + A[1] * p.y;
    C[3] = A[3];
    C[4] = A[4];
    C[5] = A[5] + A[3]*p.x + A[4] * p.y;
    return C;
}

/** @brief Compone una trasformazione affine con una traslazione in uscita
  *
  * This is the typical transformation when a coordinate is converted from sensor to world
  *  (x" y") = p + (x' y' 1); <br>
  *  (x' y') = B * (x  y  1); <br>
  *  (x" y") = p + B *(x  y  1);
  **/
template<class T>
math::TMatrix<T,2,3> Translate(const math::Point2<T> & p, const math::TMatrix<T,2,3> & B)
{
    math::TMatrix<T,2,3> C;
    C[0] = B[0];
    C[1] = B[1];
    C[2] = B[2] + p.x;
    C[3] = B[3];
    C[4] = B[4];
    C[5] = B[5] + p.y;
    return C;
}

/** @brief Compone una trasformazione con una traslazione in uscita
  * Compose an affine transformation with an output traslation.
  * This is the typical transformation when a coordinate is converted from sensor to world
  *  (x" y" z") = p + (x' y' z'); <br>
  *  (x' y' z') = B * (x  y  z); <br>
  *  (x" y" z") = p + B *(x  y  z);
  **/
template<class T>
math::TMatrix<T,3,4> Translate(const math::Point3<T> & p, const math::TMatrix<T,3,3> & B)
{
    math::TMatrix<T,3,4> C;
    C[ 0] = B[ 0];
    C[ 1] = B[ 1];
    C[ 2] = B[ 2];
    C[ 3] = p.x;
    C[ 4] = B[ 3];
    C[ 5] = B[ 4];
    C[ 6] = B[ 5];
    C[ 7] = p.y;
    C[ 8] = B[ 6];
    C[ 9] = B[ 7];
    C[10] = B[ 8];
    C[11] = p.z;
    return C;
}

/** @brief Compone una trasformazione affine con una traslazione in uscita
  * Compose an affine transformation with an output traslation.
  *
  *  (x" y" z") = p + (x' y' z'); <br>
  *  (x' y' z') = B * (x  y  z 1); <br>
  *  (x" y" z") = p + B *(x  y  z 1);
  **/
template<class T>
math::TMatrix<T,3,4> Translate(const math::Point3<T> & p, const math::TMatrix<T,3,4> & B)
{
    math::TMatrix<T,3,4> C;
    C[ 0] = B[ 0];
    C[ 1] = B[ 1];
    C[ 2] = B[ 2];
    C[ 3] = B[ 3] + p.x;
    C[ 4] = B[ 4];
    C[ 5] = B[ 5];
    C[ 6] = B[ 6];
    C[ 7] = B[ 7] + p.y;
    C[ 8] = B[ 8];
    C[ 9] = B[ 9];
    C[10] = B[10];
    C[11] = B[11] + p.z;
    return C;
}

/** crea una trasformazione affine di traslazione 3D
  * x' = x + dx; y' = y + dy; z' = z + dz;
  * @note ovviamente prima di usare una trasformazione affine per eseguire una traslazione pensarci bene se
  *       e' strettamente necessario (generalizzazioni, composizioni). La classe Point ha anche l'operatore +
  **/
template<class T>
inline math::TMatrix<T,3,4> Translate(T dx, T dy, T dz)
{
    math::TMatrix<T,3,4> M;
    M[0]=T(1);
    M[1]=T(0);
    M[2]=T(0);
    M[3] =dx;
    M[4]=T(0);
    M[5]=T(1);
    M[6]=T(0);
    M[7] =dy;
    M[8]=T(0);
    M[9]=T(0);
    M[10]=T(1);
    M[11]=dz;
    return M;
}

/** crea una trasformazione affine di traslazione 3D
  * x' = x + p.x; y' = y + p.y; z' = z + p.z;
  * @note ovviamente prima di usare una trasformazione affine per eseguire una traslazione pensarci bene se
  *       e' strettamente necessario (generalizzazioni, composizioni). La classe Point ha anche l'operatore +
  **/
template<class T>
inline math::TMatrix<T,3,4> Translate(const math::Point3<T> & p)
{
    math::TMatrix<T,3,4> M;
    M[0]=T(1);
    M[1]=T(0);
    M[2] =T(0);
    M[3] = p.x;
    M[4]=T(0);
    M[5]=T(1);
    M[6] =T(0);
    M[7] = p.y;
    M[8]=T(0);
    M[9]=T(0);
    M[10]=T(1);
    M[11]= p.z;
    return M;
}

/** Ritorna la trasformazione affine che trasforma punti di @a source in punti di @a dest
  * @note per ottenere la trasformazione inversa basta scambiare source e dest
  **/
template<class T>
inline math::TMatrix<T,2,3> Resample(const math::Rect2<T> & source, const math::Rect2<T> & dest)
{
    math::TMatrix<T,2,3> M;
    M[0] = dest.width() / source.width();
    M[1] = T(0);
    M[2] = - source.left() * M[0] + dest.left();
    M[3] = T(0);
    M[4] = dest.height() / source.height();
    M[5] = - source.top()  * M[4] + dest.top();
    return M;
}

} // namespace math

#endif
