#ifndef _IPM_PROBE_H
#define _IPM_PROBE_H

/** @file IpmProbe.h
  * @brief Widget per l'IPM
  * IPMProbeWidget per esempio.
  * @author Paolo Medici
  **/

#include <string>

#include <UI/CWindows/CWindowTypes.h>
#include <UI/CWindows/CWidget.h>
#include <Processing/Vision/PerspectiveMapping/ipm.h>
#include <Data/Math/Points.h>
#include <Data/Math/Rects.h>
#include <Processing/Vision/PerspectiveMapping/gold_proc_pm_widget_export.h>

namespace ui {
namespace win {

  // fwd
class CWindowCore;

/// Un Widget che scrive su schermo dove e' il mouse la coordinata mondo corrispondente.
/// \code
///  win->SetLayer(1);
///  win->SetColor(0,0,255);
///  win->Push(SPDrawingObject(new IPMProbeWidget(Rect2f(0,0,ipmImgWidth,ipmImgHeight), RPLimits) ));
///  win->SetLayer(0);
/// \endcode
class GOLD_PROC_PM_WIDGET_EXPORT IPMProbeWidget : public CWidget, public RefPlaneMapping
{
    public:
    // alcuni typedef (Traits) per essere indipendenti dal tipo di dati usato internamente
    typedef math::Rect2f Rect;
    private:
    /// area del widget
    Rect m_area;
    /// Punto su cui disegnare il testo
    math::Point2f m_pt;
    /// Origine Linea *immagine*
    math::Point2f m_line;
    /// Origine Line *mondo*
    math::Point2f m_line_w;
    /// Testo (X: Y:)
    std::string m_str;
    /// scostamento rispetto al punto del mouse dove compare il testo
    float m_dx,m_dy;
    /// non disegna nulla ma imposta il CustomMessage
    bool m_quiet;
    /// Track
    bool m_track;
    /// Prende il controllo dell'area
    bool m_owner;
    public:
        /// ctor:
        /// @param area rettangolo che contiene l'area da mappare
        /// @param limits i limiti dell'area
        /// @param owner se owner e' false usa @a area per delimitare il widget, altrimenti true e' tutta la finestra
        /// @param dx,dy scostamento dal cursore del testo disegnato
        /// @param quiet se quiet mostra il contenuto nella status bar usanto SetCustomStatusBar
        IPMProbeWidget(const Rect & area, const RefPlaneLimits & limits, bool owner=false, float dx=0.0f, float dy=0.0f, bool quiet=false);
        ~IPMProbeWidget();
        const char* getName() const;
        bool Interact(CWindowCoreManager* pWindow, const CWindowEvent& event);
        int Draw(CWindowCore* pWindow);
};

}
}

#endif
