#ifndef _LO_RRANSAC_H
#define _LO_RRANSAC_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file LO_RRANSAC.h
 * @author Paolo Zani (zani@vislab.it)
 * @date 2012-03-29
 */

#include <Processing/SampleConsensus/detail/EstimatorTraits.hxx>
#include <Processing/SampleConsensus/detail/DataExtractor.hxx>
#include <Processing/SampleConsensus/detail/LossFunctions.hxx>
#include <Processing/SampleConsensus/detail/PreliminaryTest.hxx>
#include <Processing/SampleConsensus/detail/LO_SAC.hxx>
#include <Processing/SampleConsensus/Consensus.h>

#include <boost/thread/thread.hpp>

#include <cstddef>
#include <limits>

namespace sample_consensus
{
    /**
    * @ingroup SAC
    * @defgroup LO-RRANSAC LO-RRANSAC
    * @brief Locally Optimized and Randomized RANSAC algorithm
    *
    * It is an hybrid of @cite LO-RANSAC03 and @cite RRANSAC02.
    * @{
    **/

    /**
     * @brief Computes the model parameters that minimize a given cost function over the samples using the supplied estimator.
     *
     * @param [out] model The model with lowest cost.
     * @param [in] samples Input data, containing both inliers and outliers.
     * @param [in] max_inliers_error Max fitting error of inlier samples.
     * @param [in] d Size of the sample used in the preliminary test.
     * @param [in] max_opt_iterations Max iterations of the inner optimization stage. Defaults to 10.
     * @param [in] a Success rate, in the range [0, 1]. Defaults to 0.99.
     * @param [in] max_iterations Max algorithm iterations. Defaults to std::numeric_limits<unsigned int>::max().
     * @param [in] estimator Data analysis class. Defaults to the built-in estimator for the given model.
     * @return Some details about both the model and the selection process.
     **/
    template<typename Model, typename Estimator, template<typename, typename> class Container, typename T, typename Allocator>
    inline ConsensusInfo LO_RRANSAC(Model& model, const Container<T, Allocator>& samples, double max_inliers_error, size_t d, unsigned int max_opt_iterations, double a, unsigned int max_iterations, Estimator& estimator, unsigned int threads_number = boost::thread::hardware_concurrency())
    {
        detail::LO_SAC<sample_consensus::detail::RectLoss> sac;
        return sac(model, 0, samples.size() - 1, detail::DataExtractor<Container<T, Allocator> >(samples), estimator, detail::TddTest(d), max_inliers_error, max_opt_iterations, a, max_iterations, threads_number);
    }

    /** @cond **/
    template<typename Model, template<typename, typename> class Container, typename T, typename Allocator>
    inline ConsensusInfo LO_RRANSAC(Model& model, const Container<T, Allocator>& samples, double max_inliers_error, size_t d, unsigned int max_opt_iterations = 10, double a = 0.99, unsigned int max_iterations = std::numeric_limits<unsigned int>::max())
    { typename detail::EstimatorTraits<Model>::EstimatorType estimator; return LO_RRANSAC(model, samples, max_inliers_error, d, max_opt_iterations, a, max_iterations, estimator); }
    /** @endcond **/


    /**
     * @brief Computes the model parameters that minimize a given cost function over the samples using the supplied estimator.
     * @note This method is useful when you want to use indexes rather than the sample values.
     *
     * @param [out] model The model with lowest cost.
     * @param [in] min_sample Minimum input index.
     * @param [in] max_sample Maximum input index.
     * @param [in] max_inliers_error Max fitting error of inlier samples.
     * @param [in] d Size of the sample used in the preliminary test.
     * @param [in] max_opt_iterations Max iterations of the inner optimization stage.
     * @param [in] a Success rate, in the range [0, 1].
     * @param [in] max_iterations Max algorithm iterations.
     * @param [in] estimator Data analysis class.
     * @param [in] threads_number Numer of threads to run in parallel. Defaults to boost::thread::hardware_concurrency().
     * @return Some details about both the model and the selection process.
     **/
    template<typename Model, typename Estimator>
    inline ConsensusInfo LO_RRANSAC(Model& model, size_t min_sample, size_t max_sample, double max_inliers_error, size_t d, unsigned int max_opt_iterations, double a, unsigned int max_iterations, Estimator& estimator, unsigned int threads_number = boost::thread::hardware_concurrency())
    {
        detail::LO_SAC<sample_consensus::detail::RectLoss> sac;
        return sac(model, min_sample, max_sample, detail::DataExtractor<void>(), estimator, detail::TddTest(d), max_inliers_error, max_opt_iterations, a, max_iterations, threads_number);
    }

    /**@}*/
}

#endif
