/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2007                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 *  Author: Carletti Marcello (April 2003)                            *
 *          Medici Paolo (October 2004 - )                            *
 **********************************************************************/

#ifndef _IMAGE_LUT_H
#define _IMAGE_LUT_H

#include <boost/math/tr1.hpp>
#include <Data/Math/Points.h>
#include <Data/Math/Rects.h>
#include <Data/CImage/Pixels/RGBA8.h>  // RGBA8
#include <Data/CImage/TImage.h>
#include "LutPixel.h"
#include <boost/thread.hpp>
#include <Processing/Vision/PerspectiveMapping/gold_proc_pm_export.h>

/** \file ImageLUT.h
  * \author Paolo Medici (medici@ce.unipr.it)
  * \date 12Oct2004
  * \brief  Questo file di header permette di di creare e gestire LookUpTable per mappare punti di una immagine su un'altra.
  *
  * Le classi definite in questo documento sono
  *  - DirectImageLUT : Mappa punti su punti senza interpolare
  *  - BilinearImageLUT : Mappa punti su punti interpolando linearmente nelle due direzioni spaziali
  *  - FPBilinearImageLUT : FixedPoint Bilinear Image LUT (fast)
  *
  * Una breve trattazione delle LUT si puo' trovare in \ref LUT .
  *
  * ImageLUT e' la classe padre, da cui puo' discendere una StorableImageLUT che e' una classe
  *   che aggiunge uno stato interno alle LUT per permetterne la composizione, la conversione
  *   e il salvataggio, e TImageLUT<T> implementa effettivamente l'applicazione
  *   della LUT usando dei traits.
  *
  * Classi che utilizzano le LUT sono TXImageLUT, TPMImageLUT, TIPMImageLUT
  **/

// valore che viene assegnato ai pixel che non sono definiti nella LUT
#define IPM_UNDEFINED_COLOR_VALUE   255

// ----- DEFINES -----
#define METLUT_UNDEFINED -1.0e30


// ------------------------------------------------------- ImageLUT* -----------------------------------
/** Classe genitore per le ImageLUT. Non puo' essere direttamente istanziata per via dei metodi puri
 *
 * una ImageLUT possiede i soli metodi ImageLUT::LoadFromFile e sopratuttto ImageLUT::Apply.
 *
 * Questa classe permette anche la generazione della LUT attraverso i metodi Reset e soprattutto
 *  attraverso il metodo virtuale ImageLUT::SetPixel.
 * C'e' da dire che SetPixel dipende molto dal tipo di LUT utilizzata e SetPixel accetta per ogni punto della LUT un Point2d Sorgente
 **/
class GOLD_PROC_PM_EXPORT ImageLUT
    {
    public:
    unsigned int width, height;   ///< LUT SIZE - Size of Destination
    unsigned int srcWidth, srcHeight;	///< Source Size

    /// funzione interna per caricare un generico file di LUT, in formato A
    /// @note file is a URI location
    static math::Point2f *LoadTextLUTFile(const char *file,
        unsigned int &FileLutWidth,
        unsigned int &FileLutHeight,
        unsigned int &FileSrcWidth,
        unsigned int &FileSrcHeight);

    /// funzione interna per caricare un generico file di LUT in formato Binario A
    /// @note file is a URI location
    static math::Point2f *LoadBinLUTFile(const char *file,
        unsigned int &FileLutWidth,
        unsigned int &FileLutHeight,
        unsigned int &FileSrcWidth,
        unsigned int &FileSrcHeight);

    /// return the geometry of LUT file
    static bool GetFileInfo(const char *filename, unsigned int &FileLutWidth,
        unsigned int &FileLutHeight,
        unsigned int &FileSrcWidth,
        unsigned int &FileSrcHeight);

    protected:

    /// Number of Threads
    int m_nThreads;
    /// color used in undefined
    cimage::RGBA8 m_undef_value; 

    public:
    /** Costruttore di default
      * @param imgLUTWidth,imgLUTHeight dimensioni della LUT che equivalgono alle dimensioni dell'immagine DESTINAZIONE
      * @param srcImgWidth,srcImgHeight dimensioni dell'immagine SORGENTE
      **/
    ImageLUT(unsigned int imgLUTWidth, unsigned int imgLUTHeight, unsigned int srcImgWidth, unsigned int srcImgHeight) :
        width(imgLUTWidth), height(imgLUTHeight), srcWidth(srcImgWidth), srcHeight(srcImgHeight), m_nThreads(boost::thread::hardware_concurrency()), m_undef_value(IPM_UNDEFINED_COLOR_VALUE) {};
    ImageLUT(unsigned int _width, unsigned int _height) :
        width(_width), height(_height), srcWidth(_width), srcHeight(_height), m_nThreads(boost::thread::hardware_concurrency()), m_undef_value(IPM_UNDEFINED_COLOR_VALUE) {};

    virtual ~ImageLUT();

/*@{*/
    /// Ritorna la dimensione della LUT (immagine di output)
    unsigned int GetWidth(void) const { return width; }
    /// Ritorna la dimensione della LUT (immagine di output)
    unsigned int GetHeight(void) const { return height; }

    /// Ritorna la dimensione dell'immagine sorgente di riferimento (su cui esegue il clamp dei valori)
    unsigned int SrcWidth(void) const { return srcWidth; }
    /// Ritorna la dimensione dell'immagine sorgente di riferimento (su cui esegue il clamp dei valori)
    unsigned int SrcHeight(void) const { return srcHeight; }
/*@}*/

    /// Set color used in undefined pixel (funziona?)
    inline void SetUndefinedColor(const cimage::RGBA8 & color) { m_undef_value = color; }

    /// Reset the whole LUT to UNDEFINED VALUE (usa SetPixel).
    void Reset(void);

    /** set the threading
      */
    inline void SetNumberOfThreads(int nThread) { m_nThreads = nThread; }

    /// Load the LUT from the file 'fileName'
    /// @note fileName puo' essere un URI per accedere a risorse (anche remote) attraverso gli xstream
    virtual bool LoadFromFile(const char *fileName);

    /** Una funzione per impostare il generico punto su una LUT.
     *
     * Associa al punto sull'immagine destinazione (xd,yd) il punto sull'immagine sorgente (xs,ys) **/
    virtual void SetPixel(unsigned int xd, unsigned int yd, double xs, double ys) = 0;

    /// Wrapper 
    template<class T>
    void SetPixel(unsigned int xd, unsigned int yd, const T & p)
        {
        SetPixel(xd, yd, p.x, p.y);
        }

/*@{*/

    /** \brief Apply: Apply LUT to a piece of, or an entire Image
     * @param dstImage Un buffer immagine destinazione, di dimensioni (width x height)
     * @param srcImage Un buffer immagine sorgente, di dimensioni (srcWidth x srcHeight)
     * @param bpp Byte Per Pixels (1:Mono8,2:Mono16,3:RGB8)
     * @param area Un area destinazione, inclusi i bordi, su cui applicare la LUT. Puo' essere NULL. In questo caso si riferisce all'intera immagine
     */
    virtual void ApplyToImage(unsigned char * dstImage, const unsigned char * srcImage, unsigned int bpp, const math::Rect2i* area=NULL) =0;

    /** \brief Apply LUT to a C-Like Buffer
      * @param dstImage a destination T buffer (width x height)
      * @param srcImage a source T buffer (srcWidth x srcHeight)
      *
      * @note only cimage::Mono8 and cimage::RGB8 are allowed
      * \code
      * lut_ipm->Apply((cimage::RGB8*)ipm_image, (const cimage::RGB8*)input_image);
      * \endcode
      **/
    template<class T>
    void Apply(T * dstImage, const T * srcImage, const math::Rect2i* area=NULL);

    /** \brief Apply LUT to a CImage
      * @param dst a destination image (it will be resized to width x height)
      * @param src source image (srcWidth x srcHeight)
      * @param area An optional subpart of output image. if NULL it process all the output image.
      *
      * @note only CImageMono8 and CImageRGB8 are supported
      * @note @a dst image is resized to LUT geometry.
      * 
      * \code
      * // process all imgDst (resized to width x height)
      * lut->Apply(imgDst, imgSrc);
      * 
      * // process a subpart
      * math::Rect2i roi(10,10,50,50);
      * lut->Apply(imgDst, imgSrc, &roi);
      * \endcode
      **/
    template<class T>
    void Apply(cimage::TImage<T> &dst, const cimage::TImage<T> &src, const math::Rect2i* area=NULL);
/*@}*/

    /** filtra la LUT usando la maschera fornita da buffer. tutto cio' che in buffer e' diverso da zero viene tolto dall'IPM.
     * @param buffer un buffer di unsigned char grande ipm width, ipm height
     * @param width,height dimensioni del buffer per validare. se il buffer e' diverso dalla lut viene lanciata un eccezione
    */
    void Filter(const unsigned char *buffer, unsigned int width, unsigned int height);

    /** filtra la LUT usando la maschera fornita da buffer. tutto cio' che in buffer e' diverso da zero viene tolto dall'IPM.
     * @param mask una CImageMono8
     * @note se l'immagine ha dimensioni differenti dalla LUT viene lanciata una eccezione
    */
    void Filter(const cimage::TImage<unsigned char > &mask);

    /** genera la LUT usando una funzione di remapping (oggetto funzione)
     * La funzione di remapping e' una funzione che accetta un Point2i (coordinate immagine destinazione) e ritorna un Point2d sull'immagine sorgente.
     * @a param r un oggetto funzione del tipo Point2d operator()(Point2i)
     * \code
     * lut->Compute(MyRemappingObject);
     * \endcode
     **/
     template<class R>
     void Compute(const R & r)
        {
        for(unsigned int j=0;j<height;j++)
          for(unsigned int i=0;i<width;i++)
            SetPixel(i, j, r(math::Point2d(i,j)) );
        }

    /** Genera una LUT (inversa ma sparsa) usando una funzione di remapping.
    *
    *  La LUT sparsa e' una LUT che potrebbe contenere dei buchi
    *  La funzione di remapping e' una funzione che accetta un Point2i (coordinate immagine sorgente) e ritorna un Point2d o un Point2i sull'immagine 'destinazione'.
    * \code
    * lut->ComputeSparse(MyRemappingObject);
    * \endcode
    **/
        template<class R>
        void ComputeSparse(const R & r)
        {
        Reset();
        for(unsigned int j=0;j<srcHeight;j++)
          for(unsigned int i=0;i<srcWidth;i++)
            {
            typename R::return_type p = r(math::Point2i(i,j));
            int ux = (int) boost::math::tr1::round( p.x );
            int uy = (int) boost::math::tr1::round( p.y );
            if((ux>=0)&&(uy>=0)&&(ux<int(width))&&(uy<int(height)))
                SetPixel(ux, uy, i, j);
            }
        }

    /** Compone l'operatore @a op con la lut @a source
      * LUT [i,j] -> op -> source -> [u,v] IMG
      * l'Operatore @a op deve avere un metodo operator()(Point2d)
      * mentre @a source deve essere una LUT (o equivalente) con il metodo GetInterpolatedPoint
      **/
    template<class T, class S>
    void CreateFrom(const T & op, const S * source)
        {
        for(unsigned int j=0;j<GetHeight();j++)
                for(unsigned int i=0;i<GetWidth();i++)
                        SetPixel(i,j, source->GetInterpolatedPoint( op(math::Point2d(i,j)) ) );
        }

};

/** Una base comune per le ImageLUT che vogliono conservare comunque memoria
 *   dei punti caricati, senza necessariamente applicarli su una immagine (per esempio per fare inversione
 *   della LUT stessa).
 *
 * Implementa il metodo virtuale SetPixel e il successivo vincolo che a un punto destinazione corrisponde un solo punto sorgente.
 *
 * A parte la GenericImageLUT TUTTE le LUT usate in GOLD discendono da questa
 *  (pertanto le IPMDirectImageLUT .. PMBilinearImageLUT etc etc)
 * 
 * @note Le StorableImageLUT potrebbero essere istanziate se implementassero un metodo Apply
 *  se utile realizzare un Apply Stub.
 *
 **/
class GOLD_PROC_PM_EXPORT StorableImageLUT : public ImageLUT
{
    private:

    // Avoid copy of StorableImageLUT
    StorableImageLUT(const StorableImageLUT & src) : ImageLUT(0,0,0,0) { }

    /// Salva la LUT su un file di testo (cross platform - big and slow)
    bool SaveToTextFile(const char *file);
    /// Salva la LUT su un file binario (dipendende dalla piattaforma, piu' piccolo e veloce)
    bool SaveToBinFile(const char *file);

    public:
    /// Effective Pixel Pos (to save LUT on Disk)
    math::Point2d *points;

    public:

    typedef math::Point2d *iterator;
    typedef math::Point2d *const_iterator;

    /// classe usata internamente da find_nearest
    struct search {
        bool found;
        double d2;
        int index;
        unsigned int x,y;
        math::Point2d *p;
    };

    public:

    StorableImageLUT(unsigned int imgLUTWidth, unsigned int imgLUTHeight, unsigned int srcImgWidth, unsigned int srcImgHeight);
    virtual ~StorableImageLUT();

    // fun Iterator :)
    inline iterator begin() { return &points[0]; }
    inline iterator end() { return &points[width*height]; }

    inline const_iterator begin() const { return &points[0]; }
    inline const_iterator end() const { return &points[width*height]; }

    /** ritorna quale punto dell'immagine di input e' associato al generico punto dell'immagine di output
     * @param dstCol,dstRow [out] coordinata nell'immagine originale
     * @param srcCol,srcRow [in] coordinata sull'immagine LUT
     * @return true se le coordinate di ingresso sono corrette o false altrimenti
     **/
    template<class T>
    bool GetRemappedPoint(T *dstCol, T *dstRow, int srcCol, int srcRow) const
    {
    if((srcCol>=0)&&(srcRow>=0)&&(srcCol<(int)width)&&(srcRow<(int)height))
        {
	    const math::Point2d *p = &points[srcCol + srcRow*width];
        *dstCol = p->x;
        *dstRow = p->y;
        return true;
        }
    return false;
    }

    /** ritorna il punto associato
     *
     * Dato il punto sull'immagine di output @a srcCol,srcRow ritorna il punto corrispondente
     *  sull'immagine di input
     * @param dst un Point2d solitamente, o un oggetto che puo' essere convertito da questo
     * @param srcCol,srcRow punto sull'immagine destinazione
     * @return se il punto e' interno all'immagine true
     */
    template<class T>
    bool GetRemappedPoint(T *dst, int srcCol, int srcRow) const
    {
    if((srcCol>=0)&&(srcRow>=0)&&(srcCol<(int)width)&&(srcRow<(int)height))
        {
	    *dst = points[srcCol + srcRow*width];
        return true;
        }
    return false;
    }

    /** ritorna il punto asssociato nell'immagine originale
    *
    * In una trasformazione LUT che discende da StorableImageLUT e' possibile sapere per ogni punto
    *  dell'immagine LUT a quale punto dell'immagine originale corrisponde.
    * @param p un punto nell'immagine LUT (Point2i)
    * @return le coordiante del punto nell'immagine originale
    */
    inline math::Point2d GetRemappedPoint(const math::Point2i & p) const
    {
    if((p.x>=0)&&(p.y>=0)&&(p.x<(int)width)&&(p.y<(int)height))
        {
        return points[p.x + p.y*width];
        }
    throw std::runtime_error("GetRemappedPoint called with invalid bounds");
    }

   /** ritorna un punto intepolando i limitrofi **/
    math::Point2d GetInterpolatedPoint(const math::Point2d & p) const;

    /// Si limita a memorizzare il dato senza generare nessuna LUT
    /// E' virtuale perche' sono i figli, che poi generano la LUT vera. Questa deve essere solo chiamata
    ///  per permettere il salvataggio dei dati o meno.
    virtual void SetPixel(unsigned int xd, unsigned int yd, double xs, double ys)
        {
        // NOTA: xs,ys potrebbero essere al di fuori dell'immagine di input
        //       e' corretto pertanto mantenere xs,ys o usare al loro posto
        //       -1,-1 ?
        points[xd + yd * width].x = xs; points[xd + yd * width].y = ys;
        }

    /// Wrapper
    template<class T>
    void SetPixel(unsigned int xd, unsigned int yd, const T & p)
        {
        SetPixel(xd, yd, p.x, p.y);
        }

    /// Save the LUT to the file 'fileName' (depends on extension a binary or text file will be produced)
    bool SaveToFile(const char *fileName);

    /** Export permette di convertire una StorableImageLUT in un altra
     *
     * @param dst StorableImageLUT che verra' impostata
     * @note non c'e' ora controllo se le LUT siano compatibili
     **/
    bool Export(ImageLUT *dst) const ;

    /** Export permette di convertire una StorableImageLUT in un altra
     *
     * @param dst StorableImageLUT che verra' impostata
     * @param rect quale sottoparte della LUT corrente esportare
     * @note non c'e' ora controllo se le LUT siano compatibili
     **/
    bool Export(ImageLUT *dst, const math::Rect2i & rect) const ;

// #ifdef INVERT_LUT //
    /** Invert e' un procedimento LENTISSIMO che permette di invertire
     *   la lut creando una LUT inversa.
     *  La LUT inversa deve essere allocata e deve avere dimensioni compatibili
     *   con la lut corrente **/
    bool Invert(ImageLUT *dst, double range=5.0) const ;


    /** Compose permette di unire la LUT corrente a un'altra
     *
     * Sia la LUT corrente una LUT che passa da una immagine [2] a una immagine [1] (in questo caso
     *  [1] e' l'immagine destinazione dell'operazione di LUT e [2] e' l'immagine sorgente) e
     *  si vuole unire la LUT corrente a una LUT che mappa i punti di [2] su i punti di [3],
     *  creando una LUT che mappa i punti di [1] su i punti di [3].
     *
     * @param src LUT a cui il sorgente verra collegato a quello di questa
     * @todo non c'e' controllo se le LUT siano compatibili
     **/
    bool Compose(const StorableImageLUT *src);

    /// Data una LUT sparsa prova a riempire i buchi piu' semplici interpolando tra i valori adiacenti
    void FillSparse(void);

/*@ {*/
    /** Una funzione LENTISSIMA: ritorna il punto che mappa piu' vicino possibile
     *   al punto richiesto
     * @param hint un area in cui cercare per ridurre il peso
     **/
    void find_nearest(search & result, double src_x, double src_y, const math::Rect2i *hint=NULL) const;
/*@ }*/

    /** ritorna un'immagine dove i valori validi sono posti a 0 e i valori invalidi della LUT a 255
     * @param buffer un buffer che verra' riempito con i valori
     * @param width,height dimensioni del buffer per validare. se il buffer e' diverso dalla lut viene lanciata un eccezione
     * @param area area dell'immagine sorgente (o una sua sottoparte per esempio)
     * @param valid valore a cui viene posto il buffer nei punti validi
     * @param unvalid valore a cui viene posto il buffer nei punti non validi
     * @note area.is_inside(points[i]) indica se il punto e' valido
     **/
    void ExportMask(unsigned char *buffer, unsigned int width, unsigned int height, const math::Rect2i & area, unsigned char valid=0, unsigned char unvalid=255);

    /** ritorna un'immagine dove i valori validi sono posti a 0 e i valori invalidi della LUT a 255
     * @param buffer un buffer che verra' riempito con i valori
     * @param width,height dimensioni del buffer per validare. se il buffer e' diverso dalla lut viene lanciata un eccezione
     * @param valid valore a cui viene posto il buffer nei punti validi
     * @param unvalid valore a cui viene posto il buffer nei punti non validi
     * @note points[i]<0 per indicare il punto non valido (NON IMPLEMENTATO sempre)
     **/
    void ExportMask(unsigned char *buffer, unsigned int width, unsigned int height, unsigned char valid=0, unsigned char unvalid=255);

    friend void Overlapp(StorableImageLUT *a, StorableImageLUT *b);
};

/** Overlapp two StorableImageLUT, keeping only the part that are not declared UNDEFINED in both the image.
  *  It checks if pixel coord is inside or outside source image.
  *  Sovrappone le parti UNDEFINED di due ImageLUT.
  *  In questo modo entrambe le LUT hanno le stesse parti attive e disattive (va bene per LUT IPM stereo per esempio).
  * @param a,b two different StorableImageLUT
  * @note if the two LUTs have different geometry an exception will be trown. 
  **/
GOLD_PROC_PM_EXPORT void Overlapp(StorableImageLUT *a, StorableImageLUT *b);

/** Questa e' la LUT che unisce alla gestione della LUT fornita dal traits T le seguenti possibilita':
  *  - R e' StorableImageLUT: uno stato interno per salvare la LUT e convertirla
  *  - R e' ImageLUT: una classe leggera senza stato interno e ridotto consumo di memoria
  *
  * NOTA: si potrebbe anche scrivere un'altra classe di LUT che non discende da StorableImageLUT, LUT che possono essere solo generate
  *       o caricate da disco ma non salvate (se non in maniera RAW). Queste LUT non possono essere convertite tra di loro
  *       ma usano meno RAM.
  * T e' l'applicatore dell'interpolazione
  **/
template<typename T, typename R=StorableImageLUT>
class GOLD_PROC_PM_EXPORT TImageLUT : public R
{
    private:
    // Avoid copy of TImageLUT
    TImageLUT(const TImageLUT<T,R> & src) : R(0,0,0,0) { }

    protected:
    /// applica la LUT usando il traits T
    template<unsigned int, typename C>
    void _internal_apply(C* dstImage, const C* srcImage, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1);
    template<unsigned int, typename C>
    void _internal_apply_mcore(C* dstImage, const C* srcImage, unsigned int x0, unsigned int y0, unsigned int x1, unsigned int y1);

    protected:
    /// The Precomputed LUT table
    T *m_lut;

    public:
    /// LUT Costructor
    TImageLUT(unsigned int imgLUTWidth, unsigned int imgLUTHeight, unsigned int srcImgWidth, unsigned int srcImgHeight) : R(imgLUTWidth, imgLUTHeight, srcImgWidth, srcImgHeight)
        {
        unsigned int i_size = imgLUTWidth * imgLUTHeight;
        if(i_size==0)
            throw std::runtime_error("[EE] TImageLUT called with invalid parameters (0 width/height)\n");

        m_lut = new T[i_size];
        }

    virtual ~TImageLUT()
        {
        delete [] m_lut;
        }

    /// Test if an element is defined
    /// @note boundaries check is not performed
    bool IsDefined(unsigned int x, unsigned int y) const
        {
        return m_lut[x + y * R::width].IsDefined();
        }

    /// Test if an element is defined
    /// @note boundaries check is not performed
    bool IsDefined(const math::Point2i & p) const
        {
        return m_lut[p.x + p.y * R::width].IsDefined();
        }

    /// Applica la LUT tra le immagini del tipo selezionato, e opzionalmente e' possibile specificare l'area destinazione
    virtual void ApplyToImage(unsigned char* dstImage, const unsigned char* srcImage, unsigned int bpp, const math::Rect2i* area=NULL);

    /// Assegna al pixel della lut (xd,yd) alla versione arrotondata di (xs,ys)
    /// @note includere ImageLUT.tcc per poter usare questa funzione direttamente
    void SetPixel(unsigned int xd, unsigned int yd, double xs, double ys);
};

/// DirectImageLUT e' la precedente versione della LUT che a ogni punto destinazione mappa un unico punto della sorgente
/// Aggiunge il metodo DirectImageLUT::GetRemappedPoint
class GOLD_PROC_PM_EXPORT DirectImageLUT : public TImageLUT<PixelPos,StorableImageLUT>
{
    public:
    DirectImageLUT(unsigned int imgLUTWidth, unsigned int imgLUTHeight, unsigned int srcImgWidth, unsigned int srcImgHeight) : TImageLUT<PixelPos>(imgLUTWidth, imgLUTHeight, srcImgWidth, srcImgHeight) {}

    /// Return the point ('lutCol','lutRow') in LUT corresponding to the given
    /// point ('srcCol','srcRow') LUT coordinate
    /// @note le DirectImageLUT mappando interi su interi hanno queste funzioni solamente
    bool GetRemappedPoint(int *lutCol, int *lutRow, int srcCol, int srcRow) const;

    /// return the point (x,y) corresponding to the given point in LUT coordinate
    /// @note le DirectImageLUT mappando interi su interi hanno queste funzioni solamente
    inline math::Point2i GetRemappedPoint(const math::Point2i & p) const
    {
    if((p.x>=0)&&(p.y>=0)&&(p.x<(int)width)&&(p.y<(int)height))
        return math::Point2i(m_lut[p.x + p.y*width].col, m_lut[p.x + p.y*width].row );
    throw std::runtime_error("GetRemappedPoint called with invalid bounds");
    }

};

/// LUT con filtraggio, usata sia per la IPM che per la rimozione della distorsione
///  Applica una interpolazione lineare all'immagine sorgente per ricavare i dati. Puo' essere composta con altre
///
/// @todo aggiungere oltre all'interpolazione lineare anche un'interpolante filtro Cubico
///       (come fare visto che SetPixel prende un solo valore?)
typedef TImageLUT<BilinearPixel,StorableImageLUT> BilinearImageLUT;

/// Nuova LUT, usata sia per la IPM che per la rimozione della distorsione
///  Applica una interpolazione lineare molto veloce usando FixedPoint all'immagine sorgente per ricavare i dati.
/// @note benchmark su StereoBox danno un aumento di prestazione > 20%
/// @todo aggiungere oltre all'interpolazione lineare anche un'interpolante filtro Cubico
///       (come fare visto che SetPixel prende un solo valore?)
typedef TImageLUT<FPBilinearPixel,StorableImageLUT> FPBilinearImageLUT;

#endif  // _IMAGE_LUT_H
