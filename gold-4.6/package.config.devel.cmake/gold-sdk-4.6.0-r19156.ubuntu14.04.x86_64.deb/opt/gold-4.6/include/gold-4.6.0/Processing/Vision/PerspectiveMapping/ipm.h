/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2007                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 *  Author: Carletti Marcello (April 2003)                            *
 *          Medici Paolo (October 2004 - today)                       *
 **********************************************************************/
/* La documentazione per questo file si puo' trovare in               *
 *   http://vislab.it/GOLD/doxy/html/ipm_8h.html                      *
 **********************************************************************/
 
#ifndef _IPM_LIB_H
#define _IPM_LIB_H


/** \file ipm.h
  * \author Paolo Medici (medici@ce.unipr.it)
  * \date 6-Apr-2005
  * \brief (Image) Perspective Mapping
  * Questo file contiene classi e funzioni che permettono di eseguire trasformazioni prospettiche
  * 
  * Le classi definite in questo documento sono
  *  - PerspectiveMapping : classe base per mappare punti nello spazio immagine su punti reali
  *  - InversePerspectiveMapping : classe base per mappare punti del mondo su punti immagine
  *
  * Una breve trattazione delle trasformazioni prospettiche si puo' trovare in \ref IPM
  **/

#include <boost/math/tr1.hpp>
#include <cmath>    
#include <iosfwd>

#include <Processing/Vision/PerspectiveMapping/gold_proc_pm_export.h>

#include <Data/Math/Points.h>
#include <Data/Math/Lines.h>
#include <Data/Math/TMatrices.h>
#include <Data/Base/CCameraParams.h>
#include "RefPlaneLimits.h"

// ------------------------------------------------------------------------------------------------------------------

class InversePerspectiveMapping;

/** This class handle PerspectiveMapping trasformation. 3D World points are mapped onto an image space 
 * @note Tutti i valori sono in metri
 * @note questa classe non funziona su immagini distorte, percio' e' sempre necessario dedistorcere le immagini in precedenza
 *
 * \code
 * PerspectiveMapping pm;
 * CameraParams cp;
 * // ... ad esempio
 * cp << camera;
 * // ...
 * pm.SetParams(cp);
 * math::Point2d i = pm(x, y, z);
 * \endcode
 **/
class GOLD_PROC_PM_EXPORT PerspectiveMapping
{
 protected:
    /// focal length (in pixel unit)
    double ku,kv;
    /// Principal Point position
    double u0,v0;  
    /// Rotation matrix
    math::TMatrix<double,3,3> r;
    /// Traslation vector (camera coord)
    math::Point3d t;
    
 public:
    typedef math::TMatrix<double,3,3> Matrix3x3_t;
 public:
    PerspectiveMapping() : ku(1.0), kv(1.0) {}
    PerspectiveMapping(const dev::CameraParams & camParams)
        {
        SetParams(camParams); 
        }

    /// setta la posizione della camera 
    ///  la camera si puo' spostare se i restanti valori dei camera params rimangono validi
    void SetCameraOrigin(double xPos, double yPos, double zPos);
    
    /// Imposta i parametri della Camera per generare la trasformazione prospettica
    void SetParams(const dev::CameraParams & camParams);

    /** Rotation Matrix (from world to camera coordinate) 
      */
    inline const math::TMatrix<double,3,3> & GetRotationMatrix() const { return r; }
    /** world origin in camera coordinate (see geometry.pdf) 
      */
    inline const math::Point3d & GetT() const { return t; }
    /** focal length in pixels unit: horizontal */
    inline double Ku() const { return ku; }
    /** focal length in pixels unit: vertical */
    inline double Kv() const { return kv; }
    
    /// ritorna la matrice K (come descritto in geometry.pdf)
    void GetIntrinsicMatrix(Matrix3x3_t & A) const;

    /// ritorna la matrice [R|t] prospettica dei soli parametri estrinseci, matrice affine che trasforma da coordinate mondo
    ///  a coordinate camera (x_c y_c z_c) = P (x_w y_w z_w 1)
    void GetRTMatrix(math::TMatrix<double, 3,4> & RT ) const;
    
    /// ritorna la matrice di proiezione prospettica (u v 1) = P (x y z 1)
    void GetPMatrix(math::TMatrix<double, 3,4> & P ) const;
    
    /** ritorna la matrice omografica del piano z=costante per la trasformazione di PerspectiveMapping 
     * {u,v,1} = H {x,y,1}
     * che proietta punti del mondo (metri) in punti immagine.
     * @note non e' una trasformazione IPM perche' le coordinate sono in metri e non in pixel
     * @see ht::HomographicMatrix
     * @param [out] H matrice 3x3 contenente la trasformazione omografica
     **/
    bool GetOmographicZMatrix(Matrix3x3_t & H, double z=0) const;


    /** Convert World Coordinates to Camera Coordinates
     * In Camera Coordiantes x is the axis left-right, y is the axis down-up and z is depth
     * @note should not be use directly, but called through PixelFromWorld
     **/
    /** Project a point from world coordinate (wx,wy,wz) to Camera Coord */
    template<class T>
    inline math::Point3d WorldToCamera(T wx, T wy, T wz) const
        {
        return math::Point3d(r[0]*wx + r[1]*wy + r[2]*wz + t.x,
                       r[3]*wx + r[4]*wy + r[5]*wz + t.y,
                       r[6]*wx + r[7]*wy + r[8]*wz + t.z);
        }
    template<class T>   
    inline math::Point3d WorldToCamera(const math::Point3<T> &w) const
        {
        return WorldToCamera<double>(w.x, w.y, w.z);
        }

     /// return the z-coordinate (depth) in camera reference frame
     ///  z-coordinate is the distance along Z-axis between camera and point
     /// @note in coordinate camera la z non e' la z delle coordinate mondo, ma e' la profondita'.
     /// @note Can be used to test if a point is in front or back of camera.
     template<class T>
     inline T GetCameraZCoord(const math::Point3<T> &w) const
     {
     return r[6]*w.x + r[7]*w.y + r[8]*w.z + t.z;
     }
   
   /// ritorna la coordinata Y immagine dell'orizzonte
   inline double GetHorizonY(void) const
        {
        return (kv * r[3] / r[6]) + v0;
        }
   /// ritorna la coordinata X immagine del punto in cui convergono tutti i raggi dell'immagine
   inline double GetHorizonX(void) const
        {
        return (ku * r[0] / r[6]) + u0;
        }
   /// Ritorna il punto dell'orizzonte
   inline math::Point2d GetHorizonPoint(void) const
		{
		return math::Point2d(GetHorizonX(),GetHorizonY());
		}

   /// Ritorna la linea dell'orizzonte (x,y -> infinito)
   math::Line3d GetHorizonLine(void) const;

   /** Project a point from Camera Coordinate to Image Coordinate */
   template<class T>
   inline math::Point2<T> PixelFromCamera(const math::Point3<T> & c) const
   {
        return math::Point2<T>( (ku * c.x / c.z) + u0,
                          (kv * c.y / c.z) + v0 );
   }

    /*@{*/
     /** (xw,yw,zw) world coordinate to math::Point2<T> image coordinate
       * \code
       * math::Point2d pm.PixelFromWorld(1.0,0.0,0.0);
       * \endcode
       **/
     template<class T>        
     inline math::Point2<T> PixelFromWorld(T xw, T yw, T zw)  const {
	return PixelFromCamera(WorldToCamera(xw, yw, zw));
    }
    
     /** Point3\<T\> from world coordinate to math::Point2\<T\> in image coordinate
       * \code
       * Point3d w = ....
       * 
       * math::Point2d pm.PixelFromWorld(w);
       * \endcode
       **/
     template<class T>        
     inline math::Point2<T> PixelFromWorld(const math::Point3<T> & w)  const {
	return PixelFromCamera(WorldToCamera(w.x, w.y, w.z));
    }
        
    /// Applica una trasformazione di PerspectiveMapping al punto mondo @a w
    template<class T>    
    inline math::Point2<T> operator() (const math::Point3<T> & w)  const {
	return PixelFromCamera(WorldToCamera(w.x, w.y, w.z));
    }
    /// Applica una trasformazione di PerspectiveMapping al punto mondo @a w
    template<class T>    
    inline math::Point2<T> operator() (T xw, T yw, T zw)  const {
	return PixelFromCamera(WorldToCamera(xw, yw, zw));
    }
    /*@}*/

   /// return the absolute distance from the camera where WidthMeters = WidthPixels
   /// @note use only intrinsic parameters
   /// @note absolute distance means the distanca in meters from pin-hole in direction along perspective ray
   double GetDistanceFromWidth(double WidthPixels, double WidthMeters) const 
   {
	// WidthPixels = ku * WidthMeters/z;
	// z = ku 
	return ku * WidthMeters / WidthPixels;
   }

    
    /** Dato un punto di origine e un vettore questa funzione ritorna la retta epipolare associata
     * @param out una linea in coordinate immagine
     * @param o un punto (x,y,z) di un punto della retta (es il pin-hole) 
     * @param v un vettore (x,y,z) che indica la direzione della retta (es. un valore ritornato da GetEpipolarVector)
     * @return true se la retta esiste, o false se degenera in un punto
     * @note unimplemented. use FundamentalMatrix instead (it is more accurate)
     **/
    bool GetEpipolarLine(math::Line3d &out, const math::Point3d & o, const math::Point3d & v);
    
    /** \brief Obtain 4 corners of RefPlaneLimits in image coordinates, usefull to draw IPM Polygon
     * @param[out] x,y a 4 double array, handling the (x,y) image coordinates
     * @param[in] limits a RefPlaneLimits structure that contain the surface limits 
     * \return bool If a valid parameters are passed to function */
    template<class T>
    void GetImagePlaneLimits(math::Point2<T> *p, const RefPlaneLimits & limits)
    {
        p[0] = PixelFromWorld(limits.xmax, limits.ymax, limits.z);
        p[1] = PixelFromWorld(limits.xmax, limits.ymin, limits.z);
        p[2] = PixelFromWorld(limits.xmin, limits.ymin, limits.z);
        p[3] = PixelFromWorld(limits.xmin, limits.ymax, limits.z);
    }
};

/** This class handle InversePerspectiveMapping trasformation. 
 *   2d Point from image are mapped on a 3D World plane.
 *
 * @note i valori sono in metri. 
 * @note questa classe non funziona su immagini distorte, percio' e' sempre necessario dedistorcere le immagini in precedenza
 *
 * \code
 * InversePerspectiveMapping ipm;
 * dev::CameraParams cp;
 * // ... ad esempio
 * cp << camera;
 * // ...
 * ipm.SetParams(cp);
 * Point3d wx = ipm.WorldFromPixelZ(u, v, 0.0);
 * Point3d wy = ipm.WorldFromPixelX(u, v, 0.0);
 * Point3d wz = ipm.WorldFromPixelY(u, v, 0.0);
 * \endcode
 **/
class GOLD_PROC_PM_EXPORT InversePerspectiveMapping
{
 protected:
    /// inverse of focal length
    double i_ku,i_kv;
    /// Principal Point position
    double u0, v0;
    /// Rotation matrix
    math::TMatrix<double,3,3> r;
    /// Traslation vector (world coord)
    math::Point3d t;
    
 public:
    typedef math::TMatrix<double,3,3> Matrix3x3_t;
 public:
   
    InversePerspectiveMapping() : i_ku(1.0), i_kv(1.0) { }

    InversePerspectiveMapping(const dev::CameraParams & camParams)
        {
        SetParams(camParams); 
        }
    
    /// setta la posizione della camera 
    ///  la camera si puo' spostare se i restanti valori dei camera params rimangono validi
    void SetCameraOrigin(double xPos, double yPos, double zPos);

    /// imposta i parametri della camera e della visuale
    void SetParams(const dev::CameraParams & camParams);
     
    /// return the inverse of focal length in pixel unit: horizontal (1/ku)
    double InvKu() const { return i_ku; }
    /// return the inverse of focal length in pixel unit: vertical (1/kv)
    double InvKv() const { return i_kv; }

    /// @return Inverse Rotation Matrix (from camera to world coord)
    const math::TMatrix<double,3,3> & GetRotationMatrix() const { return r; }
    /// @return position of pin-hole in world coordinate
    const math::Point3d & GetPinHolePosition() const { return t; }

    /// ritorna la matrice K^{-1} (come descritto in geometry.pdf)
    /// permette di trasformare punti immagine in coordinate camera
    void GetInverseIntrinsicMatrix(Matrix3x3_t & iA) const;
    
    /** ritorna la matrice omografica del piano z=costante per la trasformazione di InversePerspectiveMapping 
     * {X,Y,1} = P {u,v,1}
     * che proietta punti immagine in coordinate mondo metriche
     * @see ht::HomographicMatrix
     * @param H matrice 3x3 contenente la trasformazione omografica
     **/
    bool GetOmographicZMatrix(Matrix3x3_t & H, double z=0) const;


/*@{*/
    /** return the normalized image coordinates A-1 (u v 1) 
      * metodo interno che ritorna (x,y) in coordinate camera normalizzate
      **/
    template<class T>
    inline math::Point2d NormalizedImageCoordinate(T u, T v) const  {
        return math::Point2d(i_ku*((double)u-u0), i_kv * ((double)v-v0));
    }
    template<class T>
    inline math::Point2d NormalizedImageCoordinate(const math::Point2<T> & p) const  {
        return NormalizedImageCoordinate(p.x, p.y);
    }
/*@}*/ 

/*@{*/
   
     /** \brief Obtain(xw,yw,(zw)) World Point from (u,v) image's point
      * 
      * Fornendo le coordinate di un punto dell'immagine (u,v) e la coordinata zw si ottengolo le altre due coordinate xw,yw
      * return a Point3d living on Z plane 
      * @param u,v   a Point on image
      * @param zw    z plane height
      * @return Point3d with world point
      **/
    inline math::Point3d WorldFromPixelZ(double u, double v, double zw = 0.0 ) const
        {
        // (~u,~v,1) = A^{-1} (u,v,1)
	math::Point2d c = NormalizedImageCoordinate(u,v);
        // calcola l'intersezione tra il vettore e il piano zw: t + c*l = (*,*,zw)
        double l = (zw - t.z) / (r[6]*c.x + r[7]*c.y + r[8]);
	return math::Point3d(
		(r[0]*c.x + r[1]*c.y + r[2])*l + t.x,
		(r[3]*c.x + r[4]*c.y + r[5])*l + t.y,
		zw );
        }
        
    /** return a Point3d living on X plane
      * @param u,v   a Point on image
      * @param xw    X plane distance
      * @return Point3d with world point
      **/
    math::Point3d WorldFromPixelX(double u, double v, double xw ) const {
        // (~u,~v,1) = A^{-1} (u,v,1)
	math::Point2d c = NormalizedImageCoordinate(u,v);
	// calcola l'intersezione con il piano xw : t + c*l = (xw,*,*) 
	double l = (xw - t.x) / (r[0]*c.x + r[1]*c.y + r[2]);
	return math::Point3d(
		xw,
        	(r[3]*c.x + r[4]*c.y + r[5])*l + t.y,
		(r[6]*c.x + r[7]*c.y + r[8])*l + t.z
	);
	}

    /** return a Point3d living on Y plane
      * @param u,v   a Point on image
      * @param yw    y plane position
      * @return Point3d with world point
      **/
    math::Point3d WorldFromPixelY(double u, double v, double yw ) const {
        // (~u,~v,1) = A^{-1} (u,v,1)
        math::Point2d c = NormalizedImageCoordinate(u,v);
	// calcola l'intersezione con il piano yw:  t + c*l = (*,yw,*)
	double l = (yw - t.y) / (r[3]*c.x + r[4]*c.y + r[5]);
	return math::Point3d(
		(r[0]*c.x + r[1]*c.y + r[2])*l + t.x,
        	yw,
		(r[6]*c.x + r[7]*c.y + r[8])*l + t.z
	);

        }

    /** Return in world coordinate a line (@a out) rapresented by line at height @a z and image coordinate @a u
      */
    bool GetVerticalLineInWorld(math::Line3d * out, double z, double u) const;


      /** ritorna la coordinata Y dell'orizzonte (usando la matrice trasposta)
      **/
   inline double GetHorizonY(void) const
        {
        return (r[1] / (r[2] * i_kv)) + v0;
        }

	/** ritorna la coordinata X dell'orizzonte (usando la matrice trasposta)
      **/
   inline double GetHorizonX(void) const
        {
        return (r[0] / (r[2] * i_ku)) + u0;
        }
    
    /// Coordinata (x,y) immagine del punto in cui converge. PerspectiveMapping::GetHorizonX e PerspectiveMapping::GetHorizonX sono piu veloci
    math::Point2d GetHorizonPoint(void) const
        {
		return math::Point2d(GetHorizonX(), GetHorizonY());
        }
        
    /*@{*/

    /// return the z coordinate of ray: z>0 over horizont, z<0 below horizont
    ///  se z() e' maggiore a zero, siamo sopra l'orizzonte, quando uguale a zero siamo sull'orizzonte
    template<class T>
    inline double w(T u, T v) const
     {
        math::Point2d c = NormalizedImageCoordinate(u,v);
        // c e' in coordinate camera normalizzate
        return r[6]*c.x + r[7]*c.y + r[8];
     }
 
    
    /** ritorna l'equazione della retta in coordinate mondo sottesa al punto immagine (u,v)
     *  @param u,v coordinate di un punto dell'immagine
     *  @return un vettore che, uscendo dall'origine della camera, punta verso il punto (u,v)
     **/
    template<class T>                   
    inline math::Point3d GetEpipolarVector(T u, T v)  const
            {
            math::Point2d c = NormalizedImageCoordinate(u,v);
	    return math::Point3d(
             r[0]*c.x + r[1]*c.y + r[2],
             r[3]*c.x + r[4]*c.y + r[5],
             r[6]*c.x + r[7]*c.y + r[8] );
            }

    /** ritorna l'equazione della retta in coordinate mondo sottesa al punto immage i
     *  @param p un punto immagine
     *  @return un vettore che, uscendo dall'origine della camera, punta verso il punto (u,v)
     **/
    template<class T>
    inline math::Point3d GetEpipolarVector(const math::Point2<T> & p)  const
            {
	    return GetEpipolarVector<T>(p.x, p.y);
            }
    
    /// ritorna un vettore normalizzato (versore) rappresentante il raggio che parte dal pin-hole e passa per il punto
    ///  immagine (u,v)
    template<class T>
    math::Point3d GetEpipolarVersor(double u, double v)  const
    {
      math::Point3d p = GetEpipolarVector(u,v);
      p.normalize();
      return p;
    }
    /*@}*/
    
};

#endif
