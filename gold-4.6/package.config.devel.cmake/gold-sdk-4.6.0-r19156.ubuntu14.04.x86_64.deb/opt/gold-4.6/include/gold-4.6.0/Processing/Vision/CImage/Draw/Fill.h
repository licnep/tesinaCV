#ifndef _DRAW_FILL_H
#define _DRAW_FILL_H

/** @file Fill.h
 *  @brief apply on a whole surface a brush */

namespace draw {
  
/** \ingroup Draw
 * Apply a fill on a whole surface, without rules 
 * 
 * \code
 draw::Fill( draw::Opaque<unsigned char>(buffer, 128,128, 0) );
 * \endcode
 * @see draw::Box
 */  
template <class _Brush>
void Fill(_Brush f)
  {
  int h = f.H();
  int x1 = f.W()-1;
  for (int j = 0; j < h; j++)
      f.FillLine(0, x1, j);
  }  
  
/** \ingroup Draw
 * FloodFill algorithm */
template <class _Brush>
void FloodFill(_Brush f, int x0, int y0, int threshold);
  
}

#endif