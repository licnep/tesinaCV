#ifndef _UI_FILTEREDWTA_H
#define _UI_FILTEREDWTA_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2011                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/


/**
 * \file UI_FilteredWTA.h
 * \author Paolo Zani (zani@vislab.it)
 * \date 2011-02-08
 */

#include <Processing/Vision/Stereo/DisparityEngine/Optimization/FilteredWTA.h>

#include <UI/Panel/Panel.h>

namespace disparity
{
    // forward declarations

    namespace opt
    {
        template<typename ResultType_Agg, uint32_t Threads_Agg, typename ResultType_Opt, typename Impl_Opt, uint32_t Threads_Opt> class FilteredWTA;
    }

    template<typename Aggregation, typename Engine>
    class UI_Optimization;

    template<typename ResultType_Agg, uint32_t Threads_Agg, typename ResultType_Opt, typename Impl_Opt, uint32_t Threads_Opt, typename Engine>
    class UI_Optimization<opt::FilteredWTA<ResultType_Agg, Threads_Agg, ResultType_Opt, Impl_Opt, Threads_Opt>, Engine>
    {
        public:
        
            UI_Optimization(Engine* _this) : m_this(_this) {}

            void Init(INIFile* pIni)
            {             
                ui::var::Value<bool> disambEnabled(&m_this->m_disambEnabled);
                ui::var::Value<bool> subpixelAccuracyEnabled(&m_this->m_subpixelAccuracyEnabled);
                ui::var::Value<bool> filteringEnabled(&m_this->m_filteringEnabled);
                ui::var::Range<double> m_maxCorrelationPeakValueNorm(&m_this->m_maxCorrelationPeakValueNorm, 0, 200.0, 0.1);
                ui::var::Value<bool> extraFilteringEnabled(&m_this->m_extraFilteringEnabled);
                ui::var::Range<int32_t> minCorrelFunctionElementsNum(&m_this->m_minCorrelFunctionElementsNum, 0, 255, 1);
                ui::var::Range<double> m_maxCorrelationPeakDispersion(&m_this->m_maxCorrelationPeakDispersion, 0, 200.0, 0.1);
                ui::var::Range<double> minInvCorrelationPeakSharpness(&m_this->m_minInvCorrelationPeakSharpness, 0, 200.0, 0.1);

                ui::conf::Configuration conf(pIni);
                
                conf.Bind(disambEnabled, "ENABLE DISAMBIGUATION", m_this->DEFAULT_DISAMB_ENABLED);
                conf.Bind(subpixelAccuracyEnabled, "ENABLE SUBPIXEL", m_this->DEFAULT_SUBPIXEL_ACCURACY_ENABLED);
                conf.Bind(filteringEnabled, "ENABLE FILTERING", m_this->DEFAULT_FILTERING_ENABLED);
                conf.Bind(m_maxCorrelationPeakValueNorm, "MAX CORRELATION PEAK VALUE", m_this->DEFAULT_MAX_CORRELATION_PEAK_VALUE);
                conf.Bind(extraFilteringEnabled, "ENABLE EXTRA FILTERING", m_this->DEFAULT_EXTRA_FILTERING_ENABLED);
                conf.Bind(minCorrelFunctionElementsNum, "MIN CORRELATION FUNCTION ELEMENTS", m_this->DEFAULT_MIN_CORRELATION_FUNCTION_ELEMENTS_NUM);
                conf.Bind(m_maxCorrelationPeakDispersion, "MAX CORRELATION PEAK DISPERSION", m_this->DEFAULT_MAX_CORRELATION_PEAK_DISPERSION);
                conf.Bind(minInvCorrelationPeakSharpness, "MIN INV CORRELATION PEAK SHARPNESS", m_this->DEFAULT_MIN_INV_CORRELATION_PEAK_SHARPNESS);

                m_panel(ui::wgt::VSizer())
                (
                    ui::wgt::CheckBox(subpixelAccuracyEnabled, "Enable subpixel").Border(3),
                    ui::wgt::CheckBox(disambEnabled, "Enable disambiguation").Border(3),
                    ui::wgt::GridSizer().Border(3)
                    (
                        ui::wgt::SzCell(0, 0)( ui::wgt::CheckBox(filteringEnabled, "Enable filtering") ),
                        ui::wgt::SzCell(1, 0)( ui::wgt::Text("Max peak value") ), ui::wgt::SzCell(1, 1).HExpand()( ui::wgt::Slider(m_maxCorrelationPeakValueNorm) ),
                        ui::wgt::SzCell(2, 0)( ui::wgt::CheckBox(extraFilteringEnabled, "Enable extra filtering") ),
                        ui::wgt::SzCell(3, 0)( ui::wgt::Text("Min correl function elements") ), ui::wgt::SzCell(3, 1).HExpand()( ui::wgt::Slider(minCorrelFunctionElementsNum) ),
                        ui::wgt::SzCell(4, 0)( ui::wgt::Text("Max peak dispersion") ), ui::wgt::SzCell(4, 1).HExpand()( ui::wgt::Slider(m_maxCorrelationPeakDispersion) ),
                        ui::wgt::SzCell(5, 0)( ui::wgt::Text("Min inv peak sharpness") ), ui::wgt::SzCell(5, 1).HExpand()( ui::wgt::Slider(minInvCorrelationPeakSharpness) )
                    )
                );
            }

            inline std::string Name() { return "Filtered WTA"; }

            inline ui::wgt::Widget Panel() { return m_panel; }
            
        private:
            
            Engine* m_this;
            ui::wgt::VSizer m_panel;
    };
}

#endif
