#if 0
// Questo codice è stato spostato in Statistics
#ifndef _CIMAGE_STATISTICS_H
#define _CIMAGE_STATISTICS_H

#include <Data/CImage/TImage.h>
#include <Data/CImage/PixelTraits/PixelTraits.h>
#include "CImageAlgorithms.h"
#include "PixelFunctors.h"

// Calcoli sull'immagine e statistiche di base

/// calcola la media sui punti di un sottoinsieme regolare
// virtual StatisticType GetMean ( unsigned int Start=0, unsigned int Stride=1, unsigned int _Size=0, unsigned int PCh=0, unsigned int ICh=0 ) const = 0;

/// calcola la media dei punti nel vettore
// virtual StatisticType GetMean(const std::vector<PixelCoordType>& Pixels) const = 0;

/// calcola la media sui punti di una maschera
// virtual StatisticType GetMean ( const CImage &Mask ) const = 0;

/// calcola la somma dei pixel
// virtual double GetSum(unsigned int Start=0, unsigned int Stride=1, unsigned int _Size=0, unsigned int PCh=0, unsigned int ICh=0) const = 0;

// virtual DECLSPEC_DEPRECATED CColorHistogram ColorHistogram(unsigned int Channel=0) const = 0;

// template <class S> void ColorHistogram(S* DstArray, unsigned long NumElements, unsigned int Channel=0, unsigned int Step=1) const {}
      // Calcoli sull'immagine e statistiche di base
      // TODO: qual'e' l'insieme minimo di parametri
      // che permette di descrivere tutti i sottoinsiemi di una matrice 3D?
      // start, stride e size permettono di farlo per un array 2D.
      // NOTE: utilizzare una slice, struttura che permette di identificare regioni regolari
      // NOTE: le funzioni che operano su sottoinsiemi dovrebbero essere:
      // - sottoinsiemi regolari
      // - maschera
      // - lista di punti prepopolata

      // calcola la media sui punti di un sottoinsieme regolare
      // StatisticType GetMean ( unsigned int Start=0, unsigned int Stride=1, unsigned int _Size=0, unsigned int PCh=0, unsigned int ICh=0 ) const;


      // calcola la media sui punti di una maschera
      // StatisticType GetMean ( const CImage &Mask ) const;

      // calcola la media dei punti nel vettore
      // StatisticType GetMean(const std::vector<PixelCoordType>& Pixels) const { throw CMethod_Not_Implemented(); }

      // double GetSum(unsigned int Start=0, unsigned int Stride=1, unsigned int _Size=0, unsigned int PCh=0, unsigned int ICh=0) const { throw CMethod_Not_Implemented(); }

namespace cimage
{
  typedef std::vector<double> StatisticType;         ///< ritorna un valore per ciascun canale

  template <class ImageType, class MaskType>
  class CMean
  {
      typedef typename ImageType::PixelTraits::ChannelCumulativeType ChannelCumulativeType;

      std::vector<ChannelCumulativeType> CumulativeValues;
      AreaType N;
      double MaskSum;   // sum of the mask values
      const ImageType& m_Image;
      const unsigned int W;

      typename ImageType::PixelType m_Buffer; // buffer per le operazioni di mascheratura

    public:
      CMean ( const ImageType& Image ) :
          CumulativeValues ( ImageType::PixelTraits::Channels() ) ,
          N ( 0L ),
          MaskSum ( 0.0 ),
          m_Image ( Image ),
          W ( m_Image.W() )
      {}

      void operator() ( const typename ImageType::PixelType &pixel, const typename MaskType::PixelType mask )
      {
        // maschera il pixel
        Apply_Mask ( m_Buffer, pixel, mask );

        // aggiorna il valore cumulativo per ogni canale
        for ( unsigned int i=0; i<ImageType::PixelTraits::Channels(); ++i )
        {
          // accumula il valore di ciascun canale
          CumulativeValues[i]+=static_cast<ChannelCumulativeType> ( *ImageType::PixelTraits::GetChannel ( &m_Buffer, W, i ) );

          // accumula il valore della maschera
          MaskSum+=static_cast<double> ( mask );
        }
      }

      cimage::StatisticType GetMean()
      {
        cimage::StatisticType RetVal ( ImageType::PixelTraits::Channels() );

        // compila l'array delle statistiche per ogni canale
        for ( unsigned int i=0; i<ImageType::PixelTraits::Channels(); ++i )
          RetVal[i]=CumulativeValues[i]/static_cast<unsigned int> ( MaskSum/MaskType::PixelTraits::Channel_Max() );

        return RetVal;
      }
  };




  template<class T>
  cimage::StatisticType GetMean ( const TImage<T>& Image, unsigned int Start, unsigned int Stride, unsigned int _Size, unsigned int PCh, unsigned int ICh )
  {
    typedef PixelTraits<T> PixelTraits;

    cimage::StatisticType RetVal ( PixelTraits::Channels() );
    std::vector<typename PixelTraits::ChannelCumulativeType> CumulativeValues ( PixelTraits::Channels() );

    AreaType N=0;

    const typename PixelTraits::PixelType *Buffer = Image.RLock() +Start+PCh;
    const typename PixelTraits::PixelType *End    = Buffer+Image.Area();

    // per ogni pixel
    for ( ; Buffer<End; Buffer+=Stride, ++N )
      // per ogni canale
      for ( unsigned int i=0; i<PixelTraits::Channels(); ++i )
        CumulativeValues[i]+=*PixelTraits::GetChannel ( Buffer, Image.W(), i );

    Image.UnLock();

    // per ogni canale
    for ( unsigned int i=0; i<PixelTraits::Channels(); ++i )
      RetVal[i]=CumulativeValues[i]/N;

    return RetVal;
  }




// template<class T>
// cimage::StatisticType GetMean(const CImage &Mask) const
// {
//   std::cout << "20070904 this method is deprecated use the function instead" << std::endl;
//
//   typedef TImage<unsigned char> MaskType;
//
//   // TODO: la maschera deve avere un canale e
//   // la stessa dimensione dell'immagine
//   const MaskType &mask = reinterpret_cast<const MaskType& >(Mask);
//   return ::for_each_masked_sub_on_mask(*this, mask, CMean<TImage, MaskType>(*this)).GetMean();
// }
//


  /**
   * Funzione per il calcolo della media di una immagine su una maschera
   * @param Mask
   * @return
   */
  template<class ImageType, class MaskType>
  cimage::StatisticType Mean ( const ImageType &Image, const MaskType &Mask )
  {
    return cimage::for_each_masked_sub_on_mask ( Image, Mask, CMean<ImageType, MaskType> ( Image ) ).GetMean();
  }



// TODO: separare in un file di specializzazione in CImageMono

// template<>
// double GetSum(unsigned int Start, unsigned int Stride, unsigned int _Size, unsigned int PCh, unsigned int ICh) const
// {
//   double RetVal = 0.0;
//
//   const unsigned char *Buffer = RLock();
//   for(unsigned int i=0, j=Start; i<_Size; i++, j+=Stride)
//     RetVal+=(double) *(Buffer+j);
//   UnLock();
//
//   return RetVal;
// }

}


// TODO: le specializzazioni di BasicOperations vanno da un'altra parte
namespace cimage
{

// template<>
// // TODO: spostare in Statistics_CImageMono
// // TODO: channel
// CImage::StatisticType CImageMono::GetMean(unsigned int Start, unsigned int Stride, unsigned int _Size, unsigned int PCh, unsigned int ICh) const
// {
//   StatisticType RetVal(1, 0.0);
// 
//   const unsigned char *Buffer = RLock();
//   RetVal[0] = gsl_stats_unsigned char_mean(Buffer+Start, Stride, _Size?_Size:Size());
//   UnLock();
// 
//   return RetVal;
// }

} // namespace cimage


// template<>
// // TODO: perfezionare algoritmo
// CImage::StatisticType CImageRGB8::GetMean(unsigned int Start, unsigned int Stride, unsigned int _Size, unsigned int PCh, unsigned int ICh) const
// {
//   StatisticType RetVal(3, 0.0);
//   double R=0.0, G=0.0, B=0.0, N=0.0;
// 
//   const cimage::RGB8 *Buffer = RLock()+Start+PCh;
//   const cimage::RGB8 *End    = Buffer+Area();
//   for(; Buffer<End; Buffer+=Stride, ++N)
//     R+=Buffer->R, G+=Buffer->G, B+=Buffer->B;
//   UnLock();
// 
//   RetVal[0]=R/N; 
//   RetVal[1]=G/N;
//   RetVal[2]=B/N;
// 
//   return RetVal;
// }






#endif // _CIMAGE_STATISTICS_H


#endif