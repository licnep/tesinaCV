#ifndef _ROBERT_CROSS_H
#define _ROBERT_CROSS_H

/** @file RobertCross
 * @brief metodi di Robert Cross
 **/

#include <stdint.h>
#include <Data/CImage/PixelTraits/PixelTraits.h>
#include "ConvolutionKernel.h"
#include "FilterModifier.h"

namespace cimage {

namespace kernel {
  
/// Filtro di Robert Cross 'Orizzontale'
template<uint32_t w, uint32_t h>
class RobertCrossHorizontal;

template<>
class RobertCrossHorizontal<2,2>
{
    public:
    // unbiased filter
    static const int bias = 0; 
    // can return negative numbers
    static const bool positive = false;
    // sum of weights
    static const unsigned int magnitude = 2;    
  
  public:

   template<class D>
   inline D zero() const { return D(0); }

   inline uint32_t GetWidth() const { return 2; }
   inline uint32_t GetHeight() const { return 2; }

   template<typename S>
   struct Return {
        //typedef typename cimage::PixelTraits<S>::DifferenceType Type;
	typedef int Type;
	};

   template<typename S>
   inline typename Return<S>::Type operator() ( const S* I, long stride ) const
    {
	return (int)I[-1-stride] - (int)I[0];
    }
};

/// Filtro di Robert Cross 'Verticale'
template<uint32_t w, uint32_t h>
class RobertCrossVertical;

template<>
class RobertCrossVertical<2,2>
{
    public:
    // unbiased filter
    static const int bias = 0; 
    // can return negative numbers
    static const bool positive = false;
    // sum of weights
    static const unsigned int magnitude = 2;    
  
  public:

   template<class D>
   inline D zero() const { return D(0); }

   inline uint32_t GetWidth() const { return 2; }
   inline uint32_t GetHeight() const { return 2; }

   template<typename S>
   struct Return {
        //typedef typename cimage::PixelTraits<S>::DifferenceType Type;
	typedef int Type;
	};

   template<typename S>
   inline typename Return<S>::Type operator() ( const S* I, long stride ) const
    {
	return (int)I[-stride] - (int)I[-1];
    }
};

/** Modulo (norma1) RobertsCross normalizzato **/
typedef filter::Div< filter::Sum2< filter::Abs < RobertCrossVertical<2,2> >, filter::Abs< RobertCrossHorizontal<2,2> > >, 2> RobertCross2x2;

/** Filtro di RobertsCross con soglia **/
typedef filter::ModuleBin< RobertCrossVertical<2,2>,  RobertCrossHorizontal<2,2> >   RobertCrossBin2x2;

}

namespace filter {
  
/** Filtro di RobertsCross normalizzato **/  
typedef TLocalFilter< kernel::RobertCross2x2 > RobertCross2x2;

/** Filtro di RobertsCross con soglia **/  
typedef TLocalFilter< kernel::RobertCrossBin2x2 > RobertCrossBin2x2;

}

} // namespace cimage

#endif
