#ifndef _HOMOGRAPHIC_TRANSFORMATIONS_H
#define _HOMOGRAPHIC_TRANSFORMATIONS_H

/** \file HomographicTransformation.h
  * \brief Homographic Matrix Generators
  * \author Paolo Medici \<medici@vislab.it\>
  **/
  
#include <Data/Base/CCameraParams.h>
#include <Data/Math/Rects.h>
#include <Processing/Vision/PerspectiveMapping/RefPlaneLimits.h>
#include <Processing/Vision/PerspectiveMapping/HomographicMatrix.h>

/// Homographic trasformation namespace
namespace ht {

///@name built-in homographic transformation
/*@{*/

/** Algoritmi per ComputeHomography. Step Non Lineare */
enum MaximumLikelihoodAlgorithm {
    No_NLn_Refine,              ///< ritorna solo la trasformazione lineare
    Transfer_Error1,            ///< non Lineare: errore sulla lista FIRST
    Transfer_Error2,            ///< non Lineare: errore sulla lista SECOND
    Sampson_Error,              ///< non Lineare: errore su entrambi i dati. metodo Sampson
    Symmetric_Transfer_Error,   ///< non Lineare: errore su entrambi i dati. Minimizzazione della somma degli errori di riproiezione
    Reprojection_Error          ///< non Lineare: errore su entrambi i dati. Minimizzazione dell'errore di riproiezione
};

/** Algoritmi per ComputeHomography. Step Lineare */
enum DLTAlgorithm {
  DLT_Standard,             ///< non esegue nessun raffinamento sulla DLT
  DLT_Normalize,            ///< Normalizza le componenti prima di eseguire la DLT
  DLT_FixElement            ///< Fissa l'elemento 8 a 1 
};


/** \brief setta i parametri della camera sorgente e della camera destinazione usando il piano Z = 0
  *
  * Questa funzione permette di rimappare il piano Z=0 tra due differenti vista, con variazioni qualunque dei parametri (yaw,pitch,roll,x,y,z,alpha,beta,...),
  *  per permettere di fare per esempio Ground Plane Stereo.
  * @param target Target Parameters
  * @param source Source Parameters
  * @note To remap any points (and not only ZPlane points) but limiting the change to only rotation and aperture, you have to use CameraRectify
  * @see ht::CameraRectify
  * @see TImageHomographicMappingFilter, HomographicMappingFilter, XImageLUT
  */
GOLD_PROC_PM_EXPORT HomographicMatrix CameraWarp(const dev::CameraParams & target, const dev::CameraParams & source);

/** setta i parametri della camera sorgente e della camera destinazione
*   questa funzione calcola la matrice di riproiezione 
*  @param source dev::CameraParams dell'immagine sorgente (InversePerspectiveMapping)
*  @param target dev::CameraParams dell'immagine destinazione (PerspectiveMapping)
*  @param M Matrice di spostamento (da rimuovere quando saro' bravo a muovere la camera Target a piacimento)
*           (X',Y',1) = M * (X,Y,1)
*
*  @note forse ho invertito source con target :) controllare!
*        Essendo poi frutto di deliranti conti, potrebbe anche non funzionare
*  @note Funzione per piani z==0 (per piani z!=0 modificare i dev::CameraParams di conseguenza)
*        Si puo' modificare il codice in maniera che prenda piani Z!=0 comunque
*  @note usata per il MotionStereo di Apalaci-CRF
* @see TImageHomographicMappingFilter, HomographicMappingFilter, XImageLUT
**/
GOLD_PROC_PM_EXPORT HomographicMatrix CameraWarp(const dev::CameraParams & source, const Matrix_t & M, const dev::CameraParams & target);

/** setta i parametri di rimappatura della stessa camera 
  *   previo uno spostamento inserito nella matrice di ROTATRASLAZIONE M 3x3 (X',Y',1)=M * (X,Y,1)
  *  @note Funzione per piani z==0 (per piani z!=0 modificare i dev::CameraParams di conseguenza)
  *        Si puo' modificare il codice in maniera che prenda piani Z!=0 comunque
  * @see TImageHomographicMappingFilter, HomographicMappingFilter, XImageLUT
  * **/
GOLD_PROC_PM_EXPORT HomographicMatrix CameraWarp(const dev::CameraParams & camera, const Matrix_t & M);
  
/** Small rotation Only and Alpha e Beta Image Transformation
  * Trasformazione che usa solo i cambi di prospettiva dovuti
  * a piccole rotazioni (per il roll e' piu' robusta) e cambi di alpha e beta
  * @param source parametri camera immagine sorgente 
  * @param target parametri camera output destinazione (sintetica)
  * @note e' una trasformazione sperimentale... non garantisce che sia la migliore trasformazione affine.
  * TODO: mettere in affinemap un metodo per convertire una trasformazione omografica
  *       nella trasformazione affine che riduce al minimo l'errore.
   * @see per sicurezza usare CameraRectify. Questa funzione non garantisce risultati ottimali attualmente.
   * @TODO: spostare in affinemap.h
  **/
GOLD_PROC_PM_EXPORT HomographicMatrix AffineCameraRectify(const dev::CameraParams & target, const dev::CameraParams & source);

/** Rotation Only and Alpha e Beta Image Transformation
  * Trasformazione che usa solo i cambi di prospettiva (meglio se piccoli se c'e' distorsione) dovuti
  *  a rotazioni del pinhole e cambi di alpha e beta
  * @param source camera parameters immagine sorgente 
  * @param target camera parameters output sintetica (destinazione)
  * @note Se si vuole applicare una trasformazione a una immagine bisogna scambiare @a target con @a source
  * @see TImageHomographicMappingFilter, HomographicMappingFilter, XImageLUT
  **/
GOLD_PROC_PM_EXPORT HomographicMatrix CameraRectify(const dev::CameraParams & target, const dev::CameraParams & source);

/** \brief Modifica una matrice omografica per avere il minimo errore su un area usando una trasformazione affine
 *  Questa funzione permette di capire quanto una trasformazione omografica e' distante da una trasformazione affine.
 *  @param m una matrice omografica che in uscita sara' affine (m[6]=m[7]=0.0)
 *  @param balancing_area un'area dell'immagine target dove minimizzare l'errore
 *  @return l'errore in pixel massimo
 **/
GOLD_PROC_PM_EXPORT double HomographicToAffine(HomographicMatrix & m, const math::Rect2i & balancing_area);
 
/** \brief prepara il sistema per una operazione di InversePerspectiveMapping o di PerspectiveMapping (se usata come LUT)
  * Genera la matrice omografica per l'applicazione di una IPM, per passare da coordinate immagine a coordinate IPM (pixels) su un 
  *  piano z prestabilito.
  *
  * (x,y) = H_{IPM}(u,v)
  *
  * @param camera Parametri della camera
  * @param plane Piano di mapping di Output. z deve essere settato
  * @param ipm_width,ipm_height dimensione dell'immagine di Output IPM
  * @note se si applica la matrice ritornata su un'immagine si ottiene una trasformazione PM
  * @see TImageHomographicMappingFilter, HomographicMappingFilter, XImageLUT, InversePerspectiveMapping::GetOmographicZMatrix
  **/
GOLD_PROC_PM_EXPORT HomographicMatrix IPM(const dev::CameraParams & camera, const RefPlaneLimits &plane, unsigned int ipm_width, unsigned int ipm_height);
   
/** \brief prepara il sistema per una operazione di PerspectiveMapping o di InversePerspectiveMapping (se usata come LUT)
  * Genera la matrice omografica per l'applicazione di una PM, per passare da coordinate IPM (pixel) a coordinate immagine per 
  *  punti su un piano z prestabilito
  *
  * (u,v) = H_{PM}(x,y)
  *
  * @param camera Parametri della camera
  * @param plane Piano di mapping di Input. z deve essere settato
  * @param ipm_width,ipm_height dimensione dell'immagine di Input IPM
  * @note se si applica la matrice ritornata su un'immagine si ottiene una trasformazione IPM
  * @see TImageHomographicMappingFilter, HomographicMappingFilter, XImageLUT, PerspectiveMapping::GetOmographicZMatrix
  **/
GOLD_PROC_PM_EXPORT HomographicMatrix PM(const dev::CameraParams & camera, const RefPlaneLimits &plane, unsigned int ipm_width, unsigned int ipm_height);


/** \brief DLT Homographic transformation using a PseudoInverse mathematical regression technique
  *
  * Dati delle coppie di punti nei sistemi di riferimento sorgente e destinazione genera una matrice omografica
  *  capace di trasformare tutti i punti delle due immagini.
  * Le trasformazioni esprimibile con una omografia sono le rettificazioni (cambio di parametri intriseci e rotazioni) o 
  *  le riproizioni di piani.
  *
  * Dati punti in coordinate del sistema di riferimento 1 e gli stessi punti nel sistema di riferimento 2 ritorna la matrice
  *  che fornisce la corrispondenza tra i due piani. quando n_points e' maggiore di 4 (sono richiesti almeno 4 punti) viene riportata
  *  la matrice che minimizza ai minimi quadrati l'errore.
  *
  * \f$ (second) = H (first) \f$
  *
  * @param first un array di punti nel sistema di riferimento 1
  * @param second un array di punti nel sistema di riferimento 2
  * @param m8     se true mette m[8]=1 (deprecato perche' non e' computazionalmente ottimo)
  * 
  * @note la matrice ritornata da questo metodo trasforma i singoli punti. Se si vuole applicare in seguito la trasformazione
  *       a una immagine, si possono invertire i vettori first e second passati alla funzione.
  * @note richiede le GSL, e percio' compilare GOLD con --enable-gpl
  * @see HomographicMatrix, TImageHomographicMappingFilter, HomographicMappingFilter, XImageLUT
  **/
GOLD_PROC_PM_EXPORT HomographicMatrix ComputeHomography(const math::Point2d * first, const math::Point2d * second, unsigned int n_points, DLTAlgorithm algo1 = DLT_Standard, MaximumLikelihoodAlgorithm algo2 = Transfer_Error2);

/** \brief DLT Homographic transformation using a PseudoInverse mathematical regression technique
  *
  * Genera una matrice omografica che permette di mappare punti di un piano sotto una certa prospettiva in punti di un altro piano
  *  sotto un'altra prospettiva.
  *
  * Versione con un vector di pair, che genera la matrice Omografica che proietta i punti di @a first nei @a second o, se si usa in una LUT, la trasformazione
  *  opposta (@a second in @a first ): \f$ (second) = H (first) \f$
  *
  * Dati punti in coordinate mondo (o coordinate IPM) e punti in coordinate immagine sullo 
  *  stesso piano (Z) viene generata la matrice che fornisce la corrispondenza tra i due piani. 
  *  quando size() e' maggiore di 4 (sono richiesti almeno 4 punti) viene riportata la matrice 
  *  che minimizza ai minimi quadrati l'errore.
  * @param couples un vector di coppie di punti, first (es. mondo), second (es. immagine).
  * @param m8     se true mette m[8]=1 (deprecato perche' non e' computazionalmente ottimo)
  *
  * @return una matrice omografica che permette di passare da coordinate mondo a coordinate immagine, o, se usata in una LUT, per trasforarmare
  *         l'immagine sorgente da cui i punti @a second provengono nell'immagine destinazione dei punti @a first
  *
  * @note per ottenere una trasformazione inversa basta scambiare i punti passati alla funzione,
  *       alternativamente chiedere la Matrice Omografica l' Inversa alla HomographicMatrix
  *
  * @note per come e' realizzata la DLT il valore @a second di ogni pair e' messo nella parte dei termini noti (da solo, senza
  *        contributi di @a first) di conseguenza il residuo della DLT e' calcolato come distanza euclidea verso entrambi i valori
  *        del math::Point2d di @a second . E' comunque una stima dell'errore non euclidea e non va considerata come tale.
  *
  * @note richiede le GSL, e percio' compilare GOLD con GSL
  * @see HomographicMatrix, TImageHomographicMappingFilter, HomographicMappingFilter, XImageLUT
  **/
GOLD_PROC_PM_EXPORT HomographicMatrix ComputeHomography(const std::vector< std::pair<math::Point2d,math::Point2d> > & couples, DLTAlgorithm algo1 = DLT_Standard, MaximumLikelihoodAlgorithm algo = Transfer_Error2);

/*@}*/

/** @name homographic primitives */
/*@{*/
/** Crea una matrice di ridimensione per passare da una immagine w1 x h1 
 *   a w2 x h2 (sia che siano pixel che metri)
 **/
GOLD_PROC_PM_EXPORT HomographicMatrix Resample(double w1, double h1, double w2, double h2);
/*@}*/

/** @name Remapping Tools */
/*@{*/
/** ritorna la matrice omografica che
 *   converte le coordinate immagine IPM (u,v) in coordinate mondo (x,y) [GOLD reference frame]
 * \f$ (x,y,1) = A (u,v,1) \f$
 * @note ovviamente se si usa in una LUT esegue la trasformazione inversa
 **/
GOLD_PROC_PM_EXPORT void ImageToMeters(Matrix_t & A, double width, double height, const RefPlaneLimits &plane);

/** ritorna la matrice omografica che
  *  converte le coordinate mondo (X,Y) [GOLD reference frame] in coordinate immagine IPM (u,v)
  * \f$ (u,v,1) = B (x,y,1) \f$
  * @note ovviamente se si usa in una LUT esegue la trasformazione inversa
  **/
GOLD_PROC_PM_EXPORT void MetersToImage(Matrix_t & B, double width, double height, const RefPlaneLimits &plane);
/*@}*/
};

#endif
