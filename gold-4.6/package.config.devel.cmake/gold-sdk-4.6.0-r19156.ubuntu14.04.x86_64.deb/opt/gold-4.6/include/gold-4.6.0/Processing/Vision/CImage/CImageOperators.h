#ifndef _CIMAGE_OPERATORS_H
#define _CIMAGE_OPERATORS_H

#include <Data/CImage/TImage.h>



// template<class T, class Traits> // template<class S>
// TImage<T> &TImage<T, Traits>::operator *= ( const double Factor )
// {
//   const T* pSrc = Buffer() +m_Area;
//   T* DstStart = Buffer();
//   for ( T *pDst=DstStart+m_Area;
//         pDst>DstStart;
//         --pDst, ( *pDst ) =static_cast<T> ( Factor* ( * ( --pSrc ) ) ) );
// 
//   return *this;
// }
// 
// 
// 
// template<class T, class Traits>  // template<class S>
// TImage<T> &TImage<T, Traits>::operator += ( const double Factor )
// {
//   const T* pSrc = Buffer() +m_Area;
//   T *pDstStart=Buffer();
//   for ( T *pDst=pDstStart+m_Area;
//         pDst>pDstStart;
//         --pDst, ( *pDst ) =static_cast<T> ( Factor+ ( * ( --pSrc ) ) ) );
// 
//   return *this;
// }
// 
// 
// template<class T, class Traits>
// TImage<T> &TImage<T, Traits>::operator &= ( const TImage<T>& Image )
// {
//   cimage::impl::for_each ( *this,  Image, Bitwise_And<T> );
//   return *this;
// }
// 
// template<class T, class Traits>
// TImage<T> &TImage<T, Traits>::operator |= ( const TImage<T>& Image )
// {
//   cimage::impl::for_each ( *this,  Image, Bitwise_Or<T> );
//   return *this;
// }
// 
// template<class T, class Traits>
// TImage<T> &TImage<T, Traits>::operator ^= ( const TImage<T>& Image )
// {
//   cimage::impl::for_each ( *this,  Image, Bitwise_Xor<T> );
//   return *this;
// }
// 
// 
// ///////////////////////////////////////////////////////////////////////////////////////
// ///////////////////////////////////////////////////////////////////////////////////////
// ///////////////////////////////////////////////////////////////////////////////////////
// ///////////////////////////////////////////////////////////////////////////////////////
// 
// 
// 
// template<class T, class Traits>
// TImage<T>& TImage<T, Traits>::operator += ( const TImage<T>& Image )
// {
//   cimage::impl::for_each ( *this,  Image, ::Add<T> );
//   return *this;
// }
// 
// template<class T, class Traits>
// TImage<T> &TImage<T, Traits>::operator -= ( const TImage<T>& Image )
// {
//   cimage::impl::for_each ( *this,  Image, ::Subtract<T> );
//   return *this;
// }
// 
// 
// ///
// template<class T, class Traits>
// TImage<T> &TImage<T, Traits>::operator *= ( const TImage<T>& Image )
// {
//   cimage::impl::for_each ( *this,  Image, ::Multiply<T> );
//   return *this;
// }
// 
// 
// template<class T, class Traits>
// TImage<T> &TImage<T, Traits>::operator /= ( const TImage<T>& Image )
// {
//   cimage::impl::for_each ( *this,  Image, ::Divide<T> );
//   return *this;
// }
// 
// 
// ///////////////////////////////////////////////////////////////////////////////////////
// ///////////////////////////////////////////////////////////////////////////////////////
// ///////////////////////////////////////////////////////////////////////////////////////
// ///////////////////////////////////////////////////////////////////////////////////////



// namespace cimage
// {
 template<class T> TImage<T> operator + ( const TImage<T>& ImageA, const TImage<T>& ImageB ) { return TImage<T> ( ImageA ) +=ImageB; }
 template<class T> TImage<T> operator - ( const TImage<T>& ImageA, const TImage<T>& ImageB ) { return TImage<T> ( ImageA ) -=ImageB; }
 template<class T> TImage<T> operator * ( const TImage<T>& ImageA, const TImage<T>& ImageB ) { return TImage<T> ( ImageA ) *=ImageB; }
 template<class T> TImage<T> operator / ( const TImage<T>& ImageA, const TImage<T>& ImageB ) { return TImage<T> ( ImageA ) /=ImageB; }

 template<class T, class F> TImage<T> operator * ( const TImage<T>& Image, const F Factor ) { return TImage<T> ( Image ) *=Factor; }
 template<class T, class F> TImage<T> operator * ( const F Factor, const TImage<T>& Image ) { return TImage<T> ( Image ) *=Factor; }
// } // namespace cimage

#endif
