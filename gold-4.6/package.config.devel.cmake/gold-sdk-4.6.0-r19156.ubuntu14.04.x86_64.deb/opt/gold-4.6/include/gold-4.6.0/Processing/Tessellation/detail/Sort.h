#ifndef _SORT_HXX
#define _SORT_HXX

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file Sort.hxx
 * @author Mirko Felisa (felisa@vislab.it)
 * @date 2012-04-16
 */

#include<boost/thread/thread.hpp>
#include <algorithm>

namespace tessellation
{

    namespace detail
    {

        template<typename T>
        bool cmp_x(const T a, const T b)
        {
            return (a->x < b->x || ((a->x == b->x) && (a->y < b->y)));
        }
        template<typename T>
        bool cmp_y(const T a, const T b)
        {
            return (a->y < b->y || ((a->y == b->y) && (a->x < b->x)));
        }


        template<typename T>
        void xy_alternate_sort(T it, T end, int thread);
        template<typename T>
        void yx_alternate_sort(T it, T end, int thread)
        {
            typedef typename std::iterator_traits<T>::value_type value_type;
            int halfsize = (end - it) / 2;
            if(halfsize == 1)
            {
                std::sort(it, end, cmp_x<value_type>);
                return;
            }
            std::nth_element(it, it + halfsize, end, cmp_y<value_type>);
            thread >>= 1;
            if(thread > 0)
            {
                boost::thread left(boost::bind(&xy_alternate_sort<T>, it, it + halfsize, thread));
                boost::thread right(boost::bind(&xy_alternate_sort<T>, it + halfsize, end, thread));
                left.join();
                right.join();
            }
            else
            {
                xy_alternate_sort(it, it + halfsize, thread);
                xy_alternate_sort(it + halfsize, end, thread);
            }
        }

        template<typename T>
        void xy_alternate_sort(T it, T end, int thread)
        {
            typedef typename std::iterator_traits<T>::value_type value_type;
            int halfsize = (end - it) / 2;
            if(halfsize == 1)
            {
                std::sort(it, end, cmp_x<value_type>);
                return;
            }
            std::nth_element(it, it + halfsize, end, cmp_x<value_type>);
            thread >>= 1;
            if(thread > 0)
            {
                boost::thread left(boost::bind(&yx_alternate_sort<T>, it, it + halfsize, thread));
                boost::thread right(boost::bind(&yx_alternate_sort<T>, it + halfsize, end, thread));
                left.join();
                right.join();

            }
            else
            {
                yx_alternate_sort(it, it + halfsize, thread);
                yx_alternate_sort(it + halfsize, end, thread);
            }
        }

    }
}

#endif
