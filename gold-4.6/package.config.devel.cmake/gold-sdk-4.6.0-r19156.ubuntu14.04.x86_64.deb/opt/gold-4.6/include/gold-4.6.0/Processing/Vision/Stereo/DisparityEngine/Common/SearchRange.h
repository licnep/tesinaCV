#ifndef _SEARCH_RANGE_H
#define _SEARCH_RANGE_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2007                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file search_range.h
 * \author Paolo Zani (zani@ce.unipr.it)
 * \date 2007-01-13
 */

#include <utility>

#include <stdint.h>

namespace disparity
{
    typedef std::pair<int32_t, int32_t> SearchRange;
}

#endif
