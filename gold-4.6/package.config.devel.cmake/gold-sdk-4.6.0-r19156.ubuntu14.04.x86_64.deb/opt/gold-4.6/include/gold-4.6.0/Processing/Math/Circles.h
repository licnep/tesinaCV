/** @file circles.h
  * @author Paolo Medici
  * @brief Opearazioni sui cerchi
  **/
#ifndef _CIRCLES_REGRESSION_H
#define _CIRCLES_REGRESSION_H

#include <Processing/Math/gold_proc_math_export.h>
#include <Data/Math/circles.h>
#include <Data/Math/Points.h>

namespace math {

}

#endif
