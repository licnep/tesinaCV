#ifndef _DISPARITYENGINE_OPT_SGM_H
#define _DISPARITYENGINE_OPT_SGM_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file Definitions.h
 * \author Mirko Felisa (felisa@vislab.it), Paolo Zani (zani@vislab.it)
 * \date 2010-09-25
 */

#include <Processing/Vision/Stereo/DisparityEngine/Optimization/SGM/Impl_Cpp.h>
#include <Processing/Vision/Stereo/DisparityEngine/Optimization/SGM/Impl_SIMD.h>

namespace disparity
{
    namespace opt
    {
        template<typename ResultType_Agg, uint32_t Threads_Agg, typename ResultType_Opt, uint32_t Threads_Opt>
        class SGM<ResultType_Agg, Threads_Agg, ResultType_Opt, impl::Auto, Threads_Opt> : public SGM<ResultType_Agg, Threads_Agg, ResultType_Opt, impl::Cpp, Threads_Opt> {};

#if (defined  __SSSE3__  && defined __x86_64)         
        template< uint32_t Threads_Agg,  uint32_t Threads_Opt>
        class SGM< uint8_t, Threads_Agg, uint8_t, impl::Auto, Threads_Opt> : public SGM<uint8_t, Threads_Agg, uint8_t, impl::SIMD, Threads_Opt> {};
#endif
    }
}

#endif
