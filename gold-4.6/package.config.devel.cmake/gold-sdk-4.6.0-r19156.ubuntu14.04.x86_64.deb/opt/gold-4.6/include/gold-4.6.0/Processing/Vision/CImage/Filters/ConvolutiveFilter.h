#ifndef _CONVOLUTIVE_FILTER_H
#define _CONVOLUTIVE_FILTER_H

#include <Processing/Vision/CImage/Filters/TLocalFilter.h>
#include <Processing/Vision/CImage/Filters/FilterModifier.h>

/** @file ConvolutiveFilter.h
  * @brief implements filters able to apply a generic convolution on a image
  **/

namespace cimage {
 
namespace kernel {  
  
/**
 * \brief Implementa il calcolo di filtro convolutivo
 * \code
 * // alloco un filtro 5x5
 * TLocalFilter< Convolution<float> > filter(5,5);
 * // ritorno il kernel
 * float *kernel = filter.GetKernel();
 * // lo riempio con i pesi
 * // lo applico sull'immagine
 * filter(CImageSrc, CImageDst);
 * \endcode
*/
template<class T>
class Convolutive {
	/// filter size
	int w, h;
	/// filter coefficients
	T *f;
	
	public:
	Convolutive() : w(0), h(0),f(0)	{
	}

	Convolutive(const Convolutive & src) : w(src.w), h(src.h), f(0)	{ 
	  if(src.w * src.h != 0)
	    {
	    f = new T[src.w * src.h];
	    for(int i =0;i<w*h;++i) f[i] = src.f[i];
	    }
	} 
	
	Convolutive(int _w, int _h) : w(_w), h(_h) {
	    f = new T [w*h];
	}
	Convolutive(int _w, int _h, const T *_f) : w(_w), h(_h) {
	    f = new T [w*h];
	    for(int i =0;i<w*h;++i) f[i] = _f[i];
	}

	~Convolutive() {
	delete [] f;
	}

	/** Change the filter size **/
	void SetGeometry(int _w, int _h)
	{
	delete [] f;
	w = _w;
	h = _h;
	f = new T [w*h];
	}

	/** Change the kernel **/
	void SetKernel(const T *_f)
	{
	for(int i =0;i<w*h;++i) f[i] = _f[i];
	}

	/** Change the kernel **/
	void SetKernel(int _w, int _h, const T *_f)
	{
	delete [] f;
	w = _w;
	h = _h;
	f = new T [w*h];
        for(int i =0;i<w*h;++i) f[i] = _f[i];
	}
	
	/** normalize the kernel to 1.0f */
	void Normalize()
	{
	  T sum = 0.0f;
	  for(int i =0;i<w*h;++i) sum += f[i];
	  for(int i =0;i<w*h;++i) f[i] /= sum;
	}
	
	/** return a pointer to kernel */
	T *GetKernel() { return f; }

	template<class D>
   	inline D zero() const { return D(0); }

   	inline uint32_t GetWidth() const { return w; }
   	inline uint32_t GetHeight() const { return h; }


   	template<typename S>
   	inline S operator() ( const S* I, long stride ) const
    	{
// 	 PixelTraits<S>::AccumulatoreFloat acc;
	 T acc = T();
	 
/*	 S = TRGB<X> -> TRGB<T>
	 S -> T
	 */
	 
// 	 ConvolutiveTraits<S, T> acc;
	 I += -(w/2) - (h/2) * stride; // Move To TOP-LEFT
	 for (int32_t j = 0; j < h; j++)
                for (int32_t i = 0; i < w; i++)
			acc +=  T(I[j*stride + i]) * f[i + j * w]; // acc.Add( I[j*stride + i], f[i + j * w] );
	 return S(acc);
    	}
};

}

//
namespace filter {
  /** Create a Convolutive filter of float
   * \code
   * ConvolutiveFilter filter;
   * float coef[5*5] = { ... };
   * filter.SetKernel(5,5, coefs);
   * filter(input,output);
   * \endcode
   */
  typedef TLocalFilter< kernel::Convolutive<float> > ConvolutiveFilter;
};

}

#endif
