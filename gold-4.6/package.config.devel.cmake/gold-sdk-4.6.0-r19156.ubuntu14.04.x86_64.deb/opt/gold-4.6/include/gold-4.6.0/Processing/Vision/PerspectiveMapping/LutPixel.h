/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2007                  *
 *                                                                    *
 *       http://www.vislab.it                                        *
 *                                                                    *
 *  Author: Carletti Marcello (April 2003)                            *
 *          Medici Paolo (October 2004 - )                            *
 **********************************************************************/

#ifndef _LUT_PIXEL_H
#define _LUT_PIXEL_H

/** @file LutPixel.h
  * @brief Strutture per permettere l'uso di template per l'interpolazione dei punti
  * @note Sono usate internamente da ImageLUT. Per usare queste classi includere LutPixel.hxx
  **/

#include <Processing/Vision/PerspectiveMapping/gold_proc_pm_export.h>

#define IMGLUT_UNDEFINED -1

/// Class/Structure holding the position of a pixel
///  it is used by nearest mapping and used also to store on disk the data
struct GOLD_PROC_PM_EXPORT PixelPos {
    int col, row;

/// this element is well defined?
    inline bool IsDefined(void) const
      {
      return row!=IMGLUT_UNDEFINED;
      }

/// set the lut element (in this case xs and ys are rounded to col,row)
    void set(double xs, double ys, unsigned int width, unsigned int height);

/** apply the lut element
  * @param dst output array
  * @param src input array
  * @param stride offset beetween two input lines
  **/
    template<unsigned int byte_per_pixel, typename C>
    C * apply(C * dst, const C * src, long stride) const;
};

/// container per il singolo pixel che interpola bilinearmente
struct GOLD_PROC_PM_EXPORT BilinearPixel {
    int span;      ///< span inside image
    float k[4];    ///< pixel weight (pesi dei 4 pixel. 8bytes in piu per risparmiare su 4 moltiplicazioni)

/// this element is well defined?
    inline bool IsDefined(void) const
      {
      return span!=IMGLUT_UNDEFINED;
      }

/// set the lut element (span is calculated and weights k[0..3] are initialized)
    void set(double xs, double ys, unsigned int width, unsigned int height);

    template<unsigned int byte_per_pixel, typename C>
    C * apply(C * dst, const C * src, long stride) const;
};

/// Container per il singolo pixel che interpola bilinearmente in FixedPoint 8bit
struct GOLD_PROC_PM_EXPORT FPBilinearPixel {
    int span;              ///< span inside image
    unsigned char k[4];    ///< pixel weight (pesi dei 4 pixel in fixedpoint) 0..255

/// this element is well defined?
    inline bool IsDefined(void) const
      {
      return span!=IMGLUT_UNDEFINED;
      }

/// set the lut element (span is calculated and weights k[0..3] are initialized)
    void set(double xs, double ys, unsigned int width, unsigned int height);

    template<unsigned int byte_per_pixel, typename C>
    C * apply(C * dst, const C * src, long stride) const;
};

#endif
