#ifndef _AVERAGEFILTER_H
#define _AVERAGEFILTER_H

#include <stdexcept>
#include <stdint.h>
#include <Data/CImage/PixelTraits/PixelTraits.h>
#include <Processing/Vision/CImage/Filters/TLocalFilter.h>
#include <Processing/Vision/CImage/Filters/FilterModifier.h>
#include "BaseFilter.h"

/** @file AverageFilter.h
  * @brief filtri che lavorano sul valor medio di una finestra dell'immagine 
  * @todo implementare la versione ottimizzata
  */

namespace cimage {

namespace kernel { 
  
/** \brief Filtro che ritorna la somma dei pixel nella finestra
  * @warning questo filtro e' dal punto di vista computazionale INEFFICIENTE per finestre grandi.
  *          Usare le funzioni ad hoc per somma e media di blocchi larghi di pixel, fino a che non verra' implementato un AreaOperator
  **/
template<typename SizePolicy>
class SumFilter: public SizePolicy, public filter::ImplPixelOperator
    {
    public:
    // do not change sign
    static const bool positive = true;
    public:

	template<class D>
        inline D zero() const { return 0; }
	template<class S>
        inline typename cimage::PixelTraits<S>::CumulativeType operator()(const S* inputPixel, long stride) const
        {
            typename cimage::PixelTraits<S>::CumulativeType comp = 0;
            
            const int32_t win_w = SizePolicy::GetWidth();
            const int32_t win_h =  SizePolicy::GetHeight();
            for (int32_t j = - win_h / 2; j <= (win_h - 1) / 2; j++)
            {
                const S* pixel_row = inputPixel + stride * j;
                for (int32_t i= -win_w / 2; i <= (win_w - 1) / 2; i++)
                  comp += pixel_row[i];
            }
            return comp;
        }
  };

/** \brief Filtro che ritorna la media dei pixel nella finestra
  * @warning questo filtro e' dal punto di vista computazionale INEFFICIENTE per finestre grandi.
  *          Usare le funzioni ad hoc per somma e media di blocchi larghi di pixel
  **/
template<typename SizePolicy>
struct AverageFilter : public SumFilter<SizePolicy>, public filter::ImplPixelOperator
{
    // do not alter energy  
    static const unsigned int magnitude = 1;    
  
	public:
	template<class S>
        inline S operator()(const S* inputPixel, long stride) const
        {//casto ad int perché int/uint è uint e in caso di valori negativi è sbagliato
	return SumFilter<SizePolicy>::operator()(inputPixel, stride) / (int32_t)(SizePolicy::GetWidth()*SizePolicy::GetHeight());
	}
};


/** \brief filtro bilineare
 * Filtro non-lineare in grado di effettuare uno smoothing dell'immagine senza attenuare i contorni 
 * \code
 * TLocalFilter< kernel::BilateralFilter<policy::FixedSize<3,3> > > filter;
 * filter.SetSigmaVal(16.0f);
 * filter.SetSigmaPos(16.0f);
 * filter.SetKernelStep(1);
 * filter(m_inputImageMono, m_outputImageMono);
 * \endcode
 * @note unimplemented 
 */
template<typename SizePolicy>
struct BilateralFilter : public SizePolicy, public filter::ImplPixelOperator
{
  
  float m_valSquareSigma;
  float m_posSquareSigma;
  int m_stepInKernel;
  
  public:
    
    template<class S>
    inline S operator()(const S* inputPixel, long stride) const
    {
        return S(0); ///TODO: da implementare
    }
    
    //Square of the sigma for differences of pixel values
    void  SetSigmaVal(float s)
    {
        m_valSquareSigma = s; 
    }
    
    //Square of the sigma for pixel positions
    void  SetSigmaPos(float s)
    {
        m_posSquareSigma = s; 
    }
    
    //Processing step in the filter kernel
    void  SetKernelStep(int s)
    {
        m_stepInKernel = s; 
    }
    
    float GetSigmaVal() const {return m_valSquareSigma; }
    float GetSigmaPos() const {return m_posSquareSigma; }
    int  GetKernelStep() const {return m_stepInKernel; }
};

} // namespace kernel

// implementation
#include <Processing/Vision/CImage/Filters/AverageFilter.hxx>

namespace filter { 
  
  /// Filtro passa basso 
  /// @note filter::Average e' piu' veloce
  typedef TLocalFilter< kernel::AverageFilter< policy::VariableSize > > AverageFilter;
  /// Filtro passa basso con soglia
  /// @note filter::AverageBin e' piu' veloce
  typedef TLocalFilter< filter::Bin < kernel::AverageFilter< policy::VariableSize > > > AverageFilterBin;
  ///Filtro Bilaterale
  typedef TLocalFilter< kernel::BilateralFilter< policy::VariableSize  > > BilateralFilter;

  /** @brief an iterative low pass filter
 * Calcola la media in un intorno di BLOCK_WIDTH x BLOCK_HEIGHT pixel
 * 
 *  Abbastanza ottimizzata, e usa lo stesso principio di AverageBin
 * @param out immagine di output
 * @param src immagine sorgente
 * @param width,height              dimensione dei buffer
 * @param BLOCK_WIDTH,BLOCK_HEIGHT  dimensione del blocco
 *
 * \code
 * filter::Average(buffer_src, buffer_dst, width, height, 16, 16);
 * \endcode
 **/
 template<class D, class S>
 void Average(const S * src, unsigned char * out, unsigned int width, unsigned int height, unsigned int BLOCK_WIDTH, unsigned int BLOCK_HEIGHT);

/** Una espansione (binarizzazione) dell'immagine altamente ottimizzata
 *
 *   Accende il pixel centrale del blocco BLOCK_WIDTH x BLOCK_HEIGHT se il valor medio dei pixel src al suo 
 *    interno e' maggiore di threshold.
 * 
 * @param out immagine di output
 * @param src immagine sorgente
 * @param width,height              dimensione dei buffer
 * @param BLOCK_WIDTH,BLOCK_HEIGHT  dimensione del blocco
 * @param threshold soglia di binarizzazione
 * \code
 * filter::AverageBin(buffer_src, buffer_dst, width, height, 16, 16);
 * \endcode
 **/
template<bool extra_boundaries, class S, class D>
void AverageBin(const S * src, unsigned char * out, unsigned int width, unsigned int height, unsigned int BLOCK_WIDTH, unsigned int BLOCK_HEIGHT, unsigned int threshold);
 

/// @brief Calcola il valor medio che assume una sottoparte dell'immagine
/// calcola la media all'interno di un area, pixel in alto a sinistra in @a ptr
/// @param ptr puntatore al primo pixel da cui comincia il blocco
/// @param pitch numero di pixel per passare alla linea successiva
/// @param blockw numero di pixel orizzontali
/// @param blockh numero di pixel verticali
template<class T>
float AvgArea (const T * ptr, long pitch, unsigned int blockw, unsigned int blockh)
{
unsigned long sum = SumArea(ptr, pitch, blockw, blockh);
return float(sum)/float(blockw * blockh);
}

/// statistic reporter by ExtractStatsArea
struct block_stat_info {
  /// average
  float avg;
  /// variance
  float var;
  /// contrast factor
  float ctx;
};

/** Estrae da un blocco tutte le statistiche in un solo passaggio
 * @param src puntatore al primo pixel del blocco
 * @param stride stride in T
 * @param bw     block width
 * @param bh     block height
 **/
template<class T>
void ExtractStatsArea (block_stat_info *stat, const T * src, long stride, unsigned int bw, unsigned int bh);

////////////////////////////////////// implementation //////////////////////////////////////////////

template<class T>
void ExtractStatsArea (block_stat_info *stat, const T * src, long stride, unsigned int bw, unsigned int bh)
{
unsigned int v,v2;
unsigned char mx,mn;
float favg;
v = v2 = 0;
mx = 0;
mn = 255;

for(unsigned int j=0;j<bh;j++)
 {
 for(unsigned int i =0;i<bw;i++)
    {
    v += src[i];
    v2 += src[i] * src[i];
    if(src[i]<mn) mn = src[i];
    if(src[i]>mx) mx = src[i];
    }
 src+=stride;
 }
favg = float(v) / float(bw*bh);
stat->avg = favg;
stat->var = float(v2) / float(bw*bh) - favg * favg;
stat->ctx = float(mx - mn + 1.0f ) / float(mx + mn + 1.0f);
}

// Bottom Boundaries: TODO: scegliere dalla chiamata se aggiungere o meno
// il top e/o il bottom (in alcuni algoritmi potrebbero anche non servire)
template<bool extra_boundaries, class S>
void AverageBin(const S * src, unsigned char * out, unsigned int width, unsigned int height, unsigned int BLOCK_WIDTH, unsigned int BLOCK_HEIGHT, unsigned int threshold)
{
  int j;
  unsigned long bt = threshold * BLOCK_WIDTH * BLOCK_HEIGHT;
  unsigned long sum, sum0;
  const unsigned int left_bnd = BLOCK_WIDTH / 2;
  const unsigned int right_bnd = BLOCK_WIDTH - left_bnd;
  
  if ((BLOCK_WIDTH<=1)||(BLOCK_HEIGHT<=1))
    throw std::runtime_error("AverageBin called with INVALID argument(s)");

  // padding
  for(int i = 0;i<left_bnd;++i)
      out[i] = 0;
  
  out += left_bnd;

  if(extra_boundaries)
  {
  // TOP
  for(j = 0; j<(int)(BLOCK_HEIGHT/2) ; j++)
   {
   unsigned int h = j + (BLOCK_HEIGHT/2);
   sum = SumArea(src, width, BLOCK_WIDTH, h);
   
   bt = threshold * BLOCK_WIDTH * h;
 
   out[0] = (sum>bt) ? 255 : 0;
   
   // questo codice riempie da BLOCK_WIDTH/2 a width-BLOCK_WIDTH/2
   for(unsigned int i = 1;i+BLOCK_WIDTH<width;i++)
    {
    sum = SumAreaNext(src + i, width, BLOCK_WIDTH, h, sum);
    out[i] = (sum>bt) ? 255 : 0;
    }
   
   memset(out + width - right_bnd, 0, right_bnd);   // padding
   out += width;
   }
  }
  else
  {

  // faccio puntare a out al primo byte che deve essere scritto
  out += (BLOCK_HEIGHT/2) * width;
  }  
  
  bt = threshold * BLOCK_WIDTH * BLOCK_HEIGHT;

  sum0 = SumArea(src, width, BLOCK_WIDTH, BLOCK_HEIGHT);

  // questo codice riempie da BLOCK_HEIGHT/2 a height-BLOCK_HEIGHT/2
  for(j=0;j<int(height-BLOCK_HEIGHT);j++)
   {
   sum = sum0;
   out[0] = (sum>bt) ? 255 : 0;
   
   // questo codice riempie da BLOCK_WIDTH/2 a width-BLOCK_WIDTH/2
   for(unsigned int i = 1;i+BLOCK_WIDTH<width;i++)
    {
    sum = SumAreaNext(src + i, width, BLOCK_WIDTH, BLOCK_HEIGHT, sum);
    out[i] = (sum>bt) ? 255 : 0;
    }

   sum0 = SumAreaVNext(src, width, BLOCK_WIDTH, BLOCK_HEIGHT, sum0);
   
   memset(out + width - BLOCK_WIDTH, 0, BLOCK_WIDTH);   // padding
   out += width;
   src += width;
   }
 
  if(extra_boundaries)
  {
  for(j = height-BLOCK_HEIGHT; j+(BLOCK_HEIGHT/2)<height ; j++)
   {
   memset(out - BLOCK_WIDTH / 2, 0, BLOCK_WIDTH/2);   // padding

   unsigned int h = height - j;
   unsigned long sum = SumArea(src, width, BLOCK_WIDTH, h);
   
   bt = threshold * BLOCK_WIDTH * h;
 
   out[0] = (sum>bt) ? 255 : 0;
   
   // questo codice riempie da BLOCK_WIDTH/2 a width-BLOCK_WIDTH/2
   for(unsigned int i = 1;i+BLOCK_WIDTH<width;i++)
    {
    sum = SumAreaNext(src + i, width, BLOCK_WIDTH, h, sum);
    out[i] = (sum>bt) ? 255 : 0;
    }
   
   memset(out + width - BLOCK_WIDTH , 0, right_bnd);   // padding
   out += width;
   src += width;
   }
  }

}

template<class D, class S>
void Average(const S * src, D * out, unsigned int width, unsigned int height, unsigned int BLOCK_WIDTH, unsigned int BLOCK_HEIGHT)
{
  int j;
  // 16 bit fixed point
  unsigned int bt = 65536 / (BLOCK_WIDTH * BLOCK_HEIGHT);
  
  if ((BLOCK_WIDTH<=1)||(BLOCK_HEIGHT<=1))
    throw std::runtime_error("Average called with INVALID argument(s)\n");
  
  out += (BLOCK_WIDTH/2) + (BLOCK_HEIGHT/2) * width;
  
  for(j=0;j<int(height-BLOCK_HEIGHT);j++)
   {
   unsigned long sum = SumArea(src, width, BLOCK_WIDTH, BLOCK_HEIGHT);
   
   out[0] = (sum * bt)>>16;
   
   for(unsigned int i = 1;(i+BLOCK_WIDTH)<width;i++)
    {
    sum = SumAreaNext(src + i, width, BLOCK_WIDTH, BLOCK_HEIGHT, sum);
    out[i] = (sum * bt)>>16;
    }
   
   out += width;
   src += width;
   }
}
  
} // namespace filter

} // namespace cimage

#endif
