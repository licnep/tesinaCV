/** @file RegressionMath.h
  * @author Paolo Medici
  * @brief funzioni di regressione lineare a rette e quadriche
  **/

#ifndef _MATH_REGRESSION_H
#define _MATH_REGRESSION_H

#include <Processing/Math/gold_proc_math_export.h>
#include <Data/Math/Lines.h>
#include <Data/Math/Circles.h>
#include <Data/Math/Quadratics.h>

#include <stdexcept>

namespace math {

/** regressione ai minimi quadrati (scarti tra i punti e la retta verticali)
 *  @param out una struttura Line3<R> che contiene i parametri cercati della retta
 *  @param in un vettore di T (devono avere i membri x e y)
 *  @param size numero di elementi del vettore in (almeno 2 punti)
 *  @see vertical_least_squares_fitting_i_ex che ritorna l'errore (somma degli scarti quadratici)
 **/
template<class R, class T>
void GOLD_PROC_MATH_DEPRECATED vertical_least_squares_fitting(Line3<R> *out, const T * in, unsigned int size)
{
    R sx, sy, sxy, sx2;

    sx = sy = sxy = sx2 = R(0);

    for (unsigned int i=0;i<size;i++)
    {
        sx += (R) in[i].x;
        sy += (R) in[i].y;
        sxy += (R) in[i].x * in[i].y;
        sx2 += (R) in[i].x * in[i].x;
    }

    out->a = static_cast<R>(size) * sxy - sx * sy;
    out->b = sx * sx- size * sx2;
    out->c = sx2 * sy - sx * sxy;
}

/** @brief regressione ai minimi quadrati (scarti tra i punti e la retta in verticale, lungo la direzione y)
 *  @param out una struttura Line3<R> che contiene i parametri cercati della retta
 *  @param first an input iterator
 *  @param last  an input iterator
 *  @see vertical_least_squares_fitting_i_ex che ritorna l'errore (somma degli scarti quadratici)
 **/
template<class R, class InputIterator>
void GOLD_PROC_MATH_DEPRECATED vertical_least_squares_fitting(Line3<R> *out, InputIterator __first, InputIterator __last)
{
    R sx, sy, sxy, sx2;
    int size=0;

    sx = sy = sxy = sx2 = R(0);

    for (; __first != __last; ++__first)
    {
        sx += (R) (*__first).x;
        sy += (R) (*__first).y;
        sxy += (R) (*__first).x * (*__first).y;
        sx2 += (R) (*__first).x * (*__first).x;
        size++;
    }

    out->a = static_cast<R>(size) * sxy - sx * sy;
    out->b = sx * sx- size * sx2;
    out->c = sx2 * sy - sx * sxy;
}


/** regressione ai minimi quadrati (scarti tra i punti e la parabola verticali)
 *  @param out una struttura Quadratic<R> che contiene i parametri cercati della parabola
 *  @param in un vettore di T (devono avere i membri x e y)
 *  @param size numero di elementi del vettore in (almeno 3 punti)
 *  @note vertical_least_squares_fitting_i_ex che ritorna l'errore (somma degli scarti quadratici) non e' implementata per la parabola ancora
 **/
template<typename R, typename T>
bool GOLD_PROC_MATH_DEPRECATED vertical_least_squares_fitting(Quadratic<R> *out, const T * in, unsigned int size)
{
    R m0,m1,m2,m3,m4;
    R y0,y1,y2;
    R w;

    m0 = size;
    m1=m2=m3=m4= y0=y1=y2=R(0);

    for (unsigned int i=0;i<size;i++)
    {
        y0 += (R) in[i].y;

        m1 += (R) in[i].x;
        y1 += (R) in[i].x * in[i].y;

        m2 += (R) in[i].x * in[i].x;
        y2 += (R) in[i].x * in[i].x * in[i].y;

        m3 += (R) in[i].x * in[i].x * in[i].x;
        m4 += (R) in[i].x * in[i].x * in[i].x * in[i].x;
    }

    w = - m1*m1*m4 - m2*m2*m2 - m3*m3*m0 + m0*m2*m4 + 2*m1*m2*m3;
    if (w==R(0))
        return false;
    out->c = ( m2*m4*y0 -m3*m3*y0 +m2*m3*y1 -m1*m4*y1 -m2*m2*y2 +m1*m3*y2) / w;
    out->b = (-m1*m4*y0 +m2*m3*y0 -m2*m2*y1 +m0*m4*y1 -m0*m3*y2 +m1*m2*y2) / w;
    out->a = (-m2*m2*y0 +m1*m3*y0 -m0*m3*y1 +m1*m2*y1 -m1*m1*y2 +m0*m2*y2) / w;
    return true;
}

/** regressione ai minimi quadrati (scarti tra i punti e la parabola verticali)
 *  @param out una struttura Quadratic<R> che contiene i parametri cercati della parabola
 *  @param in un vettore di T (devono avere i membri x e y)
 *  @param size numero di elementi del vettore in (almeno 3 punti)
 *  @note vertical_least_squares_fitting_i_ex che ritorna l'errore (somma degli scarti quadratici) non e' implementata per la parabola ancora
 **/
template<typename T>
Quadratic<double> quadratic_vertical_least_squares_fitting(const T * in, unsigned int size)
{
    typedef double R;
    Quadratic<R> out;
    R m0,m1,m2,m3,m4;
    R y0,y1,y2;
    R w;

    m0 = size;
    m1=m2=m3=m4= y0=y1=y2=R(0);

    for (unsigned int i=0;i<size;i++)
    {
        y0 += (R) in[i].y;

        m1 += (R) in[i].x;
        y1 += (R) in[i].x * in[i].y;

        m2 += (R) in[i].x * in[i].x;
        y2 += (R) in[i].x * in[i].x * in[i].y;

        m3 += (R) in[i].x * in[i].x * in[i].x;
        m4 += (R) in[i].x * in[i].x * in[i].x * in[i].x;
    }

    w = - m1*m1*m4 - m2*m2*m2 - m3*m3*m0 + m0*m2*m4 + 2*m1*m2*m3;
    if (w==R(0))
    {
        throw std::runtime_error("quadratic_vertical_least_squares_fitting singularity");
    }
    out.c = ( m2*m4*y0 -m3*m3*y0 +m2*m3*y1 -m1*m4*y1 -m2*m2*y2 +m1*m3*y2) / w;
    out.b = (-m1*m4*y0 +m2*m3*y0 -m2*m2*y1 +m0*m4*y1 -m0*m3*y2 +m1*m2*y2) / w;
    out.a = (-m2*m2*y0 +m1*m3*y0 -m0*m3*y1 +m1*m2*y1 -m1*m1*y2 +m0*m2*y2) / w;
    return out;
}


/** regressione ai minimi quadrati di una linea (Line3d)
 *  @param in un vettore di T (devono avere i membri x e y)
 *  @param size numero di elementi del vettore in
 *  @return una struttura Line3d che contiene i parametri della retta
 *  @see vertical_least_squares_fitting_i_ex che ritorna l'errore
 *  \code
 *   Point2d * v = new Point2d[100];
 *   Line3d r = vertical_least_squares_fitting(v, 100);
 *  \endcode
 **/
template<class T>
Line3d vertical_least_squares_fitting(const T * in, unsigned int size)
{
    typedef double R;
    Line3<R> out;
    R sx, sy, sxy, sx2;

    sx = sy = sxy = sx2 = R(0);

    for (unsigned int i=0;i<size;i++)
    {
        sx += (R) in[i].x;
        sy += (R) in[i].y;
        sxy += (R) in[i].x * in[i].y;
        sx2 += (R) in[i].x * in[i].x;
    }

    out.a = static_cast<R>(size) * sxy - sx * sy;
    out.b = sx * sx- size * sx2;
    out.c = sx2 * sy - sx * sxy;
    return out;
}

/** regressione ai minimi quadrati di una linea (Line3d)
 *  @param first an input iterator (devono avere i membri x e y)
 *  @param last  an input iterator
 *  @return una struttura Line3d che contiene i parametri della retta
 *  @see vertical_least_squares_fitting_i_ex che ritorna l'errore
 *  \code
 *  std::vector< Point2d > test;
 *  Line3d r = vertical_least_squares_fitting(test.begin(), test.end());
 *  \endcode
 **/
template<class InputIterator>
Line3d vertical_least_squares_fitting(InputIterator __first, InputIterator __last)
{
    typedef double R;
    Line3<R> out;
    R sx, sy, sxy, sx2;
    int size=0;

    sx = sy = sxy = sx2 = R(0);

    for (; __first != __last; ++__first)
    {
        sx += (R) (*__first).x;
        sy += (R) (*__first).y;
        sxy += (R) (*__first).x * (*__first).y;
        sx2 += (R) (*__first).x * (*__first).x;
        size++;
    }

    out.a = static_cast<R>(size) * sxy - sx * sy;
    out.b = sx * sx- size * sx2;
    out.c = sx2 * sy - sx * sxy;
    return out;
}

/** regressione ai minimi quadrati (utilizzando la versione di Kenney e Keeping) per una linea
 *
 * Come vertical_least_squares_fitting ma ritorna anche lo scarto quadratico medio (\f$ s^2 \f$)
 *  definito come
 *  \f$ s^2= \sum_{i=1}^{n} (e_i^2)/(n-2) \f$ dove \f$ e_i = y_i - \tilde{y}_i \f$.
 *
 *  @param out una struttura Line3d che contiene i parametri della retta
 *  @param in un vettore di T
 *  @param size numero di elementi del vettore in
 *  @return ritorna lo scarto quadratico medio (varianza al quadrato) dei punti rispetto alla retta riportata.
 *  @note e' piu lenta della vertical_least_squares_fitting pero' se e' richiesto l'errore e' la versione preferibile
 **/
template<class R, class T>
R vertical_least_squares_fitting_i_ex(Line3<R> *out, const T * in, unsigned int size)
{
    R sx, sy, sxy, sx2, sy2;
    R ssxx, ssyy, ssxy;
    R s2;
    sx = sy = sxy = sx2 = sy2 = R(0);

    for (unsigned int i=0;i<size;i++)
    {
        sx += (R) in[i].x;
        sy += (R) in[i].y;

        sxy += (R) in[i].x * in[i].y;

        sx2 += (R) in[i].x * in[i].x;
        sy2 += (R) in[i].y * in[i].y; // serve per lo scarto
    }

    ssxx = sx2 - sx * sx / static_cast<R> (size);
    ssyy = sy2 - sy * sy / static_cast<R> (size);
    ssxy = sxy - sx * sy / static_cast<R> (size);

    out->a = size * ssxy;
    out->b = -static_cast<R> (size) * ssxx;
    out->c = sy * ssxx - sx * ssxy;

    s2 = (ssyy - ssxy * ssxy / ssxx) / (static_cast<R> (size) - 2.0);

    return s2;
}

/** regressione ai minimi quadrati (scarti tra i punti e la retta orizzontali)
 *  @param out una struttura Line3d che contiene i parametri della retta
 *  @param in un vettore di T (deve avere coppie x,y)
 *  @param size numero di elementi del vettore in
 **/
template<class R, class T>
void GOLD_PROC_MATH_DEPRECATED horizontal_least_squares_fitting(Line3<R> *out, const T * in, unsigned int size)
{
    R sy, sx, syx, sy2;

    sy = sx = syx = sy2 = 0.0;

    for (unsigned int i=0;i<size;i++)
    {
        sy += (R) in[i].y;
        sx += (R) in[i].x;
        syx += (R) in[i].y * in[i].x;
        sy2 += (R) in[i].y * in[i].y;
    }

    out->a = sy * sy - size * sy2;
    out->b = size * syx - sy * sx;
    out->c = sy2 * sx - sy * syx;
}

/** regressione ai minimi quadrati (scarti tra i punti e la retta orizzontali)
 *  @param in un vettore di T (deve avere coppie x,y)
 *  @param size numero di elementi del vettore in
 *  @return una struttura Line3<T> che contiene i parametri della retta
 **/
template<class T>
Line3d horizontal_least_squares_fitting(const T * in, unsigned int size)
{
    typedef double R;
    R sy, sx, syx, sy2;

    sy = sx = syx = sy2 = R(0);

    for (unsigned int i=0;i<size;i++)
    {
        sy += (R) in[i].y;
        sx += (R) in[i].x;
        syx += (R) in[i].y * in[i].x;
        sy2 += (R) in[i].y * in[i].y;
    }

    return Line3<R>( sy * sy - size * sy2,
                     size * syx - sy * sx,
                     sy2 * sx - sy * syx );
}

/** regressione ai minimi quadrati (scarti tra i punti e la retta orizzontali)
 *  @param in un vettore di T (deve avere coppie x,y)
 *  @param size numero di elementi del vettore in
 *  @return una struttura Line3<T> che contiene i parametri della retta
 **/
template<class InputIterator>
Line3d horizontal_least_squares_fitting(InputIterator __first, InputIterator __last)
{
    typedef double R;
    R sy, sx, syx, sy2;
    int size = 0;
    sy = sx = syx = sy2 = R(0);

    for (; __first != __last; ++__first)
    {
        sy += (R) __first->y;
        sx += (R) __first->x;
        syx += (R) __first->y * __first->x;
        sy2 += (R) __first->y * __first->y;
        size++;
    }

    return Line3<R>( sy * sy - size * sy2,
                     size * syx - sy * sx,
                     sy2 * sx - sy * syx );
}


/** come horizontal_least_squares_fitting ma ritorna anche lo scarto quadratico medio (\f$ s^2 \f$) definito come
 * \f$ s^2 = \sum_{i=1}^{n} (e_i^2)/(n-2) \f$ dove \f$ e_i = x_i - \tilde{x}_i \f$.
 * @return scarto quadratico medio
 *  @note e' piu lenta della horizontal_least_squares_fitting pero' se e' richiesto l'errore e' la versione preferibile
 */
template<class R, class T>
R horizontal_least_squares_fitting_i_ex(Line3<R> *out, const T * in, unsigned int size)
{
    R sx, sy, sxy, sx2, sy2;
    R ssxx, ssyy, ssxy;
    R s2;
    sx = sy = sxy = sx2 = sy2 = 0.0;

    for (unsigned int i=0;i<size;i++)
    {
        sx += (R) in[i].x;
        sy += (R) in[i].y;

        sxy += (R) in[i].x * in[i].y;

        sx2 += (R) in[i].x * in[i].x;
        sy2 += (R) in[i].y * in[i].y; // serve per lo scarto
    }

    ssxx = sx2 - sx * sx / R(size);
    ssyy = sy2 - sy * sy / R(size);
    ssxy = sxy - sx * sy / R(size);

    // SG: nota geometrica. Il best-fit con gli scarti orizzontali � molto raro, e non si trovano facilmente riferimenti. Tuttavia, � del tutto analogo
    // al best-fit con scarti verticali, salvo lo scambio tra xi e yi. Per�, cos� facendo l'equazione della retta ha a sua volta le coordinate scambiate,
    // e cos� da y = a+bx diventa x = a+by (usando la notazione che si trova in http://mathworld.wolfram.com/LeastSquaresFitting.html)
    // Allora, i parametri a, b e c diventano:
    // a = -1; b = ssxy/ssyy; c = sx/n - (ssxy/ssyy)*sy/n -- n = size
    // Dopo pochi passaggi semplificativi (analoghi a quelli per il best-fit con scarti verticali) si arriva a trovare i parametri cos�:
    out->a = -R(size) * ssyy;
    out->b = R(size) * ssxy;
    out->c = sx * ssyy - sy * ssxy;

    s2 = (ssxx - ssxy * ssxy / ssyy) / (R(size) - 2.0);

    return s2;
}

/// Calculate the orthogonal (perpendicular) least square regression of a point series
/// @param out a Line3d filled in output
/// @param in a point series
/// @param size size of point series
/// @return the error (average of square error of points).
/// @note supporta T solo Point2d, Point2f, Point2i. Per strutture differenti includere RegressionMath.hxx
template<class R, class T>
GOLD_PROC_MATH_EXPORT R orthogonal_least_squares_fitting(Line3<R> & out, const T * in, unsigned int size);

template<class R, class InputIterator>
GOLD_PROC_MATH_EXPORT R orthogonal_least_squares_fitting(Line3<R> & out, InputIterator __first, InputIterator __last);

/** calcola la somma [in pixel] delle distanze (ortogonali) dei punti con la retta (espressa in coordinate polari)
  * @param line una linea espressa in coordinate polari
  * @param in un array di punti da valutare
  * @param size dimensione dell'array
  * @return la somma in pixel delle distanze
  **/
template<class T, class R>
R orthogonal_error(const PolarLine<R> & line, const T * in, unsigned int size)
{
    R e = 0.0;
    R s = std::sin(line.theta);
    R c = std::cos(line.theta);
    R r = line.rho;
    for (unsigned int i=0;i<size;i++)
        e += std::abs(in[i].x * c + in[i].y * s - r);
    return e;
}

/** calcola la somma [in pixel] delle distanze (ortogonali) dei punti con la retta (espressa in forma implicita)
  * @param line una linea espressa in forma implicita
  * @param in un array di punti da valutare
  * @param size dimensione dell'array
  * @return la somma in pixel delle distanze
  **/
template<class T, class R>
R orthogonal_error(const Line3<R> & line, const T * in, unsigned int size)
{
    R e = 0.0;
    R l = std::sqrt(line.a*line.a + line.b*line.b);
    R a = line.a / l ;
    R b = line.b / l;
    for (unsigned int i=0;i<size;i++)
        e += std::abs(in[i].x * a + in[i].y * b + line.c);
    return e;
}

/// Return centroid of point distribution
/// @note normalmente le curve ottenute da una regressione ai minimi quadrati passano per il centroide (baricentro)
template<class T>
Point2d centroid(const T * in, unsigned int size)
{
    double sx=0.0,sy=0.0;
    for (unsigned int i=0;i<size;i++)
    {
        sx += in[i].x;
        sy += in[i].y;
    }
    return Point2d( sx / (double) size, sy / (double) size );
}

/// @brief Return centroid of a bidimensional (x,y) point distribution
/// @param __first an input iterator
/// @param __last an input iterator
/// @note normalmente le curve ottenute da una regressione ai minimi quadrati passano per il centroide (baricentro)
template<class T, class InputIterator>
Point2d centroid(InputIterator __first, InputIterator __last)
{
    double sx=0.0,sy=0.0;
    int size=0;
    for (;__first!=__last;++__first)
    {
        sx += (*__first).x;
        sy += (*__first).y;
        size++;
    }
    return Point2d( sx / (double) size, sy / (double) size );
}

/// @brief Return centroid of a tridimensional (x,y,z) point distribution
/// @param __first an input iterator
/// @param __last an input iterator
/// @note normalmente le curve ottenute da una regressione ai minimi quadrati passano per il centroide (baricentro)
template<class T, class InputIterator>
Point3d centroid3(InputIterator __first, InputIterator __last)
{
    double sx=0.0,sy=0.0,sz=0.0;
    int size=0;
    for (;__first!=__last;++__first)
    {
        sx += (*__first).x;
        sy += (*__first).y;
        sz += (*__first).z;
        size++;
    }
    return Point3d( sx / (double) size, sy / (double) size, sz / (double) size );
}


/** Funzione che ricava la circonferenza minimizzando `linearmente' ai minimi quadrati del set di punti fornito in ingresso.
 *
 * Cerca lo scarto ai minimi quadrati dell'equazione \f$ A(x^2 + y^2) + Bx + Cy = 1 \f$
 * @param __first an input iterator
 * @param __last an input iterator
 * @note the linear solution is faster then non linear, but less accurate
 **/
template<class InputIterator>
Circle3d linear_circle_least_squares_fitting_linear(InputIterator __first, InputIterator __last)
{
// J e' una matrice simmetrica
    double J[6], K[3];
    for (unsigned int i=0;i<6;i++) J[i]=0.0;
    for (unsigned int i=0;i<3;i++) K[i]=0.0;

    for (;__first!=__last;++__first)
    {
        double x, y, z;
        double x2,y2;

        x = (*__first).x;
        y = (*__first).y;

        x2 = x*x;
        y2 = y*y;
        z =  x2 + y2;

        K[0] += z*x;
        K[1] += z*y;
        K[2] += z;

        J[0] += x2;
        J[1] += x*y;
        J[2] += x;
        J[3] += y2;
        J[4] += y;
        J[5] += 1.0;
    }

    double den;
    double B,C,D;
// determinante della matrice 3x3 simmetrica
    den = -J[2]*J[2]*J[3]+2*J[2]*J[1]*J[4]+J[0]*J[5]*J[3]-J[4]*J[4]*J[0]-J[1]*J[1]*J[5];

    B = -( J[4]*J[2]*K[1]-J[4]*J[4]*K[0]+J[4]*J[1]*K[2]-J[5]*J[1]*K[1]+J[5]*K[0]*J[3]-K[2]*J[2]*J[3]);
    C =  ( J[2]*J[2]*K[1]-J[2]*J[4]*K[0]-J[2]*J[1]*K[2]-J[0]*J[5]*K[1]+J[4]*J[0]*K[2]+J[1]*J[5]*K[0]);
    D = -( J[0]*K[2]*J[3]-J[0]*J[4]*K[1]+J[2]*J[1]*K[1]-K[2]*J[1]*J[1]+J[4]*J[1]*K[0]-J[2]*K[0]*J[3]);

    if (den!=0.0)
    {
        Circle3d out;
        out.x0 = - B / (2.0 * den);
        out.y0 = - C / (2.0 * den);

        double r2 = out.x0*out.x0 + out.y0*out.y0 - D/den;

        if (r2<0.0)
            throw std::runtime_error("linear_circle_least_squares_fitting_linear singularity");

        out.r = std::sqrt(r2);
        return out;
    }
    else
        throw std::runtime_error("linear_circle_least_squares_fitting_linear singularity");
}

}

#endif
