#ifndef _DISPARITYENGINE_H
#define _DISPARITYENGINE_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file DisparityEngine.h
 * \author Paolo Zani (zani@vislab.it) Mirko Felisa (felisa@vislab.it)
 * \date 2010-09-21
 */


#include <Processing/Vision/Stereo/DisparityEngine/Optimization/FilteredWTA.h>
#include <Processing/Vision/Stereo/DisparityEngine/Optimization/SGM.h>

#include <Processing/Vision/Stereo/DisparityEngine/Cost/AbsDiff.h>

#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/Window.h>
#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/Census.h>
#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/ELAS.h>


#include <platform.h>

#include <stdint.h>

namespace disparity
{
    // forward declarations, for reference only

    namespace impl
    {
        class Cpp;
        class SIMD;
        class Auto;
    }

    namespace cost
    {
        template<typename ResultType_Cost> class None;
        template<typename ResultType_Cost> class AbsDiff;
    }

    namespace agg
    {
        template<typename ResultType_Cost, typename ResultType_Agg, typename Impl_Agg, uint32_t Threads_Agg> class None;
        template<typename ResultType_Cost, typename ResultType_Agg, typename Impl_Agg, uint32_t Threads_Agg> class Window_Simple;
        template<typename ResultType_Cost, typename ResultType_Agg, typename Impl_Agg, uint32_t Threads_Agg> class Window_SemiIncremental;
        template<typename ResultType_Cost, typename ResultType_Agg, typename Impl_Agg, uint32_t Threads_Agg> class Window_Incremental;
        template<typename ResultType_Cost, typename ResultType_Agg, typename Impl_Agg, uint32_t Threads_Agg> class Census;
    }

    namespace opt
    {
        template<typename ResultType_Agg, uint32_t Threads_Agg, typename ResultType_Opt, typename Impl_Opt, uint32_t Threads_Opt> class None;
        template<typename ResultType_Agg, uint32_t Threads_Agg, typename ResultType_Opt, typename Impl_Opt, uint32_t Threads_Opt> class FilteredWTA;
        template<typename ResultType_Agg, uint32_t Threads_Agg, typename ResultType_Opt, typename Impl_Opt, uint32_t Threads_Opt> class SGM;
    }


    // the disparity engine class

    template<template<typename> class Cost, typename ResultType_Cost,
            template<typename, typename, typename, uint32_t> class Aggregation, typename ResultType_Agg, typename Impl_Agg, uint32_t Threads_Agg,
            template<typename, uint32_t, typename, typename, uint32_t> class Optimization, typename ResultType_Opt, typename Impl_Opt, uint32_t Threads_Opt>
    class TDisparityEngine;
//     {
//         public:
// 
//             TDisparityEngine();
// 
//             /**
//             *\brief Returns the Disparity Space Image
//             * @return the Disparity Space Image
//             */
//             inline CDSI GetDSI() const;
// 
//             /**
//             *\brief Returns each pixel's matching score (SAD/SAV)
//             * @return the pixel matching score
//             */
//             CScoreImage GetScores() const;
// 
//             template<typename T>
//             inline CDSI& Run(const std::pair<cimage::TImage<T>, cimage::TImage<T> >& images, const std::vector<SearchRange>& searchRanges = std::vector<SearchRange>(), const cimage::CImageMono8& mask = cimage::CImageMono8());
//             
//             template<typename T>
//             inline CDSI& Run(const cimage::TImage<T>& left, const cimage::TImage<T>& right, const std::vector<SearchRange>& searchRanges = std::vector<SearchRange>(), const cimage::CImageMono8& mask = cimage::CImageMono8());            
//     };
}

#include <Processing/Vision/Stereo/DisparityEngine/Common/DisparityEngine.hxx>

// some common instantiations

typedef disparity::TDisparityEngine<disparity::cost::None, void,
                                    disparity::agg::Census, uint8_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                    disparity::opt::FilteredWTA, uint8_t, disparity::impl::Auto, PLATFORM_CPU_CORES> DisparityEngine_Census_FilteredWTA;

typedef disparity::TDisparityEngine<disparity::cost::None, void,
                                    disparity::agg::Census, uint8_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                    disparity::opt::SGM, uint8_t, disparity::impl::Auto, PLATFORM_CPU_CORES> DisparityEngine_Census_SGM;

typedef disparity::TDisparityEngine<disparity::cost::AbsDiff, uint16_t,
                                    disparity::agg::Window_Simple, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                    disparity::opt::FilteredWTA, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES> DisparityEngine_Simple_FilteredWTA;

typedef disparity::TDisparityEngine<disparity::cost::AbsDiff, uint16_t,
                                    disparity::agg::Window_Simple, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                    disparity::opt::SGM, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES> DisparityEngine_Simple_SGM;
                                    
typedef disparity::TDisparityEngine<disparity::cost::AbsDiff, uint16_t,
                                    disparity::agg::Window_SemiIncremental, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                    disparity::opt::FilteredWTA, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES> DisparityEngine_SemiIncremental_FilteredWTA;

typedef disparity::TDisparityEngine<disparity::cost::AbsDiff, uint16_t,
                                    disparity::agg::Window_SemiIncremental, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                    disparity::opt::SGM, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES> DisparityEngine_SemiIncremental_SGM;

typedef disparity::TDisparityEngine<disparity::cost::AbsDiff, uint16_t,
                                    disparity::agg::Window_Incremental, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                    disparity::opt::FilteredWTA, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES> DisparityEngine_Incremental_FilteredWTA;

typedef disparity::TDisparityEngine<disparity::cost::AbsDiff, uint16_t,
                                    disparity::agg::Window_Incremental, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                    disparity::opt::SGM, uint16_t, disparity::impl::Auto, PLATFORM_CPU_CORES> DisparityEngine_Incremental_SGM;

typedef disparity::TDisparityEngine < disparity::cost::None, void,
                                      disparity::agg::ELAS, uint8_t, disparity::impl::Auto, PLATFORM_CPU_CORES,
                                      disparity::opt::None, uint8_t, disparity::impl::Auto, PLATFORM_CPU_CORES > DisparityEngine_ELAS;
                                      
typedef DisparityEngine_Census_SGM DisparityEngine;
#endif
