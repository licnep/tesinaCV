#ifndef _BLOB_FILTER_H
#define _BLOB_FILTER_H

/** @file BlobFilter.h
 * @brief kernel filter of approximation of gaussian laplacian
 * */

#include <stdint.h>
#include <Data/CImage/PixelTraits/PixelTraits.h>
#include "FilterModifier.h"
#include "ConvolutionKernel.h"
#include "TLocalFilter.h"

namespace cimage {

  namespace kernel {
  
/// -8 + 8 (16)
class BlobFilter3x3: public TConvolutionKernel3x3<-1,-1,-1, -1,+8,-1, -1,-1,-1>
{
  public:
  static const int magnitude = 16;
};

/// Blob3x3 filter, normalized, and uint8 bias
typedef filter::Bias<filter::Div<BlobFilter3x3, 16>, 127> Blob3x3NormBias;

/// -12 +12 (24)
class BlobFilter4x4: public TConvolutionKernel4x4<-1,-1,-1,-1, -1,+3,+3,-1, -1,+3,+3,-1, -1,-1,-1,-1>
{
  public:
  static const int magnitude = 24;
};

/// Blob4x4 filter, normalized, and uint8 bias
typedef filter::Bias<filter::Div<BlobFilter4x4, 24>, 127> Blob4x4NormBias;

/// -16 +16 (32)
class BlobFilter5x5: public TConvolutionKernel5x5<-1,-1,-1,-1,-1, -1,+1,+1,+1,-1, -1,+1,+8,+1,-1, -1,+1,+1,+1,-1, -1,-1,-1,-1,-1>
{
  public:
  static const int magnitude = 32;
};

/// Blob5x5 filter, normalized, and uint8 bias
typedef filter::Bias<filter::Div<BlobFilter5x5, 32>, 127> Blob5x5NormBias;

  } // namespace kernel

namespace filter {

  typedef TLocalFilter<kernel::Blob3x3NormBias> Blob3x3NormBias;
  typedef TLocalFilter<kernel::Blob4x4NormBias> Blob4x4NormBias;
  typedef TLocalFilter<kernel::Blob5x5NormBias> Blob5x5NormBias;

}

}

#endif
