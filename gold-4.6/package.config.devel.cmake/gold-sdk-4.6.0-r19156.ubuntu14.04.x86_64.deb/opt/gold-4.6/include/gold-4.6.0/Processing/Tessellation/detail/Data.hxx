#ifndef _TESSDATA_HXX
#define _TESSDATA_HXX

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file Data.hxx
 * @author Mirko Felisa (felisa@vislab.it)
 * @date 2012-04-16
 */

#include<Processing/Tessellation/Data.h>

namespace tessellation
{

    const int plus1mod3[3] = {1, 2, 0};
    const int minus1mod3[3] = {2, 0, 1};

    template<typename T>
    inline typename TriangleHull<T>::CursorType TriangleHull<T>::Cursor() const
    {
        return m_start;
    }

    template<typename T>
    inline void TriangleHull<T>::Cursor(TriangleHull<T>::CursorType c)
    {
        m_start = c;
    }

    template<typename T>
    inline typename TriangleHull<T>::ContainerType& TriangleHull<T>::Data()
    {
        return m_data;
    }

    template<typename T>
    inline const typename TriangleHull<T>::ContainerType& TriangleHull<T>::Data() const
    {
        return m_data;
    }

    template<typename T>
    inline void TriangleHull<T>::Swap(TriangleHull& h)
    {
        std::swap(m_data, h.m_data);
        std::swap(m_start, h.m_start);
    }

    template<typename T>
    TriangleHullCursor<T>::TriangleHullCursor() :  triangle(NULL) {}

    template<typename T>
    TriangleHullCursor<T>::TriangleHullCursor(Triangle<T>* t, int o) : triangle(t), orientation(o) {}

    template<typename T>
    inline T* TriangleHullCursor<T>::Origin() const
    {
        return triangle->vertex[plus1mod3[orientation]];
    }

    template<typename T>
    inline T* TriangleHullCursor<T>::Destination() const
    {
        return triangle->vertex[minus1mod3[orientation]];
    }

    template<typename T>
    inline T* TriangleHullCursor<T>::Apex() const
    {
        return triangle->vertex[orientation];
    }

    template<typename T>
    inline void TriangleHullCursor<T>::Origin(T* v)
    {
        triangle->vertex[plus1mod3[orientation]] = v;
    }

    template<typename T>
    inline void TriangleHullCursor<T>::Destination(T* v)
    {
        triangle->vertex[minus1mod3[orientation]] = v;
    }

    template<typename T>
    inline void TriangleHullCursor<T>::Apex(T* v)
    {
        triangle->vertex[orientation] = v;
    }

    template<typename T>
    inline void TriangleHullCursor<T>::Back()
    {
        Decode(triangle->neighbour[orientation]);
    }

    template<typename T>
    inline void TriangleHullCursor<T>::Left()
    {
        Decode(triangle->neighbour[plus1mod3[orientation]]);
    }

    template<typename T>
    inline void TriangleHullCursor<T>::Right()
    {
        Decode(triangle->neighbour[minus1mod3[orientation]]);
    }

    template<typename T>
    inline void TriangleHullCursor<T>::Rotate()
    {
        orientation = plus1mod3[orientation];
    }

    template<typename T>
    inline void TriangleHullCursor<T>::InverseRotate()
    {
        orientation = minus1mod3[orientation];
    }

    template<typename T>
    inline bool TriangleHullCursor<T>::operator==(const TriangleHullCursor& a) const
    {
        return  a.triangle == triangle && a.orientation == orientation;
    }

    template<typename T>
    inline bool TriangleHullCursor<T>::operator!=(const TriangleHullCursor& a) const
    {
        return  !operator==(a);
    }

    template<typename T>
    inline Triangle<T>* TriangleHullCursor<T>::Encode() const
    {
        return (Triangle<T>*)((unsigned long) triangle | (unsigned long) orientation);
    }

    template<typename T>
    inline void TriangleHullCursor<T>::Decode(Triangle<T>* t)
    {
        orientation = (int)((unsigned long)(t) & (unsigned long) 3l);
        triangle = (Triangle<T> *)((unsigned long)(t) ^(unsigned long) orientation);
    }

    template<class T>
    inline void Back(const T& tri1, T& tri2)
    {
        tri2.Decode(tri1.triangle->neighbour[tri1.orientation]);
    }

    template<class T>
    inline void Left(const T& tri1, T& tri2)
    {
        tri2.Decode(tri1.triangle->neighbour[plus1mod3[tri1.orientation]]);
    }

    template<class T>
    inline void Right(const T& tri1, T& tri2)
    {
        tri2.Decode(tri1.triangle->neighbour[minus1mod3[tri1.orientation]]);
    }

    template<class T>
    inline void Rotate(const T& tri1, T& tri2)
    {
        tri2.triangle = tri1.triangle;
        tri2.orientation = plus1mod3[tri1.orientation];
    }

    template<class T>
    inline void InverseRotate(const T& tri1, T& tri2)
    {
        tri2.triangle = tri1.triangle;
        tri2.orientation = minus1mod3[tri1.orientation];
    }

    template<class T>
    inline void Join(T& tri1, T& tri2)
    {
        tri1.triangle->neighbour[tri1.orientation] = tri2.Encode();
        tri2.triangle->neighbour[tri2.orientation] = tri1.Encode();
    }


}

#endif

