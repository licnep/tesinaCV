#ifndef _DISTANCE_TRANSFORM_H
#define _DISTANCE_TRANSFORM_H

#include <boost/thread/thread.hpp>

/** @file DistanceTransform.h
 * @brief implements some Distance transformation methods
 * @see DistanceTransform VerticalDistanceTransform HorizontalDistanceTransform
 * */

namespace detail {

  /** convert a binary buffer in an EDT initialized buffer */
template<class T>
void edt_initialize(T *ptr, unsigned int width, unsigned int height, long stride)
{
   T infty = T(-1) - width*width - height*height;
   for(unsigned int j=0;j<height;++j)
   {
   for (unsigned int i=0; i < width; i++)
    {
	if (ptr[i] == 0)
	  ptr[i] = infty;
	else
	  ptr[i] = 0;
    }
   ptr += stride;
   }
}

/** convert a binary buffer in an EDT initialized buffer */
template<class S, class D>
void edt_initialize(const S *src, D *dst, unsigned int width, unsigned int height, long stride)
{
   D infty = D(-1) - width*width - height*height - 1; // deve poter contenere almeno g + width*width + height*height
   for(unsigned int j=0;j<height;++j)
   {
   for (unsigned int i=0; i < width; i++)
   {
     dst[i] = (src[i]) ? D(0) : infty;
   }
   src+=stride;
   dst+=stride;
   }
}

/** Euclidean Distance transformation 1D vertical using Lotufo-Zampirolli's algorithm.
  *
  * @param ptr a buffer initialized with 0 and max_distance
  * @param width,height buffer geometry
  *  
  **/
template<class T>
void edt_vertical(T *ptr, int width, int height, long stride)
{
  // per motivi di performance processo 2 pixel alla volta: width deve essere un multiplo di 2
   static const int w = 2;
   // per ogni colonna
   // (i+1)^{2} = i^{2} + 2i + 1
   // k_{i+1} = k_{i} + b_{i} 
   // b_{i+1} = b_{i} + 2
   // b_0 = 1
   for (int x=0; x<width; x+=w) {
      unsigned int b[w];
      T k[w];
      T *mem = ptr + x;

      for(int i=0;i<w;i++)
      {
	  b[i]=1;
	  k[i]=mem[i];
      }
            
      mem += stride;
      for (int y=1; y<height; y++)
      {
	for(int i=0;i<w;i++)
	{
	T c = mem[i]; 
         if (c > k[i] + b[i]) 
	 {
	    k[i]+=b[i];
            mem[i] = k[i];
            b[i] += 2;
         } 
         else
	 {
            b[i] = 1;
	    k[i] = c;
	 }
	}
      mem += stride;
      }
      mem = ptr + x + (height-1) * stride;
      
      for(int i=0;i<w;i++)
      {
	  b[i]=1;
	  k[i]=mem[i];
      }

      mem -= stride;
      for (int y=height-2; y>=0; y--) 
      {
	for(int i=0;i<w;i++)
	{
	T c = mem[i];
         if (c > k[i] + b[i]) {
	    k[i]+=b[i];
            mem[i] = k[i];
            b[i] += 2;
         } 
         else
	 {
            b[i] = 1;
	    k[i] = c;
	 }
	}
	 mem -= stride;
      }
   }
}


/** vertical distance transform (as in meijster paper)
 * @param src a mask buffer
 * @param dst a distance output buffer
 */
template<class S, class D>
void dt_vertical(const S *src, D *dst, int width, int height, long stride)
{
  const D infty = std::min<unsigned int>(std::max(width,height), D(-1)); // D(-1); // max distance
  for(int x=0;x<width;x++)
  {
    D prev;
    // first row
    prev = dst[x] = (src[x]) ? D(0) : infty;

    // scan 1
    for(int y=1;y<height;y++)
      prev = dst[x+y*stride] = (src[x+y*stride]) ? 0 : ( (prev != infty) ? (prev + 1) : prev );
      // prev = dst[x+y*width] = (src[x+y*width]) ? 0 : ( prev + 1 );
    
    // scan 2
    prev = dst[x+(height-1)*stride];
    for(int y=height-2; y>=0; --y)
    {
      if(prev < dst[x+y*stride])
	prev = dst[x+y*stride] = prev + 1;
      else
	prev = dst[x+y*stride];
    }
    
  }
}

/** vertical distance transform (as in meijster paper)
 * @param src a mask buffer
 * @param dst a distance output buffer
 */
template<class S, class D>
void dt_horizontal(const S *src, D *dst, int width, int height, long stride)
{
  const D infty = std::min<unsigned int>(std::max(width,height), D(-1)); // D(-1); // max distance
  for(int y=0;y<height;y++)
  {
    D prev;
    // first row
    prev = dst[y*width] = (src[y*stride]) ? D(0) : infty;

    // scan 1
    for(int x=1;x<width;x++)
      prev = dst[x+y*stride] = (src[x+y*stride]) ? 0 : ( (prev != infty) ? (prev + 1) : prev );
    
    // scan 2
    prev = dst[width-1+y*stride];
    for(int x=width-2; x>=0; --x)
    {
      if(prev < dst[x+y*stride])
	prev = dst[x+y*stride] = prev + 1;
      else
	prev = dst[x+y*stride];
    }
    
  }
}

/** Euclidean Distance transformation 1D horizontal using Lotufo-Zampirolli's algorithm (in meijster is pratictaly the same)
  *
  * @param ptr a buffer initialized with 0 and max_distance
  * @param width,height buffer geometry
  *  
  **/
template<class T>
void edt_horizontal(T *mem, int width, int height, long stride)
{
   // per ogni riga
   // (i+1)^{2} = i^{2} + 2i + 1
   // k_{i+1} = k_{i} + b_{i} 
   // b_{i+1} = b_{i} + 2
   // b_0 = 1
   for (int y=0; y<height; y++) {
      unsigned int b = 1;
      T k = mem[0];
      for (int x=1; x<width; x++)
      {
	T c = mem[x]; 
         if (c > k + b) 
	 {
	    k+=b;
            mem[x] = k;
            b += 2;
         } 
         else
	 {
            b = 1;
	    k = c;
	 }
      }
      b=1;
      k = mem[width-1];
      for (int x=width-2; x >= 0; x--) 
      {
	T c = mem[x];
         if (c > k + b) {
	    k+=b;
            mem[x] = k;
            b += 2;
         }
         else
	 {
            b = 1;
	    k = c;
	 }
      }
      
      mem+= stride;
   }

}

template<class T, class Algo>
bool meijster_2_pass(T *g, unsigned int width, unsigned int height, Algo op)
{
   int w;
	    
   unsigned int * s = new unsigned int [width];
   unsigned int * t = new unsigned int [width];
   T * g0 = new T[width];

   // for any row
   for (unsigned int y=0; y<height; y++) 
   {
     int q;
     q = s[0] = t[0] = 0;
     // scan3
     for (unsigned int u = 1; u < width; u++) 
     {
       while (q >=0 && op.f(t[q],s[q],g[s[q]]) > op.f(t[q], u,g[u]) )
         q--;

       if (q < 0) 
       {
         q = 0; s[0] = u;
       } 
       else 
       {
         //w := 1 + Sep(s[q],u)
         w = 1 + op.Sep(s[q], u, g);
         if (w < (int)width) {
           q++;
           s[q] = u;
           t[q] = w;
         }
       }
     }

    // tiene una copia del buffer temporanea
    for(unsigned int i =0;i<width;++i)
      g0[i] = g[i];

    // scan 4
     for (int u = width-1; u >= 0; u--) {
       g[u] = op.f(u,s[q], g0[s[q]]);
       if ((unsigned int) u == t[q])
         q--;
     }
     
     g += width;
   }

   delete [] t;
   delete [] s;
   delete [] g0;
   return true;
}

template<class Algo, class S, class D>
void vdt_mcore(const S *src, D *dst, unsigned int width, unsigned int height, int nCores)
{
    boost::thread_group thread_pool_;

    for(int32_t k = 0; k < nCores; k++)
	{
	uint32_t k0 = (width * k) / nCores;	
	uint32_t k1 = (width * (k+1) ) / nCores;

	thread_pool_.create_thread(boost::bind(Algo::template vdt<S,D>,	src + k0, dst + k0, k1 - k0, height, width));
	}

    // aspetto che i thread terminino il processing
    thread_pool_.join_all();
}

template<class Algo, class S, class D>
void hdt_mcore(const S *src, D *dst, unsigned int width, unsigned int height, int nCores)
{
    boost::thread_group thread_pool_;

    for(int32_t k = 0; k < nCores; k++)
	{
	uint32_t k0 = (height * k) / nCores;	
	uint32_t k1 = (height * (k+1) ) / nCores;

	thread_pool_.create_thread(boost::bind(Algo::template hdt<S,D>,	src + k0*width, dst + k0*width, width, k1 - k0, width));
	}

    // aspetto che i thread terminino il processing
    thread_pool_.join_all();
}

template<class Algo, class D>
void meijster_mcore( D *dst, unsigned int width, unsigned int height, int nCores)
{
    boost::thread_group thread_pool_;

    for(int32_t k = 0; k < nCores; k++)
	{
	uint32_t k0 = (height * k) / nCores;	
	uint32_t k1 = (height * (k+1) ) / nCores;
        Algo op;

	thread_pool_.create_thread(boost::bind(&meijster_2_pass<D, Algo>, dst + k0 * width, width, k1 - k0, op));
	}

    // aspetto che i thread terminino il processing
    thread_pool_.join_all();
}

} // distance transform detail --

/** Euclidean Distance Transform policy.
  * the computed distance is (x-i)*(x-i) + (y-j)*(y-j)
  **/ 
class Euclidean { 

  public:  
  
  // g2 al massimo e' max_R - w*w - h*h
  template<class R>
  inline unsigned int f(int x, int i, R g2)
    {
      return  (unsigned int)( (x - i)*(x - i) ) +  g2;
    }

  /// meijster Sep Euclidean function
  template<class R>
  inline int Sep(int i, int u, const R * g) 
    {
    // (unsigned int) ( (u*u - (s[q]*s[q]) + g[u] - g[s[q]]) / (2*(u - s[q])) ); // ;
    return (u*u - i*i + g[u] - g[i]) / (2*(u - i));
    }
      
  template<class S, class D>
  static void vdt (const S*src, D *dst, int width, int height, long stride)
  {
    detail::edt_initialize(src, dst, width, height, stride);
    detail::edt_vertical(dst, width, height, stride);
  }

  template<class S, class D>
  static void hdt (const S*src, D *dst, int width, int height, long stride)
  {
    detail::edt_initialize(src, dst, width, height, stride);
    detail::edt_horizontal(dst, width, height, stride);
  }


};

/** Manhanttan Distance Tranform policy
 * the computed distance is std::abs(x-i) + std::abs(y-j)
 **/
class Manhattan { 
  
  public:

  // g al massimo e' max_R - height quando e' un punto non inizializzato
  // funzione per passare dalla distanza verticale a quella di manhattan
  template<class R>  
  inline unsigned int f (int x, int i, R g)
    {
      return  std::abs(x - i) + g;
    }

  /// meijster Sep Manhanttan function
  template<class R>
  inline int Sep(int i, int u, const R * g) 
    {
    // (unsigned int) ( (u*u - (s[q]*s[q]) + g[u] - g[s[q]]) / (2*(u - s[q])) ); // ;
    if(g[u]>=g[i]+u-i)
	return 65536;
    if(g[i]>g[u]+u-i)
	return -65536;
    
    return (g[u] - g[i] + u + i)/2;
    }

  // policy for vertical distance transform
  template<class S, class D>
  static void vdt (const S*src, D *dst, int width, int height, long stride)
  {
    detail::dt_vertical(src, dst, width, height, stride);
  }

  // policy for horizontal distance transform
  template<class S, class D>
  static void hdt (const S*src, D *dst, int width, int height, long stride)
  {
    detail::dt_horizontal(src, dst, width, height, stride);
  }
    
};

/** Chessboard Distance Tranform policy
  * the computed distance is std::max( std::abs(x-i), std::abs(y-j) )
  **/
class ChessBoard { 

public:

 // f ritorna sempre un positivo, in quanto massimo tra 2 positivi
 template<class R>
 inline unsigned int f (unsigned int x, unsigned int i, R g)
  {
    return  std::max<unsigned int>(std::abs<int>(x - i), g);
  }

/// meijster Sep ChessBoard function
template<class R>
inline int Sep(int i, int u, const R * g) 
  {
  if(g[i]<=g[u])
    return std::max<int>( i + g[u], (i + u)/2 );
  else
    return std::min<int>( u - g[i], (i + u)/2 );
  }

  template<class S, class D>
  static void vdt (const S*src, D *dst, int width, int height, long stride)
  {
    detail::dt_vertical(src, dst, width, height, stride);
  }

  template<class S, class D>
  static void hdt (const S*src, D *dst, int width, int height, long stride)
  {
    detail::dt_horizontal(src, dst, width, height, stride);
  }
    
};

/** Distance Transform
 *
 * Possible values for Algo are showed in those examples:
 * \code
 * DistanceTransform<Euclidean>(input, output, width, height);
 * DistanceTransform<Manhattan>(input, output, width, height);
 * DistanceTransform<ChessBoard>(input, output, width, height);
 * \endcode
 **/
template<class Algo, class S, class D>
void DistanceTransform(const S*src, D *dst, int width, int height, int nCores = boost::thread::hardware_concurrency())
{
  Algo algo;
  // precompute g
  if(nCores>1)
  {
    detail::vdt_mcore<Algo>(src, dst, width, height, nCores);
    detail::meijster_mcore<Algo>(dst, width, height, nCores);
  }
  else
  {
    algo.vdt(src, dst, width, height, width);
    // 2pass
    detail::meijster_2_pass(dst, width, height, Algo() );      
  }

}

/** Vertical Distance Transform
 * @note Algo is the same policy used in DistanceTransform
 **/
template<class Algo, class S, class D>
void VerticalDistanceTransform(const S*src, D *dst, int width, int height, int nCores = boost::thread::hardware_concurrency())
{
  Algo algo;
  if(nCores>1)
    detail::vdt_mcore<Algo>(src, dst, width, height, nCores);
    else
    algo.vdt(src, dst, width, height, width);
}

/** Horizontal Distance Transform
 * @note Algo is the same policy used in DistanceTransform
 **/
template<class Algo, class S, class D>
void HorizontalDistanceTransform(const S*src, D *dst, int width, int height, int nCores = boost::thread::hardware_concurrency())
{
  Algo algo;
  if(nCores>1)
    detail::hdt_mcore<Algo>(src, dst, width, height, nCores);
    else
    algo.hdt(src, dst, width, height, width);
}

#endif
