#ifndef _CENSUS_DEFINITIONS_H
#define _CENSUS_DEFINITIONS_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file Definitions.h
 * \author Paolo Zani (zani@vislab.it) Mirko Felisa (felisa@vislab.it)
 * \date 2010-10-18
 */

#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/Census/Impl.h>


#endif
