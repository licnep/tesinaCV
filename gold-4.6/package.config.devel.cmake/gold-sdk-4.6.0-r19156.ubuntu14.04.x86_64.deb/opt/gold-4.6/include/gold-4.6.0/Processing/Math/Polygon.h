#ifndef _UUID_H
#define _UUID_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2007                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/

/**
 * \file Polygon.h
 * \author Paolo Zani (zani@ce.unipr.it)
 * \date 2007-08-22
 */

#include <cmath>
#include <utility>
#include <vector>
#include <stdexcept>

namespace math
{
/**
* \brief Computes the diagonals of a polygon
* @param [in] vertexes a vector containing the ordered polygon vertexes
* @param [out] diagonals a vector of vertex pairs, with each pair representing one of the polygon diagonals
*/
template<typename T>
inline void diagonals(const std::vector<T>& vertexes, std::vector<std::pair<T, T> >& diagonals)
{
    const int32_t size = vertexes.size();

    if (size > 3)
        for (int32_t i = 0; i < size - 2; ++i)
            for (int32_t j = i + 2; j < (i + 2) + (size - 3) - std::max(0, i - 1); ++j)
                diagonals.push_back(std::make_pair(vertexes[i], vertexes[j]));
}

/**
 * \brief Computes the area of a polygon; if the polygon vertexes are given in clockwise order the value will be negative
 * @param [in] vertexes a vector containing the ordered polygon vertexes
 * @return the polygon area, with sign
 * @see polygon::area
 */
template<typename T>
inline double signed_area(const std::vector<T>& vertexes)
{
    const unsigned int size = vertexes.size();

    if (size <= 2)
        return 0.0;

    double a = 0.0;

    for (unsigned int i = 0; i < size - 1; i++)
        a += (vertexes[i + 1].x - vertexes[i].x) * (vertexes[i + 1].y + vertexes[i].y) * 0.5;

    a += (vertexes[0].x - vertexes[size - 1].x) * (vertexes[0].y + vertexes[size - 1].y) * 0.5;

    return a;
}

/**
 * \brief Computes the area of a polygon
 * @param [in] vertexes a vector containing the ordered polygon vertexes
 * @return the polygon area
 */
template<typename T>
inline double area(const std::vector<T>& vertexes)
{
    return std::abs(signed_area(vertexes));
}

/**
 * \brief Computes the barycenter (centroid) of a polygon
 * @param [in] vertexes a vector containing the ordered polygon vertexes
 * @return the polygon barycenter
 * @note both clockwise and counterclockwise orders are supported
 */
template<typename T>
inline T barycenter(const std::vector<T>& vertexes)
{
    const unsigned int size = vertexes.size();

    T bc;

    switch (size) {

    case 0:
        throw std::runtime_error("polygon::barycenter(): empty vertexes list!");
        break;

    case 1:

        bc = vertexes[0];
        break;

    case 2:

        bc.x = (vertexes[0].x + vertexes[1].x) * 0.5;
        bc.y = (vertexes[0].y + vertexes[1].y) * 0.5;
        break;

    default: {

        bc.x = 0;
        bc.y = 0;

        for (unsigned int i = 0; i < size - 1; ++i) {

            const double c = (vertexes[i].x * vertexes[i + 1].y) - (vertexes[i + 1].x * vertexes[i].y);
            bc.x += (vertexes[i].x + vertexes[i + 1].x) * c;
            bc.y += (vertexes[i].y + vertexes[i + 1].y) * c;
        }

        const double c = (vertexes[size - 1].x * vertexes[0].y) - (vertexes[size - 1].x * vertexes[0].y);
        bc.x += (vertexes[size - 1].x + vertexes[0].x) * c;
        bc.y += (vertexes[size - 1].y + vertexes[0].y) * c;

        const double inv_den = 1.0 / (-polygon::signed_area(vertexes) * 6.0);

        bc.x *= inv_den;
        bc.y *= inv_den;
    }
    }

    return bc;
}
}


/**
 * \brief Test if a point is inside or outside the polygon
 * @param [in] vertexes a vector containing the ordered polygon vertexes
 * @return  1 for interior points and 0 for exterior points
 * @note both clockwise and counterclockwise orders are supported
 */
template<typename T>
uint8_t pnpoly(const T & point, const std::vector<T> & vertexes)
{
  int i, j, npol= vertexes.size();
  uint8_t isInXY = 0;

  for (i = 0, j = npol-1; i < npol; j = i++) {

    if ( (( vertexes[i].y <= point.y && point.y < vertexes[j].y ) || ( vertexes[j].y <= point.y && point.y < vertexes[i].y ))
    &&    ( vertexes[i].x <= point.x || vertexes[j].x <= point.x ) )

      isInXY ^= (point.x > ((point.y - vertexes[i].y) / (vertexes[j].y - vertexes[i].y) * (vertexes[j].x - vertexes[i].x) + vertexes[i].x));
    j=i;
  } 

  return isInXY;
}



#endif
