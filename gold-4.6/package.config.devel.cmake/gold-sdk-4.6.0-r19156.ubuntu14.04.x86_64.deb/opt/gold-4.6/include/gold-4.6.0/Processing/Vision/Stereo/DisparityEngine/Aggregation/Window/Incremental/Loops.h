#ifndef _FULLINCREMENTALLOOPS_H
#define _FULLINCREMENTALLOOPS_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2007                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file loops.h
 * \author Paolo Zani (zani@ce.unipr.it) Mirko Felisa (felisa@ce.unipr.it)
 * \date 2007-04-08
 */

#include <Data/CImage/Pixels/Mono8.h>
#include <Data/CImage/Pixels/Mono8s.h>
#include <Data/CImage/Pixels/Mono16.h>
#include <Data/CImage/Pixels/Mono16s.h>
#include <Data/CImage/Pixels/RGB8.h>

#include <Libs/Compatibility/DeclSpecs.h>

#include <stdint.h>

namespace disparity
{
    namespace impl
    {
        class Cpp;
        class SIMD;
        class Auto;
    }

    namespace cost
    {
        template<typename ResultType_Cost> class None;
        template<typename ResultType_Cost> class AbsDiff;
    }

    namespace incr
    {
        template<typename T, typename ResultType_Agg, typename Impl, typename Cost>
        struct pixel0_loop;

        template<typename T, typename ResultType_Agg, typename Impl, typename Cost>
        struct pixel_loop;

        template<typename T, typename ResultType_Agg, typename Cost>
        struct pixel0_loop<T, ResultType_Agg, impl::Cpp, Cost>
        {
            static inline void run(const T* pLl, const T rl, const T* pLr, const T rr, ResultType_Agg* cur_prev_row_corr, ResultType_Agg* cur_corr_row_sum, const ResultType_Agg* prev_pixel_corr, int d_min, int d_max)
            {
                for(int d = d_min; d <= d_max; ++d) {

                    ResultType_Agg corr_delta = prev_pixel_corr[d] + Cost::eval(pLr[d], rr) - Cost::eval(pLl[d], rl);

                    cur_prev_row_corr[d] = corr_delta;
                    cur_corr_row_sum[d] += corr_delta;
                }
            }
        };
        
        template<typename T, typename ResultType_Agg, typename Cost>
        struct pixel_loop<T, ResultType_Agg, impl::Cpp, Cost>
        {
            static inline void run(const T* pLl, const T rl, const T* pLr, const T rr, ResultType_Agg* cur_prev_row_corr, ResultType_Agg* cur_corr_row_sum, const ResultType_Agg* prev_pixel_corr, int d_min, int d_max)
            {
                for(int d = d_min;  d <= d_max; ++d) {

                    ResultType_Agg corr_delta = prev_pixel_corr[d] + Cost::eval(pLr[d], rr) - Cost::eval(pLl[d], rl);

                    cur_corr_row_sum[d] += corr_delta - cur_prev_row_corr[d];
                    cur_prev_row_corr[d] = corr_delta;
                }
            }
        };

        template<typename T, typename ResultType_Agg, typename Cost>
        struct pixel0_loop<T, ResultType_Agg, impl::Auto, Cost> : public pixel0_loop<T, ResultType_Agg, impl::Cpp, Cost> {};

        template<typename T, typename ResultType_Agg, typename Cost>
        struct pixel_loop<T, ResultType_Agg, impl::Auto, Cost> : pixel_loop<T, ResultType_Agg, impl::Cpp, Cost> {};
    
#ifdef __SSE2__

#define SIGNED_UNPACK_16 \
        "punpcklbw %%xmm1, %%xmm1\n\t" \
        "punpcklbw %%xmm3, %%xmm3\n\t" \
        "psraw $8, %%xmm1\n\t" \
        "psraw $8, %%xmm3\n\t" 

#define UNSIGNED_UNPACK_16 \
        "punpcklbw %%xmm1, %%xmm1\n\t" \
        "punpcklbw %%xmm3, %%xmm3\n\t"\
        "psrlw $8, %%xmm1\n\t" \
        "psrlw $8, %%xmm3\n\t" 

#define SIGNED_UNPACK_32 \
        "pshufd $78, %%xmm1, %%xmm3\n\t" \
        "punpcklwd %%xmm1, %%xmm1\n\t" \
        "punpcklwd %%xmm3, %%xmm3\n\t" \
        "psrad $16, %%xmm1\n\t" \
        "psrad $16, %%xmm3\n\t" \

#define SIGNED_PRELOAD_8 \
        "movq %0, %%xmm0\n\t" \
        "movq %1, %%xmm2\n\t" \
        "punpcklbw %%xmm0, %%xmm0\n\t" \
        "punpcklbw %%xmm2, %%xmm2\n\t" \
        "psraw $8, %%xmm0\n\t" \
        "psraw $8, %%xmm2\n\t"

#define UNSIGNED_PRELOAD_8 \
        "movq %0, %%xmm0\n\t" \
        "movq %1, %%xmm2\n\t" \
        "punpcklbw %%xmm0, %%xmm0\n\t" \
        "punpcklbw %%xmm2, %%xmm2\n\t" \
        "psrlw $8, %%xmm0\n\t" \
        "psrlw $8, %%xmm2\n\t"

#define PRELOAD_16 \
        "movdqa %0, %%xmm0\n\t" \
        "movdqa %1, %%xmm2\n\t"

#ifdef __SSE3__
#define X86_64_32_LOAD_DATA_16 \
        "lddqu %4, %%xmm1\n\t" \
        "lddqu %5, %%xmm3\n\t" 
#else
#define X86_64_32_LOAD_DATA_16 \
        "movdqu %4, %%xmm1\n\t" \
        "movdqu %5, %%xmm3\n\t" 
#endif

#define X86_64_32_LOAD_DATA_8 \
        "movq %4, %%xmm1\n\t" \
        "movq %5, %%xmm3\n\t" 

#define X86_64_32_LOAD_BUFFER \
        "movdqa %6, %%xmm5\n\t" \
        "movdqa %7, %%xmm6\n\t" \
        "movdqa %0, %%xmm4\n\t" \
        "movdqa %1, %%xmm7\n\t" \
        "movdqa %2, %%xmm8\n\t" \
        "movdqa %3, %%xmm9\n\t" 

#define X86_64_32_RUN \
        "psubw %%xmm0, %%xmm1\n\t" \
        "psubw %%xmm2, %%xmm3\n\t" \
        "pabsw %%xmm1, %%xmm1\n\t" \
        "pabsw %%xmm3, %%xmm3\n\t" \
        "psubw %%xmm3, %%xmm1\n\t"

#define X86_64_32_SAVE \
        "paddd %%xmm5, %%xmm1\n\t" \
        "paddd %%xmm6, %%xmm3\n\t" \
        "movdqa %%xmm1, %0\n\t" \
        "movdqa %%xmm3, %1\n\t" \
        "psubd %%xmm4, %%xmm8\n\t" \
        "psubd %%xmm7, %%xmm9\n\t" \
        "paddd %%xmm8, %%xmm1\n\t" \
        "paddd %%xmm9, %%xmm3\n\t" \
        "movdqa %%xmm1, %2\n\t" \
        "movdqa %%xmm3, %3\n\t"

#define X86_64_32_LOAD_DATA0 \
        "movq %4, %%xmm1\n\t" \
        "movq %5, %%xmm3\n\t" 

#define X86_64_32_LOAD_BUFFER0 \
        "movdqa %6, %%xmm5\n\t" \
        "movdqa %7, %%xmm6\n\t" \
        "movdqa %2, %%xmm4\n\t" \
        "movdqa %3, %%xmm7\n\t"

#define X86_64_32_SAVE0 \
        "paddd %%xmm5, %%xmm1\n\t" \
        "paddd %%xmm6, %%xmm3\n\t" \
        "movdqa %%xmm1, %0\n\t" \
        "movdqa %%xmm3, %1\n\t" \
        "paddd %%xmm4, %%xmm1\n\t" \
        "paddd %%xmm7, %%xmm3\n\t" \
        "movdqa %%xmm1, %2\n\t" \
        "movdqa %%xmm3, %3\n\t"

#define X86_32_LOAD_POINTER \
        "mov %0, %%edi\n\t" \
        "mov %1, %%eax\n\t" \
        "mov %2, %%esi\n\t" 

#define X86_32_LOAD_DATA_8 \
       "movq %0, %%xmm1\n\t" \
       "movq %1, %%xmm3\n\t"
       
#define X86_32_LOAD_BUFFER \
       "movdqa (%%edi), %%xmm4\n\t" \
       "movdqa 16(%%edi), %%xmm7\n\t"
       
#ifdef __SSE3__
#define X86_32_LOAD_DATA_16 \
        "lddqu %0, %%xmm1\n\t" \
        "lddqu %1, %%xmm3\n\t"
#else
#define X86_32_LOAD_DATA_16 \
        "movdqu %0, %%xmm1\n\t" \
        "movdqu %1, %%xmm3\n\t"
#endif

#ifdef __SSSE3__ 
#define X86_RUN \
       "psubw %%xmm0, %%xmm1\n\t" \
       "psubw %%xmm2, %%xmm3\n\t" \
       "pabsw %%xmm1, %%xmm1\n\t" \
       "pabsw %%xmm3, %%xmm3\n\t" \
       "psubw %%xmm3, %%xmm1\n\t"
#else 
#define X86_RUN \
       "pshufd $228, %%xmm0, %%xmm6\n\t" \
       "pshufd $228, %%xmm2, %%xmm5\n\t" \
       "psubw %%xmm1, %%xmm6\n\t" \
       "psubw %%xmm3, %%xmm5\n\t" \
       "psubw %%xmm0, %%xmm1\n\t" \
       "psubw %%xmm2, %%xmm3\n\t" \
       "pmaxsw %%xmm6, %%xmm1\n\t" \
       "pmaxsw %%xmm5, %%xmm3\n\t" \
       "psubw %%xmm3, %%xmm1\n\t"
#endif 

#define X86_32_SAVE \
       "paddd (%%esi), %%xmm1\n\t" \
       "paddd 16(%%esi), %%xmm3\n\t" \
       "movdqa %%xmm1, (%%edi)\n\t" \
       "movdqa %%xmm3, 16(%%edi)\n\t" \
       "psubd %%xmm4, %%xmm1\n\t" \
       "psubd %%xmm7, %%xmm3\n\t" \
       "paddd (%%eax), %%xmm1\n\t" \
       "paddd 16(%%eax), %%xmm3\n\t" \
       "movdqa %%xmm1, (%%eax)\n\t" \
       "movdqa %%xmm3, 16(%%eax)\n\t"

#define X86_32_LOAD0 \
       "movq %0, %%xmm1\n\t" \
       "movq %1, %%xmm3\n\t" 
       
#define X86_32_SAVE0 \
       "paddd (%%esi), %%xmm1\n\t" \
       "paddd 16(%%esi), %%xmm3\n\t" \
       "movdqa %%xmm1, (%%edi)\n\t" \
       "movdqa %%xmm3, 16(%%edi)\n\t" \
       "paddd (%%eax), %%xmm1\n\t" \
       "paddd 16(%%eax), %%xmm3\n\t" \
       "movdqa %%xmm1, (%%eax)\n\t" \
       "movdqa %%xmm3, 16(%%eax)\n\t" \

#define X86_16_LOAD_DATA_8 \
       "movq %2, %%xmm1\n\t" \
       "movq %3, %%xmm3\n\t"

#ifdef __SSE3__
#define X86_16_LOAD_DATA_16 \
       "lddqu %2, %%xmm1\n\t" \
       "lddqu %3, %%xmm3\n\t"
#else
#define X86_16_LOAD_DATA_16 \
       "movdqu %2, %%xmm1\n\t" \
       "movdqu %3, %%xmm3\n\t"
#endif

#define X86_16_LOAD_BUFFER \
       "movdqa %0, %%xmm4\n\t" \
       "movdqa %1, %%xmm7\n\t"       
       
#define X86_16_SAVE \
       "paddw %4, %%xmm1\n\t" \
       "movdqa %%xmm1, %0\n\t" \
       "psubw %%xmm4, %%xmm7\n\t" \
       "paddw %%xmm7, %%xmm1\n\t" \
       "movdqa %%xmm1, %1\n\t"

#define X86_16_LOAD_DATA0 \
       "movq %2, %%xmm1\n\t" \
       "movq %3, %%xmm3\n\t" 

#define X86_16_LOAD_BUFFER0 \
       "movdqa %4, %%xmm7\n\t" \
       "movdqa %1, %%xmm4\n\t"        
       
#define X86_16_SAVE0 \
       "paddw %%xmm7, %%xmm1\n\t" \
       "movdqa %%xmm1, %0\n\t" \
       "paddw %%xmm4, %%xmm1\n\t" \
       "movdqa %%xmm1, %1\n\t"

        inline void __asm_preload(const cimage::Mono8s* prr, const cimage::Mono8s* pll) { __asm__ __volatile__ (SIGNED_PRELOAD_8 : : "m"(*prr), "m"(*pll) : "%xmm0","%xmm2"); }

        inline void __asm_preload(const cimage::Mono8* prr, const cimage::Mono8* pll) { __asm__ __volatile__ (UNSIGNED_PRELOAD_8 : : "m"(*prr), "m"(*pll) : "%xmm0","%xmm2"); }

        inline void __asm_preload(const cimage::Mono16* prr, const cimage::Mono16* pll) { __asm__ __volatile__ (PRELOAD_16 : : "m"(*prr), "m"(*pll) : "%xmm0","%xmm2"); }

        inline void __asm_preload(const cimage::Mono16s* prr, const cimage::Mono16s* pll) { __asm__ __volatile__ (PRELOAD_16 : : "m"(*prr), "m"(*pll) : "%xmm0","%xmm2"); }


        inline void __asm_loop(const cimage::Mono8s* pLl, const cimage::Mono8s* pLr, uint16_t* cur_prev_row_corr, uint16_t * cur_corr_row_sum, const uint16_t * prev_pixel_corr, int d, int d_max)
        {
            for(; d <= d_max; d+=8) {

                __asm__ __volatile__ (

                    X86_16_LOAD_DATA_8
                    X86_16_LOAD_BUFFER
                    SIGNED_UNPACK_16
                    X86_RUN
                    X86_16_SAVE
                : "=m"(*(cur_prev_row_corr+d)), "=m"(*(cur_corr_row_sum+d))  :  "m"(*(pLr+d)),  "m"(*(pLl+d)), "m"(*( prev_pixel_corr+d)) : "%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5","%xmm6","%xmm7");
            }
        }

        inline void __asm_loop(const cimage::Mono8s* pLl, const cimage::Mono8s* pLr, uint32_t* cur_prev_row_corr, uint32_t * cur_corr_row_sum, const uint32_t * prev_pixel_corr, int d, int d_max)
        {
            for(; d <= d_max; d+=8) {
#ifdef __x86_64__
                __asm__ __volatile__ (

                    X86_64_32_LOAD_DATA_8
                    X86_64_32_LOAD_BUFFER
                    SIGNED_UNPACK_16
                    X86_64_32_RUN
                    SIGNED_UNPACK_32
                    X86_64_32_SAVE
                : "=m"(*(cur_prev_row_corr+d)), "=m"(*(cur_prev_row_corr+d+4)),"=m"(*(cur_corr_row_sum+d)), "=m"(*(cur_corr_row_sum+d+4))  :  "m"(*(pLr+d)),  "m"(*(pLl+d)), "m"(*( prev_pixel_corr+d)), "m"(*( prev_pixel_corr+d+4)) : "%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5","%xmm6","%xmm7");
#else
                __asm__ __volatile__ (X86_32_LOAD_POINTER : : "r"(cur_prev_row_corr+d), "r"(cur_corr_row_sum+d),  "r"(prev_pixel_corr+d) : "%edi","%esi","%eax");

                __asm__ __volatile__ (

                    X86_32_LOAD_DATA_8
                    X86_32_LOAD_BUFFER
                    SIGNED_UNPACK_16
                    X86_RUN
                    SIGNED_UNPACK_32
                    X86_32_SAVE
                : : "m"(*(pLr+d)), "m"(*(pLl+d)) : "%esi","%edi","%eax","%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5","%xmm6","%xmm7");
#endif
            }
        }

        inline void __asm_loop(const cimage::Mono8* pLl, const cimage::Mono8* pLr, uint16_t* cur_prev_row_corr,uint16_t * cur_corr_row_sum, const uint16_t * prev_pixel_corr, int d, int d_max)
        {
            for(; d <= d_max; d+=8) {

                __asm__ __volatile__ (

                    X86_16_LOAD_DATA_8
                    X86_16_LOAD_BUFFER
                    UNSIGNED_UNPACK_16
                    X86_RUN
                    X86_16_SAVE
                : "=m"(*(cur_prev_row_corr+d)), "=m"(*(cur_corr_row_sum+d)) : "m"(*(pLr+d)), "m"(*(pLl+d)), "m"(*( prev_pixel_corr+d)) : "%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5","%xmm6","%xmm7");
            }
        }


        inline void __asm_loop(const cimage::Mono8* pLl, const cimage::Mono8* pLr, uint32_t* cur_prev_row_corr, uint32_t * cur_corr_row_sum, const uint32_t * prev_pixel_corr, int d, int d_max)
        {
            for(; d <= d_max; d += 8) {

#ifdef __x86_64__
                __asm__ __volatile__ (
                    X86_64_32_LOAD_DATA_8
                    X86_64_32_LOAD_BUFFER
                    UNSIGNED_UNPACK_16
                    X86_64_32_RUN
                    SIGNED_UNPACK_32
                    X86_64_32_SAVE
                : "=m"(*(cur_prev_row_corr+d)), "=m"(*(cur_prev_row_corr+d+4)),"=m"(*(cur_corr_row_sum+d)), "=m"(*(cur_corr_row_sum+d+4))  :  "m"(*(pLr+d)),  "m"(*(pLl+d)), "m"(*( prev_pixel_corr+d)), "m"(*( prev_pixel_corr+d+4)) : "%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5","%xmm6","%xmm7");
#else
                __asm__ __volatile__ (X86_32_LOAD_POINTER : : "r"(cur_prev_row_corr+d), "r"(cur_corr_row_sum+d),  "r"(prev_pixel_corr+d) : "%edi","%esi","%eax");

                __asm__ __volatile__ (
                    X86_32_LOAD_DATA_8
                    X86_32_LOAD_BUFFER
                    UNSIGNED_UNPACK_16
                    X86_RUN
                    SIGNED_UNPACK_32
                    X86_32_SAVE
                : : "m"(*(pLr+d)), "m"(*(pLl+d)) : "%esi","%edi","%eax","%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5","%xmm6","%xmm7");
#endif
            }
        }

        template<class T>
        inline void __asm_loop(const T* pLl, const T* pLr, uint32_t* cur_prev_row_corr, uint32_t * cur_corr_row_sum, const uint32_t * prev_pixel_corr, int d, int d_max)
        {
            for(; d <= d_max; d += 8) {
#ifdef __x86_64__
                __asm__ __volatile__ (

                    X86_64_32_LOAD_DATA_16
                    X86_64_32_LOAD_BUFFER
                    X86_64_32_RUN
                    SIGNED_UNPACK_32
                    X86_64_32_SAVE
                : "=m"(*(cur_prev_row_corr+d)), "=m"(*(cur_prev_row_corr+d+4)),"=m"(*(cur_corr_row_sum+d)), "=m"(*(cur_corr_row_sum+d+4)) : "m"(*(pLr+d)), "m"(*(pLl+d)), "m"(*( prev_pixel_corr+d)), "m"(*( prev_pixel_corr+d+4)) : "%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5","%xmm6","%xmm7");
#else
                __asm__ __volatile__ (X86_32_LOAD_POINTER : : "r"(cur_prev_row_corr+d), "r"(cur_corr_row_sum+d),  "r"(prev_pixel_corr+d) : "%edi","%esi","%eax");

                __asm__ __volatile__ (

                    X86_32_LOAD_DATA_16
                    X86_32_LOAD_BUFFER
                    X86_RUN
                    SIGNED_UNPACK_32
                    X86_32_SAVE
                : : "m"(*(pLr+d)), "m"(*(pLl+d)) : "%esi","%edi","%eax","%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5","%xmm6","%xmm7");
#endif
            }
        }

        template<class T>
        inline void __asm_loop(const T* pLl, const T* pLr, uint16_t* cur_prev_row_corr, uint16_t * cur_corr_row_sum, const uint16_t * prev_pixel_corr, int d, int d_max)
        {
            for(; d <= d_max; d += 8) {

                __asm__ __volatile__ (
                    X86_16_LOAD_DATA_16
                    X86_16_LOAD_BUFFER
                    X86_RUN
                    X86_16_SAVE
                : "=m"(*(cur_prev_row_corr+d)), "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLr+d)),  "m"(*(pLl+d)), "m"(*( prev_pixel_corr+d)) : "%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5","%xmm6","%xmm7");
            }
        }

        inline void __asm_loop0(const cimage::Mono8s* pLl, const cimage::Mono8s* pLr, uint32_t* cur_prev_row_corr, uint32_t * cur_corr_row_sum, const uint32_t * prev_pixel_corr, int d, int d_max)
        {
            for (; d <= d_max; d+=8) {
#ifdef __x86_64__
                __asm__ __volatile__ (
                    X86_64_32_LOAD_DATA0
                    X86_64_32_LOAD_BUFFER0
                    SIGNED_UNPACK_16
                    X86_64_32_RUN
                    SIGNED_UNPACK_32
                    X86_64_32_SAVE0
                : "=m"(*(cur_prev_row_corr+d)), "=m"(*(cur_prev_row_corr+d+4)), "=m"(*(cur_corr_row_sum+d)), "=m"(*(cur_corr_row_sum+d+4))  :  "m"(*(pLr+d)),  "m"(*(pLl+d)), "m"(*( prev_pixel_corr+d)), "m"(*( prev_pixel_corr+d+4)) : "%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5","%xmm6","%xmm7");
#else
                __asm__ __volatile__ (
                    X86_32_LOAD_POINTER
                : :  "r"(cur_prev_row_corr+d), "r"(cur_corr_row_sum+d),  "r"(prev_pixel_corr+d) : "%edi","%esi","%eax");

                __asm__ __volatile__ (
                    X86_32_LOAD0
                    SIGNED_UNPACK_16
                    X86_RUN
                    SIGNED_UNPACK_32
                    X86_32_SAVE0
                : : "m"(*(pLr+d)),  "m"(*(pLl+d)) : "%esi","%edi","%eax","%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5","%xmm6");
#endif
            }

            //questo serve x reinizializzare a zero i valori in +
            for (int i = d_max + 1; i < d; i++)
                cur_corr_row_sum[i] = 0;
        }

        inline void __asm_loop0(const cimage::Mono8s* pLl, const cimage::Mono8s* pLr, uint16_t* cur_prev_row_corr, uint16_t * cur_corr_row_sum, const uint16_t * prev_pixel_corr, int d, int d_max)
        {
            for(; d <= d_max; d+=8) {

                __asm__ __volatile__ (
                    X86_16_LOAD_DATA0
                    X86_16_LOAD_BUFFER0
                    SIGNED_UNPACK_16
                    X86_RUN
                    X86_16_SAVE0
                : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d))  :  "m"(*(pLr+d)),  "m"(*(pLl+d)), "m"(*( prev_pixel_corr+d)): "%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5","%xmm6","%xmm7");
            }

            //questo serve x reinizializzare a zero i valori in +
            for (int i = d_max + 1; i < d; i++)
                cur_corr_row_sum[i] = 0;
        }

        inline void __asm_loop0(const cimage::Mono8* pLl, const cimage::Mono8* pLr, uint16_t* cur_prev_row_corr, uint16_t * cur_corr_row_sum, const uint16_t * prev_pixel_corr, int d, int d_max)
        {
            for (; d <= d_max; d+=8) {

                __asm__ __volatile__ (
                    X86_16_LOAD_DATA0
                    X86_16_LOAD_BUFFER0
                    UNSIGNED_UNPACK_16
                    X86_RUN
                    X86_16_SAVE0

                : "=m"(*(cur_prev_row_corr+d)),  "=m"(*(cur_corr_row_sum+d))  :  "m"(*(pLr+d)),  "m"(*(pLl+d)), "m"(*( prev_pixel_corr+d)): "%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5","%xmm6","%xmm7");
            }

            //questo serve x reinizializzare a zero i valori in +
            for (int i = d_max + 1; i < d; i++)
                cur_corr_row_sum[i] = 0;
        }

        inline void __asm_loop0(const cimage::Mono8* pLl, const cimage::Mono8* pLr, uint32_t* cur_prev_row_corr, uint32_t * cur_corr_row_sum, const uint32_t * prev_pixel_corr, int d, int d_max)
        {
            for(; d <= d_max; d+=8) {
#ifdef __x86_64__
                __asm__ __volatile__ (
                    X86_64_32_LOAD_DATA0
                    X86_64_32_LOAD_BUFFER0
                    UNSIGNED_UNPACK_16
                    X86_64_32_RUN
                    SIGNED_UNPACK_32
                    X86_64_32_SAVE0
                : "=m"(*(cur_prev_row_corr+d)), "=m"(*(cur_prev_row_corr+d+4)), "=m"(*(cur_corr_row_sum+d)), "=m"(*(cur_corr_row_sum+d+4))  :  "m"(*(pLr+d)),  "m"(*(pLl+d)), "m"(*( prev_pixel_corr+d)), "m"(*( prev_pixel_corr+d+4)) : "%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5","%xmm6","%xmm7");
#else
                __asm__ __volatile__(X86_32_LOAD_POINTER : : "r"(cur_prev_row_corr+d), "r"(cur_corr_row_sum+d), "r"(prev_pixel_corr+d) : "%edi","%esi","%eax");

                __asm__ __volatile__ (
                    X86_32_LOAD0
                    UNSIGNED_UNPACK_16
                    X86_RUN
                    SIGNED_UNPACK_32
                    X86_32_SAVE0
                : :  "m"(*(pLr+d)), "m"(*(pLl+d)) : "%esi","%edi","%eax","%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5", "%xmm6");
#endif
            }

            //questo serve x reinizializzare a zero i valori in +
            for (int i = d_max + 1; i < d; i++)
                cur_corr_row_sum[i] = 0;
        }

        template<class T>
        inline void __asm_loop0(const T* pLl, const T* pLr, uint32_t* cur_prev_row_corr, uint32_t * cur_corr_row_sum, const uint32_t * prev_pixel_corr, int d, int d_max)
        {
            for(; d <= d_max; d += 8) {
#ifdef __x86_64__
                __asm__ __volatile__ (

                    X86_64_32_LOAD_DATA_16
                    X86_64_32_LOAD_BUFFER0
                    X86_64_32_RUN
                    SIGNED_UNPACK_32
                    X86_64_32_SAVE0

                : "=m"(*(cur_prev_row_corr+d)), "=m"(*(cur_prev_row_corr+d+4)),"=m"(*(cur_corr_row_sum+d)), "=m"(*(cur_corr_row_sum+d+4))  :  "m"(*(pLr+d)),  "m"(*(pLl+d)), "m"(*( prev_pixel_corr+d)), "m"(*( prev_pixel_corr+d+4)) : "%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5","%xmm6","%xmm7");
#else
                __asm__ __volatile__ (X86_32_LOAD_POINTER : : "r"(cur_prev_row_corr+d), "r"(cur_corr_row_sum+d),  "r"(prev_pixel_corr+d) : "%edi","%esi","%eax");

                __asm__ __volatile__ (
                    X86_32_LOAD_DATA_16
                    X86_RUN
                    SIGNED_UNPACK_32
                    X86_32_SAVE0
                : : "m"(*(pLr+d)),  "m"(*(pLl+d)) : "%esi","%edi","%eax","%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5");
#endif
            }

            //questo serve x reinizializzare a zero i valori in +
            for (int i = d_max + 1; i < d; i++)
                cur_corr_row_sum[i] = 0;
        }

        template<class T>
        inline void __asm_loop0(const T* pLl, const T* pLr, uint16_t* cur_prev_row_corr, uint16_t * cur_corr_row_sum, const uint16_t * prev_pixel_corr, int d, int d_max)
        {
            for(; d <= d_max; d += 8) {

                __asm__ __volatile__ (
                    X86_16_LOAD_DATA_16
                    X86_16_LOAD_BUFFER0
                    X86_RUN
                    X86_16_SAVE0
                : "=m"(*(cur_prev_row_corr+d)), "=m"(*(cur_corr_row_sum+d)) :  "m"(*(pLr+d)),  "m"(*(pLl+d)), "m"(*( prev_pixel_corr+d)) : "%xmm0","%xmm1","%xmm2","%xmm3", "%xmm4","%xmm5","%xmm6","%xmm7");
            }

            //questo serve x reinizializzare a zero i valori in +
            for (int i = d_max + 1; i < d; i++)
                cur_corr_row_sum[i] = 0;
        }

        template<typename T, typename ResultType_Agg, typename C>
        struct pixel0_loop<T, ResultType_Agg, impl::SIMD, cost::AbsDiff<C> >
        {
            static inline void run(const T* pLl, const T rl, const T* pLr, const T rr, ResultType_Agg* cur_prev_row_corr, ResultType_Agg* cur_corr_row_sum, const ResultType_Agg* prev_pixel_corr, int d_min, int d_max)
            {
                DECLSPEC_ALIGN(16) T pll[8], prr[8];

                for(int k = 0; k < 8; k++) {

                    pll[k] = rl;
                    prr[k] = rr;
                }

                __asm_preload(prr, pll);

                //mi salvo la prima disparit� negativa per il pixel successivo (questo perch� l'assembly inizia dal boundary di 16 precedente a d_min)

                ResultType_Agg corr = cur_prev_row_corr[d_min-1];
                ResultType_Agg sum = cur_corr_row_sum[d_min-1];

                long d = (((long)(cur_corr_row_sum +d_min)& ~15) -(long)cur_corr_row_sum) / (long)sizeof(ResultType_Agg);

                __asm_loop0(pLl, pLr, cur_prev_row_corr, cur_corr_row_sum, prev_pixel_corr, d, d_max);

                //sovrascrivo la prima disparit� negativa x il pixel successivo

                cur_prev_row_corr[d_min - 1] = corr;
                cur_corr_row_sum[d_min - 1] = sum;
            }
        };

        template<typename T, typename ResultType_Agg, typename C>
        struct pixel_loop<T, ResultType_Agg, impl::SIMD, cost::AbsDiff<C> >
        {
            static inline void run(const T* pLl, const T rl, const T* pLr, const T rr, ResultType_Agg* cur_prev_row_corr, ResultType_Agg* cur_corr_row_sum, const ResultType_Agg* prev_pixel_corr, int d_min, int d_max)
            {
                DECLSPEC_ALIGN(16) T pll[8], prr[8];

                for(int k = 0; k < 8; k++) {

                    pll[k] = rl;
                    prr[k] = rr;
                }

                __asm_preload(prr, pll);

                //mi salvo la prima disparit� negativa per il pixel successivo (questo perch� l'assembly inizia dal boundary di 16 precedente a d_min)
                ResultType_Agg corr = cur_prev_row_corr[d_min-1];
                ResultType_Agg sum = cur_corr_row_sum[d_min-1];

                long d = (((long)(cur_corr_row_sum +d_min)& ~15) -(long)cur_corr_row_sum) / (long)sizeof(ResultType_Agg);

                __asm_loop(pLl, pLr, cur_prev_row_corr, cur_corr_row_sum, prev_pixel_corr, d, d_max);

                //sovrascrivo la prima disparit� negativa x il pixel successivo

                cur_prev_row_corr[d_min - 1] = corr;
                cur_corr_row_sum[d_min - 1] = sum;
            }
        };

        template<typename T, typename ResultType_Agg, typename C>
        struct pixel0_loop<T, ResultType_Agg, impl::Auto, cost::AbsDiff<C> > : public pixel0_loop<T, ResultType_Agg, impl::SIMD, cost::AbsDiff<C> > {};

        template<typename T, typename ResultType_Agg, typename C>
        struct pixel_loop<T, ResultType_Agg, impl::Auto, cost::AbsDiff<C> > : public pixel_loop<T, ResultType_Agg, impl::SIMD, cost::AbsDiff<C> > {};
#endif
    }
}

#endif
