#ifndef _PIXEL_FUNCTIONS_H
#define _PIXEL_FUNCTIONS_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2008                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file PixelFunctions.h
 * \author Paolo Zani (zani@vislab.it) Mirko Felisa (felisa@vislab.it)
 * \date 2009-10-01
 */

#include <Data/CImage/PixelTraits/PixelTraits.h>

#include <boost/type_traits/is_signed.hpp>
#include <boost/mpl/if.hpp>

namespace cimage
{
    template<typename T>
    inline typename cimage::PixelTraits<T>::ChannelCumulativeType Norm1(T x) { return  std::abs(x); }

//     template<typename T, typename boost::enable_if<boost::is_signed<T> >::type>
//     inline typename cimage::PixelTraits<T>::ChannelCumulativeType Norm1(T x) { return std::abs(x); }

    template<>
    inline cimage::PixelTraits<cimage::Mono8o127>::ChannelCumulativeType Norm1(cimage::Mono8o127 x) { return std::abs((int32_t)x - 127); }

    template<typename T>
    inline typename cimage::PixelTraits<cimage::TRGB<T> >::ChannelCumulativeType Norm1(cimage::TRGB<T> x)
    {
        typename cimage::PixelTraits<cimage::TRGB<T> >::ChannelCumulativeType a = std::abs(x.R);
        a += std::abs(x.G);
        a += std::abs(x.B);

        return a;
    }


    template<typename T>
    inline typename cimage::PixelTraits<T>::CumulativeType Abs(T x) { return x; }

    template<typename T, typename boost::enable_if<boost::is_signed<T> >::type>
    inline typename cimage::PixelTraits<T>::CumulativeType Abs(T x) { return std::abs(x); }

    template<typename T>
    inline typename cimage::PixelTraits<cimage::TRGB<T> >::CumulativeType Abs(cimage::TRGB<T> x)
    {
        typename cimage::PixelTraits<cimage::TRGB<T> >::CumulativeType a(std::abs(x.R), std::abs(x.G), std::abs(x.B));
        return a;
    }

    template<>
    inline cimage::PixelTraits<cimage::Mono8o127>::CumulativeType Abs(cimage::Mono8o127 x) { return std::abs((int32_t)x - 127); }


    template<typename T>
    inline typename cimage::PixelTraits<T>::CumulativeType Sqr(T x) { return x * (typename cimage::PixelTraits<T>::CumulativeType)x; }

    template<typename T>
    inline typename cimage::PixelTraits<cimage::TRGB<T> >::CumulativeType Sqr(cimage::TRGB<T> x)
    {
        typename cimage::PixelTraits<cimage::TRGB<T> >::CumulativeType a(x.R, x.G, x.B);
        a *= a;
        return a;
    }

    template<>
    inline  cimage::PixelTraits<cimage::Mono8o127>::CumulativeType Sqr(cimage::Mono8o127 x) { return ((int32_t)x - 127)* ((int32_t)x - 127); }


    template<typename T>
    inline typename cimage::PixelTraits<T>::ChannelCumulativeType ChannelSum(T x) { return x; }

    template<typename T>
    inline typename cimage::PixelTraits<T>::ChannelCumulativeType ChannelSum(cimage::TRGB<T> x) { return (typename cimage::PixelTraits<T>::ChannelCumulativeType)x.R + x.G + x.B; }
}

#endif
