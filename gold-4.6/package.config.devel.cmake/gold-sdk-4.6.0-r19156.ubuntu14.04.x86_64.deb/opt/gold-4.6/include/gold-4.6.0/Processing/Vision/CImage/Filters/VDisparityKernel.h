#ifndef _VDISPARITYFILTER_H
#define _VDISPARITYFILTER_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2007                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file VDisparityKernel.h
 * \author Paolo Zani (zani@ce.unipr.it)
 * \date 2007-03-05
 */

#include "PixelTraits.h"
#include "SobelFilter.h"
#include <stdint.h>

namespace cimage {
  
/// Al posto di vdisparity::TernarizedVerticalEdges
///       Per l'immagine 'ternarizzata' usare SobelVertical3x3SignTh4
/// Consiglio di usare direttamente filter::Sign< SobelVertical3x3, 4>
///  Il numero 4 e' stata una scelta di Claudio. Si possono usare anche altre soglie.
typedef filter::Sign<SobelVertical<3,3>, 4> SobelVertical3x3SignTh4;

// NOTE: Per l'immagine ternarizzata usare SobelVerticalTern3x3

// TODO: da sistemare... appena capisco cosa fa lo ottimizzerei anche....
template<typename D>
class VerticalBiasedErosion3x3
    {
        public:

	    template<class D2>
	    D2 bias() const { return (cimage::PixelTraits<D2>::Max() - cimage::PixelTraits<D2>::Min())/2; }

	    template<class D2>
            inline D2 zero() const { return bias<D2>(); }

            inline uint32_t GetWidth() const { return 3; }
            inline uint32_t GetHeight() const { return 3; }

	template<class S>
            inline D operator()(const S* inputPixel, long stride) const
            {
	       typedef typename cimage::PixelTraits<S>::DifferenceType type_t;

                type_t comp = static_cast<type_t>(inputPixel[-stride-1])
                              + 2 * static_cast<type_t>(inputPixel[-stride])
                              + static_cast<type_t>(inputPixel[-stride+1])
                              + static_cast<type_t>(inputPixel[-1])
                              + static_cast<type_t>(inputPixel[+1])
                              + static_cast<type_t>(inputPixel[stride-1])
                              + 2 * static_cast<type_t>(inputPixel[stride])
                              + static_cast<type_t>(inputPixel[stride+1]);

                comp *= *inputPixel;

                return comp > type_t(0) ? static_cast<type_t>(*inputPixel * bias<D>() + bias<D>() ) : bias<D>();
            }
    };
}
#endif
