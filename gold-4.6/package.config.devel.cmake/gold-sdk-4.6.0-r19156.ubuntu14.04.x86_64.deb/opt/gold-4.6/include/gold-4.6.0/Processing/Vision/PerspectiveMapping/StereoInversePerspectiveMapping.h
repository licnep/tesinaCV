#ifndef _STEREOINVERSEPERSPECTIVEMAPPING_H
#define _STEREOINVERSEPERSPECTIVEMAPPING_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file CStereoInversePerspectiveMapping.h
 * \author Paolo Zani (zani@ce.unipr.it)
 * \date 2006-11-03
 */

#include <Processing/Vision/PerspectiveMapping/ipm.h>
#include <Processing/Vision/PerspectiveMapping/StereoRectificationUtils.h>
#include <Data/Math/Points.h>

#include <cmath>
#include <limits>
#include <utility>


/**
 * \class CStereoInversePerspectiveMapping
 * \brief Stereo inverse perspective mapping class
 * This class can be used to determine the world coords of a point, given its projections in a pair of stereo images
 * @note the floating point precision to use is the one specified through the template type
 */
template<typename T = double>
class CStereoInversePerspectiveMapping
{
public:

    /// SIMPLE: funziona quando le camere sono allineate lungo l'asse Y
    static const unsigned int ALGO_SIMPLE = 0;
    /// ALIGNED: funziona quando le camere sono allineate in un generico asse del mondo
    static const unsigned int ALGO_ALIGNED = 1;
    /// RAYTRACING: minimizza in coordinate mondo la distanza tra le rette epipolari
    static const unsigned int ALGO_RAYTRACING = 2;

    /**
     * \brief CStereoInversePerspectiveMapping constructor
     * @param [in] cameraParams cameras calibration parameters
     */
    CStereoInversePerspectiveMapping(const std::pair<CameraParams, CameraParams>& cameraParams)
    {
        SetParams(cameraParams);
    }

    /**
     * \brief Sets the calibration parameters to use
     * @param [in] cameraParams cameras calibration parameters
     */
    void SetParams(const std::pair<CameraParams, CameraParams>& cameraParams)
    {
        m_cameraParams = cameraParams;

        m_l0 = math::Point3d(cameraParams.first.x, cameraParams.first.y, cameraParams.first.z);
        m_r0 = math::Point3d(cameraParams.second.x, cameraParams.second.y, cameraParams.second.z);
        m_w0 = m_l0 - m_r0;
        m_baseline = m_w0.length(); // TODO: gestire il caso di LEFT e RIGHT invertite 
        m_m0 = (m_l0 + m_r0) * 0.5;

        m_ipms = std::make_pair(InversePerspectiveMapping(cameraParams.first), InversePerspectiveMapping(cameraParams.second));

        if(HaveCameraSameIntrinsic(cameraParams.first, cameraParams.second) )
        {
            // condizione necessaria: gli intrinsici uguali

            if(AreCamerasStrictlyAligned(cameraParams.first, cameraParams.second))
            {
                // le camere sono sull'asse Y
                m_vergence = 0;
                m_data.reserve(cameraParams.first.height);
                m_data.resize(cameraParams.first.height);
                const T sin_pitch = sin(cameraParams.first.pitch);
                const T cos_pitch = cos(cameraParams.first.pitch);
                const T kub = cameraParams.first.ku * m_baseline;
                const T invkv = 1.0/cameraParams.first.kv;
                for(uint32_t v = 0; v < cameraParams.first.height; ++v)
                {
                    T a = -invkv*(v - cameraParams.first.v0);
                    m_data[v] = math::Point2<T> (kub * (a * sin_pitch + cos_pitch), kub * (a * cos_pitch - sin_pitch));
                }
                m_strictlyAlignedCameras = true;
            }
            else
            {
                m_strictlyAlignedCameras = false;
            }

            if(AreCamerasAligned(cameraParams.first, cameraParams.second) )
            {
                // le camere sono ortogonali all'asse che unisce gli epipoli
                double yaw = cameraParams.first.yaw;
                double pitch = cameraParams.first.pitch;
                double roll = cameraParams.first.roll;

                M[0]= cos(pitch)*cos(yaw);
                M[1]= sin(roll)*sin(pitch)*cos(yaw)-cos(roll)*sin(yaw);
                M[2]= cos(roll)*sin(pitch)*cos(yaw)+sin(roll)*sin(yaw);

                M[4]= cos(pitch)*sin(yaw);
                M[5]= sin(roll)*sin(pitch)*sin(yaw)+cos(roll)*cos(yaw);
                M[6]= cos(roll)*sin(pitch)*sin(yaw)-sin(roll)*cos(yaw);

                M[8]=-sin(pitch);
                M[9]= sin(roll)*cos(pitch);
                M[10]= cos(roll)*cos(pitch);

                // la classica traslazione dovuta al pinhole
                M[3]  = cameraParams.second.x;
                M[7]  = cameraParams.second.y;
                M[11] = cameraParams.second.z;

                M[0] *= cameraParams.second.ku * m_baseline;
                M[1] *= - m_baseline;
                M[2] *= - m_baseline * cameraParams.second.ku / cameraParams.second.kv;
                M[4] *= cameraParams.second.ku * m_baseline;
                M[5] *= - m_baseline;
                M[6] *= - m_baseline * cameraParams.second.ku / cameraParams.second.kv;
                M[8] *= cameraParams.second.ku * m_baseline;
                M[9] *= - m_baseline;
                M[10] *= - m_baseline * cameraParams.second.ku / cameraParams.second.kv;

                m_alignedCameras = true;
            }
            else
            {
                m_alignedCameras = false;
            }

        }
        else
        {
            // i parametri intrinseci sono diversi
            m_strictlyAlignedCameras = m_alignedCameras = false;
        }

        if(!m_alignedCameras && !m_strictlyAlignedCameras)
        {
            m_vergence = - (cameraParams.first.ku * (tan(cameraParams.first.yaw) - tan(cameraParams.second.yaw)));
        }

    }

    /**
     * Return the relative configuration of cameras involved in stereo mapping
     * @return ALGO_SIMPLE, ALGO_ALIGNED, ALGO_RAYTRACING
     */
    unsigned int GetCamerasConfiguration()
    {
        if(m_strictlyAlignedCameras)
            return ALGO_SIMPLE;
        else if(m_alignedCameras)
            return ALGO_ALIGNED;
        else
            return ALGO_RAYTRACING;
    }

    /**
     * \brief Computes the 3D world position of a point, given its projections inside a camera pair
     * @param [in] pixels std::pair<Point2<T>, Point2<T> > image coords of the pixels
     * @return Point3<T> the computed 3D world coords
     */
    template<typename P>
    inline math::Point3<T> WorldFromPixels(const std::pair<math::Point2<P>, math::Point2<P> >& points) const
    {
        if(m_strictlyAlignedCameras)
            return WorldFromPixels_StrictlyAlignedCameras<P>(points);
        else if(m_alignedCameras)
            return WorldFromPixels_AlignedCameras<P>(points);
        else
            return WorldFromPixels_Raytracing<P>(points);
    }

    /**
     * \brief Computes the 3D world position of a point, given its projections inside a camera pair
     * @param [in] pixels std::pair<Point2<T>, Point2<T> > image coords of the pixels
     * @return Point3<T> the computed 3D world coords
     * @note with aligned cameras (that is, with identical pitch and roll angles, and the same x and z position) this method is faster than WorldFromPixels_Raytracing();
     * if cameras are not aligned its results are undefined
     * @see WorldFromPixels_Raytracing
     */
    template<typename P>
    inline math::Point3<T> WorldFromPixels_StrictlyAlignedCameras(const std::pair<math::Point2<P>, math::Point2<P> >& points) const
    {
        math::Point3<T> wp;

        T id = T(1) / (points.first.x - points.second.x);

        wp.x = m_data[points.second.y].x * id + m_cameraParams.second.x;
        wp.y = (m_baseline *  (m_cameraParams.first.u0 - points.second.x) ) * id + m_cameraParams.second.y;
        wp.z = m_data[points.second.y].y * id + m_cameraParams.second.z;

        return wp;
    }

    /**
     * \brief Computes the 3D world position of a point, given its projections inside a camera pair
    *        using the Mid-point method
           * @param [in] pixels std::pair<Point2<T>, Point2<T> > image coords of the pixels
           * @return Point3<T> the computed 3D world coords
           */
    template<typename P>
    inline math::Point3<T> WorldFromPixels_Raytracing(const std::pair<math::Point2<P>, math::Point2<P> >& points) const
    {
        math::Point3<T> vl, vr;
        T a,b,c,d,e;
        T i,j;
        T iden;

        math::Point3<T> wp;

        vl = m_ipms.first.GetEpipolarVector(points.first.x, points.first.y);
        vr = m_ipms.second.GetEpipolarVector(points.second.x, points.second.y);

        a = vl * vl;
        b = vl * vr;
        c = vr * vr;
        d = vl * math::Point3<T>(m_w0);
        e = vr * math::Point3<T>(m_w0);

        iden = T(1) / (a * c - b * b);

        i = (b *e - c *d) * iden;
        j = (a *e - b *d) * iden;

        wp.x = m_m0.x + (i * vl.x + j * vr.x)*0.5;
        wp.y = m_m0.y + (i * vl.y + j * vr.y)*0.5;
        wp.z = m_m0.z + (i * vl.z + j * vr.z)*0.5;

        return wp;
    }

// World from pixel quando le camere sono arbitrariamente posizionate nel mondo, ma comunque allineate tra di loro
    template<typename P>
    inline math::Point3<T> WorldFromPixels_AlignedCameras(const std::pair<math::Point2<P>, math::Point2<P> >& points) const
    {
        math::Point3<T> p;
        // la moltiplicazione per b coinvolge tutti i puntatori di p
        //  di conseguenza e' stata trasformata in un fattore di scala e
        //  inglobato in M
        T id = T(1) / (points.first.x - points.second.x);

        /* genero una coordinata virtuale normalizzata (1, u, v, d) */
        p.x = id;
        p.y = (points.second.x - m_cameraParams.second.u0) * id;
        p.z = (points.second.y - m_cameraParams.second.v0) * id;

        /* E' da notare che per ogni id corrisponde una matrice M indi per cui
          si potrebbe creare una LUT tra id e M per il DSP */
        return math::Point3<T>( M[0] * p.x +  M[1] * p.y +  M[2] * p.z +  M[3],
                          M[4] * p.x +  M[5] * p.y +  M[6] * p.z +  M[7],
                          M[8] * p.x +  M[9] * p.y + M[10] * p.z + M[11]);
    }

    /**
     * \brief Computes cameras vergence
     * @return T the computed vergence
     */
    inline T GetVergence() const
    {
        if(m_alignedCameras)
            return GetVergence_AlignedCameras();
        else
            return GetVergence_Raytracing();
    }

    /**
     * \brief Computes cameras vergence
     * @return T the computed vergence
     * @note with aligned cameras (that is, with identical pitch and roll angles, and the same x and z position) this method is faster than GetVergence_Raytracing();
     * if cameras are not aligned its results are undefined
     */
    inline T GetVergence_AlignedCameras() const
    {
        return m_vergence;
    }

    /**
     * \brief Computes cameras vergence
     * @return T the computed vergence
     */
    inline T GetVergence_Raytracing() const
    {
        return m_ipms.first.GetHorizonX() - m_ipms.second.GetHorizonX();
    }

    /**
     * \brief Computes cameras field of view
     * @return std::vector<Point2<T> > the computed FOV (bottom-left, bottom-right, top-right, top-left)
     */
    inline std::vector<math::Point2<T> > GetFOV() const
    {
        std::vector<math::Point2<T> > fov;
        math::Point3<T> w(0.0, 0.0, 0.0);

        w = m_ipms.second.WorldFromPixelZ(0U, m_cameraParams.second.height);
        fov.push_back(w);
        w = m_ipms.first.WorldFromPixelZ(m_cameraParams.second.width, m_cameraParams.first.height);
        fov.push_back(w);

        w = m_ipms.first.WorldFromPixelZ(static_cast<double>(m_cameraParams.second.width), std::min(m_ipms.first.GetHorizonY()+1.0, static_cast<double>(m_cameraParams.first.height)));
        fov.push_back(w);

        w = m_ipms.second.WorldFromPixelZ(0.0, std::min(m_ipms.second.GetHorizonY()+1.0, static_cast<double>(m_cameraParams.second.height)));
        fov.push_back(w);

        return fov;
    }

private:

    std::pair<CameraParams, CameraParams> m_cameraParams;

    std::pair<InversePerspectiveMapping, InversePerspectiveMapping> m_ipms;

    /// PinHole
    math::Point3d m_l0, m_r0;
    /// Average PinHole
    math::Point3d m_m0;
    /// Baseline
    math::Point3d m_w0;

    /// precomputed data for ALGO_SIMPLE
    std::vector< math::Point2<T> > m_data;

    /// transformation matric (ALGO_ALIGNED)
    T M[12];

    T m_baseline;
    T m_vergence;
    /// le camere sono sulla stessa baseline?
    bool m_alignedCameras;
    /// le camere sono sulla stessa baseline e lungo l'asse Y
    bool m_strictlyAlignedCameras;
};

#endif
