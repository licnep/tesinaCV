#ifndef _CAT_ANT_H
#define _CAT_ANT_H

#include <cstdlib>
#include <cstring>
#include <ctime>            // std::time

#include <boost/random.hpp>
#include <boost/multi_array.hpp>
#include <boost/thread/mutex.hpp>

#include <boost/date_time/posix_time/posix_time_types.hpp>
#include <boost/date_time/gregorian/gregorian.hpp>

#include <Libs/Logger/Log.h>
#include <UI/CWindows/CWindow.h>
#include <Data/CImage/Images/CImageMono8.h>
#include <Data/Math/Points.h>

#include <UI/CWindows/CWindow.h>
#include <UI/CWindows/ColorSpaceConversions.h>
#include <UI/Panel/Panel.h>

#include <Processing/Optimizers/ACO/gold_proc_aco_export.h>


/** \file CAnt.h
 *
 *  \brief Questo impelmenta una Ant Colony Optimizations di base
 *
 *  Caratteristiche:
 *  1) movimento orizzontale
 *  2) immagine di input b/n
 *  3) ogni colonia (CAntColony) e' formata da un certo numero di formiche (CAnt)
 *  4) un gruppo di colonie puo' essere gestito da un manager (CAntColonyManager)
 *
 *   Esempio
 *
 *   \code
 *   MyClass{
 *
 *   CAntColonyManager m_m1,m_m2; //ogni manager gestisce un certo numero di colonie di formiche
 *
 *   MyClass()
 *   {
 *     for(int i=0;0<N_colonie;i++);
 *     {
 *       m_m1.addColony(new CAntColony(m_img_w,m_img_h));
 *       m_m2.addColony(new CAntColony(m_img_w,m_img_h));
 *     }
 *   }
 *
 *   ~MyClass()
 *   {
 *     m_m1.releaseAllColony();
 *     m_m2.releaseAllColony();
 *   }
 *
 *   Run()
 *   {
 *
 *     for(int i=0; i<m_m1.getNColony();i++)
 *     {
 *       m_m1.runColony(img1[i],i); //immagine su cui vogliamo far lavorare la colonia i-esima
 *     }
 *
 *     for(int i=0; i<m_m2.getNColony();i++)
 *     {
 *       m_m2.runColony(img2[i],i); //immagine su cui vogliamo far lavorare la colonia i-esima
 *     }
 *
 *     m_m1.countForResetAllRandomVectors();
 *     m_m2.countForResetAllRandomVectors();
 *   }
 *
 *   Output()
 *   {
 *     m_m1.Output(m_window,i); //la i-esima colonia sulla finestra m_window
 *
 *     m_m2.Output(m_window,j); //la i-esima colonia sulla finestra m_window
 *   }
 *
 *   };
 * \endcode
 *
 */

typedef double * pheromone_matrix;

//vettore risultato di default... maledetto il C++ e i reference
//usato in colony e manager
static const std::vector<math::Point3i> __resultPath__;

//////////////////////////////////////////////////////////////////////////////////
/////////////////////
/// CAnt
//
//////////////////////////////
class GOLD_PROC_ACO_EXPORT CAnt
{
public:

  /** \brief Costruttore di default
   */
  CAnt()
  {
    init = false;

    m_start_u = m_start_v = m_current_u = m_current_v = m_nsteps = m_width = m_height = 0;
    m_window = m_half_window = m_half_half_window = 0;

    m_randomStart_u = m_randomStart_v = -1;
    m_inRandom = false;
    m_maxRandomDistance = std::numeric_limits<double>::max();
    m_randomDistance = 0.0;

    m_nsteps = m_netSteps = 0;
    m_sum = 0.0;

    m_pathDestroied = false;
  }

  /** \brief Costruttore con parametri
   * @param [in] _width image width
   * @param [in] _height image height
   */
  CAnt(int _width, int _height)
  {
    init = true;

    m_width = _width;
    m_height = _height;
    m_current_u = m_start_u = 0;
    m_current_v = m_start_v = 0;
    m_window = m_half_window = 0;
    m_leftBound = std::vector<int>(m_height, 0);
    m_rightBound = std::vector<int>(m_height, m_width);

    m_randomStart_u = m_randomStart_v = -1;
    m_inRandom = false;
    m_maxRandomDistance = std::numeric_limits<double>::max();
    m_randomDistance = 0;

    m_nsteps = m_netSteps = 0;
    m_sum = 0.0;

    m_path.reserve(std::max(m_width, m_height));
    m_holes.reserve(std::max(m_width, m_height));

    m_pathDestroied = false;
  }

  /** \brief Resetta la formica, in particolare il path seguoti, il numero di passi e la somma dei pixel attraversati
   */
  void
  reset();

  /** \brief Lancia la formica
   * @param [in] img puntatore all'immagine b/n
   * @param [in] pheromone_matrix pheromone matrice del pheromone
   * @param [in] _start_u colonna di partenza
   * @param [in] _start_v riga di partenza
   * @param [in] _window finestra righe in cui si puo' spostare
   * @param [in] _alpha alpha della random proportional
   * @param [in] _gamma gamma della pseudo random proportional
   * @param [in] random_vec vettore dei numeri casuali
   * @return valore del path percorso (valore medio dei pixel)
   */
  double
  run(const unsigned char * img, const pheromone_matrix pheromone, int _start_u, int _start_v, int _window, double _alpha, double _gamma,
      std::vector<double> & random_vec/*boost::variate_generator<boost::mt19937&, boost::uniform_real<> > & uni*/);

  double
  run_up(const unsigned char * img, const pheromone_matrix pheromone, int _start_u, int _start_v, int _window, double _alpha, double _gamma,
      std::vector<double> & random_vec, double _maxRandomDistance, const std::vector<int> & _leftBound, const std::vector<int> & _rightBound);

  /** \brief Lancia la formica con un movimento non influenzato dal feromone
   * @param [in] img puntatore all'immagine b/n
   * @param [in] _start_u colonna di partenza
   * @param [in] _start_v riga di partenza
   * @param [in] _window finestra righe in cui si puo' spostare
   * @param [in] _gamma gamma della pseudo random proportional
   * @param [in] random_vec vettore dei numeri casuali
   * @return valore del path percorso (valore medio dei pixel)
   */
  double
  runNoPheromone(const unsigned char * img, int _start_u, int _start_v, int _window, double _gamma, std::vector<double> & random_vec);

  /** \brief Aggiurnamento del feromone lungo il percorso seguito
   * @param [out] pheromone_matrix pheromone matrice del pheromone
   * @param [in] vBest migliore risultato di una formica della colonia, fino ad ora
   * @param [in] Q Q della regola di aggiornamento feromone
   * @param [in] ro tasso di evaporazione
   */
  inline void
  updatePathPheromone(pheromone_matrix & pheromone, double vBest, double Q, double ro)
  {
    double deltaro = ro * Q / (1.0 + vBest - m_sum / double(m_nsteps + 1));
    for (std::vector<math::Point3i>::iterator p = m_path.begin(); p != m_path.end(); ++p)
      {
        pheromone[p->x + p->y * m_width + p->z] += deltaro;
        //pheromone[p->x][p->y][p->z] += deltaro;
      }
  }

  /** \brief Evaporazione di tutto il feromone
   * @param [out] pheromone_matrix pheromone matrice del pheromone
   * @param [in] ro tasso di evaporazione
   */
  inline void
  evaporatePheromone(pheromone_matrix pheromone, double ro)
  {
    for (int i = 0; i < m_width * m_height * m_window; ++i)
      pheromone[i] *= (1 - ro);
    //    int s0=pheromone.shape()[0];
    //    int s1=pheromone.shape()[1];
    //    int s2=pheromone.shape()[2];
    //    for (unsigned int i = 0; i < s0; ++i)
    //      for (unsigned int j = 0; j < s1; ++j)
    //        for (unsigned int k = 0; k < s2; ++k)
    //          pheromone[i][j][k] *= (1 - ro);
  }

  /** \brief Evaporazione del feromone lungo il path
   * @param [out] pheromone_matrix pheromone matrice del pheromone
   * @param [in] ro tasso di evaporazione
   */
  inline void
  evaporatePathPheromone(pheromone_matrix pheromone, double ro)
  {
    for (std::vector<math::Point3i>::iterator p = m_path.begin(); p != m_path.end(); ++p)
      {
        pheromone[p->x + p->y * m_width + p->z] *= (1 - ro);
        //pheromone[p->x][p->y][p->z] *= (1-ro);
      }
  }

  /** \brief Esamina il path seguito dalla formica e tappando i buchi con una retta ed eliminando l'eventuale coda random
   * @param [in] img puntatore all'immagine b/n
   */
  inline void
  postProcess_up(const unsigned char * img)
  {
    //TODO che porcheria...
    //se il path inzia con una zona di cammino random, la elimino
    //vedi CAnt:run
    if (m_holes[0] == -1)
      {
        if (m_holes.size() == 1) //in questo caso e' tutt random...
          m_path.clear();
        else //in questo caso ho solo un'inizio random...
          {
            m_path.erase(m_path.begin(), m_path.begin() + m_holes[1] /*- 1*/);

            m_holes[0] = 0;
            std::transform(m_holes.begin() + 1, m_holes.end(), m_holes.begin() + 1, std::bind2nd(std::minus<int>(), m_holes[1] /*- 1*/));
          }
      }

    for (std::vector<int>::iterator p = m_holes.begin(); p != m_holes.end(); ++p)
      {
        //std::cout << "Entro holes " << *(p + 1) << " " << (*p) << std::endl;
        if ((p + 1) != m_holes.end() && *(p + 1) >= (*p) + MAX_HOLE) //buco di almeno 5
          {
            int fine_buco = *(p + 1);
            int inizio_buco = *(p);
            //std::cout << "Trovato buco " << inizio_buco << " " << fine_buco << std::endl;
            //std::cout << "Gino " << m_path[fine_buco].x << " " << fine_buco << " " << m_path[inizio_buco].x << " " << inizio_buco << std::endl;
            double m = double(m_path[fine_buco].x - m_path[inizio_buco].x) / double(fine_buco - inizio_buco);
            for (int j = inizio_buco + 1; j < fine_buco; ++j)
              {
                m_path[j].x = m_path[inizio_buco].x + m * double(j - inizio_buco);
                m_path[j].z = -1;
                //std::cout<<"pathx "<<m_path[j].x<<" j "<<j<<" pathy "<<m_path[j].y<<std::endl;
              }
          }
      }

    if (m_holes.back() < (int(m_path.size()) - 1))
      m_path.erase(m_path.begin() + m_holes.back(), m_path.end());
  }

  inline void
  postProcess(const unsigned char * img)
  {
    //TODO che porcheria...
    //se il path inzia con una zona di cammino random, la elimino
    //vedi CAnt:run
    if (m_holes.size() > 1 && m_holes[0] == -1)
      {
        m_path.erase(m_path.begin(), m_path.begin() + m_holes[1]);

        m_holes[0] = 0;
        std::transform(m_holes.begin() + 1, m_holes.end(), m_holes.begin() + 1, std::bind2nd(std::minus<int>(), m_holes[1] - 1));
      }

    for (std::vector<int>::iterator p = m_holes.begin(); p != m_holes.end(); ++p)
      {
        if ((p + 1) != m_holes.end() && *(p + 1) >= (*p) + MAX_HOLE) //buco di almeno 5
          {
            int inizio_buco = (*p);
            int fine_buco = *(p + 1);
            double m = double(m_path[fine_buco].y - m_path[inizio_buco].y) / double(fine_buco - inizio_buco);
            for (int j = inizio_buco + 1; j < fine_buco; ++j)
              {
                m_path[j].y = m_path[inizio_buco].y + m * double(j - inizio_buco);
                m_path[j].z = -1;
              }
          }
      }

    if (m_holes.back() < (int(m_path.size()) - 1))
      m_path.erase(m_path.begin() + m_holes.back() + 1, m_path.end());
  }

  /** \brief Ritorna il valore del path
   * @return valore del path percorso (valore medio dei pixel)
   */
  inline double
  getResult() const
  {
    return m_sum / double(m_nsteps + 1);
  }

  inline int
  getPathLength() const
  {
    return m_nsteps + 1;
  }

  inline unsigned int
  getNetPathLength() const
  {
    return m_netSteps;
  }

  inline double
  getSum() const
  {
    return m_sum;
  }

  /** \brief Ritorna il path percorso come triplette di (riga, colonna, next)
   *         dove next e' uguale a -1 se in quel pixel la formica si e' mossa a caso
   * @return valore del path percorso (valore medio dei pixel)
   */
  inline const std::vector<math::Point3i> &
  getPath() const
  {
    return m_path;
  }

  /**\brief Copia *****DISTRUTTIVA***** del path
   * @param [out] _dst il path della formicha
   *
   */
  void
  copy_resultPath(std::vector<math::Point3i> * _dst)
  {
    std::swap(*_dst, m_path);
    m_pathDestroied = true;
  }

  /** \brief Disegna il path sulla finestra passata
   * @param [in] window puntatore alla finestra
   * @param [in] best true se vogliamo che il path venga disegnato di giallo, altrimenti sara' rosso
   */
  void
  DrawPath(ui::win::CWindow * window, bool best = false);

private:
  bool init;

  int m_width, m_height;
  int m_start_u, m_start_v;
  int m_current_u, m_current_v;
  int m_window, m_half_window, m_half_half_window;
  std::vector<int> m_leftBound;
  std::vector<int> m_rightBound;

  int m_randomStart_u;
  int m_randomStart_v;
  bool m_inRandom;
  double m_maxRandomDistance;
  double m_randomDistance;
  int m_nsteps;
  double m_sum;
  unsigned int m_netSteps;

  double m_gamma;
  double m_alpha;

  bool m_pathDestroied;
  std::vector<math::Point3i> m_path;
  std::vector<int> m_holes;

  std::vector<double> &
  m_random();

  static const int MAX_HOLE = 3;

  inline void
  step_forward(const unsigned char * img, const pheromone_matrix pheromone, double rnum/*boost::uniform_real<> > & uni*/)
  {
    int lower = std::max(m_current_v - m_half_window, 0);
    lower = (m_current_v + m_half_window >= m_height) ? m_height - m_window - 1 : lower;

    double den = 0;
    double num[m_window];
    double max_eur = 0, min_eur = 256;
    int i = 0, max_eur_i = 0;
    //double rnum = m_random[uni();//double(rand())/double(RAND_MAX);
    int ph_row = m_current_v * m_width;
    int img_row = lower * m_width;
    for (i = 0; i < m_window; ++i, img_row += m_width)
      {
        unsigned char app = img[img_row + m_current_u + 1];

        if (max_eur <= double(app))
          {
            max_eur = app;
            max_eur_i = i;
          }
        min_eur = min_eur > double(app) ? app : min_eur;

        den += m_alpha * pheromone[m_current_u + ph_row + i] + (1 - m_alpha) * app;
        //den += m_alpha * pheromone[m_current_u][m_current_v][i] + (1 - m_alpha) * app;
        num[i] = den;
      }

    if (max_eur > 0 && den > 0)
      {
        for (i = 0; i < m_window; ++i)
          {
            if (rnum <= num[i] / den)
              break;
          }
        //std::cout<<"Non Rand "<<i<<std::endl;
        //        double max_diff = 0;
        //        img_row = lower * m_width;
        //        for (int j = 0; j < m_window; ++j, img_row += m_width)
        //          max_diff = max_diff <= (max_eur - img[img_row + m_current_u + 1]) ? (max_eur - img[img_row + m_current_u + 1]) : max_diff;

        if (rnum < m_gamma * (max_eur - min_eur) / max_eur)
          i = max_eur_i;

        m_current_v = lower + i;
      }
    else
      {
        //std::cout<<"Rand "<<i<<std::endl;
        m_current_v = lower + randomMove(rnum);
      }

    m_path.back().z = m_current_v - lower;
    m_path.push_back(math::Point3i(++m_current_u, m_current_v, 0));

    m_sum += img[m_current_v * m_width + m_current_u];
    m_netSteps += img[m_current_v * m_width + m_current_u] > 0 ? 1 : 0;

    ++m_nsteps;
  }

  inline void
  step_forward_up(const unsigned char * img, const pheromone_matrix pheromone, double rnum, int _leftBound, int _rightBound)
  {
    int lefter = std::max(m_current_u - m_half_window, _leftBound);
    lefter = (m_current_u + m_half_window >= _rightBound) ? _rightBound - m_window - 1 : lefter;

    double den = 0;
    double num[m_window];
    double max_eur = 0, min_eur = 256;
    int i = 0, max_eur_i = 0;
    //double rnum = m_random[uni();//double(rand())/double(RAND_MAX);
    int ph_row = (m_current_v - 1) * m_width;
    int img_row = (m_current_v - 1) * m_width;//lower * m_width;
    int img_col = lefter;
    for (i = 0; i < m_window; ++i, ++img_col)
      {
        unsigned char app = img[img_row + img_col];

        //ho trovato un nuovo massimo
        //se ritrovo il massimo scelgo a caso
        if (max_eur < double(app) || (max_eur == double(app) && rnum<=0.5))
          {
            max_eur = app;
            max_eur_i = i;
          }
        min_eur = min_eur > double(app) ? app : min_eur;

        den += m_alpha * pheromone[img_col + ph_row] + (1 - m_alpha) * app;
        //den += m_alpha * pheromone[m_current_u][m_current_v][i] + (1 - m_alpha) * app;
        num[i] = den;
      }

    //std::cout<<"DEN "<<den<<std::endl;
    if (max_eur > 0 && den > 0)
      {
        for (i = 0; i < m_window; ++i)
          {
            if (rnum <= num[i] / den)
              break;
          }
        //std::cout<<"Non Rand "<<i<<std::endl;
        //        double max_diff = 0;
        //        img_row = lower * m_width;
        //        for (int j = 0; j < m_window; ++j, img_row += m_width)
        //          max_diff = max_diff <= (max_eur - img[img_row + m_current_u + 1]) ? (max_eur - img[img_row + m_current_u + 1]) : max_diff;

        if (rnum < m_gamma * (max_eur - min_eur) / max_eur)
          i = max_eur_i;

        m_current_u = lefter + i;

        if (m_inRandom)
          {
            m_inRandom = false;
            m_randomStart_u = m_randomStart_v = -1;
            m_randomDistance = 0.0;
          }

      }
    else
      {
        //std::cout<<"Rand "<<i<<std::endl;
        m_current_u = lefter + randomMove(rnum);
        if (!m_inRandom)
          {
            m_randomStart_u = m_current_u;
            m_randomStart_v = m_current_v;
            m_inRandom = true;
          }
        else
          {
            m_randomDistance = sqrt((m_randomStart_u - m_current_u) * (m_randomStart_u - m_current_u) + (m_randomStart_v - m_current_v) * (m_randomStart_v
                - m_current_v));
          }
      }

    //std::cout<<"current_u "<<m_current_u<<" current_v "<<m_current_v<<std::endl;
    m_path.back().z = m_current_u - lefter;
    m_path.push_back(math::Point3i(m_current_u, --m_current_v, 0));

    m_sum += img[m_current_v * m_width + m_current_u];

    //std::cout<<"Incremento nsteps "<<abs(m_current_u - lefter - m_half_window - m_half_half_window)<<std::endl;
    m_nsteps+= 1;// + abs(m_current_u - lefter - m_half_window - m_half_half_window);
  }

  inline void
  step_forward_no_pheromone(const unsigned char * img, /*boost::variate_generator<boost::mt19937&, boost::uniform_real<> > & uni*/double rnum)
  {
    int lower = std::max(m_current_v - m_half_window, 0);
    lower = (m_current_v + m_half_window >= m_height) ? m_height - m_window - 1 : lower;

    double den = 0;
    double num[m_window];
    double max_eur = 0, min_eur = 256;
    int i = 0, max_eur_i = 0;
    //double rnum = uni();
    int img_row = lower * m_width;
    for (i = 0; i < m_window; ++i, img_row += m_width)
      {
        unsigned char app = img[img_row + m_current_u + 1];

        if (max_eur < double(app))
          {
            max_eur = app;
            max_eur_i = i;
          }
        min_eur = min_eur > double(app) ? app : min_eur;

        den += app;
        num[i] = den;
      }

    if (max_eur > 0 && den > 0)
      {
        for (i = 0; i < m_window; ++i)
          {
            if (rnum <= num[i] / den)
              break;
          }

        if (rnum < m_gamma * (max_eur - min_eur) / max_eur)
          i = max_eur_i;

        m_current_v = lower + i;
      }
    else
      {
        //std::cout<<"Rand "<<i<<std::endl;
        m_current_v = lower + randomMove(rnum);
      }

    m_path.back().z = m_current_v - lower;
    m_path.push_back(math::Point3i(++m_current_u, m_current_v, 0));

    m_sum += img[m_current_v * m_width + m_current_u];

    ++m_nsteps;
  }

  inline int
  randomMove(boost::variate_generator<boost::mt19937&, boost::uniform_real<> > & uni)
  {
    return m_window * uni();
  }

  inline int
  randomMove(double r)
  {
    return m_window * r;//uni();
  }
};
//////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////
/////////////////////
/// CAntColony
//
//////////////////////////////
class GOLD_PROC_ACO_EXPORT CAntColony
{
public:
  /** \brief Costruttore con paramentri
   * @param [in] _width width dell'immagine
   * @param [in] _height height dell'immagine
   * @param [in] _window finestra di colonne nelle quali le formiche della colonia potranno spostarsi
   * @param [in] _nAnts numero di formiche di cui e' costituira la coloniua
   */
  CAntColony(int _width, int _height, int _window = DEFAULT_WINDOW, int _nAnts = DEFAULT_NANTS, bool _goup = false);

  ~CAntColony()
  {
    delete[] m_pheromone;

    m_pheromone = NULL; //eh?
  }

  /** \brief Resetta tutte le formiche, ma NON il vettore di numeri casuali
   */
  void
  reset();

  /** \brief Resetta tutte le formiche, ma NON il vettore di numeri casuali e la matrice del feromone
   */
  void
  resetNoPheromone();

  /** \brief Resetta il vettore di numeri casuali
   */
  void
  resetRandomVectors();

  /** \brief Calcola il miglior punto da cui far partire le formiche
   *         Verifica che esista almeno un quadrato 3x2 contenente almeno 4 pixel accesi
   *  @param [in] _img puntatore all'immagine b/n
   */
  void
  computeStartingPoint(const unsigned char * _img);

  /** Lancia le formiche della colonia
   * @param [in] _img puntatore all'immagine b/n
   * @param [in] startingPoints list of starting points, one for each ant managed
   * @param [in] _antsUsePheromone if true override the colony's m_antsUsePheromone member, if false is ignored
   */
  //void
  //run(const unsigned char * _img, const std::vector<Point2i> & startingPoints = std::vector<Point2i>(0), bool _antsUsePheromone=false);

  /** Lancia le formiche della colonia
   * @param [in] _img puntatore all'immagine b/n
   * @param [in] startingPoints list of starting points, one for each ant managed
   * @param [in] _antsUsePheromone if true override the colony's m_antsUsePheromone member, if false is ignored
   */
  void
  run(const unsigned char * _img, const std::vector<math::Point2i> & startingPoints = std::vector<math::Point2i>(0), const std::vector<int> & leftBound = std::vector<int>(
      0), const std::vector<int> & rightBound = std::vector<int>(0));

  /** Lancia le formiche della colonia, con feromone
   *  @param [in] _img puntatore all'immagine b/n
   *  @param [in] startingPoints list of starting points, one for each ant managed
   */
  void
  runYesPheromone_up(const unsigned char * _img, const std::vector<int> & leftBound, const std::vector<int> & rightBound,
      const std::vector<math::Point2i> & startingPoints);

  /** Lancia le formiche della colonia, con feromone
   *  @param [in] _img puntatore all'immagine b/n
   *  @param [in] startingPoints list of starting points, one for each ant managed
   */
  void
  runYesPheromone_right(const unsigned char * _img, const std::vector<int> & leftBound, const std::vector<int> & rightBound,
      const std::vector<math::Point2i> & startingPoints);

  /** Evapora tutto il feromone e aggiorna lungo i path delle formiche
   *  @param [in] bb iteratore alla prima formica che deve aggiornare
   *  @param [in] ee iteratore all'ultima formica che deve aggiornare
   */
  inline void
  updatePheromone(std::vector<CAnt>::iterator bb, std::vector<CAnt>::iterator ee)
  {
    for (; bb != ee; ++bb)
      {
        bb->evaporatePheromone(m_pheromone, m_ro);
        bb->updatePathPheromone(m_pheromone, m_vBest, m_Q, m_ro);
      }
  }

  /** Evapora il feromone e aggiorna solo lungo i path delle formiche
   *  @param [in] bb iteratore alla prima formica che deve aggiornare
   *  @param [in] ee iteratore all'ultima formica che deve aggiornare
   */
  inline void
  updatePathPheromone(std::vector<CAnt>::iterator bb, std::vector<CAnt>::iterator ee)
  {
    for (; bb != ee; ++bb)
      {
        bb->updatePathPheromone(m_pheromone, m_vBest, m_Q, m_ro);
      }
  }
  /** Evapora tutto il feromone
   */
  inline void
  evaporatePheromone()
  {
    for (int i = 0; i < m_width * m_height * m_window; ++i)
      m_pheromone[i] *= (1 - m_ro);
    //    int s0=m_pheromone.shape()[0];
    //    int s1=m_pheromone.shape()[1];
    //    int s2=m_pheromone.shape()[2];
    //    for (unsigned int i = 0; i < s0; ++i)
    //      for (unsigned int j = 0; j < s1; ++j)
    //        for (unsigned int k = 0; k < s2; ++k)
    //          m_pheromone[i][j][k] *= (1 - m_ro);
  }

  /** Evapora il feromone solo lungo i path delle formiche
   *  @param [in] bb iteratore alla prima formica che deve aggiornare
   *  @param [in] ee iteratore all'ultima formica che deve aggiornare
   */
  inline void
  evaporatePathPheromone(std::vector<CAnt>::iterator bb, std::vector<CAnt>::iterator ee)
  {
    for (; bb != ee; bb++)
      {
        bb->evaporatePathPheromone(m_pheromone, m_ro);
      }
  }

  /////////////////////////////////////////////////////
  /// Set e Get
  void
  set_nAnts(int _nAnts)
  {
    m_mutex.lock();
    m_nAnts = _nAnts;

    m_ants.clear();
    m_ants = std::vector<CAnt>(m_nAnts, CAnt(m_width, m_height));
    m_ants.reserve(MAX_ANT_NUMBER);

    m_alphaInc = (m_alpha * 5) / m_nAnts;

    m_defaultStartingPoints = std::vector<math::Point2i>(m_nAnts, math::Point2i(m_start_u, m_start_v));

    boost::mt19937 generator;
    //seed = microseconds from the epoch
    boost::posix_time::time_duration td = boost::posix_time::microsec_clock::universal_time() - boost::posix_time::ptime(boost::gregorian::date(1970,
        boost::gregorian::Jan, 1));
    generator.seed((unsigned long long) td.total_microseconds());
    boost::uniform_real<> uni_dist(0, 1);
    boost::variate_generator<boost::mt19937&, boost::uniform_real<> > uni(generator, uni_dist);

    m_randomVectors.clear();
    for (int i = 0; i < m_nAnts; ++i)
      {
        int n = m_goup ? m_height : m_width;
        m_randomVectors.push_back(std::vector<double>(n, 0));
        for (int j = 0; j < n; ++j)
          (m_randomVectors[i])[j] = uni();
      }
    m_mutex.unlock();
  }
  int
  get_nAnts() const
  {
    return m_nAnts;
  }

  void
  set_maxRandomDistance(double _maxRandomDistance)
  {
    m_maxRandomDistance = _maxRandomDistance;
  }
  double
  get_maxRandomdistance() const
  {
    return m_maxRandomDistance;
  }

  void
  set_window(int _window)
  {
    m_mutex.lock();
    m_window = (_window % 2 == 0) ? _window + 1 : _window;

    if (m_pheromone)
      delete[] m_pheromone;

    m_pheromone = new double[m_width * m_height * m_window];
    memset(m_pheromone, 0, m_width * m_height * m_window * sizeof(double));

    //    int s0=m_pheromone.shape()[0];
    //    int s1=m_pheromone.shape()[1];
    //    int s2=m_pheromone.shape()[2];
    //    for (unsigned int i = 0; i < s0; i++)
    //      for (unsigned int j = 0; j < s1; j++)
    //        for (unsigned int k = 0; k < s2; k++)
    //          m_pheromone[i][j][k] = 0;

    m_mutex.unlock();
  }
  int
  get_window() const
  {
    return m_window;
  }

  void
  set_alpha(double _alpha)
  {
    m_alpha = _alpha;
    m_alphaInc = (m_alpha * 5) / m_nAnts;
  }
  double
  get_alpha() const
  {
    return m_alpha;
  }

  void
  set_ro(double _ro)
  {
    m_ro = _ro;
  }
  double
  get_ro() const
  {
    return m_ro;
  }

  void
  set_gamma(double _gamma)
  {
    m_gamma = _gamma;
  }
  double
  get_gamma() const
  {
    return m_gamma;
  }

  void
  set_Q(double _Q)
  {
    m_Q = _Q;
  }
  double
  get_Q() const
  {
    return m_Q;
  }

  //maledetto C++!!!!!!!
  //l'alternativa e' tirare un eccezione
  const std::vector<math::Point3i>&
  get_resultPath() const
  {
    if (!m_ants.empty())
      return m_bestAnt->getPath();
    else
      return __resultPath__;
  }

  unsigned int get_bestPathNetLength() const
  {
    return m_bestAnt->getNetPathLength();
  }

  double get_bestPathValue() const
  {
    return m_vBest;
  }

  void
  copy_resultPath(std::vector<math::Point3i> * _dst)
  {
    m_bestAnt->copy_resultPath(_dst);
  }

  void
  set_starting_point(math::Point2i sp) //si tratta dello starting point *generale*
  {
    m_start_u = sp.x;
    m_start_v = sp.y;

    for (std::vector<math::Point2i>::iterator p = m_defaultStartingPoints.begin(); p != m_defaultStartingPoints.end(); ++p)
      {
        p->x = m_start_u;
        p->y = m_start_v;
      }
  }

  const std::vector<int>&
  get_defaultLeftBound() const
  {
    return m_defaultLeftBound;
  }
  const std::vector<int>&
  get_defaultRightBound() const
  {
    return m_defaultRightBound;
  }

  /// end Set e Get
  ///////////////////////////////////////////////////////////////////////////////

  /** \brief Disegna i path di tutte le formiche
   * @param [in] window finestra su cui disegnare
   */
  void
  DrawAllAntsPath(ui::win::CWindow * window);

  /** \brief Disegna il path della formica
   * @param [in] window finestra su cui disegnare
   */
  void
  DrawBestAntPath(ui::win::CWindow * window);

  //CSmartPanel* GetPanel();

  static const unsigned int MAX_ANT_NUMBER;
  static const int DEFAULT_WINDOW;
  static const int DEFAULT_NANTS;

private:
  const unsigned char * m_img;

  bool m_goup;

  int m_width, m_height;
  int m_start_u, m_start_v;
  int m_window;
  int m_nAnts;
  double m_maxRandomDistance;
  std::vector<int> m_defaultLeftBound;
  std::vector<int> m_defaultRightBound;
  std::vector<math::Point2i> m_defaultStartingPoints;

  double m_vBest;
  double m_ro;
  double m_Q;
  double m_gamma;
  double m_alpha;
  double m_alphaInc;

  std::vector<CAnt> m_ants;
  std::vector<CAnt>::iterator m_bestAnt;

  std::vector<std::vector<double> > m_randomVectors;

  double m_resultPathWeight;

  //bool m_antsUsePheromone;
  pheromone_matrix m_pheromone;

  boost::mutex m_mutex;
};
//////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////
/////////////////////
/// CAntColonyManager
//
//////////////////////////////
class GOLD_PROC_ACO_EXPORT CAntColonyManager
{
public:
  /** \brief Costruttore di default
   */
  CAntColonyManager()
  {
    m_enabled = true;
    m_initialized = false;

    m_drawAllPaths = false;
    m_drawBestPaths = true;

    m_ro = 0.3;
    m_Q = 1;
    m_gamma = 0.5;
    m_alpha = 0.5;

    m_window = 0;
    m_nAnts = 0;

    m_runCounter = 0;

    m_managedColonies.reserve(MAX_COLONY_NUMBER);
  }

  void Init();

  /** \brief Aggiunge una colonia a quella gestite
   * @param [in] _ac puntatore alla colonia gestita
   */
  void
  addColony(CAntColony * _ac)
  {
    if (m_managedColonies.size() < MAX_COLONY_NUMBER)
      {
        m_managedColonies.push_back(_ac);

        m_window = _ac->get_window();
        m_nAnts = _ac->get_nAnts();

        m_ro = _ac->get_ro();
        m_Q = _ac->get_Q();
        m_gamma = _ac->get_gamma();
        m_alpha = _ac->get_alpha();
      }
    else
      log_warn << "maximum number of AnColony reached = " << MAX_COLONY_NUMBER << std::endl;
  }

  /** \brief Dealloca tutte le colonie gestite
   */
  void
  releaseAllColony();

  /** \brief Resetta una specifica colonia gestite, ma NON i vettori di numeri casuali
   * @param [in] cant identificativo colonia
   */
  void
  resetColony(unsigned int cant);

  /** \brief Resetta tutte le colonie gestite, ma NON i vettori di numeri casuali
   */
  void
  resetAllColony();

  /** \brief Resetta il vettore di numeri casuali della colonia specificata
   * @param [in] cant identificativo colonia
   */
  void
  resetRandomVectors(unsigned int cant);

  /** \brief Resetta tutti i vettori di numeri casuali
   */
  void
  resetAllRandomVectors();

  /** \brief Incrementa il contatore che regola il reset del vettore casuale ed, eventualmente, effettua il reset
   */
  void
  countForResetAllRandomVectors();

  /** \brief Lancia la colonia specificata
   * @param [in] img immagine di lavoro
   * @param [in] identificativo della colonia
   */
  void
  runColony(const cimage::CImageMono8 & img, unsigned int cant);

  //maledetto C++!!!!!!!!
  const std::vector<math::Point3i>&
  get_colonyResultPath(unsigned int cant)
  {
    std::vector<math::Point3i> & _ret = const_cast<std::vector<math::Point3i>&> (__resultPath__); //di default restituiamo un vettore vuoto, al chiamante controllare cosa e' ritornato

    if (cant < m_managedColonies.size())
      _ret = m_managedColonies[cant]->get_resultPath();

    return _ret;
  }

  /** \brief Output su finestra della colonua specificata
   * @param [in] window finestra su cui disegnare
   * @param [in] cant identificativo della colonia
   */
  void
  Output(ui::win::CWindow * window, unsigned int cant);

  ui::wgt::Panel Panel();

private:
  bool m_enabled;
  bool m_initialized;

  bool m_drawAllPaths;
  bool m_drawBestPaths;

  int m_window;
  int m_nAnts;

  unsigned int m_runCounter;

  double m_ro;
  double m_Q;
  double m_gamma;
  double m_alpha;

  std::vector<CAntColony *> m_managedColonies;

  ui::wgt::Panel m_panel;

  void
  set_nAnts(int _nAnts)
  {
    m_nAnts = _nAnts;

    std::for_each(m_managedColonies.begin(), m_managedColonies.end(), std::bind2nd(std::mem_fun(&CAntColony::set_nAnts), m_nAnts));
  }
  int
  get_nAnts() const
  {
    return m_nAnts;
  }

  void
  set_window(int _window)
  {
    m_window = (_window % 2 == 0) ? _window + 1 : _window;

    std::for_each(m_managedColonies.begin(), m_managedColonies.end(), std::bind2nd(std::mem_fun(&CAntColony::set_window), m_window));
  }
  int
  get_window() const
  {
    return m_window;
  }

  void
  set_alpha(double _alpha)
  {
    m_alpha = _alpha;

    std::for_each(m_managedColonies.begin(), m_managedColonies.end(), std::bind2nd(std::mem_fun(&CAntColony::set_alpha), m_alpha));
  }
  double
  get_alpha() const
  {
    return m_alpha;
  }

  void
  set_ro(double _ro)
  {
    m_ro = _ro;

    std::for_each(m_managedColonies.begin(), m_managedColonies.end(), std::bind2nd(std::mem_fun(&CAntColony::set_ro), m_ro));
  }
  double
  get_ro() const
  {
    return m_ro;
  }

  void
  set_gamma(double _gamma)
  {
    m_gamma = _gamma;

    std::for_each(m_managedColonies.begin(), m_managedColonies.end(), std::bind2nd(std::mem_fun(&CAntColony::set_gamma), m_gamma));
  }
  double
  get_gamma() const
  {
    return m_gamma;
  }

  void
  set_Q(double _Q)
  {
    m_Q = _Q;

    std::for_each(m_managedColonies.begin(), m_managedColonies.end(), std::bind2nd(std::mem_fun(&CAntColony::set_Q), m_Q));
  }

  double
  get_Q() const
  {
    return m_Q;
  }

  unsigned int
  getNColony() const
  {
    return m_managedColonies.size();
  }

  static const unsigned int MAX_COLONY_NUMBER = 100;
  static const unsigned int RANDOM_NUMBERS_RESET = 100;

};

#endif //_CAT_ANT_H
