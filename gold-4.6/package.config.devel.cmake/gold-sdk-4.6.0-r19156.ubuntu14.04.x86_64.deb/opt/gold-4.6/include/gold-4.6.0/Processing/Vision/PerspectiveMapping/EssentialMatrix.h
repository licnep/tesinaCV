#ifndef _ESSENTIAL_MATRIX_H
#define _ESSENTIAL_MATRIX_H

/** @file EssentialMatrix.h
 * @brief EssentialMatrix definition and base functions
 * */

#include <Processing/Vision/PerspectiveMapping/gold_proc_pm_export.h>
#include <Data/Math/TMatrices.h>
#include <Data/Base/CCameraParams.h>
#include <Data/Math/Lines.h>
#include <Data/Math/Points.h>

#include "EpipolarGeometryTypes.h"

#include <Eigen/Core>

/** the Essential Matrix between two cameras
 * m^{T}_2 E m_1 = 0
 *
 * p_1 is a point in a camera aligned with axies [I|0] and p_2 is a point of camera with orientation and position [R|t] respect to first.
 *  In this case Essential Matrix is [t]_\times R
 * 
 * R = R_2 R^{-1}_1
 * t = -R_2(t_2 - t_1)
 * 
 * Two "camera" point, m1 and m2, should satisfy relationship m2 = R m1 + t
 *
 * @note important: essential matrix works in CAMERA COORDINATE (not in sensor coordinate, world coordinate or image coordinate).
 * @note per ottenere la matrice inversa basta scambiare i parametri di creazione, o chiamare il metodo Transpose
 **/
class GOLD_PROC_PM_EXPORT EssentialMatrix : public math::TMatrix<double,3,3>
{

public:
    /// default costructor
    EssentialMatrix() {
        SetIdentity();
    }

    /// default costructor
    EssentialMatrix(const math::TMatrix<double,3,3> & m) : math::TMatrix<double,3,3>(m) { }

    /// Import a Eigen Matrix
    EssentialMatrix(const Eigen::Matrix<double,3,3> & m) {
        Import(m);
    }

    /** Costruct essential matrix by camera parameters
      * @note essential matrix uses only relative pose between cameras, according to relationship
      *  R = R_2 R^{-1}_1
      *  t = -R_2(t_2 - t_1)
      * */
    EssentialMatrix(const dev::CameraParams & c1, const dev::CameraParams & c2);

    /// Costruct essential matrix by a Fundamental Matrix and intrinsic parameters from camera params
    /// E = K_2^{T} F K_1
    EssentialMatrix(const dev::CameraParams & c1, const FundamentalMatrix & F, const dev::CameraParams & c2);

    /// costructor using R and t
    ///  relative pose between cameras
    EssentialMatrix(const Eigen::Matrix<double,3,3> &R, const math::Point3d & t);

    /** Costruttore che genera attraverso una decomposizione SVD la matrice essenziale
     *  dato un vettore di coppie di punti.
     *  le coppie sono first = left, second = right.
     * @note e' ovvio che si possono invertire con conseguente cambio di significato di tutte le variabili
     * @note Essendo generata da una decomposizione SVD per definizione \|E\|=1
     **/
    EssentialMatrix(const std::vector< std::pair<math::Point3d, math::Point3d> > & p);

    /** costructor using homogeneous camera coordinate */
    EssentialMatrix(const std::vector< std::pair<math::Point2d, math::Point2d> > & p);

    template<class Matrix>
    void Import(const Matrix & m)
    {
        math::TMatrix<double,3,3> & M = static_cast< math::TMatrix<double,3,3> & >(*this);

        M(0,0) = m(0,0);        M(0,1) = m(0,1);        M(0,2) = m(0,2);
        M(1,0) = m(1,0);        M(1,1) = m(1,1);        M(1,2) = m(1,2);
        M(2,0) = m(2,0);        M(2,1) = m(2,1);        M(2,2) = m(2,2);
    }

    template<class Matrix>
    void Export(Matrix & E) const
    {
        E(0,0) = M[0];        E(0,1) = M[1];        E(0,2) = M[2];
        E(1,0) = M[3];        E(1,1) = M[4];        E(1,2) = M[5];
        E(2,0) = M[6];        E(2,1) = M[7];        E(2,2) = M[8];
    }

    /** Decompose using SVD the current Essential Matrix and set singular values to 1
     * @note non e' solo una normalizzazione ma e' anche una specie di irrobustimento
     * @return todo
     **/
    double Enforce();

    /// Return the transposed (invert side transformation) essential matrix
    EssentialMatrix Transpose() const {
        EssentialMatrix T;
        T[0] = M[0];        T[1] = M[3];        T[2] = M[6];
        T[3] = M[1];        T[4] = M[4];        T[5] = M[7];
        T[6] = M[2];        T[7] = M[5];        T[8] = M[8];
        return T;
    }

    /// With given point return the "search" line on the other image
    /// @note p is a normalized (camera) image coordinate
    template<class T>
    math::Line3<T> operator() (const math::Point3<T> & p) const
    {
        return math::Line3<T>(
                   M[0]*p.x+M[1]*p.y+M[2]*p.z,
                   M[3]*p.x+M[4]*p.y+M[5]*p.z,
                   M[6]*p.x+M[7]*p.y+M[8]*p.z);
    }

    /// Test if two point can be on the same epipolar line
    ///  p2 E p1 = 0
    double operator()(const math::Point3d & p1, const math::Point3d & p2) const
    {
        return (M[0]*p1.x+M[1]*p1.y+M[2]*p1.z) * p2.x +
               (M[3]*p1.x+M[4]*p1.y+M[5]*p1.z) * p2.y +
               (M[6]*p1.x+M[7]*p1.y+M[8]*p1.z) * p2.z;
    }

    /// compute  p^{T}_2 E p_1 = 0
    inline double operator()(const std::pair<math::Point3d, math::Point3d> & p) const
    {
        return operator()(p.first, p.second);
    }

    /// Test if two point can be on the same epipolar line
    ///  p2 E p1 = 0
    /// using homogeneous camera coordinate
    double operator()(const math::Point2d & p1, const math::Point2d & p2) const
    {
        return (M[0]*p1.x+M[1]*p1.y+M[2]) * p2.x +
               (M[3]*p1.x+M[4]*p1.y+M[5]) * p2.y +
               (M[6]*p1.x+M[7]*p1.y+M[8]);
    }

    /// compute  p^{T}_2 E p_1 = 0 using homogeneous camera coordinate
    inline double operator()(const std::pair<math::Point2d, math::Point2d> & p) const
    {
        return operator()(p.first, p.second);
    }

    /** Compute the sampson error between two camera points in the two images */
    double Sampson_Error(const math::Point3d & p1, const math::Point3d & p2) const
    {
        // c'e' da calcolare: p2T E p1, Ep1, p2TE
        // Ep1
        double m2x = p1.x*M[0]+p1.y*M[1]+p1.z*M[2];
        double m2y = p1.x*M[3]+p1.y*M[4]+p1.z*M[5];
        double m2z = p1.x*M[6]+p1.y*M[7]+p1.z*M[8];

        // p2TE
        double m1x = M[0]*p2.x+M[3]*p2.y+M[6]*p2.z;
        double m1y = M[1]*p2.x+M[4]*p2.y+M[7]*p2.z;
//         double m1z = M[2]*p2.x+M[5]*p2.y+M[8]*p2.z;

        double norm = m1x*m1x + m1y*m1y + m2x*m2x + m2y*m2y;

        return (p2.x * m2x + p2.y * m2y + p2.z * m2z) / std::sqrt(norm);
    }

    /** Compute the sampson error between two (normalized) points in the two images */
    double Sampson_Error(const math::Point2d & p1, const math::Point2d & p2) const
    {
        // c'e' da calcolare: p2T E p1, Ep1, p2TE
        // Ep1
        double m2x = p1.x*M[0]+p1.y*M[1]+M[2];
        double m2y = p1.x*M[3]+p1.y*M[4]+M[5];
        double m2z = p1.x*M[6]+p1.y*M[7]+M[8];

        // p2TE
        double m1x = M[0]*p2.x+M[3]*p2.y+M[6];
        double m1y = M[1]*p2.x+M[4]*p2.y+M[7];
//         double m1z = M[2]*p2.x+M[5]*p2.y+M[8];

        double norm = m1x*m1x + m1y*m1y + m2x*m2x + m2y*m2y;

        return (p2.x * m2x + p2.y * m2y + m2z) / std::sqrt(norm);
    }

    /// compute sampson error
    inline double Sampson_Error(const std::pair<math::Point2d, math::Point2d> & p) const
    {
        return Sampson_Error(p.first, p.second);
    }

    /// compute sampson error
    inline double Sampson_Error(const std::pair<math::Point3d, math::Point3d> & p) const
    {
        return Sampson_Error(p.first, p.second);
    }

    /// Decompose the Essential Matrix in two possible rotation matrix @a R1 and @a R2 and in the
    ///  traslation vector @a t
    void Decompose(Eigen::Matrix<double, 3,3> & R1, Eigen::Matrix<double, 3,3> & R2, math::Point3d & t);
};

#endif
