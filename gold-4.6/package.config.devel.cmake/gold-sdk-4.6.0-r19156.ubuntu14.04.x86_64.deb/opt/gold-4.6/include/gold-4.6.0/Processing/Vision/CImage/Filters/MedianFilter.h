#ifndef _MEDIAN_FILTER_H
#define _MEDIAN_FILTER_H

#include <algorithm>
#include <stdint.h>
#include <Processing/Vision/CImage/Filters/FilterModifier.h>
#include <Processing/Vision/CImage/Filters/TLocalFilter.h>

namespace cimage {
  
namespace kernel {  

/** \brief filtro che ritorna il valore mediano in un intorno del punto
 * \code
 * TLocalFilter< kernel::MedianFilter<policy::VariableSize> > filter;
 * filter.SetWidth(3);
 * filter.SetHeight(3);
 * filter(m_inputImageMono, m_outputImageMono);
 * \endcode
 */
template <class SizePolicy, class SelectionPolicy = policy::All>
class MedianFilter : public SelectionPolicy, public SizePolicy, public filter::ImplPixelOperator
    {
    public:
    // unbiased filter
    static const int bias = 0; 
    // do not change sign
    static const bool positive = true;
    // do not alter energy
    static const unsigned int magnitude = 1;    

    public:

	
	template<class D>
        inline D zero() const { return D(0); }
	template<class S>
        inline S operator()(const S* inputPixel, long stride) const
        {         
            const int32_t win_w = SizePolicy::GetWidth();
            const int32_t win_h =  SizePolicy::GetHeight();
            S store[win_w * win_h];
	    int k =0;
            for (int32_t j = - win_h / 2; j <= (win_h - 1) / 2; j++)
            {
                const S* pixel_row = inputPixel + stride * j;
                for (int32_t i= -win_w / 2; i <= (win_w - 1) / 2; i++)
		{
                   const S* in = pixel_row + i;
		   if ( SelectionPolicy::operator()(*in) )
                      store[k++] = *in;
		}
            }

	    if(k>0)
	    {
	      std::nth_element(&store[0], &store[k/2], &store[k]);
	      S median = store[k/2];
	      return median;
	    }
	    else
	      // TODO: throw exception? return *inputPixel?
	      return S(0);

        }
  };


/** \brief filtro che ritorna il valore mediano in un intorno del punto includendo il punto centrale weight volte
 * \code
 * TLocalFilter< kernel::MedianFilter<policy::VariableSize> > filter;
 * filter.SetWidth(3);
 * filter.SetHeight(3);
 * filter.SetWeight(2);
 * filter(m_inputImageMono, m_outputImageMono);
 * \endcode
 */
  template <class SizePolicy>
  class MedianWeightedCenterFilter : public SizePolicy, public filter::ImplPixelOperator
  {
      MedianWeightedCenterFilter(int weight = 1) : m_weight(1) {}
      int m_weight;
    
    public:
        
        void SetWeight(int w) 
        {
           m_weight = w;
        }
        
        int GetWeight() const {return m_weight;}
        
        template<class D>
        inline D zero() const { return D(0); }
        template<class S>
        inline S operator()(const S* inputPixel, long stride) const
        {         
            const int32_t win_w = SizePolicy::GetWidth();
            const int32_t win_h =  SizePolicy::GetHeight();
            S store[win_w * win_h + m_weight -1];
            int k = 0;
            for (;k < m_weight -1; k++)
              store[k++] = *inputPixel;

            for (int32_t j = - win_h / 2; j <= (win_h - 1) / 2; j++)
            {
                const S* pixel_row = inputPixel + stride * j;
                for (int32_t i= -win_w / 2; i <= (win_w - 1) / 2; i++)
                {
                   const S* in = pixel_row + i;
                   store[k++] = *in;
                }
            }
            
              std::nth_element(&store[0], &store[k/2], &store[k]);
              S median = store[k/2];
              return median;
        }
  };
  
  
  /** \brief filtro che ritorna il valore mediano tra immagini a colori (sfrutta la correlazione tra i canali)
 * \code
 * TLocalFilter< kernel::MedianFilter<policy::VariableSize> > filter;
 * filter.SetWidth(3);
 * filter.SetHeight(3);
 * filter(m_inputImageMono, m_outputImageMono);
 * \endcode
 */
template <class SizePolicy>
class MedianColorFilter : public SizePolicy, public filter::ImplPixelOperator
    {
    public:

        
        template<class D>
        inline D zero() const { return D(0); }
        template<class S>
        inline TRGB<S> operator()(const TRGB<S>* inputPixel, long stride) const
        {         
            const int32_t win_w = SizePolicy::GetWidth();
            const int32_t win_h =  SizePolicy::GetHeight();
            int store[win_w * win_h];
            int k = 0;
            TRGB<int> p(inputPixel->R, inputPixel->G, inputPixel->B); 
            for (int32_t j = - win_h / 2; j <= (win_h - 1) / 2; j++)
            {
                const S* pixel_row = inputPixel + stride * j;
                for (int32_t i= - win_w / 2; i <= (win_w - 1) / 2; i++)
                {
                   const S* in = pixel_row + i;
                   store[k++] = std::abs((int)in->R - p.R) + std::abs((int)in->G - p.G) + std::abs((int)in->B - p.B);
                }
            }

          int index = min_element(store, store + k) - store;
          return *(inputPixel - win_w / 2 + (index / win_w - win_h/2 ) * stride + index % win_w);       
        }
  };

typedef kernel::MedianFilter< policy::FixedSize<3,3>, policy::All > MedianFilter3x3;
typedef kernel::MedianFilter< policy::VariableSize, policy::All >   MedianFilterVarSize;  
  
} // kernel

}

#include <Processing/Vision/CImage/Filters/MedianFilter.hxx>

namespace cimage {
//
namespace filter {

  /** Filtro mediano in un intorno 3x3 del pixel */
typedef TLocalFilter< kernel::MedianFilter3x3 > MedianFilter3x3;

/** Filtro mediano in un intorno del pixel con finestra ridimensionabile a runtime */
typedef TLocalFilter< kernel::MedianFilterVarSize >   MedianFilter;

 /** Filtro mediano con il punto centrale incluso weight volte in un intorno 3x3 del pixel  */
typedef TLocalFilter< kernel::MedianWeightedCenterFilter< policy::FixedSize<3,3> > >   MedianWeightedCenterFilter3x3;

 /** Filtro mediano per immagini a colori (tiene conto della correlazione dei canali)  */
typedef TLocalFilter< kernel::MedianColorFilter< policy::FixedSize<3,3> > >   MedianColorFilter3x3;

}


   
} // namespace cimage



#endif
