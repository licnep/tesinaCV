#ifndef _BOUNDING_POLYGON_H
#define _BOUNDING_POLYGON_H

#include "Polygon.h"
#include <Processing/Vision/PerspectiveMapping/ipm.h>

#include "PointWrap.hxx"

template<typename T, typename U, typename V>
void bounding_polygon(std::vector<V>& output, const std::vector<T>& world_points, U z_min, U z_max, const PerspectiveMapping& pm)
{
    std::vector<V> img_points;

    for(uint32_t i = 0; i < world_points.size(); ++i) {

        T p;
        const T& w = world_points[i];

        pm.PixelFromWorld(&(p.x), &(p.y), w.x, w.y, z_min);
        img_points.push_back(p);
        pm.PixelFromWorld(&(p.x), &(p.y), w.x, w.y, z_max);
        img_points.push_back(p);
    }

    giftWrapping(output, img_points);
}

template<typename T, typename U, typename V>
inline void bounding_polygon(std::vector<V>& output, const std::vector<T>& world_points, U z_min, U z_max, const CameraParams& cp)
{
    bounding_polygon(output, world_points, z_min, z_max, PerspectiveMapping(cp));
}

template<typename T, typename U>
void bounding_polygon(std::vector<U>& output, const std::vector<T>& world_points, const PerspectiveMapping& pm)
{
    std::vector<U> img_points;

    for(uint32_t i = 0; i < world_points.size(); ++i) {

        T p;
        const T& w = world_points[i];

        pm.PixelFromWorld(&(p.x), &(p.y), w.x, w.y, w.z);
        img_points.push_back(p);
    }

    giftWrapping(output, img_points);
}

template<typename T, typename U>
inline void bounding_polygon(std::vector<U>& output, const std::vector<T>& world_points, const CameraParams& cp)
{
    bounding_polygon(output, world_points, PerspectiveMapping(cp));
}

#endif
