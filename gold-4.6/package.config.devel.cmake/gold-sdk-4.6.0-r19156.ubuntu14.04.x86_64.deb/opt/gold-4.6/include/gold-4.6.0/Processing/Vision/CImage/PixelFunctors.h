#ifndef __CIMAGE_PIXEL_FUNCTORS
#define __CIMAGE_PIXEL_FUNCTORS

/** \file PixelFunctors.h
 *  \author Vislab
 *  \brief Functors for single planar pixel operations
 *
 *  Pixel functor supply basic operation ("C = A op B" like).
 *  They can be used with Algorithms to build operation on an entire image
 *  \ref cimage
 */
namespace cimage
{
  namespace functors
  {
    template <class PixelType>
    inline void Bitwise_And ( PixelType& Dst, const PixelType& SrcA, const PixelType& SrcB ) { Dst=SrcA&SrcB; }

    template <class PixelType>
    inline void Bitwise_Or ( PixelType& Dst, const PixelType& SrcA, const PixelType& SrcB )  { Dst=SrcA|SrcB; }

    template <class PixelType>
    inline void Bitwise_Xor ( PixelType& Dst, const PixelType& SrcA, const PixelType& SrcB ) { Dst=SrcA^SrcB; }


    template <class PixelType>
    inline void Add ( PixelType& Dst, const PixelType& SrcA, const PixelType& SrcB ) { Dst=SrcA+SrcB; }

    template <class PixelType>
    inline void Subtract ( PixelType& Dst, const PixelType& SrcA, const PixelType& SrcB ) { Dst=SrcA-SrcB; }

    template <class PixelType>
    inline void Multiply ( PixelType& Dst, const PixelType& SrcA, const PixelType& SrcB ) { Dst=SrcA*SrcB; }

    template <class PixelType>
    inline void Divide ( PixelType& Dst, const PixelType& SrcA, const PixelType& SrcB ) { Dst=SrcA/SrcB; }

    // TODO: add clipping policy
    template <class PixelType>
    class LinComb_self
    {
      double m_a;
      public:
      LinComb_self(double a) :m_a(a){}
      inline void operator()( const PixelType& Src, PixelType& Dst ) 
      { 
        Dst+=m_a*Src; 
      }
    };

    template <class PixelType, class MaskType >
    inline void Apply_Mask ( PixelType& Dst, const PixelType& SrcA, const MaskType& Mask )
    {
      typename cimage::PixelTraits<PixelType>::CumulativeType Tmp ( SrcA );
      Tmp*=Mask;
      Tmp/=cimage::PixelTraits<MaskType>::Max();
      Dst=Tmp;
    }


    // TODO portare nelle specializzazioni delle varie immagini?
    // TODO al posto dei TRGB e affini ci vorrebbe il nome corretto
    ////////////////////////////////////////////////////////////////////////////////////////////
    template <> inline void Apply_Mask ( cimage::TBGRA<unsigned char>& Dst, const cimage::TBGRA<unsigned char>& SrcA, const unsigned char& Mask ) { NOT_IMPLEMENTED; }
    template <> inline void Apply_Mask ( cimage::TRGBA<unsigned char>& Dst, const cimage::TRGBA<unsigned char>& SrcA, const unsigned char& Mask ) { NOT_IMPLEMENTED; }
    template <> inline void Apply_Mask ( cimage::TRGB<uint8_t>& Dst, const cimage::TRGB<uint8_t>& SrcA, const unsigned char& Mask ) { NOT_IMPLEMENTED; }
    template <> inline void Apply_Mask ( cimage::TRGB<int16_t>& Dst, const cimage::TRGB<int16_t>& SrcA, const unsigned char& Mask ) { NOT_IMPLEMENTED; }
    template <> inline void Apply_Mask ( cimage::Bayer<RGGB>& Dst, const cimage::Bayer<RGGB>& SrcA, const unsigned char& Mask ) { NOT_IMPLEMENTED; }
    template <> inline void Apply_Mask ( cimage::Bayer<GBRG>& Dst, const cimage::Bayer<GBRG>& SrcA, const unsigned char& Mask ) { NOT_IMPLEMENTED; }
    template <> inline void Apply_Mask ( cimage::Bayer<GRBG>& Dst, const cimage::Bayer<GRBG>& SrcA, const unsigned char& Mask ) { NOT_IMPLEMENTED; }
    template <> inline void Apply_Mask ( cimage::Bayer<BGGR>& Dst, const cimage::Bayer<BGGR>& SrcA, const unsigned char& Mask ) { NOT_IMPLEMENTED; }
    ////////////////////////////////////////////////////////////////////////////////////////////
  }
}



#endif //__CIMAGE_PIXEL_FUNCTORS
