#ifndef _LOSSFUNCTIONS_HXX
#define _LOSSFUNCTIONS_HXX

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file LossFunctions.hxx
 * @author Paolo Zani (zani@vislab.it)
 * @date 2012-03-07
 */

#include <cmath>

namespace sample_consensus
{
    namespace detail
    {
        class RectLoss
        {
            public:

                RectLoss(double threshold) : m_threshold(threshold) {}

                inline double operator()(bool inlier, double error) const
                {
                    return inlier ? 0.0 : 1.0;
                }

            private:

                double m_threshold;
        };

        struct BoundedSquareLoss
        {
            public:

                BoundedSquareLoss(double threshold) : m_threshold2(threshold * threshold) {}

                inline double operator()(bool inlier, double error) const
                {
                    return inlier ? error * error : m_threshold2;
                }

            private:

                double m_threshold2;
        };
    }
}


#endif
