#ifndef _CENSUS_PARAMS_H
#define _CENSUS_PARAMS_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file Params.h
 * \author Paolo Zani (zani@vislab.it) Mirko Felisa (felisa@vislab.it)
 * \date 2010-10-18
 */

#include <stdint.h>

namespace disparity
{
    class CensusParams
    {
        public:

            static const uint32_t DEFAULT_WINDOW_WIDTH = 5;
            static const uint32_t DEFAULT_WINDOW_HEIGHT = 5;

            CensusParams() :
                    m_winWidth(DEFAULT_WINDOW_WIDTH),
                    m_winHeight(DEFAULT_WINDOW_HEIGHT), 
                    m_downsampleratio(1){}

            uint32_t m_winWidth;
            uint32_t m_winHeight;
            uint32_t m_downsampleratio;
            
    };
}

#endif 
