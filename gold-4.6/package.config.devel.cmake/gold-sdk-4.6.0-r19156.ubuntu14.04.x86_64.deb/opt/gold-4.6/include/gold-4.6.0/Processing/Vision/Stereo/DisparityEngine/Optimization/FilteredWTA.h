#ifndef _FILTEREDWTA_H
#define _FILTEREDWTA_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * \file FilteredWTA.h
 * \brief winner-takes-all optimization
 * \author Paolo Zani <zani@vislab.it>
 * \date 2010-09-17
 **/

#include <Processing/Vision/Stereo/Images/CDSI.h>
#include <Processing/Vision/Stereo/Images/CScoreImage.h>
#include <Processing/Vision/Stereo/DisparityEngine/Optimization/MinimizationFunctions.h>
#include <Processing/Vision/Stereo/DisparityEngine/Common/DisparityEngineData.h>
#include <stdint.h>

#include <limits>
#include <cmath>
#include <cstdlib>

namespace disparity
{
    namespace impl
    {
        class Cpp;
        class SIMD;
        class Auto;
    }

    namespace opt
    {
        template<typename ResultType_Agg, uint32_t Threads_Agg, typename ResultType_Opt, typename Impl_Opt, uint32_t Threads_Opt>
        class FilteredWTA : private virtual DisparityEngineData
        {
            public:
                
                static const bool DEFAULT_FILTERING_ENABLED = false;
                static const bool DEFAULT_DISAMB_ENABLED = false;
                static const bool DEFAULT_EXTRA_FILTERING_ENABLED = false;
                static const bool DEFAULT_SUBPIXEL_ACCURACY_ENABLED = true;
                static const int32_t DEFAULT_MIN_CORRELATION_FUNCTION_ELEMENTS_NUM = 16;
                const double DEFAULT_MAX_CORRELATION_PEAK_DISPERSION;
                const double DEFAULT_MIN_INV_CORRELATION_PEAK_SHARPNESS;
                const double DEFAULT_MAX_CORRELATION_PEAK_VALUE;

                bool m_filteringEnabled;
                bool m_extraFilteringEnabled;
                bool m_disambEnabled;
                bool m_subpixelAccuracyEnabled;
                int32_t m_minCorrelFunctionElementsNum;
                double m_maxCorrelationPeakDispersion;
                double m_minInvCorrelationPeakSharpness;
                double m_maxCorrelationPeakValueNorm;

            protected:

                
                FilteredWTA() :
                   DEFAULT_MAX_CORRELATION_PEAK_DISPERSION(30.0), DEFAULT_MIN_INV_CORRELATION_PEAK_SHARPNESS(10.0), DEFAULT_MAX_CORRELATION_PEAK_VALUE(10.0),
                    m_filteringEnabled(DEFAULT_FILTERING_ENABLED),
                    m_extraFilteringEnabled(DEFAULT_EXTRA_FILTERING_ENABLED),
                    m_disambEnabled(DEFAULT_DISAMB_ENABLED),
                    m_subpixelAccuracyEnabled(DEFAULT_SUBPIXEL_ACCURACY_ENABLED),
                    m_minCorrelFunctionElementsNum(DEFAULT_MIN_CORRELATION_FUNCTION_ELEMENTS_NUM),
                    m_maxCorrelationPeakDispersion(DEFAULT_MAX_CORRELATION_PEAK_DISPERSION),
                    m_minInvCorrelationPeakSharpness(DEFAULT_MIN_INV_CORRELATION_PEAK_SHARPNESS),
                    m_maxCorrelationPeakValueNorm(DEFAULT_MAX_CORRELATION_PEAK_VALUE),
                    m_disambDataSize(0){}

                ~FilteredWTA()
                {
                    for(uint32_t i = 0; i < Threads_Agg; ++i) {

                        free(m_disambData[i].m_pX);
                        free(m_disambData[i].m_pCorrel);
                    }
                }
                
                void Init(int correlScaleFactor)
                {
                    m_pDsi = m_dsi->Buffer();
                    m_pScore = m_score->Buffer();
                    m_width = m_dsi->W();
                    m_height = m_dsi->H();
                    for(uint32_t i = 0; i < Threads_Agg; ++i) {
                        if (m_disambDataSize < m_width)
                        {
                           m_disambData[i].m_pX = (int32_t*)realloc(m_disambData[i].m_pX, m_width * sizeof(int32_t));
                           m_disambData[i].m_pCorrel = (ResultType_Agg*)realloc(m_disambData[i].m_pCorrel, m_width * sizeof(ResultType_Agg));
                        }
                        m_disambData[i].m_prevY = -1;
                    }
                    m_disambDataSize = m_width;
                    m_maxCorrelationPeakValue = m_maxCorrelationPeakValueNorm * correlScaleFactor;
                }

                void Finalize() {}

                inline void Store(Disparity d, Score s, uint32_t x, uint32_t y, uint32_t stripe)
                {
                    int index = y * m_width + x;
                    m_pDsi[index] = d;
                    m_pScore[index] = s;
                }

#ifdef DISPARITY_MIN_FUNC_TEST
                void Store(ResultType_Agg* pCorr, uint32_t x, uint32_t y, int d_min, int d_max, uint32_t stripe)
                {
                    
                    uint32_t index = y * m_width + x;
                    
                    if(d_max - d_min + 1 < m_minCorrelFunctionElementsNum) {

                        m_pDsi[index] =  DISPARITY_UNKNOWN;
                        m_pScore[index] = SCORE_UNKNOWN;
                        return;
                    }

//                     ResultType_Agg minSad = std::numeric_limits<ResultType_Agg>::max();
//                     int disp;
//                     for (int i = d_min; i <= d_max; ++i)
//                     {
//                         ResultType_Agg value = pCorr[i];
//                         if ( value < minSad)
//                         {
//                             minSad = value;
//                             disp = i;
//                         }
//                     }
// 
//                     m_pDsi[index] =  disp;
//                     m_pScore[index] = minSad;

                    
                    typedef typename boost::int_t< sizeof(ResultType_Agg)<<3 >::fast  DispType;
                    DispType bestDisp[4];
                    ResultType_Agg bestCorrel[4];

                    int minimum = minimization::minimize<Impl_Opt, ResultType_Agg, DispType>(pCorr, bestDisp, bestCorrel, d_min, d_max);

                    m_pDsi[index] = bestDisp[minimum];
                    m_pScore[index] =  bestCorrel[minimum];

                    return;
                }
#else
                void Store(ResultType_Agg* pCorr, uint32_t x, uint32_t y, int d_min, int d_max, uint32_t stripe)
                {
                    uint32_t index = y * m_width + x;
                    
                    if(d_max - d_min + 1 < m_minCorrelFunctionElementsNum) 
                      goto INVALID;

                    {
                        typedef typename boost::int_t< sizeof(ResultType_Agg)<<3 >::fast  DispType;
                        DispType bestDisp[4];
                        ResultType_Agg bestCorrel[4];

                        int minimum = minimization::minimize<Impl_Opt, ResultType_Agg, DispType>(pCorr, bestDisp, bestCorrel, d_min, d_max);

                        const int32_t disparity = bestDisp[minimum];
                        const ResultType_Agg correlation =  bestCorrel[minimum];
                        
                        if(m_filteringEnabled && correlation > m_maxCorrelationPeakValue) 
                            goto INVALID;

                        if(m_extraFilteringEnabled) {

                            int deltaDisp = 0;
                            ResultType_Agg deltaCorr = 0;

                            for(int z = 0; z < 4; ++z)
                                deltaDisp += std::abs(bestDisp[z] - disparity);

                            for(int z = 0; z < 4; ++z)
                                deltaCorr += bestCorrel[z] - correlation;

                            // distinctiveness and sharpness test

                            if(deltaDisp > m_maxCorrelationPeakDispersion || deltaCorr * m_minInvCorrelationPeakSharpness < correlation)  
                                goto INVALID;
                        }

                        // disambiguation
                        if(m_disambEnabled) {

                            DisambiguationData & disData = m_disambData[stripe];
                            if((int32_t)y > disData.m_prevY) {

                                disData.m_prevY = y;
                                
                                for(uint32_t i = 0; i < m_width; ++i) {
                            //       disData.m_pX[i] = 0;
                                    disData.m_pCorrel[i] = std::numeric_limits<ResultType_Agg>::max();
                                }
                            }

                            int32_t i = (int32_t)x + disparity;

                            if(correlation < disData.m_pCorrel[i]) {
                                
                                int32_t k = y * m_width + disData.m_pX[i];                            
                                if (disData.m_pCorrel[i] != std::numeric_limits<ResultType_Agg>::max()) {                           
                                m_pDsi[k] = DISPARITY_UNKNOWN;
                                m_pScore[k] = SCORE_UNKNOWN;
                                }
                                
                                disData.m_pX[i] = x;
                                disData.m_pCorrel[i] = correlation;
                            } else {
                                goto INVALID;
                            }
                        }

                        Disparity disp = (Disparity)disparity;

                        if(m_subpixelAccuracyEnabled && (disparity > d_min) && (disparity < d_max)) {

                            int y0, y2;

                            y0 = pCorr[disparity - 1];
                            y2 = pCorr[disparity + 1];
                            Disparity y1 = (Disparity)(2 * (y0 + y2 - 2 * (int)correlation));

                            if(y1)
                                disp += ((y0 - y2) / y1);
                        }

                        m_pDsi[index] = disp;
                        m_pScore[index] = correlation;
                    }
                    
                    return;
INVALID:                    
                    m_pDsi[index] = DISPARITY_UNKNOWN;
                    m_pScore[index] = SCORE_UNKNOWN;
                }
                #endif
                
            private:
                
                uint32_t m_width;
                uint32_t m_height;
                Disparity* m_pDsi;
                Score* m_pScore;
                double m_maxCorrelationPeakValue;

                uint32_t m_disambDataSize;
                struct DisambiguationData
                {
                    DisambiguationData() : m_prevY(-1), m_pX(NULL), m_pCorrel(NULL) {}
                    
                    int32_t m_prevY;
                    int32_t* m_pX;
                    ResultType_Agg* m_pCorrel;
                };
                
                DisambiguationData m_disambData[Threads_Agg];
        };
        
        template<typename ResultType_Agg, uint32_t Threads_Agg, typename ResultType_Opt, uint32_t Threads_Opt>
        class FilteredWTA<ResultType_Agg, Threads_Agg, ResultType_Opt, impl::Auto, Threads_Opt> : public FilteredWTA<ResultType_Agg, Threads_Agg, ResultType_Opt, impl::SIMD, Threads_Opt> {};
    }
}

#endif
