#ifndef _ALPHA_BETA_FILTER_H
#define _ALPHA_BETA_FILTER_H

#include <Eigen/Core>

namespace state_estimation {

  /** A simple alpha-beta filter 
   * 
   * Alpha-Beta filter observer position of an object and return a state with
   * (0) position, (1) speed
   */
  template<class _Scalar>
  class AlphaBetaFilter {
  public:
    typedef Eigen::Matrix<_Scalar,2,1> StateType;
    
  private:
    /// the state
    StateType m_state;
    /// the smoothing parameters
    _Scalar m_alpha, m_beta;
    
  public:
    
    AlphaBetaFilter() : m_alpha(1), m_beta(1) { }
    AlphaBetaFilter(_Scalar alpha, _Scalar beta) : m_alpha(alpha), m_beta(beta) { }
    
    
    StateType & State() { return m_state; }
    const StateType & State() const { return m_state; }
    
    /// Modify the Alpha parameters (position smoothing)
    _Scalar & Alpha() { return m_alpha; }
    /// Modify the Beta parameters (speed smoothing)
    _Scalar & Beta() { return m_beta; }
    
    /** Execute a Step of AlphaBeta filter */
    void Step(_Scalar x, _Scalar dt)
    {
      _Scalar dx = x - m_state(0);
      m_state(0) += m_alpha * dx;
      m_state(1) += m_beta * (dx / dt);
    }
  };

 
}

#endif
