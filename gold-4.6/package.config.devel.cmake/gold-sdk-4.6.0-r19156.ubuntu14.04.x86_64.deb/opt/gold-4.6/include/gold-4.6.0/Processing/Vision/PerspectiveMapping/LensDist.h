/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2009                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 *   Author: Medici Paolo (October 2004 - )                           *
 **********************************************************************/

#ifndef _LENS_DISTORTION_H
#define _LENS_DISTORTION_H

#include <memory>
#include <cmath>
#include <vector>

#include <Data/Math/Points.h> 
#include <Processing/Vision/PerspectiveMapping/gold_proc_pm_export.h>
#include <boost/scoped_ptr.hpp>



/** \file LensDist.h
 *  \brief Classe per accogliere le classi che gestiscono la distorsione delle lenti
 *
 * L'header e' abbastanza complesso. Contiene 3 classi per raccogliere e usare, usando 3 algoritmi diversi, equazioni
 *  polinomiali della lente:
 * - PolynomialDistortion  punto distorto in un punto dedistorto usando i K
 * - RPolynomialDistortion punto dedistorto in un punto distorto usando i K (lenta)
 * - IPolynomialDistortion punto dedistorto in un punto distorto usano i IK
 *
 * Tali classi devono essere associate a una ImageLUT (o StorableImageLUT) per generare LUT per l'immagine.
 *  Le LUT infatti ammettono come template un oggetto funzione per generare le LUT offline.
 **/

/// calcola il risultato del polinomio di distorsione
/// \f$ 1 + k_1 * x^2 + k_2 * x^4 + k_3 * x^6 + ... \f$ (se si usa il valore x^2 sole potenze pari, altrimenti tutte).
/// @param x2 il valore di x^2 per il polinomio diretto (o x per il polinomio inverso)
/// @param k una serie di coefficienti
/// @param size il numero di coefficienti
template<class T>
inline T evaluate_dpoly(T x2, const T *k, unsigned int size)
{
T y = T(0);
for(int i=size - 1;i>=0;i--)
  y = x2 * ( k[i] + y);
return T(1) + y;
}

#ifdef GSL_FOUND

#include <gsl/gsl_poly.h>

/// return the r_d that give requested r_u. Practically resolve the equation
///  \f$ r_d + k_1 r_d^3 + k_2 r_d^5 + ... - r_u = 0 \f$
double GOLD_PROC_PM_EXPORT dradius_invert(double ru, const double * k, unsigned int size);

 /// return the r_d that give requested r_u. Practically resolve the equation
///  \f$ r_d + k_1 r_d^3 + k_2 r_d^5 + ... - r_u = 0 \f$
class GOLD_PROC_PM_EXPORT RadiusInvert {
 double *a, *z;
 unsigned int cf, cs;
 gsl_poly_complex_workspace * w;
 public:
 // esegue i precalcoli
 /// @param k i coefficienti K
 /// @param size il numero di coefficienti
 RadiusInvert( const double * k, unsigned int size );
 
 GOLD_PROC_PM_EXPORT ~RadiusInvert();
 // esegue l'inversione
 double operator() (double ru);
};
#endif

/** Classe per gestire il modello matematico della distorsione della lente 
 *   che estende il modello di lente proposto da Tsai.
 *
 *  In generale la distorsione radiale della lente puo' venire espressa, usando Taylor, 
 *   \f$ r_u = r_d (1 + k_1 * r_d^2 + k_2 * r_d^4 + ...) \f$ 
 *  in cui sono presenti solo i termini pari in quanto la funzione incognita e' simmetrica.
 *  \f$ r_u \f$ e' il raggio un-distortto mentre \f$ r_d \f$ e' il raggio distorto e \f$ k_1,k_2,... \f$ 
 *    sono coefficienti da determinarsi.
 *
 *  I coefficienti sono normalizzati all'immagine, ovvero indipendenti da Width e Height, ma normalizzati
 *   rispetto alla diagonale.
 * 
 *  Questa classe permette di traformare punti distorti in punti non distorti e viceversa. Attenzione.
 *
 *  L'inversa usa un'altra serie di coefficienti (IK) normalmente piu' complessi dei K.
 *  NOTE: l'equazione inversa non e' ancora stata validata.
 **/
class PolynomialDistortion_t {
	public:
	double sdx,sdy; ///< fattore di zoom, normalizzazione e l'aspect ratio (distorted image)
	double sux,suy; ///< fattore di zoom, normalizzazione e l'aspect ratio (undistorted image)
	double cxu,cyu; ///< centro di distorsione ideale (immagine dedistorta) 
	double cxd,cyd; ///< centro di distorsione reale  (immagine distorta)

	std::vector<double> K;	///< Coefficienti della trasformazione diretta o inversa!
 
	public:
    PolynomialDistortion_t() : sdx(1.0), sdy(1.0), sux(1.0), suy(1.0) { }
//     PolynomialDistortion_t(const PolynomialDistortion_t & t) : sux(t.sux), suy(t.suy), cxu(t.cxu), cyu(t.cyu), cxd(t.cxd), cyd (t.cyd), K(t.K) { }
    
    /// riempie i parametri esaminando una stringa del tipo "0.0001 1.020 -0.900 ..."
    void Parse(const std::string & str);
    
    /// calcola il fattore di normalizzazione dell'immagine non distorta tale che 
    ///  i bordi dell'immagine distorta coincidano con i bordi dell'immagine dedistorta
    /// Sposta il centro in modo che l'immagine massimizzi la superficie visibile.
    /// Tale conto va fatto dopo aver calcolato i coefficienti, che comunque non li modifica.
    GOLD_PROC_PM_EXPORT void Normalize(double w, double h);

    /// reset the zoom level
    void Zoom(double sf=1.0)
    {
    	sux = suy = sf;
    }

    /// Setta i parametri usando come centro di distorsione e di dedistorsione il centro dell'immagine
    /// Applica anche un fattore di zoom (opzionale, altrimenti e' impostato a 1.0) sull'immagine dedistorta.
    void SetParams(unsigned int width, unsigned int height, double sf = 1.0)
        {
//         double s = 1.0/sqrt((double)width*width +(double) height*height);
//         sux=sdx = s * sf;
//         suy=sdy = s;
	sux = suy = sf;
	SetDistortionCenter(width * 0.5, height * 0.5);
	SetDeDistortionCenter(width * 0.5, height * 0.5);
        }

    /// Setta i parametri nel caso si voglia fare un resize dell'immagine.
    /// @param wu,hu width e height immagine undistorted
    /// @param wd,hd width e height immagine distorted
//     void setParams(unsigned int wu, unsigned int hu, unsigned int wd, unsigned int hd, double sfu = 1.0, double sfd = 1.0)
//         {
//         double su = 1.0/sqrt((double)wu*wu +(double) hu*hu);
//         double sd = 1.0/sqrt((double)wd*wd +(double) hd*hd);
//         sux= su * sfu;
//         suy= su;
//         sdx = sd * sfd;
//         sdy = sd;
//         
//         cxd = wd * 0.5;
//         cyd = hd * 0.5;
// 
//         cxu = wu * 0.5;
//         cyu = hu * 0.5;
//         }

    /// Change the Polynome order
    void SetPolynomeOrder(unsigned int order)
	{
	K.resize(order);
	}
	
    /// imposta il centro di distorsione reale
    void SetDistortionCenter(double _cx, double _cy)
	{
	cxd = _cx; cyd = _cy;
	}
    /// imposta il centro di dedistorsione target
    void SetDeDistortionCenter(double _cx, double _cy)
	{
	cxu = _cx; cyu = _cy;
	}
};

/// Classe che implementa due comportamenti, basati sui parametri K diretti, attraverso l'operator ()
///  - ImageLUT::Compute: questa classe usa i K per realizzare la LUT che AGGIUNGE distorsione all'immagine
///  - operator(): permette di convertire un punto distorto in un punto un-distorto. 
/// @see ImageLUT::ComputeSparse per ottenere comunque la trasformata inversa
///
/// \code
/// PolynomialDistortiond params;
///  params.setParams(width,height,width,height);
///  params.Parse(LeftCamera["POLY DIST"]);
/// ...
///  m_lut->ComputeSparse(params);
/// \endcode
template<typename R = double>
class PolynomialDistortion : public PolynomialDistortion_t { 
public:
    typedef math::Point2<R> return_type;
    /// usa la trasformazione diretta per convertire un punto distorto nel corrispondente punto dedistorto
    /// \f$ ru/rd = (1 + k_1 r_d^2 + k_2 r_d^4 + ...) \f$
    template<class T>
    return_type operator() (const math::Point2<T> &p) const
        {
        R x = (R(p.x) - cxd) * sdx;
        R y = (R(p.y) - cyd) * sdy;

        R ru = evaluate_dpoly(x*x + y*y, &K[0], K.size() );
        return return_type(
            cxu + (x * ru / sux),
            cyu + (y * ru / suy)
            );
        }


};

typedef PolynomialDistortion<double> PolynomialDistortiond;

#ifdef GSL_FOUND
/// Classe che implementa due comportamenti, basati sull'inversione in run-time dei K diretti:
///  - ImageLUT::Compute: questa classe usa i K per realizzare la LUT che rimuove la distorsione all'immagine
///  - operator(): permette di convertire un punto undistorto in un punto distorto.
/// Questa classe e' estremamente LENTA!
/// @see ImageLUT::Compute
template<typename R = double>
class RPolynomialDistortion : public PolynomialDistortion_t { 
    boost::scoped_ptr<RadiusInvert> I;
public:
    RPolynomialDistortion() { }
    RPolynomialDistortion(const PolynomialDistortion_t & p) : PolynomialDistortion_t(p)  { }
    ~RPolynomialDistortion() { }
    typedef math::Point2<R> return_type;
    
    /// Visto che per accelerare l'inversione della matrice sono richiesti dei precalcoli
    ///  e' necessario chiamare Computer prima di usare l'operator ()
    void Compute()
    {
     I.reset( new RadiusInvert(&K[0], K.size()) );
    }
    
    /// usa i coefficienti K e risolve un polinomio per trasformare i punti da dedistorti a distorti
    /// @note e' estremamente lenta (e con estremamente voglio dire estremamente)
    /// @see dradius_invert
    // Se $r_u = r_d f_{d}(r_d)$ esiste una funzione $g_u(r_u)$ tale che $r_d = g_{u}(r_{u})$. Visto che $\frac{x_u}{x_d}=\frac{r_u}{r_d}$ si ottiene
    template<class T>
    return_type operator() (const math::Point2<T> &p) const
        {
        // ricavo la x dedistorta
        R x = (R(p.x) - cxu) * sux;
        R y = (R(p.y) - cyu) * suy;
        // ru dedistorta
        R ru = std::sqrt(x*x + y*y);
        // inverto il polinomio per ottenere la r distorta
        // R rd = dradius_invert(ru, &K[0], K.size() ) / ru;
        R rd = (*I)(ru) / ru;
        // TODO: fare una LUT su ru sarebbe meno preciso, anche se piu' veloce
        return return_type (
                cxd + (x * rd / sdx),
                cyd + (y * rd / sdy)
                );
        }
};

typedef RPolynomialDistortion<double> RPolynomialDistortiond;
#endif

/// Classe che implementa due comportamenti, basati su IK (K inversi):
///  - ImageLUT::Compute: questa classe usa IK (K inversi) per realizzare la LUT che toglie la distorsione della lente
///  - operator(): permette di convertire un punto dedistorto in un punto distorto.
///
/// @see ImageLUT::Compute
template<typename R=double>
class IPolynomialDistortion : public PolynomialDistortion_t {
public:
    typedef math::Point2<R> return_type;
    /// usa i coefficienti K (IK) per calcolare la trasformazione da punto dedistorto a punto distorto
    /// \f$ rd/ru = (1 + k_1 r_u + k_2 r_u^2 + ...) \f$
    template<class T>
    return_type operator () (const math::Point2<T> &p) const
        {
        R x = (R(p.x) - cxu) * sux;
        R y = (R(p.y) - cyu) * suy;
        R rd = evaluate_dpoly(sqrt(x*x + y*y), &K[0], K.size() );
        return return_type (
                cxd + (x * rd / sdx),
                cyd + (y * rd / sdy)
                );
        }
};

typedef IPolynomialDistortion<double> IPolynomialDistortiond;


#endif // _DIST_LUT
