#ifndef _VEHICLE_TRANSFORMATION_H
#define _VEHICLE_TRANSFORMATION_H

#include <Data/Math/TMatrices.h>
#include <Data/Math/Points.h>

#include <Processing/Vehicle/Transformation/gold_proc_vehicle_transformation_export.h>


/** @file VehicleTransformation.h
  * @brief Modello di veicolo in moto rettilineo uniforme o in rotazione
  * @note the reference frame is a cartesian reference frame.
  *  Le funzioni che potrebbero tornare utili potrebbero essere:
  *   - convertire lo stesso punto mondo da coordinate veicolo dal tempo T0 alle coordinate veicolo nel tempo T1 (e viceversa) con il veicolo che si e' spostato
  *     PrevToCurrentTransformation e CurrentToPrevTransformation soddisfano questo requisito. ReferenceFrameTransformation e' una generalizzazione.
  *     VehicleTranslationK sono versioni particolari
  *   - convertire un punto stesso del veicolo dal tempo T0 al tempo T1 ? per sapere dove saranno i punti solidali del veicolo in un altro sistema di riferimento
  *     CurrentToNextVehicleTransformation
  * * @note le trasformazioni che proiettano i punti precedenti ai correnti, possono anche essere usate per proiettare i punti correnti a punti futuri
  * @note guardare affinemap.h per applicarle su una serie di punti e comporre trasformazioni
  */

/** Return the Affine Transformation to project previous point to current one
 *  Ritorna la matrice che permette di proiettare le coordinate mondo dei punti riferite all'istante di tempo precedente
 *   al corrente con il veicolo che si e' spostato ed e' ruotato a yawrate costante.
 *   Tale trasformazione ha significato anche per predire dove saranno i punti correnti nel futuro.
 *  Converte le coordinate dei punti mondo dal sistema di riferimento T[-1] al sistema di riferimento T[0]
 * @param yawrate vehicle (average) yaw-rate
 * @param speed   vehicle (average) speed
 * @param time    integration time
 * @note chiaramente se si applica tale matrice a una immagine (modo LUT) l'effetto sara' opposto
 * @note Il sistema di riferimento e' quello del centro di massa del veicolo (dove yawrate e speed sono misurate)
 * @note per esempio c'era un ostacolo in (x,y) al tempo precedente e voglio sapere quell'ostacolo nel fotogramma attuale dove si trova, altrimenti avevo un sensore in (x,y) e voglio sapere le coordinate di quel sensore nel fotogramma precedente rispetto a quello attutale
 **/
template<class T>
math::TMatrix<T,2,3> GOLD_PROC_VEHICLE_TRANSFORMATION_EXPORT PrevToCurrentTransformation(T yawrate, T speed, T time);

/** Return the Affine Transformation to project previous point to current one
 *  Ritorna la matrice che permette di proiettare i punti mondo dell'istante di tempo precedente all'attuale
 * @param yawrate vehicle (average) yaw-rate
 * @param speed   vehicle (average) speed
 * @param time    integration time
 * @param rot_axis Rotation Point (for example c.g.) on local coordinates. The projection of ICR on X axis.
 * @note chiaramente se si applica tale matrice a una immagine (modo LUT) l'effetto sara' opposto
 **/
template<class T>
math::TMatrix<T,2,3> GOLD_PROC_VEHICLE_TRANSFORMATION_EXPORT PrevToCurrentTransformation(T yawrate, T speed, T time, const math::Point2<T> & rot_axis);


/** Return the Affine Transformation to project current point to previous one 
 * Ritorna la matrice che permette di proiettare i punti dell'istante di tempo attuale su uno precedente con un veicolo
 *  che si sposta a velocita' e ruota a velocita' costanti.
 *  Converte le coordinate dei punti dal sistema di riferimento T[0] al sistema di riferimento T[-1]
 * @param yawrate vehicle (average) yaw-rate
 * @param speed   vehicle (average) speed
 * @param time    integration time
 * @note chiaramente se si applica tale matrice a una immagine (modo LUT) l'effetto sara' opposto
 * @note e' la funzione inversa di PrevToCurrentTransformation
 * @note per esempio permette di trasformare le coordinate di un ostacolo acquisito a questo fotogramma alle coordinate dell'ostacolo in un tempo precedente con il veicolo in moto (allo stesso modo permette di trasformare punti del veicolo per esempio sensori dove erano in istanti di tempo precedente).
 **/
template<class T>
math::TMatrix<T,2,3> GOLD_PROC_VEHICLE_TRANSFORMATION_EXPORT CurrentToPrevTransformation(T yawrate, T speed, T time);

/** Return the Affine Transformation to project a current world point to previous one
 * Ritorna la matrice che permette di proiettare i punti dell'istante di tempo attuale su uno precedente
 * @param yawrate vehicle (average) yaw-rate
 * @param speed   vehicle (average) speed
 * @param time    integration time
 * @param rot_axis Rotation Point (for example c.g.) on local coordinates. The projection of ICR on X axis.
 * @note chiaramente se si applica tale matrice a una immagine (modo LUT) l'effetto sara' opposto
 * @note e' la funzione inversa di PrevToCurrentTransformation
 */
template<class T>
math::TMatrix<T,2,3> GOLD_PROC_VEHICLE_TRANSFORMATION_EXPORT CurrentToPrevTransformation(T yawrate, T speed, T time, const math::Point2<T> & rot_axis);

/** Return the Affine Transformation to transform point in Reference Frame 1 to a point in Reference Frame 2
 * Ritorna la matrice per la trasformazione affine per passare dalle coordinate del sistema di riferimento 1
 *  al sistema di riferimento 2 (rispetto a un terzo sistema di riferimento chiamato globale)
 * @param O1       Vehicle position in the first reference frame in the global reference
 * @param Angle1   Vehicle orientation in the first reference frame in the global reference
 * @param O2       Vehicle position in the second reference frame in the global reference
 * @param Angle2   Vehicle orientation in the second reference frame in the global reference
 * @note chiaramente se si applica tale matrice a una immagine (modo LUT) l'effetto sara' opposto
 **/
template<class T>
math::TMatrix<T,2,3> GOLD_PROC_VEHICLE_TRANSFORMATION_EXPORT ReferenceFrameTransformation(const math::Point2<T> & O1, T Angle1, const math::Point2<T> & O2, T Angle2);

/** Return the Affine Transformation to project vehicle current point coordinate to future point in current reference frame
 *  Ritorna la matrice che permette di proiettare i punti del veicolo dell'istante di tempo corrente al futuro
 *   Converte le coordinate dei punti dal sistema di riferimento T[0] al sistema di riferimento T[1]
 * La matrice ritornata applica una rotazione intorno al @a irc di un angolo @a yaw
 *  permette di sapere dove sara' un punto SOLIDALE con il veicolo (un sensore per esempio) nell'istante di tempo futuro
 *  rispetto al sistema di riferimento corrente.
 * @param yaw   delta yaw: yaw variation
 * @param irc   istantaneos rotation center
 * @note is the same equation of an affine rotation matrix with @a irc rotation point and @a yaw angle
 * @note yaw = spazio_percorso * curvatura e irc=( 1/k, centro_di_massa_y)
 * @note la trasformazione inversa permette di trasformare punti solidali al veicolo all'istante corrente a
 *       dove erano nel tempo precedente.
 * @warning unimplemented (ma serve?)
 **/
template<class T>
math::TMatrix<T,2,3> GOLD_PROC_VEHICLE_TRANSFORMATION_EXPORT CurrentToNextVehicleTransformation(T yaw, const math::Point2<T> & irc);

/** Return the delta movement of vehicle in the reference frame
 * @param yaw0 initial vehicle angle (compared to reference frame where yaw=0.0 is on X axis)
 * @param yawrate rotation speed (rad/s)
 * @param speed vehicle speed (in current measure unit, m/s)
 * @param time time (seconds)
 **/
template<class T>
math::Point2<T> GOLD_PROC_VEHICLE_TRANSFORMATION_EXPORT VehicleTranslation(T yaw0, T yawrate, T speed, T time);

/** Return the delta movement of vehicle in the reference frame when initial heading is 0
 * @param yawrate rotation speed (rad/s)
 * @param speed vehicle speed (in current measure unit, m/s)
 * @param time time (seconds)
 **/
template<class T>
math::Point2<T> GOLD_PROC_VEHICLE_TRANSFORMATION_EXPORT VehicleTranslation(T yawrate, T speed, T time);

/** Return the delta movement of vehicle (c.g) in the reference frame when initial heading is 0, curvature based.
 *  Calcola lo spostamento del centro di massa di un veicolo nel sistema di riferimento corrente.
 * @param yaw0 initial vehicle angle (compared to reference frame: 0.0 is X axis)
 * @param curvature curvature (rad/m)
 * @param s space (m)
 * @note yaw1 = yaw0 + s * curvature
 **/
template<class T>
math::Point2<T> GOLD_PROC_VEHICLE_TRANSFORMATION_EXPORT VehicleTranslationK(T yaw0, T curvature, T s);

#endif

