#ifndef _CIMAGE_BASIC_OPERATIONS_H
#define _CIMAGE_BASIC_OPERATIONS_H

  /** \file BasicOperations.h
   *  \author Vislab
   *  \brief This file contains basic operations on typed images
   *
   *  Basic operations include Resampling, Panning Rotation
   *  \ref cimagebasicop
   */

#include <Data/CImage/TImage.h>
#include <Data/CImage/CImageFlag.h>
// #include <Libs/Logger/Log.h>
#include <Processing/Vision/CImage/gold_proc_cimage_export.h>


/// Geometric operations
/*
      if(m_Degrees-90.0<0.001)
      else if(m_Degrees+90.0<0.001)
      else if(m_Degrees+180.0<0.001||m_Degrees-180.0<0.001)

virtual DECLSPEC_DEPRECATED CImage&  Rotate ( double Angle, ANGLE_UNIT unit=DEGREES ) = 0;
virtual DECLSPEC_DEPRECATED CImage&  Rotate ( double Xc, double Yc, double Angle, ANGLE_UNIT unit=DEGREES ) = 0;
      /// Geometric Operations

  virtual DECLSPEC_DEPRECATED CImage& operator *= ( const double factor ) = 0;
  virtual DECLSPEC_DEPRECATED CImage& operator += ( const double factor ) = 0;

  virtual DECLSPEC_DEPRECATED CImage& operator += ( const CImage& Image ) = 0;
  virtual DECLSPEC_DEPRECATED CImage& operator -= ( const CImage& Image ) = 0;
  virtual DECLSPEC_DEPRECATED CImage& operator *= ( const CImage& Image ) = 0;
  virtual DECLSPEC_DEPRECATED CImage& operator /= ( const CImage& Image ) = 0;

  // virtual void operator ~() = 0;
  virtual DECLSPEC_DEPRECATED CImage& operator& = ( const CImage& Image )  = 0;
  virtual DECLSPEC_DEPRECATED CImage& operator |= ( const CImage& Image )  = 0;
  virtual DECLSPEC_DEPRECATED CImage& operator ^= ( const CImage& Image )  = 0;
// TODO: portare all'esterno

/// Operators
// template<class S>
DECLSPEC_DEPRECATED TImage<T>& operator *= ( const double Factor );

// template<class S>
DECLSPEC_DEPRECATED TImage<T>& operator += ( const double Factor );

///
DECLSPEC_DEPRECATED TImage<T>& operator += ( const TImage<T>& Image );
DECLSPEC_DEPRECATED TImage<T>& operator -= ( const TImage<T>& Image );
DECLSPEC_DEPRECATED TImage<T>& operator *= ( const TImage<T>& Image );
DECLSPEC_DEPRECATED TImage<T>& operator /= ( const TImage<T>& Image );

// CImage version
DECLSPEC_DEPRECATED TImage<T>& operator += ( const CImage& Image )
{ return ( *this ) +=static_cast<const TImage<T>& > ( Image );}
DECLSPEC_DEPRECATED TImage<T>& operator -= ( const CImage& Image )
{ return ( *this )-=static_cast<const TImage<T>& > ( Image );}
DECLSPEC_DEPRECATED TImage<T>& operator *= ( const CImage& Image )
{ return ( *this ) /=static_cast<const TImage<T>& > ( Image );}
DECLSPEC_DEPRECATED TImage<T>& operator /= ( const CImage& Image )
{ return ( *this ) /=static_cast<const TImage<T>& > ( Image );}

// operatori logici
// void operator ~();
DECLSPEC_DEPRECATED TImage<T>& operator& = ( const TImage<T>& Image );
DECLSPEC_DEPRECATED TImage<T>& operator |= ( const TImage<T>& Image );
DECLSPEC_DEPRECATED TImage<T>& operator ^= ( const TImage<T>& Image );

// void operator ~() { return ~static_cast<const TImage<T>&  >(*this); }
DECLSPEC_DEPRECATED TImage<T>& operator& = ( const CImage& Image )
{ return ( *this )& =static_cast<const TImage<T>& > ( Image );}
DECLSPEC_DEPRECATED TImage<T>& operator |= ( const CImage& Image )
{ return ( *this ) |=static_cast<const TImage<T>& > ( Image );}
DECLSPEC_DEPRECATED TImage<T>& operator ^= ( const CImage& Image )
{ return ( *this ) ^=static_cast<const TImage<T>& > ( Image );}

// TImage A(320, 240, OriginalData); // copia l'immagine originale
// TImage B, C, D, E;
// A.Operation1();
// A.OperationN();
// B=A.OperationN1();  // A viene mantenuto e copiato in B
// B.Operation();
// *B...
// void ShiftHorizontally(int HShift) {}
// TImage& ShiftVertically(int VShift, bool BlackBG);
DECLSPEC_DEPRECATED TImage& Pan_UnFilled ( PosType x, PosType y );
DECLSPEC_DEPRECATED TImage& Pan ( PosType x, PosType y );
DECLSPEC_DEPRECATED TImage& Pan ( PosType x, PosType y, const PixelType& bg );
DECLSPEC_DEPRECATED TImage& Rotate ( double Angle, ANGLE_UNIT unit );
DECLSPEC_DEPRECATED TImage& Rotate ( double Xc, double Yc, double Angle, ANGLE_UNIT unit );

DECLSPEC_DEPRECATED TImage& Clear();
*/

namespace cimage
{

  GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( BILINEAR_INTERPOLATION );
  GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( TRILINEAR_INTERPOLATION );
  GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( RESAMPLE );
  GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( NEAREST );
  GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( DOWNSAMPLE_2X );

  // NOTE: namespace basic_ops ??
  // NOTE: dividere le base dalle tipate?

  template <typename T>
  GOLD_PROC_CIMAGE_EXPORT void Fill ( TImage<T>& Image, T Value );
  GOLD_PROC_CIMAGE_EXPORT void Fill ( CImage& Image, int Value );

  template <typename T>
  GOLD_PROC_CIMAGE_EXPORT void Clear ( TImage<T>& Image );

  template <typename T>
  GOLD_PROC_CIMAGE_EXPORT void Copy ( const TImage<T>& src, TImage<T>& dst );
  GOLD_PROC_CIMAGE_EXPORT void Copy ( const CImage& src, CImage& dst );

  template <typename T>
  GOLD_PROC_CIMAGE_EXPORT void Copy ( const void *srcImage, TImage<T>& dst );
  GOLD_PROC_CIMAGE_EXPORT void Copy ( const void *srcImage, CImage& dst );

  template <typename T>
  GOLD_PROC_CIMAGE_EXPORT void Copy ( const TImage<T>& src, void *dstImage );
  GOLD_PROC_CIMAGE_EXPORT void Copy ( const CImage& src, void *dstImage );

  template <typename T>
  GOLD_PROC_CIMAGE_EXPORT void Resize ( TImage<T>& Img, SizeType W, SizeType H );
  GOLD_PROC_CIMAGE_EXPORT void Resize ( CImage& Img, SizeType W, SizeType H );

  template <typename T>
  GOLD_PROC_CIMAGE_EXPORT void Resample ( const TImage<T>& src, TImage<T>& dst, const CImageFlag& how );
  GOLD_PROC_CIMAGE_EXPORT void Resample ( const CImage& src, CImage& dst, const CImageFlag& how );

  template <typename T>
  GOLD_PROC_CIMAGE_EXPORT void Crop ( const TImage<T>& src, TImage<T>& dst, PosType left, PosType top, PosType right, PosType bottom, bool keep_size );
  GOLD_PROC_CIMAGE_EXPORT void Crop ( const CImage& src, CImage& dst, PosType left, PosType top, PosType right, PosType bottom, bool keep_size );
  
  template <typename T>
  GOLD_PROC_CIMAGE_EXPORT void Pan ( const TImage<T>& src, TImage<T>& dst, PosType x, PosType y );

  // FIXME: qui deve ricevere solo TImage<T>::PixelType al posto di T
  template <typename T, typename P>
  GOLD_PROC_CIMAGE_EXPORT void Pan ( const TImage<T>& src, TImage<T>& dst, PosType x, PosType y, const P& bg );

  template <typename T>
  GOLD_PROC_CIMAGE_EXPORT void Rotate ( const TImage<T>& src, TImage<T>& dst, double angle, ANGLE_UNIT unit );
  GOLD_PROC_CIMAGE_EXPORT void Rotate ( const CImage& src, CImage& dst, double angle, ANGLE_UNIT unit );

  template <typename T>
  GOLD_PROC_CIMAGE_EXPORT void RotateC ( const TImage<T>& src, TImage<T>& dst, double xc, double yc, double angle, ANGLE_UNIT unit );
  GOLD_PROC_CIMAGE_EXPORT void RotateC ( const CImage& src, CImage& dst, double xc, double yc, double angle, ANGLE_UNIT unit );
  
  template <typename T>
  GOLD_PROC_CIMAGE_EXPORT void DeInterlace_OddField ( const TImage<T>& src, TImage<T>& dst);
  GOLD_PROC_CIMAGE_EXPORT void DeInterlace_OddField ( const CImage& src, CImage& dst);
  

  /**
    * Effettua un passo di combinazione lineare
    * dst += a_i*src_i;
    * @param src_i i-esima immagine della combinazione
    * @param a_i fattore per cui viene moltiplicata src_i
    * @param dst immagine destinazione
    * @return true se A e B sono dello stesso tipo, false altrimenti
    */
  template <typename T>
  GOLD_PROC_CIMAGE_EXPORT void LinComb(const TImage<T>& src_i, double a_i, TImage<T>& dst);
  GOLD_PROC_CIMAGE_EXPORT void LinComb(const CImage& src_i, double a_i, CImage& dst);

  template <typename T>
  GOLD_PROC_CIMAGE_EXPORT bool IsEmpty(const TImage<T>& image);
  GOLD_PROC_CIMAGE_EXPORT bool IsEmpty(const CImage& image);

  template<typename T> T& cast(CImage& image) { return static_cast<T& > ( image ); }

  /**
    * Permette di verificare se due immagini sono dello stesso tipo
    * @param A una CImage
    * @param B un'altra CImage
    * @return true se A e B sono dello stesso tipo, false altrimenti
    */
  template<typename T> bool HaveSameType(CImage& a, T& b) { return typeid ( a ) == typeid ( b ); }
  template<typename T> bool HaveSameType(CImage& a) { return typeid ( a ) == typeid ( T ); }

  inline bool HaveSameType ( CImage& a, CImage& b ) { return typeid ( a ) == typeid ( b ); }
  inline bool HaveSameType ( const CImage& a, const CImage& b ) { return typeid ( a ) == typeid ( b ); }

}


#endif


