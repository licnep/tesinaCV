#ifndef _CIMAGE_STATISTICS_REGISTRATION_H
#define _CIMAGE_STATISTICS_REGISTRATION_H

#include <map>

#include <Libs/Patterns/Singleton.h>

#include <Data/CImage/CImage.h>
// Procedura per aggiungere una operazione
// Statistics_Registration.h:
// 1. Aggiungere la mappa con il prototipo opportuno in cimage::impl::FunctionMatrix
// 2. Aggiungere la registrazione delle funzione sulle CImage in FunctionMatrix::Register
// 3. Aggiungere la macro di dichiarazione delle funzioni sulle TImage
// Statistics.h:
// 5. Aggiungere il prototipo dell'operazione sulle TImage e CImage
// Statistics.hxx:
// 6. Aggiungere il codice dell'operazione su TImage
// Statistics_MySpecializedImage.h:
// 6. Aggiungere il codice dell'operazione specializzato per una TImage specifica
// Statistics.cpp:
// 7. Aggiungere il codice dell'operazione su CImage (lookup nella mapppa e chiamata)




namespace cimage
{
  namespace impl
  {
    class Statistics_FnMtx // :
          // public vl::Singleton<Statistics_FnMtx>
    {
      public:

        template<typename PB, typename PC>
        void __reg ( std::map<CImage::Type, PB >&map, CImage::Type img_type, PC f )
        {
          // std::cout << "registering" << "???"
          // << img_type.name() << "@" << ( void* ) f
          //<< " " << typeid ( f ).name() <<  __FILE__<< __LINE__ << std::endl;
          map.insert ( std::make_pair ( img_type, reinterpret_cast<PB> ( f ) ) );
        }

      public:

        std::map<CImage::Type, cimage::StatisticType ( * ) ( const CImage&, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int ) >  map_Mean;
        // Add other maps here

        template<typename T>
        bool Register ()
        {
          cimage::StatisticType ( *pMean ) ( const T&, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int ) ;
          pMean  = cimage::Mean<typename T::PixelType>;
          __reg( map_Mean,  T::type_info(),  pMean);

          // void ( *pCopy ) ( const T&, T& );
          // pCopy = Copy<typename T::PixelType>;
          // __reg ( map_Copy,      typeid ( T ), pCopy );

          // Add other functions here
          return true;
        }
    };

    // Declaration macro. Aggiunge le dichiarazioni delle operazioni su una TImage
#define CIMAGE__DECLARE_STATISTICS(I)\
         template GOLD_PROC_CIMAGE_EXPORT  cimage::StatisticType Mean<I::PixelType > ( const I&, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int );

    // Registration macro registra le operazioni specifiche nella matrice delle operazioni su CImage
#define CIMAGE__REGISTER_STATISTICS(I)\
      static bool __fun_reg_##I=vl::Singleton<Statistics_FnMtx>::Instance().Register<I>();
  }
}

#endif

