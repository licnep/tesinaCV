#ifndef _DRAW_BRUSHES_H
#define _DRAW_BRUSHES_H

/** @file Brushes.h
 *  @brief API to define brushes
 * */

namespace draw {

/** \ingroup Draw
 * An opaque brush 
 * 
 * A unsigned char policy of a brush who set to 255 the elements.
 * \code
 * draw::Opaque<unsigned char>(myBuffer, width, height, 255);
 * draw::Opaque<unsigned char>(myCImageMono8, 255);
 * \endcode
 * 
 */
template<class T>
class Opaque {
  T *m_ptr;
  int m_width;
  long m_stride;
  int m_height;
  T m_value;
  public:
    Opaque(T *ptr, int width, int height, T value) : m_ptr(ptr), m_width(width), m_stride(width), m_height(height), m_value(value) { }
    Opaque(cimage::TImage<T> & img, T value) : m_ptr(img.Buffer()), m_width(img.W()), m_stride(img.W()), m_height(img.H()), m_value(value) { }
    
    /** Without boundaries check */
    void FillPixel(int x, int y) const
    {
      m_ptr[ x + y * m_stride] = m_value;
    }

    void FillLine(int x0, int x1, int y) const
    {
      T *dst = m_ptr + y * m_stride;
      for(int i = x0;i<=x1;++i)
	  dst[i] = m_value;
    }
    
    int W() const { return m_width; }
    int H() const { return m_height; }
    
    /** with boundaries check */
    void operator() (int x, int y) const
    {
      if((x>=0)&&(y>=0)&&(x<m_width)&&(y<m_height))
      {
	  FillPixel(x,y);
      }
    }
};

/** \ingroup Draw
 * Additive brush: add the new data over existing 
 * 
 * Increase accumuleator of +1
 * \code
 * draw::Opaque<unsigned char>(myBuffer, width, height, 1);
 * draw::Opaque<unsigned char>(myCImageMono8, 1);
 * \endcode
 * 
 * @note Clamp is not implemented
 */
template<class T>
class Additive {
  T *m_ptr;
  int m_width;
  long m_stride;
  int m_height;
  T m_value;
  public:
    Additive(T *ptr, int width, int height, T value) : m_ptr(ptr), m_width(width), m_stride(width), m_height(height), m_value(value) { }
    Additive(cimage::TImage<T> & img, T value) : m_ptr(img.Buffer()), m_width(img.W()), m_stride(img.W()), m_height(img.H()), m_value(value) { }

    /** With optimized boundaries check */
    void FillPixel(int x, int y)
    {
      m_ptr[ x + y * m_stride] += m_value;
    }

    void FillLine(int x0, int x1, int y)
    {
      T *dst = m_ptr + y * m_stride;
      for(int i = x0;i<=x1;++i)
	  dst[i] += m_value;
    }

    int W() const { return m_width; }
    int H() const { return m_height; }

    /** no boundaries check */
    void operator() (int x, int y)
    {
      if((x>=0)&&(y>=0)&&(x<m_width)&&(y<m_height))
      {
	  FillPixel(x,y);
      }
    }
};

/** \ingroup Draw
 * Blend the new data over existing 
 * 
 * Blend a shade of gray (192) at 50% (127)
 * \code
 * draw::Transparent<unsigned char>(myBuffer, width, height, 192, 127);
 * draw::Transparent<unsigned char>(myCImageMono8, 192, 127);
 * \endcode
 * 
 * Blend a shade of gray (0) at 25% (63)
 * \code
 * draw::Transparent(myBuffer, width, height, 0, 63);
 * \endcode
 * 
 * @note blend_factor is a integer range from 0 to 255. (0: totally transparent, 255: totally opaque).
 */
template<class T>
class Transparent {
  T *m_ptr;
  int m_width;
  long m_stride;
  int m_height;
  int m_blend_factor;
  int m_value;
  public:
    Transparent(T *ptr, int width, int height, T value, int blend_factor) : m_ptr(ptr), m_width(width), m_height(height), m_blend_factor(255-blend_factor), m_value(value*blend_factor) { }
    Transparent(cimage::TImage<T> & img, T value, int blend_factor) : m_ptr(img.Buffer()), m_width(img.W()), m_stride(img.W()), m_height(img.H()), m_blend_factor(255-blend_factor), m_value(value*blend_factor) { }

    /** With optimized boundaries check */
    void FillPixel(int x, int y)
    {
      m_ptr[ x + y * m_stride] = (m_ptr[ x + y * m_stride] * m_blend_factor + m_value)>>8;
    }

    void FillLine(int x0, int x1, int y)
    {
      T *dst = m_ptr + y * m_stride;
      for(int i = x0;i<=x1;++i)
	  dst[i] = (dst[i] * m_blend_factor + m_value)>>8;
    }

    int W() const { return m_width; }
    int H() const { return m_height; }

    /** no boundaries check */
    void operator() (int x, int y)
    {
      if((x>=0)&&(y>=0)&&(x<m_width)&&(y<m_height))
      {
	  FillPixel(x,y);
      }
    }
};


}

#endif
