/** @file Affine.h
  * @brief funzioni per applicare trasformazioni lineari (affini) su CImage
  * @author Paolo Medici
  **/
#ifndef _AFFINE_TRANSFORMATION_APPLIER_H
#define _AFFINE_TRANSFORMATION_APPLIER_H

#include <Data/CImage/CImage.h>
#include <Data/Math/TMatrices.h>
#include <Processing/Vision/CImage/Transformations/Interpolate.h>

namespace transformation {

/** Applica una trasformazione affine basata su matrice al buffer
 * @note usare i float. i double avrebbero un decadimento sensibile delle prestazioni senza
 *       alcun aumento di precisione. usare altrimenti i fixed_point
 *
 * \code
 * transformation::Affine<float, BilinearInterpolate>(dest, source, width, height, matrix);
 * \endcode
 *
 * Applica una trasformazione affine basata su matrice alle CImage
 * La trasformazione affine 
 * @note la matrice deve essere una matrice Affine. L'uso di matrici omografiche come input, anchse se permesso
 *       potrebbe dare risultati inattesi, normalmente non corretti se m[6]!=0.0 & m[7]!=0.0 (piccole variazioni prospettiche)
 * @note usare i float. i double avrebbero un decadimento sensibile delle prestazioni senza
 *       alcun aumento di precisione. usare altrimenti i fixed_point.
 *
 * \code
 * transformation::Affine<float> filter(M);
 * filter(source, dest);
 * \endcode
 *
 * \code
 * transformation::Affine<float> filter(M);
 * filter(source, dest);
 * \endcode
 *
 * \code
 *  transformation::Affine<float,NearestInterpolate> filter;
 * \endcode
 *
 * @note 
 *  Su immagini 640x300 BW su Pentium4HT 3.2Ghz
 *   BilinearInterpolate impiega circa 17msec,
 *   NearestInterpolate impiega circa 6msec.
 *  Su immagini 640x480 RGB su Pentium4HT 3.2Ghz
 *   BilinearInterpolate impiega circa 35msec,
 *   NearestInterpolate impiega circa 13msec.
 **/
template<typename R, class X>
class Affine: public math::TMatrix<R,2,3>, public X
{
    public:
    typedef math::TMatrix<R,2,3> matrix_t;
    public:
    Affine()  {}
    Affine(const matrix_t & m) : matrix_t(m) { }
    template<class S>
    explicit Affine(const S * s) : matrix_t(s) { }

template<typename T>
void operator()(T *dest,
                const T *source,
                unsigned int out_width,
                unsigned int out_height,
                unsigned int in_width,
                unsigned int in_height) const
{
    const R *matrix = this->get();

    R x0,y0;
    /* codice originale (non ottimizzato)
    x = matrix[0] * i + matrix[1] * j + matrix[2];
    y = matrix[3] * i + matrix[4] * j + matrix[5];
    */    
    x0 = matrix[2];
    y0 = matrix[5];
    for(unsigned int j=0;j<out_height;j++)
    {
        R x,y;
        x = x0;
        y = y0;
        for(unsigned int i=0;i<out_width;i++)
        {
            *dest = X::operator()(source, in_width, in_height, x, y);
            dest++;
            x+= matrix[0];
            y+= matrix[3];
        }
        x0+=matrix[1];
        y0+=matrix[4];
    }
}

/**
* @brief Applica la trasformazione lineare tra le due immagini
* @param input  Immagine di input
* @param output Immagine di output
*/
template<typename T>
void operator() (const cimage::TImage<T>& input, cimage::TImage<T>& output) const
    {
    this->operator() (output.Buffer(), input.Buffer(),
		output.W(),output.H(),
		input.W(),input.H() );
    }
};

}


#endif
