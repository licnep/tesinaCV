#ifndef _UI_WINDOW_H
#define _UI_WINDOW_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2011                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/


/**
 * \file UI_Window.h
 * \author Paolo Zani (zani@vislab.it)
 * \date 2011-02-08
 */

#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/Window/Params.h>

#include <UI/Panel/Panel.h>

namespace disparity
{
    // forward declarations

    namespace agg
    {
        template<typename ResultType_Cost, typename _ResultType_Agg, typename Impl_Agg, uint32_t _Threads_Agg>
        class Window_Simple;
        
        template<typename ResultType_Cost, typename _ResultType_Agg, typename Impl_Agg, uint32_t _Threads_Agg>
        class Window_SemiIncremental;
        
        template<typename ResultType_Cost, typename _ResultType_Agg, typename Impl_Agg, uint32_t _Threads_Agg>
        class Window_Incremental;        
    }

    template<typename Aggregation, typename Engine>
    class UI_Aggregation;

    template<typename ResultType_Cost, typename ResultType_Agg, typename Impl_Agg, uint32_t Threads_Agg, typename Engine>
    class UI_Aggregation<agg::Window_Simple<ResultType_Cost, ResultType_Agg, Impl_Agg, Threads_Agg>, Engine>
    {
        public:
        
            UI_Aggregation(Engine* _this) : m_this(_this) {}
            
            void Init(INIFile* pIni)
            {
                ui::var::Range<double> minVariance(&m_this->m_minVariance, 0.0, 1.0, 0.01);
                ui::var::Range<double> minSum(&m_this->m_minSum, 0.0, 200.0, 0.1);
                ui::var::Map<int32_t> textureAlgo(&m_this->m_textureAlgo,
                                                std::make_pair("Variance", WindowParams::VARIANCE),
                                                std::make_pair("Sum", WindowParams::SUM));
                ui::var::Range<uint32_t> winWidth(&m_this->m_winWidth, 3, 50, 1);
                ui::var::Range<uint32_t> winHeight(&m_this->m_winHeight, 3, 50, 1);

                ui::conf::Configuration conf(pIni);
                
                conf.Bind(minVariance, "MIN VARIANCE", 0.1);
                conf.Bind(minSum, "MIN SUM", 30.0);

                conf.Bind(textureAlgo, "TEXTURE ALGO", int32_t(WindowParams::VARIANCE));
                conf.Bind(winWidth, "WINDOW WIDTH", 3U);
                conf.Bind(winHeight, "WINDOW HEIGHT", 3U);
        
                m_panel
                (
                    ui::wgt::VBoxSizer("Texture").Border(3)
                    (
                        ui::wgt::GridSizer().Border(3)
                        (
                            ui::wgt::SzCell(0, 0)( ui::wgt::Text("Algo") ), ui::wgt::SzCell(0, 1).HExpand()( ui::wgt::ComboBox(textureAlgo) ),
                            ui::wgt::SzCell(1, 0)( ui::wgt::Text("Min Sum") ), ui::wgt::SzCell(1, 1).HExpand()( ui::wgt::Slider(minSum) ),
                            ui::wgt::SzCell(2, 0)( ui::wgt::Text("Min Variance") ), ui::wgt::SzCell(2, 1).HExpand()( ui::wgt::Slider(minVariance) )
                        ),
                        ui::wgt::Spacer(5),
                        ui::wgt::VBoxSizer("Correlation Window").Border(3)
                        (
                            ui::wgt::GridSizer().Border(3)
                            (
                                ui::wgt::SzCell(0, 0)( ui::wgt::Text("Width") ), ui::wgt::SzCell(0, 1).HExpand()( ui::wgt::Slider(winWidth) ),
                                ui::wgt::SzCell(1, 0)( ui::wgt::Text("Height") ), ui::wgt::SzCell(1, 1).HExpand()( ui::wgt::Slider(winHeight) )
                            )
                        )
                    )
                );
            }

            inline std::string Name() { return "Window Aggregation"; }

            inline ui::wgt::Widget Panel() { return m_panel; }
            
        private:
            
            Engine* m_this;
            ui::wgt::VSizer m_panel;
    };

    template<typename ResultType_Cost, typename ResultType_Agg, typename Impl_Agg, uint32_t Threads_Agg, typename Engine>
    class UI_Aggregation<agg::Window_SemiIncremental<ResultType_Cost, ResultType_Agg, Impl_Agg, Threads_Agg>, Engine> :
        public UI_Aggregation<agg::Window_Simple<ResultType_Cost, ResultType_Agg, Impl_Agg, Threads_Agg>, Engine> { public: UI_Aggregation(Engine* _this) : UI_Aggregation<agg::Window_Simple<ResultType_Cost, ResultType_Agg, Impl_Agg, Threads_Agg>, Engine>::UI_Aggregation(_this) {} };

    template<typename ResultType_Cost, typename ResultType_Agg, typename Impl_Agg, uint32_t Threads_Agg, typename Engine>
    class UI_Aggregation<agg::Window_Incremental<ResultType_Cost, ResultType_Agg, Impl_Agg, Threads_Agg>, Engine> :
        public UI_Aggregation<agg::Window_Simple<ResultType_Cost, ResultType_Agg, Impl_Agg, Threads_Agg>, Engine> { public: UI_Aggregation(Engine* _this) : UI_Aggregation<agg::Window_Simple<ResultType_Cost, ResultType_Agg, Impl_Agg, Threads_Agg>, Engine>::UI_Aggregation(_this) {} };
}

#endif
