#ifndef _CANNY_EDGE_DETECTOR_H
#define _CANNY_EDGE_DETECTOR_H

/** @file 
 * @note UNIMPLEMENTED
 * */

#include <Data/CImage/TImage.h>

namespace cimage {
  namespace filter {

/** Trova Edge di Canny
 * @todo unimplemented yet
 **/
class CannyEdgeDetector {
 
  public:
/**    
  *   sigma = The standard deviation of the gaussian smoothing filter.
  *   tlow  = Specifies the low value to use in hysteresis. This is a 
  *           fraction (0-1) of the computed high threshold edge strength value.
  *   thigh = Specifies the high value to use in hysteresis. This fraction (0-1)
  *           specifies the percentage point in a histogram of the gradient of
  *           the magnitude. Magnitude values of zero are not counted in the
  *           histogram.
  */    
    CannyEdgeDetector(float sigma, float tlow, float thigh) { }
    
    bool operator() (const unsigned char *src, unsigned char *edge, unsigned int width, unsigned int height);
    bool operator() (const TImage<T> & src, TImage<uint8_t> & edge);
}

  }
}


#endif
