#ifndef _SMOOTHING_H
#define _SMOOTHING_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * \file MinMaxFunctions.h
 * \brief Min Max functions
 * \author Mirko Felisa <felisa@vislab.it>
 * \date 2010-10-18
 **/


#include <stdint.h>
#include <boost/thread/barrier.hpp>

struct MinMax32f
{
    typedef float value_type;
    typedef float arg_type;
    enum { SIZE = 1 };
    arg_type load(const float* ptr) { return *ptr; }
    void store(float* ptr, arg_type val) { *ptr = val; }
    void operator()(arg_type& a, arg_type& b) const
    {
        arg_type t = a;
        a = std::min(a, b);
        b = std::max(b, t);
    }
};
    
#ifdef __SSE2__    

#include <xmmintrin.h>

struct MinMaxVec32f
{
    typedef float value_type;
    typedef __m128 arg_type;
    enum { SIZE = 4 };
    arg_type load(const float* ptr) { return _mm_loadu_ps(ptr); }
    void store(float* ptr, arg_type val) { _mm_storeu_ps(ptr, val); }
    void operator()(arg_type& a, arg_type& b) const
    {
        arg_type t = a;
        a = _mm_min_ps(a, b);
        b = _mm_max_ps(b, t);
    }
};

#else
typedef MinMax32f MinMaxVec32f;
#endif



inline void MedianLoop(float* currRow, float* dst, int m_width, uint32_t m_x_min, uint32_t m_x_max)
{
    float* prevRow =  currRow - m_width,  * nextRow =  currRow + m_width;
    MinMaxVec32f MinMax;     
    dst[m_x_min] = currRow[m_x_min];

    uint32_t j = m_x_min + 1;

    for ( ; j < m_x_max - 1; j += MinMaxVec32f::SIZE )
    {
        MinMaxVec32f::arg_type p0 = MinMax.load ( prevRow + j - 1 ), p1 =  MinMax.load ( prevRow + j ), p2 =  MinMax.load ( prevRow + j + 1 );
        MinMaxVec32f::arg_type p3 = MinMax.load ( currRow + j - 1 ), p4 =  MinMax.load ( currRow + j ), p5 =  MinMax.load ( currRow + j + 1 );
        MinMaxVec32f::arg_type p6 = MinMax.load ( nextRow + j - 1 ), p7 =  MinMax.load ( nextRow + j ), p8 =  MinMax.load ( nextRow + j + 1 );

        MinMax ( p1, p2 );
        MinMax ( p4, p5 );
        MinMax ( p7, p8 );
        MinMax ( p0, p1 );
        MinMax ( p3, p4 );
        MinMax ( p6, p7 );
        MinMax ( p1, p2 );
        MinMax ( p4, p5 );
        MinMax ( p7, p8 );
        MinMax ( p0, p3 );
        MinMax ( p5, p8 );
        MinMax ( p4, p7 );
        MinMax ( p3, p6 );
        MinMax ( p1, p4 );
        MinMax ( p2, p5 );
        MinMax ( p4, p7 );
        MinMax ( p4, p2 );
        MinMax ( p6, p4 );
        MinMax ( p4, p2 );
        MinMax.store ( dst + j, p4 );

    }

  dst[m_x_max - 1] = currRow[m_x_max - 1];
  dst[m_x_max] = DISPARITY_UNKNOWN;
  dst[m_x_max + 1] = DISPARITY_UNKNOWN;
    
}




inline void MedianLoop2(float* currRow, float* dst, int m_width, uint32_t m_x_min, uint32_t m_x_max)
{
    float* prevRow =  currRow - m_width,  * nextRow =  currRow + m_width;
    MinMaxVec32f MinMax;     
    dst[m_x_min] = currRow[m_x_min];

    uint32_t j = m_x_min + 1;

    for ( ; j < m_x_max - 2; j += MinMaxVec32f::SIZE )
    {
        MinMaxVec32f::arg_type p0 = MinMax.load ( prevRow + j - 1 ), p1 =  MinMax.load ( prevRow + j ), p2 =  MinMax.load ( prevRow + j + 1 );
        MinMaxVec32f::arg_type p3 = MinMax.load ( currRow + j - 1 ), p4 =  MinMax.load ( currRow + j ), p5 =  MinMax.load ( currRow + j + 1 );
        MinMaxVec32f::arg_type p6 = MinMax.load ( nextRow + j - 1 ), p7 =  MinMax.load ( nextRow + j ), p8 =  MinMax.load ( nextRow + j + 1 );

        MinMax ( p1, p2 );
        MinMax ( p4, p5 );
        MinMax ( p7, p8 );
        MinMax ( p0, p1 );
        MinMax ( p3, p4 );
        MinMax ( p6, p7 );
        MinMax ( p1, p2 );
        MinMax ( p4, p5 );
        MinMax ( p7, p8 );
        MinMax ( p0, p3 );
        MinMax ( p5, p8 );
        MinMax ( p4, p7 );
        MinMax ( p3, p6 );
        MinMax ( p1, p4 );
        MinMax ( p2, p5 );
        MinMax ( p4, p7 );
        MinMax ( p4, p2 );
        MinMax ( p6, p4 );
        MinMax ( p4, p2 );
        MinMax.store ( dst + j, p4 );

    }
    
    if(j < m_x_max - 1)
    {    
        MinMax32f MinMax;     
        MinMax32f::arg_type p0 = MinMax.load ( prevRow + j - 1 ), p1 =  MinMax.load ( prevRow + j ), p2 =  MinMax.load ( prevRow + j + 1 );
        MinMax32f::arg_type p3 = MinMax.load ( currRow + j - 1 ), p4 =  MinMax.load ( currRow + j ), p5 =  MinMax.load ( currRow + j + 1 );
        MinMax32f::arg_type p6 = MinMax.load ( nextRow + j - 1 ), p7 =  MinMax.load ( nextRow + j ), p8 =  MinMax.load ( nextRow + j + 1 );

        MinMax ( p1, p2 );
        MinMax ( p4, p5 );
        MinMax ( p7, p8 );
        MinMax ( p0, p1 );
        MinMax ( p3, p4 );
        MinMax ( p6, p7 );
        MinMax ( p1, p2 );
        MinMax ( p4, p5 );
        MinMax ( p7, p8 );
        MinMax ( p0, p3 );
        MinMax ( p5, p8 );
        MinMax ( p4, p7 );
        MinMax ( p3, p6 );
        MinMax ( p1, p4 );
        MinMax ( p2, p5 );
        MinMax ( p4, p7 );
        MinMax ( p4, p2 );
        MinMax ( p6, p4 );
        MinMax ( p4, p2 );
        MinMax.store ( dst + j, p4 );
   }
  dst[m_x_max - 1] = currRow[m_x_max - 1];
  dst[m_x_max] = DISPARITY_UNKNOWN;
    
}

void MedianFilter(CDSI& dsi,  CDSI& tmp, boost::barrier& barrier_, uint32_t m_dsiXMin, uint32_t m_dsiXMax,  uint32_t m_dsiYMin, uint32_t m_dsiYMax, uint32_t threadID, uint32_t threadNum )
{
    uint32_t width = dsi.W();
    uint32_t height = m_dsiYMax - m_dsiYMin;
    const int32_t k12 = (threadID * (height-2) ) / threadNum + 1 + m_dsiYMin;
    const int32_t k13 = ((threadID + 1) *  (height-2) ) / threadNum + 1 + m_dsiYMin;
    float * pDisp = (float*) dsi.Buffer();
    float * tmpBuff = (float*)tmp.Buffer();


    for(int i = k12; i < k13; i++) 
    {
      int stride1 = i * width ;
      MedianLoop2(pDisp + stride1, tmpBuff + stride1, width, m_dsiXMin, m_dsiXMax);
      
    }
    barrier_.wait();
    std::copy(tmpBuff+ k12* width, tmpBuff+ k13* width, pDisp+ k12* width ); 
    
    barrier_.wait();
}



#ifdef __SSSE3__
  #include <pmmintrin.h>
#endif
#ifdef __AVX__
  #include <immintrin.h>
#endif  


void AdaptiveMeanFilter(CDSI& dsi,  CDSI& tmp, boost::barrier& barrier_, uint32_t m_dsiXMin, uint32_t m_dsiXMax,  uint32_t m_dsiYMin, uint32_t m_dsiYMax, uint32_t threadID, uint32_t threadNum )
{

      DECLSPEC_ALIGN(16) float val[8];
      int32_t* ival = (int32_t*) val;
      ival[0] = 0x7FFFFFFF;
#ifdef __AVX__                         
      __m256 xabsmask = _mm256_broadcast_ss(val);
      val[0] = 0.0f;
      __m256 xconst0 = _mm256_broadcast_ss(val);
      val[0] =4.0f;
      __m256 xconst4 = _mm256_broadcast_ss(val);
      __m256 xval, xweight1, xfactor1;
#elif __SSSE3__
      __m128 xabsmask = _mm_set1_ps(val[0]);
      __m128 xconst0 = _mm_set1_ps(0);
      __m128 xconst4 = _mm_set1_ps(4);
      __m128 xval, xweight1, xweight2, xfactor1, xfactor2;                        
#endif                        

      float* dispout = (float*) tmp.Buffer();
      float* dispin = (float*) dsi.Buffer();
      uint32_t width = dsi.W();
      uint32_t height = dsi.H();
      int32_t k0 = (height * threadID) / threadNum;
      int32_t k1 = (height * (threadID + 1)) / threadNum;

      int stride = k0 * width;
      for(int32_t i = k0; i < k1; i++, stride += width)
      {
          dispout[stride] = dispin[stride];
          dispout[stride+1] = dispin[stride+1];
          dispout[stride+2] = dispin[stride+2];
          dispout[stride+3] = dispin[stride+3];
          
          for(int32_t j = 0; j < 7; j++)
          {
              val[j] = * (dispin + stride + j);
          }

          for(int32_t j = 7; j < (int) width; j++)
          {

              float val_curr = * (dispin + stride + j - 3);
              val[j % 8] = * (dispin + stride + j);
              
              if(val_curr!=DISPARITY_UNKNOWN)
              { 
#ifdef __AVX__                                 
                xval     = _mm256_load_ps(val);
                xweight1 = _mm256_sub_ps(xval, _mm256_broadcast_ss(&val_curr));
                xweight1 = _mm256_and_ps(xweight1, xabsmask);
                xweight1 = _mm256_sub_ps(xconst4, xweight1);
                xweight1 = _mm256_max_ps(xweight1, xconst0);
                xfactor1 = _mm256_mul_ps(xval, xweight1);
                __m256 xfactor2 = _mm256_permute2f128_ps(xfactor1, xfactor1 , 1);
                xfactor1 = _mm256_add_ps(xfactor1, xfactor2);
                xfactor1 = _mm256_hadd_ps(xfactor1, xfactor1);
                xfactor1 = _mm256_hadd_ps(xfactor1, xfactor1);
                __m256 xweight2 = _mm256_permute2f128_ps(xweight1, xweight1 , 1);
                xweight1 = _mm256_add_ps(xweight1, xweight2);
                xweight1 = _mm256_hadd_ps(xweight1, xweight1);
                xweight1 = _mm256_hadd_ps(xweight1, xweight1);
                _mm_store_ss(dispout + stride + j - 3,_mm_div_ss(_mm256_castps256_ps128(xfactor1), _mm256_castps256_ps128(xweight1))); 
#elif __SSSE3__
                xval     = _mm_load_ps(val);
                xweight1 = _mm_sub_ps(xval, _mm_set1_ps(val_curr));
                xweight1 = _mm_and_ps(xweight1, xabsmask);
                xweight1 = _mm_sub_ps(xconst4, xweight1);
                xweight1 = _mm_max_ps(xweight1, xconst0);
                xfactor1 = _mm_mul_ps(xval, xweight1);

                xval     = _mm_load_ps(val + 4);
                xweight2 = _mm_sub_ps(xval, _mm_set1_ps(val_curr));
                xweight2 = _mm_and_ps(xweight2, xabsmask);
                xweight2 = _mm_sub_ps(xconst4, xweight2);
                xweight2 = _mm_max_ps(xconst0, xweight2);
                xfactor2 = _mm_mul_ps(xval, xweight2);

                xweight1 = _mm_add_ps(xweight1, xweight2);
                xfactor1 = _mm_add_ps(xfactor1, xfactor2);
                
                xweight1 = _mm_hadd_ps(xweight1,xweight1);
                xweight1 = _mm_hadd_ps(xweight1,xweight1);
                xfactor1 = _mm_hadd_ps(xfactor1,xfactor1);
                xfactor1 = _mm_hadd_ps(xfactor1,xfactor1);                                        
                xfactor1 = _mm_div_ss(xfactor1, xweight1);
                _mm_store_ss(dispout + stride + j - 3, xfactor1); 
#else
                  float weight_sum = 0, factor_sum = 0;
                  for(int k = 0; k < 8; k++)
                  {  
                     float w = std::max(0.0f, 4.0f - std::abs(val[k]- val_curr));
                     weight_sum += w;
                     factor_sum += w * val[k];                     
                  }
                  *(dispout + stride + j - 3) = factor_sum / weight_sum;                
#endif                                  

            }else
              *(dispout + stride + j - 3) = DISPARITY_UNKNOWN;

          }
          
          dispout[stride+width-3] = dispin[stride+width-3];
          dispout[stride+width-2] = dispin[stride+width-2];
          dispout[stride+width-1] = dispin[stride+width-1];
      }

      barrier_.wait();

      
      int width3 = 3 * width;
      k0 = ((width - 6) * threadID) / threadNum + 3;
      k1 = ((width - 6) * (threadID + 1)) / threadNum + 3;
      
      if(!threadID)
          std::copy(dispout, dispout + 3*width, dispin);  
  
      if(threadID == threadNum -1)
          std::copy(dispout + width*(height-3), dispout + width*height, dispin + width*(height-3));  
      
      for(int32_t j = k0; j < k1; j++)
      {

          int stride = 0;
          for(int32_t i = 0; i < 7; i++, stride += width)
          {
              val[i] = * (dispout + stride + j);
          }

          stride = 7 * width;
          for(int32_t i = 7; i < (int) height; i++, stride += width)
          {

              float val_curr = * (dispout + stride + j - width3);
              val[i % 8] = * (dispout + stride + j);
              if(val_curr!=DISPARITY_UNKNOWN)
              { 
#ifdef __AVX__                                  
                  xval     = _mm256_load_ps(val);
                  xweight1 = _mm256_sub_ps(xval, _mm256_broadcast_ss(&val_curr));
                  xweight1 = _mm256_and_ps(xweight1, xabsmask);
                  xweight1 = _mm256_sub_ps(xconst4, xweight1);
                  xweight1 = _mm256_max_ps(xweight1, xconst0);
                  xfactor1 = _mm256_mul_ps(xval, xweight1);
                  __m256 xfactor2 = _mm256_permute2f128_ps(xfactor1, xfactor1 , 1);
                  xfactor1 = _mm256_add_ps(xfactor1, xfactor2);
                  xfactor1 = _mm256_hadd_ps(xfactor1, xfactor1);
                  xfactor1 = _mm256_hadd_ps(xfactor1, xfactor1);
                  __m256 xweight2 = _mm256_permute2f128_ps(xweight1, xweight1 , 1);
                  xweight1 = _mm256_add_ps(xweight1, xweight2);
                  xweight1 = _mm256_hadd_ps(xweight1, xweight1);
                  xweight1 = _mm256_hadd_ps(xweight1, xweight1);
                  _mm_store_ss(dispin + stride + j - width3,_mm_div_ss(_mm256_castps256_ps128(xfactor1), _mm256_castps256_ps128(xweight1))); 
#elif __SSSE3__
                  xval     = _mm_load_ps(val);
                  xweight1 = _mm_sub_ps(xval, _mm_set1_ps(val_curr));
                  xweight1 = _mm_and_ps(xweight1, xabsmask);
                  xweight1 = _mm_sub_ps(xconst4, xweight1);
                  xweight1 = _mm_max_ps(xweight1, xconst0);
                  xfactor1 = _mm_mul_ps(xval, xweight1);

                  xval     = _mm_load_ps(val + 4);
                  xweight2 = _mm_sub_ps(xval, _mm_set1_ps(val_curr));
                  xweight2 = _mm_and_ps(xweight2, xabsmask);
                  xweight2 = _mm_sub_ps(xconst4, xweight2);
                  xweight2 = _mm_max_ps(xconst0, xweight2);
                  xfactor2 = _mm_mul_ps(xval, xweight2);

                  xweight1 = _mm_add_ps(xweight1, xweight2);
                  xfactor1 = _mm_add_ps(xfactor1, xfactor2);
                  
                  xweight1 = _mm_hadd_ps(xweight1,xweight1);
                  xweight1 = _mm_hadd_ps(xweight1,xweight1);
                  xfactor1 = _mm_hadd_ps(xfactor1,xfactor1);
                  xfactor1 = _mm_hadd_ps(xfactor1,xfactor1);                                        
                  xfactor1 = _mm_div_ss(xfactor1, xweight1);
                  _mm_store_ss(dispin + stride + j - width3, xfactor1);  
#else
                  float weight_sum = 0, factor_sum = 0;
                  for(int k = 0; k < 8; k++)
                  {  
                     float w = std::max(0.0f, 4.0f - std::abs(val[k]- val_curr));
                     weight_sum += w;
                     factor_sum += w * val[k];                     
                  }
                  *(dispin + stride + j - width3) = factor_sum / weight_sum;                      
#endif                                    
              }                                    
          }
      }
      
      barrier_.wait();

}

#endif
