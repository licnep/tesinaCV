#ifndef _DISPARITYENGINE_INCREMENTAL_IMPL_H
#define _DISPARITYENGINE_INCREMENTAL_IMPL_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file Impl.h
 * \author Paolo Zani (zani@vislab.it) Mirko Felisa (felisa@vislab.it)
 * \date 2009-10-01
 */

#include <Processing/Vision/Stereo/Images/CDSI.h>
#include <Processing/Vision/Stereo/Images/CScoreImage.h>
#include <Processing/Vision/Stereo/DisparityEngine/Common/SearchRange.h>
#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/Window/Params.h>
#include <Processing/Vision/Stereo/DisparityEngine/Common/PixelFunctions.h>
#include <Processing/Vision/Stereo/DisparityEngine/Common/DisparityEngineData.h>
#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/Window/Incremental/Loops.h>
#include <Data/CImage/PixelTraits/PixelTraits.h>
#include <Libs/Threads/Parallelize.h>
#include <mm_malloc.h>
#include <limits>
#include <boost/bind.hpp>
#include <stdint.h>

// #define __DEBUG__

#include <iostream>

#ifdef __DEBUG__
#define __log_debug  std::cout << "[DB] DisparityEngine/Aggregation/Window/Core_Cpp.h "  << __LINE__ << " "
#else
#define __log_debug  while(0) std::cout
#endif

namespace disparity
{
    // forward declarations

    namespace agg
    {
        template<typename ResultType_Cost, typename _ResultType_Agg, typename Impl_Agg, uint32_t _Threads_Agg>
        class Window_Incremental;
    }

    namespace impl
    {
        class Auto;
        class Cpp;
        class SIMD;
    }

    template<typename Cost, typename Aggregation, typename Optimization>
    class Core;

    // actual specialization

    template<typename Cost, typename Optimization, typename ResultType_Cost, typename _ResultType_Agg, typename _Impl_Agg, uint32_t _Threads_Agg>
    class Core<Cost, agg::Window_Incremental<ResultType_Cost, _ResultType_Agg, _Impl_Agg, _Threads_Agg>, Optimization> : public Optimization, public WindowParams, private virtual DisparityEngineData
    {
       public:

            typedef Cost CostType;
            typedef _Impl_Agg Impl_Agg;
            typedef _ResultType_Agg ResultType_Agg;
            typedef agg::Window_Incremental<ResultType_Cost, ResultType_Agg, Impl_Agg, _Threads_Agg> AggregationType;
            typedef Optimization OptimizationType;
            typedef Core<Cost, AggregationType, Optimization> CoreType;

            static const uint32_t Threads_Agg = _Threads_Agg;

        protected:

            Core() : m_maxDisparityRangeSize(0), m_textureSize(0), m_correlSize(0), m_prevCorrelSize(0), m_textSize(0), m_pTextureImage(NULL)
            {
                for(uint32_t i = 0; i < Threads_Agg; ++i) {

                    m_pCorrel__Buffer[i] = NULL;
                    m_pPrevCorrel__Buffer[i] = NULL;
                    m_pText[i] = NULL;
                    m_pPrevText[i] = NULL;
                }
            }

            ~Core()
            {
                free(m_pTextureImage);

                for(uint32_t i = 0; i < Threads_Agg; ++i) {

                    _mm_free(m_pCorrel__Buffer[i]);
                    _mm_free(m_pPrevCorrel__Buffer[i]);
                    free(m_pText[i]);
                    free(m_pPrevText[i]);
                }
            }
            
            inline void SetDimensions(uint32_t& width, uint32_t& height){}

            template<typename T>
            inline void Run(const cimage::TImage<T>& left, const cimage::TImage<T>& right, const cimage::CImageMono8& mask)
            {
                Optimization::Init(m_winWidth * m_winHeight);

                const uint32_t width = m_dsi->W();
                const uint32_t height = m_dsi->H();

                m_pMask = mask.Area() ? mask.Buffer() : NULL;

                int sum = 0;
                for ( unsigned int i = m_dsiYMin; i < m_dsiYMax; ++i )
                    sum += std::max ( m_searchRanges[i].second - m_searchRanges[i].first + 1, 1 );
                sum/=Threads_Agg;
                      
                m_threadRange[0] = m_dsiYMin;
                int acc = 0, th = sum, j = 1;
                 for ( unsigned int i = m_dsiYMin; i < m_dsiYMax; ++i )
                {    
                    acc += std::max ( m_searchRanges[i].second - m_searchRanges[i].first + 1, 1 );
                    if (acc > th)
                    {    
                       m_threadRange[j++] = i;
                       th = j * sum;
                    }   
                }
                m_threadRange[Threads_Agg] = m_dsiYMax;

                 ///deve essere un multiplo di 16 + le disparita' eccedenti x assembly;
                int maxDisparityRangeSize = ((m_dispMax - m_dispMin + 1)  & ~(16/sizeof(ResultType_Agg) -1)) + 32/sizeof(ResultType_Agg); 
                // we might need to allocate some more memory to handle the new disparity search ranges
                if((maxDisparityRangeSize > m_maxDisparityRangeSize) || (width * maxDisparityRangeSize > m_correlSize)
                   || (m_winHeight * maxDisparityRangeSize * width > m_prevCorrelSize)) {

                    m_maxDisparityRangeSize = maxDisparityRangeSize;

                    __log_debug << "Reallocating correlation buffers (m_maxDisparityRangeSize = " << maxDisparityRangeSize <<")" << std::endl;

                    m_prevCorrelSize= width * maxDisparityRangeSize * m_winHeight;


                    for(uint32_t i = 0; i < Threads_Agg; ++i) {
                        _mm_free(m_pPrevCorrel__Buffer[i]);
                        m_pPrevCorrel__Buffer[i] = (ResultType_Agg* )_mm_malloc( m_prevCorrelSize * sizeof(ResultType_Agg), 16);                        
                    }

                    m_correlSize = width * maxDisparityRangeSize;

                    for(uint32_t i = 0; i < Threads_Agg; ++i) {
                        _mm_free(m_pCorrel__Buffer[i]);
                        m_pCorrel__Buffer[i] = (ResultType_Agg* )_mm_malloc( m_correlSize * sizeof(ResultType_Agg), 16);                        
                    }
                }

                if(m_textureSize < width * height) {
                    m_textureSize = width * height;
                    m_pTextureImage = reinterpret_cast<uint8_t*>(realloc(m_pTextureImage, m_textureSize));
                }

                // we set up the initial offset so that some room becomes available for correlation values obtained with negative disparities
                for(uint32_t i = 0; i < Threads_Agg; ++i) {
                    m_pPrevCorrel[i] = m_pPrevCorrel__Buffer[i] - m_dispMin + 16 / sizeof(ResultType_Agg);
                    //memset(m_pCorrel__Buffer[i], 0,  m_maxDisparityRangeSize * m_width * sizeof(ResultType_Agg));
                    m_pCorrel[i] = m_pCorrel__Buffer[i] - m_dispMin + 16 / sizeof(ResultType_Agg);
                }
                  
            
                uint32_t rowWidth = m_dsiXMax - m_dsiXMin - 1 + m_winWidth;
                uint32_t textSize = rowWidth * 2 * m_winHeight * sizeof(typename cimage::PixelTraits<T>::CumulativeType);
                if (textSize > m_textSize)
                {
                   m_textSize = textSize;
                   for(uint32_t i = 0; i < Threads_Agg; ++i) {
                      m_pText[i] = (ResultType_Agg* )realloc(m_pText[i], 2*rowWidth * sizeof(typename cimage::PixelTraits<T>::CumulativeType)); 
                      m_pPrevText[i] = (ResultType_Agg* )realloc( m_pPrevText[i],  textSize);                                     
                   }
                       
                }
                
                Parallelize(boost::bind(&CoreType::template ComputeDisparity<T>, this, _1, _2, _3, _4), left.Buffer(), right.Buffer(), Threads_Agg);

                Optimization::Finalize();
            }

            template<typename T>
            inline void ComputeDisparity(const T* pLeft, const T* pRight, uint32_t threadId, uint32_t threadNum)
            {                

                const uint32_t width = m_dsi->W();
                const uint32_t height = m_dsi->H();
                const uint32_t dsi_x_min = m_dsiXMin;
                const uint32_t dsi_x_max = m_dsiXMax;
                const uint32_t y_min = m_threadRange[threadId];
                const uint32_t y_max = m_threadRange[threadId + 1];
                const int32_t max_disp_range = m_maxDisparityRangeSize;
                const std::vector<SearchRange>& search_ranges = m_searchRanges;
                memset(m_pCorrel__Buffer[threadId], 0,  m_maxDisparityRangeSize * width * sizeof(ResultType_Agg));
                const int32_t min_disp = std::min(search_ranges[y_min].first, 0);
                const uint32_t win_w = m_winWidth;
                const uint32_t win_h = m_winHeight;
                
                ResultType_Agg* corr_sum = m_pCorrel[threadId];
                ResultType_Agg* prev_value = m_pPrevCorrel[threadId];
                uint8_t* pTextureImage = m_pTextureImage;

                uint32_t l_half_win_w = win_w/2;
                uint32_t r_half_win_w = (win_w % 2) ? win_w/2 : win_w/2 -1;
                uint32_t t_half_win_h = win_h/2;
                uint32_t b_half_win_h = (win_h % 2) ? win_h/2 : win_h/2 -1;

                typedef typename cimage::PixelTraits<T>::ChannelCumulativeType TextureType;
                
                if(m_textureAlgo == VARIANCE) {
                    
                    typedef typename cimage::PixelTraits<T>::CumulativeType VarianceType;
                    
                    int win_area = win_w * win_h;
                    uint32_t sum_width = dsi_x_max - dsi_x_min - 1 + win_w;

                    TextureType minSum = m_minVariance * win_area * win_area;
                    VarianceType* prev_text_value = ((VarianceType**)m_pPrevText)[threadId];
                    VarianceType* text_sum = ((VarianceType**)m_pText)[threadId];
                    // VarianceType prev_text_value[2 * sum_width * m_winHeight];
                    //VarianceType text_sum[2 * sum_width];                    
                    
                    VarianceType* cur_prev_value = prev_text_value;
                    VarianceType* cur_prev_value2 = prev_text_value + sum_width * win_h;
                    VarianceType* text_sum2 = text_sum + sum_width;
                    memset(text_sum, 0, 2 * sum_width * sizeof(VarianceType));

                    for(uint32_t i = y_min - t_half_win_h; i <= y_min + b_half_win_h; i++) {

                        const T* right = pRight + i * width + dsi_x_min - l_half_win_w;

                        for(uint32_t j = 0; j < sum_width; j++) {

                            VarianceType value = cimage::Abs(*right);
                            VarianceType value2 = cimage::Sqr(*right);
                            right++;
                            *cur_prev_value++ = value;
                            *cur_prev_value2++ = value2;
                            text_sum[j] += value;
                            text_sum2[j] += value2;
                        }
                    }

                    VarianceType sum = 0, sum2 = 0;

                    for(uint32_t j = 0; j < win_w; j++) {

                        sum += text_sum[j];
                        sum2 += text_sum2[j];
                    }

                    int stride = y_min * width + dsi_x_min;

                    pTextureImage[stride++] = (cimage::ChannelSum(win_area * sum2 - sum * sum) < minSum) ? 0 : 255;

                    for(uint32_t j = win_w; j < sum_width; j++) {

                        sum += text_sum[j] - text_sum[j - win_w];
                        sum2 += text_sum2[j] - text_sum2[j - win_w];

                        pTextureImage[stride++] = (cimage::ChannelSum(win_area * sum2 - sum * sum)  < minSum) ? 0 : 255;
                    }

                    cur_prev_value = prev_text_value;
                    cur_prev_value2 = prev_text_value + sum_width * win_h;

                    for(uint32_t i = y_min + b_half_win_h + 1; i < y_max + b_half_win_h; i++) {

                        const T* right = pRight + i * width + dsi_x_min - l_half_win_w;

                        for (uint32_t j = 0; j < sum_width; j++) {

                            VarianceType value = cimage::Abs(*right);
                            VarianceType value2 = cimage::Sqr(*right);
                            right++;
                            text_sum[j] += value - *cur_prev_value;
                            text_sum2[j] += value2 - *cur_prev_value2;
                            *cur_prev_value++ = value;
                            *cur_prev_value2++ = value2;
                        }

                        VarianceType sum = 0, sum2 = 0;

                        for(uint32_t j = 0; j < win_w; j++) {

                            sum += text_sum[j];
                            sum2 += text_sum2[j];
                        }

                        int stride = (i - b_half_win_h) * width + dsi_x_min;

                        pTextureImage[stride++]=(cimage::ChannelSum(win_area * sum2 - sum * sum)  < minSum) ? 0 : 255;

                        for (uint32_t j = win_w; j < sum_width; j++) {

                            sum += text_sum[j] - text_sum[j - win_w];
                            sum2 += text_sum2[j] - text_sum2[j - win_w];
                            pTextureImage[stride++] = (cimage::ChannelSum(win_area * sum2 - sum * sum)< minSum) ? 0 : 255;
                        }

                        int index = ((cur_prev_value - prev_text_value) / sum_width) % win_h;

                        cur_prev_value = prev_text_value + index * sum_width;
                        cur_prev_value2 = prev_text_value  + sum_width * win_h + index * sum_width;
                    }

                    //memset(text_sum, 0, 2 * sum_width * sizeof(VarianceType));
                } else {

                    int win_area = win_w  * win_h;
                    uint32_t sum_width = dsi_x_max - dsi_x_min - 1 + win_w;
                    TextureType minSum = m_minSum * win_area;
                    TextureType* prev_text_value = ((TextureType**)m_pPrevText)[threadId];
                    TextureType* text_sum = ((TextureType**)m_pText)[threadId];
                    //TextureType prev_text_value[sum_width *  m_winHeight];
                    //TextureType text_sum[sum_width]; 

     
                    TextureType* cur_prev_value = prev_text_value;
                    memset(text_sum, 0, sum_width * sizeof(TextureType));
                    
                    for(uint32_t i = y_min - t_half_win_h; i <= y_min + b_half_win_h; i++) {

                        const T* right = pRight + i * width + dsi_x_min - l_half_win_w;
                        
                        for(uint32_t j = 0; j < sum_width; j++) {

                            TextureType value = cimage::Norm1(*right++);
                            *cur_prev_value++ = value;
                            text_sum[j] += value;
                        }
                    }

                    TextureType sum = 0;

                    for(uint32_t j = 0; j < win_w; j++)
                        sum += text_sum[j];
                    
                    int stride = y_min * width + dsi_x_min;
                    
                    pTextureImage[stride++] = (sum < minSum) ? 0 : 255;

                    for(uint32_t j = win_w; j < sum_width; j++) {
                        sum += text_sum[j] - text_sum[j - win_w];
                        pTextureImage[stride++] = (sum < minSum) ? 0 : 255;
                    }

                    cur_prev_value = prev_text_value;
                    
                    for(uint32_t i = y_min + b_half_win_h + 1; i < y_max + b_half_win_h; i++) {

                        const T* right = pRight + i * width + dsi_x_min - l_half_win_w;

                        for(uint32_t j = 0; j < sum_width; j++) {

                            TextureType value = cimage::Norm1(*right++);
                            text_sum[j] += value - *cur_prev_value;
                            *cur_prev_value++ = value;
                        }

                        TextureType sum = 0;

                        for(uint32_t j = 0; j < win_w; j++)
                            sum += text_sum[j];

                        int stride = (i - b_half_win_h) * width + dsi_x_min;

                        pTextureImage[stride++] = (sum < minSum) ? 0 : 255;

                        for(uint32_t j = win_w; j < sum_width; j++) {
                            sum += text_sum [j] - text_sum[j - win_w];
                            pTextureImage[stride++] = (sum < minSum) ? 0 : 255;
                        }

                        int index = ((cur_prev_value - prev_text_value) / sum_width) % win_h;
                        cur_prev_value = prev_text_value + index * sum_width;
                    }

                   // memset(text_sum, 0, sum_width * sizeof(TextureType));
                }

                const int prev_value_stride = (dsi_x_max - dsi_x_min  ) * max_disp_range;
                const int start_range = search_ranges[y_min].first;
                const int stop_range = search_ranges[y_min].second;

                ResultType_Agg* cur_prev_value = prev_value;
                for(uint32_t i = y_min - t_half_win_h; i <= y_min + b_half_win_h; ++i) {

                    ResultType_Agg* cur_corr_row_sum = corr_sum;

                    int search_max = stop_range;

                    for(int k =  y_min + 1; k <=  (int)(i + t_half_win_h); ++k)
                        if(search_ranges[k].second   > search_max)
                            search_max = search_ranges[k].second;

                    int stride = i * width + dsi_x_min;

                    {
                        int d_min = std::max(start_range, static_cast<int>( l_half_win_w - dsi_x_min));
                        int d_max = std::min((int)width - 1 - static_cast<int>(dsi_x_min + r_half_win_w), search_max);

                        const T* left = pLeft + stride;
                        const T* right = pRight + stride;

                        for(int d = d_min;  d <= d_max; ++d) {

                            ResultType_Agg corr_delta = 0;
                            for(int w = -(int)l_half_win_w; w <=(int)r_half_win_w; ++w)
                                corr_delta += Cost::eval(left[d + w], right[w]);

                            cur_prev_value[d] = corr_delta;
                            cur_corr_row_sum[d] += corr_delta;
                        }

                        memset(cur_prev_value + d_max + 1, 0, (max_disp_range + min_disp - (d_max + 1)) * sizeof(ResultType_Agg));

                        cur_prev_value += max_disp_range;
                        cur_corr_row_sum += max_disp_range;
                    }

                    {
                        const int d0 = (int)(l_half_win_w) - (int)dsi_x_min;
                        const int loop = d0  - start_range;
                        const T* left = pLeft + stride + d0;
                        int index = d0 - 1;
                        for(int k = 1; k <= loop; ++k) {

                            const T* right = pRight + stride + k;
                            ResultType_Agg corr_delta = 0;

                            for(int w = -(int)l_half_win_w; w <= (int)r_half_win_w; ++w )
                                corr_delta += Cost::eval(left[w], right[w]);

                            cur_corr_row_sum[index] += corr_delta;
                            cur_prev_value[index] = corr_delta;
                            index += max_disp_range - 1;
                        }
                    }

                    ++stride;

                    for(uint32_t j = dsi_x_min + 1; j < dsi_x_max; ++j, ++stride) {

                        int d_min = std::max(start_range, (int)(l_half_win_w) - (int)j + 1 );
                        int d_max = std::min((int)width - 1 - (int)(j + r_half_win_w), search_max);

                        const int index = stride + r_half_win_w;
                        const T* pLr = pLeft + index;
                        const T rr = pRight[index];
                        const int index2 = stride -(int)l_half_win_w-1;
                        const T* pLl = pLeft + index2;
                        const T rl = pRight[index2];
                        const  ResultType_Agg* prev_pixel_corr = cur_prev_value - max_disp_range;

                        incr::pixel0_loop<T, ResultType_Agg, Impl_Agg, Cost>::run(pLl, rl, pLr, rr, cur_prev_value, cur_corr_row_sum, prev_pixel_corr, d_min, d_max);
                        
                        memset(cur_prev_value + d_max + 1, 0, (max_disp_range + min_disp - (d_max + 1)) * sizeof(ResultType_Agg));

                        cur_prev_value += max_disp_range;
                        cur_corr_row_sum += max_disp_range;
                    }
                }

                ResultType_Agg* cur_corr_row_sum = corr_sum;
                int stride = y_min * width + dsi_x_min;

                for(uint32_t j = dsi_x_min;  j < dsi_x_max; ++j, ++stride) {

                    if(pTextureImage[stride]) {

                        int d_min = std::max(start_range, static_cast<int>( l_half_win_w - j));
                        int d_max = std::min((int)width - 1 - static_cast<int>(j + r_half_win_w), search_ranges[y_min].second);

                        Optimization::Store(cur_corr_row_sum, j, y_min, d_min, d_max, threadId);
                    } else
                        Optimization::Store(DISPARITY_UNKNOWN, SCORE_UNKNOWN, j, y_min, threadId);

                    cur_corr_row_sum += max_disp_range;
                }

                int b_half_win_stride = b_half_win_h * width;
                cur_prev_value = prev_value;

                for(uint32_t i = y_min + b_half_win_h + 1; i < y_max + b_half_win_h; ++i) {

                    ResultType_Agg* cur_corr_row_sum = corr_sum;

                    const int ii = i - b_half_win_h;
                    const int start_range = search_ranges[ii].first;
                    const int stop_range = search_ranges[ii].second;

                    int search_max = stop_range;
                    const int end = std::min(i + t_half_win_h, height - 1);
                    
                    for(int k = i - b_half_win_h + 1; k <= end; ++k)
                        if(search_ranges[k].second > search_max)
                            search_max = search_ranges[k].second;

                    int stride = i * width + dsi_x_min;

                    {
                        int max_border =(int)width - 1- (int)(dsi_x_min  + r_half_win_w);
                        int d_min = std::max(start_range, static_cast<int>( l_half_win_w - dsi_x_min));
                        int d_max = std::min(max_border, search_max);

                        const T* left = pLeft + stride;
                        const T* right = pRight + stride;

                        for(int d = d_min; d <= d_max; ++d) {

                            ResultType_Agg corr_delta = 0;

                            for(int w = -(int)l_half_win_w; w <=(int)r_half_win_w; ++w)
                                corr_delta += Cost::eval(left[d + w], right[w]);

                            cur_corr_row_sum[d] += corr_delta - cur_prev_value[d];
                            cur_prev_value[d] = corr_delta;
                        }

                        int min_index = stride - b_half_win_stride;

                        if(pTextureImage[min_index])
                            Optimization::Store(cur_corr_row_sum, dsi_x_min, i - b_half_win_h, d_min, std::min(max_border, stop_range), threadId);
                        else
                            Optimization::Store(DISPARITY_UNKNOWN, SCORE_UNKNOWN, dsi_x_min, i - b_half_win_h, threadId);

                        cur_prev_value += max_disp_range;
                        cur_corr_row_sum += max_disp_range;
                    }

                    {
                        const int d0 = (int)(l_half_win_w) - (int)dsi_x_min;
                        const int loop = d0  - start_range;
                        const T* left = pLeft + stride + d0;
                        int index = d0 - 1;

                        for(int k = 1; k <= loop; ++k) {

                            const T* right = pRight + stride + k;
                            ResultType_Agg corr_delta = 0;

                            for (int w = -(int)l_half_win_w; w <= (int)r_half_win_w; ++w )
                                corr_delta += Cost::eval(left[w], right[w]);

                            cur_corr_row_sum[index] += corr_delta - cur_prev_value[index];
                            cur_prev_value[index] = corr_delta;
                            index += max_disp_range - 1;
                        }
                    }

                    ++stride;

                    for(uint32_t j = dsi_x_min + 1;  j < dsi_x_max; ++j, ++stride) {

                        int max_border =(int)width - 1- (int)(j + r_half_win_w);
                        int d_min = std::max(start_range, (int)(l_half_win_w) - (int)j + 1 );
                        int d_max = std::min(max_border, search_max);

                        const int index = stride + r_half_win_w;
                        const T* pLr = pLeft + index;
                        const T rr = pRight[index];
                        const int index2 = stride -(int)l_half_win_w-1;
                        const T* pLl = pLeft + index2;
                        const T rl = pRight[index2];
                        const ResultType_Agg* prev_pixel_corr = cur_prev_value - max_disp_range;

                        incr::pixel_loop<T, ResultType_Agg, Impl_Agg, Cost>::run(pLl,rl, pLr, rr, cur_prev_value, cur_corr_row_sum, prev_pixel_corr, d_min, d_max);

                        int min_index = stride - b_half_win_stride;

                        if(pTextureImage[min_index]) {

                            d_min = std::max(start_range, (int)(l_half_win_w) - (int)j);
                            int d_max = std::min(max_border, stop_range);
                            Optimization::Store(cur_corr_row_sum, j, i - b_half_win_h, d_min, d_max, threadId);
                        } else
                            Optimization::Store(DISPARITY_UNKNOWN, SCORE_UNKNOWN, j, i - b_half_win_h, threadId);

                        cur_prev_value += max_disp_range;
                        cur_corr_row_sum += max_disp_range;
                    }

                    int index = ((cur_prev_value - prev_value) / prev_value_stride) %win_h;
                    cur_prev_value = prev_value + index * prev_value_stride;
                }
            }

        private:

            const uint8_t* m_pMask;
            int32_t m_maxDisparityRangeSize;
            int m_threadRange[Threads_Agg + 1];
            uint32_t m_textureSize;
            uint32_t m_correlSize;
            uint32_t m_prevCorrelSize;
            uint32_t m_textSize;
            uint8_t* m_pTextureImage;
            ResultType_Agg* m_pCorrel[Threads_Agg];
            ResultType_Agg* m_pCorrel__Buffer[Threads_Agg];
            ResultType_Agg* m_pPrevCorrel[Threads_Agg];
            ResultType_Agg* m_pPrevCorrel__Buffer[Threads_Agg];
            void* m_pText[Threads_Agg];
            void* m_pPrevText[Threads_Agg];
    };
}

#endif
