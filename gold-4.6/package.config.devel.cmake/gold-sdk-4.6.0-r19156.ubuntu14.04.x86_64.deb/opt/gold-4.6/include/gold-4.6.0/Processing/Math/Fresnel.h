/****************************************************************************
 *              fresnel.h -
 *  Calculation of Fresnel integrals by expansion to Chebyshev series
 *  Expansions are taken from the book
 *  Y.L. Luke. Mathematical functions and their approximations.
 *  �oscow, "Mir", 1980. PP. 145-149 (Russian edition)
 ****************************************************************************
 */

#ifndef FRESNEL_H_
#define FRESNEL_H_

#include <Processing/Math/gold_proc_math_export.h>

namespace math {

/** fresnel_c(x) - Fresnel Cosine Integral
 * \\pgx_disabled_f$ C(x)=fresnel_c(x)=\dint\limits_{0}^{x}\cos (\frac{\pi}{2}t^{2})dt \\f$
 */
GOLD_PROC_MATH_EXPORT double fresnel_c(double x);

/** fresnel_s(x) - Fresnel Sine Integral
 * \\pgx_disabled_f$ S(x)=fresnel_s(x)=\dint\limits_{0}^{x}\sin (\frac{\pi}{2}t^{2})dt \\f$
 */
GOLD_PROC_MATH_EXPORT double fresnel_s(double x);

/* Additional functions*/

/** fresnel_c1(x)
 * \\pgx_disabled_f$ fresnel_c1(x)=fresnel_c(x*sqrt(2/pi))=
 * = \sqrt{\frac{2}{\pi }}\dint\limits_{0}^{x}\cos (t^{2})dt \\f$
 */
GOLD_PROC_MATH_EXPORT double fresnel_c2(double x);

/** fresnel_s1(x)
 * \\pgx_disabled_f$ fresnel_s1(x)=fresnel_s(x*sqrt(2/pi))=
 * = \sqrt{\frac{2}{\pi }}\dint\limits_{0}^{x}\sin (t^{2})dt \\f$
 */
GOLD_PROC_MATH_EXPORT double fresnel_s2(double x);

}

#endif /* FRESNEL_H_ */

