#ifndef _CONVOLUTION_KERNEL_H
#define _CONVOLUTION_KERNEL_H

/** @file ConvolutionKernel.h
  * @brief implmenetazione interna dei filtri convolutivi a pesi fissi e dimensione fissa
  * ogni filtro convolutivo deve avere alcuni campo fissi, come
  *  - bool positive: se tutti i pesi sono positivi o meno 
  *  - int magnitude: somma in valore assoluto dei pesi
  *  - int bias:      somma dei pesi
  *  - int range:     intervallo
  **/

#include <cmath>
#include "BaseFilter.h"
#include "detail/FilterModifier.hxx"

namespace cimage {
  
namespace kernel {

/// Filtro convolutivo 2x2
template<int m00, int m01,
         int m10, int m11
         >
class TConvolutionKernel2x2 : public filter::ImplPixelOperator
{
  public:

   static const int bias = m00+m01+m10+m11; 
    
   static const bool positive = (m00>=0)&&(m01>=0)&&(m10>=0)&&(m11>=0);
    
   static const unsigned int magnitude = static_abs(m00) + static_abs(m01) + 
					 static_abs(m10) + static_abs(m11);
   template<class D>
   inline D zero() const { return D(0); }

   inline uint32_t GetWidth() const { return 2; }
   inline uint32_t GetHeight() const { return 2; }

   template<typename S>
   struct Return {
        //typedef typename cimage::PixelTraits<S>::DifferenceType Type;
	typedef int16_t Type; // TODO
	};

   template<typename S>
   inline typename Return<S>::Type operator() ( const S* I, long stride ) const
    {
      return (typename Return<S>::Type) m00*I[  -stride - 1] + m01*I[  -stride + 0] + 
			       m10*I[          - 1] + m11*I[          + 0];
  	     
    }
};

/// Filtro convolutivo 3x3
template<int m00, int m01, int m02, int m10, int m11, int m12, int m20, int m21, int m22>
class TConvolutionKernel3x3 : public filter::ImplPixelOperator
{
  public:
    
   static const int bias = m00+m01+m02+
			   m10+m11+m12+
			   m20+m21+m22;
    
   static const bool positive = (m00>=0)&&(m01>=0)&&(m02>=0)&&
				(m10>=0)&&(m11>=0)&&(m12>=0)&&
				(m20>=0)&&(m21>=0)&&(m22>=0);

    
   static const unsigned int magnitude = static_abs(m00) + static_abs(m01) + static_abs(m02) + 
					 static_abs(m10) + static_abs(m11) + static_abs(m12) + 
					 static_abs(m20) + static_abs(m21) + static_abs(m22);

   template<class D>
   inline D zero() const { return D(0); }

   inline uint32_t GetWidth() const { return 3; }
   inline uint32_t GetHeight() const { return 3; }

   template<typename S>
   struct Return {
        //typedef typename cimage::PixelTraits<S>::DifferenceType Type;
	typedef int16_t Type; // TODO
	};

   template<typename S>
   inline typename Return<S>::Type operator() ( const S* I, long stride ) const
    {
      return (typename Return<S>::Type)  m00*I[-stride - 1]  + m01*I[-stride + 0]  + m02*I[-stride + 1]
			      + m10*I[        - 1]  + m11*I[        + 0]  + m12*I[        + 1]
			      + m20*I[+stride - 1]  + m21*I[+stride + 0]  + m22*I[+stride + 1];
    }
};

/// Filtro convolutivo 5x5
template<int m00, int m01, int m02, int m03, int m04,
	 int m10, int m11, int m12, int m13, int m14,
	 int m20, int m21, int m22, int m23, int m24,
         int m30, int m31, int m32, int m33, int m34,
	 int m40, int m41, int m42, int m43, int m44>
class TConvolutionKernel5x5 : public filter::ImplPixelOperator
{
  public:

   static const bool positive = (m00>=0)&&(m01>=0)&&(m02>=0)&&(m03>=0)&&(m04>=0)&&
				(m10>=0)&&(m11>=0)&&(m12>=0)&&(m13>=0)&&(m14>=0)&&
				(m20>=0)&&(m21>=0)&&(m22>=0)&&(m23>=0)&&(m24>=0)&&
				(m30>=0)&&(m31>=0)&&(m32>=0)&&(m33>=0)&&(m34>=0)&&
				(m40>=0)&&(m41>=0)&&(m42>=0)&&(m43>=0)&&(m44>=0);

   static const int bias = m00+m01+m02+m03+m04+
				m10+m11+m12+m13+m14+
				m20+m21+m22+m23+m24+
				m30+m31+m32+m33+m34+
				m40+m41+m42+m43+m44;    
   static const unsigned int magnitude = static_abs(m00) + static_abs(m01) + static_abs(m02) +static_abs(m03) + static_abs(m04) +
 					 static_abs(m10) + static_abs(m11) + static_abs(m12) +static_abs(m13) + static_abs(m14) +
 					 static_abs(m20) + static_abs(m21) + static_abs(m22) +static_abs(m23) + static_abs(m24) +
 					 static_abs(m30) + static_abs(m31) + static_abs(m32) +static_abs(m33) + static_abs(m34) +
 					 static_abs(m40) + static_abs(m41) + static_abs(m42) +static_abs(m43) + static_abs(m44);

   template<class D>
   inline D zero() const { return D(0); }

   inline uint32_t GetWidth() const { return 5; }
   inline uint32_t GetHeight() const { return 5; }

   template<typename S>
   struct Return {
        //typedef typename cimage::PixelTraits<S>::DifferenceType Type;
	typedef int Type; // TODO
	};

   template<typename S>
   inline typename Return<S>::Type operator() ( const S* I, long stride ) const
    {
      return (typename Return<S>::Type) m00*I[-2*stride - 2] + m01*I[-2*stride - 1] + m02*I[-2*stride    ] + m03*I[-2*stride + 1] +  m04*I[-2*stride + 2] +
			       m10*I[-1*stride - 2] + m11*I[-1*stride - 1] + m12*I[-1*stride    ] + m13*I[-1*stride + 1] +  m14*I[-1*stride + 2] +
	                       m20*I[          - 2] + m21*I[          - 1] + m22*I[            0] + m23*I[          + 1] +  m24*I[          + 2] +
	                       m30*I[+1*stride - 2] + m31*I[+1*stride - 1] + m32*I[+1*stride    ] + m33*I[+1*stride + 1] +  m34*I[+1*stride + 2] +
	                       m40*I[+2*stride - 2] + m41*I[+2*stride - 1] + m42*I[+2*stride    ] + m43*I[+2*stride + 1] +  m44*I[+2*stride + 2];
    }
};

/// Filtro convolutivo 4x4
template<int m00, int m01, int m02, int m03, 
         int m10, int m11, int m12, int m13, 
         int m20, int m21, int m22, int m23,
         int m30, int m31, int m32, int m33
         >
class TConvolutionKernel4x4 : public filter::ImplPixelOperator
{
  public:
   
    static const bool positive = (m00>=0)&&(m01>=0)&&(m02>=0)&&(m03>=0)&&
				(m10>=0)&&(m11>=0)&&(m12>=0)&&(m13>=0)&&
				(m20>=0)&&(m21>=0)&&(m22>=0)&&(m23>=0)&&
				(m30>=0)&&(m31>=0)&&(m32>=0)&&(m33>=0);

    static const int bias = m00+m01+m02+m03+
				m10+m11+m12+m13+
				m20+m21+m22+m23+
				m30+m31+m32+m33;
				
   static const unsigned int magnitude = static_abs(m00) + static_abs(m01) + static_abs(m02) +static_abs(m03) +
					 static_abs(m10) + static_abs(m11) + static_abs(m12) +static_abs(m13) +
					 static_abs(m20) + static_abs(m21) + static_abs(m22) +static_abs(m23) +
					 static_abs(m30) + static_abs(m31) + static_abs(m32) +static_abs(m33);
   template<class D>
   inline D zero() const { return D(0); }

   inline uint32_t GetWidth() const { return 4; }
   inline uint32_t GetHeight() const { return 4; }

   template<typename S>
   struct Return {
        //typedef typename cimage::PixelTraits<S>::DifferenceType Type;
	typedef int16_t Type; // TODO
	};

   template<typename S>
   inline typename Return<S>::Type operator() ( const S* I, long stride ) const
    {
      return (typename Return<S>::Type)  m00*I[-2*stride - 2] + m01*I[-2*stride - 1] + m02*I[-2*stride + 0] + m03 * I[-2*stride + 1]
                              + m10*I[  -stride - 2] + m11*I[  -stride - 1] + m12*I[  -stride + 0] + m13 * I[  -stride + 1]
  	                      + m20*I[          - 2] + m21*I[          - 1] + m22*I[          + 0] + m23 * I[          + 1]
  	                      + m30*I[   stride - 2] + m31*I[   stride - 1] + m32*I[   stride + 0] + m33 * I[   stride + 1];
  	     
    }
};

template<int m00, int m01, int m02, int m03, int m04, int m05,
         int m10, int m11, int m12, int m13, int m14, int m15,
         int m20, int m21, int m22, int m23, int m24, int m25,
         int m30, int m31, int m32, int m33, int m34, int m35,
         int m40, int m41, int m42, int m43, int m44, int m45,
         int m50, int m51, int m52, int m53, int m54, int m55
         >
class TConvolutionKernel6x6: public filter::ImplPixelOperator
{
  public:
    
    static const bool positive = (m00>=0)&&(m01>=0)&&(m02>=0)&&(m03>=0)&&(m04>=0)&&(m05>=0)&&
				  (m10>=0)&&(m11>=0)&&(m12>=0)&&(m13>=0)&&(m14>=0)&&(m15>=0)&&
				  (m20>=0)&&(m21>=0)&&(m22>=0)&&(m23>=0)&&(m24>=0)&&(m25>=0)&&
				  (m30>=0)&&(m31>=0)&&(m32>=0)&&(m33>=0)&&(m34>=0)&&(m35>=0)&&
				  (m40>=0)&&(m41>=0)&&(m42>=0)&&(m43>=0)&&(m44>=0)&&(m45>=0)&&
				  (m50>=0)&&(m51>=0)&&(m52>=0)&&(m53>=0)&&(m54>=0)&&(m55>=0);
    
    static const int bias = m00+m01+m02+m03+m04+m05+
				  m10+m11+m12+m13+m14+m15+
				  m20+m21+m22+m23+m24+m25+
				  m30+m31+m32+m33+m34+m35+
				  m40+m41+m42+m43+m44+m45+
				  m50+m51+m52+m53+m54+m55;
				  
    static const unsigned int magnitude = static_abs(m00) + static_abs(m01) + static_abs(m02) + static_abs(m03) + static_abs(m04) + static_abs(m05) + 
					  static_abs(m10) + static_abs(m11) + static_abs(m12) + static_abs(m13) + static_abs(m14) + static_abs(m15) + 
					  static_abs(m20) + static_abs(m21) + static_abs(m22) + static_abs(m23) + static_abs(m24) + static_abs(m25) + 
					  static_abs(m30) + static_abs(m31) + static_abs(m32) + static_abs(m33) + static_abs(m34) + static_abs(m35) + 
					  static_abs(m40) + static_abs(m41) + static_abs(m42) + static_abs(m43) + static_abs(m44) + static_abs(m45) + 
					  static_abs(m50) + static_abs(m51) + static_abs(m52) + static_abs(m53) + static_abs(m54) + static_abs(m55);

   template<class D>
   inline D zero() const { return D(0); }

   inline uint32_t GetWidth() const { return 6; }
   inline uint32_t GetHeight() const { return 6; }

   template<typename S>
   struct Return {
        //typedef typename cimage::PixelTraits<S>::DifferenceType Type;
	typedef int16_t Type; // TODO
	};

   template<typename S>
   inline typename Return<S>::Type operator() ( const S* I, long stride ) const
    {
      return (typename Return<S>::Type)  m00*I[-3*stride - 3] + m01*I[-3*stride - 2] + m02*I[-3*stride - 1] + m03 * I[-3*stride + 0] + m04 * I[-3*stride + 1] + m05 * I[-3*stride + 2] +
			        m10*I[-2*stride - 3] + m11*I[-2*stride - 2] + m12*I[-2*stride - 1] + m13 * I[-2*stride + 0] + m14 * I[-2*stride + 1] + m15 * I[-2*stride + 2] +
			        m20*I[-1*stride - 3] + m21*I[-1*stride - 2] + m22*I[-1*stride - 1] + m23 * I[-1*stride + 0] + m24 * I[-1*stride + 1] + m25 * I[-1*stride + 2] +
			        m30*I[ 0*stride - 3] + m31*I[ 0*stride - 2] + m32*I[ 0*stride - 1] + m33 * I[ 0*stride + 0] + m34 * I[ 0*stride + 1] + m35 * I[ 0*stride + 2] +
			        m40*I[ 1*stride - 3] + m41*I[ 1*stride - 2] + m42*I[ 1*stride - 1] + m43 * I[ 1*stride + 0] + m44 * I[ 1*stride + 1] + m45 * I[ 1*stride + 2] +
			        m50*I[ 2*stride - 3] + m51*I[ 2*stride - 2] + m52*I[ 2*stride - 1] + m53 * I[ 2*stride + 0] + m54 * I[ 2*stride + 1] + m55 * I[ 2*stride + 2];
           
    }
};

} // Kenrnel

} // cimage

#endif
