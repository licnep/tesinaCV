#ifndef _CDSI_H
#define _CDSI_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file CDSI.h
 * \author Paolo Zani (zani@ce.unipr.it)
 * \date 2006-04-04
 */

#include <Processing/Vision/Stereo/gold_proc_stereo_export.h>
#define TCUSTOMPIXEL_EXPORT GOLD_PROC_STEREO_EXPORT 
#include <Data/CImage/Pixels/TCustomPixel.h>
#undef TCUSTOMPIXEL_EXPORT
#include <Data/CImage/Images/CImageRGB8.h>
#include <Data/CImage/Images/CImageRGBA8.h>
#include <Data/CImage/PixelTraits/PixelTraits.h>
#include <Data/CImage/TImage.h>
#include <Processing/Vision/CImage/BasicOperations/BasicOperations.h>
#include <limits>

CIMAGE__DECLARE_CUSTOM_PIXEL(float, Disparity, GOLD_PROC_STEREO_EXPORT);

/**
 * \class CDSI
 * \brief Disparity Space Image class
 * This class represents a Disparity Space Image
 */
typedef cimage::TImage<Disparity> CDSI;

extern GOLD_PROC_STEREO_EXPORT  const Disparity DISPARITY_UNKNOWN;

GOLD_PROC_STEREO_EXPORT cimage::CImageRGBA8& operator >> (const CDSI& src, cimage::CImageRGBA8& dst);
GOLD_PROC_STEREO_EXPORT cimage::CImageRGB& operator >> (const CDSI& src, cimage::CImageRGB& dst);

GOLD_PROC_STEREO_EXPORT cimage::RGBA DisparityToRGBA(Disparity in, int32_t dmin, int32_t dmax);

namespace cimage
{
    template<> inline uint8_t PixelTraits<Disparity>::Channels() { return 1; }
    template<> inline Disparity PixelTraits<Disparity>::Min() { return Disparity (std::numeric_limits<Disparity>::min()); }
    template<> inline Disparity PixelTraits<Disparity>::Max() { return Disparity (std::numeric_limits<Disparity>::max()); }
    template<> inline Disparity PixelTraits<Disparity>::Zero() { return DISPARITY_UNKNOWN; }
}



#endif
