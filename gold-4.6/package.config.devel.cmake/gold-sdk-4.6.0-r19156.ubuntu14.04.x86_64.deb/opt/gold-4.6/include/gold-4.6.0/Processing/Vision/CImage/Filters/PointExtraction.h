#ifndef _POINT_EXTRACTION_H
#define _POINT_EXTRACTION_H

/** @brief serie di funzioni per semplificare l'estrazione di feature da immagini
 **/

#include <Data/Math/Points.h>

/// Funzione per sapere se il punto H e' un massimo nell'intorno w x h
/// \code
/// if(isMaximum<7,7>(&H[i+j*width], width)) { do_something }
/// \endcode
template<int w, int h, class T>
bool isMaximum(const T *H, int stride)
{
for(int j=-(h-1)/2;j<=(h-1)/2;++j)
 for(int i=-(w-1)/2;i<=(w-1)/2;++i)
  if ( ( (i!=0)||(j!=0) ) && (H[i+j*stride]>H[0]) )
  	return false;
return true;
}

/** Analizza una immagine di tipo generico e ritorna i massimi locali
 * \code
 * std::vector<Point2i> list;
 *
 * ExtractLocalMaxima<3,3>(HarrisCornerImage, width, height, list);
 * \endcode
**/
template<int w, int h, class T, class R>
void ExtractLocalMaxima(const T *src, unsigned int width, unsigned int height, R & list)
{
for(int j=(h-1)/2;j+(h-1)/2<=height;++j)
 {
 for(int i=(w-1)/2;i+(w-1)/2<=width;++i)
   {
   if(isMaximum<w,h>(&src[i], width))
	list.push_back(Point2i(i,j));
   }
 src+=width;
 }
}

/** Analizza una immagine di tipo generico e ritorna i massimi locali maggiori di una certa soglia
 * \code
 * std::vector<Point2i> list;
 *
 * ExtractLocalMaxima<3,3>(HarrisCornerImage, width, height, th, list);
 * \endcode
 * @note controllare che il parametro th sia dello stesso tipo di src altrimenti non compila
**/
template<int w, int h, class T, class R>
void ExtractLocalMaxima(const T *src, unsigned int width, unsigned int height, T th, R & list)
{
for(int j=(h-1)/2;j+(h-1)/2<=height;++j)
 {
 for(int i=(w-1)/2;i+(w-1)/2<=width;++i)
   {
   if((src[i]>th)&&(isMaximum<w,h>(&src[i], width)))
	list.push_back(Point2i(i,j));
   }
 src+=width;
 }
}

#endif