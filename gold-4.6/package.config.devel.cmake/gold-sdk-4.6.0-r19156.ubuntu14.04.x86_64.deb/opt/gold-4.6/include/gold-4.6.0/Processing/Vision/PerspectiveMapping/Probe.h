#ifndef _IPM_PROBE_H
#define _IPM_PROBE_H

/** @file Probe.h
  * @brief Widget per mostrare la coordinata nelle CWindow
  * @author Paolo Medici
  **/

#include <string>

#include <UI/CWindows/CWindowTypes.h>
#include <UI/CWindows/CWidget.h>
#include <Data/Math/Points.h>
#include <Data/Math/Rects.h>

#include <Processing/Vision/PerspectiveMapping/gold_proc_pm_widget_export.h>


namespace ui {
namespace win {

  // fwd
class CWindowCore;


/// Un Widget che scrive su schermo dove e' il mouse la coordinata mondo corrispondente.
/// \code
///  win->SetLayer(1);
///  win->SetColor(0,0,255);
///  win->Push(SPDrawingObject(new ProbeWidget(0,0,ipmImgWidth,ipmImgHeight)));
///  win->SetLayer(0);
/// \endcode
class GOLD_PROC_PM_WIDGET_EXPORT ProbeWidget : public CWidget
{
    public:
    // alcuni typedef (Traits) per essere indipendenti dal tipo di dati usato internamente
    typedef math::Rect2f Rect;
    private:
    /// area del widget
    Rect m_area;
    /// Punto corrente: su cui disegnare il testo (e congiungimento linea)
    math::Point2f m_pt;
    /// Origine Line
    math::Point2f m_line;
    /// Testo (X: Y:)
    std::string m_str;
    /// scostamento rispetto al punto del mouse dove compare il testo
    float m_dx,m_dy;
    /// non disegna nulla ma imposta il CustomMessage
    bool m_quiet;
    /// Track
    bool m_track;
    /// Prende il controllo dell'area
    bool m_owner;
    public:
        /// ctor:
        /// @param area rettangolo che contiene l'area da mappare
        /// @param owner se owner e' false usa @a area per delimitare il widget, altrimenti true e' tutta la finestra
        /// @param dx,dy scostamento dal cursore del testo disegnato
        /// @param quiet se quiet mostra il contenuto nella status bar usanto SetCustomStatusBar
        ProbeWidget(const Rect & area, bool owner=false, float dx=0.0f, float dy=0.0f, bool quiet=false);
        ProbeWidget(float x0, float y0, float x1, float y1, bool owner=false, float dx=0.0f, float dy=0.0f, bool quiet=false);
        virtual ~ProbeWidget();
        const char* getName() const;
        bool Interact(CWindowCoreManager* pWindow, const CWindowEvent& event);
        int Draw(CWindowCore* pWindow);
};

}
}

#endif
