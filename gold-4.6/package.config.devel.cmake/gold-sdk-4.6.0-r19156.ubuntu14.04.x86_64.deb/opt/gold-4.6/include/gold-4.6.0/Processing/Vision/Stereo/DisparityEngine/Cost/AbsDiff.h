#ifndef _ABSDIFF_H
#define _ABSDIFF_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2007                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file AbsDiff.h
 * \author Paolo Zani (zani@ce.unipr.it)
 * \date 2007-03-10
 */

#include <Data/CImage/Pixels/Mono8.h>
#include <Data/CImage/Pixels/Mono8s.h>
#include <Data/CImage/Pixels/Mono16.h>
#include <Data/CImage/Pixels/Mono16s.h>
#include <Data/CImage/Pixels/RGB8.h>
#include <Data/CImage/PixelTraits/PixelTraits.h>

#include <stdint.h>

namespace disparity
{
    namespace cost
    {
        template<typename ResultType_Cost>
        class AbsDiff
        {
            public:

                template<typename T>
                inline static ResultType_Cost eval(T p1, T p2)
                {
                    return std::abs(static_cast<typename cimage::PixelTraits<T>::DifferenceType>(p1) - static_cast<typename cimage::PixelTraits<T>::DifferenceType>(p2));
                }

                /**
                * @note here we use overloading instad of specialization because the latter is not allowed by the standard in this case
                * (static template member function, see section 14.7.3, p2)
                */

                inline static ResultType_Cost eval(cimage::Mono8 p1, cimage::Mono8 p2)
                {
                return std::abs(static_cast<int16_t>(p1) - static_cast<int16_t>(p2));
                }

                inline static ResultType_Cost eval(cimage::Mono8s p1, cimage::Mono8s p2)
                {
                    return std::abs(static_cast<int16_t>(p1) - static_cast<int16_t>(p2));
                }

                inline static ResultType_Cost eval(cimage::Mono16 p1, cimage::Mono16 p2)
                {
                    return std::abs(static_cast<int16_t>(p1) - static_cast<int16_t>(p2));
                }

                inline static ResultType_Cost eval(cimage::Mono16s p1, cimage::Mono16s p2)
                {
                    return std::abs(p1 - p2);
                }

                inline static ResultType_Cost eval(cimage::RGB8 p1, cimage::RGB8 p2)
                {
                    return std::abs(static_cast<int32_t>(p1.R) - static_cast<int32_t>(p2.R))
                        + std::abs(static_cast<int32_t>(p1.G) - static_cast<int32_t>(p2.G))
                        + std::abs(static_cast<int32_t>(p1.B) - static_cast<int32_t>(p2.B));
                }
        };
    }
}

#endif
