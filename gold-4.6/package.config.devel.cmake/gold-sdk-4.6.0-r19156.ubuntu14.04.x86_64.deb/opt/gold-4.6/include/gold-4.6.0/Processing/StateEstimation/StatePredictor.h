#ifndef _STATE_PREDICTOR_H
#define _STATE_PREDICTOR_H

/** @file
 * @brief implements base State Predictor for Kalman Filters
 * */


#include "Types.h"
#include <Eigen/Dense>

namespace state_estimation {

/** A general purpose linearized predict model, without input.
 * 
 * x_{k+1} = f(x_{k}, u_{k}) + noise(Q_k)
\code
class MyEKFPredictor: public state_estimation::LinearizedPredictor<double> {
  
  public:
  MyEKFPredictor() : state_estimation::LinearizedPredictor<double>(2) { }
  
  template<class StateType>
  void f(StateType &x1, const StateType &x) 
  { 
    ...
  }
  
  template<class StateType, class InputType>
  void f(StateType & x1, const StateType & x, const InputType & u ) 
  {
    ... only if input is used
  }

  template<class StateType>
  void Update(const StateType &x) 
  { 
    TransitionMatrix() = ....
  }
}
\endcode
* @see state_estimation::LinearPredictor
* */
template<class _Scalar, int _StateSize = Eigen::Dynamic>
class LinearizedPredictor {
  
public:
  
  typedef LinearizedImplementation Implementation;
  
  typedef Eigen::Matrix<_Scalar, _StateSize, _StateSize> MatrixAType;
  typedef Eigen::Matrix<_Scalar, _StateSize, _StateSize> MatrixQType;
  
  typedef _Scalar ScalarType;
  
  enum { StateSizePolicy = _StateSize
  };
  
protected:
  
  /// State transition matrix
  MatrixAType A; 
  /// process noise covariance matrix
  MatrixQType Q;
  
  int m_state_size;
  
public:
  LinearizedPredictor() : m_state_size( (_StateSize!=Eigen::Dynamic) ? _StateSize : 1 ) { }
  /** Initialize internal matrix size
   * @param n state size
   */
  LinearizedPredictor(int n) : A(n,n), Q(n,n), m_state_size(n) { }
  
  MatrixAType & TransitionMatrix() { return A; }
  const MatrixAType & TransitionMatrix() const { return A; }

  MatrixQType & ProcessNoiseMatrix() { return Q; }
  const MatrixQType & ProcessNoiseMatrix() const { return Q; }
  
  /** change the state size */
  void StateSize(int n) { m_state_size = n; A.resize(n,n); Q.resize(n,n); }
  /** return the state size */
  int StateSize() const {return m_state_size; }
  
  /** implement the Transition equation. 
   * 
   * In Kalman filter is linear and can be used this default. 
   * it is clear that ProcessNoiseMatrix() and TransitionMatrix() have to be correctly setted in main program.
   * */
  template<class StateType>
  void f(StateType & x1, const StateType & x)
  {
//     std::cout << "A:" << A;
    x1 = A * x;
  }
  
  /** Called before f() in order to set the new TransitionMatrix and ProcessNoiseMatrix 
   * 
   * In kalman filter this function does nothing. 
   * EKF user have to implement it and update the TransitionMatrix(), and eventually the ProcessNoiseMatrix()
   */
  template<class StateType>
  inline void Update(const StateType & s) { }
  
};


/** A general purpose linear predict model with an additional input.
 * 
 * Extend LinearizedPredictor with an additional input u_k and matrix B
 * x_{k+1} = A * x_{k} + B * u_k + noise(Q_k)
 * Extended Kalman Filter user have to implement f and Update methods as in LinearizedPredictor.
*/
template<class _Scalar, int _StateSize = Eigen::Dynamic, int _InputSize = Eigen::Dynamic>
class LinearPredictor: public LinearizedPredictor<_Scalar, _StateSize> {
  
public:
  typedef Eigen::Matrix<_Scalar, _StateSize, _InputSize> MatrixBType;
  
protected:
  
  /// input state matrix
  MatrixBType B;
  
  int m_input_size;
  
public:
  LinearPredictor() : m_input_size( (_InputSize!=Eigen::Dynamic) ? _InputSize : 1 ) { }
  /** Initialize internal matrix size
   * @param state_size state size
   * @param input_size input size
   */
  LinearPredictor(int state_size, int input_size) :  LinearizedPredictor<_Scalar, _StateSize>(state_size), B(state_size,input_size), m_input_size(input_size) { }
  
  /// permit to modify internal B matrix
  MatrixBType & InputMatrix() { return B; }
  const MatrixBType & InputMatrix() const { return B; }

  /** change the state size */
  void StateSize(int n) { LinearizedPredictor<_Scalar, _StateSize>::StateSize(n); B.resize(n, m_input_size);  }
    /** return the state size */
  int StateSize() const {return LinearizedPredictor<_Scalar, _StateSize>::StateSize(); }


  /** change the input size */
  void InputSize(int m) { m_input_size = m; B.resize(this->m_state_size, m_input_size);  }

  /** implement the Transition equation. 
   * 
   * In Kalman filter is linear and can be used this default. 
   * it is clear that ProcessNoiseMatrix() and TransitionMatrix() have to be correctly setted in main program.
   * */
  template<class StateType>
  void f(StateType & x1, const StateType & x)
  {
    LinearizedPredictor<_Scalar, _StateSize>::f(x1,x);
  }

  /** implement the Transition equation with an external input. 
   * 
   * In Kalman filter is linear and can be used this default. 
   * it is clear that ProcessNoiseMatrix(), InputMatrix() and TransitionMatrix() have to be correctly setted in main program.
   * */
  template<class StateType, class InputType>
  void f(StateType & x1, const StateType & x, const InputType & u )
  {
    LinearizedPredictor<_Scalar, _StateSize>::f(x1,x);
    x1 += B*u;
  }
  
  /** Called before f() in order to set the new TransitionMatrix and ProcessNoiseMatrix 
   * 
   * In kalman filter this function does nothing. 
   * EKF user have to implement it and update the TransitionMatrix(), and eventually the ProcessNoiseMatrix()
   */
  template<class StateType>
  inline void Update(const StateType & s) { }
};

/** Unscented predict model
 * x_{k+1} = f(x_k, u_k, w_k)
 * 
 * Unscented/Sigma Point Kalman filter user have only to implement f method
\code
class MySPKFPredictor: public state_estimation::FunctionalPredictor<double> {
  
public:
  MySPKFPredictor() : state_estimation::FunctionalPredictor<double>(2) { }
   
  template<class StateType>
  void Update(const StateType &x) 
  { 
    // is optional... can do nothing
  }

  template<class StateType, class OutStateType>
  void f(OutStateType &x1, const StateType &x) 
  { 
    // ... do something
  }
};
\endcode
 * */
template<class _Scalar, int _StateSize = Eigen::Dynamic>
struct FunctionalPredictor {
  
public:
  
  typedef UnscentedImplementation Implementation;
  
  typedef _Scalar ScalarType;
  
  typedef Eigen::Matrix<_Scalar, _StateSize, _StateSize> MatrixQType;
  
  enum { StateSizePolicy = _StateSize
  };
  
protected:
  /// process noise covariance matrix
  MatrixQType Q;
  /// state size
  int m_state_size;
public:
  FunctionalPredictor() : m_state_size( (_StateSize!=Eigen::Dynamic) ? _StateSize : 1 ) { }
  FunctionalPredictor(int n) : Q(n,n), m_state_size(n) { }

  MatrixQType & ProcessNoiseMatrix() { return Q; }
  const MatrixQType & ProcessNoiseMatrix() const { return Q; }
  
  /** change the state size */
  void StateSize(int n) { m_state_size = n; Q.resize(n,n); }
  /** return the state size */
  int StateSize() const {return m_state_size; }

  /// Process. User have to implement it
  template<class StateType, class OutStateType>
  inline void f(OutStateType & x1, const StateType & x);

  /// Process. User have to implement it
  template<class StateType, class InputType, class OutStateType> 
  inline void f(OutStateType & x1, const StateType & x, const InputType & u );
  
  /** Update is called once with previous state. 
   * User can implement it to precompute something */
  template<class StateType>
  inline void Update(const StateType & s) { }
};


}

#endif
