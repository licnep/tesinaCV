#ifndef _REF_PLANE_LIMITS_H
#define _REF_PLANE_LIMITS_H

/** @file RefPlaneLimits.h
 * @brief function to convert from a Bird Eye View (IPM) to meters and vice-versa
 * */

#include <Data/Math/TMatrices.h>
#include <Processing/Vision/PerspectiveMapping/gold_proc_pm_export.h>

/** Reference plane limits.
 *  This struct describes the plane in world coordinates
 * */
struct RefPlaneLimits
{
  /// [m] x is the distance from camera, and y the axis right - left
  double xmin, xmax, ymin, ymax;  
  /// [m] z coordinate of plane (usually 0)
  double z;                       

  /** crea l'oggetto RefPlaneLimits */
  RefPlaneLimits(double _z=0.0) : z(_z) {}
  /** crea l'oggetto RefPlaneLimits
   * xmin, ymin, xmax, ymax
   */
  RefPlaneLimits(double _xmin, double _ymin, double _xmax, double _ymax, double _z=0.0) : xmin(_xmin), xmax(_xmax), ymin(_ymin), ymax(_ymax), z(_z) {}
  
   bool IsInside(double _x, double _y) const  
       { return (_x>xmin && _x<xmax && _y>ymin && _y<ymax); }

   bool operator==(const RefPlaneLimits & rp){return (xmin==rp.xmin && xmax==rp.xmax && ymin==rp.ymin && ymax==rp.ymax && z==rp.z);}
};

/** classe per traslare punti da immagine IPM a coordinate mondo e viceversa 
 *
 * Le immagini IPM hanno lo (0,0) in alto a sinistra, mentre in coordinate mondo questo punto e' XMAX,YMAX
 *  questa classe permette di passare da un sistema di riferimento all'altro.
 *
 * \code
 * RefPlaneMapping map(limits, width, height);
 * // per convertire da un punto mondo a IPM:
 * Point2i c = map.WorldToIpm(p);
 * // per convertire un punto iPM in mondo:
 * Point2d w = map.IpmToWorld<double>(p);
 * \endcode
 * @note ::IPMImageLUT e ::PMImageLUT discendono da una RefPlaneMapping e ne ereditano i metodi
 **/
class GOLD_PROC_PM_EXPORT RefPlaneMapping {
  public:
  double dx,dy;     /// Dimensione in Pixel di 1m
  double idx,idy;   ///< 1/dx, 1/dy (dimensione in [m] di un pixel)
  double x0,y0;     /// valore in metri del punto piu' lontano a destra (XMAX, YMAX)
  double z;         ///< to preserve all information
  public:

  RefPlaneMapping() { }
  
  /** Create a refplanemapping
    * @param xmin,ymin BottomRight World coordinate
    * @param xmax,ymax TopLeft World coordinate
    * @param width,height geomtry of scene **/
  RefPlaneMapping(double xmin, double ymin, double xmax, double ymax, unsigned int width, unsigned int height){
  	SetParams(RefPlaneLimits(xmin, ymin, xmax, ymax), width, height);
  	}

  /** Inizializza il remapper
   * @param rp una struttura RefPlaneLimits_t
   * @param _width,_height dimensioni dell'immagine IPM
   **/
  RefPlaneMapping(const RefPlaneLimits & _rp, unsigned int _width, unsigned int _height)
    {    SetParams(_rp, _width, _height);      }

  /// Dopo che e' inizializzato permette di cambiare il mapping
  /// @param rp Parametri del piano (una struttura RefPlaneLimits_t inizializzata)
  /// @param width,height dimensioni dell'immagine IPM in pixels
  void SetParams(const RefPlaneLimits & rp, unsigned int width, unsigned int height);
    
/** Converte un punto da una immagine IPM, nel corrispondente punto in coordinate mondo, usando il RefPlaneLimits_t
  * @param u,v un punto in pixel dell'immagine IPM (image pixel point)
  * @return a Point2d containing (X,Y) in World Coordinate [m]
  */
template<class T>
  inline math::Point2<T> IpmToWorld(const T u, const T v) const
    {
    return math::Point2<T>( x0 - (v * idx), y0 - (u * idy));
    }

/** Converte un punto da una immagine IPM, nel corrispondente punto in coordinate mondo, usando il RefPlaneLimits_t
  * @param a un punto in coordinate pixel dell'immagine IPM 
  * @return a Point2d containing (X,Y) couple in World Coordinate
  */
 template<class T>
  inline math::Point2<T> IpmToWorld(const math::Point2<T> &a) const
    {
    return math::Point2<T>( x0 - (a.y * idx), y0 - (a.x * idy));
    }

 /** Return the matrix usefull to convert a Point from IPM to World */
 template<class T>
 math::TMatrix<T, 2,3> IpmToWorld() const
  {
	 math::TMatrix<T, 2,3> M;
	M[0] = 0.0; M[1] = - idx; M[2] = x0;
	M[3] = -idy;M[4] = 0.0;   M[5] = y0;
	return M;
  }

/** Converte un punto da coordinate mondo al corrispondente punto in coordinate IPM
  * @param X,Y un punto in coordinate mondo X,Y [m]
  * @return a Point2d containing (x,y) couple in Image Coordinate
  */
template<class T>
  inline math::Point2<T> WorldToIpm(const T X, const T Y) const
    {
    return math::Point2<T>( (y0 - Y) * dy, (x0 - X) * dx);
    }

/** Converte un punto da coordinate mondo al corrispondente punto in coordinate IPM
  * @param a un Point2 in coordinate mondo x,y [m]
  * @return a Point2 containing (x,y) couple in Image Coordinate
  */
template<class T>
 inline math::Point2<T> WorldToIpm(const math::Point2<T> & a) const
    {
    return math::Point2<T>( (y0 - a.y) * dy, (x0 - a.x) * dx);
    }

 /** Return the matrix usefull to convert a Point from World to IPM */
 template<class T>
 math::TMatrix<T, 2,3> WorldToIpm() const
  {
	 math::TMatrix<T, 2,3> M;
	M[0] = 0.0; M[1] = -dy; M[2] = y0 * dy;
	M[3] = -dx; M[4] = 0.0; M[5] = x0 * dx;
	return M;
  }

/// ritorna la dimensione (in m) dei pixel dell'immagine IPM,
/// ovvero quanti metri ogni singolo pixel dell'immagine vale in coordinate mondo
/// @param xl,yl dimensioni in metri di un pixel
  template<class T>
  inline void GetPixelSize(T *xl, T *yl) const
    {
    *xl = idx;
    *yl = idy;
    }

};

#endif
