#ifndef _CALIB_TRAITS_H
#define _CALIB_TRAITS_H

#include <Data/Math/Points.h>

class FromList {
    const math::Point2d * m_first;
    const math::Point2d * m_second;
    unsigned int m_n_points;
public:
    FromList(const math::Point2d * first, const math::Point2d * second, unsigned n_points) : m_first(first), m_second(second), m_n_points(n_points) { }

    int size() const {
        return m_n_points;
    }

    const math::Point2d & first(int i) const {
        return m_first[i];
    }
    const math::Point2d & second(int i) const {
        return m_second[i];
    }
};

class FromPair {
    const std::pair<math::Point2d, math::Point2d> * m_s;
    unsigned int m_n_points;
public:
    FromPair(const std::vector< std::pair<math::Point2d, math::Point2d> > & s) : m_s(&s[0]), m_n_points(s.size()) { }

    int size() const {
        return m_n_points;
    }

    const math::Point2d & first(int i) const {
        return m_s[i].first;
    }
    const math::Point2d & second(int i) const {
        return m_s[i].second;
    }
};

class FirstOf {
    const std::pair<math::Point2d, math::Point2d> * m_ptr;
    unsigned int m_n_points;
    math::Point2d m_off;
public:
    FirstOf(const std::vector< std::pair<math::Point2d, math::Point2d> > & s, math::Point2d off=math::Point2d() ) : m_ptr(&s[0]), m_n_points(s.size()), m_off(off) { }

    int size() const {
        return m_n_points;
    }

    math::Point2d operator[](int i) const {
        return m_ptr[i].first + m_off;
    }
};

class SecondOf {
    const std::pair<math::Point2d, math::Point2d> * m_ptr;
    unsigned int m_n_points;
    math::Point2d m_off;
public:
    SecondOf(const std::vector< std::pair<math::Point2d, math::Point2d> > & s, math::Point2d off=math::Point2d() ) : m_ptr(&s[0]), m_n_points(s.size()), m_off(off) { }

    int size() const {
        return m_n_points;
    }

    math::Point2d operator[](int i) const {
        return m_ptr[i].second + m_off;
    }
};


#endif
