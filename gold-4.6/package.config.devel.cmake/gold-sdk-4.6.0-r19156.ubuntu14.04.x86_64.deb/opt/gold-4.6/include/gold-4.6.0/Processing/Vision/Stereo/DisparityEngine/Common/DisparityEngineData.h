#ifndef _DISPARITYENGINEDATA_H
#define _DISPARITYENGINEDATA_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file DisparityEngineData.h
 * \author Paolo Zani (zani@vislab.it) Mirko Felisa (felisa@vislab.it)
 * \date 2010-12-13
 */

#include <Processing/Vision/Stereo/Images/CDSI.h>
#include <Processing/Vision/Stereo/Images/CScoreImage.h>
#include <Processing/Vision/Stereo/DisparityEngine/Common/SearchRange.h>
#include <boost/shared_ptr.hpp>

namespace disparity
{
    class DisparityEngineData
    {
       protected:  
           
            boost::shared_ptr<CDSI> m_dsi;
            boost::shared_ptr<CScoreImage> m_score;            
            std::vector<SearchRange> m_searchRanges;

            uint32_t m_dsiXMin;
            uint32_t m_dsiXMax;
            uint32_t m_dsiYMin;
            uint32_t m_dsiYMax; 
            
            uint32_t m_srcXMin;
            uint32_t m_srcXMax;
            uint32_t m_srcYMin;
            uint32_t m_srcYMax; 
            
            int32_t m_dispMin;
            int32_t m_dispMax;
            
            int m_downsample_ratio;
    };
}

#endif