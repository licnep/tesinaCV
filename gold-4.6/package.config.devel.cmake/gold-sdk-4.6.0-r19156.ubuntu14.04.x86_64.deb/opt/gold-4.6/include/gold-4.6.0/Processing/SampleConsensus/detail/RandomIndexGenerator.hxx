#ifndef _RANDOMINDEXGENERATOR_H
#define _RANDOMINDEXGENERATOR_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file RandomIndexGenerator.hxx
 * @author Paolo Zani (zani@vislab.it)
 * @date 2012-03-07
 */

#include <boost/nondet_random.hpp>
#include <boost/dynamic_bitset/dynamic_bitset.hpp>
#include <boost/random/mersenne_twister.hpp>
#include <boost/random/uniform_int.hpp>
#include <boost/random/variate_generator.hpp>

#include <cstddef>

namespace sample_consensus
{
    namespace detail
    {
        class RandomIndexGenerator : public boost::dynamic_bitset<>
        {
            boost::variate_generator<boost::mt19937, boost::uniform_int<> > m_generator;

            public:

            RandomIndexGenerator(size_t min, size_t max) :
                boost::dynamic_bitset<>(max - min + 1), m_generator(boost::mt19937(boost::random_device()()), boost::uniform_int<>(min, max))
            {}

            size_t operator()()
            {
                size_t idx;

                do
                {
                    idx = m_generator();
                } while((*this)[idx]);

                (*this)[idx] = true;

                return idx;
            }
        };
    }
}

#endif
