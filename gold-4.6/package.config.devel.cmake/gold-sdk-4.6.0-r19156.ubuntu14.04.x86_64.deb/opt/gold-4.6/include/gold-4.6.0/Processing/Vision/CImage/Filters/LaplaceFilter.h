#ifndef _LAPLACE_FILTER_H
#define _LAPLACE_FILTER_H

#include "ConvolutionKernel.h"
#include "TLocalFilter.h"

/** @file LaplaceFilter.h
  * @brief Filtro di Laplace
  **/

namespace cimage {

namespace kernel {
  
/**
 * \brief Implementa il calcolo di una maschera w x h di Laplace
*/
template<uint32_t w, uint32_t h>
class Laplace;

/**
 * \brief Implementa il calcolo di una maschera 3x3 di Laplace
*/
// qualcuno qua usa 4, ippiFilterLaplace usa 8
template<>
class Laplace<3, 3>: public TConvolutionKernel3x3<-1,-1,-1, -1,8,-1, -1,-1,-1>
{
};

/**
 * \brief Implementa il calcolo di una maschera 5x5 di Laplace
*/
template<>
class Laplace<5, 5>: public TConvolutionKernel5x5<0,0,-1,0,0, 0,-1,-2,-1,0, -1,-2,16,-1,-2,  0,-1,-2,-1,0, 0,0,-1,0,0>
{
};

////////////////////////////

/** laplace normalizzato con segno **/
typedef filter::Div<Laplace<3,3>, 16> Laplace3x3;
/** laplace normalizzato con segno **/
typedef filter::Div<Laplace<5,5>, 32> Laplace5x5;

/** laplace3x3 normalizzato alzato di 127
  * \code
  * TLocalFilter< LaplaceBias3x3 > filter;
  * filter(m_inputImageMono, m_outputImageMono);
  * \endcode
  **/
typedef filter::Bias<Laplace3x3, 127> LaplaceBias3x3;
/// laplace5x5 normalizzato alzato di 127
typedef filter::Bias<Laplace5x5, 127> LaplaceBias5x5;
}

// filtri
namespace filter {
  typedef TLocalFilter< kernel::Laplace3x3 > Laplace3x3;
  typedef TLocalFilter< kernel::Laplace5x5 > Laplace5x5;
  typedef TLocalFilter< kernel::LaplaceBias3x3 > LaplaceBias3x3;
  typedef TLocalFilter< kernel::LaplaceBias5x5 > LaplaceBias5x5;
};

} // namespace cimage

#endif
