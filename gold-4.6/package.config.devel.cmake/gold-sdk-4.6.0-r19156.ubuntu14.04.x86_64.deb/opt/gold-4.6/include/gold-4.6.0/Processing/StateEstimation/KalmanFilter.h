#ifndef _KALMAN_FILTER_H
#define _KALMAN_FILTER_H




/** @defgroup SE State Estimation
 *  Implements a generic Linear/Extended/Unscented Kalman Filter
 * 
 * Common Include Files
 * \code
 * #include <Processing/StateEstimation/StateObserver.h>
 * #include <Processing/StateEstimation/StatePredictor.h>
 * \endcode
 *
 * Linear or Extended Kalman Filter
 * \code
 * #include <Processing/StateEstimation/ExtendedKalmanFilter.h>
 * \endcode
 * 
 * Sigma Point Additional Include
 * \code
 * #include <Processing/StateEstimation/SigmaPointKalmanFilter.h>
 * \endcode
*/


#include "Types.h"
#include <Eigen/Dense>

#include "detail/ExtendedKalmanFilter.hxx"

/**
 * \brief Namespace for State Estimation Processing Library
*/
namespace state_estimation {

/// A Default Error Policy used in kalman. If you need a different errort (for example circular distance for angles), you must implement it.  
class DefaultErrorPolicy {
  public:
    template<class T>
    inline T operator()(const T &a, const T &b) const {
      return (a-b);
    }
  };

/** @brief Implements a linear, extended or unscented kalman filter.
 * @ingroup SE
 * 
 * If internally is used Linear Kalman, Extended Kalman, or Unscented Kalman Filter depend on the traits inside Observer and Predictor policy.
 * @param T precision (usually double)
 * 
 * Example of Kalman Filter:
 * \code
 * state_estimation::Kalman<double, state_estimation::LinearPredictor<double> , state_estimation::LinearObserver<double> > filter(state_size, observer_size);
 * \endcode
 * 
 * Example of Extended Kalman Filter:
 * \code
 * class MyEKFPredictor: public state_estimation::LinearPredictor<double> {
 * ...
 * };
 * 
 * class MyEKFObserver: public state_estimation::LinearObserver<double> {
 * ...
 * };
 * 
 * state_estimation::Kalman<double, MyEKFPredictor, MyEKFObserver> filter(state_size);
 * \endcode
 * 
 * Example of Sigma Point (Unscented) Kalman Filter:
 * \code
 * class MyUKFPredictor: public state_estimation::FunctionalPredictor<double> {
 * ...
 * };
 * 
 * class MyUKFObserver: public state_estimation::FunctionalObserver<double> {
 * ...
 * };
 * 
 * state_estimation::Kalman<double, MyUKFPredictor, MyUKFObserver> filter;
 * \endcode
 * @see state_estimation::LinearPredictor, state_estimation::LinearObserver, state_estimation::FunctionalPredictor, state_estimation::FunctionalObserver
 * */


template<class _Scalar, class Predictor, class Observer, class ErrorPolicy = DefaultErrorPolicy >
class Kalman : public detail::KalmanImpl<typename Predictor::Implementation, typename Observer::Implementation, _Scalar, Predictor, Observer, ErrorPolicy> 
{
  // internal filter implementation
  typedef detail::KalmanImpl<typename Predictor::Implementation, typename Observer::Implementation, _Scalar, Predictor, Observer, ErrorPolicy>  Impl;

public:
  /// the State type
  typedef typename Impl::StateType StateType;
  /// the Covariance Matrix type
  typedef typename Impl::CovarianceMatrixType CovarianceMatrixType;
public:
  
 Kalman() { }
 /** initialize Kalman filter with state size */
 Kalman(int state_size) : Impl(state_size) { }
 /** initialize kalman filter with state size and observation size
   * \code
   * state_estimation::Kalman<double, state_estimation::LinearPredictor<double> , state_estimation::LinearObserver<double> > filter(state_size, observer_size);
   * \endcode
   **/
 Kalman(int state_size, int observation_size) : Impl(state_size, observation_size) { }
  /** initialize kalman filter with state, input and observation size */
 Kalman(int state_size, int input_size, int observation_size) : Impl(state_size, input_size, observation_size) { }
 
 ~Kalman() { }

 /// Simulate prediction step
 template<class StateType>
 void Simulate(StateType & x1)
 {
   Impl::Simulate(x1);
 }
 
 /** execute one step of Kalman Filter using observation @a z
  * \code
  * filter.Step(z);
  * \endcode
  * */
 template<class ObservationType>
 void Step(const ObservationType & z)
 {
   Impl::Predict();
   Impl::Observe(z);
 }

 /** execute one step of Kalman Filter with input @a u
  * \code
  * filter.Step(u, z);
  * \endcode
  * */
 template<class InputType, class ObservationType>
 void Step(const InputType & u, const ObservationType & z)
 {
   Impl::Predict(u);
   Impl::Observe(z);
 }

 
 /** Read the internal Kalman State
  * \code
  * std::cout << filter.State() << std::endl;
  * \endcode
  **/
 inline const StateType & State() const { return Impl::State(); }
 /** Set the internal Kalman State
  * \code
  * filter.State() << x0, x1, x2, ..., xn;
  * \endcode
  **/
 inline StateType & State() { return Impl::State(); }
 
 /// return the state covariance matrix
 inline const CovarianceMatrixType & CovarianceMatrix() const { return Impl::CovarianceMatrix();}
 /** set the covariance matrix
  * \code
  * filter.CovarianceMatrix().setIdentity();
  * \endcode
  * */
 inline CovarianceMatrixType & CovarianceMatrix() { return Impl::CovarianceMatrix();}  
};

}

#endif
