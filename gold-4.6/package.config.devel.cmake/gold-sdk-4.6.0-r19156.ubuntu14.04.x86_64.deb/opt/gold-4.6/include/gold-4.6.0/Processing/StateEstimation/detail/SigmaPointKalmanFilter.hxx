#ifndef _SIGMA_POINT_KALMAN_FILTER_HXX
#define _SIGMA_POINT_KALMAN_FILTER_HXX

#include <iostream>
#include <vector>

#include <boost/static_assert.hpp>

#include "KalmanFilter.hxx"

#include <Eigen/Core>
#include <Eigen/Cholesky>
#include <Eigen/LU>

#define debug_sigma_point   false

namespace state_estimation {

namespace detail {

// un wrapper tra SigmaPoint Kalman e un Predictor utente
template<class _Predict>
class _predict_policy {
    _Predict & predict;
public:
    _predict_policy(_Predict & p) : predict(p) { }
    template<class X, class Y>
    void operator()(Y & y, const X & x)
    {
        predict.f(y, x);
    }
};

// un wrapper tra SigmaPoint Kalman e un Predictor utente, con un parametro extra
template<class _Predict, class _Param1>
class _predict_policy_param {
    _Predict & predict;
    _Param1 & param1;
public:
    _predict_policy_param(_Predict & p, _Param1 & p1) : predict(p), param1(p1) { }
    template<class X, class Y>
    void operator()(Y & y, const X & x)
    {
        predict.f(y, x, param1);
    }
};

// un wrapper tra SigmaPoint Kalman e un Observer utente
template<class _Observe>
class _observe_policy {
    _Observe & observe;
public:
    _observe_policy(_Observe & o): observe(o) { }
    template<class X, class Y>
    void operator()(Y & y, const X & x)
    {
        observe.h(y, x);
    }
};


/// Genera i Sigma Points partendo da x e Pxx e li proietta attraverso la policy @a f
/// @param f funzione per trasformare @a x
/// @param[out] sp  i sigma points trasformati
/// @param[in] x lo stato
/// @param[in] Pxx matrice di covarianza dello stato
/// @param gamma scaling factor gamma = sqrt(n + lambda)
template<class _Policy, class XSigmaPointType, class XMatrixType>
void sigma_points(_Policy f, std::vector<XSigmaPointType> & sp, const XSigmaPointType & x, const XMatrixType & Pxx, double gamma)
{
    const int n = x.size();
    // const typename Eigen::LLT<XMatrixType>::Traits::MatrixL L = Pxx.llt().matrixL();
    Eigen::MatrixXd L = Pxx.llt().matrixL();
//    const typename Eigen::LLT<XMatrixType>::Traits::MatrixL L = Pxx.llt().matrixL();

    sp.resize(2*n+1);

    sp[0].resize(x.rows());
    // sigma point centrale
    f(sp[0], x);

    // per ogni dimensione n
    for(int i = 0; i<n; ++i)
    {
        // sigma point
        XSigmaPointType v = gamma * L.col(i);
        sp[1+i*2].resize( x.rows() );
        sp[2+i*2].resize( x.rows() );
        f(sp[1+i*2], x + v );
        f(sp[2+i*2], x - v );
    }

//    if(debug_kalman)
//    {
//    std::cerr << "sigma points:\n";
//    for(int i = 0;i<2*n+1; ++i)
//      std::cerr << i << '\t' << sp[i] << std::endl;
//    }
}

/// proietta i sigma points @a xp sui sigma points @a yp attraverso la policy @a policy
/// @param size output size (YSigmaPoint)
template<class _Policy, class YSigmaPoint, class XSigmaPoint>
void project(_Policy policy, std::vector<YSigmaPoint> & yp, const std::vector<XSigmaPoint> & xp, int size)
{
    yp.resize(xp.size());
    for(unsigned int i =0; i<xp.size(); ++i)
    {
        yp[i].resize(size); //
        policy(yp[i], xp[i]);
        if(debug_sigma_point)
        {
            std::cout << "sp " << i << " | x = " << xp[i].transpose() << " | y = " << yp[i].transpose() << std::endl;
        }
    }
}

/// dati dei sigma points yp calcola il valor medio y
/// weight are lambda/(n+lambda) for central moment, and 1/2(n + lambda) for other moment
/// @note YMatrixType e SPYMatrixType potrebbero essere diverse, anche se DEVONO avere la stessa dimensione effettiva
template<class YMatrixType, class SPYMatrixType>
void average(YMatrixType & y, const std::vector<SPYMatrixType> & yp, int n, double lambda)
{
    double scale = n+lambda;
    // pesi e fattore di normalizzazione: w0 + 2 * n * wi = 1
    double w0 = lambda / scale;	  // central moment
    double wi = 1.0 / (2.0*scale); // others moment

    if(debug_sigma_point)
        std::cout << "[average] scale = " << scale << " | w0 = " << w0 << " | wi = " << wi << std::endl;

    // accumulatore stato
    y = yp[0];
    y *= w0;

    // per ogni dimensione (da 0..n)
    for(int i = 0; i<n; ++i)
    {
        // compute average
        YMatrixType sum = yp[1+i*2] + yp[2+i*2]; // sommo i pesi simmetrici intanto
        sum *= wi;
        y += sum;
    }

}

/// calcola la matrice di covarianza Pyy dato y e yp.
/// weight are lambda/(n+lambda) + central_boost for central moment, and 1/2(n + lambda) for other moment
template<class CovarianceMatrixType, class YVectorType>
void covariance( CovarianceMatrixType & Pyy, const YVectorType & y, const std::vector<YVectorType> & yp, int n, double lambda, double central_boost)
{
    double scale = n+lambda;
    double w0 = (lambda / scale) + central_boost; // central moment
    double wi = 1.0 / (2.0*scale);                // other moment
    YVectorType tmp;

    if(debug_sigma_point)
        std::cout << "[covariance] scale = " << scale << " | w0 = " << w0 << " | wi = " << wi << std::endl;

    tmp = yp[0] - y;
    // procedo al calcolo di Pyy
    Pyy = tmp * tmp.transpose();
//    std::cerr << "outer_prod:" << Pyy << std::endl;
    Pyy *= w0;

    for(int i =1; i<2*n+1; ++i)
    {
        tmp = yp[i] - y;
        Pyy+= wi * (tmp * tmp.transpose() );

    }
}

/// calcola la matrice di (cross) covarianza Pyy dato y e yp e crosscovarianza Pxy dato x e xp
template<class PXYMatrixType, class PYYMatrixType, class YMatrixType, class XMatrixType>
void cross_covariance( PXYMatrixType & Pxy,
                       PYYMatrixType & Pyy,
                       const YMatrixType & y,
                       const std::vector<YMatrixType> & yp,
                       const XMatrixType & x,
                       const std::vector<XMatrixType> & xp,
                       int n, double lambda, double central_boost)
{
    double scale = n+lambda; // L+lambda
    double w0 = (lambda / scale) + central_boost ;
    double wi = 1.0 / (2.0*scale);
    YMatrixType yt;
    XMatrixType xt;

    if(debug_sigma_point)
        std::cout << "[cross_covariance] scale = " << scale << " | w0 = " << w0 << " | wi = " << wi << std::endl;

    yt = yp[0] - y;
    xt = xp[0] - x;
    // procedo al calcolo di Pyy
    Pyy = yt * yt.transpose();
    Pyy *= w0;
    if(debug_sigma_point)
        std::cout << "outer_prod:" << Pyy << std::endl;

    Pxy = xt * yt.transpose();
    Pxy *= w0;

    for(int i =1; i<2*n+1; ++i)
    {
        yt = yp[i] - y;
        xt = xp[i] - x;
        Pyy+= wi * (yt * yt.transpose() );
        Pxy+= wi * (xt * yt.transpose() );
    }
}

/// calcola y e Pyy da yp.
template<class YMatrixType, class PYYMatrixType>
void unscent_transform(YMatrixType & y, PYYMatrixType & Pyy, const std::vector<YMatrixType> & yp, int n, double lambda, double central_boost)
{
    average(y, yp, n, lambda);
    covariance(Pyy, y, yp, n, lambda, central_boost);
}

// l'effettiva implementazione di Kalman quando Predictor e Observer sono unscented
template<class _Scalar, class Predictor, class Observer, class ErrorPolicy>
class KalmanImpl<UnscentedImplementation, UnscentedImplementation, _Scalar, Predictor, Observer, ErrorPolicy> : public Predictor, public Observer {

    /// Observer STATE SIZE == Predictor STATE SIZE
    BOOST_STATIC_ASSERT(  ((int) Predictor::StateSizePolicy == (int) Eigen::Dynamic) ||
                          ((int) Observer::StateSizePolicy == (int) Eigen::Dynamic) ||
                          ((int) Predictor::StateSizePolicy == (int) Observer::StateSizePolicy) );

    enum {
        StateSizePolicy = ((int) Predictor::StateSizePolicy != (int) Eigen::Dynamic) ? (int) Predictor::StateSizePolicy : (int) Observer::StateSizePolicy,
        ObservationSizePolicy = (int) Observer::ObservationSizePolicy
    };

public:

    typedef typename Observer::ObservedType ObservedType;
    typedef Eigen::Matrix<_Scalar, StateSizePolicy, 1> StateType;
    typedef Eigen::Matrix<_Scalar, StateSizePolicy, StateSizePolicy> CovarianceMatrixType;
    typedef Eigen::Matrix<_Scalar, StateSizePolicy, ObservationSizePolicy>  MatrixKType;
    typedef Eigen::Matrix<_Scalar, StateSizePolicy, ObservationSizePolicy>  XYCovarianceMatrixType;
    typedef Eigen::Matrix<_Scalar, ObservationSizePolicy, ObservationSizePolicy>  YYCovarianceMatrixType;

private:

    /// current state
    StateType x;
    /// next state
    StateType x1;
    /// covariance process matrix
    CovarianceMatrixType P;

    /// kalman gain
    MatrixKType K;

    /// Cross covariance (state, observation)
    XYCovarianceMatrixType Pxy;
    /// Cross Covariance (observation)
    YYCovarianceMatrixType Pyy;

    /// Sigma points (state)
    std::vector<StateType> sp;
    /// Sigma points (observation)
    std::vector<ObservedType> yp;

    // parametri empirici
    _Scalar alpha; ///< compreso tra 1e-4 e 1
    _Scalar beta;  ///< vale 2 per le gaussiane
    _Scalar kappa; ///< vale 0 normalmente

    // parametri calcolati
    _Scalar lambda;		///< lambda = a^2(n+k)-n
    _Scalar gamma;		///< gamma = sqrt(n + lambda)
    _Scalar central_boost;	///< boost = 1 - a^2 + b
private:

    void PrecomputeParams()
    {
        lambda = alpha * alpha * (StateSize() + kappa) - StateSize(); // a^2(n+k)-n
        gamma = std::sqrt(StateSize() + lambda);   // sqrt( n + lambda)
        central_boost = 1.0 - alpha * alpha + beta; // 1 - a^2 + b

        if(debug_sigma_point)
            std::cout << "lambda = " << lambda << " | gamma = " << gamma << " | central_boost = " << central_boost << std::endl;

    }


    void CommonSetUp()
    {
//       Pyy.resize(Observer::ObservationSize(), Observer::ObservationSize() ); // covariance fa questo lavoro
    }

public:

/// initialize the filter with a state @a size
    KalmanImpl(int size)
    {
        StateSize(size);
//   Weights(1e-3, 2.0, 3.0-size); // default
        Weights(1.0, 2.0, 3.0-size); // default

        CommonSetUp();
    }

    KalmanImpl()
    {
//    Weights(1e-3, 2.0, 0.0);
        Weights(1.0, 2.0, 0.0); // MMMMH

        CommonSetUp();
    }

    ~KalmanImpl()
    {
    }

// template<class UserStateType, class UserCovarianceMatrixType>
// void State(const UserStateType & x0, const UserCovarianceMatrixType & P0)
// {
//   x = x0;
//   P = P0;
// }

/// return the size of state
    int StateSize() const {
        return x.rows();
    }
/// initialize the filter with a state @a size
    void StateSize(int size)
    {
        x.resize(size);
        x1.resize(size);
        P.resize(size,size);
        // forward
        Predictor::StateSize(size);
        // forward
        Observer::StateSize(size);

//   Pxy.resize(size, Observer::ObservationSize() );  // covariance fa questo lavoro
        if(debug_sigma_point)
            std::cout << "state_size = " << size << std::endl;

        PrecomputeParams();
    }

/// set UKF parameters
    void Weights(double a, double b, double k)
    {
        alpha = a;
        beta = b;
        kappa = k;

        PrecomputeParams();
    }

/// simulate the future state of the system (without change it)
/// @param x1 return the future state
    template<class StateType>
    void Simulate(StateType & x1)
    {
      this->f(x1, x);
      /*
        const unsigned int n = this->x.cols();
        StateType tmp;

        sigma_points(_predict_policy<Predictor>(*this), sp, this->x, this->P, gamma);

        // calcolo x e P (stime a priori) usando le stime di x attraverso sp
        unscent_transform(x1, tmp, sp, n, lambda, central_boost);
        */
    }

    /// using sigma points computed by Predict() extract most probable observation
    template<class ObservationType>
    void Expected_Observation(ObservationType & z1)
    {
        const unsigned int n = this->x.cols();

//         sigma_points(_predict_policy<Predictor>(*this), sp, this->x, this->P, gamma);

        // proietto sp su yp usando policy 2*n+1 punti
        project(_observe_policy<Observer>(*this), yp, sp, z1.rows());

        // calcolo y da yp
        average(z1, yp, n, lambda);
    }
    
/// simulate the future state of the system (without change it)
/// @param x1 return the future state
/// @param input the input param
    template<class StateType, class InputType>
    void Simulate(const InputType & input, StateType & x1)
    {
    }

    template<class InputType>
    void Predict(const InputType & u)
    {
        const unsigned int n = x.rows();
        Predictor::Update(this->x);
        this->P += Predictor::ProcessNoiseMatrix();
        if(debug_sigma_point)
        {
            std::cout << "P = " << this->P << std::endl;
        }
        sigma_points(_predict_policy_param<Predictor, InputType>(*this, u), sp, this->x, this->P, gamma);
        unscent_transform(this->x, this->P, sp, n, lambda, central_boost);
    }

/// Uses an unscent transforms to predict the new state
/// predict must have a predict.f(x) function e predict.Q(x) function
    void Predict()
    {
        const unsigned int n = x.rows();
//     const double k = kappa(n);

//     if(debug_kalman)
//       std::cerr << "P-:" << this->P << std::endl;

        // segnalo un nuovo stato per permettere l'aggiornamento di Q
        Predictor::Update(this->x);
        // NOTE aggiungo il rumore a P qua
        this->P += Predictor::ProcessNoiseMatrix();
        if(debug_sigma_point)
        {
            std::cout << "P = " << this->P << std::endl;
        }
        // TODO serve lo stato aumentato n+q e nel nostro caso il rumore di processo e' uguale allo stato, percio' 2n
        //      vengono generati n sigma-points da P e n sigma points da Q
        // riempio sp con le proiezioni di x usando P
        sigma_points(_predict_policy<Predictor>(*this), sp, this->x, this->P, gamma);

        // calcolo x e P (stime a priori) usando le stime di x attraverso sp
        unscent_transform(this->x, this->P, sp, n, lambda, central_boost);

//     if(debug_kalman)
//       {
//       std::cerr << "x-:" << this->x << std::endl;
//       std::cerr << "P-:" << this->P << std::endl;
//       }

    }

    void Observe(const ObservedType & z)
    {
        const unsigned int n = x.rows();
        // average projected sigma points
        ObservedType y;
//     const double k = kappa(n);

        if(debug_sigma_point)
        {
            std::cout << "n = " << n << std::endl;
        }



        // segnalo un nuovo x all'osservatore
        Observer::Update(this->x);

        // proietto sp su yp usando policy 2*n+1 punti
        project(_observe_policy<Observer>(*this), yp, sp, z.rows());

        // calcolo y da yp
        average(y, yp, n, lambda);

        if(debug_sigma_point)
        {
            std::cout << "y:" << y.transpose() << std::endl;
        }

        // calcolo la covarianza Pyy e la crosscovarianza Pxy
        cross_covariance(Pxy, Pyy, y, yp, this->x, sp, n, lambda, central_boost);

        if(debug_sigma_point)
        {
            std::cout << "[UKF] Pyy =\n" << Pyy << std::endl;
            std::cout << "[UKF] Pxy =\n" << Pxy << std::endl;
        }

        // fase di aggiornamento della misura
        Pyy += Observer::ObservationNoiseMatrix();

        // serve?
        K.resize(n, Observer::ObservationSize() );

        // guadagno di Kalman (inverse using LU?)
        this->K = Pxy * Pyy.inverse();

        if(debug_sigma_point)
        {
            std::cout << "[UKF] K = \n" << this->K << std::endl;
        }

        // aggiornamento stato
        ErrorPolicy ep;
        ObservedType e = ep(z, y);
        if(debug_sigma_point)
        {
            std::cout << "[UKF] z = " << z.transpose() << std::endl;
            std::cout << "\ty = " << y.transpose() << std::endl;
            std::cout << "\te = " << e.transpose() << std::endl;
        }
        // blend using kalman gain:
        this->x += this->K * e;
        if(debug_sigma_point)
            std::cout << "\tx+ = " << this->x.transpose() << std::endl;

        // aggiornamento varianza
        this->P -= this->K * Pyy * this->K.transpose();

        if(debug_sigma_point)
            std::cout << "[UKF] P+ = " << this->P << std::endl;

    }

/// return the inner state
    inline const StateType & State() const {
        return x;
    }
    inline StateType & State() {
        return x;
    }

/// return the state covariance matrix
    inline const  CovarianceMatrixType & CovarianceMatrix() const {
        return P;
    }
    inline CovarianceMatrixType & CovarianceMatrix() {
        return P;
    }

};


}

}


#endif
