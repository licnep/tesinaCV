#ifndef _UI_ELAS_H
#define _UI_ELAS_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2011                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/


/**
 * \file UI_Elas.h
 * \author Mirko Felisa (felisa@vislab.it, )Paolo Zani (zani@vislab.it)
 * \date 2012-02-08
 */

#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/ELAS/Params.h>
#include <UI/Panel/Panel.h>


namespace disparity
{
    // forward declarations

    namespace agg
    {
        template<typename ResultType_Cost, typename _ResultType_Agg, typename Impl_Agg, uint32_t _Threads_Agg>
        class ELAS;
    }

    template<typename Aggregation, typename Engine>
    class UI_Aggregation;

    template<typename ResultType_Cost, typename ResultType_Agg, typename Impl_Agg, uint32_t Threads_Agg, typename Engine>
    class UI_Aggregation<agg::ELAS<ResultType_Cost, ResultType_Agg, Impl_Agg, Threads_Agg>, Engine>
    {
    public:

        UI_Aggregation (Engine* _this) : m_this (_this) {}

        void Init (INIFile* pIni)
        {

            ui::conf::Configuration conf (pIni);


            ui::var::Range<int32_t> stepsize (&m_this->m_stepsize, 1, 10, 1);
            conf.Bind (stepsize, "STEP SIZE", m_this->m_stepsize);
            ui::var::Range<int32_t> lrcheckth (&m_this->m_lr_threshold, 0, 5, 1);
            conf.Bind (lrcheckth, "LR THRESH", m_this->m_lr_threshold);
            ui::var::Range<int32_t>support_texture (&m_this->m_support_texture, 0, 20, 1);
            conf.Bind (support_texture, "SUPPORT TEXTURE THRESH", m_this->m_support_texture);
            ui::var::Range<float>support_threshold (&m_this->m_support_threshold, 0.5f, 1.0f, 0.05f);
            conf.Bind (support_threshold, "SUPPORT UNIQUES", m_this->m_support_threshold);
            ui::var::Range<int32_t>incon_window_size (&m_this->m_incon_window_size, 1, 10, 1);
            conf.Bind (incon_window_size, "INCONSISTENT CHECK SIZE", m_this->m_incon_window_size);
            ui::var::Range<int32_t> incon_threshold (&m_this->m_incon_threshold, 1, 10, 1);
            conf.Bind (incon_threshold, "INCONSISTENT THRESH", m_this->m_incon_threshold);
            ui::var::Range<int32_t> incon_min_support (&m_this->m_incon_min_support, 1, 20, 1);
            conf.Bind (incon_min_support, "INCONSISTENT CLUSTER SIZE", m_this->m_incon_min_support);
            ui::var::Value<bool> add_corners (&m_this->m_add_corners);
            conf.Bind (add_corners, "ADD CORNER POINTS", m_this->m_add_corners);
            ui::var::Range<int32_t> grid_size (&m_this->m_grid_size, 1, 40, 1);
            conf.Bind (grid_size, "GRID SIZE", m_this->m_grid_size);
            ui::var::Range<float> sigma (&m_this->m_sigma, 0.5f, 5.0f, 0.2f);
            conf.Bind (sigma, "SIGMA", m_this->m_sigma);
            ui::var::Range<float> beta (&m_this->m_beta, 0.001f, 0.1f, 0.001f);
            conf.Bind (beta, "BETA", m_this->m_beta);
            ui::var::Range<float> gamma (&m_this->m_gamma, 1.0f, 8.0f, 0.1f);
            conf.Bind (gamma, "GAMMA", m_this->m_gamma);
            ui::var::Range<float> sradius (&m_this->m_sradius, 1.0f, 8.0f, 0.1f);
            conf.Bind (sradius, "SIGMA RADIUS", m_this->m_sradius);
            ui::var::Range<int32_t>match_texture (&m_this->m_match_texture, 0, 20, 1);
            conf.Bind (match_texture, "MATCH TEXTURE THRESH", m_this->m_match_texture);
            ui::var::Range<float> speckle_sim_threshold (&m_this->m_speckle_sim_threshold, 0.0f, 5.0f, 1.0f);
            conf.Bind (speckle_sim_threshold, "SPECKLE THRESH", m_this->m_speckle_sim_threshold);
            ui::var::Range<uint32_t> speckle_size (&m_this->m_speckle_size, 0U, 800U, 1U);
            conf.Bind (speckle_size, "SPECKLE SIZE", m_this->m_speckle_size);
            ui::var::Range<int32_t>ipol_gap_width (&m_this->m_ipol_gap_width, 1, 100, 1);
            conf.Bind (ipol_gap_width, "GAP WIDTH", m_this->m_ipol_gap_width);
            ui::var::Value<bool> filter_adaptive_mean (&m_this->m_filter_adaptive_mean);
            conf.Bind (filter_adaptive_mean, "ADAPTIVE MEAN", m_this->m_filter_adaptive_mean);
            ui::var::Value<bool> filter_median (&m_this->m_filter_median);
            conf.Bind (filter_median, "MEDIAN MEAN", m_this->m_filter_median);
            ui::var::Map<uint32_t> downsampleratio(&m_this->m_downsampleratio, std::make_pair("1", 1U), std::make_pair("2", 2U) );
            conf.Bind(downsampleratio, "DOWNSAMPLE RATIO", std::string("1"));

            m_panel
            (
                ui::wgt::VBoxSizer ("").Border (3)
                (

                    ui::wgt::Scroll()
                    (
                        ui::wgt::GridSizer().Border (3)
                        (
                            ui::wgt::SzCell (0, 0) (ui::wgt::Text ("Add Corner Points").Border(3)),        ui::wgt::SzCell (0, 1).HExpand() (ui::wgt::CheckBox (add_corners)),
                            ui::wgt::SzCell (1, 0)( ui::wgt::Text("Downsample ratio").Border(3) ), ui::wgt::SzCell(1, 1).HExpand(0)(ui::wgt::ComboBox(downsampleratio).Border(3).HExpand(0).Geometry(50,-1)),                          
                            ui::wgt::SzCell (2, 0) (ui::wgt::Text ("Step Size").Border(3)),                ui::wgt::SzCell (2, 1).HExpand() (ui::wgt::Slider (stepsize)),
                            ui::wgt::SzCell (3, 0) (ui::wgt::Text ("L/R Check Threshold").Border(3)),      ui::wgt::SzCell (3, 1).HExpand() (ui::wgt::Slider (lrcheckth)),
                            ui::wgt::SzCell (4, 0) (ui::wgt::Text ("Support Min Texture").Border(3)),      ui::wgt::SzCell (4, 1).HExpand() (ui::wgt::Slider (support_texture)),
                            ui::wgt::SzCell (5, 0) (ui::wgt::Text ("Support Uniquess").Border(3)),         ui::wgt::SzCell (5, 1).HExpand() (ui::wgt::Slider (support_threshold)),
                            ui::wgt::SzCell (6, 0) (ui::wgt::Text ("Inconsistent Check Size").Border(3)),  ui::wgt::SzCell (6, 1).HExpand() (ui::wgt::Slider (incon_window_size)),
                            ui::wgt::SzCell (7, 0) (ui::wgt::Text ("Inconsistent Threshold").Border(3)),   ui::wgt::SzCell (7, 1).HExpand() (ui::wgt::Slider (incon_threshold)),
                            ui::wgt::SzCell (8, 0) (ui::wgt::Text ("Inconsistent Cluster Size").Border(3)), ui::wgt::SzCell (8, 1).HExpand() (ui::wgt::Slider (incon_min_support)),
                            ui::wgt::SzCell (9, 0) (ui::wgt::Text ("Grid Size").Border(3)),                ui::wgt::SzCell (9, 1).HExpand() (ui::wgt::Slider (grid_size))
                        ).Add
                        (
                            ui::wgt::SzCell (10, 0) (ui::wgt::Text ("Sigma").Border(3)),                   ui::wgt::SzCell (10, 1).HExpand() (ui::wgt::Slider (sigma)),
                            ui::wgt::SzCell (11, 0) (ui::wgt::Text ("Beta").Border(3)),                    ui::wgt::SzCell (11, 1).HExpand() (ui::wgt::Slider (beta)),
                            ui::wgt::SzCell (12, 0) (ui::wgt::Text ("Gamma").Border(3)),                   ui::wgt::SzCell (12, 1).HExpand() (ui::wgt::Slider (gamma)),
                            ui::wgt::SzCell (13, 0) (ui::wgt::Text ("Sigma Radius").Border(3)),            ui::wgt::SzCell (13, 1).HExpand() (ui::wgt::Slider (sradius)),
                            ui::wgt::SzCell (14, 0) (ui::wgt::Text ("Match Min Texture").Border(3)),       ui::wgt::SzCell (14, 1).HExpand() (ui::wgt::Slider (match_texture)),
                            ui::wgt::SzCell (15, 0) (ui::wgt::Text ("Speckle Threshold").Border(3)),       ui::wgt::SzCell (15, 1).HExpand() (ui::wgt::Slider (speckle_sim_threshold)),
                            ui::wgt::SzCell (16, 0) (ui::wgt::Text ("Gap Width").Border(3)),               ui::wgt::SzCell (16, 1).HExpand() (ui::wgt::Slider (ipol_gap_width)),
                            ui::wgt::SzCell (17, 0) (ui::wgt::Text ("Sigma Radius").Border(3)),            ui::wgt::SzCell (17, 1).HExpand() (ui::wgt::Slider (sradius)),
                            ui::wgt::SzCell (18, 0) (ui::wgt::Text ("Adaptive Mean Filter")),              ui::wgt::SzCell (18, 1).HExpand() (ui::wgt::CheckBox (filter_adaptive_mean)),
                            ui::wgt::SzCell (19, 0) (ui::wgt::Text ("Median Filter").Border(3)),           ui::wgt::SzCell (19, 1).HExpand() (ui::wgt::CheckBox (filter_median))
                        )
                    )
                )
            );
        }

        inline std::string Name()
        {
            return "ELAS";
        }

        inline ui::wgt::Widget Panel()
        {
            return m_panel;
        }

    private:

        Engine* m_this;
        ui::wgt::VSizer m_panel;
    };
}

#endif
