#ifndef _CIMAGE_OPERATOR_REGISTER_H
#define _CIMAGE_OPERATOR_REGISTER_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/

/**
 * \file CImageOperatorRegister.h
 * \author Paolo Grisleri (grisleri@ce.unipr.it), Paolo Zani (zani@ce.unipr.it)
 * \date 2006-05-10
 */

#include <Data/CImage/CImage.h>
#include <Libs/Patterns/Factory.h>


namespace vl
{
////////////////////////////////////////////////////////////////////////////////
// class template BasicDispatcher
// Implements a logarithmic double dispatcher for functors (or functions)
// Doesn't offer automated casts or symmetry
////////////////////////////////////////////////////////////////////////////////

    template
    <
        class BaseLhs,
        class BaseRhs = BaseLhs,
        typename ResultType = void,
        typename CallbackType = ResultType (*)(BaseLhs&, BaseRhs&)
    >
    class BasicDispatcher
    {
        typedef std::pair<cimage::CImage::Type,cimage::CImage::Type> KeyType;
        typedef CallbackType MappedType;
        typedef std::map<KeyType, MappedType> MapType;
        MapType callbackMap_;
        
        void DoAdd(cimage::CImage::Type lhs, cimage::CImage::Type rhs, CallbackType fun);
        bool DoRemove(cimage::CImage::Type lhs, cimage::CImage::Type rhs);
        
    public:
        template <class SomeLhs, class SomeRhs>
        void Add(CallbackType fun)
        {
            DoAdd(SomeLhs::type_info(), SomeRhs::type_info(), fun);
        }
        
        template <class SomeLhs, class SomeRhs>
        bool Remove()
        {
            return DoRemove(SomeLhs::type_info(), SomeRhs::type_info());
        }
        
        ResultType Go(BaseLhs& lhs, BaseRhs& rhs);
    };

    // Non-inline to reduce compile time overhead...
    template <class BaseLhs, class BaseRhs, 
        typename ResultType, typename CallbackType>
    void BasicDispatcher<BaseLhs,BaseRhs,ResultType,CallbackType>
         ::DoAdd(cimage::CImage::Type lhs, cimage::CImage::Type rhs, CallbackType fun)
    {
        callbackMap_[KeyType(lhs, rhs)] = fun;
    }
        
    template <class BaseLhs, class BaseRhs, 
        typename ResultType, typename CallbackType>
    bool BasicDispatcher<BaseLhs,BaseRhs,ResultType,CallbackType>
         ::DoRemove(cimage::CImage::Type lhs, cimage::CImage::Type rhs)
    {
        return callbackMap_.erase(KeyType(lhs, rhs)) == 1;
    }

    template <class BaseLhs, class BaseRhs, 
        typename ResultType, typename CallbackType>
    ResultType BasicDispatcher<BaseLhs,BaseRhs,ResultType,CallbackType>
               ::Go(BaseLhs& lhs, BaseRhs& rhs)
    {
        typename MapType::key_type k(lhs.TypeInfo(),rhs.TypeInfo());
        typename MapType::iterator i = callbackMap_.find(k);
        if (i == callbackMap_.end())
        {
                throw std::runtime_error("Function not found");
        }
        return (i->second)(lhs, rhs);
    }
} // namespace vl


namespace cimage
{
  template
  <
  typename RegisterType
  >
  class GOLD_PROC_CIMAGE_EXPORT OperatorRegister :
        public vl::BasicDispatcher< const CImage, CImage, CImage&>
  {
      typedef vl::BasicDispatcher<const CImage, CImage, CImage& > MyType;
      // NOTE: Loki definisce MappedType come una typedef privata qui lo ridefiniamo
      typedef CImage& ( *MappedType ) ( const CImage&, CImage& );
    public:
      template <class SomeLhs, class SomeRhs>
      bool Register ( SomeRhs& ( *pTypedOperator ) ( SomeLhs&, SomeRhs& ) )
      {

        // trasforma l'operator tipato in uno sulle classi base
        MappedType pOperator = reinterpret_cast<MappedType> ( pTypedOperator );

        // registra l'operator
        MyType::Add<SomeLhs,SomeRhs> ( pOperator );
        return true;
      }

      static OperatorRegister & Instance()
      {
        static OperatorRegister _this;
        return _this;
      }
  };

}



/**
 * @note
 * to add a new register put the register class declaration and a registration macro in a new .h file
 * \code
 *
 * class CImageMyOpRegister : public CImageOperatorRegister< CImageMyOpRegister, const CImage, CImage, CImage& > {};
 * namespace cimage{}
 * #define CIMAGE__REGISTER_MYOP( M, N ) static bool _myop_##M##N = CImageMyOpRegister::Instance().Register<const M, N > ( operator >> )
 *
 * \endcode
 */

#endif
