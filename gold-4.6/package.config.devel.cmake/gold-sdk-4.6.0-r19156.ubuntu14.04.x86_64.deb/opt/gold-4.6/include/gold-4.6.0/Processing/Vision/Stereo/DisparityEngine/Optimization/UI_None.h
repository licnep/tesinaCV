#ifndef _UI_NONE_H
#define _UI_NONE_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2011                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/


/**
 * \file UI_None.h
 * \author Mirko Felisa (felisa@vislab.it) Paolo Zani (zani@vislab.it)
 * \date 2011-02-08
 */

#include <UI/Panel/Panel.h>

namespace disparity
{
    // forward declarations

    namespace opt
    {
        template<typename ResultType_Agg, uint32_t Threads_Agg, typename ResultType_Opt, typename Impl_Opt, uint32_t Threads_Opt> class None {};
    }

    template<typename Aggregation, typename Engine>
    class UI_Optimization;

    template<typename ResultType_Agg, uint32_t Threads_Agg, typename ResultType_Opt, typename Impl_Opt, uint32_t Threads_Opt, typename Engine>
    class UI_Optimization<opt::None<ResultType_Agg, Threads_Agg, ResultType_Opt, Impl_Opt, Threads_Opt>, Engine>
    {
    public:

        UI_Optimization (Engine* _this) {}

        void Init (INIFile* pIni) {}

        inline std::string Name()
        {
            return "";
        }

        inline ui::wgt::Widget Panel()
        {
            return ui::wgt::Widget();
        }

    };
}

#endif
