#ifndef _CONVEXHULL_HXX
#define _CONVEXHULL_HXX

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file ConvexHull.hxx
 * @author Mirko Felisa (felisa@vislab.it)
 * @date 2012-04-16
 */

#include<Processing/Tessellation/ConvexHull.h>
#include<Processing/Tessellation/Data.h>
#include<Processing/Tessellation/detail/Predicates.h>
#include<Processing/Tessellation/detail/Sort.h>
#include <boost/integer.hpp>
#include <boost/utility/enable_if.hpp>
#include <boost/type_traits/is_integral.hpp>
#include <boost/mpl/if.hpp>
#include<algorithm>


namespace tessellation
{

    namespace convex_hull
    {
        template<typename T>
        void DelaunayWrapping(TriangleHull<T>& hull, typename std::vector<T>& v, bool keep_collinear)
        {
            typename TriangleHull<T>::CursorType start = hull.Cursor();
            typename TriangleHull<T>::CursorType it = start;

            if(!hull.Data().empty())
            {
                do
                {
                    v.push_back(*it.Origin());
                    it.Rotate();
                    it.Back();
                }
                while(it != start);

                if(!keep_collinear && v.size() > 2)
                {
                    T m = v[v.size() / 2];
                    T* it0 = &v[0], *it1 = it0 + 1, *it2 = it0 + 2;
                    T* begin = it0, *end = &v.back();
                    bool erase = false;
                    for(; it2 <= end; ++it2)
                    {
                        if(!detail::Counterclockwise(it0, it1, it2))
                        {
                            *it1 = *it2;
                            erase = true;
                        }
                        else
                        {
                            ++it0;
                            ++it1;
                            if(erase)
                                *it1 = *it2;
                        }
                    }

                    if(!detail::Counterclockwise(it0, it1, begin))
                        v.resize(it1 - begin);
                    else
                        v.resize(it1 - begin + 1);

                    if(v.size() == 1)
                        v.push_back(m);
                }
            }
        }

        template<typename T>
        void DelaunayWrapping(const typename std::vector<T>& point, typename std::vector<T>& v, bool keep_collinear)
        {
            if(point.size() > 2)
            {
                DelaunayTriangulation<T> dt(point);
                DelaunayWrapping(dt.Hull(), v, keep_collinear);
            }
            else
                v = point;
        }


        namespace detail
        {

            template<typename T>
            bool cmp_x(const T a, const T b)
            {
                return (a.x < b.x || ((a.x == b.x) && (a.y < b.y)));
            }


            template <typename T, typename Enabled = void>
            struct Traits
            {
                typedef T type;
            };

            template <typename T>
            struct Traits<T, typename boost::enable_if<boost::is_integral<T> >::type >
            {

                typedef typename boost::mpl::if_< boost::mpl::bool_< (sizeof(T) > 4)  > ,
                        typename boost::int_t < sizeof(T) << 3 >::fast,
                        int
                        >::type type;
            };

            template<typename T>
            inline typename Traits<T>:: type Distance(T ax, T ay, T bx, T by)
            {
                typedef typename Traits<T>:: type  type;
                type dx = (type)ax - bx;
                type dy = (type)ay - by;
                return  dx * dx + dy * dy;
            }
        }


        template<typename T>
        void GiftWrapping(const typename std::vector<T>& point, typename std::vector<T>& hull, bool keep_collinear)
        {
            if(point.size() <= 2)
            {
                hull = point;
                return;
            }

            if(!keep_collinear)
            {
                typename std::vector<T>::const_iterator it = std::min_element(point.begin(), point.end(), detail::cmp_x<T>), it0 = it;
                do
                {
                    hull.push_back(*it);
                    typename std::vector<T>::const_iterator it2 = it + 1;
                    for(typename std::vector<T>::const_iterator it3 = it2 + 1; it3 < point.end(); ++it3)
                    {
                        int c = tessellation::detail::Counterclockwise(it, it3, it2);
                        if(c > 0 || (!c && detail::Distance(it->x, it->y, it3->x, it3->y) >  detail::Distance(it->x, it->y, it2->x, it2->y)))
                            it2 = it3;
                    }

                    typename std::vector<T>::const_iterator it3 =  point.begin();
                    if(it == point.end() - 1)
                    {
                        it2 = point.begin();
                        ++it3;
                    }

                    for(; it3 != it; ++it3)
                    {
                        int c = tessellation::detail::Counterclockwise(it, it3, it2);
                        if(c > 0 || (!c && detail::Distance(it->x, it->y, it3->x, it3->y) >  detail::Distance(it->x, it->y, it2->x, it2->y)))
                            it2 = it3;
                    }

                    it = it2;
                }
                while(it != it0);
            }
            else
            {
                std::vector<typename std::vector<T>::const_iterator> buff;
                typename std::vector<T>::const_iterator it = std::min_element(point.begin(), point.end(), detail::cmp_x<T>), it0 = it;
                do
                {
                    hull.push_back(*it);
                    typename std::vector<T>::const_iterator it2 = it + 1;
                    for(typename std::vector<T>::const_iterator it3 = it2 + 1; it3 < point.end(); ++it3)
                    {
                        int c = tessellation::detail::Counterclockwise(it, it3, it2);
                        if(c > 0)
                        {
                            it2 = it3;
                            buff.clear();
                        }
                        else
                            if(!c)
                                buff.push_back(it3);

                    }

                    typename std::vector<T>::const_iterator it3 = point.begin();
                    if(it == point.end() - 1)
                    {
                        it2 = point.begin();
                        ++it3;
                    }

                    for(; it3 != it; ++it3)
                    {
                        int c = tessellation::detail::Counterclockwise(it, it3, it2);
                        if(c > 0)
                        {
                            it2 = it3;
                            buff.clear();
                        }
                        else
                            if(!c)
                                buff.push_back(it3);

                    }
                    if(!buff.empty())
                    {
                        buff.push_back(it2);
                        std::sort(buff.begin(), buff.end(), tessellation::detail::cmp_x<typename std::vector<T>::const_iterator >);

                        if(detail::Distance(it->x, it->y, buff.front()->x, buff.front()->y) < detail::Distance(it->x, it->y, buff.back()->x, buff.back()->y))
                        {
                            for(typename std::vector<typename std::vector<T>::const_iterator>::const_iterator i = buff.begin(); i != buff.end() - 1; ++i)
                                hull.push_back(**i);
                            it2 = buff.back();
                        }
                        else
                        {
                            for(typename std::vector<typename std::vector<T>::const_iterator>::const_reverse_iterator i = buff.rbegin(); i != buff.rend() - 1; ++i)
                                hull.push_back(**i);
                            it2 = buff.front();
                        }
                        buff.clear();
                    }
                    it = it2;
                }
                while(it != it0);

            }
        }

    }
}

#endif

