#ifndef _CIMAGECONVERTER_H
#define _CIMAGECONVERTER_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file cimage::CImageConversion.h
 * \author Paolo Zani (zani@ce.unipr.it)
 * \date 2006-03-24
 */

#include <Data/CImage/CImage.h>
#include <Data/CImage/TImage.h>

#include <Data/CImage/CImageFlag.h>
#include <Processing/Vision/CImage/gold_proc_cimage_export.h>
/**
 * NOTE: questa patch serve a garantire il funzionamento tra
 * MSVC e gcc-4.7
 * MSVC richiede che i template non abbiano specificatori per l'esportazione
 * gcc-4.7 richiede che i template abbiano specificatori per l'esportazione
 */
#if defined (_MSC_VER)
	#define GOLD_PROC_CIMAGE_TEMPLATE_EXPORT
#else
	#define GOLD_PROC_CIMAGE_TEMPLATE_EXPORT GOLD_PROC_CIMAGE_EXPORT
#endif


namespace cimage
{
GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( NONE );

GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( BAYER_DECODING_NONE );
GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( BAYER_DECODING_NEAREST );
GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( BAYER_DECODING_EDGE_SENSE );
GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( BAYER_DECODING_SIMPLE );
GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( BAYER_DECODING_GRADIENT );
GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( BAYER_DECODING_ADAPTIVE );
GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( BAYER_DECODING_KIMMEL );
GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( BAYER_DECODING_DOWNSAMPLE_2X );
GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( BAYER_DECODING_LUMINANCE );

GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( ALPHA_CHANNEL_NONE );
GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( ALPHA_CHANNEL_KEEP_DEST );
GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( ALPHA_CHANNEL_COLOR_KEY );

GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( COLOR_CHANNELS_AVERAGE );
GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( COLOR_CHANNELS_STANDARD_COEFFICIENTS );
GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( COLOR_CHANNEL_R );
GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( COLOR_CHANNEL_G );
GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( COLOR_CHANNEL_B );

GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( STEREO_DECODING_NONE );
GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( STEREO_DECODING_INTERLACED );
GOLD_PROC_CIMAGE_EXPORT CIMAGE__DECLARE_FLAG ( STEREO_DECODING_FIELD );

} // namespace cimage

// NOTE: cosa succede se mettiamo nel namespace cimage anche gli operatori?
namespace cimage
{

/**
 * \class CConversionInfo
 * \brief cimage::CImage conversion info class
 * This class stores the informations needed to perform a conversion between different cimage::CImage types
 */
template<typename S>
class GOLD_PROC_CIMAGE_EXPORT CConversionInfo
{
  public:

    CConversionInfo() : m_src ( NULL ), m_flags ( cimage::NONE )
    {}

    CConversionInfo ( const CConversionInfo<S>& c )
    {
      m_src = c.m_src;
      m_flags = c.m_flags;
    }

    const S* m_src;
    cimage::CImageFlagSet m_flags;
};

} // namespace cimage


GOLD_PROC_CIMAGE_EXPORT cimage::CConversionInfo<cimage::CImage> operator >> ( const cimage::CImage& src, const cimage::CImageFlag& flag );


template<typename S>
GOLD_PROC_CIMAGE_TEMPLATE_EXPORT cimage::CConversionInfo<cimage::TImage<S> > operator >> ( const cimage::TImage<S>& src, const cimage::CImageFlag& flag )
{
	cimage::CConversionInfo<cimage::TImage<S> > c;

  c.m_flags.set ( flag );
  c.m_src = &src;

  return c;
}


template<typename S>
GOLD_PROC_CIMAGE_TEMPLATE_EXPORT cimage::CConversionInfo<S> operator >> ( cimage::CConversionInfo<S> c, const cimage::CImageFlag& flag )
{
  c.m_flags.set ( flag );

  return c;
}


template<typename S, typename D>
GOLD_PROC_CIMAGE_TEMPLATE_EXPORT cimage::TImage<D>& operator >> ( const cimage::CConversionInfo<S>& c, cimage::TImage<D>& dst )
{
  // static_cast<CPropertyMap> ( dst ) = static_cast<CPropertyMap> ( * ( c.m_src ) );
  dst.MetaData() = c.m_src->MetaData();

  // if ( dst.find ( "CONVERSION FLAGS" ) == dst.end() )
  //   dst.Add ( "CONVERSION FLAGS", c.m_flags );
  
  if(dst.MetaData().count("CONVERSION FLAGS"))
    dst.MetaData().put("CONVERSION FLAGS", c.m_flags);

* ( c.m_src ) >> dst;

return dst;
}

GOLD_PROC_CIMAGE_EXPORT cimage::CImage& operator >> ( const cimage::CImage& src, cimage::CImage& dst );

template<typename S>
GOLD_PROC_CIMAGE_TEMPLATE_EXPORT cimage::CImage& operator >> ( const cimage::CConversionInfo<S>& c, cimage::CImage& dst )
{
  // static_cast<CPropertyMap> ( dst ) = static_cast<CPropertyMap> ( * ( c.m_src ) );
  dst.MetaData() = c.m_src->MetaData();

  try
  {
    // dst["CONVERSION FLAGS"]  = c.m_flags;
    dst.MetaData().put("CONVERSION FLAGS", c.m_flags);
  }
  catch ( ... /*const CPropertyNotFound& */)
  {
    // dst.Add ( "CONVERSION FLAGS", c.m_flags );
    dst.MetaData().put("CONVERSION FLAGS", c.m_flags);
  }

  * ( c.m_src ) >> dst;

  return dst;
}



template <typename D>
GOLD_PROC_CIMAGE_TEMPLATE_EXPORT cimage::TImage<D>& operator >> ( const cimage::CImage& src, cimage::TImage<D>& dst )
{
  return reinterpret_cast<cimage::TImage<D>&> ( src >> reinterpret_cast<cimage::CImage&> ( dst ) );
}


template<class S, class D>
GOLD_PROC_CIMAGE_TEMPLATE_EXPORT  cimage::TImage<D>& operator >> (const cimage::TImage<S>& src,  cimage::TImage<D>& dst );

namespace cimage
{
    template <typename S, typename D> inline cimage::TImage<D>& Convert ( const cimage::TImage<S>& src, cimage::TImage<D>& dst, const cimage::CImageFlag& flag = cimage::NONE ) { return src >> flag >> dst; }

    template <typename S> inline cimage::CImage& Convert ( const cimage::TImage<S>& src, cimage::CImage& dst, const cimage::CImageFlag& flag = cimage::NONE ) { return src >> flag >> dst; }
    
    template <typename D> inline cimage::TImage<D>& Convert ( const cimage::CImage& src, cimage::TImage<D>& dst, const cimage::CImageFlag& flag = cimage::NONE ) { return src >> flag >> dst; }
    
    inline cimage::CImage& Convert ( const cimage::CImage& src, cimage::CImage& dst, const cimage::CImageFlag& flag = cimage::NONE ) { return src >> flag >> dst; }
}

#endif
