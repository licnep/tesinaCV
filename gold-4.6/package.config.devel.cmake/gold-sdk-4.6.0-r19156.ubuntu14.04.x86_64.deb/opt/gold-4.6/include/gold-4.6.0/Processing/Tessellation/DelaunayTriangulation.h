#ifndef _DELAUNAY_TRIANGULATION_H
#define _DELAUNAY_TRIANGULATION_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file Delaunay.h
 * @author Mirko Felisa (felisa@vislab.it)
 * @date 2012-04-16
 */
#include<Processing/Tessellation/Data.h>
#include <Processing/Tessellation/gold_proc_tessellation_export.h>
#include<vector>


#ifdef __GXX_EXPERIMENTAL_CXX0X__
#include <atomic>
#define tess_atomic_int std::atomic<int>
#define tess_postincr(x) x++
#else
#define tess_atomic_int int
#define tess_postincr(x) __sync_fetch_and_add(&x, 1)
#endif

/**
 * \brief Namespace for Tessellation Processing Library
*/
namespace tessellation
{
  
    /**
    * @ingroup Tess
    * @defgroup DT Delaunay Triangulation
    * @brief Delaunay Triangulation algorithm
    * 
    * Delaunay triangulation for a set P of points in a plane is a triangulation DT(P) such that no point in P is inside the circumcircle of any triangle in DT(P).
    * For a set of points on the same line there is no Delaunay triangulation (the notion of triangulation is degenerate for this case). For four or more points 
    * on the same circle (e.g., the vertices of a rectangle) the Delaunay triangulation is not unique.
    * @{
    **/
  
  
    /**
    * @brief Defines the cut of  divide and conquer Delaunay Triangulation algorithm (X = horizontal, Y= vertical XY=alternate horizonl and vertical).
    * @note  Usually use XY. X and Y cut must be use only if the input points set is already sorted in this direction.
    *        Alternating cuts speed the algorithm and reduce its likelihood of failure.
    */
    struct Cut
    {
        enum  type {X, Y, XY};
    };


    /**
    * @brief Computes the Delaunay Triangulation of a set of points in \f$ R^{2} \f$ exploiting divide and conquer algorithm
    * @note A divide and conquer algorithm for triangulations in two dimensions is due to Lee and Schachter @cite Lee80 which was improved by Guibas and Stolfi @cite Guibas85 and later by Dwyer @cite Dwyer87 .
    * In this algorithm, one recursively draws a line to split the vertices into two sets. The Delaunay triangulation is computed for each set, and then the 
    * two sets are merged along the splitting line. Using some clever tricks, the merge operation can be done in time O(n), so the total running time is O(n log n).
    *
    **/
    template<class T>
    class GOLD_PROC_TESSELLATION_EXPORT  DelaunayTriangulation
    {
    public:

        /**
        * @brief Default class constructor
        */
        DelaunayTriangulation() {}       
        
        /**
        * @brief Computes the Delaunay Triangulation of a set of points in \f$ R^{2} \f$ exploiting divide and conquer algorithm
        * @note The input points must be unique. Duplicates can cause catastrophic failures.
        *
        * @param [in] v  Input points (e.g. std::vector<math::Point2f>)
        * @param [in] s  Defines the cut of  divide and conquer Delaunay Triangulation algorithm (X = horizontal, Y= vertical XY=alternate horizonl and vertical).
        * @param [in] threads_number Numer of threads to run in parallel. Defaults to boost::thread::hardware_concurrency().
        * 
        * @code
        * std::vector<math::Point2i> data; 
        * ...
        * tessellation::DelaunayTriangulation<math::Point2i> triangulation(data);
        * @endcode
        **/
        template< template<typename, typename> class Container, typename Allocator>
        DelaunayTriangulation(const Container<T, Allocator>& v, Cut::type  s = Cut::XY, int thread = boost::thread::hardware_concurrency())
        {
            operator()(v, s, thread);
        }

        /**
        * @brief Computes the Delaunay Triangulation of a set of points in \f$ R^{2} \f$ exploiting divide and conquer algorithm
        * @note The input points must be unique. Duplicates can cause catastrophic failures.
        *
        * @param [in] v  Input points (e.g. std::vector<math::Point2f>)
        * @param [in] s  Defines the cut of  divide and conquer Delaunay Triangulation algorithm (X = horizontal, Y= vertical XY=alternate horizonl and vertical).
        * @param [in] threads_number Numer of threads to run in parallel. Defaults to boost::thread::hardware_concurrency().
        * @return Delaunay Triangulation data structure
        * @code
        * std::vector<math::Point2i> data; 
        * ...
        * tessellation::DelaunayTriangulation<math::Point2i> triangulation;
        * triangulation(data);
        * @endcode
        **/
        template< template<typename, typename> class Container, typename Allocator>
        TriangleHull<T>& operator()(const Container<T, Allocator>& v, Cut::type  s = Cut::XY, int thread = boost::thread::hardware_concurrency());

        /**
        * @brief Returns Delaunay Triangulation data structure
        * @return Delaunay Triangulation data structure
        **/
        TriangleHull<T>& Hull()
        {
            return m_hull;
        }

    private:

        typedef typename TriangleHull<T>::CursorType HullCursorType;

        template<typename U>
        inline void  GenerateVector(const U& v);

        template<typename A>
        inline void  GenerateVector(const std::vector<T, A>& v);

        void MergeHulls(HullCursorType& far_left, HullCursorType& inner_left, HullCursorType& inner_right, HullCursorType& far_right, int axis);

        void DivConq(T** it, T** end, HullCursorType& tribegin, HullCursorType& triend, int axis, int thread);


        std::vector<T*> m_pvector;
        Cut::type m_sort;
        TriangleHull<T> m_hull;
        tess_atomic_int  hullsize;
    };
    
    /**@}*/
}


#endif
