#ifndef _ESTIMATORTRAITS_H
#define _ESTIMATORTRAITS_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file EstimatorTraits.hxx
 * @author Paolo Zani (zani@vislab.it)
 * @date 2012-04-04
 */

namespace sample_consensus
{
    namespace detail
    {
        template<typename Model>
        struct EstimatorTraits;
    }
}

#endif
