/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2007                  *
 *                                                                    *
 *       http://vislab.it                                             *
 *                                                                    *
 *  Author: Carletti Marcello (April 2003)                            *
 *          Medici Paolo (October 2004 - )                            *
 **********************************************************************/
 
#ifndef _PM_IMAGE_LUT_H
#define _PM_IMAGE_LUT_H

#include <Processing/Vision/PerspectiveMapping/ipm.h>
#include "ImageLUT.h"

/** \file PMImageLUT.h
  * \author Paolo Medici (medici@ce.unipr.it)
  * \date 12-Oct-2004
  * \brief  Questo file di header permette di eseguire operazioni prospettiche su immagini e di creare LookUpTable per mappare punti di una immagine su un'altra.
  * 
  * Le classi definite in questo documento sono
  *   
  *  - ::IPMDirectImageLUT : classe per eseguire una LUT pixel per pixel per rimuovere la prospettiva a una immagine
  *  - ::IPMBilinearImageLUT : classe per eseguire una LUT con filtro bilineare per rimuovere la prospettiva a una immagine
  *  - ::IPMFPBilinearImageLUT : classe per eseguire una LUT con filtro bilineare (fixed point) per rimuovere la prospettiva a una immagine
  *
  *  - ::PMDirectImageLUT : classe per eseguire una LUT pixel per pixel per proiettare una immagine
  *  - ::PMBilinearImageLUT : classe per eseguire una LUT con filtro bilineare per proiettare una immagine
  *  - ::PMFPBilinearImageLUT : classe per eseguire una LUT con filtro bilineare (fixed point) per proiettare una immagine
  *
  * @note queste classi sono compilate all'interno della libreria. Per usarle
  *       con proprie funzioni interpolanti includere PMImageLUT.hxx
  **/


// ------------------------------------------------------------------------------------------------------

/** la IPMImageLUT e' la base di diverse LUT che si basano su una PerspectiveMapping per creare una LUT per fare l'IPM (Inverse Perspective mapping) ovvero la possibilita' di rimuovere la prospettiva da una immagine.
 *
 *  A conti fatti questa classe e' solo un contenitore dei dati della camera e dei limiti e prototipo dei metodi da implementare
 * 
 *  Per compatibilita' verso il sistema precedente e' anche possibile accedere i metodi della classe PerspectiveMapping  ma se e' necessario applicare delle trasformazioni prospettiche senza usare la LUT e' meglio allocare e usare direttamente  la classe PerspectiveMapping.
 *
 * @see IPMBilinearImageLUT, IPMBilinearImageLUT, IPMDirectImageLUT
 **/
class GOLD_PROC_PM_EXPORT IPMImageLUT: public PerspectiveMapping, public RefPlaneMapping {
    protected:
    dev::CameraParams_t m_camParams;  ///< Backup dei dati della Camera
    bool m_computed;  ///< la lUT e' calcolata o devo eseguire la Compute?
    public:
    IPMImageLUT() : m_computed(true) {}

    IPMImageLUT(const dev::CameraParams_t & camParams) :
        PerspectiveMapping(camParams), m_camParams(camParams), m_computed(false){}

    IPMImageLUT(const dev::CameraParams_t & camParams, const RefPlaneLimits & rpMapping, unsigned int ipm_width, unsigned int ipm_height) :
        PerspectiveMapping(camParams), RefPlaneMapping(rpMapping, ipm_width, ipm_height), m_camParams(camParams), m_computed(false){}

    virtual ~IPMImageLUT();

    /// Set the parameters needed by the computation of the IPM LUT
    void SetCameraParams(const dev::CameraParams_t & camParams)
    {
        m_camParams = camParams;
        PerspectiveMapping::SetParams(camParams); 
        m_computed = false;
    }

    inline void GetCameraParams(dev::CameraParams_t & camParams) const
    {
    camParams = m_camParams;
    }

     /// E' calcolata la LUT?
     bool IsComputed() const { return m_computed; }

     /// @deprecated
     virtual void SetRefPlaneLimits(const RefPlaneLimits & rpLimits) = 0;

    /** \brief Apply LUT to a entire Image
     * @param dstImage Un buffer immagine destinazione, di dimensioni (width x height)
     * @param srcImage Un buffer immagine sorgente, di dimensioni (srcWidth, srcHeight)
     * @param bpp Byte Per pixel (1,2,3,4)
     * @param area un area rettangolare opzionale dell'immagine destinazione su cui applicare la LUT. 
     *             NULL applica su tutta l'immagine.
     */
    virtual void ApplyToImage(unsigned char* dstImage, const unsigned char* srcImage, unsigned int bpp, const math::Rect2i* area=NULL) = 0;
};

/** Template per accedere ai metodi di IPMImageLUT e permettere una specializzazione particolare
 * Il parametro per il template e' una delle classi delle ImageLUT (DirectImageLUT, BilinearImageLUT, GenericImageLUT)
 *
 * \code
 * BilinearLUT = new TIPMImageLUT<BilinearImageLUT>(ipmImgWidth, ipmImgHeight, width, height);
 * // or better:
 *  BilinearLUT = new IPMBilinearImageLUT(ipmImgWidth, ipmImgHeight, width, height);
 *
 * BilinearLUT->SetRefPlaneLimits(Limits);
 * BilinearLUT->SetCameraParams(CamParams);
 * \endcode
 *
 * Consider to use IPMBilinearImageLUT, IPMBilinearImageLUT or IPMDirectImageLUT (with different precision and speed) according to application.
 **/
template<class T>
class TIPMImageLUT: public IPMImageLUT, public T  {

    public:
    /// ctor 
    /// @param imgLUTWidth,imgLUTHeight dimensioni dell'immagine IPM
    /// @param srcImgWidth,srcImgHeight dimensioni dell'immagine sorgente (devono coincidere con quelle contenute nei dev::CameraParams_t)!
    TIPMImageLUT(unsigned int imgLUTWidth, unsigned int imgLUTHeight, unsigned int srcImgWidth, unsigned int srcImgHeight) :
  	T(imgLUTWidth, imgLUTHeight, srcImgWidth, srcImgHeight)
	{
	}

    /// ctor 
    /// @param camParams        dev::CameraParams_t con i valori width e height corretti per l'immagine sorgente
    /// @param refPlaneLimits   superficie su cui rimappare il mondo (z deve essere valido)
    /// @param imgLUTWidth,imgLUTHeight dimensioni dell'immagine IPM
    TIPMImageLUT(const dev::CameraParams_t & camParams, const RefPlaneLimits &refPlaneLimits, unsigned int imgLUTWidth, unsigned int imgLUTHeight) :
    IPMImageLUT(camParams, refPlaneLimits, imgLUTWidth, imgLUTHeight),
    T(imgLUTWidth, imgLUTHeight, camParams.width, camParams.height)
    {
    }

    // Class Destructor (virtuale, visto che IPMImageLUT lo e')
    virtual ~TIPMImageLUT() {};
    
    /// Calcola la TIPMImageLUT 
    void Compute(void);

    /// Set RefPlaneMapping::SetParams (z deve essere valido)
    void SetRefPlaneLimits(const RefPlaneLimits & rpLimits)
    {
        RefPlaneMapping::SetParams(rpLimits, T::GetWidth(), T::GetHeight());
        m_computed = false;
    }

    /** Applica la trasformazione, memorizzata nella LUT, che rappresenta una IPM all'immagine sorgente
     * @param dstImage un buffer immagine che sara' impostato con l'immagine senza la prospettiva
     * @param srcImage un buffer immagine sorgente che contiene l'immagine in prospettiva
     * @param bpp Byte Per pixel (1,2,3,4)
     * @param area una Rect2i opzionale che rappresenta la parte dell'immagine destinazione su cui applicare la lUT
     **/
    void ApplyToImage(unsigned char* dstImage, const unsigned char* srcImage, unsigned int bpp, const math::Rect2i* area = NULL)
    {
        if(!m_computed)
            Compute();
        T::ApplyToImage(dstImage, srcImage, bpp, area);
    }
    
    /** \brief Imposta il 'buffer' di dimensioni width x height (uguali all'immagine di output, e alla LUT)
    *          con pixel del colore valid e invalid a seconda se il pixel e' calcolato o meno
    *   @param buffer un array di unsigned char che verra impostato
    *   @param width,height la dimensione del buffer (puo essere diversa da quella della LUT)
    *   @param valid il valore con cui i pixel validi vengono impostati nel buffer
    *   @param invalid il valore con cui i pixel non validi vengono impostati nel buffer
    */
    void GetValidMask(unsigned char *buffer, unsigned int width, unsigned int height, unsigned char valid=0, unsigned char invalid=255);
                
};

// *************** definisco i nomi per comodita'  ************************
// typedef delle classi derivate che possono essere instanziate per eseguire una IPM. La scelta percio' ricade su una di queste 3.

/// Un oggetto IPM LUT che usa un filtro nearest
typedef TIPMImageLUT<DirectImageLUT> IPMDirectImageLUT;
/// Un oggetto IPM LUT che usa un filtro bilineare
typedef TIPMImageLUT<BilinearImageLUT> IPMBilinearImageLUT;
/// Un oggetto IPM LUT che usa un filtro bilineare fixed point
typedef TIPMImageLUT<FPBilinearImageLUT> IPMFPBilinearImageLUT;

// --------------------------- Class PMImageLUT ----------------------------

/** classe genitore per le PMImageLUT. Non puo' venire instanziata direttamente ma deve essere chiamata attraverso una delle 
 *  specializzazioni di TPMImageLUT. Permette di generare una LUT per applicare un Projective Mapping sull'immagine, ovvero
 *  aggiungere l'effetto prospettivo a una immagine. Questa classe permette di accedere ai metodi della InversePerspectiveMapping
 *  come veniva fatto precedentemente, pero' e' consigliabile creare un oggetto InversePerspectiveMapping se si vuole eseguire una 
 *  IPM e non e' usata una LUT.
 **/
class PMImageLUT: public InversePerspectiveMapping, public RefPlaneMapping {
    protected:
    /// Copia degli ultimi Camera Params usati per calcolare la LUT
    dev::CameraParams_t m_camParams;
    // i parametri sono cambiati?
    bool m_computed;
    
    public:
    PMImageLUT() : m_computed(true) {}

    PMImageLUT(const dev::CameraParams_t & camParams) :
        InversePerspectiveMapping(camParams), m_camParams(camParams) , m_computed(false){}

    PMImageLUT(const dev::CameraParams_t & camParams, const RefPlaneLimits & refPlaneLimits, unsigned int lut_width, unsigned int lut_height) :
        InversePerspectiveMapping(camParams), RefPlaneMapping(refPlaneLimits, lut_width, lut_height), m_camParams(camParams) , m_computed(false){}

    virtual ~PMImageLUT();

    /// Set the parameters needed by the computation of the IPM LUT
    void SetCameraParams(const dev::CameraParams_t & camParams)
    {
        m_camParams = camParams;
        InversePerspectiveMapping::SetParams(camParams);  // versione corretta
        m_computed = false;
    }

    inline void GetCameraParams(dev::CameraParams_t & camParams) const
    {
    camParams = m_camParams;
    }

    /// ritorna se la LUT e' gia' stata calcolata o e' da calcolare
    bool IsComputed() const { return m_computed; }

    /// @deprecated 
    virtual void SetRefPlaneLimits(const RefPlaneLimits & rpLimits) = 0;

};

/// Template per accedere ai metodi di PMImageLUT e permettere una specializzazione particolare
/// Il parametro per il template e' una delle classi delle ImageLUT (DirectImageLUT, BilinearImageLUT, GenericImageLUT)
template<class T>
class TPMImageLUT : public PMImageLUT, public T
{
  public:
    /// ctor
    /// @param imgLUTWidth,imgLUTHeight dimensione dell'immagine con prospettiva su cui trasformare l'IPM
    /// @param srcImgWidth,srcImgHeight dimensione dell'immagine IPM
    TPMImageLUT(unsigned int imgLUTWidth, unsigned int imgLUTHeight, unsigned int srcImgWidth, unsigned int srcImgHeight) 
      : T(imgLUTWidth, imgLUTHeight, srcImgWidth, srcImgHeight) {}

    /// ctor
    /// @param camParams camera params
    /// @param refPlaneLimits superficie di riferimento
    /// @param imgLUTWidth,imgLUTHeight dimensione dell'immagine con prospettiva su cui trasformare l'IPM
    /// @param srcImgWidth,srcImgHeight dimensione dell'immagine IPM
    TPMImageLUT(const dev::CameraParams_t & camParams, const RefPlaneLimits & refPlaneLimits, unsigned int imgLUTWidth, unsigned int imgLUTHeight, unsigned int srcImgWidth, unsigned int srcImgHeight)
      : PMImageLUT(camParams, refPlaneLimits, imgLUTWidth, imgLUTHeight), T(imgLUTWidth, imgLUTHeight, srcImgWidth, srcImgHeight) {}

    /// ctor
    /// @param camParams camera params. width e height vengono usati per calcolare la dimensione della LUT
    /// @param refPlaneLimits superficie di riferimento
    /// @param srcImgWidth,srcImgHeight dimensione dell'immagine IPM
    TPMImageLUT(const dev::CameraParams_t & camParams, const RefPlaneLimits & refPlaneLimits, unsigned int srcImgWidth, unsigned int srcImgHeight)
      : PMImageLUT(camParams, refPlaneLimits, camParams.width, camParams.height), T(camParams.width, camParams.height, srcImgWidth, srcImgHeight) {}
    
    // Class Destructor (virtuale, visto che il papa' lo e')
    virtual ~TPMImageLUT() {};

    /// Set RefPlaneMapping::SetParams (z deve essere valido)
    void SetRefPlaneLimits(const RefPlaneLimits & rpLimits)
    {
        RefPlaneMapping::SetParams(rpLimits, T::SrcWidth(), T::SrcHeight());
        m_computed = false;
    }

    /** Compute the PM LUT: before running it, it's necessary to set all the
     * parameters of the camera and of the region of interest on the reference
     * plane (by the methods 'SetCameraParams' and 'SetRefPlaneLimits'). */
    void Compute(void);

    void ApplyToImage(unsigned char* dstImage, const unsigned char* srcImage, unsigned int bpp, const math::Rect2i* area=NULL)
    {
        if(!m_computed)
            Compute();
        T::ApplyToImage(dstImage, srcImage, bpp, area);
    }
};


// definisco i nomi per comodita. La scelta tra le possibili PMImageLUT e' tra queste 3 classi:

/// Una perspective mapping LUT che usa un filtro nearest
typedef TPMImageLUT<DirectImageLUT> PMDirectImageLUT;
/// Una perspective mapping LUT che usa un filtro bilineare
typedef TPMImageLUT<BilinearImageLUT> PMBilinearImageLUT;
/// Una perspective mapping LUT che usa un filtro bilineare fixed point
typedef TPMImageLUT<FPBilinearImageLUT> PMFPBilinearImageLUT;

#endif // _PM_IMAGE_LUT_H
