/** \file GImageLUT.h
  * \author Paolo Medici (medici@ce.unipr.it)
  * \brief GenericImageLUT
  **/

#ifndef _GIMAGELUT_H
#define _GIMAGELUT_H

#include <vector>
#include <iosfwd>

#include <Data/Math/Points.h>

#include "ImageLUT.h"
#include "PMImageLUT.h"

// deprecated {

/// Struttura per gestire i singoli elementi che sommati danno il contributo per la GenericLutElement
struct ImageLutPixelElement: public math::Point2i {
    float weight;
    
    inline bool IsInside(int X0, int Y0, int X1, int Y1) const
        {
        return ((x>=X0)&&(y>=Y0)&&(x<X1)&&(y<Y1));
        }
};

/// Una raccolta di ImageLutPixelElement
class GenericLutElement: public std::vector<ImageLutPixelElement>
{
  typedef std::vector<ImageLutPixelElement> parent;
  public:
    GenericLutElement()  {};
    GenericLutElement(unsigned int N) : parent(N) {};
    GenericLutElement(double X, double Y) { Bilinear(X,Y); }
    GenericLutElement(double X, double Y, double _Var=1.0) { Gaussian(X,Y,_Var); }
    
    GenericLutElement(const GenericLutElement &_ipmp);
    GenericLutElement & operator = (const GenericLutElement &_ipmp);
    
    ~GenericLutElement() 
    { 
    };
    
    void Write(std::ostream &out) const;    
    
    /// Riempie il pixel con i pesi associati a una gaussiana
    void Gaussian(double X, double Y, double _Var=1.0);
    
    /// Riempie i pixel con i pesi di una bilineare
    void Bilinear(double X, double Y);
    
    unsigned int GetElementCount(void) const { return this->size(); }
    const ImageLutPixelElement *GetElementList(void) const { return &((*this)[0]); }
    /// riduce l'area di analisi della convoluzione a un'area ristretta
    void Crop(int X0, int Y0, int X1, int Y1);
    /// Normalizza la somma dei pesi
    void Normalize(void);
    
    bool IsDefined() const {return !empty();}
};

// }

// deprecated {

/// Una generica LUT per cui ogni punto dell'immagine destinazione e' la somma pesata di N punti dell'immagine sorgente
/// @note la GenericImageLUT non fornisce un gran supporto nel caso di prospettiva, ma permette di fare LUT particolari!
class GOLD_PROC_PM_EXPORT GenericImageLUT : public ImageLUT
{
    protected:
    GenericLutElement *imageLUT;
    public:
    GenericImageLUT(unsigned int imgLUTWidth, unsigned int imgLUTHeight, unsigned int srcImgWidth, unsigned int srcImgHeight);
    
    /// converte una BilinearImageLUT in una GenerincImageLut
    GenericImageLUT(const BilinearImageLUT &bil);
    /// Converte una DirectImageLUT in una GenericImageLut
    GenericImageLUT(const DirectImageLUT &dil);
    ~GenericImageLUT();
    
    /// Esegue una convoluzione sull'immagine srcImage con le informazioni contenute in lutPos. 
    /// il risultato e' salvato nel buffer a cui punta dstBuffer di dimensioni bytePerPixel
    void convolution(unsigned char * dstBuffer, const unsigned char * srcImage, unsigned int bytePerPixel, GenericLutElement* lutPos);

    // unimplemented yet
    void SetPixel(unsigned int xd, unsigned int yd, double xs, double ys)   { }

    /// Load the LUT from the file 'fileName'
    bool LoadFromFile(const char *fileName);
    /// Save the LUT to the file 'fileName'
    bool SaveToFile(const char *fileName);
    
    /// Applica la LUT tra le immagini del tipo selezionato, e opzionalmente e' possibile specificare l'area destinazione
    void Apply(unsigned char * dstImage, const unsigned char * srcImage, unsigned int bpp, const ImageBoxArea* area=NULL);
    
    bool IsDefined(unsigned int x, unsigned int y)
    {
        return imageLUT[x + y * width].IsDefined();
    }
    
};

// }

// deprecated:
typedef TIPMImageLUT<GenericImageLUT> IPMGaussianImageLUT;
template <> GOLD_PROC_PM_EXPORT void TIPMImageLUT<GenericImageLUT>::Compute(void);

#endif
