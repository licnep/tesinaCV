/* funzioni di gestione strutture dati avanzate */
/** @file bbox.h
 * @brief bbox.h contains structure base BBOX
 * 
 * In generale tutte quelle strutture che non hanno un solo proprietario, ma sono usate comunemente da piu librerie.
 **/
#ifndef _CBBOX_H
#define _CBBOX_H

///////////////////////////////////////////////////////////////////////////////
/////PGX Under development/////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

#include <cmath>
#include <iostream>
#include <iomanip>

#include <Data/CImage/CImage.h>

using cimage::CImage;

// Classe base per un Bounding Box in un'immagine
// Un Bounding Box e' una struttura dati che incapsula informazione relativa ad una particolare zona in un'immagine
// L'informazione da rappresentare non e' lasciata da specificare nelle classi derivate
class CBBox2D
{
  public:
    // Costruttore di default per un BB vuoto
    CBBox2D() : m_ID(0), m_Value(0.0), m_X(0.0), m_Y(0.0), m_W(0.0), m_H(0.0), m_Content(0), m_Image(0) {}

    CBBox2D( int X, int Y, unsigned int W, unsigned int H, CImage *Image=0) :
      m_ID(0), m_Value(0.0), m_X(X), m_Y(Y), m_W(W), m_H(H), m_Content(0), m_Image(Image) {}

    void  BindTo(CImage *Image) { m_Image=Image;}


    ~CBBox2D()
    {
      // FIXME: in alcuni casi arrivano dei valori non nulli per questi puntatori 
      // anche se nessuno sembra averli toccati
      // if(m_Content) 
      //   delete m_Content;
      // if(m_Image) 
      //   delete m_Image; 
    }

    void SetID(unsigned int newID) { m_ID = newID; }
    unsigned int GetID() const { return m_ID; }

    void SetValue(double newValue) { m_Value = newValue; }
    double GetValue() const { return m_Value; }

    void SetPosition( int X, int Y) { m_X = (double) X, m_Y = (double) Y; }
    void SetDimensions( unsigned int W, unsigned int H ) { m_W = (double) W, m_H = (double) H; }
    void SetGeometry(int X, int Y, unsigned int W, unsigned int H)
    {
      SetPosition(X, Y);
      SetDimensions(W, H);
    }
    void SetGeometryRect(int Left, int Top, int Right, int Bottom)
    {
      SetPosition(Left, Top);
      SetDimensions(std::abs((int)Left-(int)Right)+1, std::abs((int)Top-(int)Bottom)+1);
    }

    int X()  const { return (int) (m_X+0.5); }
    int Y()  const { return (int) (m_Y+0.5); }

    unsigned int W()  const { return (unsigned int) (m_W+0.5); }
    unsigned int H()  const { return (unsigned int) (m_H+0.5); }

    int Xc() const { return (int) (m_X+m_W/2.0-0.5); }
    int Yc() const { return (int) (m_Y+m_H/2.0-0.5); }

    int Left()   const { return (int) (m_X+0.5); }
    int Top()    const { return (int) (m_Y+0.5); }
    int Right()  const { return (int) (m_X+m_W-0.5); }
    int Bottom() const { return (int) (m_Y+m_H-0.5); }

    unsigned int Area() const { return (unsigned int) (m_W * m_H+0.5); }

    int Xbc() const {return (int) (m_X+m_W/2.0-0.5); }
    int Ybc() const {return (int) (m_Y+m_H-0.5); }

    CImage *GetContent(void) const { return m_Content;}
    CImage *GetImage(void) const { return m_Image;}

    friend
    std::ostream& operator << (std::ostream& os, const CBBox2D& BBox)
    {
      std::cout << BBox.m_ID << " "
      << std::setw(3) << std::setprecision(2) << BBox.m_Value << " "
      << std::fixed << std::setprecision(0)
      << BBox.m_X << " "<< BBox.m_Y << " "
      << BBox.m_W << " " << BBox.m_H << " ";
      return os;
    }

    /**
     * Ritorna true se BBox e' sovrapposto all'oggetto corrente
     * @param BBox 
     * @return 
     */
    /*    bool operator&(const CBBox2D& BBox) const
        {
          return ((Right() > BBox.m_X) && (BBox.Right() > m_X) && 
                  (Bottom() > BBox.m_Y) && (BBox.Bottom() > m_Y)) ? true : false;
        }*/
     /**
     * Ritorna true se BBox contiene il punto p
     * @param BBox 
     * @return 
     */
      //     bool operator&(Point2i p) const
      //     {
      //         return ((Right() >= p.x) && (Left() <= p.x) && 
      //                (Bottom() >= p.y) && (Top() <= p.y)) ? true : false;
      //     }

    bool Intersect(const CBBox2D &BBox) const
    {
        return ! ( m_X > BBox.m_X+BBox.m_W
        || m_X+m_W < BBox.m_X 
        || BBox.m_Y > m_Y+m_H
        || BBox.m_Y+BBox.m_H < m_Y
        );
    }
 // return !( x > r.x+r.w || x+w < r.x || y > r.y+r.h || y+h < r.y )
// /*
// bool IntersectRect(const RECT * r1, const RECT * r2)
// {
//     return ! ( r2->left > r1->right 
//         || r2->right < r1->left 
//         || r2->top > r1->bottom 
//         || r2->bottom < r1->top 
//         );
// }*/

    /// ritorna un CBBox2D che e' l'intersezione dell'oggetto con BBox
    CBBox2D& operator&=(const CBBox2D& BBox)
    {
      // TODO:
      //       m_X = std::max(m_X, std::min(std::abs(BBox.m_X-m_X+m_W), 0.0));
      //       m_Y = std::max(m_Y, std::min(std::abs(BBox.m_Y-m_Y+m_H), 0.0));
      //       m_W = std::min(std::abs(m_W-BBox.m_W), 0.0);
      //       m_H = std::min(std::abs(m_H-BBox.m_H), 0.0);

      return *this;
    }

    /// ritorna un CBBox2D che e' l'intersezione dell'oggetto con BBox
    CBBox2D& operator|=(const CBBox2D& BBox)
    {
      // TODO
      //       m_X = std::min(m_X, BBox.m_X);
      //       m_Y = std::min(m_Y, BBox.m_Y);
      //       m_W = m_W+BBox.m_W-(m_X+m_W)-BBox.m_X;
      //       m_H = m_H+BBox.m_H-(m_Y+m_H)-BBox.m_Y;

      (*this)+=BBox;
      return *this;
    }

    unsigned int Area(const CBBox2D & b) const {

       double SovrOriz = std::min(Right(), b.Right()) - std::max(Left(), b.Left())+1;
       double SovrVert = std::min(Bottom(), b.Bottom()) - std::max(Top(), b.Top())+1;
       return (SovrOriz > 0) ?  (unsigned int)(SovrOriz * SovrVert) : 0;
    }

    bool operator<=(const CBBox2D& BBox) const
    {
      return ((m_X>=BBox.m_X )              &&
              (m_Y>=BBox.m_Y )              &&
              (m_X+m_W<=BBox.m_X+BBox.m_W ) &&
              (m_Y+m_H<=BBox.m_Y+BBox.m_H )) ? true : false;
    }

    void Translate(double dX, double dY)
    {
      m_X+= dX;
      m_Y+= dY;
    }

    CBBox2D operator+(const CBBox2D & BBoxA) const
    {
        return CBBox2D(*this)+=BBoxA;
    }

    CBBox2D operator+=(const CBBox2D & BBoxA)
    {
        m_W = std::max(m_X + m_W, BBoxA.m_X + BBoxA.m_W);
        m_H = std::max(m_Y + m_H, BBoxA.m_Y + BBoxA.m_H);

        m_X = std::min(BBoxA.m_X, m_X);
        m_Y = std::min(BBoxA.m_Y, m_Y);

        m_W -= m_X;
        m_H -= m_Y;

        return *this;
     }

    friend CBBox2D operator *(const CBBox2D & BBox, double ScaleFactor);
    friend CBBox2D operator *(double ScaleFactor, const CBBox2D & BBox);


  protected:
      // membri accessibili dalle classi figlie
      unsigned int m_ID;
      double  m_Value;

      double  m_X, m_Y;              /// Coordinate dell'angolo upper-left del bbox nell'immagine (sub-pixel precision)
      double  m_W, m_H;              /// Dimensione del BB nell'immagine (sub-pixel precision)

      // TODO: attenzione all'operatore uguale. Le CImages non si accorgono
      CImage  *m_Content;
      CImage  *m_Image;
};


CBBox2D operator *(const CBBox2D & BBox, double ScaleFactor);
CBBox2D operator *(double ScaleFactor, const CBBox2D & BBox);

// Classe base per un Bounding Box in un'immagine
// Un Bounding Box e' una struttura dati che incapsula informazione relativa ad una particolare zona in un'immagine
// L'informazione da rappresentare non e' lasciata da specificare nelle classi derivate
class CBBox3D
{
  public:
    // Costruttore di default per un BB vuoto
    CBBox3D() : m_ID(0), m_Value(0.0), m_Xc(0.0), m_Yc(0.0), m_Zc(0.0), m_W(0.0), m_H(0.0), m_T(0.0) {}

    CBBox3D( double Xc, double Yc, double Zc, double W, double H, double T=0.0) :
      m_ID(0), m_Value(0.0), m_Xc(Xc), m_Yc(Yc), m_Zc(Zc), m_W(W), m_H(H), m_T(T)
    { }

    ~CBBox3D() {}

    void SetID(unsigned int newID) { m_ID = newID; }
    unsigned int GetID() const { return m_ID; }

    void SetValue(unsigned int newValue) { m_Value = newValue; }
    double GetValue() const { return m_Value; }

    void SetPosErr(double SigmaX=0.0, double SigmaY=0.0, double SigmaZ=0.0) { m_SigmaX = SigmaX, m_SigmaY=SigmaY, m_SigmaZ=SigmaZ; }
    double GetPosErrX() const { return m_SigmaX; }
    double GetPosErrY() const { return m_SigmaY; }
    double GetPosErrZ() const { return m_SigmaZ; }

    void SetSizeErr(double SigmaW=0.0, double SigmaH=0.0, double SigmaT=0.0) { m_SigmaW = SigmaW, m_SigmaH=SigmaH, m_SigmaT=SigmaT; }
    double GetSizeErrW() const { return m_SigmaW; }
    double GetSizeErrH() const { return m_SigmaH; }
    double GetSizeErrT() const { return m_SigmaT; }

    // Metodi di Accesso
    double Xc() const { return m_Xc; }
    double Yc() const { return m_Yc; }
    double Zc() const { return m_Zc; }

    double W() const { return m_W; }
    double H() const { return m_H; }

    bool operator<=(const CBBox3D BBox) const
    {
      return ((std::fabs(m_Xc-BBox.m_Xc) < 0.001)           &&
              ((m_Yc-m_W/2.0) >= (BBox.m_Yc-BBox.m_W/2.0)) &&
              ((m_Zc-m_H/2.0) >= (BBox.m_Zc-BBox.m_H/2.0)) &&
              ((m_Yc+m_W/2.0) >= (BBox.m_Yc+BBox.m_W/2.0)) &&
              ((m_Zc+m_H/2.0) >= (BBox.m_Zc+BBox.m_H/2.0))) ? true : false;
    }

    void Translate(double dXc, double dYc, double dZc)
    {
      m_Xc+= dXc;
      m_Yc+= dYc;
      m_Zc+= dZc;
    }


  private:

    unsigned int m_ID;
    double  m_Value;

    double  m_Xc, m_Yc, m_Zc;      /// Coordinate del centro in [m] rispetto al sitema di riferimento
    double  m_W, m_H, m_T;         /// Dimensione del BB nel mondo in [m]
    double  m_SigmaX, m_SigmaY, m_SigmaZ;  /// TODO: definire meglio (Errore di posizione)
    double  m_SigmaW, m_SigmaH, m_SigmaT;  /// TODO: definire meglio (Errore di dimensione)
};

class CStereoBBox: public CBBox2D{

public:

    CStereoBBox() : CBBox2D() {}

    CStereoBBox( int X, int Y, unsigned int W, unsigned int H, int disp=DISPARITY_UNKNOWN) : CBBox2D(X, Y, W, H), m_disparity(disp){}

    CStereoBBox(const CBBox2D & bbox, int disp=DISPARITY_UNKNOWN) : CBBox2D(bbox), m_disparity(disp) {}

    void SetDisparity( int disp) { m_disparity=disp; }
    int Disparity() const { return m_disparity; }

    int HomologousXc() const { return Xc() + m_disparity; }
    int HomologousYc() const { return Yc(); }

    int HomologousLeft()   const { return Left() + m_disparity; }
    int HomologousTop()    const { return Top(); }
    int HomologousRight()  const { return Right() + m_disparity; }
    int HomologousBottom() const { return Bottom(); }

    static const int DISPARITY_UNKNOWN =-101;

protected:

    int m_disparity;

};


class CBBox3D_ {

 public:

    CBBox3D_() : m_XW(0), m_YW(0), m_ZW(0), m_worldWidth(0), m_worldHeight(0) {}

    CBBox3D_( double XW, double YW, double ZW, double W3D, double H3D) :  m_XW(XW), m_YW(YW), m_ZW(ZW), m_worldWidth(W3D), m_worldHeight(H3D)  {}

    ~CBBox3D_() {}

    void SetWorldPosition( double YW, double ZW, double XW) { m_YW = YW, m_ZW = ZW, m_XW = XW; }
    void SetWorldDimensions( double W, double H ) { m_worldWidth = W, m_worldHeight = H; }
    void SetWorldGeometry( double YW ,double ZW, double XW, double W, double H)
    {
      SetWorldPosition(YW, ZW, XW);
      SetWorldDimensions(W, H);
    }
    void SetWorldGeometryRect(double Left, double Top, double Right, double Bottom, double Dist)
    {
      SetWorldPosition(Left, Top, Dist);
      SetWorldDimensions(Left-Right, Top - Bottom);   ///In gold Y ha verso contrario
    }

    void SetDist3D(double dist){m_XW=dist;}

    double XW()  const { return m_XW; }
    double YW()  const { return m_YW; }
    double ZW()  const { return m_ZW; }

    double W3D()  const { return m_worldWidth; }
    double H3D()  const { return m_worldHeight; }

    double Yc3D() const { return m_YW - m_worldWidth/2.0; }             ///In gold Y ha verso contrario
    double Zc3D() const { return m_ZW - m_worldHeight/2.0; }

    double Left3D()   const { return m_YW; }
    double Top3D()    const { return m_ZW; }
    double Right3D()  const { return m_YW - m_worldWidth; }             ///In gold Y ha verso contrario
    double Bottom3D() const { return m_ZW - m_worldHeight; }
    double Dist3D()  const { return m_XW; }

    double Area3D() const { return m_worldWidth * m_worldHeight; }

    CBBox3D_ operator+=(const CBBox3D_ & BBoxA) 
    {

      m_worldWidth = std::min(Right3D(), BBoxA.Right3D());///In gold Y ha verso contrario
      m_worldHeight = std::min(Bottom3D(), BBoxA.Bottom3D());

      m_YW = std::max(BBoxA.YW(), m_YW);        ///In gold Y ha verso contrario
      m_ZW = std::max(BBoxA.ZW(), m_ZW);

      m_worldWidth = m_YW - m_worldWidth;        ///In gold Y ha verso contrario
      m_worldHeight = m_ZW - m_worldHeight;

      m_XW = (m_XW + BBoxA.XW()) / 2;

      return *this;
     }

private:

    double m_XW, m_YW, m_ZW;
    double m_worldWidth, m_worldHeight;

};


class CBBox : public CStereoBBox, public CBBox3D_ {

public:

    CBBox() : CStereoBBox(), CBBox3D_(), m_valid(true) {}

    CBBox( int X, int Y, unsigned int W, unsigned int H,  double XW=0, double YW=0, double ZW=0, double W3D=0, double H3D=0, int disp=DISPARITY_UNKNOWN) : CStereoBBox(X, Y, W, H, disp), CBBox3D_(XW, YW, ZW, W3D, H3D), m_valid(true)  {}

    CBBox(const CStereoBBox & bbox, double XW=0, double YW=0, double ZW=0, double W3D=0, double H3D=0) : CStereoBBox(bbox), CBBox3D_(XW, YW, ZW, W3D, H3D), m_valid(true)  {}

    CBBox(const CBBox2D & bbox, double XW=0, double YW=0, double ZW=0, double W3D=0, double H3D=0, int disp=DISPARITY_UNKNOWN) : CStereoBBox(bbox, disp), CBBox3D_(XW, YW, ZW, W3D, H3D), m_valid(true)  {}

    ~CBBox() {}

    void SetValid() {m_valid = true;}
    void SetInvalid() { m_valid = false;} 
    bool IsValid() { return m_valid==true;}
    bool IsInvalid() { return m_valid==false;}

private:
 
   bool m_valid;

};




class CPedestrianBBox : public CBBox2D {

public:
	CPedestrianBBox():CBBox2D(), m_head(), m_valid(true) { m_head.SetValue(-1); }
	CPedestrianBBox(CBBox2D aBBox):CBBox2D(aBBox), m_head(), m_valid(true) { }
	CPedestrianBBox( int X, int Y, int W, int H):CBBox2D(X,Y,W,H), m_head(), m_valid(true) { }

        CBBox2D  m_head;              /// coordinate upper-left bbox della testa

        void SetValid() {m_valid = true;}
	void SetInvalid() { m_valid = false;} 
	bool IsValid() { return m_valid==true;}
	bool IsInvalid() { return m_valid==false;}


private:
      bool m_valid;
};


#endif
