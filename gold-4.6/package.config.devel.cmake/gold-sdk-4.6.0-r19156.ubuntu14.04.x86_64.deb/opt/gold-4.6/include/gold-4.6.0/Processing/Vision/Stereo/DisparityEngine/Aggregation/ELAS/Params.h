#ifndef _ELAS_PARAMS_H
#define _ELAS_PARAMS_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file Params.h
 * \author Paolo Zani (zani@vislab.it) Mirko Felisa (felisa@vislab.it)
 * \date 2012-02-18
 */

#include <stdint.h>

namespace disparity
{
    class ELASParams
    {
    public:



        ELASParams() : m_winWidth (3), m_winHeight (3), m_downsampleratio(1),
            m_stepsize (5), m_lr_threshold (2), m_support_texture (10),
            m_support_threshold (0.85f), m_incon_window_size (5), m_incon_threshold (5),
            m_incon_min_support (5), m_add_corners (1), m_grid_size (20), m_sigma (1), m_beta (0.02f), m_gamma (3),
            m_sradius (2), m_match_texture (1), m_speckle_sim_threshold (1), m_speckle_size (200), m_ipol_gap_width (3),
            m_filter_adaptive_mean (true), m_filter_median (0) {}


        uint32_t m_winWidth;
        uint32_t m_winHeight;

        uint32_t m_downsampleratio;
        int32_t m_stepsize;
        int32_t m_lr_threshold;
        int32_t m_support_texture;
        float m_support_threshold;
        int32_t m_incon_window_size;
        int32_t m_incon_threshold;
        int32_t m_incon_min_support;
        bool m_add_corners;
        int m_grid_size;
        float m_sigma;
        float m_beta;
        float m_gamma;
        float m_sradius;
        int32_t m_match_texture;
        float m_speckle_sim_threshold;
        uint32_t m_speckle_size;
        int32_t m_ipol_gap_width;
        bool m_filter_adaptive_mean;
        bool m_filter_median;
    };
}

#endif
