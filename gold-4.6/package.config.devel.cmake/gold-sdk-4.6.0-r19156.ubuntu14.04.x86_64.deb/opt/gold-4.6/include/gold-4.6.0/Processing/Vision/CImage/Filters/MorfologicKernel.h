#ifndef MORFOLOGICKERNEL_H
#define MORFOLOGICKERNEL_H


/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/

/**
 * \file MorfologicKernel.h
 * \author Claudio Caraffi (caraffi@ce.unipr.it)
 * \brief This file contains kernel for Morfologic filters
 * @see TImageKernelFilter
 * \date 2006-12-14
 */
#include <stdint.h>

#include <Data/CImage/PixelTraits/PixelTraits.h>

//Volendo si pu� mettere comp in fondo con una soglia (che ora � fissa ad 1)

template<typename S, typename D, uint32_t width, uint32_t height>
class VerticalErosion;

template<typename S, typename D>
class VerticalErosion<S, D, 3, 3>
    {
    uint32_t m_stride;
    typedef typename cimage::PixelTraits<S>::FastType type_t;

    public:

        inline D zero() const { return 0; }
        inline uint32_t GetWidth() const { return 3; }
        inline uint32_t GetHeight() const { return 3; }
        inline void SetStride(uint32_t stride) { m_stride = static_cast<int32_t>(stride); }

    inline D operator()(const S* inputPixel) const
        {
        if(inputPixel==zero())
            return zero();

        type_t comp = (static_cast<type_t>(inputPixel[-m_stride-1])
                  + 2*static_cast<type_t>(inputPixel[-m_stride]+inputPixel[-m_stride+1])
                  + static_cast<type_t>(inputPixel[-1])
                  + static_cast<type_t>(inputPixel[1])
                  + static_cast<type_t>(inputPixel[m_stride-1])
                  + 2*static_cast<type_t>(inputPixel[m_stride])
                  + static_cast<type_t>(inputPixel[m_stride+1])) * static_cast<type_t>(inputPixel[0]);

            return static_cast<D>((comp > 1) ? inputPixel[0] : zero());
        }
};

template<typename S, typename D, uint32_t width, uint32_t height>
class HorizontalErosion
    {
    uint32_t m_stride;
    typedef typename cimage::PixelTraits<S>::FastType type_t;

        public:

            inline D zero() const { return 0; }
            inline uint32_t GetWidth() const { return 3; }
            inline uint32_t GetHeight() const { return 3; }
            inline void SetStride(uint32_t stride) { m_stride = static_cast<int32_t>(stride); }

            inline D operator()(const S* inputPixel) const
            {
            if(inputPixel == zero())
                return 0;

            type_t comp = (static_cast<type_t>(inputPixel[-m_stride-1])
                      + static_cast<type_t>(inputPixel[-m_stride])
                      + static_cast<type_t>(inputPixel[-m_stride+1])
                      + 2*static_cast<type_t>(inputPixel[-1])
                      + 2*static_cast<type_t>(inputPixel[1])
                      + static_cast<type_t>(inputPixel[m_stride-1])
                      + static_cast<type_t>(inputPixel[m_stride])
                      + static_cast<type_t>(inputPixel[m_stride+1])) * static_cast<type_t>(inputPixel[0]);

            return static_cast<D>((comp>1) ? inputPixel[0] : zero());
        }
};


#endif
