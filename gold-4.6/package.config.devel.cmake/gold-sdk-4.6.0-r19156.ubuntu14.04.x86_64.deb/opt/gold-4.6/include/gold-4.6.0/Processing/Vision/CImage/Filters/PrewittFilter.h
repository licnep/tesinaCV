#ifndef _PREWITT_FILTER_H
#define _PREWITT_FILTER_H

#include <stdint.h>
#include <Data/CImage/PixelTraits/PixelTraits.h>
#include "FilterModifier.h"
#include "ConvolutionKernel.h"

namespace cimage {

namespace kernel {

/**
 * \brief Implementa il calcolo di una maschera w x h verticale di Prewitt
*/
template<uint32_t w, uint32_t h>
class PrewittVertical;

/**
 * \brief Implementa il calcolo di una maschera 3x3 verticale di Prewitt
*/
template<>
class PrewittVertical<3, 3>: public TConvolutionKernel3x3<-1,0,1, -1,0,1, -1,0,1>
{
};

/**
 * \brief Implementa il calcolo di una maschera w x h orizzontale di Prewitt
*/
template<uint32_t w, uint32_t h>
class PrewittHorizontal;

/**
 * \brief Implementa il calcolo di una maschera 3x3 orizzontale di Prewitt
*/
template<>
class PrewittHorizontal<3, 3>: public TConvolutionKernel3x3<-1,-1,-1, 0,0,0, 1,1,1>
{
};


/******************************** Filtri Comuni ***************************************/

/** prewitt verticale con segno **/
typedef filter::Div<PrewittVertical<3,3>, 6> PrewittVertical3x3;

/** prewitt verticale senza segno
* \code
* TLocalFilter< kernel::PrewittVerticalBias3x3 > filter;
* filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef filter::Bias<PrewittVertical3x3, 127> PrewittVerticalBias3x3;

/** prewitt orizzontale con segno **/
typedef filter::Div<PrewittHorizontal<3,3>, 6>  PrewittHorizontal3x3;

/** prewitt orizzontale senza segno
* \code
* TLocalFilter< kernel::PrewittHorizontalBias3x3 > filter;
* filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef filter::Bias<PrewittHorizontal3x3, 127> PrewittHorizontalBias3x3;

/** filtro trova edge con filtro di prewitt **/
typedef filter::Div< filter::Max2<filter::Abs< PrewittVertical<3,3> > , filter::Abs< PrewittHorizontal<3,3> > >, 8> PrewittEdges3x3;

}

namespace filter {

  /** prewitt verticale con segno **/
  typedef TLocalFilter< kernel::PrewittVertical3x3 > PrewittVertical3x3;
  /** prewitt verticale senza segno*/
  typedef TLocalFilter< kernel::PrewittVerticalBias3x3 > PrewittVerticalBias3x3;
  /** prewitt orizzontale con segno **/
  typedef TLocalFilter< kernel::PrewittHorizontal3x3 > PrewittHorizontal3x3;
  /** prewitt orizzontale senza segno*/
  typedef TLocalFilter< kernel::PrewittHorizontalBias3x3 > PrewittHorizontalBias3x3;
  /** filtro trova edge con filtro di prewitt **/
  typedef TLocalFilter< kernel::PrewittEdges3x3 > PrewittEdges3x3;
  
}

} // namespace cimage {

#endif
