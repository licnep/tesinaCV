#ifndef _DISPARITYENGINE_ELAS_IMPL_H
#define _DISPARITYENGINE_ELAS_IMPL_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file Impl.h
 * \author Paolo Zani (zani@vislab.it) Mirko Felisa (felisa@vislab.it)
 * \date 20012-02-18
 */

#include <Libs/Threads/Parallelize.h>
#include <Processing/Vision/Stereo/Images/CDSI.h>
#include <Processing/Vision/Stereo/Images/CScoreImage.h>
#include <Processing/Vision/Stereo/DisparityEngine/Common/SearchRange.h>
#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/ELAS/Params.h>
#include <Processing/Vision/Stereo/DisparityEngine/Common/DisparityEngineData.h>
#include <Processing/Vision/Stereo/DisparityEngine/Filter/Smoothing.h>
#include <Processing/Vision/CImage/Filters/FilterModifier.h>
#include <Processing/Vision/CImage/Filters/SobelFilter.h>
#include <Processing/Tessellation/DelaunayTriangulation.h>
#include <boost/array.hpp>
#include <stdint.h>
#include <cstdlib>
#include <vector>
#include <limits>
#ifdef __SSSE3__
#include <tmmintrin.h>
#endif
// #define __DEBUG__

#include <iostream>

#ifdef __DEBUG__
#define __log_debug  std::cout << "[DB] DisparityEngine/Aggregation/ELAS/Impl.h "  << __LINE__ << " "
#else
#define __log_debug  while(0) std::cout
#endif


namespace disparity
{
// forward declarations


    namespace agg
    {
        template<typename ResultType_Cost, typename _ResultType_Agg, typename Impl_Agg, uint32_t _Threads_Agg>
        class ELAS;
    }

    namespace impl
    {
        class Auto;
        class Cpp;
        class SIMD;
    }


    template<typename Cost, typename Aggregation, typename Optimization>
    class Core;


    template<typename Cost, typename Optimization, typename ResultType_Cost, typename _ResultType_Agg, typename _Impl_Agg, uint32_t _Threads_Agg>
    class Core<Cost, agg::ELAS<ResultType_Cost, _ResultType_Agg, _Impl_Agg, _Threads_Agg>, Optimization> :  public ELASParams, private virtual DisparityEngineData
    {
    public:

        typedef _ResultType_Agg ResultType_Agg;
        typedef _Impl_Agg Impl_Agg;
        typedef agg::ELAS<ResultType_Cost, ResultType_Agg, _Impl_Agg, _Threads_Agg> AggregationType;
        typedef Optimization OptimizationType;
        typedef Core<Cost, AggregationType, Optimization> CoreType;

        static const uint32_t Threads_Agg = _Threads_Agg;

    protected:

        Core() : m_width(0), m_height(0), m_candimage(0), m_candimage2(0), m_cansize(0), m_leftDescr(0), m_rightDescr(0), m_gridimagesize(0), m_leftGrid(0), m_rightGrid(0), tempsize(0), temp1(0),  m_barrier(_Threads_Agg) {}

        ~Core()
        {
            _mm_free(m_leftDescr);
            _mm_free(m_rightDescr);
            delete [] m_candimage;
            delete [] m_candimage2;
            delete [] m_leftGrid;
            delete [] m_rightGrid;
            delete [] temp1;

        }

        inline void SetDimensions(uint32_t& width, uint32_t& height)
        {
            halfResolution = m_downsampleratio==2;
            width /= m_downsampleratio;
            height /= m_downsampleratio;
        }

        template<typename T>
        inline void Run(const cimage::TImage<T>& left, const cimage::TImage<T>& right, const cimage::CImageMono8& mask)
        {

            m_dispMax = std::max(0, m_dispMax);
            m_dispMin = std::max(0, m_dispMin);

            if(right.Area() > m_width * m_height)
            {
                _mm_free(m_leftDescr);
                _mm_free(m_rightDescr);
                m_leftDescr = (uint8_t*) _mm_malloc(16 * right.Area() * sizeof(uint8_t), 16);
                m_rightDescr = (uint8_t*) _mm_malloc(16 * right.Area() * sizeof(uint8_t), 16);
            }

            m_width = right.W();
            m_height = right.H();

            cimage::Resize(m_leftVDescr, m_width, m_height);
            cimage::Resize(m_leftHDescr, m_width, m_height);
            cimage::Resize(m_rightVDescr, m_width, m_height);
            cimage::Resize(m_rightHDescr, m_width, m_height);

            if(halfResolution)
            {
                cimage::Resize(*m_dsi, m_width / 2, m_height / 2);  ///FIXME fare la resize fuori
                cimage::Resize(m_dsi2, m_width / 2, m_height / 2);
            }
            else
            {
                cimage::Resize(m_dsi2, m_width, m_height);
            }

            m_step = m_stepsize + ((halfResolution) ? m_stepsize % 2 : 0);

            m_candwidth = m_width / m_step + ((m_width % m_step) ? 1 : 0);
            m_candheight = m_height / m_step + ((m_height % m_step) ? 1 : 0);

            if(m_candwidth * m_candheight > m_cansize)
            {
                m_cansize = m_candwidth * m_candheight;
                delete [] m_candimage;
                delete [] m_candimage2;
                m_candimage = new int16_t[m_cansize];
                m_candimage2 = new int16_t[m_cansize];
            }

            m_gridWidth   = (uint32_t) ceil((float) m_width / (float) m_grid_size);
            m_gridHeight  = (uint32_t) ceil((float) m_height / (float) m_grid_size);
            m_gridDisp    = m_dispMax + 2;
            if(m_gridWidth * m_gridHeight * m_gridDisp > m_gridimagesize)
            {
                m_gridimagesize = m_gridWidth * m_gridHeight * m_gridDisp;
                delete [] m_leftGrid;
                delete [] m_rightGrid;
                m_leftGrid  = new int32_t[m_gridimagesize];
                m_rightGrid = new int32_t[m_gridimagesize];
                int end = m_gridimagesize;
                std::fill(m_leftGrid, m_leftGrid + (m_gridWidth + 1) * m_gridDisp, 0);
                std::fill(m_leftGrid + end - (m_gridWidth + 1) * m_gridDisp, m_leftGrid + end, 0);
                std::fill(m_rightGrid, m_rightGrid + (m_gridWidth + 1) * m_gridDisp, 0);
                std::fill(m_rightGrid + end - (m_gridWidth + 1) * m_gridDisp, m_rightGrid + end, 0);
            }


            if(std::max(m_gridWidth * m_gridHeight * (m_dispMax + 1), m_width * m_height) > tempsize)
            {
                tempsize = std::max(m_gridWidth * m_gridHeight * (m_dispMax + 1), m_width * m_height);
                delete [] temp1;
                temp1 = new uint8_t[tempsize];
            }

            Parallelize(boost::bind(&CoreType::template ComputeDisparity<T>, this,  left.Buffer(), right.Buffer(), _1, _2), Threads_Agg);
            
        }


    private:


        struct supp_point
        {
            int32_t u;
            int32_t v;
            int32_t d;
            supp_point(int32_t u, int32_t v, int32_t d) : u(u), v(v), d(d) {}
            supp_point() : u(0), v(0), d(0) {}
        };

        struct triangle
        {
            int32_t c1, c2, c3;
            float   t1a, t1b, t1c;
            float   t2a, t2b, t2c;
            triangle(int32_t c1_, int32_t c2_, int32_t c3_) : c1(c1_), c2(c2_), c3(c3_) {}
            triangle(int32_t c1_, int32_t c2_, int32_t c3_,
                     float   t1a_, float t1b_, float t1c_,
                     float   t2a_, float t2b_, float t2c_
                    ) : c1(c1_), c2(c2_), c3(c3_), t1a(t1a_), t1b(t1b_), t1c(t1c_), t2a(t2a_), t2b(t2b_), t2c(t2c_) {}
        };

        template<typename T>
        inline  void ComputeDescriptor(const T* input, uint8_t* v, uint8_t* h, uint8_t* out, uint32_t threadID, uint32_t threadNum)
        {

            typedef cimage::kernel::TConvolutionKernel3x3 < 1, 2, 1, 0, 0, 0, -1, -2, -1 > SobelHor3x3;
            typedef cimage::kernel::TConvolutionKernel3x3 < 1, 0, -1, 2, 0, -2, 1, 0, -1 > SobelVer3x3;
            typedef  cimage::filter::Bias<cimage::filter::Clamp8s< cimage::filter::Shr< SobelHor3x3, 2> >, 128 > HSobel3x3;
            typedef  cimage::filter::Bias<cimage::filter::Clamp8s< cimage::filter::Shr< SobelVer3x3, 2> >, 128 > VSobel3x3;


            HSobel3x3 HS;
            VSobel3x3 VS;
            int k0 = ((m_height - 2) * threadID) / threadNum + 1;
            int k1 = ((m_height - 2)  * (threadID + 1)) / threadNum + 1;
            uint8_t* po1 = v + k0 * m_width + 1;
            uint8_t* po2 = h + k0 * m_width + 1;
            input += k0 * m_width + 1;;

            for(int i = k0; i < k1; i++)
            {
                for(int j = 1; j < (int) m_width - 1; j++)
                {
                    *po1++ = VS(input, m_width);
                    *po2++ = HS(input++, m_width);
                }
                input += 2;
                po1 += 2;
                po2 += 2;
            }

            m_barrier.wait();

            int stride;
            if(halfResolution)
            {
                k0 = ((m_height - 7) * threadID) / threadNum + 4;
                k1 = ((m_height - 7) * (threadID + 1)) / threadNum + 4;
                k0 += k0 % 2;
                k1 += k1 % 2;
                stride = 2;
            }
            else
            {
                k0 = ((m_height - 6) * threadID) / threadNum + 3;
                k1 = ((m_height - 6) * (threadID + 1)) / threadNum + 3;
                stride = 1;
            }

            const int s = stride;
            for(int32_t i = k0; i < k1; i += s)
            {

                int curr = i * m_width;
                int prev = curr - m_width;
                int next = curr + m_width;
                int pprev = prev - m_width;
                int nnext = next + m_width;

                uint8_t* pout = out + (i * m_width + 3) * 16;
                for(uint32_t j = 3; j < m_width - 3; j++)
                {

                    *pout++ = * (v + pprev + j + 0);
                    *pout++ = * (v + prev + j - 2);
                    *pout++ = * (v + prev + j + 0);
                    *pout++ = * (v + prev + j + 2);
                    *pout++ = * (v + curr + j - 1);
                    *pout++ = * (v + curr + j + 0);
                    *pout++ = * (v + curr + j + 0);
                    *pout++ = * (v + curr + j + 1);
                    *pout++ = * (v + next + j - 2);
                    *pout++ = * (v + next + j + 0);
                    *pout++ = * (v + next + j + 2);
                    *pout++ = * (v + nnext + j + 0);
                    *pout++ = * (h + prev + j + 0);
                    *pout++ = * (h + curr + j - 1);
                    *pout++ = * (h + curr + j + 1);
                    *pout++ = * (h + next + j + 0);
                }
            }

        }


        int16_t ComputeMatchingDisparity(int32_t u, int32_t v, uint8_t* I1_desc, uint8_t* I2_desc, const bool& right_image)
        {
            const int32_t window_size = 3;
            const int32_t step      = 2;
            if(u >= window_size + step && u <= (int) m_width - window_size - 1 - step && v >= window_size + step && v <= (int) m_height - window_size - 1 - step)
            {

                int32_t  line_offset = 16 * m_width * v;
                uint8_t* I1_block_addr = I1_desc + line_offset + 16 * u;

                int32_t disp_max_valid = (!right_image) ? std::min(m_dispMax, u - window_size - step) : std::min(m_dispMax, (int32_t) m_width - u - window_size - step);
                if(disp_max_valid - m_dispMin  < 10)
                {
                    return -1;
                }
#ifdef __SSE2__ 
                __m128i xmm1, xmm2;
#endif                
                int sum;
#ifdef __SSSE3__
                __m128i xmm0;
                xmm0 = _mm_load_si128((__m128i*) I1_block_addr);
                xmm2 = _mm_cmpeq_epi32(xmm2, xmm2);
                xmm1 = xmm0;
                xmm0 = _mm_unpacklo_epi8(xmm0, xmm0);
                xmm1 = _mm_unpackhi_epi8(xmm1, xmm1);
                xmm2 = _mm_slli_epi16(xmm2, 15);
                xmm0 = _mm_srli_epi16(xmm0, 8);
                xmm1 = _mm_srli_epi16(xmm1, 8);
                xmm2 = _mm_srli_epi16(xmm2, 8);
                xmm0 = _mm_sub_epi16(xmm0, xmm2);
                xmm1 = _mm_sub_epi16(xmm1, xmm2);
                xmm0 = _mm_abs_epi16(xmm0);
                xmm1 = _mm_abs_epi16(xmm1);
                xmm0 = _mm_add_epi16(xmm0, xmm1);
                xmm1 = _mm_shuffle_epi32(xmm0, 78);
                xmm0 = _mm_add_epi16(xmm1, xmm0);
                xmm1 = _mm_shuffle_epi32(xmm0, 1);
                xmm0 = _mm_add_epi16(xmm1, xmm0);
                sum  = _mm_extract_epi16(xmm0, 0) + _mm_extract_epi16(xmm0, 1);
#else
                sum = 0;
                for(int32_t i = 0; i < 16; i++)
                {
                    sum += std::abs((int32_t)(* (I1_block_addr + i)) - 128);
                }
#endif
                if(sum < m_support_texture)
                {
                    return -1;
                }


                int32_t desc_offset_1 = -16 * step * (1 + (int) m_width);
                int32_t desc_offset_2 =  16 * step * (1 - (int) m_width);
                int32_t desc_offset_3 = -desc_offset_2;
                int32_t desc_offset_4 = -desc_offset_1;
#ifdef __SSE2__                
                __m128i xmm3, xmm4, xmm5, xmm6;
                xmm1 = _mm_load_si128((__m128i*)(I1_block_addr + desc_offset_1));
                xmm2 = _mm_load_si128((__m128i*)(I1_block_addr + desc_offset_2));
                xmm3 = _mm_load_si128((__m128i*)(I1_block_addr + desc_offset_3));
                xmm4 = _mm_load_si128((__m128i*)(I1_block_addr + desc_offset_4));
                
#endif                
                int16_t min_1_E, min_2_E;
                int16_t min_1_d, min_2_d;
                min_1_E =  min_2_E = std::numeric_limits<int16_t>::max();
                min_1_d =  min_2_d = -1;
                const int sign = right_image ? 1 : -1;
                int32_t u_warp =  u + sign * m_dispMin;
                uint8_t* I2_block_addr = I2_desc + line_offset + 16 * u_warp;
                const int sign16 = 16 * sign;
                for(int16_t d = m_dispMin; d <= disp_max_valid; d++, u_warp += sign,  I2_block_addr += sign16)
                {

#ifdef __SSE2__
                    xmm6 = _mm_load_si128((__m128i*)(I2_block_addr + desc_offset_1));
                    xmm6 = _mm_sad_epu8(xmm6, xmm1);
                    xmm5 = _mm_load_si128((__m128i*)(I2_block_addr + desc_offset_2));
                    xmm6 = _mm_add_epi16(xmm6, _mm_sad_epu8(xmm5, xmm2));
                    xmm5 = _mm_load_si128((__m128i*)(I2_block_addr + desc_offset_3));
                    xmm6 = _mm_add_epi16(xmm6, _mm_sad_epu8(xmm5, xmm3));
                    xmm5 = _mm_load_si128((__m128i*)(I2_block_addr + desc_offset_4));
                    xmm6 = _mm_add_epi16(xmm6, _mm_sad_epu8(xmm5, xmm4));
                    sum  = _mm_extract_epi16(xmm6, 0) + _mm_extract_epi16(xmm6, 4);
#else
                    sum =0;
                    for(int k = 0; k<16; k++)
                       sum+= std::abs((int)I2_block_addr[desc_offset_1+k] - (int)I1_block_addr[desc_offset_1+k]);
                    for(int k = 0; k<16; k++)
                       sum+= std::abs((int)I2_block_addr[desc_offset_2+k] - (int)I1_block_addr[desc_offset_2+k]);
                    for(int k = 0; k<16; k++)
                       sum+= std::abs((int)I2_block_addr[desc_offset_3+k] - (int)I1_block_addr[desc_offset_3+k]);
                    for(int k = 0; k<16; k++)
                       sum+= std::abs((int)I2_block_addr[desc_offset_4+k] - (int)I1_block_addr[desc_offset_4+k]);
#endif
                    if(sum < min_1_E)
                    {
                        min_1_E = sum;
                        min_1_d = d;
                    }
                    else
                        if(sum < min_2_E)
                        {
                            min_2_E = sum;
                            min_2_d = d;
                        }
                }

                if(min_1_d >= 0 && min_2_d >= 0 && min_1_E < m_support_threshold * min_2_E)
                {
                    return min_1_d;
                }

            }
            return -1;


        }

        void RemoveInconsistentSupportPoints(uint32_t threadID, uint32_t threadNum)
        {
            int k0 = (m_candheight * threadID) / threadNum;
            int k1 = (m_candheight * (threadID + 1)) / threadNum;

            int stride = k0 * m_candwidth;
            for(int32_t i = k0; i < k1; i++, stride += m_candwidth)
            {
                int v0 = std::max(i - m_incon_window_size, 1);
                int v1 = std::min(i + m_incon_window_size, (int) m_candheight - 1);
                for(int32_t j = 0; j < (int) m_candwidth; j++)
                {

                    int index = stride + j;
                    int16_t disp = m_candimage[index];
                    if(disp >= 0)
                    {

                        int32_t count = 0;
                        int u0 = std::max(j - m_incon_window_size, 1);
                        int u1 = std::min(j + m_incon_window_size, (int) m_candwidth - 1);

                        int stride2 = v0 * m_candwidth;
                        for(int32_t h = v0; h <= v1; h++, stride2 += m_candwidth)
                            for(int32_t k = u0; k <= u1; k++)
                            {
                                int16_t disp2 = m_candimage[stride2 + k];
                                if(disp2 >= 0 && std::abs(disp - disp2) <= m_incon_threshold)
                                {
                                    count++;
                                }
                            }


                        if(count < m_incon_min_support)
                        {
                            m_candimage[index] = -1;
                        }
                    }
                }
            }
        }

        void RemoveInconsistentSupportPoints2(uint32_t threadID, uint32_t threadNum)
        {
            int k0 = (m_candheight * threadID) / threadNum;
            int k1 = (m_candheight * (threadID + 1)) / threadNum;

            int stride = k0 * m_candwidth;
            for(int32_t i = k0; i < k1; i++, stride += m_candwidth)
            {
                int v0 = std::max(i - m_incon_window_size, 1);
                int v1 = std::min(i + m_incon_window_size, (int) m_candheight - 1);
                for(int32_t j = 0; j < (int) m_candwidth; j++)
                {

                    int index = stride + j;
                    int16_t disp = m_candimage[index];
                    int32_t count = 0;
                    if(disp >= 0)
                    {
                        int u0 = std::max(j - m_incon_window_size, 1);
                        int u1 = std::min(j + m_incon_window_size, (int) m_candwidth - 1);

                        int stride2 = v0 * m_candwidth;
                        for(int32_t h = v0; h <= v1; h++, stride2 += m_candwidth)
                            for(int32_t k = u0; k <= u1; k++)
                            {
                                int16_t disp2 = m_candimage[stride2 + k];
                                if(disp2 >= 0 && std::abs(disp - disp2) <= m_incon_threshold)
                                {
                                    count++;
                                }
                            }

                    }

                    m_candimage2[index] = (count < m_incon_min_support) ? -1 : disp;

                }
            }
        }



        void RemoveRedundantSupportPoints(uint32_t threadID, uint32_t threadNum)
        {

            const int32_t redun_max_dist = 5;
            const int32_t redun_threshold = 1;


            int k0 = ((m_candheight) * threadID) / threadNum;
            int k1 = ((m_candheight) * (threadID + 1)) / threadNum;

            int32_t stride =  k0 * m_candwidth;
            for(int32_t i = k0; i < k1; i++, stride += m_candwidth)
            {
                int end1 = std::min(redun_max_dist, (int) m_candheight - 1 - i);
                int end2 = std::max(-redun_max_dist, 1 - i);
                for(uint32_t j = 0; j < m_candwidth; j++)
                {

                    int index = stride + j;
                    int16_t disp =  m_candimage[index];
                    if(disp >= 0)
                    {
                        int support = 0;
                        int stride2 = m_candwidth;
                        for(int32_t u = 1; u <= end1; u++, stride2 += m_candwidth)
                        {
                            int16_t disp2 = m_candimage[index + stride2];
                            if(disp2 >= 0 && abs(disp - disp2) <= redun_threshold)
                            {
                                support++;
                                break;
                            }
                        }

                        if(support)
                        {
                            stride2 = - (int) m_candwidth;
                            for(int32_t u = -1; u >= end2; u--, stride2 -= m_candwidth)
                            {
                                int16_t disp2 = m_candimage[index + stride2];
                                if(disp2 >= 0 && abs(disp - disp2) <= redun_threshold)
                                {
                                    support++;
                                    break;
                                }
                            }
                        }

                        if(support == 2)
                        {
                            m_candimage[index] = -1;
                        }

                    }
                }
            }



            stride =  k0 * m_candwidth;
            for(int32_t i = k0; i < k1; i++, stride += m_candwidth)
                for(int32_t j = 0; j < (int) m_candwidth; j++)
                {

                    int index = stride + j;
                    int16_t disp =  m_candimage[index];
                    if(disp >= 0)
                    {
                        int support = 0;
                        int end = std::min(redun_max_dist, (int) m_candwidth - 1 - j);
                        for(int32_t u = 1; u <= end; u++)
                        {
                            int16_t disp2 = m_candimage[index + u];
                            if(disp2 >= 0 && abs(disp - disp2) <= redun_threshold)
                            {
                                support++;
                                break;
                            }
                        }

                        if(support)
                        {
                            end = std::max(-redun_max_dist, -j);
                            for(int32_t u = -1; u >= end; u--)
                            {
                                int16_t disp2 = m_candimage[index + u];
                                if(disp2 >= 0 && abs(disp - disp2) <= redun_threshold)
                                {
                                    support++;
                                    break;
                                }
                            }
                        }

                        if(support == 2)
                        {
                            m_candimage[index] = -1;
                        }

                    }
                }


        }


        void AddCornerSupportPoints()
        {

            if(m_suppPoints.empty())
            {
                return;
            }

            supp_point border[4];

            border[0] = supp_point(m_dsiXMin, (halfResolution + 1) * m_dsiYMin, 0);
            border[1] = supp_point(m_dsiXMin, m_dsiYMax, 0);
            border[2] = supp_point(m_dsiXMax, m_dsiYMin, 0);
            border[3] = supp_point(m_dsiXMax, m_dsiYMax, 0);

            for(uint32_t i = 0; i < 4; i++)
            {
                int best_dist = std::numeric_limits<int32_t>::max();
                for(uint32_t j = 0; j < m_suppPoints.size(); j++)
                {
                    supp_point& p = m_suppPoints[j];
                    int32_t du = border[i].u - p.u;
                    int32_t dv = border[i].v - p.v;
                    int32_t curr_dist = du * du + dv * dv;
                    if(curr_dist < best_dist)
                    {
                        best_dist = curr_dist;
                        border[i].d = p.d;
                    }
                }
            }

            for(uint32_t i = 0; i < 4; i++)
               m_suppPoints.push_back(border[i]);

            if(border[2].d)
               m_suppPoints.push_back(supp_point(border[2].u + border[2].d, border[2].v, border[2].d));
            if(border[3].d)
               m_suppPoints.push_back(supp_point(border[3].u + border[3].d, border[3].v, border[3].d));

        }


        void ComputeSupportMatches(uint32_t threadID, uint32_t threadNum)
        {


            int k0 = ((m_candheight - 1) * threadID) / threadNum + 1;
            int k1 = ((m_candheight - 1) * (threadID + 1)) / threadNum + 1;
            for(int32_t i = k0, v = k0 * m_step; i < k1; i++, v += m_step)
            {
                int index = i * m_candwidth;
                for(uint32_t j = 1, u = m_step; j < m_candwidth; j++, u += m_step)
                {
                    int16_t d = ComputeMatchingDisparity(u, v, m_leftDescr, m_rightDescr, false);
                    if(d >= 0)
                    {

                        int16_t d2 = ComputeMatchingDisparity(u - d, v, m_rightDescr, m_leftDescr, true);
                        if(!(d2 >= 0 && abs(d - d2) <= m_lr_threshold))
                        {
                            d = -1;
                        }
                    }

                    m_candimage[index + j] = d;
                }
            }

            m_barrier.wait();

            RemoveInconsistentSupportPoints2(threadID, threadNum);
            m_barrier.wait();
//           removeRedundantSupportPoints(threadID, threadNum);
//           m_barrier.wait();


            if(!threadID)
            {
                std::swap(m_candimage, m_candimage2);
                // removeInconsistentSupportPoints(/*threadID, threadNum*/0,1);

                RemoveRedundantSupportPoints(/*threadID, threadNum*/0, 1);

                m_suppPoints.clear();

                int t = std::max(1U, (halfResolution + 1) * m_dsiYMin / m_step);
                int b = std::min(m_candheight - 1, (halfResolution + 1) * m_dsiYMax / m_step);
                int l = std::max(1U, (halfResolution + 1) * m_dsiXMin / m_step);
                int r = std::min(m_candwidth - 1, (halfResolution + 1) * m_dsiXMax / m_step);
                for(int32_t i = t, vstride = t * m_step; i <= b; i++, vstride += m_step)
                {
                    int stride = i * m_candwidth;
                    for(int32_t j = l, ustride = l * m_step; j <= r; j++, ustride += m_step)
                    {
                        int16_t d = m_candimage[stride + j];
                        if(d >= 0)
                        {
                            m_suppPoints.push_back(supp_point(ustride, vstride , d));
                        }
                    }
                }

                if(m_add_corners)
                {
                    AddCornerSupportPoints();
                }
            }





        }


        void ComputeDelaunayTriangulation(std::vector<triangle>& triangles, bool right_image)
        {

            std::vector<math::Point2i> input;
            input.reserve(m_suppPoints.size());
            if(!right_image)
                for(uint32_t i = 0; i < m_suppPoints.size(); i++)
                    input.push_back(math::Point2i(m_suppPoints[i].u, m_suppPoints[i].v));
            else
                for(uint32_t i = 0; i < m_suppPoints.size(); i++)
                    input.push_back(math::Point2i(m_suppPoints[i].u - m_suppPoints[i].d, m_suppPoints[i].v));

            ///TODO se si diminuisce ste_size e m_lr_threshold!=0 occorre togliere i dup in right_image=1    
            tessellation::TriangleHull<math::Point2i>::ContainerType& triHull = m_triangulator[right_image](input, tessellation::Cut::XY, Threads_Agg / 2).Data();
            triangles.clear();
            math::Point2i* beg = &input[0];
            for(tessellation::TriangleHull<math::Point2i>::ContainerType::const_iterator it = triHull.begin(); it != triHull.end(); ++it)
                if(it->Valid())
                    triangles.push_back(triangle(it->vertex[0] - beg, it->vertex[1] - beg, it->vertex[2] - beg));

        }


        inline  void Solve(const boost::array<double,9>& A, const boost::array<double,3>& b,  boost::array<double,3>& x, float eps = 1e-20)
        {

            double c0 = A[3] * A[7] - A[6] * A[4];
            double c3 = A[6] * A[1] - A[0] * A[7];
            double c2 = A[0] * A[4] - A[3] * A[1];


            double det =  c2 + c3 + c0;

            if(std::abs(det) <= eps)
            {
                x[0] = x[1] = x[2] = 0;
                return;
            }

            double invdet = 1.0 / det;

            x[0] = ((A[4] - A[7]) * b[0] + (A[7] - A[1]) * b[1] + (A[1] - A[4]) * b[2]) * invdet;
            x[1] = ((A[6] - A[3]) * b[0] + (A[0] - A[6]) * b[1] + (A[3] - A[0]) * b[2]) * invdet;
            x[2] = (c0 * b[0] + c3 * b[1] + c2 * b[2]) * invdet;



            return;
        }



        void ComputeDisparityPlanes(std::vector<triangle> &tri, uint32_t threadID, uint32_t threadNum)
        {


            boost::array<double,9> A;
            boost::array<double,3> b;
            boost::array<double,3> x;

            A[2] = 1;
            A[5] = 1;
            A[8] = 1;

            uint32_t k0 = (tri.size() * threadID) / threadNum;
            uint32_t k1 = (tri.size() * (threadID + 1)) / threadNum;

            for(uint32_t i = k0; i < k1; i++)
            {

                int32_t c1 = tri[i].c1;
                int32_t c2 = tri[i].c2;
                int32_t c3 = tri[i].c3;

                A[0] = m_suppPoints[c1].u;
                A[1] = m_suppPoints[c1].v;
                A[3] = m_suppPoints[c2].u;
                A[4] = m_suppPoints[c2].v;
                A[6] = m_suppPoints[c3].u;
                A[7] = m_suppPoints[c3].v;
                b[0] = m_suppPoints[c1].d;
                b[1] = m_suppPoints[c2].d;
                b[2] = m_suppPoints[c3].d;

                Solve(A, b, x);

                tri[i].t1a = x[0];
                tri[i].t1b = x[1];
                tri[i].t1c = x[2];


                A[0] = m_suppPoints[c1].u - m_suppPoints[c1].d;
                A[3] = m_suppPoints[c2].u - m_suppPoints[c2].d;
                A[6] = m_suppPoints[c3].u - m_suppPoints[c3].d;

                Solve(A, b, x);

                tri[i].t2a = x[0];
                tri[i].t2b = x[1];
                tri[i].t2c = x[2];

            }
        }


        void CreateGrid(int32_t* pGrid, bool right_image, uint32_t threadID, uint32_t threadNum)
        {



            int d_stride = m_gridWidth * (m_dispMax + 1);
            uint32_t k0 = (m_gridHeight * d_stride * threadID) / threadNum;
            uint32_t k1 = (m_gridHeight * d_stride * (threadID + 1)) / threadNum;

            std::fill(temp1 + k0, temp1 + k1, 0);

            m_barrier.wait();

            k0 = (m_suppPoints.size() * threadID) / threadNum;
            k1 = (m_suppPoints.size() * (threadID + 1)) / threadNum;

            for(uint32_t i = k0; i < k1; i++)
            {

                int32_t x_curr = m_suppPoints[i].u;
                int32_t y_curr = m_suppPoints[i].v;
                int32_t d_curr = m_suppPoints[i].d;

                int32_t x = ((!right_image) ? x_curr : x_curr  - d_curr) / m_grid_size;
                int32_t y =  y_curr / m_grid_size;


                if(x >= 0 && x < (int) m_gridWidth && y >= 0 && y < (int) m_gridHeight && (x_curr >= d_curr || !right_image))
                    //questo serve x addPoint
                {
                    int stride = y * d_stride + x * (m_dispMax + 1);
                    if(d_curr >= 1)
                    {
                        temp1 [stride + d_curr - 1] = 1;
                    }
                    temp1 [stride + d_curr] = 1;
                    if(d_curr < m_dispMax)
                    {
                        temp1 [stride + d_curr + 1] = 1;
                    }
                }

            }


            m_barrier.wait();


            int end = m_gridWidth * (m_gridHeight - 2) - 2;
            k0 = (end * threadID) / threadNum;
            k1 = (end * (threadID + 1)) / threadNum;

            uint8_t* tmp = temp1 + k0 * (m_dispMax + 1);

            const uint8_t* tl = tmp;
            const uint8_t* tc = tmp + (m_dispMax + 1);
            const uint8_t* tr = tmp + 2 * (m_dispMax + 1);
            const uint8_t* cl = tmp + m_gridWidth * (m_dispMax + 1);
            const uint8_t* cc = tmp + (m_gridWidth + 1) * (m_dispMax + 1);
            const uint8_t* cr = tmp + (m_gridWidth + 2) * (m_dispMax + 1);
            const uint8_t* bl = tmp + (2 * m_gridWidth) * (m_dispMax + 1);
            const uint8_t* bc = tmp + (2 * m_gridWidth + 1) * (m_dispMax + 1);
            const uint8_t* br = tmp + (2 * m_gridWidth + 2) * (m_dispMax + 1);



            ///controllare bordi

            pGrid += (m_gridWidth + 1) * m_gridDisp + k0 * m_gridDisp;
            for(uint32_t x = k0; x < k1; x++)
            {
                int32_t curr_ind = 0;
                ++pGrid;
                for(int32_t d = 0; d <= m_dispMax; d++)
                {
                    if(*tl++ | *tc++ | *tr++ | *cl++ | *cc++ | *cr++ | *bl++ | *bc++ | *br++)
                    {
                        *pGrid++ = d;
                        curr_ind++;
                    }
                }

                pGrid[-curr_ind - 1] = curr_ind;
                pGrid += m_dispMax + 2 - curr_ind - 1;
            }


        }

#ifdef __SSE2__        
        inline void UpdatePosteriorMinimum(__m128i* I2_block_addr, int32_t d, int32_t w,
                                           const __m128i& xmm1, __m128i& xmm2, int32_t& min_val, int32_t& min_d)
        {
            xmm2 = _mm_load_si128(I2_block_addr);
            xmm2 = _mm_sad_epu8(xmm2, xmm1);
            int32_t val  = _mm_extract_epi16(xmm2, 0) + _mm_extract_epi16(xmm2, 4) + w;
            if(val < min_val)
            {
                min_val = val;
                min_d   = d;
            }
        }

        inline void UpdatePosteriorMinimum(__m128i* I2_block_addr, int32_t d,
                                           const __m128i& xmm1, __m128i& xmm2, int32_t& min_val, int32_t& min_d)
        {
            xmm2 = _mm_load_si128(I2_block_addr);
            xmm2 = _mm_sad_epu8(xmm2, xmm1);
            int32_t val  = _mm_extract_epi16(xmm2, 0) + _mm_extract_epi16(xmm2, 4);
            if(val < min_val)
            {
                min_val = val;
                min_d   = d;
            }
        }
#else
        inline void UpdatePosteriorMinimum(uint8_t* I2_block_addr, const uint8_t* I1_block_addr, int32_t d, int32_t w, int32_t& min_val, int32_t& min_d)
        {
            
            int32_t val = w;
            for(int k = 0; k<16; k++)
               val+= std::abs((int)I2_block_addr[k] - (int)I1_block_addr[k]);
            if(val < min_val)
            {
                min_val = val;
                min_d   = d;
            }
        }

        inline void UpdatePosteriorMinimum(uint8_t* I2_block_addr, const uint8_t* I1_block_addr, int32_t d, int32_t& min_val, int32_t& min_d)
        {
            int32_t val=0;
            for(int k = 0; k<16; k++)
               val+= std::abs((int)I2_block_addr[k] - (int)I1_block_addr[k]);
            
            if(val < min_val)
            {
                min_val = val;
                min_d   = d;
            }
        }

#endif

        inline void FindMatch(int32_t u, int32_t v, float plane_a, float plane_b, float plane_c,
                              int32_t* disparity_grid, uint8_t* I1_desc, uint8_t* I2_desc,
                              int32_t* P, int32_t plane_radius, bool valid, bool right_image, float* D)
        {

            const int32_t disp_num  = m_gridDisp - 1;
            const int32_t window_size = 3;

            ///corretto min max? //c'era ,2);
            int32_t  stride = m_width * v;
            uint8_t* I2_line_addr = I2_desc + 16 * stride;
            uint8_t* I1_block_addr = I1_desc + 16 * (stride + u);

            uint32_t d_addr = halfResolution ?  stride / 4 + u / 2 : stride + u;
            if(v < 3 + halfResolution || v > (int) m_height - 4)
            {
                * (D + d_addr) = -1;
                return;
            }
#ifdef __SSE2__ 
            __m128i xmm1, xmm2;
#endif            
            int32_t sum;
#ifdef __SSSE3__
            __m128i xmm0;
            xmm0 = _mm_load_si128((__m128i*) I1_block_addr);
            xmm2 = _mm_cmpeq_epi32(xmm2, xmm2);
            xmm1 = xmm0;
            xmm0 = _mm_unpacklo_epi8(xmm0, xmm0);
            xmm1 = _mm_unpackhi_epi8(xmm1, xmm1);
            xmm2 = _mm_slli_epi16(xmm2, 15);
            xmm0 = _mm_srli_epi16(xmm0, 8);
            xmm1 = _mm_srli_epi16(xmm1, 8);
            xmm2 = _mm_srli_epi16(xmm2, 8);
            xmm0 = _mm_sub_epi16(xmm0, xmm2);
            xmm1 = _mm_sub_epi16(xmm1, xmm2);
            xmm0 = _mm_abs_epi16(xmm0);
            xmm1 = _mm_abs_epi16(xmm1);
            xmm0 = _mm_add_epi16(xmm0, xmm1);
            xmm1 = _mm_shuffle_epi32(xmm0, 78);
            xmm0 = _mm_add_epi16(xmm0, xmm1);
            xmm1 = _mm_shuffle_epi32(xmm0, 1);
            xmm0 = _mm_add_epi16(xmm0, xmm1);
            sum  = _mm_extract_epi16(xmm0, 0) + _mm_extract_epi16(xmm0, 1);

#else
            sum = 0;
            for(int32_t i = 0; i < 16; i++)
            {
                sum += std::abs((int32_t)(* (I1_block_addr + i)) - 128);
            }
#endif
            if(sum < m_match_texture)
            {
                * (D + d_addr) = -1;
                return;
            }


            int32_t d_plane     = (int32_t)(plane_a * u + plane_b * v + plane_c);
            int32_t d_plane_min = std::max(d_plane - plane_radius, 0);
            int32_t d_plane_max = std::min(d_plane + plane_radius, disp_num - 1);

            int32_t  grid_x    = u / m_grid_size;
            int32_t  grid_y    = v / m_grid_size;
            uint32_t grid_addr = (grid_y * m_gridWidth + grid_x) * m_gridDisp;
            int32_t  num_grid  = * (disparity_grid + grid_addr);
            int32_t* d_grid    = disparity_grid + grid_addr + 1;

            // loop variables
            int32_t d_curr, u_warp;
            int32_t min_val = std::numeric_limits<int32_t>::max();
            int32_t min_d   = -1;
#ifdef __SSE2__              
            xmm1    = _mm_load_si128((__m128i*) I1_block_addr);
#endif

            if(!right_image)
            {
                for(int32_t i = 0; i < num_grid; i++)
                {
                    d_curr = d_grid[i];
                    if(d_curr < d_plane_min || d_curr > d_plane_max)
                    {
                        u_warp = u - d_curr;
                        if(u_warp < window_size || u_warp > (int32_t) m_width - window_size - 1)
                        {
                            continue;
                        }
#ifdef __SSE2__                        
                        UpdatePosteriorMinimum((__m128i*)(I2_line_addr + 16 * u_warp), d_curr, xmm1, xmm2, min_val, min_d);
#else
                        UpdatePosteriorMinimum(I2_line_addr + 16 * u_warp, I1_block_addr, d_curr, min_val, min_d);
#endif
                    }
                }


                int32_t start = std::max(d_plane_min, u - (int32_t) m_width + window_size + 1);
                int32_t end = std::min(d_plane_max, u - window_size);
                for(d_curr = start; d_curr <= end; d_curr++)
                {
                    u_warp = u - d_curr;
#ifdef __SSE2__                     
                    UpdatePosteriorMinimum((__m128i*)(I2_line_addr + 16 * u_warp), d_curr, valid ? * (P + abs(d_curr - d_plane)) : 0, xmm1, xmm2, min_val, min_d);
#else
                    UpdatePosteriorMinimum(I2_line_addr + 16 * u_warp, I1_block_addr, d_curr, valid ? * (P + abs(d_curr - d_plane)) : 0, min_val, min_d);
#endif
                  
                }



            }
            else
            {
                for(int32_t i = 0; i < num_grid; i++)
                {
                    d_curr = d_grid[i];
                    if(d_curr < d_plane_min || d_curr > d_plane_max)
                    {
                        u_warp = u + d_curr;
                        if(u_warp < window_size || u_warp > (int32_t) m_width - window_size - 1)
                        {
                            continue;
                        }
#ifdef __SSE2__                         
                        UpdatePosteriorMinimum((__m128i*)(I2_line_addr + 16 * u_warp), d_curr, xmm1, xmm2, min_val, min_d);
#else
                        UpdatePosteriorMinimum(I2_line_addr + 16 * u_warp, I1_block_addr, d_curr, min_val, min_d);
#endif                        
                    }
                }

                int32_t start = std::max(d_plane_min, window_size - u);
                int32_t end = std::min(d_plane_max, (int32_t) m_width - window_size - 1 - u);
                for(d_curr = start; d_curr <= end; d_curr++)
                {
                    u_warp = u + d_curr;
#ifdef __SSE2__                    
                    UpdatePosteriorMinimum((__m128i*)(I2_line_addr + 16 * u_warp),    d_curr, valid ? * (P + abs(d_curr - d_plane)) : 0, xmm1, xmm2, min_val, min_d);
#else
                    UpdatePosteriorMinimum(I2_line_addr + 16 * u_warp, I1_block_addr, d_curr, valid ? * (P + abs(d_curr - d_plane)) : 0, min_val, min_d);
#endif                    
                }


            }

            * (D + d_addr) =  min_d;


        }

        void ComputeDisparity(std::vector<triangle> tri, int32_t* grid, uint8_t* I1_desc, uint8_t* I2_desc, float* D, bool right_image, uint32_t threadID, uint32_t threadNum)
        {

            const int32_t window_size = 3;
            const float two_sigma_squared = 2 * m_sigma * m_sigma;
            const int32_t disp_num  = m_gridDisp - 1;
            const float logamma = log(m_gamma);
            const int32_t plane_radius = (int32_t) std::max((float) ceil(m_sigma * m_sradius), 2.0f);


            int32_t P[disp_num];


            for(int32_t delta_d = 0; delta_d < disp_num; delta_d++)
            {
                P[delta_d] = (int32_t)((-log(m_gamma + exp(-delta_d * delta_d / two_sigma_squared)) + logamma) / m_beta);
            }


            int k0 = (tri.size() * threadID) / threadNum;
            int k1 = (tri.size() * (threadID + 1)) / threadNum;

            for(int32_t i = k0; i < k1; i++)
            {

                int32_t c1 = tri[i].c1;
                int32_t c2 = tri[i].c2;
                int32_t c3 = tri[i].c3;

                std::pair<float, float> trisort[3];
                trisort[0].second = m_suppPoints[c1].v;
                trisort[1].second = m_suppPoints[c2].v;
                trisort[2].second = m_suppPoints[c3].v;

                float plane_a, plane_b, plane_c, plane_d;

                if(!right_image)
                {
                    plane_a = tri[i].t1a;
                    plane_b = tri[i].t1b;
                    plane_c = tri[i].t1c;
                    plane_d = tri[i].t2a;

                    trisort[0].first = m_suppPoints[c1].u;
                    trisort[1].first = m_suppPoints[c2].u;
                    trisort[2].first = m_suppPoints[c3].u;

                }
                else
                {
                    plane_a = tri[i].t2a;
                    plane_b = tri[i].t2b;
                    plane_c = tri[i].t2c;
                    plane_d = tri[i].t1a;

                    trisort[0].first = m_suppPoints[c1].u - m_suppPoints[c1].d;
                    trisort[1].first = m_suppPoints[c2].u - m_suppPoints[c2].d;
                    trisort[2].first = m_suppPoints[c3].u - m_suppPoints[c3].d;
                }



                if(trisort[1].first > trisort[2].first)
                {
                    std::swap(trisort[1], trisort[2]);
                }
                if(trisort[0].first > trisort[1].first)
                {
                    std::swap(trisort[0], trisort[1]);
                }
                if(trisort[1].first > trisort[2].first)
                {
                    std::swap(trisort[1], trisort[2]);
                }

                float A_u = trisort[0].first;
                float A_v = trisort[0].second;
                float B_u = trisort[1].first;
                float B_v = trisort[1].second;
                float C_u = trisort[2].first;
                float C_v = trisort[2].second;

                ///Ha senso castare a int?
                float AC_a = ((int32_t)(A_u) != (int32_t)(C_u)) ? (A_v - C_v) / (A_u - C_u) : 0;
                float AC_b = A_v - AC_a * A_u;


                bool valid = fabs(plane_a) < 0.7 && fabs(plane_d) < 0.7;

                if((int32_t)(A_u) != (int32_t)(B_u))
                {
                    float AB_a = (A_v - B_v) / (A_u - B_u);
                    float AB_b = A_v - AB_a * A_u;

                    int32_t u0 = std::max((int32_t) A_u, window_size);
                    int32_t u1 = std::min((int32_t) B_u, (int32_t) m_width - (window_size));
                    int32_t inc = 1;

                    if(halfResolution)
                    {
                        u0 += u0 % 2;
                        inc++;
                    }
                    for(int32_t u = u0; u < u1; u += inc)
                    {
                        int32_t v0 = (int32_t)(AC_a * u + AC_b);
                        int32_t v1 = (int32_t)(AB_a * u + AB_b);
                        if(v0 > v1)
                        {
                            std::swap(v0, v1);
                        }
                        if(halfResolution)
                        {
                            v0 += v0 % 2;
                        }
                        for(int32_t v = v0; v < v1; v += inc)
                            FindMatch(u, v, plane_a, plane_b, plane_c, grid,
                                      I1_desc, I2_desc, P, plane_radius, valid, right_image, D);
                    }
                }



                if((int32_t)(B_u) != (int32_t)(C_u))
                {
                    float BC_a = (B_v - C_v) / (B_u - C_u);
                    float BC_b = B_v - BC_a * B_u;

                    int32_t u0 = std::max((int32_t) B_u, window_size);
                    int32_t u1 = std::min((int32_t) C_u, (int32_t) m_width - (window_size));
                    int32_t inc = 1;

                    if(halfResolution)
                    {
                        u0 += u0 % 2;
                        inc++;
                    }
                    for(int32_t u = u0; u < u1; u += inc)
                    {
                        int32_t v0 = (int32_t)(AC_a * u + AC_b);
                        int32_t v1 = (int32_t)(BC_a * u + BC_b);
                        if(v0 > v1)
                        {
                            std::swap(v0, v1);
                        }
                        if(halfResolution)
                        {
                            v0 += v0 % 2;
                        }
                        for(int32_t v = v0; v < v1; v += inc)
                            FindMatch(u, v, plane_a, plane_b, plane_c, grid,
                                      I1_desc, I2_desc, P, plane_radius, valid, right_image, D);
                    }
                }

            }

        }


#ifdef LEFT_REFERENCE
        void LRCheck(uint32_t threadID, uint32_t threadNum)
        {
            uint32_t width = m_dsi2.W();
            uint32_t height =  m_dsi2.H();
            int k0 = (height * threadID) / threadNum;
            int k1 = (height * (threadID + 1)) / threadNum;

            ///dimostrare che  j+d1<0 || j+d1>=m_width non si verifica

            float* right = (float*) m_dsi2.Buffer() + k0 * width;
            float* left = (float*) m_dsi->Buffer() + k0 * width;
            for(int32_t i = k0; i < k1; i++)
                for(uint32_t j = 0; j < width; j++, left++, right++)
                {              
                    float d1 = *left;
                    if((d1 < 0) || ((fabs(right[-((int) d1 >> halfResolution)] - d1) > m_lr_threshold)))
                    {
                        *left = DISPARITY_UNKNOWN;
                    }

                }

        }
#else
        void LRCheck(uint32_t threadID, uint32_t threadNum)
        {
            uint32_t width = m_dsi2.W();
            uint32_t height =  m_dsi2.H();
            int k0 = (height * threadID) / threadNum;
            int k1 = (height * (threadID + 1)) / threadNum;

            ///dimostrare che  j+d1<0 || j+d1>=m_width non si verifica

            float* left = (float*) m_dsi2.Buffer() + k0 * width;
            float* right = (float*) m_dsi->Buffer() + k0 * width;
            for(int32_t i = k0; i < k1; i++)
                for(uint32_t j = 0; j < width; j++, left++, right++)
                {
                    float d1 = *right;
                    if((d1 < 0) || ((fabs(left[(int) d1 >> halfResolution] - d1) > m_lr_threshold)))
                    {
                        *right = DISPARITY_UNKNOWN;
                    }

                }

        }
#endif



        template<typename T>
        inline void ComputeDisparity(const T* left, const T* right, uint32_t threadID, uint32_t threadNum)
        {

            int k0 = (m_dsi2.Area() * threadID) / threadNum;
            int k1 = (m_dsi2.Area() * (threadID + 1)) / threadNum;
            std::fill((float*) m_dsi->Buffer() + k0, (float*) m_dsi->Buffer() + k1, DISPARITY_UNKNOWN);       ///TODO vedere se è possibile eliminarla
            std::fill((float*) m_dsi2.Buffer() + k0, (float*) m_dsi2.Buffer() + k1, DISPARITY_UNKNOWN);

            ComputeDescriptor(left, m_leftVDescr.Buffer(), m_leftHDescr.Buffer(), m_leftDescr,  threadID, threadNum);
            ComputeDescriptor(right, m_rightVDescr.Buffer(), m_rightHDescr.Buffer(), m_rightDescr,  threadID, threadNum);

            m_barrier.wait();
            ComputeSupportMatches(threadID, threadNum);
            m_barrier.wait();

            if(m_suppPoints.size() >= 3)
            {

                if(!threadID)
                    ComputeDelaunayTriangulation(m_leftTriangles, 0);

                if(threadID == 1 % threadNum)
                    ComputeDelaunayTriangulation(m_rightTriangles, 1);

                CreateGrid(m_leftGrid, 0, threadID, threadNum);
                m_barrier.wait(); //per toglierlo bisogna duplicare buff temp
                CreateGrid(m_rightGrid, 1, threadID, threadNum);

                m_barrier.wait();
                ComputeDisparityPlanes(m_leftTriangles, threadID, threadNum);
                ComputeDisparityPlanes(m_rightTriangles, threadID, threadNum);
                m_barrier.wait();
                
#ifdef LEFT_REFERENCE
                ComputeDisparity(m_leftTriangles, m_leftGrid, m_leftDescr, m_rightDescr, (float*) m_dsi->Buffer(), 0, threadID, threadNum);
                ComputeDisparity(m_rightTriangles, m_rightGrid, m_rightDescr, m_leftDescr, (float*) m_dsi2.Buffer(), 1, threadID, threadNum);
#else
                ComputeDisparity(m_leftTriangles, m_leftGrid, m_leftDescr, m_rightDescr, (float*) m_dsi2.Buffer(), 0, threadID, threadNum);
                ComputeDisparity(m_rightTriangles, m_rightGrid, m_rightDescr, m_leftDescr, (float*) m_dsi->Buffer(), 1, threadID, threadNum);
#endif                
                m_barrier.wait();

                LRCheck(threadID, threadNum);


                m_barrier.wait();


                DespeckleFilter(*m_dsi, m_barrier, m_dsiXMin, m_dsiXMax, m_dsiYMin, m_dsiYMax, m_speckle_sim_threshold,  (halfResolution) ? 2 * sqrt(m_speckle_size) : m_speckle_size, threadID, threadNum );
                
                
                GapFilter(*m_dsi, m_barrier, m_dsiXMin, m_dsiXMax, m_dsiYMin, m_dsiYMax, threadID, threadNum );
                
                if(m_filter_adaptive_mean)
                    AdaptiveMeanFilter(*m_dsi,  m_dsi2, m_barrier, m_dsiXMin, m_dsiXMax, m_dsiYMin, m_dsiYMax, threadID, threadNum );

                if(m_filter_median)
                    MedianFilter(*m_dsi,  m_dsi2, m_barrier, m_dsiXMin, m_dsiXMax, m_dsiYMin, m_dsiYMax, threadID, threadNum );
                

            }

        }


        uint32_t m_width;
        uint32_t m_height;
        uint32_t m_candwidth;
        uint32_t m_candheight;
        int16_t* m_candimage;
        int16_t* m_candimage2;
        uint32_t m_cansize;
        uint32_t m_step;
        cimage::CImageMono8 m_leftVDescr;
        cimage::CImageMono8 m_leftHDescr;
        cimage::CImageMono8 m_rightVDescr;
        cimage::CImageMono8 m_rightHDescr;
        CDSI m_dsi2;
        uint8_t* m_leftDescr;
        uint8_t* m_rightDescr;
        uint32_t m_gridWidth;
        uint32_t m_gridHeight;
        int32_t m_gridDisp;
        uint32_t m_gridimagesize;
        int32_t* m_leftGrid;
        int32_t* m_rightGrid;
        uint32_t tempsize;
        uint8_t* temp1;
        bool halfResolution;
        boost::barrier m_barrier;
        std::vector<supp_point> m_suppPoints;
        std::vector<triangle> m_leftTriangles;
        std::vector<triangle> m_rightTriangles;
        tessellation::DelaunayTriangulation<math::Point2i> m_triangulator[2];
        CDespeckleFilter<_Threads_Agg> DespeckleFilter;


    };


}

#undef __log_debug

#endif





