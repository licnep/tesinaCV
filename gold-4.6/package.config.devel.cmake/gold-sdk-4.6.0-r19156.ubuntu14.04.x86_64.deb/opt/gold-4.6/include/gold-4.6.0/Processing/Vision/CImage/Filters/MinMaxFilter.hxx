#ifndef _MINMAX_FILTER_HXX
#define _MINMAX_FILTER_HXX

#ifdef ENABLE_IPP
#include <boost/mpl/vector.hpp>
#include <boost/mpl/contains.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/utility/enable_if.hpp>
#include <ippi.h>

namespace  ipp
{            
    inline void ippiFilterMin(const uint8_t* s, int source_stride, uint8_t* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterMin_8u_C1R(s, source_stride, d, dest_stride, dstRoiSize, maskSize, anchor);
    }
    
    inline   void ippiFilterMin(const int16_t* s, int source_stride, int16_t* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterMin_16s_C1R(s, source_stride, d, dest_stride, dstRoiSize, maskSize, anchor);
    }
    
    inline void ippiFilterMin(const uint16_t* s, int source_stride, uint16_t* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterMin_16u_C1R(s, source_stride, d, dest_stride, dstRoiSize, maskSize, anchor);
    }
    
    inline void ippiFilterMin(const RGB8* s, int source_stride, RGB8* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterMin_8u_C3R((uint8_t*)s, source_stride, (uint8_t*)d, dest_stride, dstRoiSize, maskSize, anchor);
    }
    
    inline void ippiFilterMin(const float* s, int source_stride, float* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterMin_32f_C1R(s, source_stride, d, dest_stride, dstRoiSize, maskSize, anchor);
    }

    inline void ippiFilterMax(const uint8_t* s, int source_stride, uint8_t* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterMax_8u_C1R(s, source_stride, d, dest_stride, dstRoiSize, maskSize, anchor);
    }
    
    inline   void ippiFilterMax(const int16_t* s, int source_stride, int16_t* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterMax_16s_C1R(s, source_stride, d, dest_stride, dstRoiSize, maskSize, anchor);
    }
    
    inline void ippiFilterMax(const uint16_t* s, int source_stride, uint16_t* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterMax_16u_C1R(s, source_stride, d, dest_stride, dstRoiSize, maskSize, anchor);
    }
    
    inline void ippiFilterMax(const RGB8* s, int source_stride, RGB8* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterMax_8u_C3R((uint8_t*)s, source_stride, (uint8_t*)d, dest_stride, dstRoiSize, maskSize, anchor);
    }
    
    inline void ippiFilterMax(const float* s, int source_stride, float* d, int dest_stride, IppiSize dstRoiSize, IppiSize maskSize, IppiPoint anchor)
    {
        ippiFilterMax_32f_C1R(s, source_stride, d, dest_stride, dstRoiSize, maskSize, anchor);
    }
 
      
    template <class S, class D>
    struct MinMaxFilterIppSupportCheck :
            boost::mpl::and_<
            boost::mpl::bool_<boost::is_same<S, D>::value>,
            boost::mpl::contains<  boost::mpl::vector< uint8_t, int16_t, uint16_t, RGB8, float > , S> > {};
           
    template<class T, class S, class D>
    struct implementation<kernel::MinFilter<T>, S, D,  typename boost::enable_if< MinMaxFilterIppSupportCheck<S, D> >::type >
    {
        static inline int run(const kernel::MinFilter<T>& f, const S* input, D* output, uint32_t width, uint32_t height, long source_stride)
        {             
            IppiSize  roi = {width - f.GetWidth() + 1, height - f.GetHeight() + 1}, mask = {f.GetWidth(), f.GetHeight()};
            IppiPoint anchor = { f.GetWidth() / 2, f.GetHeight()/ 2};
            int source_offset = source_stride * (f.GetHeight()/ 2) + f.GetWidth() / 2;
            int output_offset = width * (f.GetHeight()/ 2) + f.GetWidth() / 2;
            ippiFilterMin(input + source_offset, source_stride * sizeof(*input) , output + output_offset, width *  sizeof(*output), roi, mask, anchor);
            FillBorders(output, width, height, f.GetWidth(), f.GetHeight());
            return 1;
                 
        }
    };
    
    template<class T, class S, class D>
    struct implementation<kernel::MaxFilter<T>, S, D,  typename boost::enable_if< MinMaxFilterIppSupportCheck<S, D> >::type >
    {
        static inline int run(const kernel::MaxFilter<T>& f, const S* input, D* output, uint32_t width, uint32_t height, long source_stride)
        {             
            IppiSize  roi = {width - f.GetWidth() + 1, height - f.GetHeight() + 1}, mask = {f.GetWidth(), f.GetHeight()};
            IppiPoint anchor = { f.GetWidth() / 2, f.GetHeight()/ 2};
            int source_offset = source_stride * (f.GetHeight()/ 2) + f.GetWidth() / 2;
            int output_offset = width * (f.GetHeight()/ 2) + f.GetWidth() / 2;
            ippiFilterMax(input + source_offset, source_stride * sizeof(*input) , output + output_offset, width *  sizeof(*output), roi, mask, anchor);
            FillBorders(output, width, height, f.GetWidth(), f.GetHeight());
            return 1;
                 
        }
    };
 
}
   

#endif

#endif