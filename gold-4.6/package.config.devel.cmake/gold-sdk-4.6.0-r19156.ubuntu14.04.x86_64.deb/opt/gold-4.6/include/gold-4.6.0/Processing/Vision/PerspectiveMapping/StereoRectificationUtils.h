#ifndef _STEREO_RECTIFICATION_UTILS_H
#define _STEREO_RECTIFICATION_UTILS_H

#include <Processing/Vision/PerspectiveMapping/gold_proc_pm_export.h>
#include <Data/Base/CCameraParams.h>

/// Test if two cameras have the same intrinsic parameters
inline bool HaveCameraSameIntrinsic(const dev::CameraParams & l, const dev::CameraParams & r)
{
  return (l.ku == r.ku) &&
  (l.kv == r.kv) &&
  (l.u0 == r.u0) &&
  (l.v0 == r.v0);
}

/// Test if 2 cameras are aligned along Y axis and optical ray orthogonal to it.
inline bool AreCamerasStrictlyAligned(const dev::CameraParams & l, const dev::CameraParams & r)
{
return  (std::abs(l.roll)<0.0001) && (std::abs(r.roll)<0.0001) &&
	  (std::abs(l.yaw)<0.0001) && (std::abs(r.yaw)<0.0001) &&
	  (std::abs(l.pitch - r.pitch)<0.0001) && 
	  (std::abs(l.x - r.x)<0.001) &&
	  (std::abs(l.z - r.z)<0.001);
}

/// Test if 2 cameras are aligned along their epipole.
bool GOLD_PROC_PM_EXPORT AreCamerasAligned(const dev::CameraParams & l, const dev::CameraParams & r);

/// Elenco di algoritmi disponibili per ComputeRectificationParams
enum RectificationAlgo {
  LeftMaster,  ///< prende tutti i parametri della sx
  RightMaster, ///< prende i parametri della dx
  Average      ///< prende i valor medi tra le camere
};

/** Questa funzione permette di ottenere i parametri della camera rettificati partendo dai parametri originali della coppia stereo 
 * \code
 * ComputeRectificationParams(m_pLeftCamera->Params(), m_pRightCamera->Params(), m_leftRectifieddev::CameraParams, m_rightRectifieddev::CameraParams, RightMaster);
 * \endcode
 */
void GOLD_PROC_PM_EXPORT ComputeRectificationParams(const dev::CameraParams & sl, const dev::CameraParams & sr, dev::CameraParams & dl, dev::CameraParams & dr, RectificationAlgo algo);

/** Questa funzione permette di ottenere i parametri della camera rettificati partendo dai parametri originali della coppia stereo */
void GOLD_PROC_PM_EXPORT ComputeRectificationParams(const std::pair<dev::CameraParams, dev::CameraParams> & s, std::pair<dev::CameraParams, dev::CameraParams> &o, RectificationAlgo algo);

#endif
