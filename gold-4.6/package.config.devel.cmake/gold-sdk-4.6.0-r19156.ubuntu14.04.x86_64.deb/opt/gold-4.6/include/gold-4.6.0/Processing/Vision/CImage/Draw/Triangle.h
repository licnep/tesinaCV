#ifndef _DRAW_TRIANGLE_H
#define _DRAW_TRIANGLE_H

#include <boost/math/tr1.hpp>

// #warning 20120728 please use boost math tr1 functions
// questo va mantenuto perchè ci sono alcuni boost::math::iround in questo file
// usare preferibilmente le funzioni in boost::math::tr1
#include <boost/math/special_functions/round.hpp>

namespace draw {

namespace detail {
  
  /** disegna una sottoparte del triangolo delimita da y0 a y1 in verticale e
    *  da due rette di equazione data in orizzontale, eseguendo il clipping su un rettangolo
    **/
template <class F>
inline void subtriangle(F & f, int xLimit, int yLimit, int y0, int y1, float & xl_edge, float & xr_edge, float dxldy, float dxrdy)
    {
//      std::cout << "fill " << y0 << " to " << y1 << ", " << xl_edge << " to " << xr_edge << std::endl;

     // Il parallelepipedo e' visibile?
     if((y0>=yLimit)||(y1<=0))
	{
	// non visibile, esco ma applico modifiche (potrebbe servire successivamente)
	xl_edge += dxldy * (y1 - y0);
	xr_edge += dxrdy * (y1 - y0);
	return;
	}
     // il parallelepipedo e' parzialmente visibile?
     if(y0<0)
     {
       // clipping in alto: avanzo di -y0 iterazioni
       xl_edge += dxldy * (-y0);
       xr_edge += dxrdy * (-y0);
       y0=0;
     }
     // clipping in basso (non avanzo xl_edge e xr_edge perche' non dovrebbe servire)
     if(y1>yLimit)
       y1= yLimit-1;

     for(int y=y0; y<y1; y++)
       {
        // clipping orizzontale
	int x0 = std::max(0, (int)boost::math::tr1::round(xl_edge)/*boost::math::tr1::round(xl_edge)*/);
	int x1 = std::min(xLimit-1, (int)boost::math::tr1::round(xr_edge)/*boost::math::tr1::round(xr_edge)*/);
	
// 	std::cout << y << ' ' << x0 << ' ' << x1 << std::endl;
	// optimized for FillLine
	f.FillLine(x0,x1,y);
	/*
        for(int x = x0; x <= x1; x++)
         {
         f.FillPixel(x,y);
         }
       */
       xl_edge += dxldy;
       xr_edge += dxrdy;
       }
//        std::cout << "filled to " << xl_edge << " to " << xr_edge << std::endl;
    }

} // detail


/** \ingroup Draw
  * Applies a triangle patch to the image
  * @param f a function called on every pixel
  * @param first,second,third Vertex of the triangle
  * @todo aggiungere una politica per il clipping
  *
  * Example of use:
  * \code
  draw::Triangle(draw::Opaque<unsigned char>(buffer, 128,128, 0), math::Point2f(10,10), math::Point2f(20,20), math::Point2f(30,30) );
  * \endcode
  */
void Triangle(F f, math::Point2f first, math::Point2f second,
		math::Point2f third)
{
	int y1, y2, y3;
	int xLimit = f.W();
	int yLimit = f.H();

	//Bubble sort from top to bottom
	if (first.y > second.y)
		std::swap(first, second);
	if (second.y > third.y)
		std::swap(third, second);
	if (first.y > second.y)
		std::swap(first, second);

	// std::cout << "triangle: " << first << ' ' << second << ' ' << third << ' ' << std::endl;

	// approssimo la Y all'intero (la X invece puo' essere floating)
	y1 = boost::math::tr1::round(first.y);
	y2 = boost::math::tr1::round(second.y);
	y3 = boost::math::tr1::round(third.y);

	if ((y3 < 0) || (y1 >= yLimit))
		return;	// il triangolo non e' visibile verticalmente

	if (y3 == y1) //3 punti allineati
	{
		float x0 = std::min(first.x, std::min(second.x, third.x));
		float x1 = std::max(first.x, std::max(second.x, third.x));

		f.FillLine((int) std::floor(x0), (int) std::ceil(x1), y3);
		return;
	}

	float deltaY = y3 - y1;

	float xl_edge;
	float xr_edge;

	float dxldy;
	float dxrdy;

	// pendenza della retta che congiunge first a third
	float dxdy2 = (float) (third.x - first.x) / deltaY;

	// che geometria ha il triangolo?
	// TODO: io lo implementerei comunque
	if (y2 == y1)
	{
		// e' un triangolo con la punta in basso e la base orizzontale y3>y2=y1

		// se i 2 punti <first,second> sono uguali? sarebbe una retta verticale (TODO andrebbe comunque renderizzata pero')
		if (second.x == first.x)
		{
			float y_0 = std::min(y1, y3);
			float y_1 = std::max(y1, y3);

			f.FillLine((int) std::floor(y_0), (int) std::ceil(y_1), third.x);
			return;
		}

		// quale e' il lato sx e quale e' il lato dx?
		if (second.x > first.x)
		{
			// x2 > x1
			xl_edge = (float) first.x;  // left edge
			xr_edge = (float) second.x;  // right edge
			dxldy = dxdy2;
			dxrdy = (float) (third.x - second.x) / deltaY;
		}
		else
		{
			// x2 <= x1
			xl_edge = (float) second.x;  // left edge
			xr_edge = (float) first.x;  // right edge
			dxldy = (float) (third.x - second.x) / deltaY;
			dxrdy = dxdy2;
		}

		// disegno il triangolo (in fondo)
	}
	else
	{
		// second.y != first.y
		// possono essere un trangolo normale con la punta in alto, come un triangolo con la punta in alto e base pari

		// -- prima parte
		// il triangolo ha la base pari?
		if (y2 == y3)
		{
			// se i 2 punti <second,third> sono uguali? sarebbe una retta verticale (TODO andrebbe comunque renderizzata pero')
			// this branch has not been tested, but should work
			if (second.x == third.x)
			{
				float y_0 = std::min(y2, y3);
				float y_1 = std::max(y2, y3);

				f.FillLine((int) std::floor(y_0), (int) std::ceil(y_1),
						first.x);
				return;
			}

			// quale e' il lato sx e quale e' il lato dx?
			if (second.x > third.x)
			{
				// x2 > x1
				xl_edge = (float) third.x;  // left edge
				xr_edge = (float) second.x;  // right edge
				dxldy = dxdy2;
				dxrdy = (float) (second.x - first.x) / deltaY;
			}
			else
			{
				// x2 <= x1
				xl_edge = (float) second.x;  // left edge
				xr_edge = (float) first.x;  // right edge
				dxldy = (float) (second.x - first.x) / deltaY;
				dxrdy = dxdy2;
			}

		}
		else
		{
			// -- seconda parte --

			// pendenza della retta che congiunge first a second
			float dxdy1 = (float) (second.x - first.x) / (y2 - y1);

			xl_edge = (float) first.x;  // left edge
			xr_edge = (float) first.x;  // right edge

			// quale e' il lato sx e quale e' il lato dx?
			// quale e' il lato sx e quale e' il lato dx?
			if (dxdy1 < dxdy2)
			{
				// la retta 1-2-3 e' a sinistra della retta 1-3
				dxldy = dxdy1;
				dxrdy = dxdy2;
			}
			else
			{
				// la retta 1-2-3 e' a destra della retta 1-3
				dxldy = dxdy2;
				dxrdy = dxdy1;
			}

			// Top half of the triangle: da first a second
			detail::subtriangle(f, xLimit, yLimit, y1, y2, xl_edge, xr_edge,
					dxldy, dxrdy);
			// nota: xl_edge e xr_edge ora puntano al punto di coordinate second.y

			// altrimenti, seconda parte del triangolo, cambio la pendenza di dxl o dxr ma mantengo xl_edge e xr_edge fissi
			if (dxdy1 < dxdy2)
				dxldy = (float) (third.x - second.x) / (third.y - second.y);
			else
				dxrdy = (float) (third.x - second.x) / (third.y - second.y);

		}

	}

	// Bottom Half of the triangle
	detail::subtriangle(f, xLimit, yLimit, y2, y3, xl_edge, xr_edge, dxldy,
			dxrdy);
}

} // namespace draw


#endif
