#ifndef _CHECKBOARD_FILTER_H
#define _CHECKBOARD_FILTER_H

#include <stdint.h>
#include <Data/CImage/PixelTraits/PixelTraits.h>
#include "FilterModifier.h"
#include "ConvolutionKernel.h"
#include "TLocalFilter.h"

namespace cimage {

  namespace kernel {
    
/// -2 + 2 (4)
class CheckBoardFilter3x3: public TConvolutionKernel3x3<-1,0,+1, 0,0,0, +1,0,-1>
{
  public:
  static const int magnitude = 4;
};

typedef filter::Bias<filter::Div<CheckBoardFilter3x3, 4>, 127> CheckBoard3x3NormBias;

/// -8 + 8 (16)
class CheckBoardFilter4x4: public TConvolutionKernel4x4<-1,-1,+1,+1, -1,-1,+1,+1, +1,+1,-1,-1, +1,+1,-1,-1>
{
  public:
  static const int magnitude = 16;
};

typedef filter::Bias<filter::Div<CheckBoardFilter4x4, 16>, 127> CheckBoard4x4NormBias;

/// -8 + 8 (16)
class CheckBoardFilter5x5: public TConvolutionKernel5x5<-1,-1,0,+1,+1, -1,-1,0,+1,+1, 0,0,0,0,0, +1,+1,0,-1,-1, +1,+1,0,-1,-1>
{
  public:
  static const int magnitude = 16;
};

typedef filter::Bias<filter::Div<CheckBoardFilter5x5, 16>, 127> CheckBoard5x5NormBias;

/// -18 + 18 (36)
class CheckBoardFilter6x6: public TConvolutionKernel6x6<-1,-1,-1,+1,+1,+1, -1,-1,-1,+1,+1,+1, -1,-1,-1,+1,+1,+1, +1,+1,+1,-1,-1,-1,  +1,+1,+1,-1,-1,-1, +1,+1,+1,-1,-1,-1>
{
  public:
  static const int magnitude = 36;
};

typedef filter::Bias<filter::Div<CheckBoardFilter6x6, 36>, 127> CheckBoard6x6NormBias;

//// MISC/////////

/// +16 -16 0
class FrameFilter5x5: public TConvolutionKernel5x5<+1,+1,+1,+1,+1, +1,-2,-2,-2,+1, +1,-2,0,-2,+1, +1,-2,-2,-2,+1, +1,+1,+1,+1,+1>
{
  public:
  static const int magnitude = 32;
};

/// +16 -8*3 +8 (24)
class SyncFilter5x5: public TConvolutionKernel5x5<+1,+1,+1,+1,+1, +1,-3,-3,-3,+1, +1,-3,+8,-2,+1, +1,-3,-3,-3,+1, +1,+1,+1,+1,+1>
{
  public:
  static const int magnitude = 24;
};

  }

namespace filter {

  typedef TLocalFilter<kernel::CheckBoard3x3NormBias> CheckBoard3x3NormBias;
  typedef TLocalFilter<kernel::CheckBoard4x4NormBias> CheckBoard4x4NormBias;
  typedef TLocalFilter<kernel::CheckBoard5x5NormBias> CheckBoard5x5NormBias;
  typedef TLocalFilter<kernel::CheckBoard6x6NormBias> CheckBoard6x6NormBias;

}

}

#endif
