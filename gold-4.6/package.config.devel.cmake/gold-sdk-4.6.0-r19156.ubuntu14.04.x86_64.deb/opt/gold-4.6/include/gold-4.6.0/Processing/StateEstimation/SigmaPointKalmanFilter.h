#ifndef _SIGMA_POINT_KALMAN_FILTER_H
#define _SIGMA_POINT_KALMAN_FILTER_H

/** @file SigmaPointKalmanFilter.h
 * @brief include headers for using SPKF
 * 	  see examples in KalmanFilter.h
 * */

#include "Types.h"
#include "detail/SigmaPointKalmanFilter.hxx"
#include "KalmanFilter.h"

#endif
