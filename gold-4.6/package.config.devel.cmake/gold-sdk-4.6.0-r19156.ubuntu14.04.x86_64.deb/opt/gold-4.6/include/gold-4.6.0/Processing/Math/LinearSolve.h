#ifndef _LIN_ALG_H
#define _LIN_ALG_H

/** @file LinearSolve.h
  * @brief Linear Resolve for Matrix
  * @note require GSL configuration options or Eigen
  **/

#include <Processing/Math/gold_proc_math_export.h>
#include <Data/Math/TMatrices.h>

/////////////// EIGEN PART ///////////////////////////////

#include <Eigen/Core>

namespace math
{

/** Compute the 1d matrix kernel using QR factorization 
 * \code
 * math::kernel(k, A);
 * \endcode
 */
template<class MatrixA, class VectorX>
bool kernel(VectorX & x, const MatrixA & A)
{
  // undersized matrix kernel
  Eigen::MatrixXd Q = Eigen::FullPivHouseholderQR<MatrixA>( A.transpose() ).matrixQ(); //  PM BUGFIX 21092012: Eigen ha cambiato l'interfaccia

  for(int i = 0;i<A.cols();++i)
    x(i) = Q(i, A.cols()-1);
  
return true; // TODO
}

/** Compute the 1d matrix kernel using QR factorization 
 * \code
 * math::kernel(k, A);
 * \endcode
 */
template<class MatrixA, class Scalar>
bool kernel(Scalar * x, const MatrixA & A)
{
  // undersized matrix kernel
  Eigen::MatrixXd Q = Eigen::FullPivHouseholderQR<MatrixA>( A.transpose() ).matrixQ(); //  PM BUGFIX 21092012: Eigen ha cambiato l'interfaccia

  for(int i = 0;i<A.cols();++i)
    x[i] = Q(i, A.cols()-1);
  
return true; // TODO
}

}

/////////////// GSL PART ///////////////////////////////

#ifdef GSL_FOUND

#define GSL_RANGE_CHECK_OFF

#include <gsl/gsl_matrix.h>

namespace math
{

/** @brief Risolve il sistema A*x=b.
 *
 *  se A e' rettangolare trova la soluzione che minimizza l'errore ai minimi quadrati
 * @param x output vector with solution
 * @param A input matrix
 * @param b input vector of known terms
 *
 * @note non e' un semplice risolutore lineare, ma e' un risolutore a pseudoinversa basato su decomposizione LU
 * @note non e' stabile per risolvere i problemi Ax=0. In tal caso usare matrix_kernel
 * @return true se la matrice e' risolvibile, false se e' singolare, sottodimensionata, o i vettori hanno dimensione errata
 * \code
 * // matrice dei coefficienti:
 * gsl_matrix *A = gsl_matrix_alloc(n_elements, n_unknown);
 * // Matrice dei termini noti
 * gsl_vector *b = gsl_vector_alloc(n_elements);
 * // Matrice risultato x = (At * t) ^-1 At * b
 * gsl_vector *x = gsl_vector_alloc(n_unknown);
 * for(unsigned int i =0 ; i \< n_elements ; i++)
 *  {
 *  // fille A
 *  gsl_matrix_set(A,i,column, value);
 *  // ...
 *  // fill b
 *  gsl_vector_set(b,i, value);
 *  // ...
 * }
 * linear_resolve(x, A, b);
 * gsl_matrix_free(A);
 * gsl_vector_free(b);
 * gsl_vector_free(x);
 * \endcode
 **/
bool GOLD_PROC_MATH_EXPORT linear_resolve(gsl_vector *x, gsl_matrix *A, gsl_vector *b);

/** @brief Risolve il sistema A*x=0.
 * @param x the 1d kernel
 * @param A the matrix (it will be destroyed)
 *
 *  se A e' rettangolare trova la soluzione che minimizza l'errore ai minimi quadrati
 * @note non e' un semplice risolutore lineare, ma e' un risolutore a pseudoinversa che sfrutta la decomposizione SVD
 * @note DISTRUGGE la matrice A
 **/
bool GOLD_PROC_MATH_EXPORT matrix_kernel(gsl_vector *x, gsl_matrix *A);

bool GOLD_PROC_MATH_EXPORT undersized_matrix_kernel(gsl_vector *x, gsl_matrix *A);
bool GOLD_PROC_MATH_EXPORT undersized_matrix_kernel(double *x, gsl_matrix *A);

/** @brief Risolve il sistema A*x=0.
 *
 * @param A the matrix (it will be destroyed)
 *
 *  se A e' rettangolare trova la soluzione che minimizza l'errore ai minimi quadrati
 * @note non e' un semplice risolutore lineare, ma e' un risolutore a pseudoinversa che sfrutta la decomposizione SVD
 * @note DISTRUGGE la matrice A
 **/
bool GOLD_PROC_MATH_EXPORT matrix_kernel(double *x, gsl_matrix *A);

/// Invia in cout la matrice A
void GOLD_PROC_MATH_EXPORT print_matrix(gsl_matrix *A, const char *matrix_name);

/// Invia in cout il vettore v
void GOLD_PROC_MATH_EXPORT print_vector(gsl_vector *v, const char *matrix_name);

/// invia in cout il calcolo A*b e |A*b|
void GOLD_PROC_MATH_EXPORT print_residual(gsl_matrix *A, gsl_vector *b);

/// invia in cout il calcolo A*x-b e |A*x-b|
void GOLD_PROC_MATH_EXPORT print_residual(gsl_matrix *A, gsl_vector *x, gsl_vector *b);

/** calcola il valor medio, varianza, e massimo del residuo del calcolo A*x=0 */
void GOLD_PROC_MATH_EXPORT evaluate_residual(gsl_matrix *A, gsl_vector *x, double & avg, double &var, double & max);

/** calcola il valor medio, varianza, e massimo del residuo del calcolo A*x=b */
void GOLD_PROC_MATH_EXPORT evaluate_residual(gsl_matrix *A, gsl_vector *x, gsl_vector *b, double & avg, double &var, double & max);

}

#endif

#endif // 
