#ifndef _MOTION_PLANNING_H
#define _MOTION_PLANNING_H

/// ///////////////////////////// Motion Prediction ///////////////////////////

/// L passo
/// B distanza tra le rutoe

/// Ackerman Steering Geometry
/// cot s0 - cot s1 = B/L

/// R = L/tan(yaw)
/// dtheta = tan(omega)/L

/// Ritorna lo spostamento che ha subito il veicolo usando i dati ritornati da un IMU
/// @param yawrate0 yawrate all'istante t0
/// @param yawrate1 yawrate all'istante t0+dt
/// @param speed velocita' del veicolo (supposta costante)
/// @param dt variazione di tempo
VehicleMotion VirtualVehicleKinematics(float yawrate0, float yawrate1, float speed, float dt);

//////////////////////// PLANNING //////////////////////

/// fitta i punti usando i parametri del veicolo
/// @return the steering angle da impostare
float FitPoint(const std::vector<math::Point2d> & p, Vehicle *vehicle);

/// fitta i punti* usando i parametri del veicolo
/// In questo caso i punti sono un pair < posizione, confidenza>. I pesi con confidenza maggiore sono pesati maggiormente
/// @return the steering angle da impostare
float FitPoint(const std::vector< std::pair<math::Point2d,float> > & p, Vehicle *vehicle);

#endif
