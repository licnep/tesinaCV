#ifndef _TLOCALFILTER_H
#define _TLOCALFILTER_H

#include <stdint.h>
#include <boost/thread/thread.hpp>
#include <Data/Math/Rects.h>
#include <Processing/Vision/CImage/BasicOperations/BasicOperations.h>
#include <Data/CImage/TImage.h>

/**
 * \file TLocalFilter.h
 * \brief Classe per applicare filtri all'immagine
 * Class used to implement image filter
 */

namespace cimage 
{

  namespace ipp 
  {
          
    template <class F, class S, class D, class E = void>
    struct implementation
    {
        static inline int run(const F& f, const S* input, D* output, uint32_t width, uint32_t height, long source_stride){ return 0;}
    };

  }

/* dichiarazione generica TLocalFilter
 * se Kernel2=void allora e' un TLocalFilter<Op> con un solo output, 
 * altrimenti e' un TLocalFilter<a,b> con due output
 */  
template<class Kernel1, class Kernel2 = void>
class TLocalFilter;

/**
 * \brief questo template permette di applicare un filtro locale generico, descritto tramite una classe kernel, da TImage a TImage o ad array in memoria
 *
 * Un TLocalFilter si istanzia specificando il filtro che dovra' essere applicato all'immagine.
 * \code
 * TLocalFilter < SobelVertical3x3 > ilMioFiltro;
 * \endcode
 *
 * Per utilizzare il TLocalFilter si utilizza l'operatore parentesi (sia su CImage che su array di byte) o il costruttore
 *
 * Nel caso si voglia applicare il filtro a una CImage:
 * \code
 * CImageMono8 input;
 * CImageMono8 output;
 * // ...
 * TLocalFilter < Kernel::SobelVerticalBias3x3 > myFilter; // o alternativamente Filter::SobelVerticalBias3x3 myFilter;
 *
 * myFilter(input,output);
 * // o alternativamente
 * Filter::SobelVerticalBias3x3(input, output);
 * \endcode
 *
 * Nel caso si voglia applicare il filtro a un buffer di unsigned char:
 * \code
 * unsigned char *input = new unsigned char [width * height];
 * unsigned char *output = new unsigned char [width * height]
 * // ...
 * TLocalFilter < SobelVerticalBias3x3 > myFilter; // 
 * myFilter(input, output, width, height );
 * \endcode
 *
 * E' altrettanto possibile processare solo UNA SOTTOPARTE dell'immagine in ingresso
 * \code
 * myFilter(input, output, math::Rect2i(20,20, 200, 200) );
 * \endcode
 * In questo caso output sara' grande 180x180 pixels.
 *
 * @note Il tipo della classe kernel utilizzata puo' essere recuperato cosi':
 * \code
 * myFilter::KernelType;
 * \endcode
 *
 * Se la funzione di filtraggio della classe kernel viene controllata da un parametro, questo puo' essere impostato come
 * \code
 * TLocalFilter < SobelVerticalTh3x3 > m_myFilter;
 * ...
 * m_myFilter.SetThreshold(threshold);
 * m_myFilter(input,output);
 * \endcode
 *
 * Al costruttore di TLocalFilter e' possibile passare come parametro un'istanza gia' pronta della classe filtro, di cui si fara' una copia.
 *
 * @note
 * La classe kernel definisce il metodo (che verra' utilizzato dal TLocalFilter istanziato)
 *  che prende in ingresso l'indirizzo di un pixel (al centro della finestra) e restituisce un valore
 *  calcolato in base ai pixel nel suo intorno (grande GetWidth() x GetHeight() )
 *
 * Le classi kernel DEVONO contenere:
 * - L'overload dell'operatore parentesi, che prenda in ingresso un puntatore al pixel centrale in ingresso
 *   (permettendogli quindi di eseguire le operazioni anche in un suo intorno)
 *   e restituisca un valore da mettere nel pixel di uscita.
 *   N.B.: Le finestre utilizzate dai kernel devono essere centrate sul pixel elaborato.
 *   - la definizione delle funzioni
 *    * zero()   -> deve restituire il valore a cui settare i pixel del bordo dell'immagine d'uscita
                   (che vanno azzerati perche' il filtro non puo' elaborarli)
 *    * GetWidth()  -> deve restituire la larghezza dell'area attorno al pixel input elaborata dal kernel
 *    * GetHeight() -> deve restituire l'altezza dell'area attorno al pixel input elaborata dal kernel
 * - Eventuali altri metodi (accessibili all'utente del filtro) per settare ad esempio soglie.
 *
 * Ecco un esempio, la classe fooKernel:
 * \code
 * class fooKernel
 *     {
 *     public:
 *         template<class D>
 *         inline D zero() const { return 0; }
 *         inline uint32_t GetWidth() const { return width; }
 *         inline uint32_t GetHeight() const { return height; }
 *         template<class S>
 *         inline X operator()(const S* inputPixel, long stride) const
 *           {
 *           return (static_cast<D>(0*inputPixel[-stride-1])
 *                   + 1*static_cast<D>(inputPixel[-stride])
 *                   + 2*static_cast<D>(inputPixel[-stride1])
 *                   + 3*static_cast<D>(inputPixel[-1])
 *                   + 4*static_cast<D>(inputPixel[0])
 *                   + 5*static_cast<D>(inputPixel[1])
 *                   + 6*static_cast<D>(inputPixel[stride-1])
 *                   + 7*static_cast<D>(inputPixel[stride])
 *                   + 8*static_cast<D>(inputPixel[stride+1]))/36;
 *           }
 *      };
 * \endcode
 *
 * Poi puo' essere aggiunta qualsiasi funzioni per settare o leggere
 * parametri della funzione del kernel, come ad esempio una soglia per Sobel
 * (vedi per esempio SobelVerticalAbsTh),
 * che saranno raggiungibili attraverso la chiamata al metodo kernel() indicata piu' sopra.
 * 
 * @see SobelFilter.h AverageFilter.h DerivativeFilter.h FilterModifier.h
 *
 * @note Di default la classe genera automaticamente tanti thread come indicato PLATFORM_CPU_CORES
 *       Per poter selezionare il numero di thread manualmente usare la sintassi
 *       \code
 *       filter.SetNumberOfThreads(n);
 *       \endcode
 **/
template<class F>
class TLocalFilter<F, void> : public F {
  
  /// PLATFORM_CPU_CORES
      int m_nCores;

	private:
	/** Block Render. Versione interna dell'applicatore del filtro. 
          * @param input pixel iniziale dell'immmagine sorgente
          * @param output pixel inizial dell'immagine destinazione
          * @param width,height dimensioni dell'are da analizzare
          * @param source_stride il delta (in pixel) per passare da una riga alla successiva
	  *
	  * @note esegue il rendering del filtro partendo su input&output per count linee. Riempie con (zero) i valori non validi orizzontali
          **/
	template<class S, class D>
        inline void render(const S* input, D* output, uint32_t width, uint32_t count, long source_stride);
     
	/** funzione chiamata per ogni thread
	  * @param input  puntatore ai dati Input
	  * @param output puntatore ai dati in Output
          * @param width  processing image width
          * @param input_stride delta tra una riga e la successiva dell'input
          * @param count numero di righe da processare
          * @param slice numero di slice a cui e' assegnato il dato
          **/
	template<class S, class D>
	inline void mcore(const S * input, D * output, uint32_t width, long input_stride, uint32_t count, uint32_t slice  );

        /// La funzione che applica effettivamente il filtro. Genera multithreading o singlethreading a seconda di m_nCores
        template<class S, class D>
        inline void apply(const S* input, D* output, uint32_t width, uint32_t height, long source_stride);
        
        
        template<class S, class D>
        inline void apply2(const S* input, D* output, uint32_t width, uint32_t height, long source_stride);

	/** Versione per generare da un singolo filtro che ritorna una pair due immagini */
	template<class S, class D1, class D2>
        inline void apply(const S* input, D1* output1, D2* output2, uint32_t width, uint32_t height, long source_stride);

	public:
	/// costruttore con i parametri di un filtro
	TLocalFilter(const F & f = F(), int nCores = boost::thread::hardware_concurrency()) : F(f), m_nCores(nCores) { }
	
	/// Costructor able to execute the processing
	/// @param input input image
	/// @param output output image
	template<class S, class D>
        TLocalFilter (const TImage<S>& input, TImage<D>& output, const F & f = F(), int nCores = boost::thread::hardware_concurrency()) : F(f), m_nCores(nCores)
            {
	      this->operator()(input, output);
            }

	/// Costructor able to execute the processing
	/// @param input input buffer
	/// @param output output buffer
	/// @param width,height buffers geometry
	template<class S, class D>
        TLocalFilter (const S* input, D* output, uint32_t width, uint32_t height, const F & f = F(), int nCores = boost::thread::hardware_concurrency()) : F(f), m_nCores(nCores)
            {
	      this->apply(input, output, width, height, width);
            }

	/// Costructor able to execute the processing
	/// @param input input buffer
	/// @param output output buffer
	/// @param width,height buffers geometry
	/// @param source_stride line size
	template<class S, class D>
        TLocalFilter (const S* input, D* output, uint32_t width, uint32_t height, long source_stride, const F & f = F(), int nCores = boost::thread::hardware_concurrency()) : F(f), m_nCores(nCores)
            {
	      this->apply(input, output, width, height, source_stride);
            }

        /** Operatore per applicare un filtro su immagini di input croppate.
	 * @param input input buffer
	 * @param output output buffer
	 * @param width,height geometry of buffers
	 * @param source_stride line size
	 */
	template<class S, class D>
        inline void operator()(const S* input, D* output, uint32_t width, uint32_t height, long source_stride)
	{
	this->apply(input, output, width, height, source_stride);
	}

        /**
        * @brief Calcola l'immagine filtrata con la maschera scelta nel template
        * @param input  Buffer dell'immagine di input
        * @param output Buffer dell'immagine di output
        * @param width Larghezza delle immagini di input/output
        * @param height Altezza delle immagini di input/output
        */
	template<class S, class D>
        inline void operator()(const S* input, D* output, const uint32_t width, const uint32_t height)
	{
	this->apply(input, output, width, height, width);
	}

        /**
        * @brief Calcola l'immagine filtrata con la maschera scelta nel template
        * @param input  Buffer dell'immagine di input
        * @param output Buffer dell'immagine di output
        * @param width Larghezza delle immagini di input
        * @param height Altezza delle immagini di input
        * @param area area di ingresso da processare, e rettangolo grande come l'immagine di output
        */
	template<class S, class D>
        inline void operator()(const S* input, D* output, const uint32_t width, const uint32_t height, const math::Rect2i &area)
	{
	this->apply(input + area.x0 + area.y0 *width, output, area.width(), area.height(), width);
	}

        /**
        * @brief Applica il filtro tra due CImage
        * @param input  Immagine di input
        * @param output Immagine di output
        */
        template<class S, class D>
        inline void operator() (const TImage<S>& input, TImage<D>& output)
            {
            const uint32_t width = input.W();
            const uint32_t height = input.H();
            Resize(output, width, height);
 
            this->apply(input.Buffer(), output.Buffer(), width, height, width);
            }

	/**
        * @brief Applica il filtro tra due CImage con maschera
        * @param input  Immagine di input
        * @param output Immagine di output
        */
        template<class S, class D>
        inline void operator() (const TImage<S>& input, TImage<D>& output, const cimage::TImage<uint8_t> & mask)
            {
            const uint32_t width = input.W();
            const uint32_t height = input.H();
            Resize(output, width, height);
            this->apply(input.Buffer(), output.Buffer(), mask.Buffer(), width, height, width);
            }
            
        /**
        * @brief Applica il filtro tra due CImage in una sottoparte dell'immagine sorgente
        * @param input  Immagine di input
        * @param output Immagine di output
        * @param source_origin rettangolo dell'immagine di input da processare
	* @param crop se true l'immagine output e' grande come il Rettangolo, altrimenti viene generato l'output nella stessa zona dell'input
        */
        template<class S, class D>
        inline void operator() (const TImage<S>& input, TImage<D>& output, const math::Rect2i &source_origin, bool crop=true)
            {
            const uint32_t width = source_origin.width();
            const uint32_t height = source_origin.height();
            Resize(output, width, height);
            this->apply(input.Buffer(), output.Buffer(), width, height, source_origin);
            }

        /**
        * @brief Applica il filtro tra due CImage
        * @param input  Immagine di input
        * @param output Immagine di output
        */
        template<class S, class D1, class D2>
        inline void operator() (const TImage<S>& input, TImage<D1>& output1, TImage<D2>& output2)
            {
            const uint32_t width = input.W();
            const uint32_t height = input.H();
            Resize(output1, width, height);
            Resize(output2, width, height);
            this->apply(input.Buffer(), output1.Buffer(), output2.Buffer(), width, height, width);
            }

	/// Return the number of threads involved in processing
	inline int GetNumberOfThreads() const { return m_nCores; }

	/// Change the number of threads involved in processing
	inline void SetNumberOfThreads(int nCores) { m_nCores = nCores; }

};

/** Single Input, Multiple Output
  * Questa versione permette di applicare due filtri contemporaneamente alla stessa area di memoria sorgente, multiple uscite,
  *  permettendo di condivere conti e cache
  * \code
  *  cimage::TLocalFilter<cimage::kernel::SobelVerticalBias5x5, cimage::kernel::SobelHorizontalBias5x5> filter;
  *  filter(inputImageMono, outputImageMono, outputImageMono2);
  * \endcode
  **/
template<typename A, typename B>
class TLocalFilter {
  /// PLATFORM_CPU_CORES
      int m_nCores;
private:
  
  /// Internal multicore render
    template<class S, class D1, class D2>
    void apply(const S* input, D1* output1, D2* output2, uint32_t width, uint32_t height, long stride);

    /// riempie
    template<class D1, class D2>
    void fill_border(D1* output1, D2* output2, uint32_t width, uint32_t height, long stride);
    
public:
  /// first filter
  	A first;
  /// second filter
  	B second;
public:
  
	/// costructor with two filter and optional platform cpu cores
	TLocalFilter(const A & a = A(), const B & b=B(), int nCores = boost::thread::hardware_concurrency()) : m_nCores(nCores), first(a), second(b) { }

	/// return the whole filter size
	int GetWidth() const { return std::max(first.GetWidth(), second.GetWidth()); }
	/// return the whole filter size
	int GetHeight() const { return std::max(first.GetHeight(), second.GetHeight()); }
	
	/// metodo per generare due immagini da una sorgente. Le immagini input e output devono avere tutte la stessa dimensione
	template<class S, class D1, class D2>
        void operator()(const S* input, D1* output1, D2* output2, uint32_t width, uint32_t height);

	/** metodo per generare 2 immagini da una sorgente
	  * @param input an input CImage
	  * @param output1 an output CImage for filter A
	  * @param output2 an output CImage for filter B
	  * */
        template<class S, class D1, class D2>
        void operator() (const cimage::TImage<S>& input, cimage::TImage<D1> & output1, cimage::TImage<D2>& output2)
            {
            const uint32_t width = input.W();
            const uint32_t height = input.H();
            Resize(output1, width, height);
            Resize(output2, width, height);
            this->operator()(input.Buffer(), output1.Buffer(), output2.Buffer(), width, height);
            }
            
	/// Return the number of threads involved in processing
	inline int GetNumberOfThreads() const { return m_nCores; }

	/// Change the number of threads involved in processing
	inline void SetNumberOfThreads(int nCores) { m_nCores = nCores; }
            
}; 

} // cimage

// implementazione
#include "detail/TLocalFilter.hxx"

#endif
