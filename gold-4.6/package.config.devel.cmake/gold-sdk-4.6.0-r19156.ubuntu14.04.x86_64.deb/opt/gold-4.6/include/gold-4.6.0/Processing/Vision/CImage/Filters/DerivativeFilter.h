#ifndef _DERIVATIVE_FILTER_H
#define _DERIVATIVE_FILTER_H

/** @file DerivativeFilter.h
  * @brief Filtri immagine derivata
  **/

#include <stdint.h>
#include <Data/CImage/PixelTraits/PixelTraits.h>
#include "FilterModifier.h"
#include "TLocalFilter.h"

namespace cimage {

namespace kernel {  
  
/**
 * \brief Implementa il calcolo della derivata verticale, preservando il segno
*/
template<uint32_t w>
class DerivativeVertical;

/**
 * \brief Implementa il calcolo della derivata verticale
*/
template<>
class DerivativeVertical<3>
{
  public:

    // unbiased filter
   static const int bias = 0; 
    // can return negative number
   static const bool positive = false;
    
   // sum
   static const unsigned int magnitude = 2;    
   
   template<typename S>
   struct Return {
        typedef typename cimage::PixelTraits<S>::DifferenceType Type;
	};

    template<class D>
    inline D zero() const { return 0; }
    inline uint32_t GetWidth() const { return 3; }
    inline uint32_t GetHeight() const { return 1; }
    template<class S>
    inline typename cimage::PixelTraits<S>::CumulativeType operator() ( const S* inputPixel, long stride ) const
    {
     typedef typename cimage::PixelTraits<S>::CumulativeType type_t;
     return   static_cast<type_t> ( inputPixel[+1] )
            - static_cast<type_t> ( inputPixel[-1] );
    }
};

/**
 * \brief Implementa il calcolo della derivata verticale
*/
template<>
class DerivativeVertical<2>
{
  public:

    // unbiased filter
   static const int bias = 0; 
    // can return negative number
   static const bool positive = false;
   // sum
   static const unsigned int magnitude = 2;    
    
   template<typename S>
   struct Return {
        typedef typename cimage::PixelTraits<S>::DifferenceType Type;
	};

    template<class D>
    inline D zero() const { return 0; }
    inline uint32_t GetWidth() const { return 2; }
    inline uint32_t GetHeight() const { return 1; }
    template<class S>
    inline typename cimage::PixelTraits<S>::CumulativeType operator() ( const S* inputPixel, long stride ) const
    {
     typedef typename cimage::PixelTraits<S>::CumulativeType type_t;
     return   static_cast<type_t> ( inputPixel[0] )
            - static_cast<type_t> ( inputPixel[-1] );
    }
};

template<uint32_t h>
class DerivativeHorizontal;

/**
 * \brief Implementa il calcolo della derivata orizzontale, preservando il segno
 *
 * I valori inferiori alla soglia vengono azzerati, gli altri preservati
*/
template<>
class DerivativeHorizontal<3>
{
  public:

    // unbiased filter
   static const int bias = 0; 
    // can return negative number
   static const bool positive = false;
   // sum
   static const unsigned int magnitude = 2;    
    
   template<typename S>
   struct Return {
        typedef typename cimage::PixelTraits<S>::DifferenceType Type;
	};

    template<class D>
    inline D zero() const { return 0; }
    inline uint32_t GetWidth() const { return 1; }
    inline uint32_t GetHeight() const { return 3; }
    template<class S>
    inline typename cimage::PixelTraits<S>::CumulativeType operator() ( const S* inputPixel, long stride ) const
    {
     typedef typename cimage::PixelTraits<S>::CumulativeType type_t;
     return   static_cast<type_t> ( inputPixel[+stride] )
            - static_cast<type_t> ( inputPixel[-stride] );
    }
};

/**
 * \brief Implementa il calcolo della derivata orizzontale, preservando il segno
 *
 * I valori inferiori alla soglia vengono azzerati, gli altri preservati
*/
template<>
class DerivativeHorizontal<2>
{
  public:

    // unbiased filter
   static const int bias = 0; 
    // can return negative number
   static const bool positive = false;
   // sum
   static const unsigned int magnitude = 2;    
    
   template<typename S>
   struct Return {
        typedef typename cimage::PixelTraits<S>::DifferenceType Type;
	};

    template<class D>
    inline D zero() const { return 0; }
    inline uint32_t GetWidth() const { return 1; }
    inline uint32_t GetHeight() const { return 2; }
    template<class S>
    inline typename cimage::PixelTraits<S>::CumulativeType operator() ( const S* inputPixel, long stride ) const
    {
     typedef typename cimage::PixelTraits<S>::CumulativeType type_t;
     return   static_cast<type_t> ( inputPixel[0] )
            - static_cast<type_t> ( inputPixel[-stride] );
    }
};


/******************************** Filtri Comuni ***************************************/

/** derivata verticale 3x1 con segno **/
typedef filter::Div<DerivativeVertical<3>, 2> DerivativeVertical3;

/** derivata verticale senza segno
 * \code
 *  TLocalFilter< DerivativeVerticalBias3 > filter;
 *  filter(m_inputImageMono, m_outputImageMono);
 * \endcode
 **/
typedef filter::Bias<DerivativeVertical3, 127> DerivativeVerticalBias3;

/** derivata verticale 3x1 con segno **/
typedef filter::Div<DerivativeVertical<2>, 2> DerivativeVertical2;

/** derivata verticale 2x1 senza segno
 * \code
 *  TLocalFilter< DerivativeVerticalBias2 > filter;
 *  filter(m_inputImageMono, m_outputImageMono);
 * \endcode
 **/
typedef filter::Bias<DerivativeVertical2, 127> DerivativeVerticalBias2;

/** derivata orizzontale 1x3 con segno */
typedef filter::Div<DerivativeHorizontal<3>, 2> DerivativeHorizontal3;

/** derivata orizzontale 1x3 senza segno
 * \code
 *  TLocalFilter< DerivativeHorizontalBias3 > filter;
 *  filter(m_inputImageMono, m_outputImageMono);
 * \endcode
 */
typedef filter::Bias<DerivativeHorizontal3, 127> DerivativeHorizontalBias3;

/** derivata orizzontale con 1x2 segno **/
typedef filter::Div<DerivativeHorizontal<2>, 2> DerivativeHorizontal2;

/** derivata orizzontale 1x2 senza segno
 * \code
 *  TLocalFilter< DerivativeHorizontalBias2 > filter;
 *  filter(m_inputImageMono, m_outputImageMono);
 * \endcode
 */
typedef filter::Bias<DerivativeHorizontal2, 127> DerivativeHorizontalBias2;

}

//////// 
namespace filter {
  typedef TLocalFilter< kernel::DerivativeVertical3>       DerivativeVertical3;
  typedef TLocalFilter< kernel::DerivativeVerticalBias3>   DerivativeVerticalBias3;
  typedef TLocalFilter< kernel::DerivativeVertical2>       DerivativeVertical2;
  typedef TLocalFilter< kernel::DerivativeVerticalBias2>   DerivativeVerticalBias2;
  typedef TLocalFilter< kernel::DerivativeHorizontal3>     DerivativeHorizontal3;
  typedef TLocalFilter< kernel::DerivativeHorizontalBias3> DerivativeHorizontalBias3;
  typedef TLocalFilter< kernel::DerivativeHorizontal2>     DerivativeHorizontal2;
  typedef TLocalFilter< kernel::DerivativeHorizontalBias2> DerivativeHorizontalBias2;
}

} // namespace cimage

#endif
