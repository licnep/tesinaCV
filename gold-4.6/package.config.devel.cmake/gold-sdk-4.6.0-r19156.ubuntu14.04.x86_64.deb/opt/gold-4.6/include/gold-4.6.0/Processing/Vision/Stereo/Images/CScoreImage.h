#ifndef _CSCOREIMAGE_H
#define _CSCOREIMAGE_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2006                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file CScoreImage.h
 * \author Paolo Zani (zani@ce.unipr.it)
 * \date 2007-07-20
 */

#include <Processing/Vision/Stereo/gold_proc_stereo_export.h>
#define TCUSTOMPIXEL_EXPORT GOLD_PROC_STEREO_EXPORT 
#include <Data/CImage/Pixels/TCustomPixel.h>
#undef TCUSTOMPIXEL_EXPORT
#include <Data/CImage/PixelTraits/PixelTraits.h>
#include <Data/CImage/TImage.h>

#include <limits>
#include <stdint.h>

CIMAGE__DECLARE_CUSTOM_PIXEL ( float, Score, GOLD_PROC_STEREO_EXPORT );

/**
 * \class CScoreImage
 * \brief Score Image class
 * This class represents a Score Image
 */
typedef cimage::TImage<Score> CScoreImage;

GOLD_PROC_STEREO_EXPORT extern const Score SCORE_UNKNOWN;

namespace cimage
{
  template<> inline uint8_t PixelTraits<Score>::Channels() { return 1; }
  template<> inline Score PixelTraits<Score>::Min() { return Score ( std::numeric_limits<float>::min() ); }
  template<> inline Score PixelTraits<Score>::Max() { return Score ( std::numeric_limits<float>::max() ); }
  template<> inline Score PixelTraits<Score>::Zero() { return SCORE_UNKNOWN; }
}

#endif

