#ifndef _VEHICLE_TRAJECTORY_H
#define _VEHICLE_TRAJECTORY_H

/** @file VehicleTrajectory.h
  * @brief Function to simulate vehicle movement and trajectory
  * @author Paolo Medici
  **/

#include <vector>
#include <Data/Math/Points.h>

/** approssimazione della funzione dell'integrale Coseno con taylor all'ottavo grado
 * \f$ \int \cos (1/2 \sigma s^2 + \kappa_0 \sigma) ds \f$
 * @note attenzione che non sono le espansioni di taylor delle funzioni di fresnel
 */
class fresnel_cos_taylor8 {
	/// pesi da s a s^8
	double w[8];
	public:
	/** @param a sharpness \f$ \sigma \f$
          * @param b intial curvature \f$ \kappa_0 \f$
          **/
	fresnel_cos_taylor8(double a, double b)
	{
	w[0] = 1.0;	  // s
	w[1] = 0.0;       // s^2
	w[2] = - b*b/6.0; // s^3
	w[3] = - a*b/8.0; // s^4
	w[4] = (b*b*b*b/120.0 - a*a/40.0); // s^5
	w[5] = (a*b*b*b/72.0);	// s^6
	w[6] = (-b*b*b*b*b*b/5040.0 + a*a*b*b / 112.0); // s^7
	w[7] = (-a*b*b*b*b*b/1920.0 + a*a*a*b / 384.0);	// s^8
	}
	/// evaluate the function (14 multiplications)
	double operator()(double s) const
	{
	double a = 0.0;
	double t = s; // da s^1 a s^8
	for(int i =0;i<8;i++)
		{
		a += w[i] * t;
		t *= s;
		}
	return a;
	};
};

/** approssimazione della funzione integrale Seno con taylor al nono grado
 * \f$ \int \sin (1/2 \sigma s^2 + \kappa_0 \sigma) ds \f$
 * @note attenzione che non sono le espansioni di taylor delle funzioni di fresnel
 */
class fresnel_sin_taylor9 {
	/// pesi da s^2 a s^9
	double w[8];
	public:
	/** @param a sharpness \f$ \sigma \f$
          * @param b intial curvature \f$ \kappa_0 \f$
          **/
	fresnel_sin_taylor9(double a, double b)
	{
	w[0] = b/2.0;	  	// s^2
	w[1] = a/6.0;       	// s^3
	w[2] = - b*b*b/24.0; // s^4
	w[3] = - a*b*b/20.0; // s^5
	w[4] = b*b*b*b*b/720.0 - a*a*b/48.0;	// s^6
	w[5] = a*b*b*b*b/336.0 - a*a*a/336.0;	// s^7
	w[6] = - b*b*b*b*b*b*b / 40320.0 + a*a*b*b*b / 384.0;	// s^8
	w[7] = - a*b*b*b*b*b*b / 12960.0 + a*a*a*b*b / 864.0;   // s^9
	}
	/// evaluate the function (15 multiplications)
	double operator()(double s) const
	{
	double a = 0.0;
	double t = s*s; // da s^2 a s^9
	for(int i =0;i<8;i++)
		{
		a += w[i] * t;
		t *= s;
		}
	return a;
	};
};

/** Traiettoria clotoide approssimata usando taylor
  * @note the measure unit can be both meters and seconds (the important is to not mix)
  **/
class clothoid_taylor {
	double M[4];	/// Rototraslation matrix
	fresnel_cos_taylor8 x;
	fresnel_sin_taylor9 y;
	double m_theta0, m_kappa0, m_sharpness;
	public:
	/** 
	     @param theta0 initial angle (partial implemented)
	     @param kappa0 initial curvature (rad/x)
	     @param sharpness sharpness (rad/x^2)
          */
	clothoid_taylor(double theta0, double kappa0, double sharpness) : x(sharpness,kappa0), y(sharpness,kappa0), m_theta0(theta0), m_kappa0(kappa0), m_sharpness(sharpness) { }

	/** evaluate the theta angle at @a s  */
	double theta(double s) const { return m_theta0 + (m_kappa0 + m_sharpness * s) * s; }
	/** evaluate the curvature (rad/x) */
	double curvature(double s) const { return m_kappa0 + m_sharpness * s;}
	/// Evaluate the function at @a s
	math::Point2d operator() (double s) const
	{
	// manca la rotazione per theta0
	return math::Point2d(x(s), y(s));
	}
};

/// clotoide non approssimata
/// @note potrebbe essere molto lenta
class clothoid {
	double M[4];	/// Rototraslation matrix
	double m_theta0, m_kappa0, m_sharpness;
	double A,B,C,D;
	double BC, BS;
	double c0,s0;
	public:
	/**
	     @param theta0 initial angle (partial implemented)
	     @param kappa0 initial curvature (rad/x)
	     @param sharpness sharpness (rad/x^2)
	 */
	clothoid(double theta0, double kappa0, double sharpness);
	/** evaluate the theta angle at @a s  */
	double theta(double s) const { return m_theta0 + (m_kappa0 + m_sharpness * s) * s; }
	/** evaluate the curvature (rad/x) */
	double curvature(double s) const { return m_kappa0 + m_sharpness * s;}
	/// Evaluate the function at @a s
	math::Point2d operator() (double s) const;
};

////////////////////////

/** Traiettoria circolare
  * @note the measure unit can be both meters and seconds (the important is to not mix)
  **/
class circular {
	/// initial angle
	double m_theta0;
	/// circumference curvature
	double m_k;
	// precalc
	double m_c0, m_s0;
	bool m_straight;
	public:

	/** @param theta0 initial angle (rad)
	  * @param k curvature (rad/x)
 	  */
	circular(double theta0, double kappa) : m_theta0(theta0), m_k(kappa), m_c0(cos(theta0)), m_s0(sin(theta0))
		{
		// valuto se piu che una circonferenza, e' una retta
		//  la soglia e' da valutare
		m_straight = std::abs(m_k)<0.001;
		}

	/** evaluate the theta angle */
	double theta(double s) const { return m_theta0 + m_k *s; }
	/** evaluate the curvature */
	double curvature(double s) const { return m_k;}
	/// Evaluate the function at @a s
	math::Point2d operator() (double s)	const
	{
	return (m_straight) ? math::Point2d(
		m_c0*s,
		m_s0*s
		) : math::Point2d(
		(sin(m_theta0 + m_k *s) - m_s0 ) / m_k ,
		(m_c0 - cos(m_theta0 + m_k *s) ) / m_k
		);
	}
};

//////////////////////////////////////////////////////////////////////////

/** simulate an incremental trajectory */
class trajectory {
	///////////
	math::Point2d m_p;
	double m_theta;
	double m_k;
	double m_s;
	////////// precalcoli ////////////////
	double m_c0, m_s0;
	bool m_low_curvature;
	public:

	trajectory() : m_p(0.0, 0.0), m_s(0.0) { theta(0.0); curvature(0.0); }

        /** return the distance on curve */
	double distance() const { return m_s; }
	/** set the position */
	void position(const math::Point2d & p) { m_p = p; }
	/** set the orientation */
	void theta(double theta) { m_theta = theta; m_c0 = cos(theta); m_s0 = sin(theta); }
	/** set the curvature */
	void curvature(double k) { m_k = k; m_low_curvature = std::abs(m_k)<0.001; }

	/** return corrent position */
	math::Point2d position() const { return m_p;}
	/** return corrent angle */
	double theta() const { return m_theta; }
	/** return corrent curvature */
	double curvature() const { return m_k; }

	/** advance using a circular trajectory
	  * @param s simulation step
	  */
	void move_const_curvature(double s)
	{
	if(m_low_curvature)
		{
		// straight line
		m_p += math::Point2d(m_c0*s, m_s0*s);
		}
		else
		{
		// curved line
		m_p += math::Point2d(
		(sin(m_theta + m_k * s) - m_s0 ) / m_k ,
		(m_c0 - cos(m_theta + m_k * s) ) / m_k
		);
		}
	// update theta
	theta(m_theta + m_k * s);
	//
	m_s += s;
	}

	/** advance using a circular trajectory
	  * @param s simulation step
	  * @param k new circular curvature (rad/x)
	  */
	void move_const_curvature(double s, double k)
	{
	curvature(k);
	move_const_curvature(s);
	}

	/** advance using a clothoid trajectory
	  * @param s simulation step
	  * @param sharpness sharpness (rad/x^2)
	  */
	void move_const_sharpness(double s, double sharpness)
	{
	fresnel_cos_taylor8 x(sharpness, m_k);
	fresnel_sin_taylor9 y(sharpness, m_k);

	math::Point2d p (x(s), y(s));
	m_p += math::Point2d(
		m_c0 * p.x - m_s0 * p.y,
		m_s0 * p.x + m_c0 * p.y
		);
	// update
	theta(m_theta + 0.5 * sharpness * s * s + m_k * s);
	curvature(m_k + s * sharpness);
	m_s += s;
	}
};

/** simulate the trajectory and record it on a vector */
class trajectory_recorder : public trajectory {
	public:
	std::vector<math::Point2d> data;
	public:
	trajectory_recorder()
	{
	data.push_back(position());
	}

	/** simulate a step @a s */
	void move_const_curvature(double s)
	{
	trajectory::move_const_curvature(s);
	data.push_back(position());
	}

	/** change the curvature to @a k and simulate a step @a s */
	void move_const_curvature(double s, double k)
	{
	trajectory::move_const_curvature(s, k);
	data.push_back(position());
	}

	/** simulate a movement on a clothoid */
	void move_const_sharpness(double s, double sharpness)
	{
	trajectory::move_const_sharpness(s, sharpness);
	data.push_back(position());
	}
};


#endif
