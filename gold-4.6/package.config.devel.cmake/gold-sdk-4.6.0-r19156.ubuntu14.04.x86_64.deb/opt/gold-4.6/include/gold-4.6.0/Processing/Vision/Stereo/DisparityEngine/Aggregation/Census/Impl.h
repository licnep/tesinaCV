#ifndef _DISPARITYENGINE_CENSUS_IMPL_H
#define _DISPARITYENGINE_CENSUS_IMPL_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file Impl.h
 * \author Paolo Zani (zani@vislab.it) Mirko Felisa (felisa@vislab.it)
 * \date 20010-10-18
 */

#include <Libs/Threads/Parallelize.h>
#include <Processing/Vision/Stereo/Images/CDSI.h>
#include <Processing/Vision/Stereo/Images/CScoreImage.h>
#include <Processing/Vision/Stereo/DisparityEngine/Common/SearchRange.h>
#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/Census/Params.h>
#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/Census/Loops.h>
#include <Processing/Vision/Stereo/DisparityEngine/Common/DisparityEngineData.h>
#include <stdint.h>
#include <boost/preprocessor/iteration/local.hpp>
#include <boost/preprocessor/arithmetic/div.hpp>
#include <boost/preprocessor/selection/min.hpp>
#ifdef __AVX__
#include <immintrin.h>
#endif

#ifndef DE_AGG_CENSUS_MAX_ARITY
#define DE_AGG_CENSUS_MAX_ARITY 7
#endif
#ifndef DE_AGG_CENSUS_MIN_ARITY
#define DE_AGG_CENSUS_MIN_ARITY 3
#endif

#define LOOP(z, j, i) case i *DE_AGG_CENSUS_MAX_ARITY+  j + DE_AGG_CENSUS_MIN_ARITY: Parallelize( boost::bind ( &CoreType::template ComputeDisparity<j+DE_AGG_CENSUS_MIN_ARITY, i, T>, this, left.Buffer(), right.Buffer(), _1, _2 ), Threads_Agg ); break;
#define BOOST_PP_LOCAL_MACRO(N)  BOOST_PP_REPEAT(BOOST_PP_SUB(BOOST_PP_MIN( BOOST_PP_DIV(64,N),DE_AGG_CENSUS_MAX_ARITY),BOOST_PP_SUB(DE_AGG_CENSUS_MIN_ARITY,1)), LOOP, N)
#define BOOST_PP_LOCAL_LIMITS (DE_AGG_CENSUS_MIN_ARITY, DE_AGG_CENSUS_MAX_ARITY)

#include <cstdlib>
#include <vector>

 //#define __DEBUG__

#include <iostream>

#ifdef __DEBUG__
#define __log_debug  std::cout << "[DB] DisparityEngine/Aggregation/Census/Impl.h "  << __LINE__ << " "
#else
#define __log_debug  while(0) std::cout
#endif


namespace disparity
{
    // forward declarations

    namespace agg
    {
        template<typename ResultType_Cost, typename _ResultType_Agg, typename Impl_Agg, uint32_t _Threads_Agg>
        class Census;
    }

    namespace impl
    {
        class Auto;
        class Cpp;
        class SIMD;
    }

    template<typename Cost, typename Aggregation, typename Optimization>
    class Core;

    // actual specialization
    template<typename Cost, typename Optimization, typename ResultType_Cost, typename _ResultType_Agg, typename _Impl_Agg, uint32_t _Threads_Agg>
    class Core<Cost, agg::Census<ResultType_Cost, _ResultType_Agg, _Impl_Agg, _Threads_Agg>, Optimization> : public Optimization, public CensusParams, private virtual DisparityEngineData
    {
        public:

            typedef _ResultType_Agg ResultType_Agg;
            typedef _Impl_Agg Impl_Agg;
            typedef agg::Census<ResultType_Cost, ResultType_Agg, _Impl_Agg, _Threads_Agg> AggregationType;
            typedef Optimization OptimizationType;
            typedef Core<Cost, AggregationType, Optimization> CoreType;

            static const uint32_t Threads_Agg = _Threads_Agg;

        protected:
            
            inline void SetDimensions(uint32_t& width, uint32_t& height){}

            template<typename T>
            inline void Run ( const cimage::TImage<T>& left, const cimage::TImage<T>& right, const cimage::CImageMono8& mask)
            {
                Optimization::Init(m_winWidth * m_winHeight);

                m_pMask = mask.Area() ? mask.Buffer() : NULL;

                int sum = 0;
                for ( unsigned int i = m_dsiYMin; i < m_dsiYMax; ++i )
                    sum += std::max ( m_searchRanges[i].second - m_searchRanges[i].first + 1, 1 );
                sum/=Threads_Agg;
                      
                m_threadRange[0] = m_dsiYMin;
                int acc = 0, th = sum, j = 1;
                 for ( unsigned int i = m_dsiYMin; i < m_dsiYMax; ++i )
                {    
                    acc += std::max ( m_searchRanges[i].second - m_searchRanges[i].first + 1, 1 );
                    if (acc > th)
                    {    
                       m_threadRange[j++] = i;
                       th = j * sum;
                    }   
                }
                m_threadRange[Threads_Agg] = m_dsiYMax;

                m_maxDisparityRangeSize = m_dispMax - m_dispMin + 1;

                switch(DE_AGG_CENSUS_MAX_ARITY*m_winHeight+ m_winWidth)
                {               
                  #include BOOST_PP_LOCAL_ITERATE()
                  default: throw(std::invalid_argument( "[EE] DisparityEngine::Run<T>() - unsupported census window size!"));
                }
                Optimization::Finalize();
            }

            template<int w, int h, typename T>
            inline void ComputeDisparity ( const T* left, const T* right, uint32_t threadID, uint32_t threadNum )
            {
                const uint32_t y_min = m_threadRange[threadID]; 
                const uint32_t y_max = m_threadRange[threadID + 1];
                const uint32_t width = m_dsi->W();

                ResultType_Agg pCorrel[m_maxDisparityRangeSize];

                const int size = w * h * sizeof(typename cimage::PixelTraits<T>:: ChannelType) / sizeof(T);
                typename boost::uint_t<size>::least censusLeft[width];

                for(int i = y_min; i < (int)y_max; i++) {

                    int d_min = m_searchRanges[i].first;
                    int d_max = m_searchRanges[i].second;
                    
                    int start = std::max((int)m_dsiXMin - d_min, w / 2);
                    int stop = std::min((int)m_dsiXMax + d_max, (int)width -  (w - 1) / 2 );
                    
                    int stride = i * width;
                    for(int j = start; j < stop; j++)
                        censusLeft[j] = census::pixel_loop<w, h, Impl_Agg>::run(left +  stride + j, width);

                    for(int j = m_dsiXMin; j < (int)m_dsiXMax; j++) {

                        int index = stride + j;
                        int start = std::max(d_min, w / 2 - j);
                        int stop = std::min(d_max, (int)width - 1 - (w / 2) - j);

                        typename boost::uint_t<size>::least r = census::pixel_loop<w, h, Impl_Agg>::run(right + index, width);

                        hamming::pixel_loop< ResultType_Agg, Impl_Agg>::run(pCorrel - m_dispMin, start, stop, censusLeft + j, r);
                        Optimization::Store(pCorrel - m_dispMin, j, i, start, stop, threadID);
                    }
                }
            }

        private:

            const uint8_t* m_pMask;
            int32_t m_maxDisparityRangeSize;
            int m_threadRange[Threads_Agg + 1];
    };

    
    #define BOOST_PP_LOCAL_MACRO(N)  BOOST_PP_REPEAT(BOOST_PP_SUB(BOOST_PP_MIN( BOOST_PP_DIV(64,N),DE_AGG_CENSUS_MAX_ARITY),BOOST_PP_SUB(DE_AGG_CENSUS_MIN_ARITY,1)), LOOP, N)
    #define BOOST_PP_LOCAL_LIMITS (DE_AGG_CENSUS_MIN_ARITY, DE_AGG_CENSUS_MAX_ARITY)  
    
    template<typename Cost, typename ResultType_Cost, typename _ResultType_Agg, typename _Impl_Agg, uint32_t _Threads_Agg  , typename _ResultType_Opt, typename _Impl_Opt, uint32_t _Threads_Opt>
    class Core<Cost, agg::Census<ResultType_Cost, _ResultType_Agg, _Impl_Agg, _Threads_Agg>, opt::SGM<_ResultType_Agg,  _Threads_Agg, _ResultType_Opt, _Impl_Opt, _Threads_Opt>  > : public opt::SGM<_ResultType_Agg,  _Threads_Agg, _ResultType_Opt, _Impl_Opt, _Threads_Opt>, public CensusParams, private virtual DisparityEngineData
    {
        public:

            typedef _ResultType_Agg ResultType_Agg;
            typedef _Impl_Agg Impl_Agg;
            typedef opt::SGM<_ResultType_Agg,  _Threads_Agg, _ResultType_Opt, _Impl_Opt, _Threads_Opt> Optimization;
            typedef agg::Census<ResultType_Cost, ResultType_Agg, _Impl_Agg, _Threads_Agg> AggregationType;
            typedef Core<Cost, AggregationType, Optimization> CoreType;

            static const uint32_t Threads_Agg = _Threads_Agg;
            
            Core() : m_old_downsample_ratio(0) {}

        protected:
            
            inline void SetDimensions(uint32_t& width, uint32_t& height)
            {
                    width /= m_downsampleratio;
                    height /= m_downsampleratio;
            }

            template<typename T>
            inline void Run ( const cimage::TImage<T>& left, const cimage::TImage<T>& right, const cimage::CImageMono8& mask)
            {
                Optimization::Init(m_winWidth * m_winHeight);

                m_pMask = mask.Area() ? mask.Buffer() : NULL;

                int sum = 0;
                for ( unsigned int i = m_srcYMin; i < m_srcYMax; i+=m_downsample_ratio )
                    sum += std::max ( m_searchRanges[i].second - m_searchRanges[i].first + 1, 1 );
                sum/=Threads_Agg;

                m_threadRange[0] = m_srcYMin;
                int acc = 0, th = sum, j = 1;
                 for ( unsigned int i = m_srcYMin; i < m_srcYMax; i+=m_downsample_ratio )
                {
                    acc += std::max ( m_searchRanges[i].second - m_searchRanges[i].first + 1, 1 );
                    if (acc > th)
                    {
                       m_threadRange[j++] = i;
                       th = j * sum;
                    }
                }
               m_threadRange[Threads_Agg] = m_srcYMax;
               m_maxDisparityRangeSize = Optimization::m_max_disparity;  
               
               if(m_oldSearchRanges != m_searchRanges || m_old_w != m_winWidth || m_old_h != m_winHeight ||  m_old_downsample_ratio != m_downsample_ratio || 
                  m_oldSrcXMin != m_srcXMin ||  m_oldSrcXMax != m_srcXMax || m_oldSrcYMin != m_srcYMin ||  m_oldSrcYMax != m_srcYMax)
               {  
                  m_oldSearchRanges = m_searchRanges;
                  m_old_downsample_ratio = m_downsample_ratio;
                  m_old_w = m_winWidth; 
                  m_old_h = m_winHeight;
                  m_oldSrcXMin = m_srcXMin;
                  m_oldSrcXMax = m_srcXMax;
                  m_oldSrcYMin = m_srcYMin;
                  m_oldSrcYMax = m_srcYMax; 
                  m_setBorderCost = true;
               } else
                  m_setBorderCost = false;
               
               switch(DE_AGG_CENSUS_MAX_ARITY*m_winHeight+ m_winWidth)
               {               
                  #include BOOST_PP_LOCAL_ITERATE()
                  default: throw(std::invalid_argument( "[EE] DisparityEngine::Run<T>() - unsupported census window size!"));
               }
               
              Optimization::Finalize();
            }

            template<int w, int h, typename T>
            inline void ComputeDisparity ( const T* left, const T* right, uint32_t threadID, uint32_t threadNum )
            
            {
                const uint32_t y_min = m_threadRange[threadID];
                const uint32_t y_max = m_threadRange[threadID + 1];
                const uint32_t width = m_dsi->W();              
                const uint32_t src_width =  m_downsample_ratio*width;

                ResultType_Agg *pCorrel = Optimization::m_disparityInputCube - m_dispMin;
                const int size = w * h *  sizeof(T) / sizeof(typename cimage::PixelTraits<T>:: ChannelType);
            
                typename boost::uint_t< size>::least censusLeft[src_width];

                for(int i = y_min, dsi_i = y_min/m_downsample_ratio ; i < (int)y_max; i+=m_downsample_ratio, dsi_i++)
                {

                    int d_min = m_searchRanges[i].first;
                    int d_max = m_searchRanges[i].second;
                                     
                    int start = std::max((int)m_srcXMin + d_min, w / 2);
                    int stop = std::min((int)m_srcXMax + d_max, (int)src_width - (w - 1) / 2 );
                    
                    int stride = i * src_width;
                    for(int j = start; j < stop; j++)
                        censusLeft[j] = census::pixel_loop<w, h, Impl_Agg>::run(left +  stride + j, src_width);

                    int index = stride + m_srcXMin;
                    stride =  (dsi_i - m_dsiYMin) * (m_dsiXMax - m_dsiXMin) * m_maxDisparityRangeSize;
                    for(int j = m_srcXMin; j < (int)m_srcXMax; j+=m_downsample_ratio, index+=m_downsample_ratio, stride += m_maxDisparityRangeSize)
                    {

                        int start = std::max(d_min, w / 2 - j);
                        int stop = std::min(d_max, (int)src_width - 1 - (w - 1) / 2 - j);

                        typename boost::uint_t<size>::least r = census::pixel_loop<w, h, Impl_Agg>::run(right + index, src_width);

#ifdef __AVX__
                          _mm256_zeroupper(); //il for successivo usa ymm register e quindi genera una penalità di 100 ms
#endif

                        if(m_setBorderCost)
                          for ( int d = m_dispMin;  d < start; d++ )            
                              pCorrel[stride + d] = std::numeric_limits<ResultType_Agg>::max();
                     
                        hamming::pixel_loop< ResultType_Agg, Impl_Agg>::run (  pCorrel + stride, start, stop, censusLeft + j, r );

//                         if(m_setBorderCost)
//                           for ( int d = stop + 1;  d < m_maxDisparityRangeSize + m_dispMin; d++ )
//                               pCorrel[stride + d] = std::numeric_limits<ResultType_Agg>::max();
//                         else 
//                           for ( int d = stop + 1;  d <= k; d++ )
//                               pCorrel[stride + d] = std::numeric_limits<ResultType_Agg>::max();
                          
                          if(m_setBorderCost)
                          for ( int d = stop + 1;  d <  m_maxDisparityRangeSize + m_dispMin; d++ )
                              pCorrel[stride + d] = std::numeric_limits<ResultType_Agg>::max();      

                    }
                }
            }

        private:

            const uint8_t* m_pMask;
            int32_t m_maxDisparityRangeSize;
            int m_threadRange[Threads_Agg + 1];
            std::vector<SearchRange> m_oldSearchRanges;
            int m_old_downsample_ratio;
            uint32_t m_old_w, m_old_h, m_oldSrcXMin, m_oldSrcXMax, m_oldSrcYMin, m_oldSrcYMax;
            bool m_setBorderCost;
    };

}

#undef __log_debug

#endif
