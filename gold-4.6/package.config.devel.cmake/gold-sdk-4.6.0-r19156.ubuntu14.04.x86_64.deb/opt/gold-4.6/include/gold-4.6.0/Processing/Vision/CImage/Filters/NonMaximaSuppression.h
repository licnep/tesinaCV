#ifndef _NON_MAXIMA_SUPPRESSION_H
#define _NON_MAXIMA_SUPPRESSION_H

// #include <platform.h> // CPU_CORES
#include <boost/thread.hpp>
#include <vector>

/** @file NonMaximaSuppression.h
 * @brief Questo header implementa i metodi di Non Maxima Suppression per individuare massimi e minimi locali per feature
 **/


/** Non Maxima Suppression (senza maschera) 
 * This algorithm find local maxima of a map @a src of geometry @a width x @a height
 *  skipping a border @a margin.
 * Two maxima cannot be near more than @a n and have a value less than a @a threshold
 * @param src an image (int, double, float, etc etc)
 * @param 
 *  @todo MultiThread
 **/
template<class D, class FeatureListType, class Param>
void NonMaximaSuppression(const D *src, FeatureListType &maxima, unsigned int n, unsigned int margin, unsigned int width, unsigned int height, D threshold, Param param, int nThreads = boost::thread::hardware_concurrency() );

/// una NonMaximaNonMinimaSuppression su celle w x h MultiThread
/// escludo un margine intorno dove i descrittori non sarebbero validi
template<class D, class FeatureListType, class Param>
void NonMaximaNonMinimaSuppression(const D *src, uint8_t *mask, FeatureListType &maxima, int n, int margin, int width, int height, D threshold, Param id, int nThreads = boost::thread::hardware_concurrency() );

/// una NonMaximaNonMinimaSuppression su celle w x h MultiThread
/// escludo un margine intorno dove i descrittori non sarebbero validi
template<class D, class FeatureListType, class Param>
void NonMaximaNonMinimaSuppression(const D *src, FeatureListType &maxima, int n, int margin, int width, int height, D threshold, Param param, int nThreads = boost::thread::hardware_concurrency() );

/******************** implementation ***************************************/

namespace detail {
  
/// The internal NMNM class
template<class D, class FeatureListType, class Param>
struct LocalMaximaLocalMinimaWithMask {
    /// The buffer
    const D *m_src;
    /// the margin
    int32_t realmargin;
    /// the (optinal) rejection mask
    uint8_t *mask;
    /// nms step
    int n;
    /// nms margin
    int margin;
    /// stride
    int width;
    /// optional data used by Set Method
    Param id;
    /// threshold
    D threshold;

public:    
    
/// internal NonMaximaNonMinimaSuppression based on Mask
void Process(FeatureListType &maxima, int j0, int j1) const
{
const D * src = m_src + j0 * width;
for(int j=j0;j<j1;j+=n+1)
 {
 for(int i=realmargin;i+n+realmargin<width;i+=n+1)
   {
     // src punta sempre alla riga (j)
     const D *ptr;
     int pi, pj, ni, nj;

      D pval, nval;
      pval = threshold-1;
      nval = -threshold+1;  // TODO: unbiased 
      pi = ni = i;
      pj = nj = j;
      ptr = src; // ptr deve puntare sempre alla riga di inizio, con i invece relativo al tipo di elaborazione
    // per ogni cella n x n cerco il massimo assoluto
    for(int j2=j;j2<=j+n;++j2)
    {
     for(int i2=i;i2<=i+n;++i2)
     {
       D cval = ptr[i2];
       // il punto deve essere maggiore o uguale al precedente per essere valido
       // POSITIVI
       if( cval>pval) {
            pi   = i2;
            pj   = j2;
            pval = cval;
        }
       // NEGATIVI
       if( cval<nval) {
            ni   = i2;
            nj   = j2;
            nval = cval;
        }
        
     }
       ptr += width;
    }
    
     if(pval<threshold)
       goto pfailed;
    
      // siccome src punta sempre a j devo togliere j 
      ptr = src + (pj - n - j ) * width;
     for (int32_t j2=pj-n; j2<=pj+n; j2++) {
      for (int32_t i2=pi-n; i2<=pi+n; i2++) {
          if (i2<i || i2>i+n || j2<j || j2>j+n) {
            D cval = ptr[i2];
            if (cval>pval)
              goto pfailed;
          }
        }
        ptr += width;
      }
    
        // POSITIVI
    if( (pval>=threshold) && (mask[pi + pj * width] == 0))
    {
      mask[pi + pj * width] = 1; 
      typename FeatureListType::value_type p;
      p.Set(pi, pj, pval, id);
      maxima.push_back( p );
    }

      pfailed:
      
     if(nval>-threshold)
       goto nfailed;

     ptr = src + (nj - n - j ) * width;
     for (int32_t j2=nj-n; j2<=nj+n; j2++) {
      for (int32_t i2=ni-n; i2<=ni+n; i2++) {
          if (i2<i || i2>i+n || j2<j || j2>j+n) {
            D cval = ptr[i2];
            if (cval<nval)
              goto nfailed;
          }
        }
        ptr += width;
      }


        // NEGATIVI
    if((nval<=-threshold) &&( mask[ni + nj * width] == 0))
    {
      mask[ni + nj * width] = 1; // TODO
      typename FeatureListType::value_type p;
      p.Set(ni, nj, -nval, id+1);
      maxima.push_back( p );      
    }

      nfailed:;
      
      
    
   }
  src+= (width * (n+1));
 }
}

};

/// The internal NMNM class
template<class D, class FeatureListType, class Param>
struct LocalMaximaLocalMinima {
    /// The buffer
    const D *m_src;
    /// the margin
    int32_t realmargin;
    /// nms step
    int n;
    /// nms margin
    int margin;
    /// stride
    int width;
    /// optional data used by Set Method
    Param id;
    /// threshold
    D threshold;

public:    
/// internal NonMaximaNonMinima Suppression 
void Process(FeatureListType &maxima, int j0, int j1) const
{
const D * src = m_src + j0 * width;
for(int j=j0;j<j1;j+=n+1)
 {
 for(int i=realmargin;i+n+realmargin<width;i+=n+1)
   {
     // src punta sempre alla riga (j)
     const D *ptr;
     int pi, pj, ni, nj;

      D pval, nval;
      pval = threshold-1;
      nval = -threshold+1; // TODO: unbiased 
      pi = ni = i;
      pj = nj = j;
      ptr = src; // ptr deve puntare sempre alla riga di inizio, con i invece relativo al tipo di elaborazione
    // per ogni cella n x n cerco il massimo assoluto
    for(int j2=j;j2<=j+n;++j2)
    {
     for(int i2=i;i2<=i+n;++i2)
     {
       D cval = ptr[i2];
       // il punto deve essere maggiore o uguale al precedente per essere valido
       // POSITIVI
       if( cval>pval) {
            pi   = i2;
            pj   = j2;
            pval = cval;
        }
       // NEGATIVI
       if( cval<nval) {
            ni   = i2;
            nj   = j2;
            nval = cval;
        }
        
     }
       ptr += width;
    }
    
     if(pval<threshold)
       goto pfailed;
    
      // siccome src punta sempre a j devo togliere j 
      ptr = src + (pj - n - j ) * width;
     for (int32_t j2=pj-n; j2<=pj+n; j2++) {
      for (int32_t i2=pi-n; i2<=pi+n; i2++) {
          if (i2<i || i2>i+n || j2<j || j2>j+n) {
            D cval = ptr[i2];
            if (cval>pval)
              goto pfailed;
          }
        }
        ptr += width;
      }
    
        // POSITIVI
    if(pval>=threshold)
    {
      typename FeatureListType::value_type p;
      p.Set(pi, pj, pval, id);
      maxima.push_back( p );      
    }

      pfailed:
      
     if(nval>-threshold)
       goto nfailed;

     ptr = src + (nj - n - j ) * width;
     for (int32_t j2=nj-n; j2<=nj+n; j2++) {
      for (int32_t i2=ni-n; i2<=ni+n; i2++) {
          if (i2<i || i2>i+n || j2<j || j2>j+n) {
            D cval = ptr[i2];
            if (cval<nval)
              goto nfailed;
          }
        }
        ptr += width;
      }


        // NEGATIVI
    if(nval<=-threshold)
    {
      typename FeatureListType::value_type p;
      p.Set(ni, nj, -nval, id+1);
      maxima.push_back( p );      
    }

      nfailed:;
      
      
    
   }
  src+= (width * (n+1));
 }
}

};

/// The internal NMNM class
template<class D, class FeatureListType, class Param>
struct LocalMaxima {
    /// The buffer
    const D *m_src;
    /// the margin
    int32_t realmargin;
    /// nms step
    int n;
    /// nms margin
    int margin;
    /// stride
    int width;
    /// optional data used by Set Method
    Param id;
    /// threshold
    D threshold;
public:
/// Internal Non Maxima Suppression
void Process(FeatureListType &maxima, int j0, int j1) const
{
const D * src = m_src + j0 * width;
typedef typename FeatureListType::value_type FeatureType;
for(int j=j0;j<j1;j+=n+1)
 {
 for(int i=realmargin;i+n+realmargin<width;i+=n+1)
   {
     // src punta sempre alla riga (j)
     const D *ptr;
     int pi, pj;
      D pval;
      
      pval = threshold-1;
      pi = i;
      pj = j;
      ptr = src; // ptr deve puntare sempre alla riga di inizio, con i invece relativo al tipo di elaborazione
    // per ogni cella n x n cerco il massimo assoluto
    for(int j2=j;j2<=j+(int)n;++j2)
    {
     for(int i2=i;i2<=i+(int)n;++i2)
     {
       D cval = ptr[i2];
       // il punto deve essere maggiore o uguale al precedente per essere valido
       // POSITIVI
       if( cval>pval) {
            pi   = i2;
            pj   = j2;
            pval = cval;
        }
     }
       ptr += width;
    }
    
     if(pval<threshold)
       goto pfailed;
    
      // siccome src punta sempre a j devo togliere j 
      ptr = src + (pj - int(n) - j ) * (long) width;
     for (int32_t j2=pj-(int)n; j2<=pj+(int)n; j2++) {
      for (int32_t i2=pi-(int)n; i2<=pi+(int)n; i2++) {
          if (i2<i || i2>i+(int)n || j2<j || j2>j+(int)n) {
            D cval = ptr[i2];
            if (cval>pval)
              goto pfailed;
          }
        }
        ptr += width;
      }
    
        // POSITIVI
    if(pval>=threshold)
    {
      FeatureType p;
      p.Set(pi, pj, pval, id);
      maxima.push_back( p );
    }

      pfailed: ;
      
   }
  src+= (width * (n+1));
 }
}

};

} //detail


// multithread implementation:

template<class D, class FeatureListType, class Param>
void NonMaximaSuppression(const D *src, FeatureListType &maxima, unsigned int n, unsigned int margin, unsigned int width, unsigned int height, D threshold, Param param, int nThreads )
{
  detail::LocalMaxima<D, FeatureListType, Param> nms;
  // TODO: assert margin >= n
  nms.m_src = src;
  nms.n = n;
  nms.width = width;
  nms.threshold = threshold;
  nms.id = param;
  nms.realmargin = std::max(margin, n);

  if(nThreads>1)
    {
    boost::thread_group thread_pool_;
    FeatureListType *outputs = new FeatureListType[nThreads];
    
  // divido la mappa in celle di (n+1) x (n+1)
  
    int32_t active = (height - n - nms.realmargin - nms.realmargin) / (n+1);

    for(int k=0;k<nThreads;++k)
      {
      uint32_t k0 = (active * k) / nThreads;	 // prima riga da assegnare a questo core
      uint32_t k1 = (active * (k+1) ) / nThreads; // ultima riga (non compresa) da assegnare a questo core
      thread_pool_.create_thread(	boost::bind(  &detail::LocalMaxima<D, FeatureListType, Param>::Process,
				  boost::cref(&nms), boost::ref(outputs[k]), (int) nms.realmargin + k0 * (n+1), (int) nms.realmargin + k1 * (n+1)));
      }
    
    thread_pool_.join_all();
    
    for(int k =0;k<nThreads;++k)
      {
      maxima.insert(maxima.end(), outputs[k].begin(),outputs[k].end());
      }
    
    delete [] outputs;
    }
    else
    {
      nms.Process(maxima, nms.realmargin, height - nms.realmargin);
    }
}    

template<class D, class FeatureListType, class Param>
void NonMaximaNonMinimaSuppression(const D *src, uint8_t *mask, FeatureListType &maxima, int n, int margin, int width, int height, D threshold, Param id, int nThreads)
{
  detail::LocalMaximaLocalMinimaWithMask<D, FeatureListType, Param> nms;
    
  // TODO: assert margin >= n
  nms.m_src = src;
  nms.mask = mask;
  nms.n = n;
  nms.width = width;
  nms.threshold = threshold;
  nms.id = id;
  nms.realmargin = std::max(margin, n);

  if(nThreads>1)
    {
    boost::thread_group thread_pool_;
    FeatureListType *outputs = new FeatureListType [nThreads];
    
  // divido la mappa in celle di (n+1) x (n+1)
  
    int32_t active = (height - n - nms.realmargin - nms.realmargin) / (n+1);

    for(int k=0;k<nThreads;++k)
    {
      uint32_t k0 = (active * k) / nThreads;	 // prima riga da assegnare a questo core
      uint32_t k1 = (active * (k+1) ) / nThreads; // ultima riga (non compresa) da assegnare a questo core
      thread_pool_.create_thread(	boost::bind(  &detail::LocalMaximaLocalMinimaWithMask<D, FeatureListType, Param>::Process,
				  boost::cref(&nms), boost::ref(outputs[k]), (int) nms.realmargin + k0 * (n+1), (int) nms.realmargin + k1 * (n+1)));
    }
    
    thread_pool_.join_all();
    
    for(int k =0;k<nThreads;++k)
    {
      maxima.insert(maxima.end(), outputs[k].begin(),outputs[k].end());
    }
    
    delete [] outputs;
    }
  else
  {
   nms.Process(maxima, nms.realmargin, height - nms.realmargin);
  }
}

template<class D, class FeatureListType, class Param>
void NonMaximaNonMinimaSuppression(const D *src, FeatureListType &maxima, int n, int margin, int width, int height, D threshold, Param param, int nThreads)
{
  detail::LocalMaxima<D, FeatureListType, Param> nms;
  // TODO: assert margin >= n
  nms.m_src = src;
//  nms.mask = 0;
  nms.n = n;
  nms.width = width;
  nms.threshold = threshold;
  nms.id = param;
  nms.realmargin = std::max(margin, n);

  if(nThreads>1)
    {
    boost::thread_group thread_pool_;
    FeatureListType *outputs = new FeatureListType[nThreads];
    
  // divido la mappa in celle di (n+1) x (n+1)
  
    int32_t active = (height - n - nms.realmargin - nms.realmargin) / (n+1);

  for(int k=0;k<nThreads;++k)
    {
      uint32_t k0 = (active * k) / nThreads;	 // prima riga da assegnare a questo core
      uint32_t k1 = (active * (k+1) ) / nThreads; // ultima riga (non compresa) da assegnare a questo core
      thread_pool_.create_thread(	boost::bind(  &detail::LocalMaxima<D, FeatureListType, Param>::Process,
				  boost::cref(&nms), boost::ref(outputs[k]), (int) nms.realmargin + k0 * (n+1), (int) nms.realmargin + k1 * (n+1)));
    }
    
    thread_pool_.join_all();
    
    for(int k =0;k<nThreads;++k)
    {
      maxima.insert(maxima.end(), outputs[k].begin(),outputs[k].end());
    }
    
    delete [] outputs;
    }
    else
    {
      nms.Process(maxima, nms.realmargin, height - nms.realmargin);
    }
}


#endif
