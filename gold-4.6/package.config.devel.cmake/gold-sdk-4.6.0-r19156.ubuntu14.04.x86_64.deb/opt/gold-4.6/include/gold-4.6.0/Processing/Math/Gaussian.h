#ifndef GAUSSIAN
#define GAUSSIAN

#include <Processing/Math/gold_proc_math_export.h>

/*******************************************************************************
* PROCEDURE: make_gaussian_kernel
* PURPOSE: Create a one dimensional gaussian kernel.
* NAME: Mike Heath
* DATE: 2/15/96
*******************************************************************************/

namespace math
{

GOLD_PROC_MATH_EXPORT void make_gaussian_kernel(float sigma, float **kernel, int *windowsize);

/** make_1d_gaussian_filter
    crea un filtro passa basso gaussiano di varianza sigma (normalizzato) **/
GOLD_PROC_MATH_EXPORT void make_1d_gaussian_filter(float *filter, float sigma, unsigned int size);

/** make_2d_gaussian_filter
  * crea un filtro gaussiano bidimensionale di varianza sigma (normalizzato)
  *
  **/
GOLD_PROC_MATH_EXPORT void make_2d_gaussian_filter(float *filter, float sigma, unsigned int size);

/** make a 1d gaussian first order derivative filter
  **/
GOLD_PROC_MATH_EXPORT void make_1d_gaussian_first_order_derivative_filter(float *filter, float sigma, unsigned int size);

/** make a 1d gaussian second order derivative filter
  **/
GOLD_PROC_MATH_EXPORT void make_1d_gaussian_second_order_derivative_filter(float *filter, float sigma, unsigned int size);
 
}

#endif