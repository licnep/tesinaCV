#ifndef _SCHARR_FILTER_H
#define _SCHARR_FILTER_H

#include <stdint.h>
#include <Data/CImage/PixelTraits/PixelTraits.h>
#include "ConvolutionKernel.h"
#include "FilterModifier.h"
#include "TLocalFilter.h"

namespace cimage {
  
namespace kernel {  
  
/**
 * \brief Implementa il calcolo di una maschera w x h verticale di Scharr
*/
template<uint32_t w, uint32_t h>
class ScharrVertical;

/**
 * \brief Implementa il calcolo di una maschera 3x3 verticale di Scharr
*/
template<>
class ScharrVertical<3, 3>: public TConvolutionKernel3x3<-3,0,3, -10,0,10, -3,0,3>
{
};

/**
 * \brief Implementa il calcolo di una maschera w x h orizzontale di Scharr
*/
template<uint32_t w, uint32_t h>
class ScharrHorizontal;

/**
 * \brief Implementa il calcolo di una maschera 3x3 orizzontale di Scharr
*/
template<>
class ScharrHorizontal<3, 3>: public TConvolutionKernel3x3<-3,-10,-3, 0,0,0, 3,10,3>
{
};

/******************************** Filtri Comuni ***************************************/

/** Scharr verticale con segno **/
typedef filter::Div<ScharrVertical<3,3>, 32> ScharrVertical3x3;
/** Scharr verticale senza segno
* \code
* TLocalFilter< ScharrVerticalBias3x3 > filter;
* filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef filter::Bias<ScharrVertical3x3, 127> ScharrVerticalBias3x3;

/** Scharr verticale senza segno **/
typedef filter::Div<filter::Abs< ScharrVertical<3,3> >, 16> ScharrVerticalAbs3x3;

/** Scharr orizzontale con segno **/
typedef filter::Div<ScharrHorizontal<3,3>, 32> ScharrHorizontal3x3;
/** Scharr orizzontale senza segno con bias
* \code
* TLocalFilter< ScharrHorizontalBias3x3 > filter;
* filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef filter::Bias<ScharrHorizontal3x3, 127> ScharrHorizontalBias3x3;

/** Scharr orizzontale senza segno in valore assoluto **/
typedef filter::Div< filter::Abs< ScharrHorizontal<3,3> >, 16> ScharrHorizontalAbs3x3;

/** filtro trova edge usando Scharr
* \code
* TLocalFilter< ScharrEdges3x3 > filter;
* filter(m_inputImageMono, m_outputImageMono);
* \endcode
**/
typedef filter::Div< filter::Max2< filter::Abs< ScharrVertical<3,3> > , filter::Abs< ScharrVertical<3,3> > >, 16> ScharrEdges3x3;

} // namespace kernel

/******************* Filtri ********************************************/

namespace filter {
  
/** Scharr verticale con segno **/
typedef TLocalFilter<kernel::ScharrVertical3x3>       ScharrVertical3x3;

/** Scharr verticale senza segno con bias **/
typedef TLocalFilter<kernel::ScharrVerticalBias3x3>   ScharrVerticalBias3x3;

/** Scharr verticale senza segno in valore assoluto **/
typedef TLocalFilter<kernel::ScharrVerticalAbs3x3>    ScharrVerticalAbs3x3;

/** Scharr orizzontale con segnp */
typedef TLocalFilter<kernel::ScharrHorizontal3x3>     ScharrHorizontal3x3;

/** Scharr orizzontale senza segno con bias **/
typedef TLocalFilter<kernel::ScharrHorizontalBias3x3> ScharrHorizontalBias3x3;

/** Scharr orizzontale senza segno in valore assoluto **/
typedef TLocalFilter<kernel::ScharrHorizontalAbs3x3>  ScharrHorizontalAbs3x3;

/** filtro trova edge usando Scharr */
typedef TLocalFilter<kernel::ScharrEdges3x3>          ScharrEdges3x3;

}

} // namespace cimage

#endif
