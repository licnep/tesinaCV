#ifndef _DELAUNAY_HXX
#define _DELAUNAY_HXX

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * @file Delaunay.hxx
 * @author Mirko Felisa (felisa@vislab.it)
 * @date 2012-04-16
 */

#include<Processing/Tessellation/DelaunayTriangulation.h>
#include<Processing/Tessellation/detail/Sort.h>
#include<Processing/Tessellation/detail/Predicates.h>
#include<algorithm>
#include<boost/thread/thread.hpp>

namespace tessellation
{

    template<typename T>
    template<typename U>
    void  DelaunayTriangulation<T>::GenerateVector(const U& v)
    {
        m_pvector.clear();
        for(typename U::iterator it = const_cast<U>(&v).begin(); it < v.end(); ++it)
            m_pvector.push_back(&*it);
    }

    template<typename T>
    template<typename A>
    inline void  DelaunayTriangulation<T>::GenerateVector(const std::vector<T, A>& v)
    {
        m_pvector.resize(v.size());
        T* p = & (*const_cast<std::vector<T, A>*>(&v)) [0];
        for(int i = 0, end = v.size(); i < end; ++i)
            m_pvector[i] = p++;
    }


    template<typename T>
    template< template<typename, typename> class Container, typename Allocator>
    TriangleHull<T>&  DelaunayTriangulation<T>::operator()(const Container<T, Allocator>& v, Cut::type  s, int thread)
    {
        if(v.size() < 2)
        {
            m_hull.Data().resize(0);
            m_hull.Cursor(HullCursorType());
            return m_hull;
        }

        hullsize = 0;
        m_hull.Data().resize(2 * v.size() - 2);
        GenerateVector(v);
        HullCursorType start, end;
        m_sort = s;
        switch(s)
        {
            case Cut::XY:
                detail::xy_alternate_sort(m_pvector.begin(), m_pvector.end(), thread);
                DivConq(&m_pvector[0], &m_pvector[0] + v.size(), start, end, 0, thread);
                break;

            case Cut::X:
                std::sort(m_pvector.begin(), m_pvector.end(), detail::cmp_x<T*>);
                DivConq(&m_pvector[0], &m_pvector[0] + v.size(), start, end, 0, thread);
                break;

            case Cut::Y:
                std::sort(m_pvector.begin(), m_pvector.end(), detail::cmp_y<T*>);
                DivConq(&m_pvector[0], &m_pvector[0] + v.size(), start, end, 1, thread);
                break;
        };

        m_hull.Cursor(start);
        return m_hull;

    }


    template<typename T>
    void  DelaunayTriangulation<T>::MergeHulls(HullCursorType& far_left, HullCursorType& inner_left, HullCursorType& inner_right, HullCursorType& far_right, int axis)
    {
        HullCursorType left_cand, right_cand;
        HullCursorType base_edge;
        HullCursorType next_edge;
        HullCursorType side_casing, top_casing, outer_casing;
        HullCursorType check_edge;

        T* far_left_pt, * far_right_pt;
        T* far_left_apex, *far_right_apex;
        T* lower_left, *lower_right;
        T* upper_left, *upper_right;
        T* next_apex;
        T* check_vertex;
        int changemade;
        int badedge;
        int left_finished, right_finished;

        T* inner_left_dest = inner_left.Destination();
        T* inner_left_apex = inner_left.Apex();
        T* inner_right_org = inner_right.Origin();
        T* inner_right_apex = inner_right.Apex();

        // horizontal cuts.
        if(axis == 1)
        {
            far_left_pt = far_left.Origin();
            far_left_apex = far_left.Apex();
            far_right_pt = far_right.Destination();
            far_right_apex = far_right.Apex();
            while(far_left_apex->y < far_left_pt->y)
            {
                far_left.Rotate();
                far_left.Back();
                far_left_pt = far_left_apex;
                far_left_apex = far_left.Apex();
            }

            Back(inner_left, check_edge);
            check_vertex = check_edge.Apex();

            while(check_vertex->y > inner_left_dest->y)
            {
                Rotate(check_edge, inner_left);
                inner_left_apex = inner_left_dest;
                inner_left_dest = check_vertex;
                Back(inner_left, check_edge);
                check_vertex = check_edge.Apex();
            }
            while(inner_right_apex->y < inner_right_org->y)
            {
                inner_right.Rotate();
                inner_right.Back();
                inner_right_org = inner_right_apex;
                inner_right_apex = inner_right.Apex();
            }

            Back(far_right, check_edge);
            check_vertex = check_edge.Apex();
            while(check_vertex->y > far_right_pt->y)
            {
                Rotate(check_edge, far_right);
                far_right_apex = far_right_pt;
                far_right_pt = check_vertex;
                Back(far_right, check_edge);
                check_vertex = check_edge.Apex();
            }
        }
        //Compute the lower common tangent of both hulls.
        do
        {
            changemade = 0;
            // Make inner_left_dest the "bottommost" vertex of the left hull.
            if(detail::Counterclockwise(inner_left_dest, inner_left_apex, inner_right_org) > 0)
            {
                inner_left.InverseRotate();
                inner_left.Back();
                inner_left_dest = inner_left_apex;
                inner_left_apex = inner_left.Apex();
                changemade = 1;
            }
            // Make inner_right_org the "bottommost" vertex of the right hull.
            if(detail::Counterclockwise(inner_right_apex, inner_right_org, inner_left_dest) > 0)
            {
                inner_right.Rotate();
                inner_right.Back();
                inner_right_org = inner_right_apex;
                inner_right_apex = inner_right.Apex();
                changemade = 1;
            }
        }
        while(changemade);

        Back(inner_left, left_cand);
        Back(inner_right, right_cand);
        base_edge = HullCursorType(&m_hull.Data()[tess_postincr(hullsize)], 0);

        // Connect the left and right triangulations.
        Join(base_edge, inner_left);
        base_edge.Rotate();
        Join(base_edge, inner_right);
        base_edge.Rotate();
        base_edge.Origin(inner_right_org);
        base_edge.Destination(inner_left_dest);
        base_edge.Apex(NULL);

        far_left_pt = far_left.Origin();
        if(inner_left_dest == far_left_pt)
            Rotate(base_edge, far_left);

        far_right_pt = far_right.Destination();
        if(inner_right_org == far_right_pt)
            InverseRotate(base_edge, far_right);
        lower_left = inner_left_dest;
        lower_right = inner_right_org;
        upper_left = left_cand.Apex();
        upper_right = right_cand.Apex();
        //This is the merge loop.
        while(1)
        {
            left_finished = detail::Counterclockwise(upper_left, lower_left, lower_right) <= 0;
            right_finished = detail::Counterclockwise(upper_right, lower_left, lower_right) <= 0;
            if(left_finished && right_finished)
            {
                next_edge = HullCursorType(&m_hull.Data()[tess_postincr(hullsize)], 0);
                next_edge.Origin(lower_left);
                next_edge.Destination(lower_right);
                next_edge.Apex(NULL);
                Join(next_edge, base_edge);
                next_edge.Rotate();
                Join(next_edge, right_cand);
                next_edge.Rotate();
                Join(next_edge, left_cand);

                // horizontal cuts
                if(axis == 1)
                {
                    far_left_pt = far_left.Origin();
                    far_left_apex = far_left.Apex();
                    far_right_pt = far_right.Destination();
                    far_right_apex = far_right.Apex();
                    Back(far_left, check_edge);
                    check_vertex = check_edge.Apex();
                    while(check_vertex->x < far_left_pt->x)
                    {
                        InverseRotate(check_edge, far_left);
                        far_left_apex = far_left_pt;
                        far_left_pt = check_vertex;
                        Back(far_left, check_edge);
                        check_vertex = check_edge.Apex();
                    }
                    while(far_right_apex->x > far_right_pt->x)
                    {
                        far_right.InverseRotate();
                        far_right.Back();
                        far_right_pt = far_right_apex;
                        far_right_apex = far_right.Apex();
                    }
                }
                return;
            }
            if(!left_finished)
            {
                InverseRotate(left_cand, next_edge);
                next_edge.Back();
                next_apex = next_edge.Apex();
                if(next_apex)
                {
                    badedge = detail::Incircle(lower_left, lower_right, upper_left, next_apex);
                    while(badedge)
                    {
                        next_edge.Rotate();
                        Back(next_edge, top_casing);
                        next_edge.Rotate();
                        Back(next_edge, side_casing);
                        Join(next_edge, top_casing);
                        Join(left_cand, side_casing);
                        left_cand.Rotate();
                        Back(left_cand, outer_casing);
                        next_edge.InverseRotate();
                        Join(next_edge, outer_casing);
                        left_cand.Origin(lower_left);
                        left_cand.Destination(NULL);
                        left_cand.Apex(next_apex);

                        next_edge.Origin(NULL);
                        next_edge.Destination(upper_left);
                        next_edge.Apex(next_apex);
                        upper_left = next_apex;
                        next_edge = side_casing;
                        next_apex = next_edge.Apex();
                        badedge = (next_apex) ? detail::Incircle(lower_left, lower_right, upper_left, next_apex) : 0;
                    }
                }
            }
            if(!right_finished)
            {
                Rotate(right_cand, next_edge);
                next_edge.Back();
                next_apex = next_edge.Apex();
                if(next_apex)
                {
                    badedge = detail::Incircle(lower_left, lower_right, upper_right, next_apex);
                    while(badedge)
                    {
                        next_edge.InverseRotate();
                        Back(next_edge, top_casing);
                        next_edge.InverseRotate();
                        Back(next_edge, side_casing);
                        Join(next_edge, top_casing);
                        Join(right_cand, side_casing);
                        right_cand.InverseRotate();
                        Back(right_cand, outer_casing);
                        next_edge.Rotate();
                        Join(next_edge, outer_casing);
                        right_cand.Origin(NULL);
                        right_cand.Destination(lower_right);
                        right_cand.Apex(next_apex);
                        next_edge.Origin(upper_right);
                        next_edge.Destination(NULL);
                        next_edge.Apex(next_apex);
                        upper_right = next_apex;
                        next_edge = side_casing;
                        next_apex = next_edge.Apex();
                        badedge = (next_apex) ? detail::Incircle(lower_left, lower_right, upper_right, next_apex) : 0;
                    }
                }
            }
            //The next cross edge is to be connected to either left_cand.Destination or right_cand.Destination
            //both are valid, then choose the appropriate one using the InCircle test
            if(left_finished || (!right_finished && (detail::Incircle(upper_left, lower_left, lower_right, upper_right))))
            {
                //Add cross edge base1 from lower_left to upper_right
                Join(base_edge, right_cand);
                InverseRotate(right_cand, base_edge);
                base_edge.Destination(lower_left);
                lower_right = upper_right;
                Back(base_edge, right_cand);
                upper_right = right_cand.Apex();
            }
            else
            {
                //Add cross edge base1 from upper_right to lower_left
                Join(base_edge, left_cand);
                Rotate(left_cand, base_edge);
                base_edge.Origin(lower_right);
                lower_left = upper_left;
                Back(base_edge, left_cand);
                upper_left = left_cand.Apex();
            }
        }
    }

    template< typename T>
    void DelaunayTriangulation<T>::DivConq(T** it, T** end, HullCursorType& tri_begin, HullCursorType& tri_end, int axis, int thread)
    {
        HullCursorType mid_tri, tri1, tri2, tri3;
        int size = end - it;

        if(size == 2)
        {
            // The triangulation of two vertices is an edge.
            //  An edge is  represented by two bounding triangles.
            tri_begin = HullCursorType(&m_hull.Data()[tess_postincr(hullsize)], 0);
            tri_begin.Origin(*it);
            tri_begin.Destination(it[1]);
            tri_begin.Apex(NULL);
            tri_end = HullCursorType(&m_hull.Data()[tess_postincr(hullsize)], 0);
            tri_end.Origin(it[1]);
            tri_end.Destination(*it);
            tri_end.Apex(NULL);
            Join(tri_begin, tri_end);
            tri_begin.InverseRotate();
            tri_end.Rotate();
            Join(tri_begin, tri_end);
            tri_begin.InverseRotate();
            tri_end.Rotate();
            Join(tri_begin, tri_end);
            //setto tri_begin a it[0]
            InverseRotate(tri_end, tri_begin);
        }
        else
            if(size == 3)
            {
                // The triangulation of three vertices is either a triangle (with
                //   three bounding triangles) or two edges (with four bounding
                //   triangles).
                mid_tri = HullCursorType(&m_hull.Data()[tess_postincr(hullsize)], 0);
                tri1 = HullCursorType(&m_hull.Data()[tess_postincr(hullsize)], 0);
                tri2 = HullCursorType(&m_hull.Data()[tess_postincr(hullsize)], 0);
                tri3 = HullCursorType(&m_hull.Data()[tess_postincr(hullsize)], 0);
                tri1.Apex(NULL);
                tri2.Apex(NULL);
                tri3.Apex(NULL);
                int area = detail::Counterclockwise(*it, it[1], it[2]);
                if(area == 0)
                {
                    // Three collinear vertices
                    mid_tri.Origin(*it);
                    mid_tri.Destination(it[1]);
                    tri1.Origin(it[1]);
                    tri1.Destination(*it);
                    tri2.Origin(it[2]);
                    tri2.Destination(it[1]);
                    tri3.Origin(it[1]);
                    tri3.Destination(it[2]);
                    mid_tri.Apex(NULL);
                    Join(mid_tri, tri1);
                    Join(tri2, tri3);
                    mid_tri.Rotate();
                    tri1.InverseRotate();
                    tri2.Rotate();
                    tri3.InverseRotate();
                    Join(mid_tri, tri3);
                    Join(tri1, tri2);
                    mid_tri.Rotate();
                    tri1.InverseRotate();
                    tri2.Rotate();
                    tri3.InverseRotate();
                    Join(mid_tri, tri1);
                    Join(tri2, tri3);
                    //setto tri_begin a it[0]
                    tri_begin = tri1;
                    //setto trient a it[2]
                    tri_end = tri2;
                }
                else
                {
                    // The three vertices are not collinear
                    mid_tri.Origin(*it);
                    tri1.Destination(*it);
                    tri3.Origin(*it);
                    if(area > 0)
                    {
                        // The vertices are in Counterclockwise order.
                        mid_tri.Destination(it[1]);
                        tri1.Origin(it[1]);
                        tri2.Destination(it[1]);
                        mid_tri.Apex(it[2]);
                        tri2.Origin(it[2]);
                        tri3.Destination(it[2]);
                    }
                    else
                    {
                        // The vertices are in clockwise order.
                        mid_tri.Destination(it[2]);
                        tri1.Origin(it[2]);
                        tri2.Destination(it[2]);
                        mid_tri.Apex(it[1]);
                        tri2.Origin(it[1]);
                        tri3.Destination(it[1]);
                    }
                    Join(mid_tri, tri1);
                    mid_tri.Rotate();
                    Join(mid_tri, tri2);
                    mid_tri.Rotate();
                    Join(mid_tri, tri3);
                    tri1.InverseRotate();
                    tri2.Rotate();
                    Join(tri1, tri2);
                    tri1.InverseRotate();
                    tri3.InverseRotate();
                    Join(tri1, tri3);
                    tri2.Rotate();
                    tri3.InverseRotate();
                    Join(tri2, tri3);
                    //setto tri_begin a it[0]
                    tri_begin = tri1;
                    //setto trient a it[2]
                    if(area > 0)
                        tri_end = tri2;
                    else
                        Rotate(tri_begin, tri_end);

                }

            }
            else
            {
                HullCursorType inner_left, inner_right;
                int half = size >> 1;
                int nextaxis = (m_sort == Cut::XY) ? 1 - axis : axis;

                thread >>= 1;
                if(thread > 0)
                {
                    boost::thread left(boost::bind(&DelaunayTriangulation<T>::DivConq, this, it, it + half, boost::ref(tri_begin), boost::ref(inner_left), nextaxis, thread));
                    boost::thread right(boost::bind(&DelaunayTriangulation<T>::DivConq, this, it + half, end, boost::ref(inner_right), boost::ref(tri_end), nextaxis, thread));
                    left.join();
                    right.join();
                }
                else
                {
                    DivConq(it, it + half, tri_begin, inner_left, nextaxis, thread);
                    DivConq(it + half, end, inner_right, tri_end, nextaxis, thread);
                }
                MergeHulls(tri_begin, inner_left, inner_right, tri_end, axis);
            }
    }


}

#endif
