#ifndef _GAUSSIAN_FILTER_H
#define _GAUSSIAN_FILTER_H

#include "ConvolutionKernel.h"
#include "ConvolutiveFilter.h"
#include <Processing/Vision/CImage/Filters/TLocalFilter.h>
#include <Processing/Vision/CImage/Filters/FilterModifier.h>
#include <Processing/Math/Gaussian.h>

/** @file GaussianFilter.h
  * @brief Filtri gaussiani
  **/

namespace cimage {
  
namespace kernel {  

/**
 * \brief Implementa il calcolo di un filtro passa basso 3x3 di varianza 0.85 in fixed point (non normalizzato)
*/
class Gaussian3x3UnNorm: public TConvolutionKernel3x3<1,2,1, 2,4,2, 1,2,1>
{
};

/**
 * \brief Implementa il calcolo di filtro passa basso usando una Gaussiana di varianza indicata
 * @note to use RGB8 include ConvolutiveFilter.hxx
 * \code
 * // alloco un filtro gaussiano di varianza 1.2
 * TLocalFilter< kernel::Gaussian<float> > filter(1.2f);
 * // ...
 * filter(CImageSrc, CImageDst);
 * \endcode
*/
template<typename Precision>
class Gaussian: public Convolutive<Precision> {
    public:
    // unbiased filter
    static const int bias = 0; 
    // do not change sign
    static const bool positive = true;
    // do not alter energy
    static const unsigned int magnitude = 1;    
  
	public:
	/** inizializza la Gaussiana **/
	Gaussian(Precision var = 0.85)
	{
	SetVariance(var);
	}

	~Gaussian() {
	}

	/** Change the filter variance **/
	void SetVariance(Precision sigma)
	{
	// in 2.5 volte la varianza c'e' il 90% della gaussiana
	int size = (unsigned int) ( 1 + 2 * ceil(2.5 * sigma) );
	Convolutive<Precision>::SetGeometry(size, size);
	math::make_2d_gaussian_filter(Convolutive<Precision>::GetKernel(), sigma, size);
	}
};

/////////// filtri prefabbricati /////////////////

/** Filtro Gaussiano 3x3 di varianza 0.85 normalizzato **/
typedef filter::Div<Gaussian3x3UnNorm, 16> Gaussian3x3;

}

namespace filter {
  
  /** Filtro Gaussiano Stock di varianza 0.85 */
  typedef TLocalFilter< kernel::Gaussian3x3 > Gaussian3x3;
  
  /** Filtro Gaussiano di varianza impostabile  
  * \code
  * // alloco un filtro gaussiano di varianza 1.2
  * filter::Gaussian filter(1.2f);
  * filter.SetVariance( ... change variance value ...)
  * // ...
  * filter(CImageSrc, CImageDst);
  * \endcode
  */
  typedef TLocalFilter< kernel::Gaussian<float> > Gaussian;
}

} // namespace cimage

#endif
