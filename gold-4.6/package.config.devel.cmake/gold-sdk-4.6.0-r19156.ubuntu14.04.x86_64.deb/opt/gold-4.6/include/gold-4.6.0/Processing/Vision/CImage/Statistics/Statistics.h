#ifndef _CIMAGE_STATISTICS_H
#define _CIMAGE_STATISTICS_H

#include <vector>

#include <Processing/Vision/CImage/gold_proc_cimage_export.h>
#include <Data/CImage/TImage.h>

namespace cimage
{
// Calcoli sull'immagine e statistiche di base

/// calcola la media sui punti di un sottoinsieme regolare
// virtual StatisticType GetMean ( unsigned int Start=0, unsigned int Stride=1, unsigned int _Size=0, unsigned int PCh=0, unsigned int ICh=0 ) const = 0;

/// calcola la media dei punti nel vettore
// virtual StatisticType GetMean(const std::vector<PixelCoordType>& Pixels) const = 0;

/// calcola la media sui punti di una maschera
// virtual StatisticType GetMean ( const CImage &Mask ) const = 0;

/// calcola la somma dei pixel
// virtual double GetSum(unsigned int Start=0, unsigned int Stride=1, unsigned int _Size=0, unsigned int PCh=0, unsigned int ICh=0) const = 0;

// virtual DECLSPEC_DEPRECATED CColorHistogram ColorHistogram(unsigned int Channel=0) const = 0;

// template <class S> void ColorHistogram(S* DstArray, unsigned long NumElements, unsigned int Channel=0, unsigned int Step=1) const {}
// Calcoli sull'immagine e statistiche di base
// TODO: qual'e' l'insieme minimo di parametri
// che permette di descrivere tutti i sottoinsiemi di una matrice 3D?
// start, stride e size permettono di farlo per un array 2D.
// NOTE: utilizzare una slice, struttura che permette di identificare regioni regolari
// NOTE: le funzioni che operano su sottoinsiemi dovrebbero essere:
// - sottoinsiemi regolari
// - maschera
// - lista di punti prepopolata

  typedef std::vector<double> StatisticType;         ///< ritorna un valore per ciascun canale

  // 
  /**
   * calcola la media di una immagine. Ritorna un vettore di double in cui ciascun elemento è la media per il canale i-esimo
   * @param Image immagine sorgente
   * @param Start offset in pixel per la partenza del calcolo
   * @param Stride pixel dal saltare per ogni iterazione
   * @return
   */
  template<class T>
  cimage::StatisticType Mean ( const TImage<T>& Image, unsigned int Start=0, 
						unsigned int Stride=1, unsigned int _Size=0, 
						unsigned int PCh=0, unsigned int ICh=0 );

  cimage::StatisticType Mean ( const CImage& Image, unsigned int Start=0, 
						unsigned int Stride=1, unsigned int _Size=0, 
						unsigned int PCh=0, unsigned int ICh=0 );



  /**
   * Funzione per il calcolo della media di una immagine su una maschera
   * @param Mask
   * @return
   */
  template<class ImageType, class MaskType>
  cimage::StatisticType Mean ( const ImageType &Image, const MaskType &Mask );


// calcola la media sui punti di un sottoinsieme regolare
// StatisticType GetMean ( unsigned int Start=0, unsigned int Stride=1, unsigned int _Size=0, unsigned int PCh=0, unsigned int ICh=0 ) const;


// calcola la media sui punti di una maschera
// StatisticType GetMean ( const CImage &Mask ) const;

// calcola la media dei punti nel vettore
// StatisticType GetMean(const std::vector<PixelCoordType>& Pixels) const { throw CMethod_Not_Implemented(); }

// double GetSum(unsigned int Start=0, unsigned int Stride=1, unsigned int _Size=0, unsigned int PCh=0, unsigned int ICh=0) const { throw CMethod_Not_Implemented(); }


// template<class T>
// cimage::StatisticType GetMean(const CImage &Mask) const
// {
//   std::cout << "20070904 this method is deprecated use the function instead" << std::endl;
//
//   typedef TImage<unsigned char> MaskType;
//
//   // TODO: la maschera deve avere un canale e
//   // la stessa dimensione dell'immagine
//   const MaskType &mask = reinterpret_cast<const MaskType& >(Mask);
//   return ::for_each_masked_sub_on_mask(*this, mask, CMean<TImage, MaskType>(*this)).GetMean();
// }
//


// TODO: separare in un file di specializzazione in CImageMono

// template<>
// double GetSum(unsigned int Start, unsigned int Stride, unsigned int _Size, unsigned int PCh, unsigned int ICh) const
// {
//   double RetVal = 0.0;
//
//   const unsigned char *Buffer = RLock();
//   for(unsigned int i=0, j=Start; i<_Size; i++, j+=Stride)
//     RetVal+=(double) *(Buffer+j);
//   UnLock();
//
//   return RetVal;
// }

// TODO: le specializzazioni di BasicOperations vanno da un'altra parte


// template<>
// // TODO: spostare in Statistics_CImageMono
// // TODO: channel
// CImage::StatisticType CImageMono::GetMean(unsigned int Start, unsigned int Stride, unsigned int _Size, unsigned int PCh, unsigned int ICh) const
// {
//   StatisticType RetVal(1, 0.0);
// 
//   const unsigned char *Buffer = RLock();
//   RetVal[0] = gsl_stats_unsigned char_mean(Buffer+Start, Stride, _Size?_Size:Size());
//   UnLock();
// 
//   return RetVal;
// }




// template<>
// // TODO: perfezionare algoritmo
// CImage::StatisticType CImageRGB8::GetMean(unsigned int Start, unsigned int Stride, unsigned int _Size, unsigned int PCh, unsigned int ICh) const
// {
//   StatisticType RetVal(3, 0.0);
//   double R=0.0, G=0.0, B=0.0, N=0.0;
// 
//   const cimage::RGB8 *Buffer = RLock()+Start+PCh;
//   const cimage::RGB8 *End    = Buffer+Area();
//   for(; Buffer<End; Buffer+=Stride, ++N)
//     R+=Buffer->R, G+=Buffer->G, B+=Buffer->B;
//   UnLock();
// 
//   RetVal[0]=R/N; 
//   RetVal[1]=G/N;
//   RetVal[2]=B/N;
// 
//   return RetVal;
// }

} // namespace cimage


#endif // _CIMAGE_STATISTICS_H


