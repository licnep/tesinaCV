#ifndef _UDISPARITYFILTER_H
#define _UDISPARITYFILTER_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2007                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file UDisparityKernel.h
 * \author Mirko Felisa (felisa@ce.unipr.it)
 * \date 2007-03-05
 */

#include "PixelTraits.h"
#include <stdint.h>

namespace cimage {

/// Per l'immagine ternarizzata usare SobelHorizontal3x3SignTh4
///       in SobelFilter.h
/// Consiglio di usare direttamente filter::Sign< SobelHorizontal3x3, 4>
///  Il numero 4 e' stata una scelta di Claudio. Si possono usare anche altre soglie.
typedef filter::Sign<SobelHorizontal3x3, 4> SobelHorizontal3x3SignTh4;

// TODO: da sistemare... appena capisco cosa fa lo ottimizzerei anche....
template<class D>
class HorizontalBiasedErosion3x3
    {

        public:

	    D bias() { return (cimage::PixelTraits<D>::Max() - cimage::PixelTraits<D>::Min())/2; }

	    template<class D2>
            inline D2 zero() const { return bias(); }

            inline uint32_t GetWidth() const { return 3; }
            inline uint32_t GetHeight() const { return 3; }

	    template<class S>
            inline D operator()(const S* inputPixel, long stride) const
            {
		typedef typename cimage::PixelTraits<S>::DifferenceType type_t;

                type_t comp = static_cast<type_t>(inputPixel[-stride-1])
                              + 2 * static_cast<type_t>(inputPixel[-stride])
                              + static_cast<type_t>(inputPixel[-stride+1])
                              + static_cast<type_t>(inputPixel[-1])
                              + static_cast<type_t>(inputPixel[+1])
                              + static_cast<type_t>(inputPixel[stride-1])
                              + 2 * static_cast<type_t>(inputPixel[stride])
                              + static_cast<type_t>(inputPixel[stride+1]);

                comp *= *inputPixel;

                return comp > type_t(0) ? static_cast<type_t>(*inputPixel * bias() + bias() ) : bias();
            }
    };
}

#endif
