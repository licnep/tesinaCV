#ifndef _DISPARITYENGINE_AGG_WINDOW_H
#define _DISPARITYENGINE_AGG_WINDOW_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2010                  *
 *                                                                    *
 *       http://www.vislab.ce.unipr.it                                *
 *                                                                    *
 **********************************************************************/


/**
 * \file Definitions.h
 * \author Paolo Zani (zani@vislab.it) Mirko Felisa (felisa@vislab.it)
 * \date 2010-09-22
 */

#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/Window/Simple/Impl.h>
#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/Window/SemiIncremental/Impl.h>
#include <Processing/Vision/Stereo/DisparityEngine/Aggregation/Window/Incremental/Impl.h>

#endif
