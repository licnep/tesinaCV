#ifndef _CIMAGE_BASIC_OPERATIONS_HXX
#define _CIMAGE_BASIC_OPERATIONS_HXX

#include <boost/math/constants/constants.hpp>

#include <Data/CImage/TImage.h>
#include <Processing/Vision/CImage/Algorithms.hxx>
#include <Processing/Vision/CImage/BasicOperations/BasicOperations.h>


// Generic implementations for Basic Operations
namespace cimage
{
  template <typename T>
  void Fill ( TImage<T>& Image, T Value )
  {
    T* pdst = Image.Buffer();

    std::fill ( pdst, pdst+Image.Area(), Value );
  }


  template <typename T>
  void Clear ( TImage<T>& Image )
  {
    Fill ( Image, TImage<T>::PixelTraits::Zero() );
  }


  template <typename T>
  void Copy ( const TImage<T>& src, TImage<T>& dst )
  {    
    // controllo per ottimizare il caso degenere 
    // di copia dello stesso buffer
    if(src.Buffer() == dst.Buffer())
        return;
       
    dst = src;
  }

  template <typename T>
  void Copy ( const void* srcBuffer, TImage<T>& dst )
  {
    T* dstBuffer = dst.Buffer();
    std::copy ( ( uint8_t * ) srcBuffer, ( ( uint8_t * ) srcBuffer ) + dst.Size(), ( uint8_t* ) dstBuffer );
  }


  template <typename T>
  void Copy ( const TImage<T>& src, void *dstBuffer )
  {
    const T * srcBuffer = src.Buffer();
    std::copy ( ( ( uint8_t * ) srcBuffer ), ( ( uint8_t * ) srcBuffer ) +  src.Size(), ( uint8_t * ) dstBuffer );
  }


  template <typename T>
  void Resize ( TImage<T>& Img, SizeType W, SizeType H )
  {
    if(Img.W()!=W || Img.H()!=H)
    {
      TImage<T> tmp( W,H );
      Img.Swap(tmp);
    }
      
  }

  template <typename T>
  void Resample ( const TImage<T>& dst, TImage<T>& src, const CImageFlag& how )
  {
    // throw std::runtime_error("  template <typename T> void Resample ( TImage<T>& dst, const TImage<T>& src, const CImageFlag& How ) Unimplemented");
  }




// export
  template <typename T>
  void Crop ( const TImage<T>& src, TImage<T>& dst, PosType left, PosType top, PosType right, PosType bottom, bool keep_size)
  {
    if ( top > bottom )
      std::swap ( top, bottom );

    if ( left > right )
      std::swap ( left, right );

    // Precondizioni
    PosType _left   = std::max ( PosType ( 0 ), left );
    PosType _top    = std::max ( PosType ( 0 ), top );
    PosType _right  = std::max ( PosType ( 0 ), right );
    PosType _bottom = std::max ( PosType ( 0 ), bottom );

    _left   = std::min ( _left, ( PosType ) src.W()-1 );
    _top    = std::min ( _top, ( PosType )  src.H()-1 );
    _right  = std::min ( _right, ( PosType ) src.W()-1 );
    _bottom = std::min ( _bottom, ( PosType ) src.H()-1 );

    // calcola le dimensioni del buffer richiesto dall'utente
    const SizeType buff_w=keep_size?std::abs ( right-left ) +1:std::abs ( _right-_left ) +1;
    const SizeType buff_h=keep_size?std::abs ( bottom-top ) +1:std::abs ( _bottom-_top ) +1;

    if ( buff_w!=dst.W() || buff_h!=dst.H() )
      throw std::runtime_error ( "Crop: bad destination size" );

    // calcola la posizione nel buffer destinazione da cui deve cominciare l'immagine sorgente
    const SizeType VOffset = keep_size?std::abs ( _top - top ) :0;
    const SizeType HOffset = keep_size?std::abs ( _left - left ) :0;

    // log_debug << "VOffset =  " << VOffset << " HOffset = " << HOffset << std::endl;

    const T* m_src = src.Buffer();
    T*       m_dst = dst.Buffer();

    // pulisce il buffer
    for ( unsigned int i = 0; i < buff_w*buff_h; ++i )
      m_dst[i] = TImage<T>::PixelTraits::Zero();

    // calcola le dimensioni del buffer effettivo disponibile all'interno dell'immagine
    const SizeType row_size= ( std::abs ( _right-_left ) +1 ) *sizeof ( T );

    // riempie la destinazione con la sottoimmagine (scansione per righe)
    for ( int i=_top, j = VOffset; i <= _bottom; ++i, ++j )
      // memcpy(((uint8_t*) m_dst + j*Buffer.W() + HOffset ), (const uint8_t*) m_src + i*m_width + _left , row_size);
      std::copy ( ( ( const uint8_t* ) m_src + i*src.W() + _left ),
                  ( ( const uint8_t* ) m_src + i*src.W() + _left + row_size ),
                  ( ( uint8_t* ) m_dst + j*dst.W() + HOffset )
                );
  }


  template <typename T>
  void Pan_UnFilled ( TImage<T>& src, const TImage<T>& dst, PosType x, PosType y )
  {
    SizeType m_width=src.W(), m_height=src.H();

    // TODO: errore se src e dst non hanno la stessa dimensione
    if ( x==0& & y==0 )
      dst = src;
    else if ( x==0 )
    {
      y = std::max ( std::min ( y, static_cast<PosType> ( m_height ) ), -static_cast<PosType> ( m_height ) );

      T* pdst = dst.Buffer();
      const T* psrc = src.Buffer();

      const SizeType rmin = std::max ( PosType ( 0 ), -y );
      const SizeType rmax = std::min ( m_height  - y, m_height );
      const AreaType count = ( rmax - rmin ) * m_width;

      pdst += ( std::min ( m_height, m_height+y ) * m_width - count );
      psrc += rmin * m_width;

      if ( y > 0 )
        for ( int i = ( int ) count - 1; i >= 0; --i )
          pdst[i] = psrc[i];
      else
        for ( unsigned int i = 0; i < count; ++i )
          pdst[i] = psrc[i];
    }
    //TODO: remove unnecessary buffer allocations from the code below
    else if ( y==0 )
    {
      x = std::max ( std::min ( x, PosType ( m_width ) ), - PosType ( m_width ) );

      T* pdst = dst.Buffer();
      const T* psrc = src.Buffer();

      const SizeType cmin = std::max ( PosType ( 0 ), -x );
      const SizeType cmax = std::min ( m_width - x, m_width );
      const SizeType skip = std::max ( PosType ( 0 ), x ) - cmin;

      for ( SizeType i = 0; i < m_height; ++i )
        for ( SizeType j = cmin; j < cmax; ++j )
          pdst[i*m_width+j + skip] = psrc[i * m_width + j];
    }
    else
    {

      x = std::max ( std::min ( x, static_cast<PosType> ( m_width ) ), -static_cast<PosType> ( m_width ) );
      y = std::max ( std::min ( y, static_cast<PosType> ( m_height ) ), -static_cast<PosType> ( m_height ) );

      T* pdst = dst.Buffer();
      const T* psrc = src.Buffer();

      const unsigned int cmin = std::max ( PosType ( 0 ), -x );
      const unsigned int cmax = std::min ( static_cast<PosType> ( m_width ) - x, static_cast<PosType> ( m_width ) );
      const unsigned int rmin = std::max ( PosType ( 0 ), -y );
      const unsigned int rmax = std::min ( static_cast<PosType> ( m_height ) - y, static_cast<PosType> ( m_height ) );
      const unsigned int hskip = std::max ( PosType ( 0 ), x ) - cmin;
      const unsigned int vskip = std::max ( PosType ( 0 ), y ) - rmin;

      for ( unsigned int i = rmin; i < rmax; ++i )
        for ( unsigned int j = cmin; j < cmax; ++j )
          pdst[ ( i + vskip ) * m_width + j + hskip] = psrc[i * m_width + j];
    }
  }

  template <typename T>
  void Pan ( TImage<T>& dst, const TImage<T>& src, PosType x, PosType y )
  {
    return Pan ( dst, src, x, y, TImage<T>::PixelTraits::Zero() );
  }

  // FIXME: qui deve ricevere solo TImage<T>::PixelType al posto di T
  template <typename T, typename P>
  void Pan ( const TImage<T>& src, TImage<T>& dst, PosType x, PosType y, const P& bg )
  {
    // altrimenti static assert qui in modo che fallisca a compiletimes
    if ( typeid ( T ) !=typeid ( typename TImage<T>::PixelType ) )
      throw -1;
    SizeType m_width=src.W(), m_height=src.H();

    if ( x==0 && y==0 )
      dst=src;
    else if ( x==0 )
    {
      y = std::max ( std::min ( y, PosType ( m_height ) ), -PosType ( m_height ) );

      const T* psrc = src.Buffer();
      T* pdst = dst.Buffer();

      const unsigned int bgmin = y > 0 ? 0 : ( m_height + y ) * m_width;
      const unsigned int bgmax = y > 0 ? y * m_width : m_height * m_width;

      const unsigned int rmin = std::max ( PosType ( 0 ), -y );
      const unsigned int rmax = std::min ( PosType ( m_height ) - y, PosType ( m_height ) );
      const unsigned int count = ( rmax -rmin ) * m_width;

      pdst += ( std::min ( m_height, m_height+y ) * m_width - count );
      psrc += rmin * m_width;

      if ( y > 0 )
      {
        for ( int i = ( int ) count - 1; i >= 0; --i )
          pdst[i] = psrc[i];

        for ( int i = ( int ) bgmax - 1; i >= ( int ) bgmin; --i )
          pdst[i] = bg;
      }
      else
      {
        for ( unsigned int i = 0; i < count; ++i )
          pdst[i] = psrc[i];

        for ( unsigned int i = bgmin; i < bgmax; ++i )
          pdst[i] = bg;
      }
    }
    else if ( y==0 )
    {
      x = std::max ( std::min ( x, PosType ( m_width ) ), -PosType ( m_width ) );

      T* pdst = dst.Buffer();
      const T* psrc = src.Buffer();

      const PosType bgmin = x > 0 ? 0 : m_width + x;
      const PosType bgmax = x > 0 ? x  : m_width;

      for ( PosType i = 0; i < PosType ( m_height ); ++i )
        for ( PosType j = bgmin; j < bgmax; ++j )
          pdst[i*m_width + j] = bg;

      const PosType cmin = std::max ( PosType ( 0 ), -x );
      const PosType cmax = std::min ( PosType ( m_width ) - x, PosType ( m_width ) );
      const PosType skip = std::max ( PosType ( 0 ), x ) - cmin;

      for ( PosType i = 0; i < PosType ( m_height ); ++i )
        for ( PosType j = cmin; j < cmax; ++j )
          pdst[i*m_width+j + skip] = psrc[i * m_width + j];
    }
    else
    {

      x = std::max ( std::min ( x, PosType ( m_width ) ), -PosType ( m_width ) );
      y = std::max ( std::min ( y, PosType ( m_height ) ), -PosType ( m_height ) );

      T* pdst = dst.Buffer();
      const T* psrc = src.Buffer();

      const unsigned int bgminr_idx = y > 0 ? 0 : ( m_height + y ) * m_width;
      const unsigned int bgmaxr_idx = y > 0 ? y * m_width : m_height * m_width;
      const unsigned int bgminc = x > 0 ? 0 : m_width + x;
      const unsigned int bgmaxc = x > 0 ? x : m_width;
      const unsigned int bgc_minr = std::max ( y, PosType ( 0 ) );
      const unsigned int bgc_maxr = std::min ( m_height, m_height + y );

      for ( unsigned int i = bgminr_idx; i < bgmaxr_idx; ++i )
        pdst[i] = bg;

      for ( unsigned int i = bgc_minr; i < bgc_maxr; ++i )
        for ( unsigned int j = bgminc; j < bgmaxc; ++j )
          pdst[i * m_width + j] = bg;

      const unsigned int cmin = std::max ( PosType ( 0 ), -x );
      const unsigned int cmax = std::min ( PosType ( m_width ) - x, PosType ( m_width ) );
      const unsigned int rmin = std::max ( PosType ( 0 ), -y );
      const unsigned int rmax = std::min ( PosType ( m_height ) - y, PosType ( m_height ) );
      const unsigned int hskip = std::max ( PosType ( 0 ), x ) - cmin;
      const unsigned int vskip = std::max ( PosType ( 0 ), y ) - rmin;

      for ( unsigned int i = rmin; i < rmax; ++i )
        for ( unsigned int j = cmin; j < cmax; ++j )
          pdst[ ( i + vskip ) * m_width + j + hskip] = psrc[i * m_width + j];

    }
  }


  template <typename T>
  void Rotate (const TImage<T>& src, TImage<T>& dst, double angle, ANGLE_UNIT unit )
  {
    if ( unit==RADIANTS )
      angle*= ( 180.0/boost::math::constants::pi<double>() );

    SizeType m_width=src.W(), m_height=src.H();
    AreaType m_area = src.Area();

    // TODO: si possono eliminare le sottrazioni con indici aggiuntivi da incrementare
    // TODO: la condizione andrebbe verificata per ogni periodicita' (2*K*M_PI)
    if ( fabs ( angle-90.0 ) <std::numeric_limits<double>::epsilon() ||
            fabs ( angle+270.0 ) <std::numeric_limits<double>::epsilon() )
    {
      const T* psrc = src.Buffer();
      T* pdst = dst.Buffer();

      T* pTmpdst=pdst+m_area-m_height;
      for ( SizeType jj=0; jj<m_height; ++jj, pTmpdst=pdst+m_area-m_height+jj )
        for ( SizeType ii=0; ii<m_width; ++ii, ++psrc, pTmpdst-=m_height )
          *pTmpdst=*psrc;
    }
    else if ( fabs ( angle-180.0 ) <std::numeric_limits<double>::epsilon() ||
              fabs ( angle+180.0 ) <std::numeric_limits<double>::epsilon() )
    {
      const T* psrc = src.Buffer();
      T* pdst = dst.Buffer() + m_area;

      for ( AreaType ii=0; ii<m_area; --pdst, ++psrc, ++ii )
        *pdst=*psrc;
    }
    else if ( fabs ( angle+90.0 ) <std::numeric_limits<double>::epsilon() ||
              fabs ( angle-270.0 ) <std::numeric_limits<double>::epsilon() )
    {
      const T* psrc = src.Buffer();
      T* pdst = dst.Buffer();

      T* pTmpdst=pdst+m_height-1;
      for ( SizeType jj = 0; jj<m_height; ++jj, pTmpdst=pdst+m_height-jj-1 )
        for ( SizeType ii=0; ii<m_width; ++ii, ++psrc, pTmpdst+=m_height )
          *pTmpdst=*psrc;
    }
    else if ( fabs ( angle-360.0 ) <std::numeric_limits<double>::epsilon() ||
              fabs ( angle+360.0 ) <std::numeric_limits<double>::epsilon() ||
              fabs ( angle-0.0 ) <std::numeric_limits<double>::epsilon() ) {} // nothing to do
    else
      ;// log_debug << "Free rotation not implemented yet." << std::endl;
  }


  template <typename T>
  void RotateC (const TImage<T>& src, TImage<T>& dst, double xc, double yc, double angle, ANGLE_UNIT unit )
  {
    throw std::runtime_error ( "To be implemented" );
  }
  
  
  template <typename T>
  void DeInterlace_OddField( const TImage<T>& src, TImage<T>& dst )
  {
    if((dst.W() != src.W()) || (dst.H()!=src.H()/2))
      throw std::runtime_error("DeInterlace_OddField bad argument geometry");
    
    SizeType m_width=src.W(), m_height=src.H();
    
    const T* psrc = src.Buffer();
    T* pdst = dst.Buffer();    
    
    for ( SizeType jj = 0; jj<m_height; jj+=2, psrc+=m_width )
      for ( SizeType ii=0; ii<m_width; ++ii, ++psrc, ++pdst )
        *pdst=*psrc;          
  }


  template <typename T>
  void LinComb(const TImage<T>& src_i, double a_i, TImage<T>& dst)
  {
    cimage::functors::LinComb_self<T> lin_comb_self(a_i);
    cimage::algorithms::transform_self ( src_i, dst, dst, lin_comb_self );
  }

  /**
   * Testa se l'immagine sorgente è vuota
   * @param src Immagine da testare
   * @return true se l'immagine è vuota (tutti i pixel a zero), false altrimenti
   */
  template <typename T>
  bool IsEmpty ( const TImage<T>& Image )
  {
    const T* psrc = Image.Buffer();
    typename cimage::AreaType counter=0;

    for(typename cimage::AreaType i=0; i<Image.Area();++i,++psrc)
      if(*psrc==TImage<T>::PixelTraits::Zero())
        counter++;

    if(counter>Image.Area()/2)
      std::cout << "Empty Image detected" << std::endl;

    return (counter>Image.Area()/2);
  }

  // altra implementazione più breve
  //   template <class T> GOLD_PROC_CIMAGE_EXPORT bool IsEmpty ( const TImage<T>& src )
  //   {
  //     return HasEachPixelValue ( src, PixelTraits<T>::Zero() );
  //   }

} // namespace cimages

#endif
