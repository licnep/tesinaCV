#ifndef _HARRIS_H
#define _HARRIS_H

/** @file Harris.h
  * @brief Funzioni per calcolare l'immagine di Harris
  **/

#include <Processing/Vision/CImage/gold_proc_cimage_export.h>

/** Dato una immagine in toni di grigio @a input ritorna i due buffer @a gradX @a gradY con il gradiente orizzontale e verticale
 * @note e' una funzione di comodo per Harris
 **/
GOLD_PROC_CIMAGE_EXPORT void ll_grey_DerivativeGradient(signed char *gradX, signed char *gradY, const unsigned char *input, int width, int height);

/** Dato una immagine in toni di grigio @a input ritorna i due buffer @a gradX @a gradY con il gradiente orizzontale e verticale usando il filtro di Sobel 3x3
 * @note e' una funzione di comodo per Harris
 **/
GOLD_PROC_CIMAGE_EXPORT void ll_grey_SobelGradient(signed char *gradX, signed char *gradY, const unsigned char *input, int width, int height);

/** Date le immagini dei gradienti orizzontali (@a pGradImgX ) e verticali (@a pGradImgY )
 *   ritorna l'immagine dei corner di Harris @a H
 * @param H Un buffer width x height
 * @param harrisWindow dimensione della finestra di correlazione (numero dispari, esempio 3,5,7)
 * @param kHarris costante di Harris (vale da 0 a 0.25 e solitamente e' 0.04)
 *
 * \code
 *  ll_grey_DerivativeGradient(gradX, gradY, src, width , height);
 *  HarrisCorner(H, gradX, gradY, width , height, m_harris_window_size, m_harris_k);
 * \endcode
 **/
GOLD_PROC_CIMAGE_EXPORT void HarrisCorner(int *H, const signed char *pGradImgX, const signed char *pGradImgY, unsigned int width, unsigned int height, unsigned int harrisWindow, float kHarris);

/** Date le immagini dei gradienti orizzontali (@a pGradImgX ) e verticali (@a pGradImgY )
 *   ritorna l'immagine del valore del piu' piccolo autovalore (Shi e Tomasi)
 * @param H Un buffer width x height
 * @param harrisWindow dimensione della finestra di correlazione (numero dispari, esempio 3,5,7)
 **/
GOLD_PROC_CIMAGE_EXPORT void ShiTomasiCorner(int *H, const signed char *pGradImgX, const signed char *pGradImgY, unsigned int width, unsigned int height, unsigned int harrisWindow);

/** Date le immagini dei gradienti orizzontali (@a pGradImgX ) e verticali (@a pGradImgY )
 *   ritorna l'immagine del valore come rapporto del determinante e la traccia (Forstner)
 * @param H Un buffer width x height
 * @param harrisWindow dimensione della finestra di correlazione (numero dispari, esempio 3,5,7)
 **/
GOLD_PROC_CIMAGE_EXPORT void ForstnerCorner(int *H, const signed char *pGradImgX, const signed char *pGradImgY, unsigned int width, unsigned int height, unsigned int harrisWindow);

/** Converte un buffer di interi H contenente il valore dei corner in un buffer di char disegnabile  */
GOLD_PROC_CIMAGE_EXPORT void DrawableHarrisImage(unsigned char *out, const int *H, unsigned int width, unsigned int height, float factor);

/** Converte un buffer di interi H contenente il valore dei mini autovalori in un buffer di char disegnabile  */
GOLD_PROC_CIMAGE_EXPORT void DrawableMinEigenvalueImage(unsigned char *out, const int *H, unsigned int width, unsigned int height, float factor);


#endif
