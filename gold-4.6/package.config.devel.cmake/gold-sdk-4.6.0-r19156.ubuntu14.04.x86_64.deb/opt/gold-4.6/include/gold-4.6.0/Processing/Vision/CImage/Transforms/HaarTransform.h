#ifndef _HAAR_TRANSFORM_H
#define _HAAR_TRANSFORM_H

#include <Data/CImage/TImage.h>

namespace cimage {

/** trasforma il buffer @a buf usando la trasformata di haar
  * @param buf un buffer che viene distrutto e sostituito con la sua trasformata
  * @param width,height dimensione del buffer
  * @param levels numero di successive applicazioni della trasformata (da 1 a log2(min(w,h)) )
  * @note 4msec su bw 640x480 levels>=3
  **/
template<class T>
GOLD_PROC_CIMAGE_EXPORT void HaarTransform(T *buf, unsigned int width, unsigned int height, unsigned int levels); 

/** trasforma il buffer @a buf usando la trasformata di haar
  * @param buf un buffer che viene distrutto e sostituito con la sua trasformata
  * @param width,height dimensione del buffer
  * @param levels numero di successive applicazioni della trasformata (da 1 a log2(min(w,h)) )
  * @note 4msec su bw 640x480 levels>=3
  **/
template<class T>
GOLD_PROC_CIMAGE_EXPORT void HaarTransform(TImage<T> *buf, unsigned int levels); 

}

#endif
