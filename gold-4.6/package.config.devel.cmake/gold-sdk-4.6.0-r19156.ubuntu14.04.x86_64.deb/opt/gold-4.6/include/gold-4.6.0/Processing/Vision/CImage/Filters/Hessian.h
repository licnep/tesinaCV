#ifndef _HESSIAN_H
#define _HESSIAN_H

/** @file Hessian.h
  * @brief Header to handle hessian image and transformation
  **/

#include <Processing/Vision/CImage/gold_proc_cimage_export.h>
#include <Data/Math/Points.h>


/** Calcola l'hessiana S = rxx * ryy - rxy * rxy e le derivate parziali (necessarie per la SubPixelAccuracy)
 * @param S [out] l'immagine hessiana
 * @param rxx [out] la derivata dx^2 dell'immagine
 * @param rxy [out] la derivata dxy dell'immagine
 * @param ryy [out] la derivata dy^2 dell'immagine
 * @param dx [in] la derivata dx dell'immagine (Sobel, Prewitt, Derivative o quello che si preferisce)
 * @param dy [in] la derivata dy dell'immagine (Sobel, Prewitt, Derivative o quello che si preferisce)
 * @param width,height Image geometry
 **/
GOLD_PROC_CIMAGE_EXPORT void SobelHessianEx(int * S, signed char *rxx, signed char *rxy, signed char *ryy, const signed char *dx, const signed char *dy, int width, int height);

/** Estrae la funzione S = rxx * ryy - rxy * rxy
 * @param S [out] l'immagine hessiana
 * @param dx [in] la derivata dx dell'immagine (Sobel, Prewitt, Derivative o quello che si preferisce)
 * @param dy [in] la derivata dy dell'immagine (Sobel, Prewitt, Derivative o quello che si preferisce)
 * @param width,height Image geometry
 **/
GOLD_PROC_CIMAGE_EXPORT void SobelHessian(int *S, const signed char *dx, const signed char *dy, int width, int height);

/** ritorna il minimo/massimo nell'interno del punto x,y con subpixel accuracy
 * cerca il minimo/massimo della funzione
 * @param rxx,rxy,ryy derivate seconde parziali nel punto
 * @param dx,dy derivate prime parziali nel punto
 * @return il punto di minimo/massimo nell'intorno
 **/
inline math::Point2f SubPixelAccuracy(int rxx, int rxy, int ryy, int dx, int dy)
  {
  float den = 1.0f/(float)(rxx*ryy-rxy*rxy);
  return math::Point2f(
    (float)(dy * rxy - dx * ryy)*den,
    (float)(dx * rxy - dy * rxx)*den
    );
  }

#endif
