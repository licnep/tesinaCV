#ifndef _TLOCALFILTER_HXX
#define _TLOCALFILTER_HXX

#include <vector>

/* clearance:
 *  un filtro n x m quando processa un'immagine w x h non processa
 *  left: n/2 ((n-1)/2 per i dispari, n/2 per i pari)
 *  right (n-1)-left complemento
 *  top: m/2 (... bla bla)
 *  bottom (m-1)-top complemento
 * l'area attiva pertanto risulta
 *  active_width = width - left - right = -( n-1+n/2 ) = 
 * */

namespace cimage 
{
// namespace filter 
// {
 
/// riempie i bordi di S(0)
template< class S>
void FillBorders(S* output, uint32_t width, uint32_t height, uint32_t win_w, uint32_t win_h)
{

    const uint32_t l_half_w =  win_w / 2;
    const uint32_t t_half_h =  win_h / 2;
    const uint32_t r_half_w =  (win_w - 1) / 2;
    const uint32_t b_half_h =  (win_h - 1) / 2;
    
    for(uint32_t k = 0; k < width * t_half_h; k++)
      *output++= S(0);    
        
    for(uint32_t k = 0; k < height - win_h + 1; k++)
    {
        for(uint32_t h = 0; h < l_half_w; h++)
            *output++= S(0);

        output += width - win_w + 1;

        for(uint32_t h = 0; h < r_half_w; h++)
            *output++= S(0);
    }
    
    for(uint32_t k = 0; k < width * b_half_h; k++)
      *output++= S(0);   
    
}
  
template<class F>
template<class S, class D>
void TLocalFilter<F>::render(const S* input, D* output, uint32_t width, uint32_t count, long source_stride)
{
    //larghezza bordo a sx e dx dell'immagine che non devo elaborare ma semplicemente azzerrare
    const uint32_t left = this->GetWidth()/2;
    const uint32_t right = (this->GetWidth()-1)-left;

    const D _zero = F::template zero<D>();

    for(uint32_t k = 0; k < count; k++)
    {
    for(uint32_t h = 0; h < left; h++)
        *output++=_zero;

    for(uint32_t j=left; j<(width-right); j++)
        {
        *output++ = F::operator()(&input[j], source_stride);
        }

    for(uint32_t h = 0; h < right; h++)
        *output++=_zero;

    input += source_stride;
    }    
}

template<class F>
template<class S, class D>
void TLocalFilter<F>::mcore(const S * input, D * output, uint32_t width, long input_stride, uint32_t count, uint32_t slice  )
{
//// codice solo per *NIX
//// Alcuni test non hanno mostrato prestazioni migliori
#if (defined(__linux__)) && (defined(ENABLE_AFFINITY))
	cpu_set_t mask;
        CPU_ZERO(&mask);
        CPU_SET(slice, &mask);
        pthread_setaffinity_np(pthread_self(), sizeof(mask), &mask);
#endif

render<S,D>(input, output, width, count, input_stride);
}


template<class F>
template<class S, class D>
inline void TLocalFilter<F>::apply(const S* input, D* output, uint32_t width, uint32_t height, long source_stride)
{
     if(!ipp::implementation<F, S, D>::run(*this, input, output, width, height, source_stride))
       apply2(input, output, width, height, source_stride);  
}


template<class F>
template<class S, class D>
void TLocalFilter<F>::apply2(const S* input, D* output, uint32_t width, uint32_t height, long source_stride)
{
    const uint32_t top = this->GetHeight()/2;			// prima riga da processare (inclusa) {se dispari (h-1)/2, se pari h/2)
    const uint32_t bottom = (this->GetHeight()-1) - top;	// clearance nel bottom {il complemento del top a height, se dispari (h+1)/2 }
    const uint32_t active = height - top - bottom;		// numero effettivo di pixel da processare

    const D _zero = F::template zero<D>();

    // cancello <top> linee in alto
    for(uint32_t h = 0; h < width * top; h++)
	*output++ = _zero;

    // sposto input di <top> linee
    input += source_stride * top;

    if(m_nCores > 1)
    {
    std::vector<boost::thread*> v(m_nCores);
    // boost::thread_group thread_pool_;

    for(int32_t k = 0; k < m_nCores; k++)
        {
        uint32_t k0 = (active * k) / m_nCores;      // prima riga da assegnare a questo core
        uint32_t k1 = (active * (k+1) ) / m_nCores; // ultima riga (non compresa) da assegnare a questo core

        // nota: se non si usa l'affinity usare direttamente render<S,D> invece di mcore
        // thread_pool_.create_thread(
        //         boost::bind(&TLocalFilter<F>::template mcore<S,D>, this,
        //                 input + k0 * source_stride,
        //                 output + k0 * width, (uint32_t) width, (long) source_stride, k1 - k0, k));

        v[k] = new boost::thread(boost::bind(&TLocalFilter<F>::template mcore<S,D>, this,
                        input + k0 * source_stride,
                        output + k0 * width, (uint32_t) width, (long) source_stride, k1 - k0, k));
        }        

    // aspetto che i thread terminino il processing
    for(int32_t k = 0; k < m_nCores; k++)
      {
      v[k]->join();
      delete v[k];
      }
    }
    else
    {
      // single thread: eseguo direttamente il calcolo
      render<S,D>(input, output, width, active, source_stride);
    }

    output += active * width;

    // cancello bottom linee in basso
    for(uint32_t h = 0; h < width * bottom; h++)
	*output++=_zero;

}

template<class F>
template<class S, class D1, class D2>
void TLocalFilter<F>::apply(const S* input, D1* output1, D2* output2, uint32_t width, uint32_t height, long source_stride)
{
//larghezza bordo sopra e sotto l'immagine che non devo elaborare ma semplicemente azzerrare
// NOTE una dimensione Height/Width Pari produce un top/left > di bottom/right
const uint32_t top = this->GetHeight()/2;
const uint32_t bottom = (this->GetHeight()-1)-top;

//larghezza bordo a sx e dx dell'immagine che non devo elaborare ma semplicemente azzerrare
const uint32_t left = this->GetWidth()/2;
const uint32_t right = (this->GetWidth()-1)-left;

const D1 _zero1 = F::template first_zero<D1>();
const D2 _zero2 = F::template second_zero<D2>();

for(uint32_t h = 0; h < width * top; h++)
    { *output1++ = _zero1; *output2++ = _zero2; }

input += source_stride * top;

for(uint32_t k = top; k < (height-bottom); k++)
    {

    for(uint32_t h = 0; h < left; h++)
	{ *output1++ = _zero1; *output2++ = _zero2; }

    for(uint32_t j=left; j<(width-right); j++)
	{
	__split(F::operator()(&input[j], source_stride), output1, output2);
	output1++;
	output2++;
	}

    for(uint32_t h = 0; h < right; h++)
	{ *output1++ = _zero1; *output2++ = _zero2; }

    input += source_stride;
    }

for(uint32_t h = 0; h < width * bottom; h++)
    { *output1++ = _zero1; *output2++ = _zero2; }
}

template<class A, class B>
template<class D1, class D2>
void TLocalFilter<A,B>::fill_border(D1* output1, D2* output2, uint32_t width, uint32_t kvb, long source_stride)
{
  const D1 _zero1 = first.template zero<D1>();
  const D2 _zero2 = second.template zero<D2>();

  for(uint32_t h = 0; h < width * kvb; h++)
      { *output1++ = _zero1; *output2++ = _zero2; }
  
}


template<class A, class B>
template<class S, class D1, class D2>
void TLocalFilter<A,B>::operator()(const S* input, D1* output1, D2* output2, uint32_t width, uint32_t height)
{
    const uint32_t top = this->GetHeight()/2;			// prima riga da processare (inclusa) {se dispari (h-1)/2, se pari h/2)
    const uint32_t bottom = this->GetHeight()-1-top;		// clearance nel bottom {il complemento del top a height, se dispari (h+1)/2 }
    const uint32_t active = height - top - bottom;		// numero effettivo di righe da processare
    
    // riempio il primo blocco di nero
    fill_border(output1, output2, width, top, width);

    // sposto input di <top> linee
    input += width * top;
    output1 += width * top;
    output2 += width * top;

    if(m_nCores > 1)
    {
    boost::thread_group thread_pool_;

    for(int32_t k = 0; k < m_nCores; k++)
        {
        uint32_t k0 = (active * k) / m_nCores;      // prima riga da assegnare a questo core
        uint32_t k1 = (active * (k+1) ) / m_nCores; // ultima riga, non compresa, da assegnare a questo core

        thread_pool_.create_thread(
                 boost::bind(&TLocalFilter<A,B>::template apply<S,D1,D2>, this,
                         input + k0 * width,
                         output1 + k0 * width,
			 output2 + k0 * width, 
			 (uint32_t) width, 
			 k1 - k0, 
			 width)
		);
        }        
        
     thread_pool_.join_all();

    }
    else
    {
      // single thread: eseguo direttamente il calcolo
      apply<S,D1,D2>(input, output1, output2, width, active, width);
    }

    output1 += active * width;
    output2 += active * width;
    // riempio l'ultimo blocco di nero
    fill_border(output1, output2, width, bottom, width);

}

template<class A, class B>
template<class S, class D1, class D2>
void TLocalFilter<A,B>::apply(const S* input, D1* output1, D2* output2, uint32_t width, uint32_t height, long source_stride)
  {
  //larghezza bordo a sx e dx dell'immagine che non devo elaborare ma semplicemente azzerrare
  const uint32_t left = this->GetWidth()/2;
  const uint32_t right = this->GetWidth()-1-left;

  const D1 _zero1 = first.template zero<D1>();
  const D2 _zero2 = second.template zero<D2>();

  for(uint32_t k = 0; k < height; k++)
      {
      // left bord
      for(uint32_t h = 0; h < left; h++)
	  { *output1++=_zero1; *output2++=_zero2; }

      for(uint32_t j=left; j<(width-right); j++)
	  {
	  *output1++ = first(&input[j], width);
	  *output2++ = second(&input[j], width);
	  }

      // right bord
      for(uint32_t h = 0; h < right; h++)
	  { *output1++=_zero1; *output2++=_zero2; }

      input += source_stride; // go to next row
      }

  }

// }
}

#endif

