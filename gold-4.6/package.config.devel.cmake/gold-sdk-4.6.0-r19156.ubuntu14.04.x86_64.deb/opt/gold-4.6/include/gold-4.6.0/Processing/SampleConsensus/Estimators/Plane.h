#ifndef _SAC_EST_PLANE_H
#define _SAC_EST_PLANE_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * \file Plane.h
 * \author Paolo Zani (zani@vislab.it)
 * \date 2012-04-04
 */

#define SAC_EST_PLANE_COVARIANCE_BASED_OPTIMIZER

#include <Data/Math/Planes.h>
#include <Data/Math/Points.h>
#include <Processing/SampleConsensus/detail/EstimatorTraits.hxx>

#include <Eigen/Core>
#include <Eigen/Eigenvalues>
#ifndef SAC_EST_PLANE_COVARIANCE_BASED_OPTIMIZER
    #include <Eigen/QR>
#endif

#include <boost/array.hpp>

#include <cmath>
#include <cstddef>



namespace sample_consensus
{
    namespace estimators
    {
        class Plane
        {
            public:

                /**
                 * @brief Constructor
                 * @note Optimization is performed only by the Local Optimization (LO-*) class of algorithms.
                 * @param optimization_inliers_fraction The fraction of inliers used during the optimization step, in the range [0, 1]. Defaults to 0.5
                 * @param max_soundness The ratio of the smallest eigenvalue and the second one, giving a hint about the relevance of the solution. Defaults to 0.000001.
                 **/
                Plane(double optimization_inliers_fraction = 0.05, double max_soundness = 0.000001) : m_optimization_inliers_fraction(optimization_inliers_fraction), m_max_soundness(max_soundness) {}

                /**
                 * @brief The number of 3D points needed to generate a plane.
                 * @return size_t Sample size.
                 **/
                size_t SampleSize() const { return 3; }

                /**
                 * @brief Generate a 3D plane from the given 3D points.
                 *
                 * @param [out] model The generated plane.
                 * @param [in] sample an STL-like container of points.
                 * @return true if no error occurred, false otherwise.
                 **/
                template<typename T, template<typename, typename> class Container, class Allocator>
                bool Generate(math::Plane3<T>& model, const Container<math::Point3<T>, Allocator>& sample) const
                {
                    bool valid;

                    model = math::Plane3<T>(sample[0], sample[1], sample[2], valid);
                    return valid;
                }

                /**
                 * @brief The size of the sample used during the optimization step.
                 * @note This is required only by the Local Optimization (LO-*) class of algorithms.
                 * @return size_t Sample size.
                 **/
                size_t OptimizationSampleSize(size_t inliers_size) const { return m_optimization_inliers_fraction * inliers_size; }

                /**
                 * @brief Generate a refined 3D plane from the given 3D points.
                 * @note This is required only by the Local Optimization (LO-*) class of algorithms.
                 *
                 * @param [in,out] model The generated plane.
                 * @param [in] sample an STL-like container of points.
                 * @return bool true if no error occurred, false otherwise;
                 **/
                template<typename T, template<typename, typename> class Container, class Allocator>
                bool Optimize(math::Plane3<T>& model, const Container<math::Point3<T>, Allocator>& sample) const
                {
#ifdef SAC_EST_PLANE_COVARIANCE_BASED_OPTIMIZER
                    // compute the mean of the data
                    Eigen::Matrix<T, 3, 1> mean = Eigen::Matrix<T, 3, 1>::Zero();

                    for(size_t i = 0; i < sample.size(); ++i)
                    {
                        mean(0, 0) += sample[i].x;
                        mean(1, 0) += sample[i].y;
                        mean(2, 0) += sample[i].z;
                    }
                    mean /= sample.size();

                    // compute the covariance matrix
                    Eigen::Matrix<T, 3, 3> covMat = Eigen::Matrix<T, 3, 3>::Zero();

                    for(size_t i = 0; i < sample.size(); ++i)
                    {
                        Eigen::Matrix<T, 3, 1> diff;

                        diff(0, 0) = sample[i].x - mean(0, 0);
                        diff(1, 0) = sample[i].y - mean(1, 0);
                        diff(2, 0) = sample[i].z - mean(2, 0);

                        diff = diff.conjugate();

                        covMat += diff * diff.adjoint();
                    }

                    // now we just have to pick the eigen vector with smallest eigen value
                    Eigen::SelfAdjointEigenSolver<Eigen::Matrix<T, 3, 3> > eig(covMat);

                    T a = eig.eigenvectors()(0, 0);
                    T b = eig.eigenvectors()(1, 0);
                    T c = eig.eigenvectors()(2, 0);

                    T soundness = eig.eigenvalues().coeff(0)/eig.eigenvalues().coeff(1);

                    // let's compute the constant coefficient such that the
                    // plane pass trough the mean point:
                    T d = -(a * mean(0, 0) + b * mean(1, 0) + c * mean(2, 0));

                    model = math::Plane3<T>(a, b, c, d);

                    return soundness < m_max_soundness;
#else
                    typedef typename Eigen::Matrix<T, Eigen::Dynamic, Eigen::Dynamic> MatrixAType;
                    MatrixAType A = MatrixAType::Zero(sample.size(), 4);

                    for(size_t i = 0; i < sample.size(); ++i)
                    {
                        A(i, 0) = sample[i].x;
                        A(i, 1) = sample[i].y;
                        A(i, 2) = sample[i].z;
                        A(i, 3) = 1;
                    }

                    typename Eigen::FullPivHouseholderQR<MatrixAType>::MatrixQType Q = Eigen::FullPivHouseholderQR<MatrixAType>(A.transpose()).matrixQ();

                    model = math::Plane3<T>(Q(0, 3), Q(1, 3), Q(2, 3), Q(3, 3));

                    return true;
#endif
                }

                /**
                 * @brief Check whether a 3D point is close to the given 3D plane.
                 *
                 * @param [in] model A 3D plane.
                 * @param [in] datum A 3D point.
                 * @return The euclidean distance of the point from the plane.
                 **/
                template<typename T>
                double Evaluate(const math::Plane3<T>& model, const math::Point3<T>& datum) const
                {
                    return std::abs(model.Distance(datum));
                }

            private:

                double m_optimization_inliers_fraction;
                double m_max_soundness;
        };
    }

    namespace detail
    {
        template<>
        template<typename T>
        struct EstimatorTraits<math::Plane3<T> >
        {
            typedef estimators::Plane EstimatorType;
        };
    }
}

#endif
