#ifndef _SAC_EST_LINE_H
#define _SAC_EST_LINE_H

/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2012                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/

/**
 * \file Line.h
 * \author Paolo Zani (zani@vislab.it)
 * \date 2012-03-16
 */

#include <Data/Math/Points.h>
#include <Data/Math/Lines.h>
#include <Processing/Math/Regression.hxx>
#include <Processing/SampleConsensus/detail/EstimatorTraits.hxx>

#include <cmath>
#include <cstddef>

namespace sample_consensus
{
    namespace estimators
    {
        /**
         * @brief 2D line estimation class
         **/
        class Line
        {
            public:

                /**
                 * @brief Constructor
                 * @note Optimization is performed only by the Local Optimization (LO-*) class of algorithms.
                 * @param optimization_inliers_fraction The fraction of inliers used during the optimization step, in the range [0, 1]. Defaults to 0.5
                 **/
                Line(double optimization_inliers_fraction = 0.5) : m_optimization_inliers_fraction(optimization_inliers_fraction) {}

                /**
                 * @brief The number of 2D points needed to generate a 2D line.
                 * @return size_t Sample size.
                 **/
                size_t SampleSize() const { return 2; }

                /**
                 * @brief Generate a 2D line from the given 2D points.
                 *
                 * @param [out] model The generated line.
                 * @param [in] sample an STL-like container of points.
                 * @return bool true if no error occurred, false otherwise.
                 **/
                template<typename T, template<typename, typename> class Container, class Allocator>
                bool Generate(math::Line3<T>& model, const Container<math::Point2<T>, Allocator>& sample) const
                {
                    model = math::Line3<T>(sample.front(), sample.back());
                    return true;
                }

                /**
                 * @brief The size of the sample used during the optimization step.
                 * @note This is required only by the Local Optimization (LO-*) class of algorithms.
                 * @return size_t Sample size.
                 **/
                size_t OptimizationSampleSize(size_t inliers_size) const { return std::max(inliers_size * m_optimization_inliers_fraction, static_cast<double>(SampleSize())); }

                /**
                 * @brief Generate a refined 2D line from the given 2D points.
                 * @note An orthogonal least squares fitting strategy is used.
                 * @note This is required only by the Local Optimization (LO-*) class of algorithms.
                 *
                 * @param [in,out] model The generated line.
                 * @param [in] sample an STL-like container of points.
                 * @return bool true if no error occurred, false otherwise;
                 **/
                template<typename T, template<typename, typename> class Container, class Allocator>
                bool Optimize(math::Line3<T>& model, const Container<math::Point2<T>, Allocator>& sample) const
                {
                    math::orthogonal_least_squares_fitting(model, &sample[0], sample.size());

                    return true;
                }

                /**
                 * @brief Check whether a 2D point is close to the given 2D line.
                 *
                 * @param [in] model A 2D line.
                 * @param [in] datum A 2D point.
                 * @return double The euclidean distance of the point from the line.
                 **/
                template<typename T>
                double Evaluate(const math::Line3<T>& model, const math::Point2<T>& datum) const
                {
                    return std::abs(model.distance(datum));
                }

            private:

                double m_optimization_inliers_fraction;
        };
    }

    namespace detail
    {
        template<>
        template<typename T>
        struct EstimatorTraits<math::Line3<T> >
        {
            typedef estimators::Line EstimatorType;
        };
    }
}

#endif
