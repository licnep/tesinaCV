/**********************************************************************
 *                                                                    *
 *  This file is part of the GOLD software                            *
 *                                                                    *
 *            University of Parma, Italy   1996-2009                  *
 *                                                                    *
 *       http://www.vislab.it                                         *
 *                                                                    *
 **********************************************************************/


/**
 * \file GOLD_AutoCompilerFlags.cpp
 * \author Paolo Zani (zani@vislab.it) Mirko Felisa (felisa@vislab.it)
 * \date 2009-04-01
 */

#include <algorithm>
#include <cstring>
#include <iostream>
#include <sstream>
#include <string>
#include <utility>
#include <vector>
#include <stdexcept>

#if defined (_MSC_VER)
#include <intrin.h>
#endif

#include <stdint.h>

using namespace std;

namespace acf
{
    struct db_entry_type
    {
        inline db_entry_type(const string& _key_hard, const string& _key_soft, const string& _cflags_debug, const string& _cflags_release) :
            key_hard(_key_hard), key_soft(_key_soft), cflags_debug(_cflags_debug), cflags_release(_cflags_release), cxxflags_debug(_cflags_debug), cxxflags_release(_cflags_release) {}

        inline db_entry_type(const string& _key_hard, const string& _key_soft, const string& _cflags_debug, const string& _cflags_release, const string& _cxxflags_debug, const string& _cxxflags_release) :
            key_hard(_key_hard), key_soft(_key_soft), cflags_debug(_cflags_debug), cflags_release(_cflags_release), cxxflags_debug(_cxxflags_debug), cxxflags_release(_cxxflags_release) {}

        string key_hard;
        string key_soft;

        string cflags_debug;
        string cflags_release;
        string cxxflags_debug;
        string cxxflags_release;
    };

    typedef vector<db_entry_type> db_type;

    const db_entry_type flags_db_data[] = {


        // AMD processors

        // Geode(TM) Integrated Processor by AMD PCS LX800
            // GCC
            db_entry_type("AuthenticAMD-5102-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Os -march=k6-2 -pipe -fno-align-jumps -fno-align-functions -fno-align-labels -fno-align-loops -fomit-frame-pointer -mmmx -m3dnow -DNDEBUG"),
            db_entry_type("AuthenticAMD-5102-gnuc", "40303", "-Wall -O0 -ggdb -pipe", "-Os -march=geode -pipe -fno-align-jumps -fno-align-functions -fno-align-labels -fno-align-loops -fomit-frame-pointer  -mmmx -m3dnow -DNDEBUG"),
            db_entry_type("AuthenticAMD-5102-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // MSVC
            db_entry_type("AuthenticAMD-5102-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /D NDEBUG"),

        // AMD Athlon(tm) 64 X2 Dual Core Processor 3800+
            // GCC
            db_entry_type("AuthenticAMD-15352-gnuc","40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=k8 -ftracer -fomit-frame-pointer -msse3 -msse2 -msse -mmmx -m3dnow  -DNDEBUG"),
            db_entry_type("AuthenticAMD-15352-gnuc","40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -fomit-frame-pointer -msse3 -msse2 -msse -mmmx -m3dnow -DNDEBUG"),
            db_entry_type("AuthenticAMD-15352-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // MSVC
            db_entry_type("AuthenticAMD-15352-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),

        // AMD Mobile AMD Sempron(tm) Processor 3500+
            // GCC
            db_entry_type("AuthenticAMD-15762-gnuc","40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=athlon-xp -ftracer -fomit-frame-pointer -msse3 -msse2 -msse -mmmx -m3dnow  -DNDEBUG"),
            db_entry_type("AuthenticAMD-15762-gnuc","40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -fomit-frame-pointer -msse3 -msse2 -msse -mmmx -m3dnow -DNDEBUG"),
            db_entry_type("AuthenticAMD-15762-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // MSVC
            db_entry_type("AuthenticAMD-15762-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),

        // Intel processors

        // Intel(R) Pentium(R) 4 CPU 2.80GHz
            // GCC
            db_entry_type("GenuineIntel-1529-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=pentium4 -ftracer -fomit-frame-pointer  -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-1529-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -fomit-frame-pointer  -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-1529-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -fomit-frame-pointer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-1529-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-1529-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),

        // Intel(R) Pentium(R) 4 CPU 2.80GHz
            // GCC
            db_entry_type("GenuineIntel-1533-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=pentium4 -ftracer -fomit-frame-pointer  -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-1533-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -fomit-frame-pointer  -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-1533-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -fomit-frame-pointer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-1533-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-1533-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),

        // Intel(R) Pentium(R) 4 CPU 3.20GHz
            // GCC
            db_entry_type("GenuineIntel-1534-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=pentium4 -ftracer -fomit-frame-pointer  -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-1534-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -fomit-frame-pointer  -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-1534-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -fomit-frame-pointer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-1534-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-1534-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),

        // Intel(R) Pentium(R) 4 CPU 3.00GHz
            // GCC
            db_entry_type("GenuineIntel-1541-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=pentium4 -ftracer -fomit-frame-pointer  -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-1541-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -fomit-frame-pointer  -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-1541-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -fomit-frame-pointer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-1541-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-1541-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),

        // Intel(R) Pentium(R) D CPU 3.40GHz
            // GCC
            db_entry_type("GenuineIntel-1562-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=nocona -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-1562-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-1562-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-1562-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // ICCL
            db_entry_type("GenuineIntel-1562-iccl", "100000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -xP -parallel -march=pentium4 -prefetch -align -ip -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-1562-iccl", "110100", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -xHost -opt-prefetch -align -ip  -pipe -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-1562-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),

        // Intel(R) Pentium(R) M processor 1.70GHz
            // GCC
            db_entry_type("GenuineIntel-6136-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=pentium-m -ftracer -fomit-frame-pointer -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6136-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -fomit-frame-pointer -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6136-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -fomit-frame-pointer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6136-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-6136-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),

        // Intel(R) CPU T2300 1.66GHz
            // GCC
            db_entry_type("GenuineIntel-6148-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=prescott -ftracer -fomit-frame-pointer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6148-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -fomit-frame-pointer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6148-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -fomit-frame-pointer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6148-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-6148-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),

        // Intel(R) Core(TM)2 CPU T7200 1.86GHz, Intel(R) Core(TM)2 CPU L7400 1.50GHz
            // GCC
            db_entry_type("GenuineIntel-6156-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=nocona -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6156-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6156-gnuc", "40300", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6156-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6156-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // DARWIN_GCC
            db_entry_type("GenuineIntel-6156-gnucd", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=core2 -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-6156-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),
  
        // Intel(R) Core(TM)2 Quad CPU 2.40GHz
            // GCC
            db_entry_type("GenuineIntel-6157-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=nocona -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6157-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6157-gnuc", "40300", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6157-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6157-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // DARWIN_GCC
            db_entry_type("GenuineIntel-6157-gnucd", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=core2 -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-6157-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),

        // Intel(R) Core(TM)2 Quad CPU Q6600 2.40GHz
            // GCC
            db_entry_type("GenuineIntel-61511-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=nocona -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-61511-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-61511-gnuc", "40300", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-61511-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-61511-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // DARWIN_GCC
            db_entry_type("GenuineIntel-61511-gnud", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=core2 -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-61511-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),

        //  Intel(R) Core(TM)2 Duo CPU E4500 2.20GHz
            // GCC
            db_entry_type("GenuineIntel-61513-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=nocona -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-61513-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-61513-gnuc", "40300", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-61513-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-61513-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // DARWIN_GCC
            db_entry_type("GenuineIntel-61513-gnucd", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=core2 -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-61513-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),

        //  Intel(R) Core(TM)2 Duo CPU P8600 2.40GHz
            // GCC
            db_entry_type("GenuineIntel-6236-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=nocona -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6236-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6236-gnuc", "40300", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse4.1 -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6236-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -msse4.1 -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6236-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // DARWIN_GCC
            db_entry_type("GenuineIntel-6236-gnucd", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=core2 -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-6236-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),

        // Intel(R) Core(TM)2 Quad CPU Q9550 2.83GHz
            // GCC
            db_entry_type("GenuineIntel-62310-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=nocona -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-62310-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-62310-gnuc", "40300", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse4.1 -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-62310-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -msse4.1 -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-62310-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // DARWIN_GCC
            db_entry_type("GenuineIntel-62310-gnucd", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=core2 -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-62310-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),

        // Intel(R) Core(TM) i7 CPU 920 2.67GHz
            // GCC
            db_entry_type("GenuineIntel-6265-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=nocona -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6265-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6265-gnuc", "40300", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse4.2 -msse4.1 -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6265-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -msse4.2 -msse4.1 -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6265-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -msse4.2 -msse4.1 -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6265-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // DARWIN_GCC
            db_entry_type("GenuineIntel-6265-gnucd", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=core2 -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-6265-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),

        // Intel(R) Core(TM) CPU 330 1.60GHz, Intel(R) Atom(TM) CPU Z510 1.10GHz, Intel(R) Atom(TM) CPU Z530 1.60GHz
            // GCC
            db_entry_type("GenuineIntel-6282-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=nocona -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6282-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6282-gnuc", "40300", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6282-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6282-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // DARWIN_GCC
            db_entry_type("GenuineIntel-6282-gnucd", "40200", "-Wall -O0 -ggdb -pipe ", "-Wall -O3 -fforce-addr -pipe -march=core2 -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-6282-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),

        // Intel(R) Core(TM) i7 CPU 860 2.80GHz
            // GCC
            db_entry_type("GenuineIntel-6305-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=nocona -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6305-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6305-gnuc", "40300", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse4.2 -msse4.1 -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6305-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -msse4.2 -msse4.1 -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6305-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // DARWIN_GCC
            db_entry_type("GenuineIntel-6305-gnucd", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=core2 -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-6305-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),

        // Intel(R) Core(TM) i5 CPU M 520 2.40GHz
            // GCC
            db_entry_type("GenuineIntel-6372-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=nocona -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6372-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6372-gnuc", "40300", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse4.2 -msse4.1 -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6372-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -msse4.2 -msse4.1 -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),            
            db_entry_type("GenuineIntel-6372-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // DARWIN_GCC
            db_entry_type("GenuineIntel-6372-gnucd", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=core2 -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-6372-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),
            
        // Intel(R) Core(TM) i7 CPU M 640 2.80GHz
            // GCC
            db_entry_type("GenuineIntel-6375-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=nocona -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6375-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6375-gnuc", "40300", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse4.2 -msse4.1 -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6375-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -msse4.2 -msse4.1 -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),            
            db_entry_type("GenuineIntel-6375-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // DARWIN_GCC
            db_entry_type("GenuineIntel-6375-gnucd", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=core2 -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-6375-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),
            
        // Intel(R) Core(TM) i7 CPU 2630QM 2.00GHz, Intel(R) Core(TM) i7 CPU 2600 3.40GHz
            // GCC
            db_entry_type("GenuineIntel-6427-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=nocona -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6427-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6427-gnuc", "40300", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -msse4.2 -msse4.1 -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6427-gnuc", "40400", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -msse4.2 -msse4.1 -mssse3 -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            db_entry_type("GenuineIntel-6427-gnuc", "40600", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=native -ftracer -floop-interchange -floop-strip-mine -floop-block -ftree-loop-distribution -DNDEBUG"),
            // DARWIN_GCC
            db_entry_type("GenuineIntel-6427-gnucd", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -fforce-addr -pipe -march=core2 -ftracer -msse3 -msse2 -msse -mmmx -DNDEBUG"),
            // MSVC
            db_entry_type("GenuineIntel-6427-msvc", "1600", "/MDd /D_DEBUG /Zi /Ob0 /Od /RTC1", "/MD /Ox /arch:SSE2 /D NDEBUG"),
    };

    db_type flags_db(flags_db_data, flags_db_data + sizeof(flags_db_data)/sizeof(flags_db_data[0]));

    struct less_key_hard
    {
        bool operator()(const db_entry_type& e, const string& s) { return e.key_hard < s; }
        bool operator()(const string& s, const db_entry_type& e) { return s < e.key_hard; }
        bool operator()(const db_entry_type& e1, const db_entry_type& e2) { return e1.key_hard < e2.key_hard; }
    };

    struct less_key_soft
    {
        bool operator()(const db_entry_type& e, const string& s) { return e.key_soft < s; }
        bool operator()(const string& s, const db_entry_type& e) { return s < e.key_soft; }
        bool operator()(const db_entry_type& e1, const db_entry_type& e2) { return e1.key_soft < e2.key_soft; }
    };

    struct less_key
    {
        bool operator()(const db_entry_type& e1, const db_entry_type& e2) { return e1.key_hard + e1.key_soft < e2.key_hard + e2.key_soft; }
    };

    
    
    struct cpu_registers
    {
        int32_t eax;
        int32_t ebx;
        int32_t ecx;
        int32_t edx;
        
        std::string str() const
        {
            char s[17];
            memcpy(s,this,16);
            s[16]='\0';
            return s;
            
        }
    };

    struct cpu_info
    {
        cpu_info() : arch(32), family(0), model(0), stepping(0), cpu_cores(1), mmx(0), sse(0), sse2(0), sse3(0), ssse3(0), sse4_1(0), sse4_2(0), mmxext(0), _3dnow(0), _3dnow2(0), sse4_a(0)
        {
            memset(vendor_id.raw, 0x0, sizeof(vendor_id.raw));
        }

        int arch;
        union
        {
            int raw[4];
            char c_str[4 * sizeof(int)];
        } vendor_id;
        std::string model_name;
        int family;
        int model;
        int stepping;
        int cpu_cores;
        int mmx;
        int sse;
        int sse2;
        int sse3;
        int ssse3;
        int sse4_1;
        int sse4_2;
        int mmxext;
        int _3dnow;
        int _3dnow2;
        int sse4_a;
    };

    inline cpu_registers cpuid(int cmd)
    {
        cpu_registers regs = {0, 0, 0, 0};

#if defined (_MSC_VER)
    #if _MSC_VER >= 1400
        __cpuidex((int*)&regs, cmd, 0);
    #endif
#else
    #if defined (__APPLE__)
        __asm__ __volatile__("xchgl %%ebx, %1; cpuid; xchgl %%ebx, %1" : "=a" (regs.eax), "=r" (regs.ebx), "=c" (regs.ecx), "=d" (regs.edx) : "a" (cmd), "c"(0));
    #else
        __asm__ __volatile__("cpuid" : "=a" (regs.eax), "=b" (regs.ebx), "=c" (regs.ecx), "=d" (regs.edx) : "a" (cmd), "c"(0));
    #endif
#endif

        return regs;
    }

    inline cpu_info cpuinfo()
    {
        cpu_registers regs;
        cpu_info info;

        int maxLevel;

        regs = cpuid(0x00000000);
        maxLevel = regs.eax;

        if(maxLevel > 0x00000000) {

            info.vendor_id.raw[0] = regs.ebx;
            info.vendor_id.raw[1] = regs.edx;
            info.vendor_id.raw[2] = regs.ecx;
            info.vendor_id.raw[3] = 0;
        }

        if(maxLevel >= 0x00000001) {

            regs = cpuid(0x00000001);

            info.stepping = regs.eax & 0xf;
            info.model = (((regs.eax >> 16) & 0xf) << 4) + ((regs.eax >> 4) & 0xf);
            info.family = (((regs.eax >> 20) & 0xff) << 4) + ((regs.eax >> 8) & 0xf);
            info.mmx = (regs.edx >> 23) & 0x1;
            info.sse = (regs.edx >> 25) & 0x1;
            info.sse2 = (regs.edx >> 26) & 0x1;
            info.sse3 = regs.ecx & 1;
            info.ssse3 = (regs.ecx >> 9) & 0x1;
            info.sse4_1 = (regs.ecx >> 19) & 0x1;
            info.sse4_2 = (regs.ecx >> 20) & 0x1;
        }

        regs = cpuid(0x80000000);
        int maxExtendedLevel = regs.eax;

        if(maxExtendedLevel >= 0x80000001) {

            regs = cpuid(0x80000001);
            info.mmxext = (regs.edx >> 22) & 0x1;
            info._3dnow2 = (regs.edx >> 30) & 0x1;
            info._3dnow = (regs.edx >> 31) & 0x1;
            info.sse4_a = (regs.ecx >> 6) & 0x1;
        }

        info.cpu_cores = 1;

        if(!strcmp("GenuineIntel", info.vendor_id.c_str) && maxLevel >= 0x00000004) {

           regs = cpuid(0x00000004);
           info.cpu_cores += (regs.eax >> 26) & 0x3f ;
        } else if(!strcmp("AuthenticAMD", info.vendor_id.c_str) && maxExtendedLevel >= 0x80000008) {

           regs = cpuid(0x80000008);
           info.cpu_cores += regs.ecx & 0xff ;
        }
 
 
        info.model_name = cpuid(0x80000002).str();  
        info.model_name += cpuid(0x80000003).str(); 
        info.model_name += cpuid(0x80000004).str(); 

        info.arch = sizeof(void*) << 3;

        return info;
    }
} // namespace acf

using namespace acf;

int main(int argc, char* argv[])
{
//TODO: optionally get compiler and processor from command line (useful for cross-compiling)

    ostringstream key_hard;
    ostringstream key_soft;
    db_type guessed_flags;

    cpu_info info = cpuinfo();

    key_hard << info.vendor_id.c_str << "-" << info.family << info.model << info.stepping << "-";

#if defined (__INTEL_COMPILER)
    #ifndef WIN32
        key_hard << "iccl";
        key_soft << __INTEL_COMPILER;
        guessed_flags.push_back(db_entry_type("guessed-iccl", "0000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -pipe -DNDEBUG"));
    #else
        key_hard << "iccw";
        key_soft << __INTEL_COMPILER;
        guessed_flags.push_back(db_entry_type("guessed-iccw", "0000", "", ""));
    #endif

    string module_ldflags_release = "";
    string shared_ldflags_release = "";
    string exe_ldflags_release = "";

    string module_ldflags_debug = "";
    string shared_ldflags_debug = "";
    string exe_ldflags_debug = "";

    string module_ldflags_relwithdebinfo = "";
    string shared_ldflags_relwithdebinfo = "";
    string exe_ldflags_relwithdebinfo = "";
    
    string module_ldflags_minsizerel = "";
    string shared_ldflags_minsizerel = "";
    string exe_ldflags_minsizerel = "";
    
#elif defined (__clang__)   
    string module_ldflags_release = "-Wl,-O1 -Wl,--as-needed";
    string shared_ldflags_release = "-Wl,-O1 -Wl,--as-needed";
    string exe_ldflags_release = "-Wl,-O1";

    string module_ldflags_debug = "-Wl,-O1 -Wl,--as-needed";
    string shared_ldflags_debug = "-Wl,-O1 -Wl,--as-needed";
    string exe_ldflags_debug = "-Wl,-O1";

    string module_ldflags_relwithdebinfo = "-Wl,-O1 -Wl,--as-needed";
    string shared_ldflags_relwithdebinfo = "-Wl,-O1 -Wl,--as-needed";
    string exe_ldflags_relwithdebinfo = "-Wl,-O1";
    
    string module_ldflags_minsizerel = "-Wl,--as-needed";
    string shared_ldflags_minsizerel = "-Wl,--as-needed";
    string exe_ldflags_minsizerel = "";
    
#elif defined (__GNUC__)
    #if defined (__linux__) ||  defined (__MINGW32__)
        key_hard << "gnuc";
        key_soft << __GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__;
        #if (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__ >= 40200)
            guessed_flags.push_back(db_entry_type("guessed-gnuc", "40200", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -pipe -march=native -DNDEBUG"));
        #else
            guessed_flags.push_back(db_entry_type("guessed-gnuc", "40000", "-Wall -O0 -ggdb -pipe", "-Wall -O3 -pipe -DNDEBUG"));
        #endif

   
        string module_ldflags_release = "-Wl,-O1 -Wl,--as-needed -z defs";
        string shared_ldflags_release = "-Wl,-O1 -Wl,--as-needed -z defs";
        string exe_ldflags_release = "-Wl,-O1 -z defs";

        string module_ldflags_debug = "-Wl,-O1 -Wl,--as-needed -z defs";
        string shared_ldflags_debug = "-Wl,-O1 -Wl,--as-needed -z defs";
        string exe_ldflags_debug = "-Wl,-O1 -z defs";

        string module_ldflags_relwithdebinfo = "-Wl,-O1 -Wl,--as-needed -z defs";
        string shared_ldflags_relwithdebinfo = "-Wl,-O1 -Wl,--as-needed -z defs";
        string exe_ldflags_relwithdebinfo = "-Wl,-O1 -z defs";
        
        string module_ldflags_minsizerel = "-Wl,--as-needed -z defs";
        string shared_ldflags_minsizerel = "-Wl,--as-needed -z defs";
        string exe_ldflags_minsizerel = "-z defs";

     #elif defined (__APPLE__)
        key_hard << "gnucd";
        key_soft << __GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__;
        #if (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__ >= 40200)
            guessed_flags.push_back(db_entry_type("guessed-gnucd", "40200", "-Wall -O0 -ggdb -pipe ", "-Wall -O3 -pipe  -DNDEBUG "));
        #else
            guessed_flags.push_back(db_entry_type("guessed-gnucd", "40000", "-Wall -O0 -ggdb -pipe ", "-Wall -O3 -pipe -DNDEBUG "));
        #endif 
        string module_ldflags_release = "";
        string shared_ldflags_release = "";
        string exe_ldflags_release = "";

        string module_ldflags_debug = "";
        string shared_ldflags_debug = "";
        string exe_ldflags_debug = "";

        string module_ldflags_relwithdebinfo = "";
        string shared_ldflags_relwithdebinfo = "";
        string exe_ldflags_relwithdebinfo = "";
        
        string module_ldflags_minsizerel = "";
        string shared_ldflags_minsizerel = "";
        string exe_ldflags_minsizerel = "";
    #else
        string module_ldflags_release = "";
        string shared_ldflags_release = "";
        string exe_ldflags_release = "";

        string module_ldflags_debug = "";
        string shared_ldflags_debug = "";
        string exe_ldflags_debug = "";

        string module_ldflags_relwithdebinfo = "";
        string shared_ldflags_relwithdebinfo = "";
        string exe_ldflags_relwithdebinfo = "";
        
        string module_ldflags_minsizerel = "";
        string shared_ldflags_minsizerel = "";
        string exe_ldflags_minsizerel = "";
    #endif
#elif defined (_MSC_VER)
    key_hard << "msvc";
    key_soft << _MSC_VER;

    guessed_flags.push_back(db_entry_type("guessed-msvc", "0000", "", ""));

    string module_ldflags_release = "";
    string shared_ldflags_release = "";
    string exe_ldflags_release = "";

    string module_ldflags_debug = "";
    string shared_ldflags_debug = "";
    string exe_ldflags_debug = "";

    string module_ldflags_relwithdebinfo = "";
    string shared_ldflags_relwithdebinfo = "";
    string exe_ldflags_relwithdebinfo = "";
    
    string module_ldflags_minsizerel = "";
    string shared_ldflags_minsizerel = "";
    string exe_ldflags_minsizerel = "";
#endif

    sort(flags_db.begin(), flags_db.end(), less_key());

    pair<db_type::iterator, db_type::iterator> entry_hard = equal_range(flags_db.begin(), flags_db.end(), key_hard.str(), less_key_hard());
    db_type::iterator entry_soft = guessed_flags.begin();
	bool match = false;

    if(entry_hard.first != entry_hard.second) { // we have matches

        entry_soft = lower_bound(entry_hard.first, entry_hard.second, key_soft.str(), less_key_soft());
		match = true;

        if((entry_soft == entry_hard.second) || entry_soft->key_soft != key_soft.str()) // no exact match
            if(entry_soft != entry_hard.first) // older compiler available
                --entry_soft;
            else {

                entry_soft = guessed_flags.begin();
            	match = false;
            }
    }

    if(!entry_soft->cflags_release.empty())
        cout << "CMAKE_C_FLAGS_NATIVEREL|" << entry_soft->cflags_release << ";";
    if(!entry_soft->cxxflags_release.empty())    
        cout << "CMAKE_CXX_FLAGS_NATIVEREL|" << entry_soft->cxxflags_release << ";";
    if(!entry_soft->cflags_debug.empty())
        cout << "CMAKE_C_FLAGS_DEBUG|" << entry_soft->cflags_debug << ";";
    if(!entry_soft->cxxflags_debug.empty())
        cout << "CMAKE_CXX_FLAGS_DEBUG|" << entry_soft->cxxflags_debug << ";";

    // LDFLAGS
    
    // Debug
    if(!exe_ldflags_debug.empty())
        cout << "CMAKE_EXE_LINKER_FLAGS_DEBUG|" << exe_ldflags_debug << ";";
    if(!module_ldflags_debug.empty())
        cout << "CMAKE_MODULE_LINKER_FLAGS_DEBUG|" << module_ldflags_debug << ";";
    if(!shared_ldflags_debug.empty())
        cout << "CMAKE_SHARED_LINKER_FLAGS_DEBUG|" << shared_ldflags_debug << ";";

    // Release / NativeRel
    if(!exe_ldflags_release.empty()) {
        cout << "CMAKE_EXE_LINKER_FLAGS_RELEASE|" << exe_ldflags_release << ";";
        cout << "CMAKE_EXE_LINKER_FLAGS_NATIVEREL|" << exe_ldflags_release << ";";
    }
    
    if(!module_ldflags_release.empty()) {
        
        cout << "CMAKE_MODULE_LINKER_FLAGS_RELEASE|" << module_ldflags_release << ";";
        cout << "CMAKE_MODULE_LINKER_FLAGS_NATIVEREL|" << module_ldflags_release << ";";
    }
    
    if(!shared_ldflags_release.empty()) {
        
        cout << "CMAKE_SHARED_LINKER_FLAGS_RELEASE|" << shared_ldflags_release << ";";
        cout << "CMAKE_SHARED_LINKER_FLAGS_NATIVEREL|" << shared_ldflags_release << ";";
    }

    // RelWithDebInfo    
    if(!exe_ldflags_relwithdebinfo.empty())
        cout << "CMAKE_EXE_LINKER_FLAGS_RELWITHDEBINFO|" << exe_ldflags_relwithdebinfo << ";";
    if(!module_ldflags_relwithdebinfo.empty())
        cout << "CMAKE_MODULE_LINKER_FLAGS_RELWITHDEBINFO|" << module_ldflags_relwithdebinfo << ";";
    if(!shared_ldflags_relwithdebinfo.empty())
        cout << "CMAKE_SHARED_LINKER_FLAGS_RELWITHDEBINFO|" << shared_ldflags_relwithdebinfo << ";";
    
    // MinSizeRel
    if(!exe_ldflags_relwithdebinfo.empty())
        cout << "CMAKE_EXE_LINKER_FLAGS_MINSIZEREL|" << exe_ldflags_relwithdebinfo << ";";
    if(!module_ldflags_relwithdebinfo.empty())
        cout << "CMAKE_MODULE_LINKER_FLAGS_MINSIZEREL|" << module_ldflags_relwithdebinfo << ";";
    if(!shared_ldflags_relwithdebinfo.empty())
        cout << "CMAKE_SHARED_LINKER_FLAGS_MINSIZEREL|" << shared_ldflags_relwithdebinfo << ";";

    // cout << "PLATFORM_CPU_CORES|" << info.cpu_cores << ";"
    cout << "PLATFORM_CPU_NAME|"<<info.model_name<<";";

    if(!match)
        return -2;

    return 0;
}


